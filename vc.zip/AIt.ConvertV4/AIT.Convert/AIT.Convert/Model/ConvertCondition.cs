﻿namespace AIT.Convert.Model
{
    public class ConvertCondition
    {
        public ConvertCondition(bool hasSpread, TypeConvertDB? typeConvertDB, TypeConvertRpt? typeConvertRpt)
        {
            HasSpread = hasSpread;
            TypeConvertDB = typeConvertDB;
            TypeConvertRpt = typeConvertRpt;
        }

        public bool HasSpread { get; set; }
        public TypeConvertDB? TypeConvertDB { get; set; }
        public TypeConvertRpt? TypeConvertRpt { get; set; }
    }

    public enum TypeConvertDB
    {
        OracleToOracle,
        OaracleToSQLServer,
    }
    public enum TypeConvertRpt
    {
        VSPrintToFlexReport,
    }
}
