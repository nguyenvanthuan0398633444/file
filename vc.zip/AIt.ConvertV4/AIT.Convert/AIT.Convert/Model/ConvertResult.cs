﻿using System.Collections.Generic;

namespace AIT.Convert.Model
{
    public class ConvertResult
    {
        public bool Result { get; set; }
        public bool IsNotCode { get; set; }
        public string Before { get; set; }
        public string After { get; set; }
        public bool CommentOut{ get; set; }
        public bool DelFlg { get; set; }
        public bool AddFlg {get;set;}
        public List<string> MessageID { get; set; }

        public ConvertResult(string line)
        {
            After = line;
            Before = line;
            Result = false;
            IsNotCode = false;
            DelFlg = false;
            CommentOut = false;
            AddFlg = false;
            MessageID = new List<string>();
        }
    }
}
