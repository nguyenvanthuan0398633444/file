﻿using System;
using System.IO;
using System.Windows.Forms;

namespace AIT.Convert.Logic
{
    public class LogWriter
    {
        private string m_exePath = string.Empty;
        public LogWriter(string logMessage, string txtOutputPath)
        {
            LogWrite(logMessage, txtOutputPath);
        }

        public void LogWrite(string logMessage, string txtOutputPath)
        {
            try
            {
                using (StreamWriter w = File.AppendText(txtOutputPath + "\\" + "ConvertLog.log"))
                {
                    Log(logMessage, w);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ERROR!", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        public void Log(string logMessage, TextWriter txtWriter)
        {
            try
            {
                txtWriter.Write("\r\nLog Entry : ");
                txtWriter.WriteLine("{0} {1}", DateTime.Now.ToLongTimeString(),
                    DateTime.Now.ToLongDateString());
                txtWriter.WriteLine(logMessage);
                txtWriter.WriteLine("-------------------------------");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ERROR!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
