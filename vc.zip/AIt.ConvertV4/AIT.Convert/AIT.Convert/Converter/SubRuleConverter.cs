﻿using AIT.Convert.Const;
using AIT.Convert.Model;
using AIT.Convert.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace AIT.Convert.Converter
{
    public static class SubRuleConverter
    {
        public static List<SubRuleModel> SubRules = new List<SubRuleModel>();

        /// <summary>
        /// Thực hiện kiểm tra và Convert sử dụng Rule phụ tương ứng được khai báo trong rule
        /// </summary>
        /// <param name="rule"></param>
        /// <param name="convertLine"></param>
        /// <param name="functionBlock"></param>
        public static void ConvertSubRule(RuleModel rule, ConvertResult convertLine, List<ConvertResult> functionBlock)
        {
            foreach (int id in rule.SubRuleIdList)
            {
                SubRuleModel subRule = SubRules.Where(sRule => sRule.ID == id).FirstOrDefault();
                if (subRule == null)
                {
                    continue;
                }
                Convert(rule, subRule, convertLine, functionBlock);
            }
        }

        /// <summary>
        /// Thực hiện Convert
        /// </summary>
        /// <param name="rule"></param>
        /// <param name="subRule"></param>
        /// <param name="convertLine"></param>
        /// <param name="functionBlock"></param>
        private static void Convert(RuleModel rule, SubRuleModel subRule, ConvertResult convertLine, List<ConvertResult> functionBlock)
        {
            Regex subRuleRegex = new Regex(subRule.Pattern, RegexOptions.IgnoreCase);
            if (subRuleRegex.IsMatch(convertLine.After))
            {
                if (subRule.WarningMsgId != null)
                {
                    Common.AddMessageID(convertLine, rule.WarningMsgId);
                }
                if (subRule.TodoFlg)
                {
                    Common.AddMessageID(convertLine, Constant.TodoMsgId);
                    return;
                }
                //Trong trường hợp rule phụ này yêu cầu thỏa mãn một điều kiện khác trong functionblock
                if (subRule.HasExtraCondition)
                {
                    if (!CheckExtraCondition(subRule, convertLine, functionBlock))
                    {
                        return;
                    }
                }
                // trường hợp rule phụ sẽ thay đổi một số Syntax tương ứng trong functionBlock
                if (subRule.FuncBlockSearchFlag)
                {
                    SearchAndReplaceInFuncBlock(rule, subRule, convertLine, functionBlock);
                }
                convertLine.Result = true;
                convertLine.After = subRuleRegex.Replace(convertLine.After, subRule.SubtitutionPattern);
            }
        }


        private static void SearchAndReplaceInFuncBlock(RuleModel rule, SubRuleModel subRule, ConvertResult convertLine, List<ConvertResult> functionBlock)
        {
            foreach (var item in subRule.FuncBlockSearchReplacePattern)
            {
                string[] findReplaceOfMultiline = item.Split(new string[] { ";;" }, StringSplitOptions.None);
                string findPattern = Regex.Replace(convertLine.After, subRule.Pattern, findReplaceOfMultiline[0]);
                string replacePattern = findReplaceOfMultiline[1];

                Regex findRegex = new Regex(findPattern, RegexOptions.IgnoreCase);
                ConvertResult matchedFindPattern = functionBlock.Where(i => findRegex.IsMatch(i.After)&&!i.IsNotCode).FirstOrDefault();
                if (matchedFindPattern != null)
                {
                    matchedFindPattern.After = findRegex.Replace(matchedFindPattern.After,replacePattern);
                }
            };
        }

        private static bool CheckExtraCondition(SubRuleModel subRule, ConvertResult convertLine, List<ConvertResult> functionBlock)
        {
            string extraConditionPattern = Regex.Replace(convertLine.After, subRule.Pattern, subRule.ExtraConditionPattern, RegexOptions.IgnoreCase);
            try
            {
                Regex extraConditionRegex = new Regex(extraConditionPattern, RegexOptions.IgnoreCase);
                ConvertResult sastifyExtraconditionLine = functionBlock.Where(i => extraConditionRegex.IsMatch(i.After)&&!i.IsNotCode).FirstOrDefault();
                if (sastifyExtraconditionLine != null)
                {
                    return true;
                }
                return false;
            }
            catch (System.Exception)
            {
                return false;
            }
        }

    }
}
