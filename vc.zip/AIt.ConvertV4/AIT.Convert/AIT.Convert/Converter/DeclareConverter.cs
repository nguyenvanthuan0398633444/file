﻿using AIT.Convert.Const;
using AIT.Convert.Model;
using AIT.Convert.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace AIT.Convert
{
    public static class DeclareConverter
    {
        public static List<string> DataTypeList = new List<string> {"Array", "Boolean", "Currency", "Date", "Double",
                                                "Integer", "Long", "Single", "String", "Variant", "Short", "Object"};

        public static List<string> DeclarationTriggerSyntax = new List<string> { "Dim", "Public", "Static", "Const" };

        /// <summary>
        /// Kiểm tra dòng có phải là dạng khai báo không
        /// </summary>
        /// <param name="sample"></param>
        /// <returns></returns>
        public static bool CheckDeclaration(string sample)
        {
            bool result = false;
            foreach (string trigger in DeclarationTriggerSyntax)
            {
                // sua loi replace trong Function
                if (trigger == "Public") {
                    string newParttern = String.Format(@"{0} Declare Function",trigger);
                    if (Regex.IsMatch(sample, newParttern, RegexOptions.IgnoreCase)) {
                        return result;
                    }
                }
                
                string pattern = String.Format(@"^\s*({0})\s+(.*)\s+As\s+(.*)", trigger);

                result = Regex.IsMatch(sample, pattern, RegexOptions.IgnoreCase);
                if (result)
                {
                    break;
                }
            }
            return result;
        }

        /// <summary>
        /// Convert Declaration
        /// </summary>
        /// <param name="line"></param>
        public static void ConvertDeclaration(ConvertResult line)
        {
            if (CheckDeclaration(line.Before))
            {
                string pattern = @"^(\s*)(\w+)\s+(.*)\s+As\s+(.*)";

                Match match = Regex.Match(line.After, pattern, RegexOptions.IgnoreCase);

                string tabIndent = match.Groups[1].Value;
                string declareType = match.Groups[2].Value;
                string declareProps = match.Groups[3].Value;
                string dataType = match.Groups[4].Value;

                var isNomarlDataType = DataTypeList.Contains(char.ToUpper(dataType[0]) + dataType.Substring(1).ToLower());
                if (isNomarlDataType)
                {
                    if (declareProps.Contains(","))
                    {
                        line.Result = true;
                        line.After = FormatDeclareProps(tabIndent, declareProps, declareType, dataType);
                        Common.AddMessageID(line, Constant.TodoMsgId);
                    }
                }
                string fixedStringPattern = @"^(\s*)Public\s+(\w*)\s+As\s+New\s+VB6\.FixedLengthString\((\d+)\)(.*)";
                if (Regex.IsMatch(line.After, fixedStringPattern, RegexOptions.IgnoreCase))
                {
                    string replacePattern = "$1Dim $2 As String = Space($3)$4";
                    line.Result = true;
                    line.After = Regex.Replace(line.After, fixedStringPattern, replacePattern, RegexOptions.IgnoreCase);
                }
            }
        }

        /// <summary>
        /// Format nếu là dạng khai báo kép
        /// </summary>
        /// <param name="tabIndent"></param>
        /// <param name="declareProps"></param>
        /// <param name="declareType"></param>
        /// <param name="dataType"></param>
        /// <returns></returns>
        private static string FormatDeclareProps(string tabIndent, string declareProps, string declareType, string dataType)
        {
            string formatedPropsString = "";
            var variables = declareProps.Split(',').ToList();
            StringBuilder sb = new StringBuilder();
            foreach (var variable in variables)
            {
                sb.Append($"{tabIndent}{declareType} {variable.Trim()} AS {dataType} {Environment.NewLine}");
            }
            formatedPropsString = sb.ToString();
            if (variables.Any())
            {
                formatedPropsString = formatedPropsString.Remove(formatedPropsString.Length - 3);
            }
            return formatedPropsString;
        }

        /// <summary>
        /// Convert Trường hợp khai báo dạng dữ liệu object và sử dụng các method Ubound LBound
        /// </summary>
        /// <param name="convertLine"></param>
        /// <param name="functionBlock"></param>
        public static void CheckAndConvertLUBound(ConvertResult convertLine, List<ConvertResult> functionBlock)
        {
            Regex declareAsObjectRegex = new Regex(Constant.ObjectDeclaration, RegexOptions.IgnoreCase);
            string[] stringSeparators = new string[] { "\r\n" };
            string[] lines = convertLine.After.Trim().Split(stringSeparators, StringSplitOptions.None);
            foreach (string line in lines)
            {
                if (declareAsObjectRegex.IsMatch(line))
                {
                    string confirmPatter = declareAsObjectRegex.Replace(line, @"$2\s*=\s*UBound.*|$2\s*=\s*LBound.*");
                    foreach (ConvertResult item in functionBlock)
                    {
                        if (Regex.IsMatch(item.After, confirmPatter, RegexOptions.IgnoreCase))
                        {
                            convertLine.Result = true;
                            convertLine.After = Regex.Replace(convertLine.After, "Object", "Long", RegexOptions.IgnoreCase);
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Convert trường hợp khai báo kiểu dữ liệu FixedLengthString
        /// </summary>
        /// <param name="convertLine"></param>
        /// <param name="functionBlock"></param>
        public static void CheckAndConvertVbFixedString(ConvertResult convertLine, List<ConvertResult> functionBlock)
        {
            string fixedStringPattern = @"^(\s*)Dim\s+(\w*)\s+As\s+New\s+VB6\.FixedLengthString\((\d+)\)(.*)";
            if (Regex.IsMatch(convertLine.After, fixedStringPattern, RegexOptions.IgnoreCase))
            {
                string setValuePattern = Regex.Replace(convertLine.After, fixedStringPattern, "($2)\\s*=\\s*\"\"", RegexOptions.IgnoreCase);
                string dotvaluePattern = Regex.Replace(convertLine.After, fixedStringPattern, "($2)\\.Value", RegexOptions.IgnoreCase);
                foreach (ConvertResult item in functionBlock)
                {
                    if (Regex.IsMatch(item.After, setValuePattern, RegexOptions.IgnoreCase))
                    {
                        item.CommentOut = true;
                    }
                    if (Regex.IsMatch(item.After, dotvaluePattern, RegexOptions.IgnoreCase))
                    {
                        item.Result = true;
                        item.After = Regex.Replace(item.After, dotvaluePattern, "$1", RegexOptions.IgnoreCase);
                    }
                }
                convertLine.Result = true;
                string replacePattern = "$1Dim $2 As String = space($3)$4";
                convertLine.After = Regex.Replace(convertLine.After, fixedStringPattern, replacePattern, RegexOptions.IgnoreCase);
            }
        }

        public static void CheckAndConvertVbFixedArr(ConvertResult convertLine, List<ConvertResult> functionBlock)
        {
            string fixedStringPattern = @"^(\s*)(Dim|Public)\s+(.*)\((\d*)\)\s+As\s+String\*(\d+)";
            if (Regex.IsMatch(convertLine.After, fixedStringPattern, RegexOptions.IgnoreCase))
            {
                convertLine.Result = true;
                string replacePattern = "$1<VBFixedString($5), System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray, SizeConst:=$4)> Public $3() As String";
                convertLine.After = Regex.Replace(convertLine.After, fixedStringPattern, replacePattern, RegexOptions.IgnoreCase);
            }
        }
       
    }
}
