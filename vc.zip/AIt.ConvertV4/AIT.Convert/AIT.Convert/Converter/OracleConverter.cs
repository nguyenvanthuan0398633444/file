﻿using System;
using System.Collections.Generic;
using System.Linq;
using AIT.Convert.Model;
using AIT.Convert.Const;
using System.Text.RegularExpressions;
using AIT.Convert.Utils;

namespace AIT.Convert.Converter
{
    public class OracleConverter
    {
        /// <summary>
        /// Check xem có sử dụng các method của Oracle phiên bản cũ không, nếu có thì convert
        /// </summary>
        /// <param name="functionBlock"></param>
        public static void CheckAndConvertOracle(List<ConvertResult> functionBlock)
        {
            List<ConvertResult> objectDeclarationListEntry = functionBlock.Where(item => Regex.IsMatch(item.After, Constant.ObjectDeclaration, RegexOptions.IgnoreCase)).ToList();
            if (!objectDeclarationListEntry.Any())
            {
                return;
            }
            foreach (ConvertResult convertLine in objectDeclarationListEntry)
            {
                string propName = Regex.Match(convertLine.After, Constant.ObjectDeclaration, RegexOptions.IgnoreCase).Groups[2].Value;
                Regex oradynasetRegexCheckPattern = new Regex($@"({propName})\.DbUpdate|({propName})\.DbAddNeW|({propName})\.DbEdit|({propName})\.Fields", RegexOptions.IgnoreCase);
                ConvertResult sastifyCheckPattern = functionBlock.Where(item => oradynasetRegexCheckPattern.IsMatch(item.After)).FirstOrDefault();
                if (sastifyCheckPattern == null)
                {
                    return;
                }
                Convert(propName, convertLine, functionBlock);
            }
            return;
        }

        /// <summary>
        /// Thực hiện convert Properties Fields và Syntax các method thường dùng của Oracle
        /// </summary>
        /// <param name="propName"></param>
        /// <param name="convertLine"></param>
        /// <param name="functionBlock"></param>
        private static void Convert(string propName, ConvertResult convertLine, List<ConvertResult> functionBlock)
        {
            string tabIndent = Regex.Match(convertLine.After, Constant.ObjectDeclaration, RegexOptions.IgnoreCase).Groups[1].Value;
            convertLine.Result = true;
            convertLine.After = Regex.Replace(convertLine.After, Constant.ObjectDeclaration, $@"{tabIndent}Dim $2 As DataTable", RegexOptions.IgnoreCase);
            PreConvertOraField(propName, convertLine, functionBlock);
            ConvertOraSyntax(propName, functionBlock);
            return;
        }

        /// <summary>
        /// Convert Các Syntax sau đây :    DbAddNew(),DbEdit(),DbUpdate(),Property EOF,DbClose()
        /// FPubOpen()
        /// </summary>
        /// <param name="propName"></param>
        /// <param name="functionBlock"></param>
        private static void ConvertOraSyntax(string propName, List<ConvertResult> functionBlock)
        {
            Regex dbAddNewRegex = new Regex($@"({propName})\.DbADDNew\(\)", RegexOptions.IgnoreCase);
            Regex dbEditRegex = new Regex($@"({propName})\.DbEdit", RegexOptions.IgnoreCase);
            Regex dbUpdateRegex = new Regex($@"({propName})\.DbUpdate\(\)", RegexOptions.IgnoreCase);
            Regex dbEOFRegex = new Regex($@"({propName})\.EOF", RegexOptions.IgnoreCase);
            Regex dbCloseRegex = new Regex($@"s*({propName})\.Close\(\)", RegexOptions.IgnoreCase);
            Regex dbFpubOpenRegex = new Regex($@"s*({propName})\s*=\s*FPub_RsOpen\((\w*)\,.*\)", RegexOptions.IgnoreCase);
            foreach (ConvertResult item in functionBlock)
            {
                if (item.IsNotCode)
                {
                    continue;
                }
                if (dbAddNewRegex.IsMatch(item.After))
                {
                    item.Result = true;
                    item.After = dbAddNewRegex.Replace(item.After, $"DTRow = $1.NewRow() {Environment.NewLine} $1.Rows.Add(DTRow)");
                }
                if (dbEditRegex.IsMatch(item.After))
                {
                    item.Result = true;
                    item.CommentOut = true;
                }
                if (dbUpdateRegex.IsMatch(item.After))
                {
                    item.Result = true;
                    item.After = dbUpdateRegex.Replace(item.After, $"FPub_Update($1)");
                }
                if (dbEOFRegex.IsMatch(item.After))
                {
                    item.Result = true;
                    Common.AddMessageID(item, Constant.TodoMsgId);
                    item.After = dbEOFRegex.Replace(item.After, $"$1.Rows.Count = 0");
                }
                if (dbCloseRegex.IsMatch(item.After))
                {
                    item.Result = true;
                    item.After = dbCloseRegex.Replace(item.After, $"$1.Dispose()");
                }
                if (dbFpubOpenRegex.IsMatch(item.After))
                {
                    item.Result = true;
                    item.After = dbFpubOpenRegex.Replace(item.After, $"$1 = FPub_RsOpen($2)");
                }
            }
        }
        /// <summary>
        /// Đọc cấu trúc Function và set các điều kiện cơ bản để tiến hành convert Property Fields
        /// </summary>
        /// <param name="propName"></param>
        /// <param name="convertLine"></param>
        /// <param name="functionBlock"></param>
        private static void PreConvertOraField(string propName, ConvertResult convertLine, List<ConvertResult> functionBlock)
        {

            Regex ifEOFCond = new Regex($@"^\s*If\s+({propName})\.EOF\s+Then", RegexOptions.IgnoreCase);
            Regex ifNotEOFCond = new Regex($@"^\s*If\s+Not\s+({propName})\.EOF\s+Then", RegexOptions.IgnoreCase);

            Regex ifRegex = new Regex(@"^\s*If\s+(.*)\s+Then", RegexOptions.IgnoreCase);
            Regex endIfRegex = new Regex(@"^\s*End\s+If", RegexOptions.IgnoreCase);
            Regex elseRegex = new Regex(@"^\s*Else", RegexOptions.IgnoreCase);

            Regex loopRegex = new Regex($@"^\s*For\s*|^\s*Do.*$|^\s*Do\s+Until\s+|^\s*Do\s+While\s+|^\s*While\s+", RegexOptions.IgnoreCase);
            Regex endLoopRegex = new Regex(@"^\s*Next\s*|^\s*Loop\s*|^\s*End\s+While\s*", RegexOptions.IgnoreCase);

            Regex dbAddnewRegex = new Regex($@"({propName})\.DbAddNew", RegexOptions.IgnoreCase);

            bool addNewTrigger = false;
            ConvertResult dbAddnewLine = functionBlock.Where(item => dbAddnewRegex.IsMatch(item.After)).FirstOrDefault();
            if (dbAddnewLine != null)
            {
                if (!dbAddnewLine.IsNotCode)
                {
                    addNewTrigger = true;
                    convertLine.Result = true;
                    convertLine.After += $"{Environment.NewLine}{Regex.Match(convertLine.After, Constant.ObjectDeclaration, RegexOptions.IgnoreCase).Groups[1].Value}{Constant.OracleDataRow}{Common.getADDComment()}";
                }
            }

            bool inEOFCondition = false;
            if (addNewTrigger)
            {
                bool inEOF = false;
                bool inNotEOF = false;
                bool inElseOfnotEOF = false;
                int tempCountIf = 0;
                foreach (ConvertResult item in functionBlock)
                {
                    if (dbAddnewRegex.IsMatch(item.After))
                    {
                        if (!inEOF)
                        {
                            if (inElseOfnotEOF)
                            {
                                inEOFCondition = true;
                            }
                            else
                            {
                                inEOFCondition = false;
                            }
                        }
                        else
                        {
                            inEOFCondition = true;
                        }
                        break;
                    }
                    if (ifEOFCond.IsMatch(item.After))
                    {
                        inEOF = true;
                    }
                    if (ifNotEOFCond.IsMatch(item.After))
                    {
                        inNotEOF = true;
                    }
                    if (elseRegex.IsMatch(item.After))
                    {
                        if (tempCountIf == 0 && inNotEOF)
                        {
                            inElseOfnotEOF = true;
                        }
                    }
                    if (ifRegex.IsMatch(item.After))
                    {
                        if (inEOF || inNotEOF)
                        {
                            tempCountIf++;
                        }
                    }
                    if (endIfRegex.IsMatch(item.After))
                    {
                        if (inEOF)
                        {
                            if (tempCountIf > 0)
                            {
                                tempCountIf--;
                            }
                            else
                            {
                                inEOF = false;
                            }
                        }
                        if (inNotEOF)
                        {
                            if (tempCountIf > 0)
                            {
                                tempCountIf--;
                            }
                            else
                            {
                                inNotEOF = false;
                            }
                        }
                    }

                }
            }

            bool inLoopTrigger = false;
            Regex oraFieldRegex = new Regex($@"{propName}\.Fields(.*)\.VALUE", RegexOptions.IgnoreCase);
            foreach (ConvertResult item in functionBlock)
            {
                if (item.IsNotCode)
                {
                    continue;
                }
                if (loopRegex.IsMatch(item.After))
                {
                    inLoopTrigger = true;
                }
                if (endLoopRegex.IsMatch(item.After))
                {
                    inLoopTrigger = false;
                }
                if (oraFieldRegex.IsMatch(item.After))
                {
                    if (addNewTrigger)
                    {
                        if (inEOFCondition)
                        {
                            item.Result = true;
                            Common.AddMessageID(item, Constant.OracleFieldWarningID);
                            item.After = oraFieldRegex.Replace(item.After, $"DTRow$1");
                        }
                        else
                        {
                            item.Result = true;
                            Common.AddMessageID(item, Constant.OracleFieldWarningID);
                            item.After = oraFieldRegex.Replace(item.After, $"{propName}.Rows(0)$1");
                        }
                    }
                    else
                    {
                        if (inLoopTrigger)
                        {
                            item.Result = true;
                            Common.AddMessageID(item, Constant.OracleFieldWarningID);
                            item.After = oraFieldRegex.Replace(item.After, $"{propName}.Rows(i)$1");
                        }
                        else
                        {
                            item.Result = true;
                            Common.AddMessageID(item, Constant.OracleFieldWarningID);
                            item.After = oraFieldRegex.Replace(item.After, $"{propName}.Rows(0)$1");
                        }
                    }
                }
            }
        }
    }
}
