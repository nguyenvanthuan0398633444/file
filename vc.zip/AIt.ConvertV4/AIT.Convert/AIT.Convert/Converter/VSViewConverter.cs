﻿using System;
using AIT.Convert.Const;
using AIT.Convert.Model;
using AIT.Convert.Utils;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using AIT.Convert.Content;

namespace AIT.Convert.Converter
{
    public static class VSViewConverter
    {
        public static List<RuleModel> VSViewRules = new List<RuleModel>();
        public static List<RuleModel> ViewToolRules = new List<RuleModel>();

        public static bool isHasFncTextWidth = false;
        public static bool isHasFncTextHeight = false;
        public static bool isHasFncRoundFontSize = false;
        public static bool isHasFncPrint_First = false;
        public static bool isHasFncPRN_XGet = false;
        public static bool isHasFncPRN_XGet_mm = false;
        public static bool isHasFncPRN_END = false;
        public static bool isHasPR_WK_Structure = false;

        public static bool isPaperKind = false;
        public static bool isDashStyle = false;
        public static bool isOrientationEnum = false;

        static string vsPrinterName = string.Empty;

        /// <summary>
        /// Convert Syntax của các dòng lẻ không nằm trong Function Block
        /// </summary>
        /// <param name="convertLine"></param>
        public static void ConvertSingleLineVsViewRules(ConvertResult convertLine)
        {
            foreach (RuleModel rule in VSViewRules)
            {
                if (Regex.IsMatch(convertLine.After, rule.Find, RegexOptions.IgnoreCase))
                {
                    if (rule.WarningMsgId != null) Common.AddMessageID(convertLine, rule.WarningMsgId);

                    if (rule.TodoFlg)
                    {
                        convertLine.MessageID.Add(Constant.TodoMsgId);
                        continue;
                    }
                    //Remove phần comment đi
                    string commentPart = string.Empty;
                    string targetStringRemovedComment = convertLine.After;
                    if (Regex.IsMatch(convertLine.After, @"\s+'.*"))
                    {
                        commentPart = Regex.Match(targetStringRemovedComment, @"\s+'.*").Value;
                        targetStringRemovedComment = Regex.Replace(targetStringRemovedComment, @"\s+'.*", "");
                        Match match = Regex.Match(targetStringRemovedComment, rule.Find, RegexOptions.IgnoreCase);
                        //trong trường hợp sau khi remove phần comment đi và không còn thõa mãn pattern nữa thì return;
                        if (!match.Success)
                        {
                            continue;
                        }
                    }
                    convertLine.After = $"{Regex.Replace(targetStringRemovedComment, rule.Find, rule.Replace, RegexOptions.IgnoreCase)}\t{commentPart}";
                    if(rule.ID == 6)
                    {
                        vsPrinterName = targetStringRemovedComment.Split(' ')[1];
                    }
                    convertLine.Result = true;
                }
            }
        }

        /// <summary>
        /// Convert Syntax của dòng thuộc functionBlock
        /// </summary>
        /// <param name="convertLine"></param>
        /// <param name="functionBlock"></param>
        public static void ConvertBlockFuncVb(ConvertResult convertLine, List<ConvertResult> functionBlock,string filename = "")
        {
            foreach (RuleModel rule in VSViewRules)
            {
                Regex regex = new Regex(rule.Find, RegexOptions.IgnoreCase);
                if (regex.IsMatch(convertLine.After))
                {
                    if (rule.WarningMsgId != null) Common.AddMessageID(convertLine, rule.WarningMsgId);

                    if (rule.TodoFlg)
                    {
                        Common.AddMessageID(convertLine, Constant.TodoMsgId);
                        continue;
                    }

                    if (rule.SubRuleIdList.Any())
                    {
                        SubRuleConverter.ConvertSubRule(rule, convertLine, functionBlock);
                    }

                    if (!rule.Replace.Equals("NOT_REPLACE", StringComparison.OrdinalIgnoreCase))
                    {
                        //Tách phần comment và phần code(nội dung) ra. Phân cách = dấu \'
                        string commentPart = string.Empty;
                        string targetStringRemovedComment = convertLine.After;
                        if (Regex.IsMatch(convertLine.After, @"\s+'.*"))
                        {
                            commentPart = Regex.Match(targetStringRemovedComment, @"\s+'.*").Value;
                            targetStringRemovedComment = Regex.Replace(targetStringRemovedComment, @"\s+'.*", "");
                            Match match = Regex.Match(targetStringRemovedComment, rule.Find, RegexOptions.IgnoreCase);
                            //trong trường hợp sau khi tách phần comment mà không còn thõa mãn pattern nữa thì return;
                            if (!match.Success)
                            {
                                continue;
                            }
                        }
                        convertLine.After = $"{Regex.Replace(targetStringRemovedComment, rule.Find, rule.Replace, RegexOptions.IgnoreCase)}\t{commentPart}";
                        convertLine.Result = true;
                    }

                    if (rule.Find.Equals(Constant.VSViewTextWidth)) isHasFncTextWidth = true;
                    if (rule.Find.Equals(Constant.VSViewTextHeight)) isHasFncTextHeight = true;
                    if (rule.Find.Equals(Constant.VSViewFontSize)) isHasFncRoundFontSize = true;
                    if (rule.ID == 20 || rule.ID == 16) isPaperKind = true;
                    if (rule.ID == 19 || rule.ID == 1 || rule.ID == 12 || rule.ID == 13) isDashStyle = true;
                    if (rule.ID == 4 || rule.ID == 18) isOrientationEnum = true;
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="convertLine"></param>
        /// <param name="functionBlock"></param>
        /// <param name="filename"></param>
        public static void CheckViewToolFunction(ConvertResult convertLine, List<ConvertResult> functionBlock, string filename)
        {
            foreach (RuleModel rule in ViewToolRules)
            {
                if (rule.WarningMsgId != null) Common.AddMessageID(convertLine, rule.WarningMsgId);

                if (rule.TodoFlg)
                {
                    Common.AddMessageID(convertLine, Constant.TodoMsgId);
                    continue;
                }

                if (rule.SubRuleIdList.Any()) SubRuleConverter.ConvertSubRule(rule, convertLine, functionBlock);

                Regex regex = new Regex(rule.Find, RegexOptions.IgnoreCase);
                if (regex.IsMatch(convertLine.After))
                {
                    if (filename.ToLower() == Constant.VIEWTOOL)
                        ConvertBlockFuncViewTool(functionBlock, rule);
                }
            }
        }

        /// <summary>
        /// Xử lý convert viewtool.vb
        /// </summary>
        /// <param name="convertLine"></param>
        /// <param name="functionBlock"></param>
        /// <param name="rule"></param>
        private static void ConvertBlockFuncViewTool(List<ConvertResult> functionBlock, RuleModel rule)
        {
            switch (rule.ID) {
                case 1: // Xử lý hàm Print_Set
                    var printerName = functionBlock.Where(a => a.Before.Contains(" As New Printer")).FirstOrDefault().After.Split(' ')[1];
                    Regex regex = new Regex("For(.*)To(.*).Count", RegexOptions.IgnoreCase);
                    var lineFor = functionBlock.Where(a => regex.IsMatch(a.Before)).FirstOrDefault();
                    var varFor = lineFor.After.Split(' ')[1];

                    if (Regex.IsMatch(lineFor.After, "For(.*)To(.*).Count"))
                    {
                        var commentPart = Regex.Match(lineFor.After, @"\s+'.*").Value;
                        var targetStringRemovedComment = Regex.Replace(lineFor.After, @"\s+'.*", "");
                        if (Regex.Match(targetStringRemovedComment, "For(.*)To(.*).Count", RegexOptions.IgnoreCase).Success)
                        {
                            lineFor.After = $"{Regex.Replace(targetStringRemovedComment, "For(.*)To(.*).Count", "For $1 To " +printerName+".Count", RegexOptions.IgnoreCase)}\t{commentPart}";
                            lineFor.Result = true;
                        }
                    }
                    var convertPrinter = functionBlock.Where(a => a.Before.Contains($"Printers({varFor}).DeviceName")).ToList();
                    foreach (var cvPrinter in convertPrinter)
                    {
                        cvPrinter.After = cvPrinter.After.Replace($"Printers({varFor}).DeviceName", $"{printerName}.Item({varFor})");
                        cvPrinter.Result = true;
                    }

                    var convertPrinterName = functionBlock.Where(a => a.Before.Contains($"{printerName} = Printers({varFor})")).ToList();
                    foreach (var cvPrinter in convertPrinterName)
                    {
                        cvPrinter.After = cvPrinter.After.Replace($"{printerName} =", $"ViewForm.C1FlexViewer1.PageSettings.PrinterSettings.PrinterName =")
                            .Replace($"Printers({varFor})", $"{printerName}.Item({varFor})");
                        cvPrinter.Result = true;
                    }

                    var indexIsWindownsNT = functionBlock.IndexOf(functionBlock.Where(a => a.Before.Contains("isWindowsNT")).FirstOrDefault());
                    do
                    {
                        functionBlock.ElementAt(indexIsWindownsNT).After = "'" + functionBlock.ElementAt(indexIsWindownsNT).After;
                        functionBlock.ElementAt(indexIsWindownsNT).Result = true;
                    } while (!functionBlock.ElementAt(indexIsWindownsNT++).After.Contains("End If"));

                    var contentComment = functionBlock.Where(a => a.After.Contains("ViewForm.vsPrinter1.Device")).ToList();
                    foreach (var cvPrinter in contentComment)
                    {
                        cvPrinter.After = "'" + cvPrinter.After;
                        cvPrinter.Result = true;
                    }
                    break;
                case 2:  // Xử lý hàm  PRN_FontGet_mm ,PRN_FontGet, PRN_FontGetHeight và PRN_FontGetHeight_mm
                    var printNameTemp = string.IsNullOrEmpty(vsPrinterName) ? "PRN" : "vsPrinterName";
                    var convertFontsize = functionBlock.Where(a => a.Before.Contains($"{printNameTemp}.FontSize")).ToList();
                    foreach (var cvFontsize in convertFontsize)
                    {
                        cvFontsize.After = cvFontsize.After.Replace($"{printNameTemp}.FontSize", $"{printNameTemp}.Font.Size");
                        cvFontsize.Result = true;
                    }
                    break;
                case 3: // Xử lý hàm  PRN_XGet
                case 4: // Xử lý hàm  PRN_XGet_mm
                case 5: // Xử lý hàm  PRN_First
                case 6: // Xử lý hàm  PRN_END
                    if(isHasPR_WK_Structure || rule.ID >= 5) { 
                        foreach (var convert in functionBlock)
                        {
                            string tabIndent = Regex.Match(convert.Before, @"^\s*").Value;
                            convert.Before = tabIndent + "\'" + convert.Before.Trim();
                            convert.After = convert.Before;
                            convert.Result = false;
                        }
                    }
                    if (rule.ID == 3 && isHasPR_WK_Structure)
                    {
                        isHasFncPRN_XGet = true;
                    }
                    else if (rule.ID == 4 && isHasPR_WK_Structure)
                    {
                        isHasFncPRN_XGet_mm = true;
                    }
                    else if (rule.ID == 5)
                    {
                        isHasFncPrint_First = true;
                    }
                    else if (rule.ID == 6)
                    {
                        isHasFncPRN_END = true;
                    }


                    break;
                case 7:
                    isHasPR_WK_Structure = true;
                    break;
            }
        }

        /// <summary>
        /// Convert Syntax của các dòng lẻ nằm trong Block thuộc file ViewTool.vb
        /// </summary>
        /// <param name="convertLine"></param>
        public static void ConvertSingleLineViewToolRules(ConvertResult convertLine)
        {
            foreach (RuleModel rule in ViewToolRules)
            {
                if (Regex.IsMatch(convertLine.After, rule.Find, RegexOptions.IgnoreCase))
                {
                    if (rule.WarningMsgId != null)
                    {
                        Common.AddMessageID(convertLine, rule.WarningMsgId);
                    }
                    if (rule.TodoFlg)
                    {
                        convertLine.MessageID.Add(Constant.TodoMsgId);
                        continue;
                    }
                    //Remove phần comment đi
                    string commentPart = string.Empty;
                    string targetStringRemovedComment = convertLine.After;
                    if (Regex.IsMatch(convertLine.After, @"\s+'.*"))
                    {
                        commentPart = Regex.Match(targetStringRemovedComment, @"\s+'.*").Value;
                        targetStringRemovedComment = Regex.Replace(targetStringRemovedComment, @"\s+'.*", "");
                        Match match = Regex.Match(targetStringRemovedComment, rule.Find, RegexOptions.IgnoreCase);
                        //trong trường hợp sau khi remove phần comment đi và không còn thõa mãn pattern nữa thì return;
                        if (!match.Success)
                        {
                            continue;
                        }
                    }
                    convertLine.After = $"{Regex.Replace(targetStringRemovedComment, rule.Find, rule.Replace, RegexOptions.IgnoreCase)}\t{commentPart}";
                    if (rule.ID == 6)
                    {
                        vsPrinterName = targetStringRemovedComment.Split(' ')[1];
                    }
                    convertLine.Result = true;
                }
            }
        }

        /// <summary>
        /// Thêm các function phục vụ cho print view
        /// </summary>
        /// <param name="fileContent"></param>
        public static void CreateContent(ref List<string> fileContent, string fileName = "")
        {
            if (fileName.ToLower() == Constant.VIEWTOOL)
            {
                var listImport = new List<string>()
                {
                    Common.getADDComment(string.Empty),
                    "Imports System.Text",
                    "Imports System.Drawing.Printing",
                    "Imports System.Drawing.Printing.PrinterSettings",
                    "Imports C1.Win.C1Document",
                    "Imports C1.Win.FlexReport",
                    "Imports C1.Win.FlexViewer",
                    Common.getCommentEnd(string.Empty)
                };
                fileContent.InsertRange(2, listImport);
            }

            if (isPaperKind) fileContent.Insert(2, "Imports System.Drawing.Printing");
            if (isDashStyle) fileContent.Insert(2, "Imports C1.Win.C1Document");
            if (isOrientationEnum) fileContent.Insert(2, "Imports C1.Win.FlexReport");

            string endContent = fileContent[fileContent.Count - 1];
            fileContent.RemoveAt(fileContent.Count - 1);

            fileContent.Add(string.Empty);
            fileContent.Add(Common.getADDComment());
            if(isHasPR_WK_Structure)
            {
                var pr_WKindex = fileContent.IndexOf(fileContent.First(a => a.Contains("Structure PR_WK")));
                var listInsertWK = new List<string>()
                {
                    Common.getADDComment("		"),
                    "		Dim AL As FieldAlignEnum",
                    "		Dim WID As Single",
                    Common.getCommentEnd("		")
                };
                fileContent.InsertRange(pr_WKindex + 1, listInsertWK);
            }
            if (fileName.ToLower() == Constant.VIEWTOOL)
            {
                if (isHasFncPrint_First)
                {
                    fileContent.AddRange(ViewToolContent.ModifyFncPRN_First());
                    fileContent.AddRange(ViewToolContent.AddFncIsPaperSize());
                    isHasFncTextHeight = true;
                }
                if (isHasFncPRN_XGet && isHasPR_WK_Structure) fileContent.AddRange(ViewToolContent.ModifyFncPRN_XGET());
                if (isHasFncPRN_XGet_mm && isHasPR_WK_Structure) fileContent.AddRange(ViewToolContent.ModifyFncPRN_XGET_mm());

                fileContent.Add("    Public pDlg As PrintDialog");
                fileContent.Add("    Public CustomPaperName As String");
                if (!fileContent.Any(a => a.Contains("P_DevName As String")))
                    fileContent.Add("    Public P_DevName As String");
                fileContent.Add(string.Empty);
                fileContent.AddRange(ViewToolContent.AddFncOpenDialogPrint());
                if (isHasFncPRN_END)
                {
                    fileContent.AddRange(ViewToolContent.ModifyFncPRN_END());
                    fileContent.AddRange(ViewToolContent.AddFncCustomPrint());
                }
            }

            if (isHasFncTextWidth) fileContent.AddRange(ViewToolContent.AddFncTextWidthToTwips(vsPrinterName));

            if (isHasFncTextHeight) fileContent.AddRange(ViewToolContent.AddFncTextHeightToTwips(vsPrinterName));

            if (isHasFncRoundFontSize) fileContent.AddRange(ViewToolContent.AddFncRoundFontSize());

            fileContent.Add(Common.getCommentEnd());
            fileContent.Add(endContent);
            fileContent.Add(string.Empty);
            ResetProperties();
        }
        /// <summary>
        /// Reset properties of VSViewConverter
        /// </summary>
        private static void ResetProperties()
        {
            isHasFncTextWidth = false;
            isHasFncTextHeight = false;
            isHasFncRoundFontSize = false;
            isHasFncPrint_First = false;
            isHasFncPRN_XGet = false;
            isHasFncPRN_XGet_mm = false;
            isHasFncPRN_END = false;
            isHasPR_WK_Structure = false;
            isPaperKind = false;
            isDashStyle = false;
            isOrientationEnum = false;

        }
    }
}
