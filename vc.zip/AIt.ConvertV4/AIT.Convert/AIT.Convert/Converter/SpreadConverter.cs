﻿using AIT.Convert.Const;
using AIT.Convert.Model;
using AIT.Convert.Utils;
using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;
using System.Linq;

namespace AIT.Convert.Converter
{
    public static class SpreadConverter
    {
        public static List<RuleModel> SpreadRules = new List<RuleModel>();
        public static List<FileInfo> DesignFiles = new List<FileInfo>();

        /// <summary>
        /// Kiểm tra nếu File Designer tương ứng có phát hiện sử dụng Spread
        /// </summary>
        /// <param name="fileName"></param>
        /// <returns></returns>
        public static bool CheckHasSpread(string fileName)
        {
            bool result = false;
            FileInfo DesignFile = DesignFiles.Where(designFile => designFile.Name.Contains(fileName.Split('.')[0])).FirstOrDefault();
            if (DesignFile != null)
            {
                Regex spreadConfirmPattern = new Regex($@"Me\.(\w*)\..*FarPoint.Win.Spread.*$");
                using (StreamReader sr = DesignFile.OpenText())
                {
                    string dline = "";
                    while ((dline = sr.ReadLine()) != null)
                    {
                        if (spreadConfirmPattern.IsMatch(dline))
                        {
                            result = true;
                        }
                    }
                }
            }
            return result;
        }

        /// <summary>
        /// Thực hiện convert Spread
        /// </summary>
        /// <param name="convertLine"></param>
        public static void ConvertSpread(ConvertResult convertLine)
        {
            foreach (RuleModel rule in SpreadRules)
            {
                Regex spreadRuleRegex = new Regex($@"\.{rule.Find}", RegexOptions.IgnoreCase);
                if (spreadRuleRegex.IsMatch(convertLine.After))
                {
                    if (rule.WarningMsgId != null)
                    {
                        Common.AddMessageID(convertLine, rule.WarningMsgId);
                    }
                    if (rule.TodoFlg)
                    {
                        Common.AddMessageID(convertLine, Constant.TodoMsgId);
                        continue;
                    }
                    convertLine.After = spreadRuleRegex.Replace(convertLine.After, $".{rule.Replace}");
                    convertLine.Result = true;

                }
            }
        }
    }
}
