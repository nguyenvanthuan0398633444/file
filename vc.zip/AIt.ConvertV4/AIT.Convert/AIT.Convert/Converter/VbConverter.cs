﻿using System;
using AIT.Convert.Const;
using AIT.Convert.Model;
using AIT.Convert.Utils;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace AIT.Convert.Converter
{
    public static class VbConverter
    {
        public static List<RuleModel> VBRules = new List<RuleModel>();

        public static List<RuleModel> DBRules = new List<RuleModel>();

        /// <summary>
        /// Convert Syntax của các dòng lẻ không nằm trong Function Block
        /// </summary>
        /// <param name="convertLine"></param>
        public static void ConvertSingleLineVbRules(ConvertResult convertLine)
        {
            foreach (RuleModel rule in VBRules)
            {
                if (rule.SubRuleIdList.Count > 1 || rule.SubRuleIdList[0] != 0)
                {
                    continue;
                }
                if (Regex.IsMatch(convertLine.After, rule.Find, RegexOptions.IgnoreCase))
                {
                    if (rule.WarningMsgId != null)
                    {
                        Common.AddMessageID(convertLine, rule.WarningMsgId);
                    }
                    if (rule.TodoFlg)
                    {
                        convertLine.MessageID.Add(Constant.TodoMsgId);
                        continue;
                    }

                    if (!rule.Replace.Equals("NOT_REPLACE", StringComparison.OrdinalIgnoreCase))
                    {
                        //Remove phần comment đi
                        string commentPart = String.Empty;
                        string targetStringRemovedComment = convertLine.After;
                        if (Regex.IsMatch(convertLine.After, @"\s+'.*"))
                        {
                            commentPart = Regex.Match(targetStringRemovedComment, @"\s+'.*").Value;
                            targetStringRemovedComment = Regex.Replace(targetStringRemovedComment, @"\s+'.*", "");
                            Match match = Regex.Match(targetStringRemovedComment, rule.Find, RegexOptions.IgnoreCase);
                            //trong trường hợp sau khi remove phần comment đi và không còn thõa mãn pattern nữa thì return;
                            if (!match.Success)
                                continue;
                        }

                        convertLine.After = $"{Regex.Replace(targetStringRemovedComment, rule.Find, rule.Replace, RegexOptions.IgnoreCase)}\t{commentPart}";
                        convertLine.Result = true;
                    }
                }
            }
        }

        /// <summary>
        /// Convert Vb của dòng thuộc functionBlock
        /// </summary>
        /// <param name="convertLine"></param>
        /// <param name="functionBlock"></param>
        public static void ConvertBlockFuncVb(ConvertResult convertLine, List<ConvertResult> functionBlock)
        {
            foreach (RuleModel rule in VBRules)
            {
                Regex regex = new Regex(rule.Find, RegexOptions.IgnoreCase);
                if (regex.IsMatch(convertLine.After))
                {
                    if (rule.WarningMsgId != null)
                    {
                        Common.AddMessageID(convertLine, rule.WarningMsgId);
                    }
                    if (rule.TodoFlg)
                    {
                        Common.AddMessageID(convertLine, Constant.TodoMsgId);
                        continue;
                    }

                    if (rule.SubRuleIdList.Any())
                    {
                        SubRuleConverter.ConvertSubRule(rule, convertLine, functionBlock);
                    }

                    if (!rule.Replace.Equals("NOT_REPLACE", StringComparison.OrdinalIgnoreCase))
                    {
                        //Remove phần comment đi
                        string commentPart = String.Empty;
                        string targetStringRemovedComment = convertLine.After;
                        if (Regex.IsMatch(convertLine.After, @"\s+'.*"))
                        {
                            commentPart = Regex.Match(targetStringRemovedComment, @"\s+'.*").Value;
                            targetStringRemovedComment = Regex.Replace(targetStringRemovedComment, @"\s+'.*", "");
                            Match match = Regex.Match(targetStringRemovedComment, rule.Find, RegexOptions.IgnoreCase);
                            //trong trường hợp sau khi remove phần comment đi và không còn thõa mãn pattern nữa thì return;
                            if (!match.Success)
                            {
                                continue;
                            }
                        }
                        convertLine.After = $"{Regex.Replace(targetStringRemovedComment, rule.Find, rule.Replace, RegexOptions.IgnoreCase)}\t{commentPart}";
                        convertLine.Result = true;
                    }
                }
            }
        }

        public static void ConvertTryCatch(List<ConvertResult> functionBlock)
        {
            Regex tryRegex = new Regex(@"^\s*On\s+Error\s+GoTo\s+(\w*)\s*", RegexOptions.IgnoreCase);
            bool hasTryCatch = false;
            string errorHandleName = String.Empty;
            foreach (ConvertResult convertLine in functionBlock)
            {
                if (convertLine.IsNotCode)
                {
                    continue;
                }
                if (tryRegex.IsMatch(convertLine.After))
                {
                    hasTryCatch = true;
                    errorHandleName = tryRegex.Match(convertLine.After).Groups[1].Value;
                    convertLine.Result = true;
                    convertLine.After = "\t\tTry";
                }
            }
            if (hasTryCatch)
            {
                Regex throwExceptionRegex = new Regex($@"^\s*GoTo\s+{errorHandleName}",RegexOptions.IgnoreCase);
                Regex errorHandlerRegex = new Regex($@"^\s*{errorHandleName}\s*:", RegexOptions.IgnoreCase);
                Regex errorMsgCallRegex = new Regex($@"^\s*Call\s+MsgBox\s*\(.*ErrorToString\((\w+)\.Number\)\s*\&(.*)\)", RegexOptions.IgnoreCase);
                foreach (ConvertResult convertLine in functionBlock)
                {
                    if (convertLine.IsNotCode)
                    {
                        continue;
                    }
                    if (throwExceptionRegex.IsMatch(convertLine.After))
                    {
                        convertLine.Result = true;
                        string replacePattern = "\t\tThrow New Exception";
                        convertLine.After = throwExceptionRegex.Replace(convertLine.After, replacePattern);
                    }
                    if (errorHandlerRegex.IsMatch(convertLine.After))
                    {
                        convertLine.Result = true;
                        string replacePattern = "\t\tCatch ex As Exception";
                        convertLine.Before = Regex.Replace(convertLine.Before, @"^\s*", "\t\t");
                        convertLine.After = errorHandlerRegex.Replace(convertLine.After, replacePattern);
                    }
                    if (errorMsgCallRegex.IsMatch(convertLine.After))
                    {
                        convertLine.Result = true;
                        string replacePattern = "\t\tCall MsgBox(ex.Message & \" \" & CStr(ex.HResult) & $2)";
                        convertLine.After = errorMsgCallRegex.Replace(convertLine.After, replacePattern);
                    }
                }

                ConvertResult endTryLine = new ConvertResult($"\t\tEnd Try {Common.getADDComment()}\r\n\t" );

                functionBlock.Insert(functionBlock.Count - 1, endTryLine);
            }
        }
    }
}