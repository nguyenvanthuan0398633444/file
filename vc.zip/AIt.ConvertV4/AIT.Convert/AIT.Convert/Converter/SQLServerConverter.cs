﻿using System;
using System.Collections.Generic;
using AIT.Convert.Model;
using AIT.Convert.Const;
using System.Text.RegularExpressions;
using AIT.Convert.Utils;

namespace AIT.Convert.Converter
{
    public class SQLServerConverter
    {
        public static List<RuleModel> SQLServerRules = new List<RuleModel>();

        public static bool isDbConnection = false;
        public static bool isDoUntil = false;
        public static bool isForInDoUntil = false;
        /// <summary>
        /// Convert Syntax của các dòng lẻ không nằm trong Function Block
        /// </summary>
        /// <param name="convertLine"></param>
        public static void ConvertSingleLineSQlServeRules(ConvertResult convertLine)
        {
            foreach (RuleModel rule in SQLServerRules)
            {
                if (Regex.IsMatch(convertLine.After, rule.Find, RegexOptions.IgnoreCase))
                {
                    if (rule.WarningMsgId != null)
                    {
                        Common.AddMessageID(convertLine, rule.WarningMsgId);
                    }
                    if (rule.TodoFlg)
                    {
                        convertLine.MessageID.Add(Constant.TodoMsgId);
                        continue;
                    }
                    //Remove phần comment đi
                    string commentPart = String.Empty;
                    string targetStringRemovedComment = convertLine.After;
                    if (Regex.IsMatch(convertLine.After, @"\s+'.*"))
                    {
                        commentPart = Regex.Match(targetStringRemovedComment, @"\s+'.*").Value;
                        targetStringRemovedComment = Regex.Replace(targetStringRemovedComment, @"\s+'.*", "");
                        Match match = Regex.Match(targetStringRemovedComment, rule.Find, RegexOptions.IgnoreCase);
                        //trong trường hợp sau khi remove phần comment đi và không còn thõa mãn pattern nữa thì return;
                        if (!match.Success)
                        {
                            continue;
                        }
                    }
                    if (rule.Find.Equals(Constant.SQLServerDbConnection))
                    {
                        isDbConnection = true;
                    }
                    convertLine.After = $"{Regex.Replace(targetStringRemovedComment, rule.Find, rule.Replace, RegexOptions.IgnoreCase)}\t{commentPart}";
                    // Replace các dòng breakline, tab
                    convertLine.After = convertLine.After.Replace("\\n", "\n").Replace("\\t", "\t");
                    convertLine.Result = true;
                }
            }
        }

        /// <summary>
        /// Convert Syntax của dòng thuộc functionBlock
        /// </summary>
        /// <param name="convertLine"></param>
        /// <param name="functionBlock"></param>
        public static void ConvertBlockFuncVb(ConvertResult convertLine, List<ConvertResult> functionBlock)
        {
            foreach (RuleModel rule in SQLServerRules)
            {
                Regex regex = new Regex(rule.Find, RegexOptions.IgnoreCase);
                if (regex.IsMatch(convertLine.After))
                {
                    if (rule.WarningMsgId != null)
                    {
                        Common.AddMessageID(convertLine, rule.WarningMsgId);
                    }
                    if (rule.TodoFlg)
                    {
                        Common.AddMessageID(convertLine, Constant.TodoMsgId);
                        continue;
                    }

                    if (!rule.Replace.Equals("NOT_REPLACE", StringComparison.OrdinalIgnoreCase))
                    {
                        //Remove phần comment đi
                        string commentPart = String.Empty;
                        string targetStringRemovedComment = convertLine.After;
                        if (Regex.IsMatch(convertLine.After, @"\s+'.*"))
                        {
                            commentPart = Regex.Match(targetStringRemovedComment, @"\s+'.*").Value;
                            targetStringRemovedComment = Regex.Replace(targetStringRemovedComment, @"\s+'.*", "");
                            Match match = Regex.Match(targetStringRemovedComment, rule.Find, RegexOptions.IgnoreCase);
                            //trong trường hợp sau khi remove phần comment đi và không còn thõa mãn pattern nữa thì return;
                            if (!match.Success)
                            {
                                continue;
                            }
                        }
                        if (rule.Find.Equals(Constant.DoUntil))
                        {
                            // Enable is do until flag
                            isDoUntil = true;
                        }
                        //if Do Until then Convert to For each and loop to Next
                        if (rule.Find.Equals(@"Loop"))
                        {
                            if (isDoUntil)
                            {
                                isDoUntil = false;
                                isForInDoUntil = false;
                            }
                            else
                            {
                                continue;
                            }
                        }
                        String ruleReplace = "";
                        ruleReplace = rule.Replace;
                        //if has for each in do until
                        if (isDoUntil && rule.Find.Equals(@"For\sEach\s(\w*)\sIn\s(\w*)\.Fields"))
                        {
                            isForInDoUntil = true;
                            ruleReplace = "For Each $1 In Row.Table.Columns";
                        }
                        if(isForInDoUntil && rule.Find.Equals(@"Fld.Value"))
                        {
                            ruleReplace = "Row(Fld.ColumnName)";
                        }
                        convertLine.After = $"{Regex.Replace(targetStringRemovedComment, rule.Find, ruleReplace, RegexOptions.IgnoreCase)}\t{commentPart}";
                        // Replace các dòng breakline, tab
                        convertLine.After = convertLine.After.Replace("\\n", "\n").Replace("\\t", "\t");
                        convertLine.Result = true;
                    }
                    
                }
            }
        }

        /// <summary>
        /// Thêm các function liên quan db vào file db_tool
        /// </summary>
        /// <param name="fileContent"></param>
        public static void CreateContent(ref List<string> fileContent)
        {
            
            if (isDbConnection)
            {
                //Add import Imports System.Data.Common
                fileContent.Insert(2, Common.getADDComment().Replace("\t", String.Empty));
                fileContent.Insert(3, "Imports System.Data.Common");
                fileContent.Insert(4, Common.getCommentEnd().Replace("\t", String.Empty));
                fileContent.Insert(5, String.Empty);

                //find CLOSEDB function and add content
                int index = fileContent.FindIndex(a => a.Contains("Public Sub CLOSEDB"));
                fileContent.Insert(index + 4, "\t" + Common.getADDComment());
                fileContent.Insert(index + 5, "\t\tSYKTranaction = Nothing");
                fileContent.Insert(index + 6, "\t\tSYKCommand = Nothing");
                fileContent.Insert(index + 7, "\t" + Common.getCommentEnd());

                //find ODBC_Check Function and update 
                index = fileContent.FindIndex(a => a.Contains("Public Function ODBC_Check"));
                for(int i = index + 1; i<= fileContent.Count -1; i++)
                {
                    //if line is end function then add check Dsn
                    if (fileContent[i].Replace("\t", string.Empty).Equals("End Function"))
                    {
                        fileContent.Insert(i - 1, "\t" + Common.getADDComment());
                        fileContent.Insert(i, "\t" + Common.getCommentEnd());
                        fileContent.Insert(i, "\t\tODBC_Check = False");
                        fileContent.Insert(i, "\t\tEnd If");
                        fileContent.Insert(i, "\t\t\tExit Function");
                        fileContent.Insert(i, "\t\t\tODBC_Check = True");
                        fileContent.Insert(i, "\t\tIf CheckDsn(Microsoft.Win32.Registry.CurrentUser, DNSName) OrElse CheckDsn(Microsoft.Win32.Registry.LocalMachine, DNSName) Then");
                        break;
                    }
                    // Comment line in function if not empty line
                    if (!String.IsNullOrEmpty(fileContent[i].Replace("\t", string.Empty)))
                    {
                        fileContent[i] = "'" + fileContent[i];
                    }
                }

                string endContent = fileContent[fileContent.Count - 1];
                fileContent.RemoveAt(fileContent.Count - 1);

                fileContent.Add(Common.getADDComment());
                fileContent.Add(String.Empty);
                // Add function Rsopen
                fileContent.Add("    '**********************************************************************");
                fileContent.Add("    ' サブルーチン名               RsOpen");
                fileContent.Add("    '-------------------------------------------------------------------------------");
                fileContent.Add("    ' 用途   リモートＤＢレコードセット取得ＳＱＬ発効                                 ");
                fileContent.Add("    ' 説明   モジュールグローバルなDatabaseオブジェクト変数にセットされている          ");
                fileContent.Add("    ' 　　   データベースにＳＱＬ文を発効しその結果のレコードセットを返す          ");
                fileContent.Add("    ' 引数   :sSql,I,String,実行するＳＱＬ文                                   ");
                fileContent.Add("    ' 戻値   レコードセット                                                    ");
                fileContent.Add("    '**********************************************************************");
                fileContent.Add("    Public Function RsOpen(ByVal sSQL As String) As DataTable");
                fileContent.Add(String.Empty);
                fileContent.Add("        Dim dt As New DataTable");
                fileContent.Add("        If SYKDB.State = ConnectionState.Closed Then SYKDB.Open()");
                fileContent.Add("        SYKCommand.CommandText = sSQL");
                fileContent.Add("        dt.Load(SYKCommand.ExecuteReader())");
                fileContent.Add("        RsOpen = dt");
                fileContent.Add(String.Empty);
                fileContent.Add("    End Function");
                // Add Sub ExecSQL
                fileContent.Add("    '**********************************************************************");
                fileContent.Add("    ' サブルーチン名               ExecSQL");
                fileContent.Add("    '-------------------------------------------------------------------------------");
                fileContent.Add("    ' 用途   リモートＤＢデータ操作ＳＱＬ発効                                 ");
                fileContent.Add("    ' 説明   モジュールグローバルなDatabaseオブジェクト変数にセットされている         ");
                fileContent.Add("    ' 　　   データベースにＳＱＬ文を発効する         ");
                fileContent.Add("    ' 引数   :sSql,I,String,実行するＳＱＬ文                                              ");
                fileContent.Add("    '**********************************************************************");
                fileContent.Add("    Public Sub ExecSQL(ByVal sSQL As String)");
                fileContent.Add(String.Empty);
                fileContent.Add("        If SYKDB.State = ConnectionState.Closed Then SYKDB.Open()");
                fileContent.Add("        SYKCommand.CommandText = sSQL");
                fileContent.Add("        SYKCommand.ExecuteNonQuery()");
                fileContent.Add(String.Empty);
                fileContent.Add("    End Sub");
                // Add Sub BeginTrans
                fileContent.Add("    'トランザクション開始                                              ");
                fileContent.Add("    Public Sub BeginTrans()");
                fileContent.Add(String.Empty);
                fileContent.Add("        If SYKDB.State = ConnectionState.Closed Then SYKDB.Open()");
                fileContent.Add("           SYKTranaction = SYKDB.BeginTransaction()");
                fileContent.Add("        SYKCommand.Transaction = SYKTranaction");
                fileContent.Add(String.Empty);
                fileContent.Add("    End Sub");
                // Add Sub RollBack
                fileContent.Add("    'ロールバック                                             ");
                fileContent.Add("    '**********************************************************************");
                fileContent.Add("    Public Sub RollBack()");
                fileContent.Add(String.Empty);
                fileContent.Add("        If SYKTranaction IsNot Nothing Then");
                fileContent.Add("        SYKTranaction.Rollback()");
                fileContent.Add("        End If");
                fileContent.Add("        SYKDB.Close()");
                fileContent.Add(String.Empty);
                fileContent.Add("    End Sub");
                // Add Sub CommitTransaction
                fileContent.Add("    'コミット                                            ");
                fileContent.Add("    Public Sub CommitTransaction()");
                fileContent.Add(String.Empty);
                fileContent.Add("        SYKTranaction.Commit()");
                fileContent.Add("        SYKDB.Close()");
                fileContent.Add(String.Empty);
                fileContent.Add("    End Sub");
                // Add Function Check Dsn
                fileContent.Add("    'Check Dsn");
                fileContent.Add("    Private Function CheckDsn(ByVal rootKey As Microsoft.Win32.RegistryKey, ByVal DNSName As String) As Boolean");
                fileContent.Add("       Dim regKey As Microsoft.Win32.RegistryKey = rootKey.OpenSubKey(\"Software\\ODBC\\ODBC.INI\\ODBC Data Sources\") 'TODO: Please check this path");
                fileContent.Add(String.Empty);
                fileContent.Add("       If regKey IsNot Nothing Then");
                fileContent.Add(String.Empty);
                fileContent.Add("           For Each name As String In regKey.GetValueNames()");
                fileContent.Add("               Dim value As String = regKey.GetValue(name,\"\").ToString()");
                fileContent.Add("               If Trim(name) = Trim(DNSName) Then");
                fileContent.Add("                   CheckDsn = True");
                fileContent.Add("                   Exit Function");
                fileContent.Add("               End If");
                fileContent.Add("           Next");
                fileContent.Add("       End If");
                fileContent.Add("       CheckDsn = False");
                fileContent.Add("   End Function");

                fileContent.Add(Common.getCommentEnd());
                fileContent.Add(endContent);
                isDbConnection = false; 
            }
        }
    }
}
