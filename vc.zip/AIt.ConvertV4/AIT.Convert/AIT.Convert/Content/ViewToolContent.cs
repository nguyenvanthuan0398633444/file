﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AIT.Convert.Content
{
    public static class ViewToolContent
    {
        public static List<string> ModifyFncPRN_First()
        {
            var fileContent = new List<string>
            {
				string.Empty,
                "   Public sDetail As Section",
                "   Public P_COUNT As Integer 'PAGE COUNT ",
                "   ",
                "   '-------------------------------------------------------------------------------",
                "   '   処理    :   印刷処理初期設定",
                "   '   関数    :   Function     PRN_First(ViewFrm,PhysFlg)",
                "   '   引数    :   ViewFrm      Object      プレビューフォーム",
                "   '   　　        PhysFlg      Boolean     ページサイズ（物理的 = True）",
                "   '   　　        SHeight      Single      用紙高さ",
                "   '   　　        SWidth       Single      用紙幅",
                "   '   　　        PrnBin       Integer     用紙トレー",
                "   '   戻値    :   True         正常終了",
                "   '   　　        False        異常終了",
                "   '   機能    :   印刷処理の初期設定を行う。",
                "   '-------------------------------------------------------------------------------",
                "   Public Function PRN_First(ByRef ViewFrm As Object, Optional ByVal PhysFlg As Boolean = False, Optional ByVal sHeight As Single = 0, Optional ByVal sWidth As Single = 0, Optional ByVal iDuplex As Duplex = Printing.Duplex.Default) As Boolean",
                "       Dim printSt = PrinterSettings.InstalledPrinters",
                "       Dim flxViewer As C1FlexViewer = ViewFrm.C1FlexViewer1",
                "",
                "       On Error Resume Next",
                "       '戻り値の初期化",
                "       PRN_First = False",
                "",
                "       '中断フラグの初期化",
                "       PrnCancel = 0",
                "       PRN = New C1FlexReport()",
                "       P_COUNT = 0",
                "       PRN.Layout.MarginTop = 0",
                "       PRN.Layout.MarginBottom = 0",
                "       PRN.Layout.MarginLeft = 0",
                "       PRN.Layout.MarginRight = 0",
                "       sDetail = PRN.Sections(SectionTypeEnum.Detail)",
                "       sDetail.AutoHeight = AutoSizeBehavior.GrowAndShrink  'default : CanGrow",
                "       sDetail.Visible = True",
                "",
                "       With PRN",
                "           .ReportName = DocName",
                "           flxViewer.StatusText = DocName",
                "           .Font.Name = FNT_MSM",
                "           .Font.Size = F_Size",
                "           flxViewer.PageSettings.PrinterSettings.PrinterName = P_DevName",
                "           Dim paperSourceCollection = flxViewer.PageSettings.PrinterSettings.PaperSizes",
                "",
                "           If IsPaperSize(paperSourceCollection, P_SIZE) Then",
                "               If P_SIZE <> 0 Then",
                "                   PRN.Layout.PaperSize = P_SIZE",
                "                   flxViewer.ZoomFactor = 1",
                "               End If",
                "           Else",
                "               MsgBox(\"用紙サイズを設定できませんでした。\", MsgBoxStyle.Exclamation, Application.OpenForms(0).Text)",
                "               Call PRN_ErrEnd()",
                "               Exit Function",
                "           End If",
                "",
                "           .Layout.Orientation = P_ORIENT",
                "           If.Layout.Orientation<> P_ORIENT Then",
                "               MsgBox(\"用紙方向を設定できませんでした。\", MsgBoxStyle.Exclamation, Application.OpenForms(0).Text)",
                "               Call PRN_ErrEnd()",
                "               Exit Function",
                "           End If",
                "",
                "           flxViewer.PageSettings.Landscape = If(P_ORIENT = OrientationEnum.Landscape, True, False)",
                "           flxViewer.PageSettings.PrinterSettings.Duplex = iDuplex",
                "           P_XX = TextWidthToTwips(\"M\")",
                "           P_YY = TextHeightToTwips(\"M\")",
                "           P_HEIGHT = .PageSettings.Height.Value '高さ",
                "           P_WIDTH = .PageSettings.Width.Value '幅",
                "       End With",
                "",
                "       If ViewFlg = True Then",
                "           ViewFrm.Text = DocName & \"を出力中...\"",
                "           '2021.08.12 UPGRADE E",
                "       Else",
                "           ViewFrm.Hide()",
                "       End If",
                "       '正常終了",
                "       PRN_First = True",
                "   End Function"
            };
            return fileContent;
        }

        public static List<string> ModifyFncPRN_XGET()
        {
            var fileContent = new List<string>();
            fileContent.Add(string.Empty);
            fileContent.Add("    '-------------------------------------------------------------------------------");
            fileContent.Add("    '   処理    :   印刷開始位置取得処理");
            fileContent.Add("    '   関数    :   Function    PRN_XGet(FG,XX1,XX2,FSIZE,DT)");
            fileContent.Add("    '   引数    :   FG          Integer     印刷位置    0:左詰め  1:中央揃え  2:右詰め");
            fileContent.Add("    '   　　        XX1         Single      印刷開始位置");
            fileContent.Add("    '   　　        XX2         Single      印刷終了位置");
            fileContent.Add("    '   　　        FSIZE       Single      現設定フォントサイズ");
            fileContent.Add("    '   　　        DT          String      印刷データ");
            fileContent.Add("    '   戻値    :   印刷開始位置");
            fileContent.Add("    '   機能    :   印刷データを指定位置に印刷する為のポイントを取得する。");
            fileContent.Add("    '-------------------------------------------------------------------------------");
            fileContent.Add("Public Sub PRN_XGet(ByVal FG As Short, ByVal XX1 As Single, ByVal XX2 As Single, ByRef PR_WK_Renamed As PR_WK)");
            fileContent.Add("    Dim psiP_XX = TextWidthToTwips(\"M\", PR_WK_Renamed.FS)");
            fileContent.Add("    PR_WK_Renamed.X = XX1 + psiP_XX / 2");
            fileContent.Add("    Select Case FG");
            fileContent.Add("       '左詰め");
            fileContent.Add("        Case 0");
            fileContent.Add("            PR_WK_Renamed.AL = FieldAlignEnum.LeftMiddle");
            fileContent.Add("        '中央揃え");
            fileContent.Add("        Case 1");
            fileContent.Add("            PR_WK_Renamed.AL = FieldAlignEnum.CenterMiddle");
            fileContent.Add("        '右詰め");
            fileContent.Add("        Case 2");
            fileContent.Add("            PR_WK_Renamed.AL = FieldAlignEnum.RightMiddle");
            fileContent.Add("    End Select");
            fileContent.Add("    PR_WK_Renamed.WID = XX2 - XX1 - psiP_XX");
            fileContent.Add("   End Sub");
            return fileContent;
        }
        public static List<string> ModifyFncPRN_XGET_mm()
        {
            var fileContent = new List<string>();
            fileContent.Add(string.Empty);
            fileContent.Add("    '-------------------------------------------------------------------------------");
            fileContent.Add("    '   処理    :   印刷開始位置取得処理（ミリメートル指定）");
            fileContent.Add("    '   関数    :   Function    PRN_XGet(FG,XX1,XX2,FSIZE,DT)");
            fileContent.Add("    '   引数    :   FG          Integer     印刷位置    0:左詰め  1:中央揃え  2:右詰め");
            fileContent.Add("    '   　　        XX1         Single      印刷開始位置");
            fileContent.Add("    '   　　        XX2         Single      印刷終了位置");
            fileContent.Add("    '   　　        DT          String      印刷データ");
            fileContent.Add("    '   戻値    :   印刷開始位置");
            fileContent.Add("    '   機能    :   印刷データを指定位置に印刷する為のポイントを取得する。");
            fileContent.Add("    '-------------------------------------------------------------------------------");
            fileContent.Add("    Public Function PRN_XGet_mm(ByRef FG As Short, ByRef XX1 As Single, ByRef XX2 As Single, ByRef PR_WK_Renamed As PR_WK) As Single");
            fileContent.Add("        Dim psiP_XX = TextWidthToTwips(\"M\")");
            fileContent.Add("       PR_WK_Renamed.X = ((XX1 * 56.7) + psiP_XX / 2) / 56.7");
            fileContent.Add("       Select Case FG");
            fileContent.Add("'          '左詰め");
            fileContent.Add("           Case 0");
            fileContent.Add("               PR_WK_Renamed.AL = FieldAlignEnum.LeftMiddle");
            fileContent.Add("           '中央揃え");
            fileContent.Add("           Case 1");
            fileContent.Add("               PR_WK_Renamed.AL = FieldAlignEnum.CenterMiddle");
            fileContent.Add("           '右詰め");
            fileContent.Add("           Case 2");
            fileContent.Add("               PR_WK_Renamed.AL = FieldAlignEnum.RightMiddle");
            fileContent.Add("       End Select");
            fileContent.Add("       PR_WK_Renamed.WID = XX2 * 56.7 - XX1 * 56.7 - psiP_XX");
            fileContent.Add("   End Function");
            return fileContent;
        }
        public static List<string> ModifyFncPRN_END()
        {
            var fileContent = new List<string>();
            fileContent.Add(string.Empty);
            fileContent.Add("    '-------------------------------------------------------------------------------");
            fileContent.Add("    '   処理    :   印刷終了処理");
            fileContent.Add("    '   関数    :   Sub     PRN_END()");
            fileContent.Add("    '   機能    :   印刷終了処理を行う。");
            fileContent.Add("    '-------------------------------------------------------------------------------");
            fileContent.Add("    Public Sub PRN_END()");
            fileContent.Add("        '----- 印刷");
            fileContent.Add("        If P_COUNT > 0 Then");
            fileContent.Add("            PRN.Sections.Detail.Height = (P_COUNT + 1) * P_HEIGHT");
            fileContent.Add("        Else");
            fileContent.Add("            PRN.Sections.Detail.Height = P_HEIGHT");
            fileContent.Add("        End If");
            fileContent.Add("        ViewForm.C1FlexViewer1.DocumentSource = PRN");
            fileContent.Add("        P_COUNT = 0");
            fileContent.Add("        If ViewFlg = True Then");
            fileContent.Add("            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default");
            fileContent.Add("            ViewForm.ShowDialog()");
            fileContent.Add("        Else");
            fileContent.Add("            If pDlg Is Nothing Then");
            fileContent.Add("                CustomPrint(False)");
            fileContent.Add("            Else");
            fileContent.Add("                CustomPrint(True)");
            fileContent.Add("            End If");
            fileContent.Add("            ViewForm.Close()");
            fileContent.Add("        End If");
            fileContent.Add("        PRN = Nothing");
            fileContent.Add("    End Sub");
            return fileContent;
        }

        public static List<string> AddFncTextWidthToTwips(string vsPrinterName)
        {
            var name = string.IsNullOrEmpty(vsPrinterName) ? "PRN" : vsPrinterName;
            var fileContent = new List<string>();
            fileContent.Add(string.Empty);
            fileContent.Add("    '-------------------------------------------------------------------------------");
            fileContent.Add("    '   処理    :   Get text width                                                  ");
            fileContent.Add("    '   関数    :   Function         TextWidthToTwips(text)                         ");
            fileContent.Add("    '   引数    :   text       String                                               ");
            fileContent.Add("    '   機能    :                                                                   ");
            fileContent.Add("    '-------------------------------------------------------------------------------");
            fileContent.Add("    Public Function TextWidthToTwips(text As String, Optional fontSize As Single = 0) As Single");
            if (string.IsNullOrEmpty(vsPrinterName)) 
                fileContent.Add("        '\\\\TODO: Change property name of \"PRN\"");

            fileContent.Add("        If fontSize = 0 Then");
            fileContent.Add("            fontSize = " + name + ".Font.Size");
            fileContent.Add("        End If");
            fileContent.Add("        Dim font As Font");
            fileContent.Add("        font = New Font(" + name + ".Font.Name, fontSize, FontStyle.Regular, GraphicsUnit.Point, 128)");
            fileContent.Add("        Dim g As Graphics = ViewForm.CreateGraphics()");
            fileContent.Add("        g.PageUnit = GraphicsUnit.Point");
            fileContent.Add("        'A twip = 1/20 point");
            fileContent.Add("        Dim w As Single = 20 * g.MeasureString(text, Font, -1, StringFormat.GenericTypographic).Width");
            fileContent.Add("        If 0F = w Then");
            fileContent.Add("            ' encoding shift-JIS");
            fileContent.Add("            Dim countBytes As Integer = Encoding.GetEncoding(932).GetBytes(text).Length");
            fileContent.Add("            Dim strByByte As New String(\"M\", countBytes)");
            fileContent.Add("            w = 20 * g.MeasureString(strByByte, Font, -1, StringFormat.GenericTypographic).Width");
            fileContent.Add("        End If");
            fileContent.Add("        Return w");
            fileContent.Add("    End Function");
            return fileContent;
        }

        public static List<string> AddFncTextHeightToTwips(string vsPrinterName)
        {
            var name = string.IsNullOrEmpty(vsPrinterName) ? "PRN" : vsPrinterName;
            var fileContent = new List<string>();
            fileContent.Add(string.Empty);
            fileContent.Add("    '-------------------------------------------------------------------------------");
            fileContent.Add("    '   処理    :   Get text width                                                  ");
            fileContent.Add("    '   関数    :   Function         TextHeightToTwips(text)                         ");
            fileContent.Add("    '   引数    :   text       String                                               ");
            fileContent.Add("    '   機能    :                                                                   ");
            fileContent.Add("    '-------------------------------------------------------------------------------");
            fileContent.Add("    Public Function TextHeightToTwips(text As String, Optional fontSize As Single = 0) As Single");
            if (string.IsNullOrEmpty(vsPrinterName))
                fileContent.Add("        '\\\\TODO: Change property name of \"PRN\"");

            fileContent.Add("        If fontSize = 0 Then");
            fileContent.Add("            fontSize = " + name + ".Font.Size");
            fileContent.Add("        End If");
            fileContent.Add("        Dim font As Font");
            fileContent.Add("        font = New Font(" + name + ".Font.Name, fontSize, FontStyle.Regular, GraphicsUnit.Point, 128)");
            fileContent.Add("        Dim g As Graphics = ViewForm.CreateGraphics()");
            fileContent.Add("        g.PageUnit = GraphicsUnit.Point");
            fileContent.Add("        'A twip = 1/20 point");
            fileContent.Add("        Dim h As Single = 20 * g.MeasureString(text, font, -1, StringFormat.GenericTypographic).Height");
            fileContent.Add(string.Empty);
            fileContent.Add("        Return h");
            fileContent.Add("    End Function");
            return fileContent;
        }

        public static List<string> AddFncRoundFontSize()
        {
            var fileContent = new List<string>();
            fileContent.Add(string.Empty);
            fileContent.Add("    '-------------------------------------------------------------------------------");
            fileContent.Add("    '   処理    :   Round FontSize");
            fileContent.Add("    '   関数    :   Function         RoundFontSize(size)");
            fileContent.Add("    '   引数    :   size       Single ");
            fileContent.Add("    '   機能    :   ");
            fileContent.Add("    '-------------------------------------------------------------------------------");
            fileContent.Add("    Private Function RoundFontSize(size As Single) As Single");
            fileContent.Add("        Dim int As Integer = size * 10 \\ 10");
            fileContent.Add("        Dim dec As Integer = size * 10 Mod 10");
            fileContent.Add("        Dim decRound As Single");
            fileContent.Add(string.Empty);
            fileContent.Add("        Select Case dec");
            fileContent.Add("            Case 0");
            fileContent.Add("                int -= 1");
            fileContent.Add("                decRound = 0.75");
            fileContent.Add("            Case 2");
            fileContent.Add("                decRound = 0");
            fileContent.Add("            Case 4");
            fileContent.Add("                decRound = 0.25");
            fileContent.Add("            Case 6");
            fileContent.Add("                decRound = 0.25");
            fileContent.Add("            Case 8");
            fileContent.Add("                decRound = 0.5");
            fileContent.Add("        End Select");
            fileContent.Add(string.Empty);
            fileContent.Add("        Return int + decRound");
            fileContent.Add("    End Function");
            return fileContent;
        }

        public static List<string> AddFncIsPaperSize()
        {
            var fileContent = new List<string>();
            fileContent.Add(string.Empty);
            fileContent.Add("    '-------------------------------------------------------------------------------");
            fileContent.Add("    '   処理    :   Check PaperSize");
            fileContent.Add("    '   関数    :   Function         IsPaperSize(paperSizeCollection, paperKind)");
            fileContent.Add("    '   引数    :   paperSizeCollection       PaperSizeCollection ");
            fileContent.Add("    '   　　        paperKind   PaperKind");
            fileContent.Add("    '   機能    :   ");
            fileContent.Add("    '-------------------------------------------------------------------------------");
            fileContent.Add("    Private Function IsPaperSize(paperSizeCollection As PaperSizeCollection, paperKind As PaperKind) As Boolean");
            fileContent.Add("        Dim result = False");
            fileContent.Add("        For Each item As PaperSize In paperSizeCollection");
            fileContent.Add("            If item.Kind = paperKind Then");
            fileContent.Add("                result = True");
            fileContent.Add("                Exit For");
            fileContent.Add("            End If");
            fileContent.Add("        Next");
            fileContent.Add("        Return result");
            fileContent.Add("    End Function");
            return fileContent;
        }

        public static List<string> AddFncOpenDialogPrint()
        {
            var fileContent = new List<string>();
            fileContent.Add(string.Empty);
            fileContent.Add("    '----------------------------------------------------------------------");
            fileContent.Add("    ' サブルーチン名          OpenDialogPrint");
            fileContent.Add("    '");
            fileContent.Add("    ' 戻値     印刷設定ダイアログ");
            fileContent.Add("    '----------------------------------------------------------------------");
            fileContent.Add("    Public Function OpenDialogPrint() As Boolean");
            fileContent.Add("        Dim C1FlexReport1 As New C1FlexReport");
            fileContent.Add("        ' レポート描画");
            fileContent.Add("        C1FlexReport1.Render()");
            fileContent.Add(string.Empty);
            fileContent.Add("        ' .NET標準の印刷設定ダイアログ");
            fileContent.Add("        pDlg = New PrintDialog");
            fileContent.Add("        pDlg.UseEXDialog = True");
            fileContent.Add(string.Empty);
            fileContent.Add("        ' ページ指定を可能にします");
            fileContent.Add("        pDlg.AllowSomePages = True");
            fileContent.Add("        pDlg.PrinterSettings.FromPage = 1");
            fileContent.Add("        pDlg.PrinterSettings.ToPage = C1FlexReport1.PageCount");
            fileContent.Add("        For Each item As PaperSize In pDlg.PrinterSettings.PaperSizes");
            fileContent.Add("            If item.Kind = P_SIZE Then");
            fileContent.Add("                pDlg.PrinterSettings.DefaultPageSettings.PaperSize = item");
            fileContent.Add("                Exit For");
            fileContent.Add("            End If");
            fileContent.Add("        Next");
            fileContent.Add("        If P_ORIENT = OrientationEnum.Landscape Then pDlg.PrinterSettings.DefaultPageSettings.Landscape = True Else pDlg.PrinterSettings.DefaultPageSettings.Landscape = False");
            fileContent.Add(string.Empty);
            fileContent.Add("        ' ダイアログ表示");
            fileContent.Add("        If pDlg.ShowDialog = DialogResult.OK Then");
            fileContent.Add("            P_SIZE = pDlg.PrinterSettings.DefaultPageSettings.PaperSize.Kind");
            fileContent.Add("            If pDlg.PrinterSettings.DefaultPageSettings.Landscape Then");
            fileContent.Add("                P_ORIENT = OrientationEnum.Landscape");
            fileContent.Add("            Else");
            fileContent.Add("                P_ORIENT = OrientationEnum.Portrait");
            fileContent.Add("            End If");
            fileContent.Add("            Return True");
            fileContent.Add("        End If");
            fileContent.Add("        Return False");
            fileContent.Add("    End Function");
            return fileContent;
        }

        public static List<string> AddFncCustomPrint()
        {
            var fileContent = new List<string>();
            fileContent.Add(string.Empty);
            fileContent.Add("    '----------------------------------------------------------------------");
            fileContent.Add("    ' サブルーチン名          CustomPrint");
            fileContent.Add("    '");
            fileContent.Add("    ' 戻値     印刷");
            fileContent.Add("    '----------------------------------------------------------------------");
            fileContent.Add("    Public Sub CustomPrint(ByVal dialogFlg As Boolean)");
            fileContent.Add("        PRN.Render()");
            fileContent.Add("        If dialogFlg = False Then");
            fileContent.Add("            pDlg = New PrintDialog");
            fileContent.Add("        End If");
            fileContent.Add("        pDlg.UseEXDialog = True");
            fileContent.Add(string.Empty);
            fileContent.Add("        ' ページ指定を可能にします");
            fileContent.Add("        pDlg.AllowSomePages = True");
            fileContent.Add("        pDlg.PrinterSettings.FromPage = 1");
            fileContent.Add("        pDlg.PrinterSettings.ToPage = PRN.PageCount");
            fileContent.Add("        For Each item As PaperSize In pDlg.PrinterSettings.PaperSizes");
            fileContent.Add("            If item.Kind = P_SIZE Then");
            fileContent.Add("                pDlg.PrinterSettings.DefaultPageSettings.PaperSize = item");
            fileContent.Add("                Exit For");
            fileContent.Add("            End If");
            fileContent.Add("        Next");
            fileContent.Add("        If P_ORIENT = OrientationEnum.Landscape Then pDlg.PrinterSettings.DefaultPageSettings.Landscape = True Else pDlg.PrinterSettings.DefaultPageSettings.Landscape = False");
            fileContent.Add("        pDlg.PrinterSettings.PrinterName = P_DevName");
            fileContent.Add(string.Empty);
            fileContent.Add("        PRN.Print(pDlg.PrinterSettings)");
            fileContent.Add("    End Sub");
            return fileContent;
        }
    }
}
