﻿using AIT.Convert.Const;
using AIT.Convert.Converter;
using AIT.Convert.Logic;
using AIT.Convert.Messages;
using AIT.Convert.Model;
using AIT.Convert.Utils;
using Microsoft.WindowsAPICodePack.Dialogs;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace AIT.Convert
{
    public partial class Main : Form
    {
        private enum SelectMode { All, None, Change }

        private void SelectItems(SelectMode mode)
        {
            foreach (ListViewItem item in lvwFiles.Items)
            {
                switch (mode)
                {
                    case SelectMode.All:
                        item.Checked = true;
                        break;
                    case SelectMode.None:
                        item.Checked = false;
                        break;
                    case SelectMode.Change:
                        item.Checked = !item.Checked;
                        break;
                }
            }
        }

        private void ListFiles(string path)
        {

            lvwFiles.Items.Clear();

            List<FileInfo> Files = new DirectoryInfo(path).GetFiles("*.vb", SearchOption.TopDirectoryOnly).ToList(); //Get files



            List<FileInfo> VbFiles = Files.Where(File => !Regex.Match(File.Name, Constant.VbDesignerFilePattern, RegexOptions.IgnoreCase).Success).ToList();//file VB
            if (!VbFiles.Any())
            {
                MessageBox.Show("There is no .vb files founded in this folder", "No Files !", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtSource.Clear();
                txtSource.Focus();
            }
            SpreadConverter.DesignFiles = Files.Where(File => Regex.Match(File.Name, Constant.VbDesignerFilePattern, RegexOptions.IgnoreCase).Success).ToList();//File Design

            //Dictionary<string, string> types = new Dictionary<string, string>();
            //types.Add(".bas", "Module");
            //types.Add(".cls", "Class");
            //types.Add(".frm", "Form");
            //types.Add(".vb", "VB");

            //DirectoryInfo dir = new DirectoryInfo(path);

            foreach (FileInfo file in VbFiles)
            {
                string type = file.Extension;
                string name = file.Name;

                ListViewItem item = new ListViewItem(new string[] { name, type, string.Empty, string.Empty });
                item.UseItemStyleForSubItems = false;
                item.Checked = true;
                lvwFiles.Items.Add(item);
            }
            bool hasItems = lvwFiles.Items.Count > 0;
            gbxFiles.Enabled = hasItems;
            gbxDestination.Enabled = hasItems;
            btnConvert.Enabled = hasItems;
        }

        private void FolderSelectionHandler(object sender, EventArgs e)
        {
            try
            {
                TextBox TextBoxObject = null;

                if (object.ReferenceEquals(sender, btnSourceSelect))
                    TextBoxObject = txtSource;
                else if (object.ReferenceEquals(sender, btnDestinationSelect))
                    TextBoxObject = txtDestination;
                else
                    return;


                CommonOpenFileDialog dialog = new CommonOpenFileDialog();
                dialog.InitialDirectory = TextBoxObject.Text;
                dialog.IsFolderPicker = true;
                if (dialog.ShowDialog() == CommonFileDialogResult.Ok)
                {
                    TextBoxObject.Text = dialog.FileName;
                    if (object.ReferenceEquals(sender, btnSourceSelect))
                        ListFiles(TextBoxObject.Text);
                }

                TextBoxObject.Focus();
            }
            catch (Exception ex)
            {
                MessageBox.Show("There's a error trying to select a directory. \n\nDetails: " + ex.Message, "VB Converter", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void SelectItemsHandler(object sender, EventArgs e)
        {
            try
            {
                if (object.ReferenceEquals(sender, btnSelectAll))
                    SelectItems(SelectMode.All);
                else if (object.ReferenceEquals(sender, btnSelectNone))
                    SelectItems(SelectMode.None);
                else if (object.ReferenceEquals(sender, btnSelectChange))
                    SelectItems(SelectMode.Change);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Details: " + ex.Message, "VB Converter", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        /// <summary>
        /// Load Form
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FileTool_Load(object sender, EventArgs e)
        {
            cmbDatabase.Items.Insert(0, "");
            cmbDatabase.Items.Insert(1, "Oracle->SQL Server");
            cmbDatabase.Items.Insert(2, "Oracle->Oracle");
            try
            {
                gbxFiles.Enabled = false;
                gbxDestination.Enabled = false;
                btnConvert.Enabled = false;
                pbrStatus.Visible = false;
                btnReason.Visible = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show("There's a error trying to open the window. \n\nDetails: " + ex.Message, "VB Converter", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// Clear Folder
        /// To clear all file and folder in path
        /// </summary>
        /// <returns>Result of Clear Folder</returns>
        private bool ClearFolder()
        {
            if (Common.IsDirectoryEmpty(txtDestination.Text))
            {
                return true;
            }
            DirectoryInfo di = new DirectoryInfo(txtDestination.Text);
            var connfirm = MessageBox.Show($"We're about to Clear all the files and folder in this path " +
                $"{Environment.NewLine} [ {txtDestination.Text} ] {Environment.NewLine} Please check and confirm again, this can't be revert !",
                   "CONFIRM CLEAR", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (connfirm == DialogResult.Yes)
            {
                try
                {
                    foreach (FileInfo file in di.GetFiles())
                    {
                        file.Delete();
                    }
                    foreach (DirectoryInfo dir in di.GetDirectories())
                    {
                        dir.Delete(true);
                    }
                    return true;
                }
                catch (Exception)
                {
                    return false;
                }
            }
            return false;
        }

        private void btnConvert_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtDestination.Text.Equals(txtSource.Text))
                {
                    MessageBox.Show("The destination folder and source folder is same. \n\nPlease choose right path.", "VB Converter", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtDestination.Focus();
                    return;
                }

                if (string.IsNullOrEmpty(txtDestination.Text))
                {
                    MessageBox.Show("The destination folder has not been informed. \n\nPlease inform a valid path for recording the result of the conversion.", "VB Converter", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtDestination.Focus();
                    return;
                }

                int fileCount = lvwFiles.CheckedItems.Count;
                if (fileCount == 0)
                {
                    MessageBox.Show("There are no files selected for conversion. \n\nSelect files by clicking on the checkbox ・ to the left of the name.", "VB Converter", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    lvwFiles.Focus();
                    return;
                }

                if (!ClearFolder())
                {
                    txtDestination.Focus();
                    return;
                }

                this.Cursor = Cursors.WaitCursor;
                lblStatus.Text = "Processing...";
                pbrStatus.Maximum = fileCount;
                pbrStatus.Value = 0;

                pbrStatus.Visible = true;
                lblStatus.Visible = true;

                foreach (ListViewItem item in lvwFiles.CheckedItems)
                {
                    item.SubItems[2].Text = string.Empty;
                    item.SubItems[2].ForeColor = item.ForeColor;
                    item.SubItems[2].Font = new Font(item.Font, FontStyle.Regular);
                    item.SubItems[3].Text = string.Empty;
                }

                Application.DoEvents();
                int sucessCount = 0;
                int errorCount = 0;

                LoadRules();
                LoadMessagesAndSubRules();

                foreach (ListViewItem item in lvwFiles.CheckedItems)
                {
                    pbrStatus.Value++;
                    lblStatus.Text = "Converting the file" + item.Text;
                    item.SubItems[2].Text = "Converting...";
                    item.EnsureVisible();

                    string reason = string.Empty;
                    bool success = ConvertFile(item.Text, out reason);
                    if (success)
                        sucessCount++;
                    else
                        errorCount++;

                    item.SubItems[2].Text = success ? "Success" : "Error";
                    item.SubItems[2].ForeColor = success ? Color.Blue : Color.Red;
                    item.SubItems[2].Font = new Font(item.SubItems[2].Font, FontStyle.Bold);
                    item.SubItems[3].Text = reason;
                }

                string message = "Batch conversion sucessfully done !";
                if (errorCount > 0)
                    message = string.Format("The batch conversion has finished, but {0} files couldn't be converted !'.", errorCount);

                MessageBox.Show(message, "VB Converter", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("There's a error trying to convert!. \n\nDetail: " + ex.Message, "VB Converter", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                lblStatus.Visible = false;
                pbrStatus.Visible = false;
                this.Cursor = Cursors.Default;
            }
        }

        private bool ConvertFile(string file, out string errorReason)
        {
            try
            {
                Application.DoEvents();
                string sourcePath = $"{txtSource.Text}\\{file}";

                FileInfo info = new FileInfo(sourcePath);
                string fileName = info.Name;
                ConvertLogic converter = new ConvertLogic();
                bool hasSpread = SpreadConverter.CheckHasSpread(fileName);
                ConvertCondition condition = new ConvertCondition(hasSpread, GetConditionDb(), GetConditionRpt());
                bool success = converter.ConvertFile(info, condition, txtSource.Text, txtDestination.Text, out errorReason);

                if (success)
                {
                    errorReason = null;
                    btnReason.Visible = true;
                    return success;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                errorReason = string.Format("Cannot convert due to internal error.\n\nDetails: " + ex.Message);
                return false;
            }
        }

        private TypeConvertRpt? GetConditionRpt()
        {
            if (cmbConvertReport.SelectedIndex == 1)
                return TypeConvertRpt.VSPrintToFlexReport;
            else
                return null;
        }

        private TypeConvertDB? GetConditionDb()
        {
            if (cmbDatabase.SelectedIndex == 1)
                return TypeConvertDB.OaracleToSQLServer;
            else if (cmbDatabase.SelectedIndex == 2)
                return TypeConvertDB.OracleToOracle;
            else
                return null;
        }

        private void ShowErrorReasonHandler(object sender, EventArgs e)
        {
            try
            {
                string text = string.Empty;
                LogFrm logfrm = new LogFrm();
                logfrm.GetLog(txtDestination.Text);
                logfrm.ShowDialog();
                if (!string.IsNullOrEmpty(text))
                    MessageBox.Show("This file cannot be converted.\n\nDetails: " + text, "VB Converter", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            catch (Exception ex)
            {
                MessageBox.Show("This file cannot be converted.\n\nDetails: " + ex.Message, "VB Converter", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadRules()
        {
            VbConverter.VBRules = LoadRuleByName(nameof(VbConverter.VBRules));
            VbConverter.DBRules = LoadRuleByName(nameof(VbConverter.DBRules));
            SpreadConverter.SpreadRules = LoadRuleByName(nameof(SpreadConverter.SpreadRules));
            VSViewConverter.VSViewRules = LoadRuleByName(nameof(VSViewConverter.VSViewRules));
            VSViewConverter.ViewToolRules = LoadRuleByName(nameof(VSViewConverter.ViewToolRules));
        }
        private List<RuleModel> LoadRuleByName(string nameRules)
        {
            List<RuleModel> rules = new List<RuleModel>();
            var path = string.Empty;
            switch (nameRules)
            {
                case nameof(VbConverter.VBRules):
                    path = Constant.FilePath.VB_RULES;
                    break;
                case nameof(SpreadConverter.SpreadRules):
                    path = Constant.FilePath.SPREAD_RULES;
                    break;
                case nameof(VbConverter.DBRules):
                    if (GetConditionDb() == TypeConvertDB.OracleToOracle)
                        path = Constant.FilePath.ORACLE_RULES;
                    else
                        path = Constant.FilePath.SQLSV_RULES;
                    break;
                case nameof(VSViewConverter.VSViewRules):
                    path = Constant.FilePath.VSVIEW_RULES;
                    break;
                case nameof(VSViewConverter.ViewToolRules):
                    path = Constant.FilePath.VIEWTOOL_RULES;
                    break;
            }
            string text = System.IO.File.ReadAllText(path);
            string[] ruleArr = text.Split(Environment.NewLine.ToCharArray());
            ruleArr = ruleArr.Where(x => !string.IsNullOrEmpty(x)).ToArray();
            rules = new List<RuleModel>();
            foreach (var item in ruleArr.Skip(1))
            {
                try
                {
                    RuleModel rule = new RuleModel(item);
                    rules.Add(rule);
                }
                catch (Exception)
                {
                    continue;
                }
            }
            return rules;
        }

        /// <summary>
        /// LoadMessages
        /// Convert Messages to Object
        /// </summary>
        private void LoadMessagesAndSubRules()
        {
            string text = System.IO.File.ReadAllText(Constant.FilePath.MESSAGES);
            string[] MessArr = text.Split(Environment.NewLine.ToCharArray());
            MessArr = MessArr.Where(x => !string.IsNullOrEmpty(x)).ToArray();
            foreach (var item in MessArr.Skip(1))
            {
                try
                {
                    ConvertMessage message = new ConvertMessage(item);
                    Common.MessagesList.Add(message);
                }
                catch (Exception)
                {
                    continue;
                }
            }

            text = System.IO.File.ReadAllText(Constant.FilePath.SUB_RULES);
            string[] ruleArr = text.Split(Environment.NewLine.ToCharArray());
            ruleArr = ruleArr.Where(x => !string.IsNullOrEmpty(x)).ToArray();
            foreach (var item in ruleArr.Skip(1))
            {
                try
                {
                    SubRuleModel subRule = new SubRuleModel(item);
                    SubRuleConverter.SubRules.Add(subRule);
                }
                catch (Exception)
                {
                    continue;
                }
            }
        }
    }
}