﻿using AIT.Convert.Const;
using AIT.Convert.Messages;
using AIT.Convert.Model;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace AIT.Convert.Utils
{
    public static class Common
    {
        private static FileInfo ConvertingFile1;
        public static List<ConvertMessage> MessagesList = new List<ConvertMessage>();

        public static FileInfo ConvertingFile { get => ConvertingFile1; set => ConvertingFile1 = value; }

        public static string TabIndent;

        /// <summary>
        /// Get Message
        /// Get Message by messageID
        /// </summary>
        /// <param name="messageID">Message ID</param>
        /// <returns>Return Message String</returns>
        public static string GetMessage(string messageID)
        {
            string message = String.Empty;
            if (messageID == null)
            {
                return message;
            }
            ConvertMessage convertMessage = MessagesList.Where(
                   m => m.ID.Equals(messageID, StringComparison.OrdinalIgnoreCase)).FirstOrDefault();
            message += $"\t'{convertMessage.Value}";
            return message;
        }

        /// <summary>
        /// Get Messages
        /// Get Message by List of messageID
        /// </summary>
        /// <param name="messageID">Message ID</param>
        /// <returns>Return Message String</returns>
        public static string GetMessage(List<string> messageID)
        {
            string message = String.Empty;
            if (!messageID.Any())
            {
                return message;
            }
            foreach (string id in messageID)
            {
                ConvertMessage convertMessage = MessagesList.Where(
                    m => m.ID.Equals(id, StringComparison.OrdinalIgnoreCase)).FirstOrDefault();
                if (convertMessage != null)
                {
                    message += $"\t'{convertMessage.Value}{Environment.NewLine}";
                }
            }
            return message;
        }

        /// <summary>
        /// Add Message
        /// Add Message to Convert Object
        /// </summary>
        /// <param name="messageID">Message ID</param>
        /// <param name="convertObject">Convert Object</param>
        public static void AddMessageID(ConvertResult convertObject, string messageId)
        {
            if (!convertObject.MessageID.Contains(messageId))
            {
                convertObject.MessageID.Add(messageId);
            }
        }

        /// <summary>
        /// Get Messages
        /// Get Message by List of messageID
        /// </summary>
        /// <param name="messageID">Message ID</param>
        /// <param name="convertObject">Convert Object</param>
        public static bool IsDirectoryEmpty(string path)
        {
            return !Directory.EnumerateFileSystemEntries(path).Any();
        }

        /// <summary>
        /// Check line comment
        /// </summary>
        /// <param name="line"></param>
        /// <returns>Result of Is Comment</returns>
        public static bool IsComment(string Line)
        {
            //if (Line.StartsWith("'"))
            if(Regex.IsMatch(Line,@"^\s*\'.*"))
            {
                return true;
            }
            return false;
        }

        public static string getCommentStart(string tabIndent = "\t", string converterName = "Tool Convert")
        {
            return $"{tabIndent}'{ DateTime.Now:yyyy.MM.dd} UPGRADE S  AIT){converterName}";
        }
        public static string getCommentEnd(string tabIndent = "\t", string converterName = "Tool Convert")
        {
            return $"{tabIndent}'{ DateTime.Now:yyyy.MM.dd} UPGRADE E";
        }

        public static string getADDComment(string tabIndent = "\t", string converterName = "Tool Convert")
        {
            return $"{tabIndent}'{ DateTime.Now:yyyy.MM.dd} UPGRADE ADD AIT){converterName}";
        }

        public static string getDELComment(string tabIndent = "\t", string converterName = "Tool Convert")
        {
            return $"{tabIndent}'{ DateTime.Now:yyyy.MM.dd} UPGRADE DEL AIT){converterName}";
        }
    }
}
