﻿using Microsoft.WindowsAPICodePack.Dialogs;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Windows.Forms;
using static AIT.Convert.Utils.ConfigUtil;

namespace AIT.Convert.Utils
{
    public static class FileUtils
    {

        /// <summary>
        /// PercentCalculator
        /// </summary>
        /// <param name="fileIndex">fileIndex</param>
        /// <param name="totalFile">totalFile</param>
        public static int PercentCalculator(int fileIndex, int totalFile)
        {
            int percentComplete = (int)Math.Round((double)(100 * fileIndex) / totalFile);
            return percentComplete;
        }

        /// <summary>
        /// WriteFile
        /// </summary>
        /// <param name="fileIndex">Textbox</param>
        /// <param name="totalFile">Key</param>
        public static void WriteFile(string inputPath, string outputPath, FileInfo file, string content)
        {
            string folderPath = file.FullName.Replace(inputPath, outputPath).Replace(file.Name, "");
            string outputPathString = file.FullName.Replace(inputPath, outputPath);
            if (!Directory.Exists(folderPath))
            {
                System.IO.Directory.CreateDirectory(folderPath);
            }
            try
            {
                if (File.Exists(outputPathString))
                {
                    using (FileStream fs = File.Create(outputPathString))
                    {
                        byte[] info = Encoding.GetEncoding(932).GetBytes(content);
                        fs.Write(info, 0, info.Length);
                    }
                }
                else
                {
                    using (FileStream fs = File.Create(outputPathString))
                    {
                        byte[] info = Encoding.GetEncoding(932).GetBytes(content);
                        fs.Write(info, 0, info.Length);
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception("WriteFile Error: " + ex.Message);
            }
        }

    }
}
