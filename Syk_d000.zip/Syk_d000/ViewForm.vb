Option Strict Off
Option Explicit On
Friend Class ViewForm
	Inherits System.Windows.Forms.Form
	'
	
	Private Sub ConfigureButtons()
		Const pixLeft As Short = 220
		Const pixTop As Short = 2
		Const pixWid As Short = 20
		Const pixHei As Short = 14
		Const pixSpace As Short = 4

		' �ϊ��l���擾����
		Dim tppX, tppY As Single
		'2021.08.05 UPGRADE S  AIT)dannnl
		'tppX = VB6.TwipsPerPixelX
		'tppY = VB6.TwipsPerPixelY
		tppX = Util.TwipsPerPixelX(Me)
		tppY = Util.TwipsPerPixelY(Me)
		'2021.08.05 UPGRADE E

		' �{�^���R���g���[���̐ݒ�
		'Dim i As Short
		'Dim X As Single
		'For i = 0 To 1
		'	With picBtn(i)
		'		.AutoRedraw = True
		'		.BorderStyle = System.Windows.Forms.BorderStyle.None
		'		X = (pixLeft + (pixWid + pixSpace) * i) * tppX
		'		'2021.08.05 UPGRADE S  AIT)dannnl
		'		'.SetBounds(VB6.TwipsToPixelsX(VB6.PixelsToTwipsX(vsPrinter1.Left) + X), VB6.TwipsToPixelsY(VB6.PixelsToTwipsY(vsPrinter1.Top) + pixTop * tppY), VB6.TwipsToPixelsX(pixWid * tppX), VB6.TwipsToPixelsY(pixHei * tppY))
		'		'.SetBounds(Util.TwipsToPixelsX(Util.PixelsToTwipsX(vsPrinter1.Left, Me) + X, Me), Util.TwipsToPixelsY(Util.PixelsToTwipsY(vsPrinter1.Top, Me) + pixTop * tppY, Me), Util.TwipsToPixelsX(pixWid * tppX, Me), Util.TwipsToPixelsY(pixHei * tppY, Me))
		'		'2021.08.05 UPGRADE E
		'		.BringToFront()
		'		FrameBtn(picBtn(i), False)
		'	End With
		'Next
	End Sub
	
	Private Sub FrameBtn(ByRef pic As System.Windows.Forms.PictureBox, ByRef bPushed As Short)

		' �ϊ��l�̎擾
		Dim tppX, tppY As Single
		'2021.08.05 UPGRADE S  AIT)dannnl
		'tppX = VB6.TwipsPerPixelX
		'tppY = VB6.TwipsPerPixelY
		tppX = Util.TwipsPerPixelX(Me)
		tppY = Util.TwipsPerPixelY(Me)
		'2021.08.05 UPGRADE E

		' �{�^���t���[���̕`��
		With pic
			If bPushed Then .ForeColor = System.Drawing.ColorTranslator.FromOle(&H80000010) Else .ForeColor = System.Drawing.ColorTranslator.FromOle(&H80000014)
			'pic.Line(0, 0) - (VB6.PixelsToTwipsX(pic.Width), VB6.PixelsToTwipsY(pic.Height)), B
			If bPushed Then .ForeColor = System.Drawing.ColorTranslator.FromOle(&H80000014) Else .ForeColor = System.Drawing.ColorTranslator.FromOle(&H80000010)
			'pic.Line(-100, -100) - (VB6.PixelsToTwipsX(pic.Width) - tppX, VB6.PixelsToTwipsY(pic.Height) - tppY), B
		End With
	End Sub
	
	Private Sub ViewForm_Activated(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Activated
		System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
	End Sub
	
	Private Sub ViewForm_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
		'vsPrinter1.Dock = System.Windows.Forms.DockStyle.Top
		ConfigureButtons()
	End Sub
	
	Private Sub ViewForm_Resize(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Resize
		On Error Resume Next
		'vsPrinter1.Height = ClientRectangle.Height
	End Sub
	
	Private Sub Image1_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) 
		'�v�����^�摜
		Call picBtn_DoubleClick(picBtn.Item(2), New System.EventArgs())
		
	End Sub

	'2021.08.05 UPGRADE S  AIT)dannnl
	'Private Sub picBtn_DoubleClick(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles picBtn.DoubleClick
	'	Dim Index As Short = picBtn.GetIndex(eventSender)
	Private Sub picBtn_DoubleClick(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) 
		Dim Index As Short = picBtn.IndexOf(eventSender)
		'2021.08.05 UPGRADE E
		Select Case Index
			Case 0 ' �g��
				'vsPrinter1.Zoom = vsPrinter1.Zoom + vsPrinter1.ZoomStep
			Case 1 ' �k��
				'vsPrinter1.Zoom = vsPrinter1.Zoom - vsPrinter1.ZoomStep
			Case 2 ' ���
				'If vsPrinter1.PrintDialog(VSPrinter7Lib.PrintDialogSettings.pdPrinterSetup) = False Then
				'�v�����^�̐ݒ�𒆎~���ꂽ�ꍇ
				Exit Sub
				'End If
				'vsPrinter1.PrintDoc()
				'2021.08.31  UPGRADE S  AIT)hieutv
				'Me.Close()
				Me.Dispose()
				'2021.08.31  UPGRADE E
		End Select
	End Sub

	'2021.08.05 UPGRADE S  AIT)dannnl
	'Private Sub picBtn_MouseDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.MouseEventArgs) Handles picBtn.MouseDown
	Private Sub picBtn_MouseDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.MouseEventArgs) 
		'2021.08.05 UPGRADE E
		Dim Button As Short = eventArgs.Button \ &H100000
		Dim Shift As Short = System.Windows.Forms.Control.ModifierKeys \ &H10000
		'2021.08.05 UPGRADE S  AIT)dannnl
		'Dim X As Single = VB6.PixelsToTwipsX(eventArgs.X)
		'Dim Y As Single = VB6.PixelsToTwipsY(eventArgs.Y)
		'Dim Index As Short = picBtn.GetIndex(eventSender)
		Dim X As Single = Util.PixelsToTwipsX(eventArgs.X, Me)
		Dim Y As Single = Util.PixelsToTwipsY(eventArgs.Y, Me)
		Dim Index As Short = picBtn.IndexOf(eventSender)
		'2021.08.05 UPGRADE E
		If Button = 1 Then
			picBtn(Index).Tag = "*"
			FrameBtn(picBtn(Index), True)
		End If
	End Sub

	'2021.08.05 UPGRADE S  AIT)dannnl
	'Private Sub picBtn_MouseUp(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.MouseEventArgs) Handles picBtn.MouseUp
	Private Sub picBtn_MouseUp(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.MouseEventArgs) 
		'2021.08.05 UPGRADE E
		Dim Button As Short = eventArgs.Button \ &H100000
		Dim Shift As Short = System.Windows.Forms.Control.ModifierKeys \ &H10000
		'2021.08.05 UPGRADE S  AIT)dannnl
		'Dim X As Single = VB6.PixelsToTwipsX(eventArgs.X)
		'Dim Y As Single = VB6.PixelsToTwipsY(eventArgs.Y)
		'Dim Index As Short = picBtn.GetIndex(eventSender)
		Dim X As Single = Util.PixelsToTwipsX(eventArgs.X, Me)
		Dim Y As Single = Util.PixelsToTwipsY(eventArgs.Y, Me)
		Dim Index As Short = picBtn.IndexOf(eventSender)
		'2021.08.05 UPGRADE E
		If Button = 1 Then
			If picBtn(Index).Tag = "*" Then
				picBtn_DoubleClick(picBtn.Item(Index), New System.EventArgs())
			End If
			picBtn(Index).Tag = ""
			FrameBtn(picBtn(Index), False)
		End If
	End Sub

	'2021.08.05 UPGRADE S  AIT)dannnl
	'Private Sub picBtn_MouseMove(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.MouseEventArgs) Handles picBtn.MouseMove
	Private Sub picBtn_MouseMove(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.MouseEventArgs) 
		'2021.08.05 UPGRADE E
		Dim Button As Short = eventArgs.Button \ &H100000
		Dim Shift As Short = System.Windows.Forms.Control.ModifierKeys \ &H10000
		'2021.08.05 UPGRADE S  AIT)dannnl
		'Dim X As Single = VB6.PixelsToTwipsX(eventArgs.X)
		'Dim Y As Single = VB6.PixelsToTwipsY(eventArgs.Y)
		'Dim Index As Short = picBtn.GetIndex(eventSender)
		Dim X As Single = Util.PixelsToTwipsX(eventArgs.X, Me)
		Dim Y As Single = Util.PixelsToTwipsY(eventArgs.Y, Me)
		Dim Index As Short = picBtn.IndexOf(eventSender)
		'2021.08.05 UPGRADE E
		If Button = 1 Then
			With picBtn(Index)
				'2021.08.05 UPGRADE S  AIT)dannnl
				'If X < 0 Or Y < 0 Or X > VB6.PixelsToTwipsX(.Left) Or Y > VB6.PixelsToTwipsY(.Height) Then
				If X < 0 Or Y < 0 Or X > Util.PixelsToTwipsX(.Left, Me) Or Y > Util.PixelsToTwipsY(.Height, Me) Then
					'2021.08.05 UPGRADE E
					picBtn(Index).Tag = ""
					FrameBtn(picBtn(Index), False)
				Else
					picBtn(Index).Tag = "*"
					FrameBtn(picBtn(Index), True)
				End If
			End With
		End If
	End Sub
End Class
