Imports GrapeCity.Win.Editors

<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frmSYKD100
#Region "Windows Form Designer generated code "
    <System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
        MyBase.New()
        InitializeComponent()
        'This call is required by the Windows Form Designer.
        Me.Frame1 = New ArrayList
        Me.Label1 = New ArrayList
        Me.cmdKey = New ArrayList
        Me.imText1 = New ArrayList
        Me.imText2 = New ArrayList
        Me.imText3 = New ArrayList
        Me.imText1.Add(_imText1_0)
        Me.imText1.Add(_imText1_1)
        Me.imText2.Add(_imText2_0)
        Me.imText2.Add(_imText2_1)
        Me.imText1.Add(_imText1_2)
        Me.imText1.Add(_imText1_3)
        Me.imText3.Add(_imText3_0)
        Me.imText3.Add(_imText3_1)
        Me.imText2.Add(_imText2_2)
        Me.imText2.Add(_imText2_3)

        Me.Frame1.Add(_Frame1_0)
        Me.Frame1.Add(_Frame1_1)
        Me.Frame1.Add(_Frame1_2)

        Me.Label1.Add(_Label1_0)
        Me.Label1.Add(_Label1_1)
        Me.Label1.Add(_Label1_2)
        Me.Label1.Add(_Label1_3)
        Me.Label1.Add(_Label1_4)
        Me.Label1.Add(_Label1_5)
        Me.Label1.Add(_Label1_6)
        Me.Label1.Add(_Label1_7)
        Me.Label1.Add(_Label1_8)
        Me.Label1.Add(_Label1_9)
        Me.Label1.Add(_Label1_10)
        Me.Label1.Add(_Label1_11)
        Me.Label1.Add(_Label1_12)
        Me.Label1.Add(_Label1_13)
        Me.Label1.Add(_Label1_14)
        Me.Label1.Add(_Label1_15)
        Me.Label1.Add(_Label1_16)

        Me.cmdKey.Add(Nothing)
        Me.cmdKey.Add(_cmdKey_1)
        Me.cmdKey.Add(Nothing)
        Me.cmdKey.Add(Nothing)
        Me.cmdKey.Add(Nothing)
        Me.cmdKey.Add(Nothing)
        Me.cmdKey.Add(Nothing)
        Me.cmdKey.Add(Nothing)
        Me.cmdKey.Add(Nothing)
        Me.cmdKey.Add(Nothing)
        Me.cmdKey.Add(Nothing)
        Me.cmdKey.Add(Nothing)
        Me.cmdKey.Add(_cmdKey_12)
    End Sub
    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
        If Disposing Then
            If Not components Is Nothing Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(Disposing)
    End Sub
    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer
    Public ToolTip1 As System.Windows.Forms.ToolTip
    Public WithEvents _imText3_0 As GcTextBox
    Public WithEvents _imText3_1 As GcTextBox
    Public WithEvents imNumber1 As GcNumber
    Public WithEvents imNumber2 As GcNumber
    Public WithEvents imNumber3 As GcNumber
    Public WithEvents imNumber4 As GcNumber
    Public WithEvents _imText1_2 As GcTextBox
    Public WithEvents imNumber5 As GcNumber
    Public WithEvents _Label1_16 As System.Windows.Forms.Label
    Public WithEvents _Label1_14 As System.Windows.Forms.Label
    Public WithEvents _Label1_15 As System.Windows.Forms.Label
    Public WithEvents _Label1_13 As System.Windows.Forms.Label
    Public WithEvents _Label1_12 As System.Windows.Forms.Label
    Public WithEvents _Label1_11 As System.Windows.Forms.Label
    Public WithEvents _Label1_10 As System.Windows.Forms.Label
    Public WithEvents _Label1_9 As System.Windows.Forms.Label
    Public WithEvents _Label1_8 As System.Windows.Forms.Label
    Public WithEvents _Frame1_2 As System.Windows.Forms.GroupBox
    Public WithEvents _imText1_1 As GcTextBox
    Public WithEvents _imText1_0 As GcTextBox
    Public WithEvents _imText1_3 As GcTextBox
    Public WithEvents _Label1_0 As System.Windows.Forms.Label
    Public WithEvents _Label1_1 As System.Windows.Forms.Label
    Public WithEvents _Frame1_0 As System.Windows.Forms.GroupBox
    Public WithEvents _imText2_0 As GcTextBox
    Public WithEvents _imText2_2 As GcTextBox
    Public WithEvents _imText2_3 As GcTextBox
    Public WithEvents _imText2_1 As GcTextBox
    Public WithEvents _Label1_7 As System.Windows.Forms.Label
    Public WithEvents _Label1_3 As System.Windows.Forms.Label
    Public WithEvents _Label1_4 As System.Windows.Forms.Label
    Public WithEvents _Label1_5 As System.Windows.Forms.Label
    Public WithEvents _Label1_6 As System.Windows.Forms.Label
    Public WithEvents _Label1_2 As System.Windows.Forms.Label
    Public WithEvents _Frame1_1 As System.Windows.Forms.GroupBox
    Public WithEvents _cmdKey_12 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_1 As System.Windows.Forms.Button
    Public WithEvents Picture1 As System.Windows.Forms.Panel
    Public WithEvents _StatusBar1_Panel2 As System.Windows.Forms.ToolStripStatusLabel
    Public WithEvents Message As System.Windows.Forms.ToolStripStatusLabel
    Public WithEvents StatusBar1 As System.Windows.Forms.StatusStrip
    Public WithEvents lblTitle As System.Windows.Forms.Label
    Public WithEvents Frame1 As ArrayList
    Public WithEvents Label1 As ArrayList
    Public WithEvents cmdKey As ArrayList
    Public WithEvents imText1 As ArrayList
    Public WithEvents imText2 As ArrayList
    Public WithEvents imText3 As ArrayList
    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmSYKD100))
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me._Frame1_2 = New System.Windows.Forms.GroupBox()
        Me._imText3_0 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._imText3_1 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me.imNumber1 = New GrapeCity.Win.Editors.GcNumber(Me.components)
        Me.imNumber2 = New GrapeCity.Win.Editors.GcNumber(Me.components)
        Me.imNumber3 = New GrapeCity.Win.Editors.GcNumber(Me.components)
        Me.imNumber4 = New GrapeCity.Win.Editors.GcNumber(Me.components)
        Me._imText1_2 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me.imNumber5 = New GrapeCity.Win.Editors.GcNumber(Me.components)
        Me._Label1_16 = New System.Windows.Forms.Label()
        Me._Label1_14 = New System.Windows.Forms.Label()
        Me._Label1_15 = New System.Windows.Forms.Label()
        Me._Label1_13 = New System.Windows.Forms.Label()
        Me._Label1_12 = New System.Windows.Forms.Label()
        Me._Label1_11 = New System.Windows.Forms.Label()
        Me._Label1_10 = New System.Windows.Forms.Label()
        Me._Label1_9 = New System.Windows.Forms.Label()
        Me._Label1_8 = New System.Windows.Forms.Label()
        Me._Frame1_0 = New System.Windows.Forms.GroupBox()
        Me._imText1_1 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._imText1_0 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._imText1_3 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._Label1_0 = New System.Windows.Forms.Label()
        Me._Label1_1 = New System.Windows.Forms.Label()
        Me._Frame1_1 = New System.Windows.Forms.GroupBox()
        Me._imText2_0 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._imText2_2 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._imText2_3 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._imText2_1 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._Label1_7 = New System.Windows.Forms.Label()
        Me._Label1_3 = New System.Windows.Forms.Label()
        Me._Label1_4 = New System.Windows.Forms.Label()
        Me._Label1_5 = New System.Windows.Forms.Label()
        Me._Label1_6 = New System.Windows.Forms.Label()
        Me._Label1_2 = New System.Windows.Forms.Label()
        Me.Picture1 = New System.Windows.Forms.Panel()
        Me._cmdKey_12 = New System.Windows.Forms.Button()
        Me._cmdKey_1 = New System.Windows.Forms.Button()
        Me.StatusBar1 = New System.Windows.Forms.StatusStrip()
        Me._StatusBar1_Panel2 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.Message = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me._Frame1_2.SuspendLayout()
        CType(Me._imText3_0, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imText3_1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.imNumber1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.imNumber2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.imNumber3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.imNumber4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imText1_2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.imNumber5, System.ComponentModel.ISupportInitialize).BeginInit()
        Me._Frame1_0.SuspendLayout()
        CType(Me._imText1_1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imText1_0, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imText1_3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me._Frame1_1.SuspendLayout()
        CType(Me._imText2_0, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imText2_2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imText2_3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imText2_1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Picture1.SuspendLayout()
        Me.StatusBar1.SuspendLayout()
        Me.SuspendLayout()
        '
        '_Frame1_2
        '
        Me._Frame1_2.BackColor = System.Drawing.SystemColors.Control
        Me._Frame1_2.Controls.Add(Me._imText3_0)
        Me._Frame1_2.Controls.Add(Me._imText3_1)
        Me._Frame1_2.Controls.Add(Me.imNumber1)
        Me._Frame1_2.Controls.Add(Me.imNumber2)
        Me._Frame1_2.Controls.Add(Me.imNumber3)
        Me._Frame1_2.Controls.Add(Me.imNumber4)
        Me._Frame1_2.Controls.Add(Me._imText1_2)
        Me._Frame1_2.Controls.Add(Me.imNumber5)
        Me._Frame1_2.Controls.Add(Me._Label1_16)
        Me._Frame1_2.Controls.Add(Me._Label1_14)
        Me._Frame1_2.Controls.Add(Me._Label1_15)
        Me._Frame1_2.Controls.Add(Me._Label1_13)
        Me._Frame1_2.Controls.Add(Me._Label1_12)
        Me._Frame1_2.Controls.Add(Me._Label1_11)
        Me._Frame1_2.Controls.Add(Me._Label1_10)
        Me._Frame1_2.Controls.Add(Me._Label1_9)
        Me._Frame1_2.Controls.Add(Me._Label1_8)
        Me._Frame1_2.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Frame1_2.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Frame1_2.Location = New System.Drawing.Point(6, 192)
        Me._Frame1_2.Name = "_Frame1_2"
        Me._Frame1_2.Padding = New System.Windows.Forms.Padding(0)
        Me._Frame1_2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Frame1_2.Size = New System.Drawing.Size(551, 207)
        Me._Frame1_2.TabIndex = 29
        Me._Frame1_2.TabStop = False
        '
        '_imText3_0
        '
        Me._imText3_0.BackColor = System.Drawing.SystemColors.Control
        Me._imText3_0.ContentAlignment = System.Drawing.ContentAlignment.MiddleRight
        Me._imText3_0.DisabledForeColor = System.Drawing.SystemColors.MenuText
        Me._imText3_0.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Bold)
        Me._imText3_0.Location = New System.Drawing.Point(142, 44)
        Me._imText3_0.Name = "_imText3_0"
        Me._imText3_0.Size = New System.Drawing.Size(143, 23)
        Me._imText3_0.TabIndex = 15
        Me._imText3_0.TabStop = False
        '
        '_imText3_1
        '
        Me._imText3_1.BackColor = System.Drawing.SystemColors.Control
        Me._imText3_1.ContentAlignment = System.Drawing.ContentAlignment.MiddleRight
        Me._imText3_1.DisabledForeColor = System.Drawing.SystemColors.MenuText
        Me._imText3_1.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Bold)
        Me._imText3_1.Location = New System.Drawing.Point(142, 70)
        Me._imText3_1.Name = "_imText3_1"
        Me._imText3_1.Size = New System.Drawing.Size(143, 23)
        Me._imText3_1.TabIndex = 16
        Me._imText3_1.TabStop = False
        '
        'imNumber1
        '
        Me.imNumber1.AlternateText.DisplayZero.ForeColor = System.Drawing.SystemColors.WindowText
        Me.imNumber1.AlternateText.Zero.ForeColor = System.Drawing.SystemColors.WindowText
        Me.imNumber1.DisabledBackColor = System.Drawing.SystemColors.Window
        Me.imNumber1.DisabledForeColor = System.Drawing.SystemColors.MenuText
        Me.imNumber1.Fields.DecimalPart.MaxDigits = 0
        Me.imNumber1.Fields.IntegerPart.GroupSizes = New Integer() {3, 3, 3, 0}
        Me.imNumber1.Fields.IntegerPart.MaxDigits = 10
        Me.imNumber1.Fields.IntegerPart.MinDigits = 1
        Me.imNumber1.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Bold)
        Me.imNumber1.ImeMode = System.Windows.Forms.ImeMode.Disable
        Me.imNumber1.Location = New System.Drawing.Point(142, 96)
        Me.imNumber1.MaxValue = New Decimal(New Integer() {1410065407, 2, 0, 0})
        Me.imNumber1.MinValue = New Decimal(New Integer() {1410065407, 2, 0, -2147483648})
        Me.imNumber1.Name = "imNumber1"
        Me.imNumber1.Size = New System.Drawing.Size(143, 23)
        Me.imNumber1.TabIndex = 0
        Me.imNumber1.Tag = "���㏊�v�������z����͂��ĉ������B"
        '
        'imNumber2
        '
        Me.imNumber2.AlternateText.Zero.ForeColor = System.Drawing.SystemColors.WindowText
        Me.imNumber2.DisabledBackColor = System.Drawing.SystemColors.Window
        Me.imNumber2.DisabledForeColor = System.Drawing.SystemColors.WindowText
        Me.imNumber2.Fields.DecimalPart.MaxDigits = 0
        Me.imNumber2.Fields.IntegerPart.GroupSizes = New Integer() {3, 3, 3, 0}
        Me.imNumber2.Fields.IntegerPart.MaxDigits = 11
        Me.imNumber2.Fields.IntegerPart.MinDigits = 1
        Me.imNumber2.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Bold)
        Me.imNumber2.ImeMode = System.Windows.Forms.ImeMode.Disable
        Me.imNumber2.Location = New System.Drawing.Point(142, 122)
        Me.imNumber2.MaxValue = New Decimal(New Integer() {1215752191, 23, 0, 0})
        Me.imNumber2.MinValue = New Decimal(New Integer() {1215752191, 23, 0, -2147483648})
        Me.imNumber2.Name = "imNumber2"
        Me.imNumber2.Size = New System.Drawing.Size(143, 23)
        Me.imNumber2.TabIndex = 1
        Me.imNumber2.Tag = "���{�������z����͂��ĉ������B"
        '
        'imNumber3
        '
        Me.imNumber3.AlternateText.Zero.ForeColor = System.Drawing.SystemColors.WindowText
        Me.imNumber3.DisabledBackColor = System.Drawing.SystemColors.Window
        Me.imNumber3.DisabledForeColor = System.Drawing.SystemColors.MenuText
        Me.imNumber3.Fields.DecimalPart.MaxDigits = 0
        Me.imNumber3.Fields.IntegerPart.GroupSizes = New Integer() {3, 3, 3, 0}
        Me.imNumber3.Fields.IntegerPart.MaxDigits = 10
        Me.imNumber3.Fields.IntegerPart.MinDigits = 1
        Me.imNumber3.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Bold)
        Me.imNumber3.ImeMode = System.Windows.Forms.ImeMode.Disable
        Me.imNumber3.Location = New System.Drawing.Point(142, 148)
        Me.imNumber3.MaxValue = New Decimal(New Integer() {1410065407, 2, 0, 0})
        Me.imNumber3.MinValue = New Decimal(New Integer() {1410065407, 2, 0, -2147483648})
        Me.imNumber3.Name = "imNumber3"
        Me.imNumber3.Size = New System.Drawing.Size(143, 23)
        Me.imNumber3.TabIndex = 2
        Me.imNumber3.Tag = "�\�Z�Δ���z����͂��ĉ������B"
        '
        'imNumber4
        '
        Me.imNumber4.AlternateText.Zero.ForeColor = System.Drawing.SystemColors.WindowText
        Me.imNumber4.DisabledBackColor = System.Drawing.SystemColors.Window
        Me.imNumber4.DisabledForeColor = System.Drawing.SystemColors.MenuText
        Me.imNumber4.Fields.DecimalPart.MaxDigits = 0
        Me.imNumber4.Fields.IntegerPart.GroupSizes = New Integer() {3, 3, 3, 0}
        Me.imNumber4.Fields.IntegerPart.MaxDigits = 11
        Me.imNumber4.Fields.IntegerPart.MinDigits = 1
        Me.imNumber4.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Bold)
        Me.imNumber4.ImeMode = System.Windows.Forms.ImeMode.Disable
        Me.imNumber4.Location = New System.Drawing.Point(142, 174)
        Me.imNumber4.MaxValue = New Decimal(New Integer() {1215752191, 23, 0, 0})
        Me.imNumber4.MinValue = New Decimal(New Integer() {1215752191, 23, 0, -2147483648})
        Me.imNumber4.Name = "imNumber4"
        Me.imNumber4.Size = New System.Drawing.Size(143, 23)
        Me.imNumber4.TabIndex = 3
        Me.imNumber4.Tag = "�ύX�������z����͂��ĉ������B"
        '
        '_imText1_2
        '
        Me._imText1_2.Location = New System.Drawing.Point(456, 170)
        Me._imText1_2.Name = "_imText1_2"
        Me._imText1_2.Size = New System.Drawing.Size(83, 23)
        Me._imText1_2.TabIndex = 14
        Me._imText1_2.Visible = False
        '
        'imNumber5
        '
        Me.imNumber5.AlternateText.DisplayZero.ForeColor = System.Drawing.SystemColors.WindowText
        Me.imNumber5.AlternateText.DisplayZero.Text = "0"
        Me.imNumber5.BackColor = System.Drawing.SystemColors.Control
        Me.imNumber5.ContentAlignment = System.Drawing.ContentAlignment.MiddleRight
        Me.imNumber5.DisabledForeColor = System.Drawing.SystemColors.MenuText
        Me.imNumber5.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Bold)
        Me.imNumber5.Location = New System.Drawing.Point(316, 44)
        Me.imNumber5.MaxValue = New Decimal(New Integer() {1215752191, 23, 0, 0})
        Me.imNumber5.MinValue = New Decimal(New Integer() {1215752191, 23, 0, -2147483648})
        Me.imNumber5.Name = "imNumber5"
        Me.imNumber5.Size = New System.Drawing.Size(143, 23)
        Me.imNumber5.TabIndex = 6
        Me.imNumber5.TabStop = False
        '
        '_Label1_16
        '
        Me._Label1_16.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_16.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_16.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_16.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_16.ForeColor = System.Drawing.Color.White
        Me._Label1_16.Location = New System.Drawing.Point(316, 18)
        Me._Label1_16.Name = "_Label1_16"
        Me._Label1_16.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_16.Size = New System.Drawing.Size(143, 23)
        Me._Label1_16.TabIndex = 39
        Me._Label1_16.Text = "�O�񖘎x�����z"
        Me._Label1_16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_14
        '
        Me._Label1_14.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_14.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_14.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_14.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_14.ForeColor = System.Drawing.Color.White
        Me._Label1_14.Location = New System.Drawing.Point(12, 18)
        Me._Label1_14.Name = "_Label1_14"
        Me._Label1_14.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_14.Size = New System.Drawing.Size(127, 23)
        Me._Label1_14.TabIndex = 38
        Me._Label1_14.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        '_Label1_15
        '
        Me._Label1_15.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_15.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_15.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_15.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_15.ForeColor = System.Drawing.Color.White
        Me._Label1_15.Location = New System.Drawing.Point(142, 18)
        Me._Label1_15.Name = "_Label1_15"
        Me._Label1_15.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_15.Size = New System.Drawing.Size(143, 23)
        Me._Label1_15.TabIndex = 36
        Me._Label1_15.Text = "���@�z"
        Me._Label1_15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_13
        '
        Me._Label1_13.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_13.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_13.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_13.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_13.ForeColor = System.Drawing.Color.White
        Me._Label1_13.Location = New System.Drawing.Point(12, 174)
        Me._Label1_13.Name = "_Label1_13"
        Me._Label1_13.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_13.Size = New System.Drawing.Size(126, 23)
        Me._Label1_13.TabIndex = 35
        Me._Label1_13.Text = "�ύX����"
        Me._Label1_13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_12
        '
        Me._Label1_12.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_12.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_12.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_12.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_12.ForeColor = System.Drawing.Color.White
        Me._Label1_12.Location = New System.Drawing.Point(12, 148)
        Me._Label1_12.Name = "_Label1_12"
        Me._Label1_12.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_12.Size = New System.Drawing.Size(126, 23)
        Me._Label1_12.TabIndex = 34
        Me._Label1_12.Text = "�\�Z�Δ�"
        Me._Label1_12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_11
        '
        Me._Label1_11.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_11.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_11.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_11.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_11.ForeColor = System.Drawing.Color.White
        Me._Label1_11.Location = New System.Drawing.Point(12, 122)
        Me._Label1_11.Name = "_Label1_11"
        Me._Label1_11.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_11.Size = New System.Drawing.Size(126, 23)
        Me._Label1_11.TabIndex = 33
        Me._Label1_11.Text = "���{����"
        Me._Label1_11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_10
        '
        Me._Label1_10.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_10.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_10.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_10.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_10.ForeColor = System.Drawing.Color.White
        Me._Label1_10.Location = New System.Drawing.Point(12, 96)
        Me._Label1_10.Name = "_Label1_10"
        Me._Label1_10.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_10.Size = New System.Drawing.Size(126, 23)
        Me._Label1_10.TabIndex = 32
        Me._Label1_10.Text = "���㏊�v����"
        Me._Label1_10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_9
        '
        Me._Label1_9.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_9.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_9.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_9.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_9.ForeColor = System.Drawing.Color.White
        Me._Label1_9.Location = New System.Drawing.Point(12, 70)
        Me._Label1_9.Name = "_Label1_9"
        Me._Label1_9.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_9.Size = New System.Drawing.Size(126, 23)
        Me._Label1_9.TabIndex = 31
        Me._Label1_9.Text = "�݁@��"
        Me._Label1_9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_8
        '
        Me._Label1_8.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_8.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_8.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_8.ForeColor = System.Drawing.Color.White
        Me._Label1_8.Location = New System.Drawing.Point(12, 44)
        Me._Label1_8.Name = "_Label1_8"
        Me._Label1_8.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_8.Size = New System.Drawing.Size(126, 23)
        Me._Label1_8.TabIndex = 30
        Me._Label1_8.Text = "�x�@��"
        Me._Label1_8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Frame1_0
        '
        Me._Frame1_0.BackColor = System.Drawing.SystemColors.Control
        Me._Frame1_0.Controls.Add(Me._imText1_1)
        Me._Frame1_0.Controls.Add(Me._imText1_0)
        Me._Frame1_0.Controls.Add(Me._imText1_3)
        Me._Frame1_0.Controls.Add(Me._Label1_0)
        Me._Frame1_0.Controls.Add(Me._Label1_1)
        Me._Frame1_0.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Frame1_0.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Frame1_0.Location = New System.Drawing.Point(6, 32)
        Me._Frame1_0.Name = "_Frame1_0"
        Me._Frame1_0.Padding = New System.Windows.Forms.Padding(0)
        Me._Frame1_0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Frame1_0.Size = New System.Drawing.Size(551, 81)
        Me._Frame1_0.TabIndex = 26
        Me._Frame1_0.TabStop = False
        '
        '_imText1_1
        '
        Me._imText1_1.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me._imText1_1.DisabledBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me._imText1_1.DisabledForeColor = System.Drawing.SystemColors.MenuText
        Me._imText1_1.Enabled = False
        Me._imText1_1.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Bold)
        Me._imText1_1.Location = New System.Drawing.Point(191, 18)
        Me._imText1_1.Name = "_imText1_1"
        Me._imText1_1.Size = New System.Drawing.Size(323, 23)
        Me._imText1_1.TabIndex = 8
        '
        '_imText1_0
        '
        Me._imText1_0.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me._imText1_0.ContentAlignment = System.Drawing.ContentAlignment.MiddleCenter
        Me._imText1_0.DisabledBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me._imText1_0.DisabledForeColor = System.Drawing.SystemColors.MenuText
        Me._imText1_0.Enabled = False
        Me._imText1_0.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._imText1_0.Location = New System.Drawing.Point(142, 18)
        Me._imText1_0.Name = "_imText1_0"
        Me._imText1_0.Size = New System.Drawing.Size(45, 23)
        Me._imText1_0.TabIndex = 7
        Me._imText1_0.TabStop = False
        '
        '_imText1_3
        '
        Me._imText1_3.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me._imText1_3.DisabledBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me._imText1_3.DisabledForeColor = System.Drawing.SystemColors.MenuText
        Me._imText1_3.Enabled = False
        Me._imText1_3.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Bold)
        Me._imText1_3.Location = New System.Drawing.Point(142, 48)
        Me._imText1_3.Name = "_imText1_3"
        Me._imText1_3.Size = New System.Drawing.Size(373, 23)
        Me._imText1_3.TabIndex = 9
        '
        '_Label1_0
        '
        Me._Label1_0.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_0.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_0.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_0.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_0.ForeColor = System.Drawing.Color.White
        Me._Label1_0.Location = New System.Drawing.Point(12, 18)
        Me._Label1_0.Name = "_Label1_0"
        Me._Label1_0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_0.Size = New System.Drawing.Size(126, 23)
        Me._Label1_0.TabIndex = 28
        Me._Label1_0.Text = "�H�@��"
        Me._Label1_0.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_1
        '
        Me._Label1_1.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_1.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_1.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_1.ForeColor = System.Drawing.Color.White
        Me._Label1_1.Location = New System.Drawing.Point(12, 48)
        Me._Label1_1.Name = "_Label1_1"
        Me._Label1_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_1.Size = New System.Drawing.Size(126, 23)
        Me._Label1_1.TabIndex = 27
        Me._Label1_1.Text = "���@��"
        Me._Label1_1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Frame1_1
        '
        Me._Frame1_1.BackColor = System.Drawing.SystemColors.Control
        Me._Frame1_1.Controls.Add(Me._imText2_0)
        Me._Frame1_1.Controls.Add(Me._imText2_2)
        Me._Frame1_1.Controls.Add(Me._imText2_3)
        Me._Frame1_1.Controls.Add(Me._imText2_1)
        Me._Frame1_1.Controls.Add(Me._Label1_7)
        Me._Frame1_1.Controls.Add(Me._Label1_3)
        Me._Frame1_1.Controls.Add(Me._Label1_4)
        Me._Frame1_1.Controls.Add(Me._Label1_5)
        Me._Frame1_1.Controls.Add(Me._Label1_6)
        Me._Frame1_1.Controls.Add(Me._Label1_2)
        Me._Frame1_1.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Frame1_1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me._Frame1_1.Location = New System.Drawing.Point(6, 114)
        Me._Frame1_1.Name = "_Frame1_1"
        Me._Frame1_1.Padding = New System.Windows.Forms.Padding(0)
        Me._Frame1_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Frame1_1.Size = New System.Drawing.Size(551, 77)
        Me._Frame1_1.TabIndex = 20
        Me._Frame1_1.TabStop = False
        '
        '_imText2_0
        '
        Me._imText2_0.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me._imText2_0.ContentAlignment = System.Drawing.ContentAlignment.MiddleRight
        Me._imText2_0.DisabledForeColor = System.Drawing.SystemColors.MenuText
        Me._imText2_0.Enabled = False
        Me._imText2_0.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Bold)
        Me._imText2_0.Location = New System.Drawing.Point(142, 44)
        Me._imText2_0.Name = "_imText2_0"
        Me._imText2_0.Size = New System.Drawing.Size(93, 23)
        Me._imText2_0.TabIndex = 10
        '
        '_imText2_2
        '
        Me._imText2_2.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me._imText2_2.ContentAlignment = System.Drawing.ContentAlignment.MiddleRight
        Me._imText2_2.DisabledForeColor = System.Drawing.SystemColors.MenuText
        Me._imText2_2.Enabled = False
        Me._imText2_2.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Bold)
        Me._imText2_2.Location = New System.Drawing.Point(288, 44)
        Me._imText2_2.Name = "_imText2_2"
        Me._imText2_2.Size = New System.Drawing.Size(111, 23)
        Me._imText2_2.TabIndex = 12
        '
        '_imText2_3
        '
        Me._imText2_3.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me._imText2_3.ContentAlignment = System.Drawing.ContentAlignment.MiddleRight
        Me._imText2_3.DisabledForeColor = System.Drawing.SystemColors.MenuText
        Me._imText2_3.Enabled = False
        Me._imText2_3.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Bold)
        Me._imText2_3.Location = New System.Drawing.Point(402, 44)
        Me._imText2_3.Name = "_imText2_3"
        Me._imText2_3.Size = New System.Drawing.Size(137, 23)
        Me._imText2_3.TabIndex = 13
        '
        '_imText2_1
        '
        Me._imText2_1.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me._imText2_1.ContentAlignment = System.Drawing.ContentAlignment.MiddleCenter
        Me._imText2_1.DisabledForeColor = System.Drawing.SystemColors.MenuText
        Me._imText2_1.Enabled = False
        Me._imText2_1.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Bold)
        Me._imText2_1.Location = New System.Drawing.Point(238, 44)
        Me._imText2_1.Name = "_imText2_1"
        Me._imText2_1.Size = New System.Drawing.Size(47, 23)
        Me._imText2_1.TabIndex = 11
        '
        '_Label1_7
        '
        Me._Label1_7.AutoSize = True
        Me._Label1_7.BackColor = System.Drawing.Color.Teal
        Me._Label1_7.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_7.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_7.ForeColor = System.Drawing.Color.White
        Me._Label1_7.Location = New System.Drawing.Point(50, 34)
        Me._Label1_7.Name = "_Label1_7"
        Me._Label1_7.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_7.Size = New System.Drawing.Size(59, 16)
        Me._Label1_7.TabIndex = 37
        Me._Label1_7.Text = "�_�@��"
        Me._Label1_7.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        '_Label1_3
        '
        Me._Label1_3.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_3.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_3.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_3.ForeColor = System.Drawing.Color.White
        Me._Label1_3.Location = New System.Drawing.Point(142, 18)
        Me._Label1_3.Name = "_Label1_3"
        Me._Label1_3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_3.Size = New System.Drawing.Size(93, 23)
        Me._Label1_3.TabIndex = 25
        Me._Label1_3.Text = "�� ��"
        Me._Label1_3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_4
        '
        Me._Label1_4.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_4.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_4.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_4.ForeColor = System.Drawing.Color.White
        Me._Label1_4.Location = New System.Drawing.Point(238, 18)
        Me._Label1_4.Name = "_Label1_4"
        Me._Label1_4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_4.Size = New System.Drawing.Size(47, 23)
        Me._Label1_4.TabIndex = 24
        Me._Label1_4.Text = "�P��"
        Me._Label1_4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_5
        '
        Me._Label1_5.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_5.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_5.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_5.ForeColor = System.Drawing.Color.White
        Me._Label1_5.Location = New System.Drawing.Point(288, 18)
        Me._Label1_5.Name = "_Label1_5"
        Me._Label1_5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_5.Size = New System.Drawing.Size(111, 23)
        Me._Label1_5.TabIndex = 23
        Me._Label1_5.Text = "�P�@��"
        Me._Label1_5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_6
        '
        Me._Label1_6.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_6.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_6.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_6.ForeColor = System.Drawing.Color.White
        Me._Label1_6.Location = New System.Drawing.Point(402, 18)
        Me._Label1_6.Name = "_Label1_6"
        Me._Label1_6.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_6.Size = New System.Drawing.Size(137, 23)
        Me._Label1_6.TabIndex = 22
        Me._Label1_6.Text = "���@�z"
        Me._Label1_6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_2
        '
        Me._Label1_2.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_2.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_2.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_2.ForeColor = System.Drawing.Color.White
        Me._Label1_2.Location = New System.Drawing.Point(12, 18)
        Me._Label1_2.Name = "_Label1_2"
        Me._Label1_2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_2.Size = New System.Drawing.Size(126, 49)
        Me._Label1_2.TabIndex = 21
        Me._Label1_2.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Picture1
        '
        Me.Picture1.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Picture1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Picture1.Controls.Add(Me._cmdKey_12)
        Me.Picture1.Controls.Add(Me._cmdKey_1)
        Me.Picture1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Picture1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Picture1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Picture1.Location = New System.Drawing.Point(0, 408)
        Me.Picture1.Name = "Picture1"
        Me.Picture1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Picture1.Size = New System.Drawing.Size(565, 51)
        Me.Picture1.TabIndex = 30
        '
        '_cmdKey_12
        '
        Me._cmdKey_12.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_12.CausesValidation = False
        Me._cmdKey_12.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_12.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_12.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_12.Location = New System.Drawing.Point(478, 4)
        Me._cmdKey_12.Name = "_cmdKey_12"
        Me._cmdKey_12.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_12.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_12.TabIndex = 5
        Me._cmdKey_12.Tag = "�I�����܂��B"
        Me._cmdKey_12.Text = "F12" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "�I ��"
        Me._cmdKey_12.UseVisualStyleBackColor = False
        '
        '_cmdKey_1
        '
        Me._cmdKey_1.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_1.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_1.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_1.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_1.Location = New System.Drawing.Point(6, 4)
        Me._cmdKey_1.Name = "_cmdKey_1"
        Me._cmdKey_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_1.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_1.TabIndex = 4
        Me._cmdKey_1.Tag = "���̓f�[�^��o�^���܂��B"
        Me._cmdKey_1.Text = "F1" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "�o �^"
        Me._cmdKey_1.UseVisualStyleBackColor = False
        '
        'StatusBar1
        '
        Me.StatusBar1.Font = New System.Drawing.Font("MS Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.StatusBar1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me._StatusBar1_Panel2, Me.Message})
        Me.StatusBar1.Location = New System.Drawing.Point(0, 459)
        Me.StatusBar1.Name = "StatusBar1"
        Me.StatusBar1.Size = New System.Drawing.Size(565, 23)
        Me.StatusBar1.SizingGrip = False
        Me.StatusBar1.TabIndex = 17
        '
        '_StatusBar1_Panel2
        '
        Me._StatusBar1_Panel2.AutoSize = False
        Me._StatusBar1_Panel2.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me._StatusBar1_Panel2.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter
        Me._StatusBar1_Panel2.Margin = New System.Windows.Forms.Padding(0)
        Me._StatusBar1_Panel2.Name = "_StatusBar1_Panel2"
        Me._StatusBar1_Panel2.Size = New System.Drawing.Size(117, 23)
        '
        'Message
        '
        Me.Message.AutoSize = False
        Me.Message.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me.Message.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter
        Me.Message.Margin = New System.Windows.Forms.Padding(0)
        Me.Message.Name = "Message"
        Me.Message.Size = New System.Drawing.Size(440, 23)
        Me.Message.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblTitle
        '
        Me.lblTitle.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.lblTitle.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTitle.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblTitle.Font = New System.Drawing.Font("MS Mincho", 20.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblTitle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.lblTitle.Location = New System.Drawing.Point(0, 0)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblTitle.Size = New System.Drawing.Size(565, 31)
        Me.lblTitle.TabIndex = 19
        Me.lblTitle.Text = " �C��"
        '
        'frmSYKD100
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(565, 482)
        Me.Controls.Add(Me._Frame1_2)
        Me.Controls.Add(Me._Frame1_0)
        Me.Controls.Add(Me._Frame1_1)
        Me.Controls.Add(Me.Picture1)
        Me.Controls.Add(Me.StatusBar1)
        Me.Controls.Add(Me.lblTitle)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.KeyPreview = True
        Me.Location = New System.Drawing.Point(167, 129)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmSYKD100"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "�H���Ǘ��V�X�e��"
        Me._Frame1_2.ResumeLayout(False)
        CType(Me._imText3_0, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._imText3_1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.imNumber1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.imNumber2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.imNumber3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.imNumber4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._imText1_2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.imNumber5, System.ComponentModel.ISupportInitialize).EndInit()
        Me._Frame1_0.ResumeLayout(False)
        CType(Me._imText1_1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._imText1_0, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._imText1_3, System.ComponentModel.ISupportInitialize).EndInit()
        Me._Frame1_1.ResumeLayout(False)
        Me._Frame1_1.PerformLayout()
        CType(Me._imText2_0, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._imText2_2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._imText2_3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._imText2_1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Picture1.ResumeLayout(False)
        Me.StatusBar1.ResumeLayout(False)
        Me.StatusBar1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
#End Region
End Class