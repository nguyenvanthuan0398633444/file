Imports GrapeCity.Win.Editors

<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frmSYKD040
#Region "Windows Form Designer generated code "
    <System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
        MyBase.New()
        InitializeComponent()
        'This call is required by the Windows Form Designer.
        Me.Frame1 = New ArrayList
        Me.Label1 = New ArrayList
        Me.Option1 = New ArrayList
        Me.Option2 = New ArrayList
        Me.Picture2 = New ArrayList
        Me.cmdKey = New ArrayList
        Me.cmdLook = New ArrayList
        Me.imText1 = New ArrayList
        Me.imText2 = New ArrayList
        Me.Frame1.Add(_Frame1_0)
        Me.Frame1.Add(_Frame1_1)
        Me.Frame1.Add(_Frame1_2)

        Me.Label1.Add(_Label1_0)
        Me.Label1.Add(_Label1_1)
        Me.Label1.Add(_Label1_2)
        Me.Label1.Add(_Label1_3)
        Me.Label1.Add(_Label1_4)
        Me.Label1.Add(_Label1_5)

        Me.Option1.Add(Nothing)
        Me.Option1.Add(_Option1_1)
        Me.Option1.Add(_Option1_2)

        Me.Option2.Add(Nothing)
        Me.Option2.Add(_Option2_1)
        Me.Option2.Add(_Option2_2)
        Me.Option2.Add(_Option2_3)

        Me.Picture2.Add(_Picture2_0)
        Me.Picture2.Add(_Picture2_1)

        Me.cmdKey.Add(Nothing)
        Me.cmdKey.Add(_cmdKey_1)
        Me.cmdKey.Add(Nothing)
        Me.cmdKey.Add(Nothing)
        Me.cmdKey.Add(Nothing)
        Me.cmdKey.Add(Nothing)
        Me.cmdKey.Add(Nothing)
        Me.cmdKey.Add(Nothing)
        Me.cmdKey.Add(Nothing)
        Me.cmdKey.Add(Nothing)
        Me.cmdKey.Add(Nothing)
        Me.cmdKey.Add(Nothing)
        Me.cmdKey.Add(_cmdKey_12)

        Me.imText1.Add(_imText1_0)
        Me.imText1.Add(_imText1_1)
        Me.imText1.Add(_imText1_2)

        Me.cmdLook.Add(Nothing)
        Me.cmdLook.Add(Nothing)
        Me.cmdLook.Add(_cmdLook_2)

        Me.imText2.Add(Nothing)
        Me.imText2.Add(Nothing)
        Me.imText2.Add(_imText2_2)
    End Sub
    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
        If Disposing Then
            If Not components Is Nothing Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(Disposing)
    End Sub
    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer
    Public ToolTip1 As System.Windows.Forms.ToolTip
    Public WithEvents _cmdLook_2 As System.Windows.Forms.Button
    Public WithEvents _imText2_2 As GcTextBox
    Public WithEvents _imText1_2 As GcTextBox
    Public WithEvents imNumber1 As GcNumber
    Public WithEvents _Label1_5 As System.Windows.Forms.Label
    Public WithEvents _Label1_4 As System.Windows.Forms.Label
    Public WithEvents _Frame1_2 As System.Windows.Forms.GroupBox
    Public WithEvents _Option2_3 As System.Windows.Forms.RadioButton
    Public WithEvents _Option2_1 As System.Windows.Forms.RadioButton
    Public WithEvents _Option2_2 As System.Windows.Forms.RadioButton
    Public WithEvents _Picture2_1 As System.Windows.Forms.Panel
    Public WithEvents _Label1_3 As System.Windows.Forms.Label
    Public WithEvents _Frame1_1 As System.Windows.Forms.GroupBox
    Public WithEvents _Option1_2 As System.Windows.Forms.RadioButton
    Public WithEvents _Option1_1 As System.Windows.Forms.RadioButton
    Public WithEvents _Picture2_0 As System.Windows.Forms.Panel
    Public WithEvents _imText1_0 As GcTextBox
    Public WithEvents _imText1_1 As GcTextBox
    Public WithEvents _Label1_1 As System.Windows.Forms.Label
    Public WithEvents _Label1_0 As System.Windows.Forms.Label
    Public WithEvents _Label1_2 As System.Windows.Forms.Label
    Public WithEvents _Frame1_0 As System.Windows.Forms.GroupBox
    Public WithEvents _cmdKey_12 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_1 As System.Windows.Forms.Button
    Public WithEvents Picture1 As System.Windows.Forms.Panel
    Public WithEvents _StatusBar1_Panel2 As System.Windows.Forms.ToolStripStatusLabel
    Public WithEvents Message As System.Windows.Forms.ToolStripStatusLabel
    Public WithEvents StatusBar1 As System.Windows.Forms.StatusStrip
    Public WithEvents lblTitle As System.Windows.Forms.Label
    Public WithEvents Frame1 As ArrayList
    Public WithEvents Label1 As ArrayList
    Public WithEvents Option1 As ArrayList
    Public WithEvents Option2 As ArrayList
    Public WithEvents Picture2 As ArrayList
    Public WithEvents cmdKey As ArrayList
    Public WithEvents cmdLook As ArrayList
    Public WithEvents imText1 As ArrayList
    Public WithEvents imText2 As ArrayList
    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmSYKD040))
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me._Frame1_2 = New System.Windows.Forms.GroupBox()
        Me._cmdLook_2 = New System.Windows.Forms.Button()
        Me._imText2_2 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._imText1_2 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me.imNumber1 = New GrapeCity.Win.Editors.GcNumber(Me.components)
        Me._Label1_5 = New System.Windows.Forms.Label()
        Me._Label1_4 = New System.Windows.Forms.Label()
        Me._Frame1_1 = New System.Windows.Forms.GroupBox()
        Me._Picture2_1 = New System.Windows.Forms.Panel()
        Me._Option2_3 = New System.Windows.Forms.RadioButton()
        Me._Option2_1 = New System.Windows.Forms.RadioButton()
        Me._Option2_2 = New System.Windows.Forms.RadioButton()
        Me._Label1_3 = New System.Windows.Forms.Label()
        Me._Frame1_0 = New System.Windows.Forms.GroupBox()
        Me._Picture2_0 = New System.Windows.Forms.Panel()
        Me._Option1_2 = New System.Windows.Forms.RadioButton()
        Me._Option1_1 = New System.Windows.Forms.RadioButton()
        Me._imText1_0 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._imText1_1 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._Label1_1 = New System.Windows.Forms.Label()
        Me._Label1_0 = New System.Windows.Forms.Label()
        Me._Label1_2 = New System.Windows.Forms.Label()
        Me.Picture1 = New System.Windows.Forms.Panel()
        Me._cmdKey_12 = New System.Windows.Forms.Button()
        Me._cmdKey_1 = New System.Windows.Forms.Button()
        Me.StatusBar1 = New System.Windows.Forms.StatusStrip()
        Me._StatusBar1_Panel2 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.Message = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me._Frame1_2.SuspendLayout()
        CType(Me._imText2_2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imText1_2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.imNumber1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me._Frame1_1.SuspendLayout()
        Me._Picture2_1.SuspendLayout()
        Me._Frame1_0.SuspendLayout()
        Me._Picture2_0.SuspendLayout()
        CType(Me._imText1_0, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imText1_1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Picture1.SuspendLayout()
        Me.StatusBar1.SuspendLayout()
        Me.SuspendLayout()
        '
        '_Frame1_2
        '
        Me._Frame1_2.BackColor = System.Drawing.SystemColors.Control
        Me._Frame1_2.Controls.Add(Me._cmdLook_2)
        Me._Frame1_2.Controls.Add(Me._imText2_2)
        Me._Frame1_2.Controls.Add(Me._imText1_2)
        Me._Frame1_2.Controls.Add(Me.imNumber1)
        Me._Frame1_2.Controls.Add(Me._Label1_5)
        Me._Frame1_2.Controls.Add(Me._Label1_4)
        Me._Frame1_2.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Frame1_2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me._Frame1_2.Location = New System.Drawing.Point(6, 222)
        Me._Frame1_2.Name = "_Frame1_2"
        Me._Frame1_2.Padding = New System.Windows.Forms.Padding(0)
        Me._Frame1_2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Frame1_2.Size = New System.Drawing.Size(593, 87)
        Me._Frame1_2.TabIndex = 22
        Me._Frame1_2.TabStop = False
        Me._Frame1_2.Text = " �O �� "
        '
        '_cmdLook_2
        '
        Me._cmdLook_2.BackColor = System.Drawing.SystemColors.Control
        Me._cmdLook_2.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdLook_2.Font = New System.Drawing.Font("MS PGothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdLook_2.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdLook_2.Image = CType(resources.GetObject("_cmdLook_2.Image"), System.Drawing.Image)
        Me._cmdLook_2.Location = New System.Drawing.Point(216, 22)
        Me._cmdLook_2.Name = "_cmdLook_2"
        Me._cmdLook_2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdLook_2.Size = New System.Drawing.Size(25, 23)
        Me._cmdLook_2.TabIndex = 23
        Me._cmdLook_2.TabStop = False
        Me._cmdLook_2.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me._cmdLook_2.UseVisualStyleBackColor = False
        '
        '_imText2_2
        '
        Me._imText2_2.BackColor = System.Drawing.SystemColors.Control
        Me._imText2_2.DisabledForeColor = System.Drawing.SystemColors.MenuText
        Me._imText2_2.ImeMode = System.Windows.Forms.ImeMode.Off
        Me._imText2_2.Location = New System.Drawing.Point(242, 22)
        Me._imText2_2.Name = "_imText2_2"
        Me._imText2_2.Size = New System.Drawing.Size(335, 23)
        Me._imText2_2.TabIndex = 24
        '
        '_imText1_2
        '
        Me._imText1_2.DisabledForeColor = System.Drawing.SystemColors.MenuText
        Me._imText1_2.Format = "9"
        Me._imText1_2.HighlightText = True
        Me._imText1_2.ImeMode = System.Windows.Forms.ImeMode.Disable
        Me._imText1_2.Location = New System.Drawing.Point(132, 22)
        Me._imText1_2.MaxLength = 8
        Me._imText1_2.Name = "_imText1_2"
        Me._imText1_2.Size = New System.Drawing.Size(83, 23)
        Me._imText1_2.TabIndex = 6
        Me._imText1_2.Tag = "�Ǝк��ނ���͂��ĉ������B�@����߰����F������"
        '
        'imNumber1
        '
        Me.imNumber1.DisabledForeColor = System.Drawing.SystemColors.MenuText
        Me.imNumber1.Fields.DecimalPart.MaxDigits = 0
        Me.imNumber1.Fields.IntegerPart.GroupSizes = New Integer() {3, 3, 3, 0}
        Me.imNumber1.Fields.IntegerPart.MaxDigits = 10
        Me.imNumber1.Fields.IntegerPart.MinDigits = 1
        Me.imNumber1.HighlightText = True
        Me.imNumber1.ImeMode = System.Windows.Forms.ImeMode.Disable
        Me.imNumber1.Location = New System.Drawing.Point(132, 50)
        Me.imNumber1.MaxValue = New Decimal(New Integer() {1410065407, 2, 0, 0})
        Me.imNumber1.MinValue = New Decimal(New Integer() {1410065407, 2, 0, -2147483648})
        Me.imNumber1.Name = "imNumber1"
        Me.imNumber1.Size = New System.Drawing.Size(129, 23)
        Me.imNumber1.TabIndex = 7
        Me.imNumber1.Tag = "�_����z����͂��ĉ������B"
        '
        '_Label1_5
        '
        Me._Label1_5.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_5.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_5.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_5.ForeColor = System.Drawing.Color.White
        Me._Label1_5.Location = New System.Drawing.Point(14, 50)
        Me._Label1_5.Name = "_Label1_5"
        Me._Label1_5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_5.Size = New System.Drawing.Size(114, 23)
        Me._Label1_5.TabIndex = 26
        Me._Label1_5.Text = "�_����z"
        Me._Label1_5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_4
        '
        Me._Label1_4.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_4.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_4.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_4.ForeColor = System.Drawing.Color.White
        Me._Label1_4.Location = New System.Drawing.Point(14, 22)
        Me._Label1_4.Name = "_Label1_4"
        Me._Label1_4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_4.Size = New System.Drawing.Size(114, 23)
        Me._Label1_4.TabIndex = 25
        Me._Label1_4.Text = "�Ɓ@��"
        Me._Label1_4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Frame1_1
        '
        Me._Frame1_1.BackColor = System.Drawing.SystemColors.Control
        Me._Frame1_1.Controls.Add(Me._Picture2_1)
        Me._Frame1_1.Controls.Add(Me._Label1_3)
        Me._Frame1_1.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Frame1_1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me._Frame1_1.Location = New System.Drawing.Point(6, 158)
        Me._Frame1_1.Name = "_Frame1_1"
        Me._Frame1_1.Padding = New System.Windows.Forms.Padding(0)
        Me._Frame1_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Frame1_1.Size = New System.Drawing.Size(593, 59)
        Me._Frame1_1.TabIndex = 19
        Me._Frame1_1.TabStop = False
        Me._Frame1_1.Text = " �� �c "
        '
        '_Picture2_1
        '
        Me._Picture2_1.BackColor = System.Drawing.SystemColors.Control
        Me._Picture2_1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Picture2_1.Controls.Add(Me._Option2_3)
        Me._Picture2_1.Controls.Add(Me._Option2_1)
        Me._Picture2_1.Controls.Add(Me._Option2_2)
        Me._Picture2_1.Cursor = System.Windows.Forms.Cursors.Default
        Me._Picture2_1.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Picture2_1.Location = New System.Drawing.Point(132, 22)
        Me._Picture2_1.Name = "_Picture2_1"
        Me._Picture2_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Picture2_1.Size = New System.Drawing.Size(253, 23)
        Me._Picture2_1.TabIndex = 20
        '
        '_Option2_3
        '
        Me._Option2_3.BackColor = System.Drawing.SystemColors.Control
        Me._Option2_3.Cursor = System.Windows.Forms.Cursors.Default
        Me._Option2_3.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Option2_3.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Option2_3.Location = New System.Drawing.Point(170, 0)
        Me._Option2_3.Name = "_Option2_3"
        Me._Option2_3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Option2_3.Size = New System.Drawing.Size(77, 23)
        Me._Option2_3.TabIndex = 5
        Me._Option2_3.TabStop = True
        Me._Option2_3.Tag = "��p�敪��I�����ĉ������B"
        Me._Option2_3.Text = "�O����"
        Me._Option2_3.UseVisualStyleBackColor = False
        '
        '_Option2_1
        '
        Me._Option2_1.BackColor = System.Drawing.SystemColors.Control
        Me._Option2_1.Cursor = System.Windows.Forms.Cursors.Default
        Me._Option2_1.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Option2_1.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Option2_1.Location = New System.Drawing.Point(6, 0)
        Me._Option2_1.Name = "_Option2_1"
        Me._Option2_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Option2_1.Size = New System.Drawing.Size(77, 23)
        Me._Option2_1.TabIndex = 3
        Me._Option2_1.TabStop = True
        Me._Option2_1.Tag = "��p�敪��I�����ĉ������B"
        Me._Option2_1.Text = "�ޗ���"
        Me._Option2_1.UseVisualStyleBackColor = False
        '
        '_Option2_2
        '
        Me._Option2_2.BackColor = System.Drawing.SystemColors.Control
        Me._Option2_2.Cursor = System.Windows.Forms.Cursors.Default
        Me._Option2_2.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Option2_2.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Option2_2.Location = New System.Drawing.Point(88, 0)
        Me._Option2_2.Name = "_Option2_2"
        Me._Option2_2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Option2_2.Size = New System.Drawing.Size(77, 23)
        Me._Option2_2.TabIndex = 4
        Me._Option2_2.TabStop = True
        Me._Option2_2.Tag = "��p�敪��I�����ĉ������B"
        Me._Option2_2.Text = "�J����"
        Me._Option2_2.UseVisualStyleBackColor = False
        '
        '_Label1_3
        '
        Me._Label1_3.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_3.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_3.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_3.ForeColor = System.Drawing.Color.White
        Me._Label1_3.Location = New System.Drawing.Point(14, 22)
        Me._Label1_3.Name = "_Label1_3"
        Me._Label1_3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_3.Size = New System.Drawing.Size(114, 23)
        Me._Label1_3.TabIndex = 21
        Me._Label1_3.Text = "��p�敪"
        Me._Label1_3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Frame1_0
        '
        Me._Frame1_0.BackColor = System.Drawing.SystemColors.Control
        Me._Frame1_0.Controls.Add(Me._Picture2_0)
        Me._Frame1_0.Controls.Add(Me._imText1_0)
        Me._Frame1_0.Controls.Add(Me._imText1_1)
        Me._Frame1_0.Controls.Add(Me._Label1_1)
        Me._Frame1_0.Controls.Add(Me._Label1_0)
        Me._Frame1_0.Controls.Add(Me._Label1_2)
        Me._Frame1_0.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Frame1_0.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Frame1_0.Location = New System.Drawing.Point(6, 34)
        Me._Frame1_0.Name = "_Frame1_0"
        Me._Frame1_0.Padding = New System.Windows.Forms.Padding(0)
        Me._Frame1_0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Frame1_0.Size = New System.Drawing.Size(593, 119)
        Me._Frame1_0.TabIndex = 13
        Me._Frame1_0.TabStop = False
        '
        '_Picture2_0
        '
        Me._Picture2_0.BackColor = System.Drawing.SystemColors.Control
        Me._Picture2_0.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Picture2_0.Controls.Add(Me._Option1_2)
        Me._Picture2_0.Controls.Add(Me._Option1_1)
        Me._Picture2_0.Cursor = System.Windows.Forms.Cursors.Default
        Me._Picture2_0.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Picture2_0.Location = New System.Drawing.Point(132, 82)
        Me._Picture2_0.Name = "_Picture2_0"
        Me._Picture2_0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Picture2_0.Size = New System.Drawing.Size(139, 23)
        Me._Picture2_0.TabIndex = 14
        '
        '_Option1_2
        '
        Me._Option1_2.BackColor = System.Drawing.SystemColors.Control
        Me._Option1_2.Cursor = System.Windows.Forms.Cursors.Default
        Me._Option1_2.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Option1_2.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Option1_2.Location = New System.Drawing.Point(72, 0)
        Me._Option1_2.Name = "_Option1_2"
        Me._Option1_2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Option1_2.Size = New System.Drawing.Size(67, 23)
        Me._Option1_2.TabIndex = 2
        Me._Option1_2.TabStop = True
        Me._Option1_2.Tag = "���c�敪��I�����ĉ������B"
        Me._Option1_2.Text = "�O��"
        Me._Option1_2.UseVisualStyleBackColor = False
        '
        '_Option1_1
        '
        Me._Option1_1.BackColor = System.Drawing.SystemColors.Control
        Me._Option1_1.Cursor = System.Windows.Forms.Cursors.Default
        Me._Option1_1.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Option1_1.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Option1_1.Location = New System.Drawing.Point(6, 0)
        Me._Option1_1.Name = "_Option1_1"
        Me._Option1_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Option1_1.Size = New System.Drawing.Size(67, 23)
        Me._Option1_1.TabIndex = 1
        Me._Option1_1.TabStop = True
        Me._Option1_1.Tag = "���c�敪��I�����ĉ������B"
        Me._Option1_1.Text = "���c"
        Me._Option1_1.UseVisualStyleBackColor = False
        '
        '_imText1_0
        '
        Me._imText1_0.BackColor = System.Drawing.SystemColors.Control
        Me._imText1_0.ContentAlignment = System.Drawing.ContentAlignment.MiddleCenter
        Me._imText1_0.ImeMode = System.Windows.Forms.ImeMode.Disable
        Me._imText1_0.Location = New System.Drawing.Point(132, 22)
        Me._imText1_0.Name = "_imText1_0"
        Me._imText1_0.ReadOnly = True
        Me._imText1_0.Size = New System.Drawing.Size(29, 23)
        Me._imText1_0.TabIndex = 15
        Me._imText1_0.TabStop = False
        '
        '_imText1_1
        '
        Me._imText1_1.HighlightText = True
        Me._imText1_1.ImeMode = System.Windows.Forms.ImeMode.[On]
        Me._imText1_1.Location = New System.Drawing.Point(132, 48)
        Me._imText1_1.MaxLength = 40
        Me._imText1_1.MaxLengthUnit = GrapeCity.Win.Editors.LengthUnit.[Byte]
        Me._imText1_1.Name = "_imText1_1"
        Me._imText1_1.Size = New System.Drawing.Size(371, 23)
        Me._imText1_1.TabIndex = 0
        Me._imText1_1.Tag = "���̂���͂��ĉ������B"
        '
        '_Label1_1
        '
        Me._Label1_1.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_1.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_1.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_1.ForeColor = System.Drawing.Color.White
        Me._Label1_1.Location = New System.Drawing.Point(14, 48)
        Me._Label1_1.Name = "_Label1_1"
        Me._Label1_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_1.Size = New System.Drawing.Size(114, 23)
        Me._Label1_1.TabIndex = 18
        Me._Label1_1.Text = "���@��"
        Me._Label1_1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_0
        '
        Me._Label1_0.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_0.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_0.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_0.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_0.ForeColor = System.Drawing.Color.White
        Me._Label1_0.Location = New System.Drawing.Point(14, 22)
        Me._Label1_0.Name = "_Label1_0"
        Me._Label1_0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_0.Size = New System.Drawing.Size(114, 23)
        Me._Label1_0.TabIndex = 17
        Me._Label1_0.Text = "���o�ԍ�"
        Me._Label1_0.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_2
        '
        Me._Label1_2.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_2.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_2.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_2.ForeColor = System.Drawing.Color.White
        Me._Label1_2.Location = New System.Drawing.Point(14, 82)
        Me._Label1_2.Name = "_Label1_2"
        Me._Label1_2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_2.Size = New System.Drawing.Size(114, 23)
        Me._Label1_2.TabIndex = 16
        Me._Label1_2.Text = "���c�敪"
        Me._Label1_2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Picture1
        '
        Me.Picture1.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Picture1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Picture1.Controls.Add(Me._cmdKey_12)
        Me.Picture1.Controls.Add(Me._cmdKey_1)
        Me.Picture1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Picture1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Picture1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Picture1.Location = New System.Drawing.Point(0, 320)
        Me.Picture1.Name = "Picture1"
        Me.Picture1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Picture1.Size = New System.Drawing.Size(607, 51)
        Me.Picture1.TabIndex = 23
        '
        '_cmdKey_12
        '
        Me._cmdKey_12.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_12.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_12.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_12.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_12.Location = New System.Drawing.Point(521, 4)
        Me._cmdKey_12.Name = "_cmdKey_12"
        Me._cmdKey_12.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_12.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_12.TabIndex = 9
        Me._cmdKey_12.Tag = "�I�����܂��B"
        Me._cmdKey_12.Text = "F12" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "�I ��"
        Me._cmdKey_12.UseVisualStyleBackColor = False
        '
        '_cmdKey_1
        '
        Me._cmdKey_1.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_1.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_1.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_1.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_1.Location = New System.Drawing.Point(6, 4)
        Me._cmdKey_1.Name = "_cmdKey_1"
        Me._cmdKey_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_1.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_1.TabIndex = 8
        Me._cmdKey_1.Tag = "���̓f�[�^��o�^���܂��B"
        Me._cmdKey_1.Text = "F1" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "�o �^"
        Me._cmdKey_1.UseVisualStyleBackColor = False
        '
        'StatusBar1
        '
        Me.StatusBar1.Font = New System.Drawing.Font("MS Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.StatusBar1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me._StatusBar1_Panel2, Me.Message})
        Me.StatusBar1.Location = New System.Drawing.Point(0, 371)
        Me.StatusBar1.Name = "StatusBar1"
        Me.StatusBar1.Size = New System.Drawing.Size(607, 23)
        Me.StatusBar1.SizingGrip = False
        Me.StatusBar1.TabIndex = 10
        '
        '_StatusBar1_Panel2
        '
        Me._StatusBar1_Panel2.AutoSize = False
        Me._StatusBar1_Panel2.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me._StatusBar1_Panel2.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter
        Me._StatusBar1_Panel2.Margin = New System.Windows.Forms.Padding(0)
        Me._StatusBar1_Panel2.Name = "_StatusBar1_Panel2"
        Me._StatusBar1_Panel2.Size = New System.Drawing.Size(117, 23)
        '
        'Message
        '
        Me.Message.AutoSize = False
        Me.Message.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me.Message.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter
        Me.Message.Margin = New System.Windows.Forms.Padding(0)
        Me.Message.Name = "Message"
        Me.Message.Size = New System.Drawing.Size(482, 23)
        Me.Message.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblTitle
        '
        Me.lblTitle.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblTitle.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTitle.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblTitle.Font = New System.Drawing.Font("MS Mincho", 20.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblTitle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.lblTitle.Location = New System.Drawing.Point(0, 0)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblTitle.Size = New System.Drawing.Size(607, 31)
        Me.lblTitle.TabIndex = 12
        Me.lblTitle.Text = " ���o������"
        '
        'frmSYKD040
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(607, 394)
        Me.Controls.Add(Me._Frame1_2)
        Me.Controls.Add(Me._Frame1_1)
        Me.Controls.Add(Me._Frame1_0)
        Me.Controls.Add(Me.Picture1)
        Me.Controls.Add(Me.StatusBar1)
        Me.Controls.Add(Me.lblTitle)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.KeyPreview = True
        Me.Location = New System.Drawing.Point(184, 160)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmSYKD040"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "�H���Ǘ��V�X�e��"
        Me._Frame1_2.ResumeLayout(False)
        CType(Me._imText2_2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._imText1_2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.imNumber1, System.ComponentModel.ISupportInitialize).EndInit()
        Me._Frame1_1.ResumeLayout(False)
        Me._Picture2_1.ResumeLayout(False)
        Me._Frame1_0.ResumeLayout(False)
        Me._Picture2_0.ResumeLayout(False)
        CType(Me._imText1_0, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._imText1_1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Picture1.ResumeLayout(False)
        Me.StatusBar1.ResumeLayout(False)
        Me.StatusBar1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
#End Region
End Class