Option Strict Off
Option Explicit On
Imports System.Drawing.Printing
Imports C1.Win.C1Document
Imports C1.Win.FlexReport

Module prnSYKD076
    '=============================================================
    ' ���[�U�[���@  �F  �R�z�H�Ɗ������
    ' �V�X�e�����@  �F  �H���Ǘ��V�X�e��
    ' ���W���[����  �F  �x���ꗗ�i�䗦�v�Z�j���
    ' ���W���[��ID�@�F  prnSYKD076.bas
    ' �쐬���@ �@�@ �F  ���� 15 �N 04 �� 24 ��
    ' �X�V���@�@  �@�F
    '=============================================================
    '

    ' �x���f�[�^�\����
    Private Structure SIHARAI_LIST_QRY
        '2021.08.03 UPGRADE S  AIT)Tool Convert
        '<VBFixedString(8),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=8)> Public GYOUSYA_CD() As Char ' �Ǝк���
        '<VBFixedString(1),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=1)> Public MEISAI_KB() As Char ' ���׋敪�i9:�O���j
        '<VBFixedString(2),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=2)> Public CHUUMON_NO() As Char ' �����ԍ�
        '<VBFixedString(40),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=40)> Public MEISYOU() As Char ' �i���^��������
        <VBFixedStringAttribute(8)> Public GYOUSYA_CD As String  ' �Ǝк���
        <VBFixedStringAttribute(1)> Public MEISAI_KB As String   ' ���׋敪�i9:�O���j
        <VBFixedStringAttribute(2)> Public CHUUMON_NO As String  ' �����ԍ�
        <VBFixedStringAttribute(40)> Public MEISYOU As String    ' �i���^��������
        '2021.08.03 UPGRADE E
        Dim KINGAKU As Decimal ' �x�����z
        Dim HIRITU_FUR As Single ' �x���䗦�i�U���j
        Dim HIRITU_GEN As Single ' �x���䗦�i�����j
        Dim HIRITU_TEG As Single ' �x���䗦�i��`�j
        Dim FUR_KIN As Decimal ' �U�����z
        Dim GEN_KIN As Decimal ' �������z
        Dim TEG_KIN As Decimal ' ��`���z
    End Structure

    Private P_Cnt As Short ' ����y�[�W�J�E���g
    Private XX() As Single ' ����w�ʒu
    Private YY() As Single ' ����x�ʒu
    '

    '-------------------------------------------------------------------------------
    '   ����   :   �x����ʎx�����̎擾
    '   �֐�   :   Function SelectSiharai()
    '   ����   :   DT()�@   SIHARAI_LIST_QRY
    '   �ߒl   :   �ް���   ����I��
    '   �@�@       -1�@     �ُ�I��
    '   �@�\   :   �x����ʂ̎x�������擾���܂��B
    '-------------------------------------------------------------------------------
    Private Function SelectSiharai(ByRef DT() As SIHARAI_LIST_QRY) As Integer

        Dim QRY1 As String
        Dim QRY2 As String
        Dim SQL As String
        '2021.08.12 UPGRADE S  AIT)hieutv
        'Dim Rs As ADODB.Recordset
        'Dim Fld As ADODB.Field
        Dim Rs As New DataTable
        Dim Fld As DataColumn
        '2021.08.12 UPGRADE E
        Dim Cnt As Integer
        Dim OpenFlg As Short

        '2021.08.03 UPGRADE S  AIT)Tool Convert
        'On Error GoTo SelectSiharai_Err
        Try
            '2021.08.03 UPGRADE E

            ' �߂�l�̏�����
            SelectSiharai = -1

            ' QRY/SELECT���g��
            QRY1 = "(SELECT"
            QRY1 = QRY1 & " GYOUSYA_CD,"
            QRY1 = QRY1 & " MEISAI_KB,"
            QRY1 = QRY1 & " '00'  AS CHUUMON_NO,"
            QRY1 = QRY1 & " BIKOU AS MEISYOU,"
            QRY1 = QRY1 & " KINGAKU,"
            QRY1 = QRY1 & " HIRITU_FURI,"
            QRY1 = QRY1 & " HIRITU_GEN,"
            QRY1 = QRY1 & " HIRITU_TE"
            QRY1 = QRY1 & " FROM IPPAN_DATA"
            QRY1 = QRY1 & " WHERE KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"
            QRY1 = QRY1 & " AND EDA_NO = '" & KeyKouji.EDA_NO & "'"
            QRY1 = QRY1 & " AND SIME_YM = '" & CtlKouji.SYORI_YM & "'"
            QRY1 = QRY1 & " AND NYUURYOKU_FLG = '01'"
            QRY1 = QRY1 & " AND S_FLG_GENKA = '1'"
            QRY1 = QRY1 & " AND NOT(MEISAI_KB = '2' AND SUURYOU <> (H_SUURYOU + H_ZAIKO))"
            QRY1 = QRY1 & ") AS IPPANDT"

            ' QRY/SELECT���g��
            QRY2 = "(SELECT"
            QRY2 = QRY2 & " GAI_KIHON_DATA.GYOUSYA_CD,"
            QRY2 = QRY2 & " '9' AS MEISAI_KB,"
            QRY2 = QRY2 & " GAI_KIHON_DATA.CHUUMON_NO,"
            QRY2 = QRY2 & " WARIDASI_MAST.MEISYOU,"
            QRY2 = QRY2 & " GAI_KIHON_DATA.KON_SI_GAKU AS KINGAKU,"
            QRY2 = QRY2 & " GAI_KIHON_DATA.HIRITU_FURI,"
            QRY2 = QRY2 & " GAI_KIHON_DATA.HIRITU_GEN,"
            QRY2 = QRY2 & " GAI_KIHON_DATA.HIRITU_TE"
            QRY2 = QRY2 & " FROM GAI_KIHON_DATA INNER JOIN WARIDASI_MAST"
            QRY2 = QRY2 & " ON  GAI_KIHON_DATA.CHUUMON_NO = WARIDASI_MAST.WARIDASI_NO"
            QRY2 = QRY2 & " AND GAI_KIHON_DATA.EDA_NO     = WARIDASI_MAST.EDA_NO"
            QRY2 = QRY2 & " AND GAI_KIHON_DATA.KOUJI_NO   = WARIDASI_MAST.KOUJI_NO"
            QRY2 = QRY2 & " WHERE GAI_KIHON_DATA.KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"
            QRY2 = QRY2 & " AND GAI_KIHON_DATA.EDA_NO = '" & KeyKouji.EDA_NO & "'"
            QRY2 = QRY2 & " AND SIME_YM = '" & CtlKouji.SYORI_YM & "'"
            QRY2 = QRY2 & " AND (KON_SI_GAKU + ZEI_GAKU) <> 0"
            QRY2 = QRY2 & ") AS GAICHUU"

            ' SQL/SELECT���g��
            SQL = "SELECT * FROM " & QRY1 & " UNION ALL SELECT * FROM " & QRY2
            SQL = SQL & " ORDER BY GYOUSYA_CD, MEISAI_KB, CHUUMON_NO"

            ' SQL�����s
            '2021.08.12 UPGRADE S  AIT)hieutv
            'Rs = SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText)
            Rs = RsOpen(SQL)
            '2021.08.12 UPGRADE E
            OpenFlg = 1

            Cnt = 0
            '2021.08.12 UPGRADE S  AIT)hieutv
            'Do Until Rs.EOF
            For Each Row As DataRow In Rs.Rows
                '2021.08.12 UPGRADE E
                ReDim Preserve DT(Cnt)
                With DT(Cnt)
                    '----- ������
                    .GYOUSYA_CD = "" ' �Ǝк���
                    .MEISAI_KB = "" ' ���׋敪
                    .CHUUMON_NO = "" ' �����ԍ�
                    .MEISYOU = "" ' �i���^��������
                    .KINGAKU = 0 ' �x�����z
                    .HIRITU_FUR = 0 ' �x���䗦�i�U���j
                    .HIRITU_GEN = 0 ' �x���䗦�i�����j
                    .HIRITU_TEG = 0 ' �x���䗦�i��`�j
                    .FUR_KIN = 0 ' �U�����z
                    .GEN_KIN = 0 ' �������z
                    .TEG_KIN = 0 ' ��`���z
                    '----- �\���̂�
                    '2021.08.12 UPGRADE S  AIT)hieutv
                    'For	Each Fld In Rs.Fields
                    '	If IsDbNull(Fld.Name) = False And IsDbNull(Fld.Value) = False Then
                    '		Select Case UCase(Fld.Name)
                    '			Case "GYOUSYA_CD" : .GYOUSYA_CD = Fld.Value ' �Ǝк���
                    '			Case "MEISAI_KB" : .MEISAI_KB = Fld.Value ' ���׋敪
                    '			Case "CHUUMON_NO" : .CHUUMON_NO = Fld.Value ' �����ԍ�
                    '			Case "MEISYOU" : .MEISYOU = Fld.Value ' �i���^��������
                    '			Case "KINGAKU" : .KINGAKU = Fld.Value ' �x�����z
                    '			Case "HIRITU_FURI" : .HIRITU_FUR = Fld.Value ' �x���䗦�i�U���j
                    '			Case "HIRITU_GEN" : .HIRITU_GEN = Fld.Value ' �x���䗦�i�����j
                    '			Case "HIRITU_TE" : .HIRITU_TEG = Fld.Value ' �x���䗦�i��`�j
                    '		End Select
                    '	End If
                    'Next Fld
                    For Each Fld In Row.Table.Columns
                        If IsDBNull(Fld.ColumnName) = False And IsDBNull(Row(Fld.ColumnName)) = False Then
                            Select Case UCase(Fld.ColumnName)
                                Case "GYOUSYA_CD" : .GYOUSYA_CD = Row(Fld.ColumnName) ' �Ǝк���
                                Case "MEISAI_KB" : .MEISAI_KB = Row(Fld.ColumnName) ' ���׋敪
                                Case "CHUUMON_NO" : .CHUUMON_NO = Row(Fld.ColumnName) ' �����ԍ�
                                Case "MEISYOU" : .MEISYOU = Row(Fld.ColumnName) ' �i���^��������
                                Case "KINGAKU" : .KINGAKU = Row(Fld.ColumnName) ' �x�����z
                                Case "HIRITU_FURI" : .HIRITU_FUR = Row(Fld.ColumnName) ' �x���䗦�i�U���j
                                Case "HIRITU_GEN" : .HIRITU_GEN = Row(Fld.ColumnName) ' �x���䗦�i�����j
                                Case "HIRITU_TE" : .HIRITU_TEG = Row(Fld.ColumnName) ' �x���䗦�i��`�j
                            End Select
                        End If
                    Next Fld
                    '2021.08.12 UPGRADE E
                    '----- �䗦�v�Z
                    '2021.08.03 UPGRADE S  AIT)Tool Convert
                    '.FUR_KIN = CCur2(VB6.Format(.KINGAKU * (.HIRITU_FUR / 100), "0")) ' �U�����z
                    '.GEN_KIN = CCur2(VB6.Format(.KINGAKU * (.HIRITU_GEN / 100), "0")) ' �������z
                    '.TEG_KIN = CCur2(VB6.Format(.KINGAKU * (.HIRITU_TEG / 100), "0")) ' ��`���z
                    .FUR_KIN = CCur2(CDec(.KINGAKU * (.HIRITU_FUR / 100)).ToString("0")) ' �U�����z
                    .GEN_KIN = CCur2(CDec(.KINGAKU * (.HIRITU_GEN / 100)).ToString("0")) ' �������z
                    .TEG_KIN = CCur2(CDec(.KINGAKU * (.HIRITU_TEG / 100)).ToString("0")) ' ��`���z
                    '2021.08.03 UPGRADE E
                    If 0 <> (.FUR_KIN + .GEN_KIN + .TEG_KIN) Then
                        If .KINGAKU <> (.FUR_KIN + .GEN_KIN + .TEG_KIN) Then
                            If .FUR_KIN > 0 Then
                                .FUR_KIN = .KINGAKU - (.GEN_KIN + .TEG_KIN)
                            ElseIf .GEN_KIN > 0 Then
                                .GEN_KIN = .KINGAKU - (.FUR_KIN + .TEG_KIN)
                            Else
                                .TEG_KIN = .KINGAKU - (.FUR_KIN + .GEN_KIN)
                            End If
                        End If
                    End If
                End With
                Cnt = Cnt + 1
                '2021.08.12 UPGRADE S  AIT)hieutv
                '	Rs.MoveNext()
                'Loop

                'Rs.Close()
            Next

            Rs.Dispose()
            '2021.08.12 UPGRADE E
            Rs = Nothing

            ' �߂�l�̃Z�b�g
            SelectSiharai = Cnt
            Exit Function

            '2021.08.03 UPGRADE S  AIT)Tool Convert
            'SelectSiharai_Err:
        Catch ex As Exception
            '2021.08.03 UPGRADE E

            If OpenFlg = 1 Then
                '2021.08.12 UPGRADE S  AIT)hieutv
                'Rs.Close()
                Rs.Dispose()
                '2021.08.12 UPGRADE E
            End If
            Rs = Nothing

            '2021.08.12 UPGRADE S  AIT)hieutv
            'Call Sql_Error_Msg("SelectSiharai")
            Call Sql_Error_Msg(ex, "SelectSiharai")
            '2021.08.12 UPGRADE E

        End Try     '2021.08.03 UPGRADE ADD AIT)Tool Convert
    End Function

    '-------------------------------------------------------------------------------
    '   ����    :   �x���ꗗ�i�䗦�v�Z�j���
    '   �֐�    :   Function PrnMainD076()
    '   ����    :   ����
    '   �ߒl    :   True    ����I��
    '   �@�@        False   ���f
    '-------------------------------------------------------------------------------
    Public Function PrnMainD076() As Object

        Dim lp As Integer
        Dim Cnt As Integer
        Dim DT() As SIHARAI_LIST_QRY
        Dim pryy As Single
        Dim CmpKey As String
        Dim R_Cnt As Integer
        Dim L_Length As Single
        Dim KinKei() As Decimal
        Dim SouKei() As Decimal
        Dim SouKeiG() As Decimal
        Dim SouKeiI() As Decimal

        Cnt = 0

        ' �f�[�^�̓ǂݍ���(��ʃ}�X�^)
        Cnt = SelectSiharai(DT)
        If Cnt <= 0 Then
            Exit Function
        End If

        ' �v�����^�[�f�o�C�X�̓ǂݍ���
        Call INI_PRN_Read(1)

        ' �����ݒ�
        If PrnFirstD076() = False Then
            Exit Function
        End If

        ' ����ʒu�̎擾
        Call PrXYGetD076()

        ' ������
        P_Cnt = 1 : pryy = YY(0)
        CmpKey = DT(0).GYOUSYA_CD

        ' ���o����(�y�[�W���o��)
        Call PrItemPD076(pryy)
        '----- ���s
        pryy = pryy + ((P_YY * 1.5) * 5)
        ' ���o����(���ڌ��o��)
        Call PrItemD076(pryy, DT(0))

        If PrnCancel = 1 Then
            '----- ���f
            Call PRN_ErrEnd()
            Exit Function
        End If

        ReDim KinKei(3)
        ReDim SouKei(3)
        ReDim SouKeiG(3)
        ReDim SouKeiI(3)
        For lp = 0 To Cnt - 1
            ' �ƎЂ��Ⴄ�ꍇ
            If CmpKey <> DT(lp).GYOUSYA_CD Then
                '/// ���v���
                Call PrGokeiD076(pryy, KinKei, SouKeiG, SouKeiI)
                ReDim KinKei(3)
                ' ���y�[�W�`�F�b�N
                '----- ���R�[�h�����̎擾
                R_Cnt = PrRcntD076(DT(lp).GYOUSYA_CD)
                '----- �󎚕��̎擾(�f�[�^�s(R_Cnt) + ���o���s(2) + ���v�s(1))
                L_Length = P_YY * (R_Cnt + 2 + 1) * 1.5 + P_YY * 5
                If NewPage_CHK(pryy, L_Length) = False Then
                    '----- ���y�[�W
                    Call PRN_NewPage()
                    '----- �y�[�W���̍X�V
                    P_Cnt = P_Cnt + 1
                    '----- �󎚈ʒu�̃��Z�b�g
                    pryy = YY(0)
                    ' ���o����(�y�[�W���o��)
                    Call PrItemPD076(pryy)
                    '----- ���s
                    pryy = pryy + ((P_YY * 1.5) * 5)
                    ' ���o����(���ڌ��o��)
                    Call PrItemD076(pryy, DT(lp))
                    If PrnCancel = 1 Then
                        '----- ���f
                        Call PRN_ErrEnd()
                        Exit Function
                    End If
                Else
                    ' ���o����(���ڌ��o��)
                    Call PrItemD076(pryy, DT(lp))
                End If
                ' �Đݒ�
                CmpKey = DT(lp).GYOUSYA_CD
            End If
            ' ���y�[�W�`�F�b�N
            If NewPage_CHK(pryy, P_YY * 5) = False Then
                '----- ���y�[�W
                Call PRN_NewPage()
                '----- �y�[�W���̍X�V
                P_Cnt = P_Cnt + 1
                '----- �󎚈ʒu�̃��Z�b�g
                pryy = YY(0)
                ' ���o����(�y�[�W���o��)
                Call PrItemPD076(pryy)
                '----- ���s
                pryy = pryy + ((P_YY * 1.5) * 5)
                ' ���o����(���ڌ��o��)
                Call PrItemD076(pryy, DT(lp))
                If PrnCancel = 1 Then
                    '----- ���f
                    Call PRN_ErrEnd()
                    Exit Function
                End If
            End If
            ' �f�[�^��
            Call PrDataD076(pryy, DT(lp))
            KinKei(0) = KinKei(0) + DT(lp).KINGAKU
            KinKei(1) = KinKei(1) + DT(lp).FUR_KIN
            KinKei(2) = KinKei(2) + DT(lp).GEN_KIN
            KinKei(3) = KinKei(3) + DT(lp).TEG_KIN
            SouKei(0) = SouKei(0) + DT(lp).KINGAKU
            SouKei(1) = SouKei(1) + DT(lp).FUR_KIN
            SouKei(2) = SouKei(2) + DT(lp).GEN_KIN
            SouKei(3) = SouKei(3) + DT(lp).TEG_KIN
            If DT(lp).MEISAI_KB = "9" Then
                '�O��
                SouKeiG(0) = SouKeiG(0) + DT(lp).KINGAKU
                SouKeiG(1) = SouKeiG(1) + DT(lp).FUR_KIN
                SouKeiG(2) = SouKeiG(2) + DT(lp).GEN_KIN
                SouKeiG(3) = SouKeiG(3) + DT(lp).TEG_KIN
            Else
                '���
                SouKeiI(0) = SouKeiI(0) + DT(lp).KINGAKU
                SouKeiI(1) = SouKeiI(1) + DT(lp).FUR_KIN
                SouKeiI(2) = SouKeiI(2) + DT(lp).GEN_KIN
                SouKeiI(3) = SouKeiI(3) + DT(lp).TEG_KIN
            End If
            If PrnCancel = 1 Then
                '----- ���f
                Call PRN_ErrEnd()
                Exit Function
            End If
            '----- ���s
            pryy = pryy + (P_YY * 1.5)
            '----- ����
            '2021.08.19 UPGRADE S  AIT)hieutv
            'Call PRN_LINE(XX(0), pryy, XX(UBound(XX)), pryy, 1, "", VSDraw7Lib.PenStyleSettings.psDot)
            Call PRN_LINE(XX(0), pryy, XX(UBound(XX)), pryy, 1, "", DashStyle.Dot)
            '2021.08.19 UPGRADE E
        Next lp
        '/// ���v���
        Call PrGokeiD076(pryy, KinKei, SouKeiG, SouKeiI)
        '----- ����
        Call PRN_LINE(XX(0), pryy, XX(UBound(XX)), pryy, 20, "")
        '/// �����v���
        Call PrGokeiD076(pryy, SouKei, SouKeiG, SouKeiI, 1)

        ' ����I��
        Call PRN_END()

        ' �v���r���[�\��
        If ViewFlg = True Then
            frmSYKD075.StatusBar1.Items.Item("Message").Text = ""
            ViewForm.ShowDialog()
        End If

        ' ����I��
        PrnMainD076 = True

    End Function

    '-------------------------------------------------------------------------------
    '   ����    :   �����ݒ�
    '   �֐�    :   Sub     PrnFirstD076()
    '   ����    :   ����
    '   �ߒl    :   True    ����I��
    '   �@�@        False   �Y���Ȃ�
    '-------------------------------------------------------------------------------
    Private Function PrnFirstD076() As Boolean

        ' �߂�l�̏�����
        PrnFirstD076 = False

        ' �^�C�g���ݒ�
        DocName = "�x���ꗗ�i�䗦�v�Z�j"

        ' �v�����^�[�f�o�C�X�̐ݒ�
        If Printer_Set(PRN1) = False Then
            '2021.09.14 UPGRADE S  AIT)dannnl
            'MsgBox("�ݒ�ɖ����v�����^�[�f�o�C�X���w�肳��܂����B")
            MsgBox("�ݒ�ɖ����v�����^�[�f�o�C�X���w�肳��܂����B", MsgBoxStyle.ApplicationModal, SYSTEMNM)
            '2021.09.14 UPGRADE E
            Exit Function
        End If

        ' �p���ݒ�
        '2021.08.19 UPGRADE S  AIT)hieutv
        'P_SIZE = PrinterObjectConstants.vbPRPSA4 ' �`�S
        'P_ORIENT = VSPrinter7Lib.OrientationSettings.orPortrait ' ��:orLandscape,�c:orPortrait
        P_SIZE = PaperKind.A4 ' �`�S
        P_ORIENT = OrientationEnum.Portrait ' ��:orLandscape,�c:orPortrait
        '2021.08.19 UPGRADE E
        F_SIZE = 12

        ' ����ďo��ʂ̃Z�b�g
        CallForm = frmSYKD075

        ' ��������ݒ�
        If PRN_First(ViewForm) = False Then
            '2021.09.14 UPGRADE S  AIT)dannnl
            'MsgBox("�v�����^�̐ݒ�Ɏ��s���܂����B", MsgBoxStyle.Exclamation)
            MsgBox("�v�����^�̐ݒ�Ɏ��s���܂����B", MsgBoxStyle.Exclamation, SYSTEMNM)
            '2021.09.14 UPGRADE E
            Exit Function
        End If

        ' ����I��
        PrnFirstD076 = True

    End Function

    '-------------------------------------------------------------------------------
    '   ����    :   ����ʒu�ݒ菈��
    '   �֐�    :   Sub PrXYGetD076()
    '   ����    :   ����
    '   �ߒl    :   ����
    '-------------------------------------------------------------------------------
    Private Sub PrXYGetD076()

        Dim PrLen As Short
        Dim xMargn As Short

        ' ���ڐ��̐ݒ�
        ReDim XX(9)
        ReDim YY(1)

        ' �����񒷂̎Z�o(PrLen=92)
        PrLen = 0
        PrLen = PrLen + Len(Space(4)) ' �x���敪
        PrLen = PrLen + Len(Space(10)) ' �敪���e
        PrLen = PrLen + Len(Space(40)) ' �i���E�K�i
        PrLen = PrLen + Len(Space(10)) ' �x�����z
        PrLen = PrLen + Len(Space(10)) ' �U�����z
        PrLen = PrLen + Len(Space(10)) ' �������z
        PrLen = PrLen + Len(Space(10)) ' ��`���z

        ' �t�H���g�T�C�Y�̎Z�o
        xMargn = 9
        '2021.08.19 UPGRADE S  AIT)hieutv
        'F_SIZE = PRN_FontGet(P_XX * xMargn * 2, P_WIDTH, Basic_F, Space(PrLen))
        F_SIZE = PRN_FontGet(P_XX * xMargn * 2, P_WIDTH, Basic_F, New String(")", PrLen)) - 0.05
        PRN.Font.Size = F_SIZE
        '2021.08.19 UPGRADE E

        ' �P�������E�����̍Đݒ�
        '2021.08.19 UPGRADE S  AIT)hieutv
        'P_XX = PRN.TextWidth("M")
        'P_YY = PRN.TextHeight("M")
        P_XX = TextWidthToTwips("M")
        P_YY = TextHeightToTwips("M") + 1.6
        '2021.08.19 UPGRADE E

        ' ���ڈ󎚈ʒu�̐ݒ� Y��
        YY(0) = P_YY * 7 ' ���ڏ��
        YY(1) = YY(0) + P_YY * 1.5 ' ���ډ���

        ' ���ڈ󎚈ʒu�̐ݒ� X��
        XX(0) = P_XX * xMargn ' �r�����[
        XX(1) = XX(0) + P_XX * 1 ' �x���敪
        XX(2) = XX(1) + P_XX * (4 + 4) ' �敪���e
        XX(3) = XX(2) + P_XX * (10 + 4) ' �i���E�K�i
        XX(4) = XX(3) + P_XX * (40 + 4) ' �x�����z
        XX(5) = XX(4) + P_XX * (10 + 4) ' �U�����z
        XX(6) = XX(5) + P_XX * (10 + 4) ' �������z
        XX(7) = XX(6) + P_XX * (10 + 4) ' ��`���z
        XX(8) = XX(7) + P_XX * (10 + 4)
        XX(9) = P_WIDTH - P_XX * xMargn ' �r���E�[

    End Sub

    '-------------------------------------------------------------------------------
    '   ����    :   ���ڈ������(�y�[�W���o��)
    '   �֐�    :   Sub PrItemPD076()
    '   ����    :   pryy    �󎚂x�ʒu
    '   �@�@        DT()    IPPAN_DATA_DBT(��ʃ}�X�^)
    '   �ߒl    :   �Ȃ�
    '-------------------------------------------------------------------------------
    Private Sub PrItemPD076(ByRef pryy As Single)

        Dim PR_WK_Renamed As PR_WK
        Dim PR_Text As String
        Dim yMargn As Single
        Dim i As Short

        ' ���f
        If PrnCancel = 1 Then Exit Sub

        '----- �]��
        yMargn = P_YY * 0.25

        ' dummy
        PR_WK_Renamed.DT = ""
        PR_WK_Renamed.FS = F_SIZE
        PR_WK_Renamed.X = XX(0)
        PR_WK_Renamed.Y = YY(0)
        Call PRN_DATA(PR_WK_Renamed)

        '----- �w�b�_
        ' �^�C�g��
        PR_WK_Renamed.DT = "���� �x���ꗗ�i�䗦�v�Z�j ����"
        PR_WK_Renamed.FS = 12
        '2021.08.19 UPGRADE S  AIT)hieutv
		'PR_WK_Renamed.X = PRN_XGet(1, XX(1), XX(4), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(1, XX(1), XX(4), PR_WK_Renamed)
        '2021.08.19 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed, Nothing, Nothing, True)
        ' ����
        Call PRN_LINE(XX(5), pryy, XX(UBound(XX)), pryy, 20, "")
        Call PRN_LINE(XX(5), YY(1), XX(UBound(XX)), YY(1), 20, "")
        Call PRN_LINE(XX(5), pryy + ((P_YY * 1.5) * 4), XX(UBound(XX)), pryy + ((P_YY * 1.5) * 4), 20, "")

        For i = 0 To 5
            Call PRN_LINE(XX(5) + (((XX(UBound(XX)) - XX(5)) / 5) * i), pryy, XX(5) + (((XX(UBound(XX)) - XX(5)) / 5) * i), pryy + ((P_YY * 1.5) * 4), 20, "")
        Next i
        For i = 0 To 4
            Select Case i
                Case 0 : PR_WK_Renamed.DT = Trim(HIRITU01)
                Case 1 : PR_WK_Renamed.DT = Trim(HIRITU02)
                Case 2 : PR_WK_Renamed.DT = Trim(HIRITU03)
                Case 3 : PR_WK_Renamed.DT = Trim(HIRITU04)
                Case 4 : PR_WK_Renamed.DT = Trim(HIRITU05)
            End Select
            PR_WK_Renamed.FS = 7.25
            '2021.08.19 UPGRADE S  AIT)hieutv
			'PR_WK_Renamed.X = PRN_XGet(1, XX(5) + (((XX(UBound(XX)) - XX(5)) / 5) * i), XX(5) + (((XX(UBound(XX)) - XX(5)) / 5) * (i + 1)), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
            PRN_XGet(1, XX(5) + (((XX(UBound(XX)) - XX(5)) / 5) * i), XX(5) + (((XX(UBound(XX)) - XX(5)) / 5) * (i + 1)), PR_WK_Renamed)
            '2021.08.19 UPGRADE E
            PR_WK_Renamed.Y = YY(0) + yMargn
            Call PRN_DATA(PR_WK_Renamed)
        Next i

        ' ����y�[�W
        '2021.08.12 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.DT = VB6.Format(P_Cnt) & " ��"
        PR_WK_Renamed.DT = P_Cnt.ToString & " ��"
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.19 UPGRADE S  AIT)hieutv
		'PR_WK_Renamed.X = PRN_XGet(2, XX(0), XX(4), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(0), XX(4), PR_WK_Renamed)
        '2021.08.19 UPGRADE E
        PR_WK_Renamed.Y = pryy + (P_YY * 1.5) + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' �����
        '2021.08.03 UPGRADE S  AIT)Tool Convert
        'PR_WK_Renamed.DT = "������t�F" & VB6.Format(Today, "yyyy/mm/dd")
        PR_WK_Renamed.DT = "������t�F" & Today.ToString("yyyy/MM/dd")
        '2021.08.03 UPGRADE E
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.19 UPGRADE S  AIT)hieutv
		'PR_WK_Renamed.X = PRN_XGet(2, XX(0), XX(4), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(0), XX(4), PR_WK_Renamed)
        '2021.08.19 UPGRADE E
        PR_WK_Renamed.Y = pryy + ((P_YY * 1.5) * 2) + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' ����
        '2021.08.03 UPGRADE S  AIT)Tool Convert
        'PR_WK_Renamed.DT = "�����F" & VB6.Format(CtlKouji.SYORI_YM, "0000/00")
        PR_WK_Renamed.DT = "�����F" & CDec(CtlKouji.SYORI_YM).ToString("0000/00")
        '2021.08.03 UPGRADE E
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.19 UPGRADE S  AIT)hieutv
		'PR_WK_Renamed.X = PRN_XGet(0, XX(0), XX(4), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(0, XX(0), XX(4), PR_WK_Renamed)
        '2021.08.19 UPGRADE E
        PR_WK_Renamed.Y = pryy + ((P_YY * 1.5) * 2) + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' �H���ԍ��{�}�ԁ{�H������
        PR_Text = ""
        If KeyKouji.EDA_NO <> "0000" Then PR_Text = "- " & KeyKouji.EDA_NO & Space(1)
        PR_WK_Renamed.DT = "�H���ԍ��F" & KeyKouji.KOUJI_NO & Space(1) & PR_Text & "�H�����́F" & GetNameKouji(KeyKouji.KOUJI_NO, KeyKouji.EDA_NO)
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.19 UPGRADE S  AIT)hieutv
		'PR_WK_Renamed.X = PRN_XGet(0, XX(0), XX(4), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(0, XX(0), XX(4), PR_WK_Renamed)
        '2021.08.19 UPGRADE E
        PR_WK_Renamed.Y = pryy + ((P_YY * 1.5) * 3) + yMargn
        Call PRN_DATA(PR_WK_Renamed)

    End Sub

    '-------------------------------------------------------------------------------
    '   ����    :   ���ڈ������(���ڌ��o��)
    '   �֐�    :   Sub PrItemD076()
    '   ����    :   pryy    �󎚂x�ʒu
    '   �@�@        DT()    IPPAN_DATA_DBT(��ʃ}�X�^)
    '   �ߒl    :   �Ȃ�
    '-------------------------------------------------------------------------------
    Private Sub PrItemD076(ByRef pryy As Single, ByRef DT As SIHARAI_LIST_QRY)

        Dim PR_WK_Renamed As PR_WK
        Dim PR_Text As String
        Dim yMargn As Single

        ' ���f
        If PrnCancel = 1 Then Exit Sub

        '----- �]��
        yMargn = P_YY * 0.25

        '----- ����
        Call PRN_LINE(XX(0), pryy, XX(UBound(XX)), pryy, 40, "")

        ' �񍀖�
        '----- 1�s��
        ' �Ǝк���
        PR_WK_Renamed.DT = "�Ǝк���:" & DT.GYOUSYA_CD
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.19 UPGRADE S  AIT)hieutv
		'PR_WK_Renamed.X = PRN_XGet(0, XX(1), XX(2), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(0, XX(1), XX(3), PR_WK_Renamed)
        '2021.08.19 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' �ƎЖ���
        PR_WK_Renamed.DT = "�ƎЖ���:" & GetNameGyousya(DT.GYOUSYA_CD)
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.19 UPGRADE S  AIT)hieutv
		'PR_WK_Renamed.X = PRN_XGet(0, XX(3), XX(4), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(0, XX(3), XX(5), PR_WK_Renamed)
        '2021.08.19 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)

        '----- ���s
        pryy = pryy + (P_YY * 1.5)

        '----- 2�s��
        ' �敪
        PR_WK_Renamed.DT = "�敪"
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.19 UPGRADE S  AIT)hieutv
		'PR_WK_Renamed.X = PRN_XGet(0, XX(1) + P_XX * 4, XX(2), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(0, XX(1) + P_XX * 4, XX(3), PR_WK_Renamed)
        '2021.08.19 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' �i���E�K�i
        PR_WK_Renamed.DT = "�i���E�K�i"
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.19 UPGRADE S  AIT)hieutv
		'PR_WK_Renamed.X = PRN_XGet(0, XX(3), XX(4), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(0, XX(3), XX(4), PR_WK_Renamed)
        '2021.08.19 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' ���z
        PR_WK_Renamed.DT = "���z"
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.19 UPGRADE S  AIT)hieutv
		'PR_WK_Renamed.X = PRN_XGet(2, XX(4), XX(5), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(4), XX(5), PR_WK_Renamed)
        '2021.08.19 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' �U��
        PR_WK_Renamed.DT = "�U��"
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.19 UPGRADE S  AIT)hieutv
		'PR_WK_Renamed.X = PRN_XGet(2, XX(5), XX(6), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(5), XX(6), PR_WK_Renamed)
        '2021.08.19 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' ����
        PR_WK_Renamed.DT = "����"
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.19 UPGRADE S  AIT)hieutv
		'PR_WK_Renamed.X = PRN_XGet(2, XX(6), XX(7), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(6), XX(7), PR_WK_Renamed)
        '2021.08.19 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' ��`
        PR_WK_Renamed.DT = "��`"
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.19 UPGRADE S  AIT)hieutv
		'PR_WK_Renamed.X = PRN_XGet(2, XX(7), XX(8), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(7), XX(8), PR_WK_Renamed)
        '2021.08.19 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)

        '----- ���s
        pryy = pryy + (P_YY * 1.5)
        '----- ����
        Call PRN_LINE(XX(0), pryy, XX(UBound(XX)), pryy, 20, "")

    End Sub

    '-------------------------------------------------------------------------------
    '   ����    :   �f�[�^�������
    '   �֐�    :   Sub PrDataD076()
    '   ����    :   pryy    ����x�ʒu
    '   �@�@        DT()    IPPAN_DATA_DBT
    '   �ߒl    :   �Ȃ�
    '-------------------------------------------------------------------------------
    Private Sub PrDataD076(ByRef pryy As Single, ByRef DT As SIHARAI_LIST_QRY)

        Dim PR_WK_Renamed As PR_WK
        Dim yMargn As Single
        Dim PR_Text As String

        '----- �]��
        yMargn = P_YY * 0.25

        ' �x���敪
        Select Case DT.MEISAI_KB
            Case "9" : PR_Text = "�O��"
            Case Else : PR_Text = "���"
        End Select
        PR_WK_Renamed.DT = PR_Text
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.19 UPGRADE S  AIT)hieutv
		'PR_WK_Renamed.X = PRN_XGet(0, XX(1), XX(2), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(0, XX(1), XX(2), PR_WK_Renamed)
        '2021.08.19 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' �敪���e
        Select Case DT.MEISAI_KB
            Case "1" : PR_Text = "1:�x����"
            Case "2" : PR_Text = "2:�O������"
            Case "3" : PR_Text = "3:���c�x��"
            Case "9" : PR_Text = "������ " & Trim(DT.CHUUMON_NO)
            Case Else : PR_Text = ""
        End Select
        PR_WK_Renamed.DT = PR_Text
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.19 UPGRADE S  AIT)hieutv
		'PR_WK_Renamed.X = PRN_XGet(0, XX(2), XX(3), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(0, XX(2), XX(3), PR_WK_Renamed)
        '2021.08.19 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' �i���^���o����
        PR_WK_Renamed.DT = RTrim(DT.MEISYOU)
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.19 UPGRADE S  AIT)hieutv
		'PR_WK_Renamed.X = PRN_XGet(0, XX(3), XX(4), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(0, XX(3), XX(4), PR_WK_Renamed)
        '2021.08.19 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' ���z
        '2021.08.12 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.DT = VB6.Format(DT.KINGAKU, "#,###,###,##0")
        PR_WK_Renamed.DT = DT.KINGAKU.ToString("#,###,###,##0")
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.19 UPGRADE S  AIT)hieutv
		'PR_WK_Renamed.X = PRN_XGet(2, XX(4), XX(5), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(4), XX(5), PR_WK_Renamed)
        '2021.08.19 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' �U��
        '2021.08.12 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.DT = VB6.Format(DT.FUR_KIN, "#,###,###,##0")
        PR_WK_Renamed.DT = DT.FUR_KIN.ToString("#,###,###,##0")
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.19 UPGRADE S  AIT)hieutv
		'PR_WK_Renamed.X = PRN_XGet(2, XX(5), XX(6), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(5), XX(6), PR_WK_Renamed)
        '2021.08.19 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' ����
        '2021.08.12 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.DT = VB6.Format(DT.GEN_KIN, "#,###,###,##0")
        PR_WK_Renamed.DT = DT.GEN_KIN.ToString("#,###,###,##0")
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.19 UPGRADE S  AIT)hieutv
		'PR_WK_Renamed.X = PRN_XGet(2, XX(6), XX(7), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(6), XX(7), PR_WK_Renamed)
        '2021.08.19 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' ��`
        '2021.08.12 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.DT = VB6.Format(DT.TEG_KIN, "#,###,###,##0")
        PR_WK_Renamed.DT = DT.TEG_KIN.ToString("#,###,###,##0")
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.19 UPGRADE S  AIT)hieutv
		'PR_WK_Renamed.X = PRN_XGet(2, XX(7), XX(8), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(7), XX(8), PR_WK_Renamed)
        '2021.08.19 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)

    End Sub

    '-------------------------------------------------------------------------------
    '   ����    :   ���v�f�[�^�������
    '   �֐�    :   Sub PrGokeiD076()
    '   ����    :   pryy    ����x�ʒu
    '   �@�@        Kingaku ���v���z
    '   �ߒl    :   �Ȃ�
    '-------------------------------------------------------------------------------
    Private Sub PrGokeiD076(ByRef pryy As Single, ByRef KINGAKU() As Decimal, ByRef KINGAKU_G() As Decimal, ByRef KINGAKU_I() As Decimal, Optional ByRef Flg As Short = 0)

        Dim PR_WK_Renamed As PR_WK
        Dim yMargn As Single

        '----- �]��
        yMargn = P_YY * 0.25

        If Flg = 0 Then
            PR_WK_Renamed.DT = "���@�v"
            PR_WK_Renamed.FS = F_SIZE
            '2021.08.19 UPGRADE S  AIT)hieutv
			'PR_WK_Renamed.X = PRN_XGet(2, XX(3), XX(4), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
            PRN_XGet(2, XX(3), XX(4), PR_WK_Renamed)
            '2021.08.19 UPGRADE E
            PR_WK_Renamed.Y = pryy + yMargn
            Call PRN_DATA(PR_WK_Renamed)
            ' �x�����z
            '2021.08.12 UPGRADE S  AIT)hieutv
            'PR_WK_Renamed.DT = VB6.Format(KINGAKU(0), "#,###,###,##0")
            PR_WK_Renamed.DT = KINGAKU(0).ToString("#,###,###,##0")
            '2021.08.12 UPGRADE E
            PR_WK_Renamed.FS = F_SIZE
            '2021.08.19 UPGRADE S  AIT)hieutv
			'PR_WK_Renamed.X = PRN_XGet(2, XX(4), XX(5), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
            PRN_XGet(2, XX(4), XX(5), PR_WK_Renamed)
            '2021.08.19 UPGRADE E
            PR_WK_Renamed.Y = pryy + yMargn
            Call PRN_DATA(PR_WK_Renamed)
            ' �U�����z
            '2021.08.12 UPGRADE S  AIT)hieutv
            'PR_WK_Renamed.DT = VB6.Format(KINGAKU(1), "#,###,###,##0")
            PR_WK_Renamed.DT = KINGAKU(1).ToString("#,###,###,##0")
            '2021.08.12 UPGRADE E
            PR_WK_Renamed.FS = F_SIZE
            '2021.08.19 UPGRADE S  AIT)hieutv
			'PR_WK_Renamed.X = PRN_XGet(2, XX(5), XX(6), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
            PRN_XGet(2, XX(5), XX(6), PR_WK_Renamed)
            '2021.08.19 UPGRADE E
            PR_WK_Renamed.Y = pryy + yMargn
            Call PRN_DATA(PR_WK_Renamed)
            ' �������z
            '2021.08.12 UPGRADE S  AIT)hieutv
            'PR_WK_Renamed.DT = VB6.Format(KINGAKU(2), "#,###,###,##0")
            PR_WK_Renamed.DT = KINGAKU(2).ToString("#,###,###,##0")
            '2021.08.12 UPGRADE E
            PR_WK_Renamed.FS = F_SIZE
            '2021.08.19 UPGRADE S  AIT)hieutv
			'PR_WK_Renamed.X = PRN_XGet(2, XX(6), XX(7), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
            PRN_XGet(2, XX(6), XX(7), PR_WK_Renamed)
            '2021.08.19 UPGRADE E
            PR_WK_Renamed.Y = pryy + yMargn
            Call PRN_DATA(PR_WK_Renamed)
            ' ��`���z
            '2021.08.12 UPGRADE S  AIT)hieutv
            'PR_WK_Renamed.DT = VB6.Format(KINGAKU(3), "#,###,###,##0")
            PR_WK_Renamed.DT = KINGAKU(3).ToString("#,###,###,##0")
            '2021.08.12 UPGRADE E
            PR_WK_Renamed.FS = F_SIZE
            '2021.08.19 UPGRADE S  AIT)hieutv
			'PR_WK_Renamed.X = PRN_XGet(2, XX(7), XX(8), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
            PRN_XGet(2, XX(7), XX(8), PR_WK_Renamed)
            '2021.08.19 UPGRADE E
            PR_WK_Renamed.Y = pryy + yMargn
            Call PRN_DATA(PR_WK_Renamed)

            '----- ���s
            pryy = pryy + P_YY * 1.5
        Else
            PR_WK_Renamed.DT = "�O���@�����v"
            PR_WK_Renamed.FS = F_SIZE
            '2021.08.19 UPGRADE S  AIT)hieutv
			'PR_WK_Renamed.X = PRN_XGet(2, XX(3), XX(4), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
            PRN_XGet(2, XX(3), XX(4), PR_WK_Renamed)
            '2021.08.19 UPGRADE E
            PR_WK_Renamed.Y = pryy + yMargn
            Call PRN_DATA(PR_WK_Renamed)
            ' �x�����z
            '2021.08.12 UPGRADE S  AIT)hieutv
            'PR_WK_Renamed.DT = VB6.Format(KINGAKU_G(0), "#,###,###,##0")
            PR_WK_Renamed.DT = KINGAKU_G(0).ToString("#,###,###,##0")
            '2021.08.12 UPGRADE E
            PR_WK_Renamed.FS = F_SIZE
            '2021.08.19 UPGRADE S  AIT)hieutv
			'PR_WK_Renamed.X = PRN_XGet(2, XX(4), XX(5), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
            PRN_XGet(2, XX(4), XX(5), PR_WK_Renamed)
            '2021.08.19 UPGRADE E
            PR_WK_Renamed.Y = pryy + yMargn
            Call PRN_DATA(PR_WK_Renamed)
            ' �U�����z
            '2021.08.12 UPGRADE S  AIT)hieutv
            'PR_WK_Renamed.DT = VB6.Format(KINGAKU_G(1), "#,###,###,##0")
            PR_WK_Renamed.DT = KINGAKU_G(1).ToString("#,###,###,##0")
            '2021.08.12 UPGRADE E
            PR_WK_Renamed.FS = F_SIZE
            '2021.08.19 UPGRADE S  AIT)hieutv
			'PR_WK_Renamed.X = PRN_XGet(2, XX(5), XX(6), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
            PRN_XGet(2, XX(5), XX(6), PR_WK_Renamed)
            '2021.08.19 UPGRADE E
            PR_WK_Renamed.Y = pryy + yMargn
            Call PRN_DATA(PR_WK_Renamed)
            ' �������z
            '2021.08.12 UPGRADE S  AIT)hieutv
            'PR_WK_Renamed.DT = VB6.Format(KINGAKU_G(2), "#,###,###,##0")
            PR_WK_Renamed.DT = KINGAKU_G(2).ToString("#,###,###,##0")
            '2021.08.12 UPGRADE E
            PR_WK_Renamed.FS = F_SIZE
            '2021.08.19 UPGRADE S  AIT)hieutv
			'PR_WK_Renamed.X = PRN_XGet(2, XX(6), XX(7), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
            PRN_XGet(2, XX(6), XX(7), PR_WK_Renamed)
            '2021.08.19 UPGRADE E
            PR_WK_Renamed.Y = pryy + yMargn
            Call PRN_DATA(PR_WK_Renamed)
            ' ��`���z
            '2021.08.12 UPGRADE S  AIT)hieutv
            'PR_WK_Renamed.DT = VB6.Format(KINGAKU_G(3), "#,###,###,##0")
            PR_WK_Renamed.DT = KINGAKU_G(3).ToString("#,###,###,##0")
            '2021.08.12 UPGRADE E
            PR_WK_Renamed.FS = F_SIZE
            '2021.08.19 UPGRADE S  AIT)hieutv
			'PR_WK_Renamed.X = PRN_XGet(2, XX(7), XX(8), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
            PRN_XGet(2, XX(7), XX(8), PR_WK_Renamed)
            '2021.08.19 UPGRADE E
            PR_WK_Renamed.Y = pryy + yMargn
            Call PRN_DATA(PR_WK_Renamed)

            '----- ���s
            pryy = pryy + P_YY * 1.5

            PR_WK_Renamed.DT = "��ʁ@�����v"
            PR_WK_Renamed.FS = F_SIZE
            '2021.08.19 UPGRADE S  AIT)hieutv
			'PR_WK_Renamed.X = PRN_XGet(2, XX(3), XX(4), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
            PRN_XGet(2, XX(3), XX(4), PR_WK_Renamed)
            '2021.08.19 UPGRADE E
            PR_WK_Renamed.Y = pryy + yMargn
            Call PRN_DATA(PR_WK_Renamed)
            ' �x�����z
            '2021.08.12 UPGRADE S  AIT)hieutv
            'PR_WK_Renamed.DT = VB6.Format(KINGAKU_I(0), "#,###,###,##0")
            PR_WK_Renamed.DT = KINGAKU_I(0).ToString("#,###,###,##0")
            '2021.08.12 UPGRADE E
            PR_WK_Renamed.FS = F_SIZE
            '2021.08.19 UPGRADE S  AIT)hieutv
			'PR_WK_Renamed.X = PRN_XGet(2, XX(4), XX(5), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
            PRN_XGet(2, XX(4), XX(5), PR_WK_Renamed)
            '2021.08.19 UPGRADE E
            PR_WK_Renamed.Y = pryy + yMargn
            Call PRN_DATA(PR_WK_Renamed)
            ' �U�����z
            '2021.08.12 UPGRADE S  AIT)hieutv
            'PR_WK_Renamed.DT = VB6.Format(KINGAKU_I(1), "#,###,###,##0")
            PR_WK_Renamed.DT = KINGAKU_I(1).ToString("#,###,###,##0")
            '2021.08.12 UPGRADE E
            PR_WK_Renamed.FS = F_SIZE
            '2021.08.19 UPGRADE S  AIT)hieutv
			'PR_WK_Renamed.X = PRN_XGet(2, XX(5), XX(6), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
            PRN_XGet(2, XX(5), XX(6), PR_WK_Renamed)
            '2021.08.19 UPGRADE E
            PR_WK_Renamed.Y = pryy + yMargn
            Call PRN_DATA(PR_WK_Renamed)
            ' �������z
            '2021.08.12 UPGRADE S  AIT)hieutv
            'PR_WK_Renamed.DT = VB6.Format(KINGAKU_I(2), "#,###,###,##0")
            PR_WK_Renamed.DT = KINGAKU_I(2).ToString("#,###,###,##0")
            '2021.08.12 UPGRADE E
            PR_WK_Renamed.FS = F_SIZE
            '2021.08.19 UPGRADE S  AIT)hieutv
			'PR_WK_Renamed.X = PRN_XGet(2, XX(6), XX(7), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
            PRN_XGet(2, XX(6), XX(7), PR_WK_Renamed)
            '2021.08.19 UPGRADE E
            PR_WK_Renamed.Y = pryy + yMargn
            Call PRN_DATA(PR_WK_Renamed)
            ' ��`���z
            '2021.08.12 UPGRADE S  AIT)hieutv
            'PR_WK_Renamed.DT = VB6.Format(KINGAKU_I(3), "#,###,###,##0")
            PR_WK_Renamed.DT = KINGAKU_I(3).ToString("#,###,###,##0")
            PR_WK_Renamed.FS = F_SIZE
            '2021.08.19 UPGRADE S  AIT)hieutv
			'PR_WK_Renamed.X = PRN_XGet(2, XX(7), XX(8), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
            PRN_XGet(2, XX(7), XX(8), PR_WK_Renamed)
            '2021.08.19 UPGRADE E
            PR_WK_Renamed.Y = pryy + yMargn
            Call PRN_DATA(PR_WK_Renamed)

            '----- ���s
            pryy = pryy + P_YY * 1.5
        End If

    End Sub

    '-------------------------------------------------------------------------------
    '   ����    :   ���y�[�W�`�F�b�N�p���R�[�h�������o����
    '   �֐�    :   Sub PrRcntD076()
    '   ����    :   sCode   �Ǝк���
    '   �ߒl    :   R_Cnt   ���o���R�[�h����
    '-------------------------------------------------------------------------------
    Private Function PrRcntD076(ByRef sCode As String) As Integer

        Dim Jouken As String
        Dim Cnt1 As Integer
        Dim Cnt2 As Integer

        ' �߂�l�̏�����
        PrRcntD076 = -1

        ' WHERE���g��
        Jouken = "KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"
        Jouken = Jouken & " AND EDA_NO = '" & KeyKouji.EDA_NO & "'"
        Jouken = Jouken & " AND SIME_YM = '" & CtlKouji.SYORI_YM & "'"
        Jouken = Jouken & " AND GYOUSYA_CD = '" & Trim(sCode) & "'"
        Jouken = Jouken & " AND NYUURYOKU_FLG = '01'"
        Jouken = Jouken & " AND S_FLG_GENKA = '1'"
        Jouken = Jouken & " AND NOT(MEISAI_KB = '2' AND SUURYOU <> (H_SUURYOU + H_ZAIKO))"

        ' ��ʕ�����
        Cnt1 = CNTGET_IPPAN_DATA(Jouken)
        If Cnt1 < 0 Then Cnt1 = 0

        ' WHERE���g��
        Jouken = "KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"
        Jouken = Jouken & " AND EDA_NO = '" & KeyKouji.EDA_NO & "'"
        Jouken = Jouken & " AND SIME_YM = '" & CtlKouji.SYORI_YM & "'"
        Jouken = Jouken & " AND GYOUSYA_CD = '" & Trim(sCode) & "'"
        Jouken = Jouken & " AND (KON_SI_GAKU + ZEI_GAKU) <> 0"

        ' �O������
        Cnt2 = CNTGET_GAI_KIHON_DATA(Jouken)
        If Cnt2 < 0 Then Cnt2 = 0

        ' �߂�l�̃Z�b�g
        PrRcntD076 = Cnt1 + Cnt2

    End Function
End Module
