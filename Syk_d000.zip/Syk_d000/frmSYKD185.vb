Option Strict Off
Option Explicit On
Friend Class frmSYKD185
	Inherits System.Windows.Forms.Form
	'

	'2021.08.03 UPGRADE S  AIT)Hoangtx
	'	Private Sub Check1_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles Check1.Enter
	Private Sub Check1_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _Check1_0.Enter, _Check1_1.Enter
		'Dim Index As Short = Check1.GetIndex(eventSender)
		Dim Index As Short = Check1.IndexOf(eventSender)
		'Call GotFocus(Check1(Index), StatusBar1)
		Call MtyTool.GotFocus(Check1(Index), StatusBar1)
		'2021.08.03 UPGRADE E
	End Sub
	'2021.08.03 UPGRADE S  AIT)Hoangtx
	'	Private Sub Check1_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles Check1.Leave
	Private Sub Check_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _Check1_0.Leave, _Check1_1.Leave
		'Dim Index As Short = Check1.GetIndex(eventSender)
		Dim Index As Short = Check1.IndexOf(eventSender)
		'Call LostFocus(Check1(Index), StatusBar1)
		Call MtyTool.LostFocus(Check1(Index), StatusBar1)
		'2021.08.03 UPGRADE E
	End Sub
	'2021.08.03 UPGRADE S  AIT)Hoangtx
	'	Private Sub cmdKey_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Click
	Private Sub cmdKey_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _cmdKey_12.Click, _cmdKey_1.Click
		'Dim Index As Short = cmdKey.GetIndex(eventSender)
		Dim Index As Short = cmdKey.IndexOf(eventSender)
		'2021.08.03 UPGRADE E

		Dim Jouken As String
		Dim Msg As String

		Select Case Index
			Case 1 '----- �������
				'2021.08.09 UPGRADE S  AIT)Hoangtx
				'If Check1(0).CheckState = CDbl("1") Or Check1(1).CheckState = CDbl("1") Then
				'If MsgBox("�H������(�y��)��������܂��B��낵���ł����H", MsgBoxStyle.YesNo) = MsgBoxResult.No Then
				If Check1(0).CheckState = CDbl("1") OrElse Check1(1).CheckState = CDbl("1") Then
					If MsgBox("�H������(�y��)��������܂��B��낵���ł����H", MsgBoxStyle.YesNo, SYSTEMNM) = MsgBoxResult.No Then
						'2021.08.09 UPGRADE E
						Exit Sub
					End If

					If Check1(0).CheckState = 1 Then
						System.Windows.Forms.Application.DoEvents()
						System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
						StatusBar1.Items.Item("Message").Text = "����f�[�^�i����j�쐬���E�E�E"
						System.Windows.Forms.Application.DoEvents()
						'2021.09.17 ADD S  AIT)Hoangtx
						Call MtyTool.LostFocus(_cmdKey_1, StatusBar1)
						'2021.09.17 ADD E
						If PrnMainD185() = True Then
							'2001/01/21 �ҏW�̏ꍇ�̂ݍX�V����
							If INPMODE = "2" Then '�ҏW��
								' �H�����i����j�y�؂̍X�V
								CtlKouji.P_FLG_GEPPOU = "1" '���FLG �H������
								Jouken = "KOUJI_NO = '" & CtlKouji.KOUJI_NO & "' AND EDA_NO = '" & CtlKouji.EDA_NO & "'"
								If UPDATE_KOUJI_CTRL_D(Jouken, CtlKouji) = False Then
									Msg = "�H�����i����j�y�؂̍X�V�Ɏ��s���܂����B"
									'2021.09.14 UPGRADE S  AIT)dannnl
									'MsgBox(Msg, MsgBoxStyle.OkOnly)
									MsgBox(Msg, MsgBoxStyle.OkOnly, SYSTEMNM)
									'2021.09.14 UPGRADE E
									Exit Sub
								End If
							End If
						End If
						'2021.09.17 ADD S  AIT)Hoangtx
						_cmdKey_1.BackColor = System.Drawing.Color.Yellow
						'2021.09.17 ADD E
					End If
					If Check1(1).CheckState = 1 Then
						System.Windows.Forms.Application.DoEvents()
						System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
						StatusBar1.Items.Item("Message").Text = "����f�[�^�i�ڍׁj�쐬���E�E�E"
						System.Windows.Forms.Application.DoEvents()
						'2021.09.17 ADD S  AIT)Hoangtx
						Call MtyTool.LostFocus(_cmdKey_1, StatusBar1)
						'2021.09.17 ADD E
						If PrnMainD186() = True Then
							'2001/01/21 �ҏW�̏ꍇ�̂ݍX�V����
							If INPMODE = "2" Then '�ҏW��
								' �H�����i����j�y�؂̍X�V
								CtlKouji.P_FLG_GEPPOU = "1" '���FLG �H������
								Jouken = "KOUJI_NO = '" & CtlKouji.KOUJI_NO & "' AND EDA_NO = '" & CtlKouji.EDA_NO & "'"
								If UPDATE_KOUJI_CTRL_D(Jouken, CtlKouji) = False Then
									Msg = "�H�����i����j�y�؂̍X�V�Ɏ��s���܂����B"
									'2021.09.14 UPGRADE S  AIT)dannnl
									'MsgBox(Msg, MsgBoxStyle.OkOnly)
									MsgBox(Msg, MsgBoxStyle.OkOnly, SYSTEMNM)
									'2021.09.14 UPGRADE E
									Exit Sub
								End If
							End If
						End If
						'2021.09.17 ADD S  AIT)Hoangtx
						_cmdKey_1.BackColor = System.Drawing.Color.Yellow
						'2021.09.17 ADD E
					End If
				Else
					Exit Sub
				End If
				System.Windows.Forms.Application.DoEvents()
				StatusBar1.Items.Item("Message").Text = ""
				System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
				System.Windows.Forms.Application.DoEvents()

			Case 12 '----- �����I��

				'2021.08.03 UPGRAPE S  AIT)Hoangtx
				'Me.Close()
				Me.Dispose()
				'2021.08.03 UPGRAPE E
		End Select

	End Sub

	'2021.08.03 UPGRADE S  AIT)Hoangtx
	'	Private Sub cmdKey_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Enter


	Private Sub cmdKey_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _cmdKey_12.Enter, _cmdKey_1.Enter
		'Dim Index As Short = cmdKey.GetIndex(eventSender)
		Dim Index As Short = cmdKey.IndexOf(eventSender)
		'Call GotFocus(cmdKey(Index), StatusBar1)
		Call MtyTool.GotFocus(cmdKey(Index), StatusBar1)
		'2021.08.03 UPGRADE E
	End Sub

	'2021.08.03 UPGRADE S  AIT)Hoangtx
	'	Private Sub cmdKey_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Leave
	Private Sub cmdKey_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _cmdKey_12.Leave, _cmdKey_1.Leave
		'Dim Index As Short = cmdKey.GetIndex(eventSender)
		Dim Index As Short = cmdKey.IndexOf(eventSender)
		'Call LostFocus(cmdKey(Index), StatusBar1)
		Call MtyTool.LostFocus(cmdKey(Index), StatusBar1)
		'2021.08.03 UPGRADE E
	End Sub

	Private Sub frmSYKD185_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown
		Dim KeyCode As Short = eventArgs.KeyCode
		Dim Shift As Short = eventArgs.KeyData \ &H10000
		Select Case KeyCode
			Case System.Windows.Forms.Keys.Return
				'2021.08.17 UPGRADE S  AIT)dannnl
				'Call NextCntlGet(Me, Me.ActiveControl.TabIndex)
				Call NextCntlGet()
				'2021.08.17 UPGRADE E
			Case System.Windows.Forms.Keys.F1
				If cmdKey(1).Enabled = True Then cmdKey(1).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(1), New System.EventArgs())
			Case System.Windows.Forms.Keys.F12
				If cmdKey(12).Enabled = True Then cmdKey(12).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(12), New System.EventArgs())
		End Select
	End Sub
	
	Private Sub frmSYKD185_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
		Call FormDisp(Me)
	End Sub
End Class
