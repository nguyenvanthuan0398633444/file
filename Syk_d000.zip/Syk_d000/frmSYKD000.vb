Option Strict Off
Option Explicit On
Friend Class frmSYKD000
	Inherits System.Windows.Forms.Form
	'=============================================================
	' ���[�U�[���@  �F  �R�z�H�Ɗ������
	' �V�X�e�����@  �F  �H���Ǘ��V�X�e��
	' ���W���[����  �F  �p�X���[�h����
	' ���W���[��ID�@�F  frmSYKD000.frm
	' �쐬���@ �@�@ �F  ���� 13 �N 05 �� 29 ��
	' �X�V���@�@  �@�F  ����    �N    ��    ��
	'=============================================================
	'
	'
	
	'-------------------------------------------------------------------------------
	'   ����    :   ��ʂ̃N���A
	'   �֐�    :   Sub DispClear()
	'   ����    :   �Ȃ�
	'   �@�\    :   ��ʃf�[�^���N���A���܂��B
	'-------------------------------------------------------------------------------
	Private Sub DispClear()
		imText1(0).Text = ""
		imText2(0).Text = ""
		imText1(1).Text = ""
	End Sub
	
	'-------------------------------------------------------------------------------
	'   ����    :   �p�X���[�h�̃`�F�b�N
	'   �֐�    :   Function DispDataCheck()
	'   ����    :   �Ȃ�
	'   �ߒl    :   True  ���͐���
	'   �@�@    :   False ���̓G���[
	'   �@�\    :   �p�X���[�h���`�F�b�N���܂��B
	'-------------------------------------------------------------------------------
	Private Function DispDataCheck() As Boolean
		
		Dim Jouken As String
		Dim Order As String
		Dim Cnt As Integer
		Dim DT() As SYAIN_MAST_DBT
		
		DispDataCheck = False
		
		'----- �Ј�
		If Trim(imText1(0).Text) = "" Then
			'2021.09.14 UPGRADE S  AIT)dannnl
			'MsgBox("�Ј����ނ����͂���Ă��܂���B", MsgBoxStyle.Information)
			MsgBox("�Ј����ނ����͂���Ă��܂���B", MsgBoxStyle.Information, SYSTEMNM)
			'2021.09.14 UPGRADE E
			imText1(0).Focus()
			Exit Function
		End If
		Jouken = "SYAIN_CD = '" & Trim(imText1(0).Text) & "'"
		Order = ""
		Cnt = SELECT_SYAIN_MAST(Jouken, Order, DT)
		If Cnt <= 0 Then
			'2021.09.14 UPGRADE S  AIT)dannnl
			'MsgBox("���͂��ꂽ�Ј����ނ͓o�^����Ă��܂���B", MsgBoxStyle.Information)
			MsgBox("���͂��ꂽ�Ј����ނ͓o�^����Ă��܂���B", MsgBoxStyle.Information, SYSTEMNM)
			'2021.09.14 UPGRADE E
			imText1(0).Focus()
			Exit Function
		End If

		'----- �p�X���[�h
		If Trim(imText1(1).Text) = "" Then
			'2021.09.14 UPGRADE S  AIT)dannnl
			'MsgBox("�p�X���[�h�����͂���Ă��܂���B", MsgBoxStyle.Information)
			MsgBox("�p�X���[�h�����͂���Ă��܂���B", MsgBoxStyle.Information, SYSTEMNM)
			'2021.09.14 UPGRADE E
			imText1(1).Focus()
			Exit Function
		End If
		If Trim(imText1(1).Text) <> Trim(DT(0).PASSWARD) Then
			'2021.09.14 UPGRADE S  AIT)dannnl
			'MsgBox("�p�X���[�h���Ⴂ�܂��B", MsgBoxStyle.Information)
			MsgBox("�p�X���[�h���Ⴂ�܂��B", MsgBoxStyle.Information, SYSTEMNM)
			'2021.09.14 UPGRADE E
			imText1(1).Focus()
			Exit Function
		End If

		'----- ����
		INPMODE = DT(0).KENGEN_KB_D
		B11INPMODE = DT(0).KENGEN_KB_D
		B10INPMODE = DT(0).KENGEN_KB_D
		If INPMODE = "0" Then
			'2021.09.14 UPGRADE S  AIT)dannnl
			'MsgBox("�V�X�e���ɑ΂��錠��������܂���B", MsgBoxStyle.Information)
			MsgBox("�V�X�e���ɑ΂��錠��������܂���B", MsgBoxStyle.Information, SYSTEMNM)
			'2021.09.14 UPGRADE E
			imText1(0).Focus()
			Exit Function
		End If
		
		'----- �\���̂ɃZ�b�g
		CtlSyain = DT(0)
		
		DispDataCheck = True
		
	End Function
	'2021.08.02 UPGRADE S  AIT)Hoangtx
	'Private Sub cmdKey_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Click
	'	Dim Index As Short = cmdKey.GetIndex(eventSender)
	Private Sub cmdKey_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _cmdKey_1.Click, _cmdKey_12.Click
		Dim Index As Short = cmdKey.IndexOf(eventSender)
		'2021.08.02 UPGRADE E

		Select Case Index
			Case 1 '----- �m�F
				If DispDataCheck() = False Then
					Exit Sub
				End If
				' ���M�p�f�B���N�g���̊m�F
				Call DirectoryCheck(SENDPATH)
				' ��M�p�f�B���N�g���̊m�F
				Call DirectoryCheck(RECVPATH)
				' ��Ɨp�f�B���N�g���̊m�F
				Call DirectoryCheck(TEMPPATH)
				'2014/01/16 �ǉ� ----------------------����������
				If SYSTEMID <> "S" Then
					' ���M��f�t�H���g�f�B���N�g���̊m�F
					Call DirectoryCheck(SFDPATH)
					' ��M���f�t�H���g�f�B���N�g���̊m�F
					Call DirectoryCheck(RFDPATH)
				End If
				'--------------------------------------����������
				'2021.08.02 ADD S  AIT)Hoangtx
				Me.Hide()
				'2021.08.02 ADD E
				frmSYKD010.Show()
				'2021.08.02 DELETE S  AIT)Hoangtx
				'Me.Close()
				'2021.08.02 DELETE E

				System.Windows.Forms.Application.DoEvents()
			Case 12 '----- �I��
				Call JobEnd()
		End Select
	End Sub
	'2021.08.02 UPGRADE S  AIT)Hoangtx
	'Private Sub cmdKey_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Enter
	'	Dim Index As Short = cmdKey.GetIndex(eventSender)
	'	Call GotFocus(cmdKey(Index), StatusBar1)

	Private Sub cmdKey_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _cmdKey_1.Enter, _cmdKey_12.Enter
		Dim Index As Short = cmdKey.IndexOf(eventSender)
		Call MtyTool.GotFocus(cmdKey(Index), StatusBar1)
		'2021.08.02 UPGRADE E
	End Sub

	'2021.08.02 UPGRADE S  AIT)Hoangtx
	'Private Sub cmdKey_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Leave
	'	Dim Index As Short = cmdKey.GetIndex(eventSender)
	'	Call LostFocus(cmdKey(Index), StatusBar1)
	Private Sub cmdKey_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _cmdKey_1.Leave, _cmdKey_12.Leave
		Dim Index As Short = cmdKey.IndexOf(eventSender)
		Call MtyTool.LostFocus(cmdKey(Index), StatusBar1)
		'2021.08.02 UPGRADE E
	End Sub

	'2021.08.02 UPGRADE S  AIT)Hoangtx
	'Private Sub cmdLook_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdLook.Click
	'	Dim Index As Short = cmdLook.GetIndex(eventSender)
	Private Sub cmdLook_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _cmdLook_0.Click
		Dim Index As Short = cmdLook.IndexOf(eventSender)
		'2021.08.02 UPGRADE E
		Select Case Index
			Case 0 '�Ј��}�X�^����
				frmSearch.MastNo = 2
				frmSearch.ShowDialog()
				If frmSearch.GetCD <> "" Then
					imText1(Index).Text = Trim(frmSearch.GetCD)
					imText2(Index).Text = Trim(frmSearch.GetNM)
					'2021.08.02 add S  AIT)Hoangtx
					'imText1(1).Focus()
					imText1(0).Focus()
					'2021.08.02 add E
					Exit Sub
				End If
				imText1(Index).Focus()
		End Select
	End Sub

	Private Sub frmSYKD000_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown
		Dim KeyCode As Short = eventArgs.KeyCode
		Dim Shift As Short = eventArgs.KeyData \ &H10000
		Select Case KeyCode
			Case System.Windows.Forms.Keys.F1
				If cmdKey(1).Enabled = True Then cmdKey(1).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(1), New System.EventArgs())
			Case System.Windows.Forms.Keys.F12
				If cmdKey(12).Enabled = True Then cmdKey(12).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(12), New System.EventArgs())
		End Select
	End Sub
	
	Private Sub frmSYKD000_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
		'��������
		Call JobFirst()
		'�����\��
		Call FormDisp(Me)
		Call DispClear()
	End Sub
	
	Private Sub frmSYKD000_FormClosing(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
		Dim Cancel As Boolean = eventArgs.Cancel
		Dim UnloadMode As System.Windows.Forms.CloseReason = eventArgs.CloseReason
		If UnloadMode = System.Windows.Forms.CloseReason.UserClosing Then
			Call JobEnd()
		End If
		eventArgs.Cancel = Cancel
	End Sub
	'2021.08.02 UPGRADE S  AIT)Hoangtx
	'Private Sub imText1_Change(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles imText1.Change
	'	Dim Index As Short = imText1.GetIndex(eventSender)
	Private Sub imText1_Change(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _imText1_1.TextChanged, _imText1_0.TextChanged
		Dim Index As Short = imText1.IndexOf(eventSender)
		'2021.08.02 UPGRADE E
		If Index = 0 Then
			imText2(Index).Text = ""
		End If
	End Sub

	'2021.08.02 UPGRADE S  AIT)Hoangtx
	'Private Sub imText1_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles imText1.Enter
	'	Dim Index As Short = imText1.GetIndex(eventSender)
	'	Call GotFocus(imText1(Index), StatusBar1)

	Private Sub imText1_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _imText1_1.Enter, _imText1_0.Enter
		Dim Index As Short = imText1.IndexOf(eventSender)
		Call MtyTool.GotFocus(imText1(Index), StatusBar1)
		'2021.08.02 UPGRADE E
	End Sub

	'2021.08.02 UPGRADE S  AIT)Hoangtx
	'Private Sub imText1_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles imText1.KeyDown
	Private Sub imText1_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles _imText1_0.KeyDown, _imText1_1.KeyDown
		Dim KeyCode As Short = eventArgs.KeyCode
		Dim Shift As Short = eventArgs.KeyData \ &H10000
		'Dim Index As Short = imText1.GetIndex(eventSender)
		Dim Index As Short = imText1.IndexOf(eventSender)
		'2021.08.02 ADD S  AIT)Hoangtx
		Dim text As String = imText1(0).text
		'2021.08.02 ADD E
		'2021.08.02 UPGRADE E
		Select Case KeyCode
			Case System.Windows.Forms.Keys.Return
				Select Case Index
					Case 0 : imText1(1).Focus()
					Case 1 : Call cmdKey_Click(cmdKey.Item(1), New System.EventArgs())
				End Select
			Case System.Windows.Forms.Keys.Space
				'2021.08.02 UPGRADE S  AIT)Hoangtx
				'Call cmdLook_Click(cmdLook.Item(Index), New System.EventArgs())
				If Index = 0 Then
					Call cmdLook_Click(cmdLook.Item(Index), New System.EventArgs())
					If imText1(0).text = Trim(text) OrElse imText1(0).text = " " Then
						imText1(0).text = Trim(text)
					End If
					If Trim(imText1(0).text) <> "" Then
						imText1(0).text = Strings.Right(New String("0", imText1(Index).MaxLength) & Trim(imText1(Index).Text), imText1(Index).MaxLength)
						imText2(Index).Text = GetNameSyain(imText1(Index).Text)
						imText1(0).selectall()
					Else
						imText1(0).text = ""
					End If
				End If
				'2021.08.02 UPGRADE E
		End Select
	End Sub
	'2021.08.02 UPGRADE S  AIT)Hoangtx
	'Private Sub imText1_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles imText1.Leave
	'	Dim Index As Short = imText1.GetIndex(eventSender)
	Private Sub imText1_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _imText1_1.Leave, _imText1_0.Leave
		Dim Index As Short = imText1.IndexOf(eventSender)
		'2021.08.02 UPGRADE E
		Call MtyTool.LostFocus(imText1(Index), StatusBar1)
		'If imText1(Index).Format = "9" Then
		'2021.08.02 UPGRADE S  AIT)Hoangtx
		'imText1(Index).Text = VB6.Format(imText1(Index).Text, New String("0", imText1(Index).MaxLength))
		If imText1(Index) IsNot Nothing AndAlso imText1(Index).Format = "9" Then
			If imText1(Index).Text <> "" Then
				imText1(Index).Text = Strings.Right(New String("0", imText1(Index).MaxLength) & Trim(imText1(Index).Text), imText1(Index).MaxLength)
			End If
			'2021.08.02 UPGRADE E
		End If
		Select Case Index
			Case 0 '----- �Ј�����
				imText2(Index).Text = GetNameSyain(imText1(Index).Text)
		End Select
	End Sub
	'2021.08.02 UPGRADE S  AIT)Hoangtx
	Private Sub imText2_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _imText2_0.Leave
		Dim Index As Short = imText1.IndexOf(eventSender)
		_imText1_0.Focus()
	End Sub
	'2021.08.02 UPGRADE E
	Private Sub frmSYKD000_Activated(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Activated
		imText1(0).Focus()
		'2021.08.02 add S  AIT)Hoangtx
		RemoveHandler Me.Activated, AddressOf frmSYKD000_Activated
		'2021.08.02 add E
	End Sub
End Class
