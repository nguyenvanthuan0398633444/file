<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frmWaridasi
#Region "Windows Form Designer generated code "
    <System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
        MyBase.New()
        InitializeComponent()
        'This call is required by the Windows Form Designer.
        Me.cmdKey = New ArrayList

        Me.cmdKey.Add(Nothing)
        Me.cmdKey.Add(_cmdKey_1)
        Me.cmdKey.Add(Nothing)
        Me.cmdKey.Add(Nothing)
        Me.cmdKey.Add(Nothing)
        Me.cmdKey.Add(Nothing)
        Me.cmdKey.Add(Nothing)
        Me.cmdKey.Add(Nothing)
        Me.cmdKey.Add(Nothing)
        Me.cmdKey.Add(Nothing)
        Me.cmdKey.Add(Nothing)
        Me.cmdKey.Add(Nothing)
        Me.cmdKey.Add(_cmdKey_12)
    End Sub
    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer
	Public ToolTip1 As System.Windows.Forms.ToolTip
	'Public WithEvents vaSpread1 As AxFPSpread.AxvaSpread
	Public WithEvents _cmdKey_1 As System.Windows.Forms.Button
	Public WithEvents _cmdKey_12 As System.Windows.Forms.Button
	Public WithEvents Picture1 As System.Windows.Forms.Panel
	Public WithEvents _StatusBar1_Panel2 As System.Windows.Forms.ToolStripStatusLabel
	Public WithEvents Message As System.Windows.Forms.ToolStripStatusLabel
	Public WithEvents StatusBar1 As System.Windows.Forms.StatusStrip
	Public WithEvents lblTitle As System.Windows.Forms.Label
	Public WithEvents cmdKey As ArrayList
	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim ColumnHeaderRenderer1 As FarPoint.Win.Spread.CellType.ColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.ColumnHeaderRenderer()
        Dim RowHeaderRenderer1 As FarPoint.Win.Spread.CellType.RowHeaderRenderer = New FarPoint.Win.Spread.CellType.RowHeaderRenderer()
        Dim ColumnHeaderRenderer2 As FarPoint.Win.Spread.CellType.ColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.ColumnHeaderRenderer()
        Dim ColumnHeaderRenderer3 As FarPoint.Win.Spread.CellType.ColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.ColumnHeaderRenderer()
        Dim RowHeaderRenderer2 As FarPoint.Win.Spread.CellType.RowHeaderRenderer = New FarPoint.Win.Spread.CellType.RowHeaderRenderer()
        Dim RowHeaderRenderer3 As FarPoint.Win.Spread.CellType.RowHeaderRenderer = New FarPoint.Win.Spread.CellType.RowHeaderRenderer()
        Dim RowHeaderRenderer4 As FarPoint.Win.Spread.CellType.RowHeaderRenderer = New FarPoint.Win.Spread.CellType.RowHeaderRenderer()
        Dim RowHeaderRenderer5 As FarPoint.Win.Spread.CellType.RowHeaderRenderer = New FarPoint.Win.Spread.CellType.RowHeaderRenderer()
        Dim ColumnHeaderRenderer4 As FarPoint.Win.Spread.CellType.ColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.ColumnHeaderRenderer()
        Dim RowHeaderRenderer6 As FarPoint.Win.Spread.CellType.RowHeaderRenderer = New FarPoint.Win.Spread.CellType.RowHeaderRenderer()
        Dim ColumnHeaderRenderer5 As FarPoint.Win.Spread.CellType.ColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.ColumnHeaderRenderer()
        Dim ColumnHeaderRenderer6 As FarPoint.Win.Spread.CellType.ColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.ColumnHeaderRenderer()
        Dim RowHeaderRenderer7 As FarPoint.Win.Spread.CellType.RowHeaderRenderer = New FarPoint.Win.Spread.CellType.RowHeaderRenderer()
        Dim RowHeaderRenderer8 As FarPoint.Win.Spread.CellType.RowHeaderRenderer = New FarPoint.Win.Spread.CellType.RowHeaderRenderer()
        Dim RowHeaderRenderer9 As FarPoint.Win.Spread.CellType.RowHeaderRenderer = New FarPoint.Win.Spread.CellType.RowHeaderRenderer()
        Dim RowHeaderRenderer10 As FarPoint.Win.Spread.CellType.RowHeaderRenderer = New FarPoint.Win.Spread.CellType.RowHeaderRenderer()
        Dim DefaultFocusIndicatorRenderer1 As FarPoint.Win.Spread.DefaultFocusIndicatorRenderer = New FarPoint.Win.Spread.DefaultFocusIndicatorRenderer()
        Dim DefaultScrollBarRenderer1 As FarPoint.Win.Spread.DefaultScrollBarRenderer = New FarPoint.Win.Spread.DefaultScrollBarRenderer()
        Dim NamedStyle1 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("Color65637636822673028223")
        Dim NamedStyle2 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("Font193637636822673184713")
        Dim NamedStyle3 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("FilterBarDefault")
        Dim FilterBarCellType1 As FarPoint.Win.Spread.CellType.FilterBarCellType = New FarPoint.Win.Spread.CellType.FilterBarCellType()
        Dim NamedStyle4 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("HeaderDefault")
        Dim NamedStyle5 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("RowHeaderDefault")
        Dim NamedStyle6 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("DataAreaDefault")
        Dim GeneralCellType1 As FarPoint.Win.Spread.CellType.GeneralCellType = New FarPoint.Win.Spread.CellType.GeneralCellType()
        Dim SpreadSkin1 As FarPoint.Win.Spread.SpreadSkin = New FarPoint.Win.Spread.SpreadSkin()
        Dim NamedStyle7 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("HeaderDefault")
        Dim NamedStyle8 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("HeaderDefault")
        Dim NamedStyle9 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("RowHeaderDefault")
        Dim NamedStyle10 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("RowHeaderDefault")
        Dim NamedStyle11 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("DataAreaDefault")
        Dim GeneralCellType2 As FarPoint.Win.Spread.CellType.GeneralCellType = New FarPoint.Win.Spread.CellType.GeneralCellType()
        Dim NamedStyle12 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("FilterBarDefault")
        Dim FilterBarCellType2 As FarPoint.Win.Spread.CellType.FilterBarCellType = New FarPoint.Win.Spread.CellType.FilterBarCellType()
        Dim NamedStyle13 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("RowHeaderDefault")
        Dim NamedStyle14 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("RowHeaderDefault")
        Dim DefaultScrollBarRenderer2 As FarPoint.Win.Spread.DefaultScrollBarRenderer = New FarPoint.Win.Spread.DefaultScrollBarRenderer()
        Dim StatusBarSkin1 As FarPoint.Win.Spread.StatusBarSkin = New FarPoint.Win.Spread.StatusBarSkin()
        Dim TipAppearance1 As FarPoint.Win.Spread.TipAppearance = New FarPoint.Win.Spread.TipAppearance()
        Dim DefaultScrollBarRenderer3 As FarPoint.Win.Spread.DefaultScrollBarRenderer = New FarPoint.Win.Spread.DefaultScrollBarRenderer()
        Dim LineBorder1 As FarPoint.Win.LineBorder = New FarPoint.Win.LineBorder(System.Drawing.SystemColors.WindowFrame)
        Dim TextCellType1 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType()
        Dim TextCellType2 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType()
        Dim TextCellType3 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType()
        Dim TextCellType4 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType()
        Dim TextCellType5 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType()
        Dim LineBorder2 As FarPoint.Win.LineBorder = New FarPoint.Win.LineBorder(System.Drawing.SystemColors.WindowFrame)
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmWaridasi))
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.Picture1 = New System.Windows.Forms.Panel()
        Me._cmdKey_1 = New System.Windows.Forms.Button()
        Me._cmdKey_12 = New System.Windows.Forms.Button()
        Me.StatusBar1 = New System.Windows.Forms.StatusStrip()
        Me._StatusBar1_Panel2 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.Message = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.FpSpread1 = New FarPoint.Win.Spread.FpSpread()
        Me.FpSpread1_Sheet1 = New FarPoint.Win.Spread.SheetView()
        Me.Picture1.SuspendLayout()
        Me.StatusBar1.SuspendLayout()
        CType(Me.FpSpread1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.FpSpread1_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        ColumnHeaderRenderer1.Name = "ColumnHeaderRenderer1"
        ColumnHeaderRenderer1.PictureZoomEffect = False
        ColumnHeaderRenderer1.TextRotationAngle = 0R
        ColumnHeaderRenderer1.ZoomFactor = 1.0!
        RowHeaderRenderer1.Name = "RowHeaderRenderer1"
        RowHeaderRenderer1.PictureZoomEffect = False
        RowHeaderRenderer1.TextRotationAngle = 0R
        RowHeaderRenderer1.ZoomFactor = 1.0!
        ColumnHeaderRenderer2.Name = "ColumnHeaderRenderer2"
        ColumnHeaderRenderer2.PictureZoomEffect = False
        ColumnHeaderRenderer2.TextRotationAngle = 0R
        ColumnHeaderRenderer2.ZoomFactor = 1.0!
        ColumnHeaderRenderer3.Name = "ColumnHeaderRenderer3"
        ColumnHeaderRenderer3.PictureZoomEffect = False
        ColumnHeaderRenderer3.TextRotationAngle = 0R
        ColumnHeaderRenderer3.ZoomFactor = 1.0!
        RowHeaderRenderer2.Name = "RowHeaderRenderer2"
        RowHeaderRenderer2.PictureZoomEffect = False
        RowHeaderRenderer2.TextRotationAngle = 0R
        RowHeaderRenderer2.ZoomFactor = 1.0!
        RowHeaderRenderer3.Name = "RowHeaderRenderer3"
        RowHeaderRenderer3.PictureZoomEffect = False
        RowHeaderRenderer3.TextRotationAngle = 0R
        RowHeaderRenderer3.ZoomFactor = 1.0!
        RowHeaderRenderer4.Name = "RowHeaderRenderer4"
        RowHeaderRenderer4.PictureZoomEffect = False
        RowHeaderRenderer4.TextRotationAngle = 0R
        RowHeaderRenderer4.ZoomFactor = 1.0!
        RowHeaderRenderer5.Name = "RowHeaderRenderer5"
        RowHeaderRenderer5.PictureZoomEffect = False
        RowHeaderRenderer5.TextRotationAngle = 0R
        RowHeaderRenderer5.ZoomFactor = 1.0!
        ColumnHeaderRenderer4.Name = "ColumnHeaderRenderer4"
        ColumnHeaderRenderer4.PictureZoomEffect = False
        ColumnHeaderRenderer4.TextRotationAngle = 0R
        ColumnHeaderRenderer4.ZoomFactor = 1.0!
        RowHeaderRenderer6.Name = "RowHeaderRenderer6"
        RowHeaderRenderer6.PictureZoomEffect = False
        RowHeaderRenderer6.TextRotationAngle = 0R
        RowHeaderRenderer6.ZoomFactor = 1.0!
        ColumnHeaderRenderer5.Name = "ColumnHeaderRenderer5"
        ColumnHeaderRenderer5.PictureZoomEffect = False
        ColumnHeaderRenderer5.TextRotationAngle = 0R
        ColumnHeaderRenderer5.ZoomFactor = 1.0!
        ColumnHeaderRenderer6.Name = "ColumnHeaderRenderer6"
        ColumnHeaderRenderer6.PictureZoomEffect = False
        ColumnHeaderRenderer6.TextRotationAngle = 0R
        ColumnHeaderRenderer6.ZoomFactor = 1.0!
        RowHeaderRenderer7.Name = "RowHeaderRenderer7"
        RowHeaderRenderer7.PictureZoomEffect = False
        RowHeaderRenderer7.TextRotationAngle = 0R
        RowHeaderRenderer7.ZoomFactor = 1.0!
        RowHeaderRenderer8.Name = "RowHeaderRenderer8"
        RowHeaderRenderer8.PictureZoomEffect = False
        RowHeaderRenderer8.TextRotationAngle = 0R
        RowHeaderRenderer8.ZoomFactor = 1.0!
        RowHeaderRenderer9.Name = "RowHeaderRenderer9"
        RowHeaderRenderer9.PictureZoomEffect = False
        RowHeaderRenderer9.TextRotationAngle = 0R
        RowHeaderRenderer9.ZoomFactor = 1.0!
        RowHeaderRenderer10.Name = "RowHeaderRenderer10"
        RowHeaderRenderer10.PictureZoomEffect = False
        RowHeaderRenderer10.TextRotationAngle = 0R
        RowHeaderRenderer10.ZoomFactor = 1.0!
        '
        'Picture1
        '
        Me.Picture1.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Picture1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Picture1.Controls.Add(Me._cmdKey_1)
        Me.Picture1.Controls.Add(Me._cmdKey_12)
        Me.Picture1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Picture1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Picture1.Font = New System.Drawing.Font("MS PGothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Picture1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Picture1.Location = New System.Drawing.Point(0, 494)
        Me.Picture1.Name = "Picture1"
        Me.Picture1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Picture1.Size = New System.Drawing.Size(804, 51)
        Me.Picture1.TabIndex = 5
        '
        '_cmdKey_1
        '
        Me._cmdKey_1.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_1.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_1.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_1.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_1.Location = New System.Drawing.Point(4, 4)
        Me._cmdKey_1.Name = "_cmdKey_1"
        Me._cmdKey_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_1.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_1.TabIndex = 1
        Me._cmdKey_1.Tag = "�I���f�[�^�����肵�܂��B"
        Me._cmdKey_1.Text = "F1" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "�� ��"
        Me._cmdKey_1.UseVisualStyleBackColor = False
        '
        '_cmdKey_12
        '
        Me._cmdKey_12.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_12.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_12.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_12.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_12.Location = New System.Drawing.Point(718, 4)
        Me._cmdKey_12.Name = "_cmdKey_12"
        Me._cmdKey_12.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_12.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_12.TabIndex = 2
        Me._cmdKey_12.Tag = "������ʂ��I�����܂��B"
        Me._cmdKey_12.Text = "F12" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "�I ��"
        Me._cmdKey_12.UseVisualStyleBackColor = False
        '
        'StatusBar1
        '
        Me.StatusBar1.Font = New System.Drawing.Font("MS Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.StatusBar1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me._StatusBar1_Panel2, Me.Message})
        Me.StatusBar1.Location = New System.Drawing.Point(0, 545)
        Me.StatusBar1.Name = "StatusBar1"
        Me.StatusBar1.Size = New System.Drawing.Size(804, 23)
        Me.StatusBar1.SizingGrip = False
        Me.StatusBar1.TabIndex = 4
        '
        '_StatusBar1_Panel2
        '
        Me._StatusBar1_Panel2.AutoSize = False
        Me._StatusBar1_Panel2.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me._StatusBar1_Panel2.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter
        Me._StatusBar1_Panel2.Margin = New System.Windows.Forms.Padding(0)
        Me._StatusBar1_Panel2.Name = "_StatusBar1_Panel2"
        Me._StatusBar1_Panel2.Size = New System.Drawing.Size(117, 23)
        '
        'Message
        '
        Me.Message.AutoSize = False
        Me.Message.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me.Message.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter
        Me.Message.Margin = New System.Windows.Forms.Padding(0)
        Me.Message.Name = "Message"
        Me.Message.Size = New System.Drawing.Size(675, 23)
        Me.Message.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblTitle
        '
        Me.lblTitle.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.lblTitle.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTitle.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblTitle.Font = New System.Drawing.Font("MS Mincho", 20.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblTitle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.lblTitle.Location = New System.Drawing.Point(0, 0)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblTitle.Size = New System.Drawing.Size(803, 31)
        Me.lblTitle.TabIndex = 3
        Me.lblTitle.Text = " ���o��񌟍�"
        '
        'FpSpread1
        '
        Me.FpSpread1.AccessibleDescription = "FpSpread1, Sheet1, Row 0, Column 0"
        Me.FpSpread1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.FpSpread1.FocusRenderer = DefaultFocusIndicatorRenderer1
        Me.FpSpread1.HorizontalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.FpSpread1.HorizontalScrollBar.Name = ""
        Me.FpSpread1.HorizontalScrollBar.Renderer = DefaultScrollBarRenderer1
        Me.FpSpread1.HorizontalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.Never
        Me.FpSpread1.Location = New System.Drawing.Point(8, 40)
        Me.FpSpread1.Name = "FpSpread1"
        NamedStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        NamedStyle1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        NamedStyle1.Locked = False
        NamedStyle2.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        NamedStyle2.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold)
        NamedStyle2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        NamedStyle2.Locked = False
        NamedStyle3.BackColor = System.Drawing.SystemColors.Control
        FilterBarCellType1.FormatString = ""
        NamedStyle3.CellType = FilterBarCellType1
        NamedStyle3.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle3.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle3.Renderer = FilterBarCellType1
        NamedStyle3.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle4.BackColor = System.Drawing.SystemColors.Control
        NamedStyle4.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle4.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle4.Renderer = ColumnHeaderRenderer4
        NamedStyle4.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle5.BackColor = System.Drawing.SystemColors.Control
        NamedStyle5.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle5.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle5.Renderer = RowHeaderRenderer6
        NamedStyle5.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle6.BackColor = System.Drawing.Color.Empty
        NamedStyle6.CellType = GeneralCellType1
        NamedStyle6.ForeColor = System.Drawing.SystemColors.WindowText
        NamedStyle6.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.General
        NamedStyle6.Renderer = GeneralCellType1
        NamedStyle6.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.General
        Me.FpSpread1.RowSplitBoxPolicy = FarPoint.Win.Spread.SplitBoxPolicy.Never
        Me.FpSpread1.SelectionBlockOptions = FarPoint.Win.Spread.SelectionBlockOptions.None
        Me.FpSpread1.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.FpSpread1_Sheet1})
        Me.FpSpread1.Size = New System.Drawing.Size(787, 445)
        NamedStyle7.BackColor = System.Drawing.SystemColors.Control
        NamedStyle7.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle7.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle7.Renderer = ColumnHeaderRenderer5
        NamedStyle7.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle7.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        SpreadSkin1.ColumnFooterDefaultStyle = NamedStyle7
        NamedStyle8.BackColor = System.Drawing.SystemColors.Control
        NamedStyle8.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle8.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle8.Renderer = ColumnHeaderRenderer6
        NamedStyle8.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle8.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        SpreadSkin1.ColumnHeaderDefaultStyle = NamedStyle8
        NamedStyle9.BackColor = System.Drawing.SystemColors.Control
        NamedStyle9.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle9.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle9.Renderer = RowHeaderRenderer7
        NamedStyle9.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle9.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        SpreadSkin1.CornerDefaultStyle = NamedStyle9
        NamedStyle10.BackColor = System.Drawing.SystemColors.Control
        NamedStyle10.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle10.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle10.Renderer = RowHeaderRenderer8
        NamedStyle10.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle10.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        SpreadSkin1.CornerFooterDefaultStyle = NamedStyle10
        NamedStyle11.BackColor = System.Drawing.Color.Empty
        NamedStyle11.CellType = GeneralCellType2
        NamedStyle11.ForeColor = System.Drawing.SystemColors.WindowText
        NamedStyle11.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.General
        NamedStyle11.Renderer = GeneralCellType2
        NamedStyle11.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.General
        NamedStyle11.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        SpreadSkin1.DefaultStyle = NamedStyle11
        NamedStyle12.BackColor = System.Drawing.SystemColors.Control
        FilterBarCellType2.FormatString = ""
        NamedStyle12.CellType = FilterBarCellType2
        NamedStyle12.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle12.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle12.Renderer = FilterBarCellType2
        NamedStyle12.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle12.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        SpreadSkin1.FilterBarDefaultStyle = NamedStyle12
        NamedStyle13.BackColor = System.Drawing.SystemColors.Control
        NamedStyle13.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle13.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle13.Renderer = RowHeaderRenderer9
        NamedStyle13.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle13.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        SpreadSkin1.FilterBarHeaderDefaultStyle = NamedStyle13
        SpreadSkin1.FocusRenderer = DefaultFocusIndicatorRenderer1
        SpreadSkin1.Name = "CustomSkin1"
        NamedStyle14.BackColor = System.Drawing.SystemColors.Control
        NamedStyle14.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle14.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle14.Renderer = RowHeaderRenderer10
        NamedStyle14.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle14.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        SpreadSkin1.RowHeaderDefaultStyle = NamedStyle14
        SpreadSkin1.ScrollBarRenderer = DefaultScrollBarRenderer2
        SpreadSkin1.SelectionRenderer = New FarPoint.Win.Spread.DefaultSelectionRenderer()
        StatusBarSkin1.BackColor = System.Drawing.SystemColors.Control
        StatusBarSkin1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        StatusBarSkin1.ForeColor = System.Drawing.SystemColors.ControlText
        StatusBarSkin1.Name = "Classic"
        StatusBarSkin1.ZoomButtonHoverColor = System.Drawing.SystemColors.ButtonHighlight
        StatusBarSkin1.ZoomSliderColor = System.Drawing.SystemColors.ControlDarkDark
        StatusBarSkin1.ZoomSliderHoverColor = System.Drawing.SystemColors.ControlDark
        StatusBarSkin1.ZoomSliderTrackColor = System.Drawing.SystemColors.ControlDarkDark
        SpreadSkin1.StatusBarSkin = StatusBarSkin1
        Me.FpSpread1.Skin = SpreadSkin1
        Me.FpSpread1.NamedStyles.AddRange(New FarPoint.Win.Spread.NamedStyle() {NamedStyle1, NamedStyle2, NamedStyle3, NamedStyle4, NamedStyle5, NamedStyle6})
        Me.FpSpread1.TabIndex = 0
        Me.FpSpread1.Tag = "�f�[�^��I�����ĉ������B"
        TipAppearance1.BackColor = System.Drawing.SystemColors.Info
        TipAppearance1.Font = New System.Drawing.Font("MS PGothic", 9.0!)
        TipAppearance1.ForeColor = System.Drawing.SystemColors.InfoText
        Me.FpSpread1.TextTipAppearance = TipAppearance1
        Me.FpSpread1.VerticalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.FpSpread1.VerticalScrollBar.Name = ""
        Me.FpSpread1.VerticalScrollBar.Renderer = DefaultScrollBarRenderer3
        '
        'FpSpread1_Sheet1
        '
        Me.FpSpread1_Sheet1.Reset()
        Me.FpSpread1_Sheet1.SheetName = "Sheet1"
        'Formulas and custom names must be loaded with R1C1 reference style
        Me.FpSpread1_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1
        Me.FpSpread1_Sheet1.ColumnCount = 6
        Me.FpSpread1_Sheet1.RowCount = 20
        Me.FpSpread1_Sheet1.ActiveSkin = FarPoint.Win.Spread.DefaultSkins.Default
        Me.FpSpread1_Sheet1.Cells.Get(0, 0).Value = "1234567890123456789012345678901234567890"
        Me.FpSpread1_Sheet1.Cells.Get(0, 1).Value = "9,999.99"
        Me.FpSpread1_Sheet1.Cells.Get(0, 2).Value = "1234"
        Me.FpSpread1_Sheet1.Cells.Get(0, 3).Value = "999,999,999"
        Me.FpSpread1_Sheet1.Cells.Get(0, 4).Value = "999,999,999"
        Me.FpSpread1_Sheet1.ColumnFooter.Columns.Default.Resizable = False
        Me.FpSpread1_Sheet1.ColumnFooter.Columns.Default.SortIndicator = FarPoint.Win.Spread.Model.SortIndicator.None
        Me.FpSpread1_Sheet1.ColumnFooter.Columns.Default.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread1_Sheet1.ColumnFooter.DefaultStyle.BackColor = System.Drawing.Color.Empty
        Me.FpSpread1_Sheet1.ColumnFooter.DefaultStyle.ForeColor = System.Drawing.Color.Empty
        Me.FpSpread1_Sheet1.ColumnFooter.DefaultStyle.Locked = False
        Me.FpSpread1_Sheet1.ColumnFooter.DefaultStyle.Parent = "HeaderDefault"
        Me.FpSpread1_Sheet1.ColumnFooter.DefaultStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread1_Sheet1.ColumnFooter.Rows.Default.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread1_Sheet1.ColumnFooterSheetCornerStyle.BackColor = System.Drawing.Color.Empty
        Me.FpSpread1_Sheet1.ColumnFooterSheetCornerStyle.ForeColor = System.Drawing.Color.Empty
        Me.FpSpread1_Sheet1.ColumnFooterSheetCornerStyle.Locked = False
        Me.FpSpread1_Sheet1.ColumnFooterSheetCornerStyle.Parent = "RowHeaderDefault"
        Me.FpSpread1_Sheet1.ColumnFooterSheetCornerStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 0).Value = "���@�@�@�@�@��"
        Me.FpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = "����"
        Me.FpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 2).Value = "�P��"
        Me.FpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 3).Value = "�P ��"
        Me.FpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 4).Value = "�� �z"
        Me.FpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 5).Value = "�ԍ�"
        Me.FpSpread1_Sheet1.ColumnHeader.Columns.Default.Resizable = False
        Me.FpSpread1_Sheet1.ColumnHeader.Columns.Default.SortIndicator = FarPoint.Win.Spread.Model.SortIndicator.None
        Me.FpSpread1_Sheet1.ColumnHeader.Columns.Default.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread1_Sheet1.ColumnHeader.DefaultStyle.BackColor = System.Drawing.Color.Empty
        Me.FpSpread1_Sheet1.ColumnHeader.DefaultStyle.Border = LineBorder1
        Me.FpSpread1_Sheet1.ColumnHeader.DefaultStyle.CellType = TextCellType1
        Me.FpSpread1_Sheet1.ColumnHeader.DefaultStyle.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FpSpread1_Sheet1.ColumnHeader.DefaultStyle.ForeColor = System.Drawing.Color.Black
        Me.FpSpread1_Sheet1.ColumnHeader.DefaultStyle.Locked = True
        Me.FpSpread1_Sheet1.ColumnHeader.DefaultStyle.LockFont = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FpSpread1_Sheet1.ColumnHeader.DefaultStyle.LockForeColor = System.Drawing.Color.Black
        Me.FpSpread1_Sheet1.ColumnHeader.DefaultStyle.Parent = "HeaderDefault"
        Me.FpSpread1_Sheet1.ColumnHeader.DefaultStyle.Renderer = TextCellType1
        Me.FpSpread1_Sheet1.ColumnHeader.DefaultStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread1_Sheet1.ColumnHeader.Rows.Default.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread1_Sheet1.ColumnHeader.Rows.Get(0).Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.FpSpread1_Sheet1.ColumnHeader.Rows.Get(0).ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.FpSpread1_Sheet1.ColumnHeader.Rows.Get(0).Height = 23.0!
        Me.FpSpread1_Sheet1.ColumnHeader.Rows.Get(0).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.General
        Me.FpSpread1_Sheet1.ColumnHeader.Rows.Get(0).Locked = True
        Me.FpSpread1_Sheet1.ColumnHeader.Rows.Get(0).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread1_Sheet1.Columns.Default.Resizable = False
        Me.FpSpread1_Sheet1.Columns.Default.SortIndicator = FarPoint.Win.Spread.Model.SortIndicator.None
        TextCellType2.Static = True
        Me.FpSpread1_Sheet1.Columns.Get(0).CellType = TextCellType2
        Me.FpSpread1_Sheet1.Columns.Get(0).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Left
        Me.FpSpread1_Sheet1.Columns.Get(0).Label = "���@�@�@�@�@��"
        Me.FpSpread1_Sheet1.Columns.Get(0).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread1_Sheet1.Columns.Get(0).Width = 370.0!
        TextCellType3.Static = True
        Me.FpSpread1_Sheet1.Columns.Get(1).CellType = TextCellType3
        Me.FpSpread1_Sheet1.Columns.Get(1).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Right
        Me.FpSpread1_Sheet1.Columns.Get(1).Label = "����"
        Me.FpSpread1_Sheet1.Columns.Get(1).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread1_Sheet1.Columns.Get(1).Width = 80.0!
        TextCellType4.Static = True
        Me.FpSpread1_Sheet1.Columns.Get(2).CellType = TextCellType4
        Me.FpSpread1_Sheet1.Columns.Get(2).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.FpSpread1_Sheet1.Columns.Get(2).Label = "�P��"
        Me.FpSpread1_Sheet1.Columns.Get(2).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread1_Sheet1.Columns.Get(3).CellType = TextCellType3
        Me.FpSpread1_Sheet1.Columns.Get(3).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Right
        Me.FpSpread1_Sheet1.Columns.Get(3).Label = "�P ��"
        Me.FpSpread1_Sheet1.Columns.Get(3).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread1_Sheet1.Columns.Get(3).Width = 108.0!
        Me.FpSpread1_Sheet1.Columns.Get(4).CellType = TextCellType3
        Me.FpSpread1_Sheet1.Columns.Get(4).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Right
        Me.FpSpread1_Sheet1.Columns.Get(4).Label = "�� �z"
        Me.FpSpread1_Sheet1.Columns.Get(4).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread1_Sheet1.Columns.Get(4).Width = 108.0!
        Me.FpSpread1_Sheet1.Columns.Get(5).CellType = TextCellType3
        Me.FpSpread1_Sheet1.Columns.Get(5).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Right
        Me.FpSpread1_Sheet1.Columns.Get(5).Label = "�ԍ�"
        Me.FpSpread1_Sheet1.Columns.Get(5).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread1_Sheet1.Columns.Get(5).Visible = False
        Me.FpSpread1_Sheet1.Columns.Get(5).Width = 0!
        Me.FpSpread1_Sheet1.DefaultStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        TextCellType5.MaxLength = 60
        Me.FpSpread1_Sheet1.DefaultStyle.CellType = TextCellType5
        Me.FpSpread1_Sheet1.DefaultStyle.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold)
        Me.FpSpread1_Sheet1.DefaultStyle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.FpSpread1_Sheet1.DefaultStyle.Locked = False
        Me.FpSpread1_Sheet1.DefaultStyle.Parent = "DataAreaDefault"
        Me.FpSpread1_Sheet1.DefaultStyle.Renderer = TextCellType5
        Me.FpSpread1_Sheet1.FilterBar.DefaultStyle.BackColor = System.Drawing.Color.Empty
        Me.FpSpread1_Sheet1.FilterBar.DefaultStyle.ForeColor = System.Drawing.Color.Empty
        Me.FpSpread1_Sheet1.FilterBar.DefaultStyle.Locked = False
        Me.FpSpread1_Sheet1.FilterBar.DefaultStyle.Parent = "FilterBarDefault"
        Me.FpSpread1_Sheet1.FilterBar.DefaultStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread1_Sheet1.FilterBarHeaderStyle.BackColor = System.Drawing.Color.Empty
        Me.FpSpread1_Sheet1.FilterBarHeaderStyle.ForeColor = System.Drawing.Color.Empty
        Me.FpSpread1_Sheet1.FilterBarHeaderStyle.Locked = False
        Me.FpSpread1_Sheet1.FilterBarHeaderStyle.Parent = "RowHeaderDefault"
        Me.FpSpread1_Sheet1.FilterBarHeaderStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread1_Sheet1.OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        Me.FpSpread1_Sheet1.Protect = True
        Me.FpSpread1_Sheet1.RowHeader.Columns.Default.Resizable = False
        Me.FpSpread1_Sheet1.RowHeader.Columns.Default.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread1_Sheet1.RowHeader.Columns.Get(0).Width = 42.0!
        Me.FpSpread1_Sheet1.RowHeader.DefaultStyle.BackColor = System.Drawing.Color.Empty
        Me.FpSpread1_Sheet1.RowHeader.DefaultStyle.Border = LineBorder2
        Me.FpSpread1_Sheet1.RowHeader.DefaultStyle.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FpSpread1_Sheet1.RowHeader.DefaultStyle.ForeColor = System.Drawing.Color.Empty
        Me.FpSpread1_Sheet1.RowHeader.DefaultStyle.Locked = False
        Me.FpSpread1_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderDefault"
        Me.FpSpread1_Sheet1.RowHeader.DefaultStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread1_Sheet1.RowHeader.Rows.Default.Resizable = False
        Me.FpSpread1_Sheet1.RowHeader.Rows.Default.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread1_Sheet1.Rows.Default.Resizable = False
        Me.FpSpread1_Sheet1.SelectionUnit = FarPoint.Win.Spread.Model.SelectionUnit.Row
        Me.FpSpread1_Sheet1.SheetCornerStyle.BackColor = System.Drawing.Color.Empty
        Me.FpSpread1_Sheet1.SheetCornerStyle.ForeColor = System.Drawing.Color.Empty
        Me.FpSpread1_Sheet1.SheetCornerStyle.Locked = False
        Me.FpSpread1_Sheet1.SheetCornerStyle.Parent = "RowHeaderDefault"
        Me.FpSpread1_Sheet1.SheetCornerStyle.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread1_Sheet1.SheetCornerStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread1_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1
        '
        'frmWaridasi
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(804, 568)
        Me.Controls.Add(Me.FpSpread1)
        Me.Controls.Add(Me.Picture1)
        Me.Controls.Add(Me.StatusBar1)
        Me.Controls.Add(Me.lblTitle)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.KeyPreview = True
        Me.Location = New System.Drawing.Point(113, 127)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmWaridasi"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "�������"
        Me.Picture1.ResumeLayout(False)
        Me.StatusBar1.ResumeLayout(False)
        Me.StatusBar1.PerformLayout()
        CType(Me.FpSpread1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.FpSpread1_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents FpSpread1 As FarPoint.Win.Spread.FpSpread
	Friend WithEvents FpSpread1_Sheet1 As FarPoint.Win.Spread.SheetView
#End Region
End Class