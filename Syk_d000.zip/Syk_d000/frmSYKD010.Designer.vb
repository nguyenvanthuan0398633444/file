Imports GrapeCity.Win.Editors

<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frmSYKD010
#Region "Windows Form Designer generated code "
    <System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
        MyBase.New()
        InitializeComponent()
        'This call is required by the Windows Form Designer.
        Me.Command1 = New ArrayList
        Me.Frame1 = New ArrayList
        Me.Picture2 = New ArrayList
        Me.cmdKey = New ArrayList
        Me.imText2 = New ArrayList
        Me.Command1.Add(_Command1_0)
        Me.Command1.Add(_Command1_1)
        Me.Command1.Add(_Command1_2)
        Me.Command1.Add(_Command1_3)
        Me.Command1.Add(_Command1_4)
        Me.Command1.Add(_Command1_5)
        Me.Command1.Add(_Command1_6)
        Me.Command1.Add(_Command1_7)
        Me.Command1.Add(_Command1_8)
        Me.Command1.Add(_Command1_9)
        Me.Command1.Add(_Command1_10)
        Me.Command1.Add(_Command1_11)
        Me.Command1.Add(_Command1_12)
        Me.Command1.Add(_Command1_13)
        Me.Command1.Add(_Command1_14)

        Me.Frame1.Add(_Frame1_0)
        Me.Frame1.Add(_Frame1_1)
        Me.Frame1.Add(_Frame1_2)
        Me.Frame1.Add(_Frame1_3)

        Me.Picture2.Add(_Picture2_0)
        Me.Picture2.Add(_Picture2_1)
        Me.Picture2.Add(_Picture2_2)
        Me.Picture2.Add(_Picture2_3)
        Me.Picture2.Add(_Picture2_4)
        Me.Picture2.Add(_Picture2_5)
        Me.Picture2.Add(_Picture2_6)
        Me.Picture2.Add(_Picture2_7)
        Me.Picture2.Add(_Picture2_8)
        Me.Picture2.Add(_Picture2_9)
        Me.Picture2.Add(_Picture2_10)
        Me.Picture2.Add(_Picture2_11)
        Me.Picture2.Add(_Picture2_12)
        Me.Picture2.Add(_Picture2_13)
        Me.Picture2.Add(_Picture2_14)

        Me.cmdKey.Add(Nothing)
        Me.cmdKey.Add(_cmdKey_1)
        Me.cmdKey.Add(_cmdKey_2)
        Me.cmdKey.Add(_cmdKey_3)
        Me.cmdKey.Add(_cmdKey_4)
        Me.cmdKey.Add(_cmdKey_5)
        Me.cmdKey.Add(_cmdKey_6)
        Me.cmdKey.Add(_cmdKey_7)
        Me.cmdKey.Add(_cmdKey_8)
        Me.cmdKey.Add(_cmdKey_9)
        Me.cmdKey.Add(_cmdKey_10)
        Me.cmdKey.Add(_cmdKey_11)
        Me.cmdKey.Add(_cmdKey_12)

        Me.imText2.Add(_imText2_0)
        Me.imText2.Add(_imText2_1)
        Me.imText2.Add(_imText2_2)
    End Sub
    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
        If Disposing Then
            If Not components Is Nothing Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(Disposing)
    End Sub
    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer
    Public ToolTip1 As System.Windows.Forms.ToolTip
    Public WithEvents VerCommand As System.Windows.Forms.Button
    Public WithEvents VerPicture As System.Windows.Forms.Panel
    Public WithEvents Command2 As System.Windows.Forms.Button
    Public WithEvents Picture3 As System.Windows.Forms.Panel
    Public WithEvents _cmdKey_5 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_2 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_11 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_1 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_9 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_8 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_7 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_6 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_10 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_4 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_12 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_3 As System.Windows.Forms.Button
    Public WithEvents Picture1 As System.Windows.Forms.Panel
    Public WithEvents _StatusBar1_Panel2 As System.Windows.Forms.ToolStripStatusLabel
    Public WithEvents Message As System.Windows.Forms.ToolStripStatusLabel
    Public WithEvents StatusBar1 As System.Windows.Forms.StatusStrip
    Public WithEvents imText1 As GcTextBox
    Public WithEvents _imText2_2 As GcTextBox
    Public WithEvents _imText2_0 As GcTextBox
    Public WithEvents _imText2_1 As GcTextBox
    Public WithEvents _Command1_14 As System.Windows.Forms.Button
    Public WithEvents _Command1_13 As System.Windows.Forms.Button
    Public WithEvents _Command1_12 As System.Windows.Forms.Button
    Public WithEvents _Command1_11 As System.Windows.Forms.Button
    Public WithEvents _Command1_10 As System.Windows.Forms.Button
    Public WithEvents _Command1_9 As System.Windows.Forms.Button
    Public WithEvents _Command1_8 As System.Windows.Forms.Button
    Public WithEvents _Command1_7 As System.Windows.Forms.Button
    Public WithEvents _Command1_6 As System.Windows.Forms.Button
    Public WithEvents _Command1_5 As System.Windows.Forms.Button
    Public WithEvents _Command1_4 As System.Windows.Forms.Button
    Public WithEvents _Command1_3 As System.Windows.Forms.Button
    Public WithEvents _Command1_2 As System.Windows.Forms.Button
    Public WithEvents _Command1_1 As System.Windows.Forms.Button
    Public WithEvents _Command1_0 As System.Windows.Forms.Button
    Public WithEvents _Picture2_14 As System.Windows.Forms.PictureBox
    Public WithEvents _Picture2_13 As System.Windows.Forms.PictureBox
    Public WithEvents _Frame1_4 As System.Windows.Forms.GroupBox
    Public WithEvents _Picture2_5 As System.Windows.Forms.PictureBox
    Public WithEvents _Picture2_1 As System.Windows.Forms.PictureBox
    Public WithEvents _Picture2_2 As System.Windows.Forms.PictureBox
    Public WithEvents _Picture2_3 As System.Windows.Forms.PictureBox
    Public WithEvents _Picture2_4 As System.Windows.Forms.PictureBox
    Public WithEvents _Frame1_1 As System.Windows.Forms.GroupBox
    Public WithEvents _Picture2_9 As System.Windows.Forms.PictureBox
    Public WithEvents _Picture2_7 As System.Windows.Forms.PictureBox
    Public WithEvents _Picture2_6 As System.Windows.Forms.PictureBox
    Public WithEvents _Picture2_8 As System.Windows.Forms.PictureBox
    Public WithEvents _Frame1_3 As System.Windows.Forms.GroupBox
    Public WithEvents _Picture2_0 As System.Windows.Forms.PictureBox
    Public WithEvents _Frame1_0 As System.Windows.Forms.GroupBox
    Public WithEvents _Picture2_12 As System.Windows.Forms.PictureBox
    Public WithEvents _Picture2_10 As System.Windows.Forms.PictureBox
    Public WithEvents _Picture2_11 As System.Windows.Forms.PictureBox
    Public WithEvents _Frame1_2 As System.Windows.Forms.GroupBox
    Public WithEvents Picture4 As System.Windows.Forms.Panel
    Public WithEvents Label1 As System.Windows.Forms.Label
    Public WithEvents lblTitle As System.Windows.Forms.Label
    Public WithEvents Command1 As ArrayList
    Public WithEvents Frame1 As ArrayList
    Public WithEvents Picture2 As ArrayList
    Public WithEvents cmdKey As ArrayList
    Public WithEvents imText2 As ArrayList
    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmSYKD010))
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.VerPicture = New System.Windows.Forms.Panel()
        Me.VerCommand = New System.Windows.Forms.Button()
        Me.Picture3 = New System.Windows.Forms.Panel()
        Me.Command2 = New System.Windows.Forms.Button()
        Me.Picture1 = New System.Windows.Forms.Panel()
        Me._cmdKey_5 = New System.Windows.Forms.Button()
        Me._cmdKey_2 = New System.Windows.Forms.Button()
        Me._cmdKey_11 = New System.Windows.Forms.Button()
        Me._cmdKey_1 = New System.Windows.Forms.Button()
        Me._cmdKey_9 = New System.Windows.Forms.Button()
        Me._cmdKey_8 = New System.Windows.Forms.Button()
        Me._cmdKey_7 = New System.Windows.Forms.Button()
        Me._cmdKey_6 = New System.Windows.Forms.Button()
        Me._cmdKey_10 = New System.Windows.Forms.Button()
        Me._cmdKey_4 = New System.Windows.Forms.Button()
        Me._cmdKey_12 = New System.Windows.Forms.Button()
        Me._cmdKey_3 = New System.Windows.Forms.Button()
        Me.StatusBar1 = New System.Windows.Forms.StatusStrip()
        Me._StatusBar1_Panel2 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.Message = New System.Windows.Forms.ToolStripStatusLabel()
        Me.imText1 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._imText2_2 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._imText2_0 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._imText2_1 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me.Picture4 = New System.Windows.Forms.Panel()
        Me._Command1_14 = New System.Windows.Forms.Button()
        Me._Command1_13 = New System.Windows.Forms.Button()
        Me._Command1_12 = New System.Windows.Forms.Button()
        Me._Command1_11 = New System.Windows.Forms.Button()
        Me._Command1_10 = New System.Windows.Forms.Button()
        Me._Command1_9 = New System.Windows.Forms.Button()
        Me._Command1_8 = New System.Windows.Forms.Button()
        Me._Command1_7 = New System.Windows.Forms.Button()
        Me._Command1_6 = New System.Windows.Forms.Button()
        Me._Command1_5 = New System.Windows.Forms.Button()
        Me._Command1_4 = New System.Windows.Forms.Button()
        Me._Command1_3 = New System.Windows.Forms.Button()
        Me._Command1_2 = New System.Windows.Forms.Button()
        Me._Command1_1 = New System.Windows.Forms.Button()
        Me._Command1_0 = New System.Windows.Forms.Button()
        Me._Frame1_4 = New System.Windows.Forms.GroupBox()
        Me._Picture2_14 = New System.Windows.Forms.PictureBox()
        Me._Picture2_13 = New System.Windows.Forms.PictureBox()
        Me._Frame1_1 = New System.Windows.Forms.GroupBox()
        Me._Picture2_5 = New System.Windows.Forms.PictureBox()
        Me._Picture2_1 = New System.Windows.Forms.PictureBox()
        Me._Picture2_2 = New System.Windows.Forms.PictureBox()
        Me._Picture2_3 = New System.Windows.Forms.PictureBox()
        Me._Picture2_4 = New System.Windows.Forms.PictureBox()
        Me._Frame1_3 = New System.Windows.Forms.GroupBox()
        Me._Picture2_9 = New System.Windows.Forms.PictureBox()
        Me._Picture2_7 = New System.Windows.Forms.PictureBox()
        Me._Picture2_6 = New System.Windows.Forms.PictureBox()
        Me._Picture2_8 = New System.Windows.Forms.PictureBox()
        Me._Frame1_0 = New System.Windows.Forms.GroupBox()
        Me._Picture2_0 = New System.Windows.Forms.PictureBox()
        Me._Frame1_2 = New System.Windows.Forms.GroupBox()
        Me._Picture2_12 = New System.Windows.Forms.PictureBox()
        Me._Picture2_10 = New System.Windows.Forms.PictureBox()
        Me._Picture2_11 = New System.Windows.Forms.PictureBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.VerPicture.SuspendLayout()
        Me.Picture3.SuspendLayout()
        Me.Picture1.SuspendLayout()
        Me.StatusBar1.SuspendLayout()
        CType(Me.imText1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imText2_2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imText2_0, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imText2_1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Picture4.SuspendLayout()
        Me._Frame1_4.SuspendLayout()
        CType(Me._Picture2_14, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._Picture2_13, System.ComponentModel.ISupportInitialize).BeginInit()
        Me._Frame1_1.SuspendLayout()
        CType(Me._Picture2_5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._Picture2_1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._Picture2_2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._Picture2_3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._Picture2_4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me._Frame1_3.SuspendLayout()
        CType(Me._Picture2_9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._Picture2_7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._Picture2_6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._Picture2_8, System.ComponentModel.ISupportInitialize).BeginInit()
        Me._Frame1_0.SuspendLayout()
        CType(Me._Picture2_0, System.ComponentModel.ISupportInitialize).BeginInit()
        Me._Frame1_2.SuspendLayout()
        CType(Me._Picture2_12, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._Picture2_10, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._Picture2_11, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'VerPicture
        '
        Me.VerPicture.BackColor = System.Drawing.SystemColors.Control
        Me.VerPicture.Controls.Add(Me.VerCommand)
        Me.VerPicture.Cursor = System.Windows.Forms.Cursors.Default
        Me.VerPicture.Enabled = False
        Me.VerPicture.ForeColor = System.Drawing.SystemColors.ControlText
        Me.VerPicture.Location = New System.Drawing.Point(916, 42)
        Me.VerPicture.Name = "VerPicture"
        Me.VerPicture.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.VerPicture.Size = New System.Drawing.Size(95, 27)
        Me.VerPicture.TabIndex = 58
        Me.VerPicture.TabStop = True
        '
        'VerCommand
        '
        Me.VerCommand.BackColor = System.Drawing.SystemColors.Control
        Me.VerCommand.Cursor = System.Windows.Forms.Cursors.Default
        Me.VerCommand.Enabled = False
        Me.VerCommand.Font = New System.Drawing.Font("MS Mincho", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.VerCommand.ForeColor = System.Drawing.SystemColors.ControlText
        Me.VerCommand.Location = New System.Drawing.Point(-6, -6)
        Me.VerCommand.Name = "VerCommand"
        Me.VerCommand.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.VerCommand.Size = New System.Drawing.Size(105, 39)
        Me.VerCommand.TabIndex = 59
        Me.VerCommand.Text = " Ver9.99 "
        Me.VerCommand.UseVisualStyleBackColor = False
        '
        'Picture3
        '
        Me.Picture3.BackColor = System.Drawing.SystemColors.Control
        Me.Picture3.Controls.Add(Me.Command2)
        Me.Picture3.Cursor = System.Windows.Forms.Cursors.Default
        Me.Picture3.Enabled = False
        Me.Picture3.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Picture3.Location = New System.Drawing.Point(602, 36)
        Me.Picture3.Name = "Picture3"
        Me.Picture3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Picture3.Size = New System.Drawing.Size(311, 43)
        Me.Picture3.TabIndex = 35
        Me.Picture3.Visible = False
        '
        'Command2
        '
        Me.Command2.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Command2.Cursor = System.Windows.Forms.Cursors.Default
        Me.Command2.Font = New System.Drawing.Font("MS Mincho", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Command2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Command2.Location = New System.Drawing.Point(0, 0)
        Me.Command2.Name = "Command2"
        Me.Command2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Command2.Size = New System.Drawing.Size(311, 43)
        Me.Command2.TabIndex = 36
        Me.Command2.TabStop = False
        Me.Command2.Text = "�f�[�^�̓]�������     "
        Me.Command2.UseVisualStyleBackColor = False
        '
        'Picture1
        '
        Me.Picture1.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Picture1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Picture1.Controls.Add(Me._cmdKey_5)
        Me.Picture1.Controls.Add(Me._cmdKey_2)
        Me.Picture1.Controls.Add(Me._cmdKey_11)
        Me.Picture1.Controls.Add(Me._cmdKey_1)
        Me.Picture1.Controls.Add(Me._cmdKey_9)
        Me.Picture1.Controls.Add(Me._cmdKey_8)
        Me.Picture1.Controls.Add(Me._cmdKey_7)
        Me.Picture1.Controls.Add(Me._cmdKey_6)
        Me.Picture1.Controls.Add(Me._cmdKey_10)
        Me.Picture1.Controls.Add(Me._cmdKey_4)
        Me.Picture1.Controls.Add(Me._cmdKey_12)
        Me.Picture1.Controls.Add(Me._cmdKey_3)
        Me.Picture1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Picture1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Picture1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Picture1.Location = New System.Drawing.Point(0, 668)
        Me.Picture1.Name = "Picture1"
        Me.Picture1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Picture1.Size = New System.Drawing.Size(1016, 51)
        Me.Picture1.TabIndex = 28
        '
        '_cmdKey_5
        '
        Me._cmdKey_5.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_5.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_5.Enabled = False
        Me._cmdKey_5.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_5.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_5.Location = New System.Drawing.Point(348, 4)
        Me._cmdKey_5.Name = "_cmdKey_5"
        Me._cmdKey_5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_5.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_5.TabIndex = 19
        Me._cmdKey_5.Text = "F5"
        Me._cmdKey_5.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_5.UseVisualStyleBackColor = False
        '
        '_cmdKey_2
        '
        Me._cmdKey_2.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_2.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_2.Enabled = False
        Me._cmdKey_2.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_2.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_2.Location = New System.Drawing.Point(86, 4)
        Me._cmdKey_2.Name = "_cmdKey_2"
        Me._cmdKey_2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_2.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_2.TabIndex = 16
        Me._cmdKey_2.Text = "F2"
        Me._cmdKey_2.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_2.UseVisualStyleBackColor = False
        '
        '_cmdKey_11
        '
        Me._cmdKey_11.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_11.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_11.Enabled = False
        Me._cmdKey_11.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_11.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_11.Location = New System.Drawing.Point(849, 4)
        Me._cmdKey_11.Name = "_cmdKey_11"
        Me._cmdKey_11.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_11.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_11.TabIndex = 25
        Me._cmdKey_11.Text = "F11"
        Me._cmdKey_11.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_11.UseVisualStyleBackColor = False
        '
        '_cmdKey_1
        '
        Me._cmdKey_1.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_1.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_1.Enabled = False
        Me._cmdKey_1.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_1.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_1.Location = New System.Drawing.Point(6, 4)
        Me._cmdKey_1.Name = "_cmdKey_1"
        Me._cmdKey_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_1.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_1.TabIndex = 15
        Me._cmdKey_1.Text = "F1"
        Me._cmdKey_1.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_1.UseVisualStyleBackColor = False
        '
        '_cmdKey_9
        '
        Me._cmdKey_9.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_9.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_9.Enabled = False
        Me._cmdKey_9.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_9.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_9.Location = New System.Drawing.Point(689, 4)
        Me._cmdKey_9.Name = "_cmdKey_9"
        Me._cmdKey_9.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_9.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_9.TabIndex = 23
        Me._cmdKey_9.Text = "F9"
        Me._cmdKey_9.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_9.UseVisualStyleBackColor = False
        '
        '_cmdKey_8
        '
        Me._cmdKey_8.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_8.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_8.Enabled = False
        Me._cmdKey_8.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_8.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_8.Location = New System.Drawing.Point(588, 4)
        Me._cmdKey_8.Name = "_cmdKey_8"
        Me._cmdKey_8.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_8.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_8.TabIndex = 22
        Me._cmdKey_8.Text = "F8"
        Me._cmdKey_8.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_8.UseVisualStyleBackColor = False
        '
        '_cmdKey_7
        '
        Me._cmdKey_7.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_7.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_7.Enabled = False
        Me._cmdKey_7.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_7.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_7.Location = New System.Drawing.Point(508, 4)
        Me._cmdKey_7.Name = "_cmdKey_7"
        Me._cmdKey_7.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_7.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_7.TabIndex = 21
        Me._cmdKey_7.Text = "F7"
        Me._cmdKey_7.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_7.UseVisualStyleBackColor = False
        '
        '_cmdKey_6
        '
        Me._cmdKey_6.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_6.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_6.Enabled = False
        Me._cmdKey_6.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_6.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_6.Location = New System.Drawing.Point(428, 4)
        Me._cmdKey_6.Name = "_cmdKey_6"
        Me._cmdKey_6.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_6.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_6.TabIndex = 20
        Me._cmdKey_6.Text = "F6"
        Me._cmdKey_6.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_6.UseVisualStyleBackColor = False
        '
        '_cmdKey_10
        '
        Me._cmdKey_10.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_10.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_10.Enabled = False
        Me._cmdKey_10.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_10.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_10.Location = New System.Drawing.Point(769, 4)
        Me._cmdKey_10.Name = "_cmdKey_10"
        Me._cmdKey_10.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_10.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_10.TabIndex = 24
        Me._cmdKey_10.Text = "F10"
        Me._cmdKey_10.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_10.UseVisualStyleBackColor = False
        '
        '_cmdKey_4
        '
        Me._cmdKey_4.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_4.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_4.Enabled = False
        Me._cmdKey_4.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_4.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_4.Location = New System.Drawing.Point(246, 4)
        Me._cmdKey_4.Name = "_cmdKey_4"
        Me._cmdKey_4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_4.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_4.TabIndex = 18
        Me._cmdKey_4.Text = "F4"
        Me._cmdKey_4.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_4.UseVisualStyleBackColor = False
        '
        '_cmdKey_12
        '
        Me._cmdKey_12.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_12.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_12.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_12.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_12.Location = New System.Drawing.Point(929, 4)
        Me._cmdKey_12.Name = "_cmdKey_12"
        Me._cmdKey_12.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_12.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_12.TabIndex = 26
        Me._cmdKey_12.Tag = "���j���[���I�����܂��B"
        Me._cmdKey_12.Text = "F12" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "�I ��"
        Me._cmdKey_12.UseVisualStyleBackColor = False
        '
        '_cmdKey_3
        '
        Me._cmdKey_3.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_3.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_3.Enabled = False
        Me._cmdKey_3.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_3.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_3.Location = New System.Drawing.Point(166, 4)
        Me._cmdKey_3.Name = "_cmdKey_3"
        Me._cmdKey_3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_3.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_3.TabIndex = 17
        Me._cmdKey_3.Text = "F3"
        Me._cmdKey_3.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_3.UseVisualStyleBackColor = False
        '
        'StatusBar1
        '
        Me.StatusBar1.Font = New System.Drawing.Font("MS Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.StatusBar1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me._StatusBar1_Panel2, Me.Message})
        Me.StatusBar1.Location = New System.Drawing.Point(0, 719)
        Me.StatusBar1.Name = "StatusBar1"
        Me.StatusBar1.Size = New System.Drawing.Size(1016, 23)
        Me.StatusBar1.SizingGrip = False
        Me.StatusBar1.TabIndex = 27
        '
        '_StatusBar1_Panel2
        '
        Me._StatusBar1_Panel2.AutoSize = False
        Me._StatusBar1_Panel2.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me._StatusBar1_Panel2.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter
        Me._StatusBar1_Panel2.Margin = New System.Windows.Forms.Padding(0)
        Me._StatusBar1_Panel2.Name = "_StatusBar1_Panel2"
        Me._StatusBar1_Panel2.Size = New System.Drawing.Size(117, 23)
        '
        'Message
        '
        Me.Message.AutoSize = False
        Me.Message.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me.Message.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter
        Me.Message.Margin = New System.Windows.Forms.Padding(0)
        Me.Message.Name = "Message"
        Me.Message.Size = New System.Drawing.Size(897, 23)
        Me.Message.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'imText1
        '
        Me.imText1.BackColor = System.Drawing.SystemColors.Control
        Me.imText1.ContentAlignment = System.Drawing.ContentAlignment.TopCenter
        Me.imText1.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.imText1.Location = New System.Drawing.Point(118, 44)
        Me.imText1.Name = "imText1"
        Me.imText1.ReadOnly = True
        Me.imText1.Size = New System.Drawing.Size(81, 23)
        Me.imText1.TabIndex = 30
        Me.imText1.TabStop = False
        '
        '_imText2_2
        '
        Me._imText2_2.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me._imText2_2.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._imText2_2.Location = New System.Drawing.Point(577, 6)
        Me._imText2_2.Name = "_imText2_2"
        Me._imText2_2.ReadOnly = True
        Me._imText2_2.Size = New System.Drawing.Size(433, 23)
        Me._imText2_2.TabIndex = 32
        Me._imText2_2.TabStop = False
        '
        '_imText2_0
        '
        Me._imText2_0.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me._imText2_0.ContentAlignment = System.Drawing.ContentAlignment.TopCenter
        Me._imText2_0.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._imText2_0.Location = New System.Drawing.Point(441, 6)
        Me._imText2_0.Name = "_imText2_0"
        Me._imText2_0.ReadOnly = True
        Me._imText2_0.Size = New System.Drawing.Size(83, 23)
        Me._imText2_0.TabIndex = 33
        Me._imText2_0.TabStop = False
        '
        '_imText2_1
        '
        Me._imText2_1.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me._imText2_1.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._imText2_1.Location = New System.Drawing.Point(528, 6)
        Me._imText2_1.Name = "_imText2_1"
        Me._imText2_1.ReadOnly = True
        Me._imText2_1.Size = New System.Drawing.Size(45, 23)
        Me._imText2_1.TabIndex = 34
        Me._imText2_1.TabStop = False
        '
        'Picture4
        '
        Me.Picture4.BackColor = System.Drawing.SystemColors.Control
        Me.Picture4.Controls.Add(Me._Command1_14)
        Me.Picture4.Controls.Add(Me._Command1_13)
        Me.Picture4.Controls.Add(Me._Command1_12)
        Me.Picture4.Controls.Add(Me._Command1_11)
        Me.Picture4.Controls.Add(Me._Command1_10)
        Me.Picture4.Controls.Add(Me._Command1_9)
        Me.Picture4.Controls.Add(Me._Command1_8)
        Me.Picture4.Controls.Add(Me._Command1_7)
        Me.Picture4.Controls.Add(Me._Command1_6)
        Me.Picture4.Controls.Add(Me._Command1_5)
        Me.Picture4.Controls.Add(Me._Command1_4)
        Me.Picture4.Controls.Add(Me._Command1_3)
        Me.Picture4.Controls.Add(Me._Command1_2)
        Me.Picture4.Controls.Add(Me._Command1_1)
        Me.Picture4.Controls.Add(Me._Command1_0)
        Me.Picture4.Controls.Add(Me._Frame1_4)
        Me.Picture4.Controls.Add(Me._Frame1_1)
        Me.Picture4.Controls.Add(Me._Frame1_3)
        Me.Picture4.Controls.Add(Me._Frame1_0)
        Me.Picture4.Controls.Add(Me._Frame1_2)
        Me.Picture4.Cursor = System.Windows.Forms.Cursors.Default
        Me.Picture4.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Picture4.Location = New System.Drawing.Point(12, 70)
        Me.Picture4.Name = "Picture4"
        Me.Picture4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Picture4.Size = New System.Drawing.Size(999, 593)
        Me.Picture4.TabIndex = 27
        '
        '_Command1_14
        '
        Me._Command1_14.BackColor = System.Drawing.SystemColors.Control
        Me._Command1_14.Cursor = System.Windows.Forms.Cursors.Default
        Me._Command1_14.Font = New System.Drawing.Font("MS Mincho", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Command1_14.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Command1_14.Location = New System.Drawing.Point(538, 528)
        Me._Command1_14.Name = "_Command1_14"
        Me._Command1_14.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Command1_14.Size = New System.Drawing.Size(419, 39)
        Me._Command1_14.TabIndex = 14
        Me._Command1_14.Text = "��M�f�[�^�ꗗ"
        Me._Command1_14.UseVisualStyleBackColor = False
        '
        '_Command1_13
        '
        Me._Command1_13.BackColor = System.Drawing.SystemColors.Control
        Me._Command1_13.Cursor = System.Windows.Forms.Cursors.Default
        Me._Command1_13.Font = New System.Drawing.Font("MS Mincho", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Command1_13.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Command1_13.Location = New System.Drawing.Point(34, 528)
        Me._Command1_13.Name = "_Command1_13"
        Me._Command1_13.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Command1_13.Size = New System.Drawing.Size(419, 39)
        Me._Command1_13.TabIndex = 6
        Me._Command1_13.Text = "���M�f�[�^�ꗗ"
        Me._Command1_13.UseVisualStyleBackColor = False
        '
        '_Command1_12
        '
        Me._Command1_12.BackColor = System.Drawing.SystemColors.Control
        Me._Command1_12.Cursor = System.Windows.Forms.Cursors.Default
        Me._Command1_12.Font = New System.Drawing.Font("MS Mincho", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Command1_12.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Command1_12.Location = New System.Drawing.Point(538, 438)
        Me._Command1_12.Name = "_Command1_12"
        Me._Command1_12.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Command1_12.Size = New System.Drawing.Size(419, 39)
        Me._Command1_12.TabIndex = 13
        Me._Command1_12.Text = "�m�茎��f�[�^���"
        Me._Command1_12.UseVisualStyleBackColor = False
        '
        '_Command1_11
        '
        Me._Command1_11.BackColor = System.Drawing.SystemColors.Control
        Me._Command1_11.Cursor = System.Windows.Forms.Cursors.Default
        Me._Command1_11.Font = New System.Drawing.Font("MS Mincho", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Command1_11.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Command1_11.Location = New System.Drawing.Point(538, 374)
        Me._Command1_11.Name = "_Command1_11"
        Me._Command1_11.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Command1_11.Size = New System.Drawing.Size(419, 39)
        Me._Command1_11.TabIndex = 12
        Me._Command1_11.Text = "����f�[�^�쐬"
        Me._Command1_11.UseVisualStyleBackColor = False
        '
        '_Command1_10
        '
        Me._Command1_10.BackColor = System.Drawing.SystemColors.Control
        Me._Command1_10.Cursor = System.Windows.Forms.Cursors.Default
        Me._Command1_10.Font = New System.Drawing.Font("MS Mincho", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Command1_10.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Command1_10.Location = New System.Drawing.Point(538, 310)
        Me._Command1_10.Name = "_Command1_10"
        Me._Command1_10.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Command1_10.Size = New System.Drawing.Size(419, 39)
        Me._Command1_10.TabIndex = 11
        Me._Command1_10.Text = "�H �� �� �� �� ��"
        Me._Command1_10.UseVisualStyleBackColor = False
        '
        '_Command1_9
        '
        Me._Command1_9.BackColor = System.Drawing.SystemColors.Control
        Me._Command1_9.Cursor = System.Windows.Forms.Cursors.Default
        Me._Command1_9.Enabled = False
        Me._Command1_9.Font = New System.Drawing.Font("MS Mincho", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Command1_9.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Command1_9.Location = New System.Drawing.Point(538, 220)
        Me._Command1_9.Name = "_Command1_9"
        Me._Command1_9.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Command1_9.Size = New System.Drawing.Size(419, 39)
        Me._Command1_9.TabIndex = 10
        Me._Command1_9.Text = "�� �� �� �� ��"
        Me._Command1_9.UseVisualStyleBackColor = False
        '
        '_Command1_8
        '
        Me._Command1_8.BackColor = System.Drawing.SystemColors.Control
        Me._Command1_8.Cursor = System.Windows.Forms.Cursors.Default
        Me._Command1_8.Font = New System.Drawing.Font("MS Mincho", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Command1_8.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Command1_8.Location = New System.Drawing.Point(538, 154)
        Me._Command1_8.Name = "_Command1_8"
        Me._Command1_8.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Command1_8.Size = New System.Drawing.Size(419, 39)
        Me._Command1_8.TabIndex = 9
        Me._Command1_8.Text = "�O���o�����񍐏����"
        Me._Command1_8.UseVisualStyleBackColor = False
        '
        '_Command1_7
        '
        Me._Command1_7.BackColor = System.Drawing.SystemColors.Control
        Me._Command1_7.Cursor = System.Windows.Forms.Cursors.Default
        Me._Command1_7.Enabled = False
        Me._Command1_7.Font = New System.Drawing.Font("MS Mincho", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Command1_7.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Command1_7.Location = New System.Drawing.Point(538, 90)
        Me._Command1_7.Name = "_Command1_7"
        Me._Command1_7.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Command1_7.Size = New System.Drawing.Size(419, 39)
        Me._Command1_7.TabIndex = 8
        Me._Command1_7.Text = "���c��O�����o���ꗗ���"
        Me._Command1_7.UseVisualStyleBackColor = False
        '
        '_Command1_6
        '
        Me._Command1_6.BackColor = System.Drawing.SystemColors.Control
        Me._Command1_6.Cursor = System.Windows.Forms.Cursors.Default
        Me._Command1_6.Font = New System.Drawing.Font("MS Mincho", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Command1_6.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Command1_6.Location = New System.Drawing.Point(538, 26)
        Me._Command1_6.Name = "_Command1_6"
        Me._Command1_6.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Command1_6.Size = New System.Drawing.Size(419, 39)
        Me._Command1_6.TabIndex = 7
        Me._Command1_6.Text = "�x �� �� �� �� ��"
        Me._Command1_6.UseVisualStyleBackColor = False
        '
        '_Command1_5
        '
        Me._Command1_5.BackColor = System.Drawing.SystemColors.Control
        Me._Command1_5.Cursor = System.Windows.Forms.Cursors.Default
        Me._Command1_5.Font = New System.Drawing.Font("MS Mincho", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Command1_5.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Command1_5.Location = New System.Drawing.Point(36, 426)
        Me._Command1_5.Name = "_Command1_5"
        Me._Command1_5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Command1_5.Size = New System.Drawing.Size(419, 51)
        Me._Command1_5.TabIndex = 5
        Me._Command1_5.Text = "�H �� �� �� �� ��"
        Me._Command1_5.UseVisualStyleBackColor = False
        '
        '_Command1_4
        '
        Me._Command1_4.BackColor = System.Drawing.SystemColors.Control
        Me._Command1_4.Cursor = System.Windows.Forms.Cursors.Default
        Me._Command1_4.Font = New System.Drawing.Font("MS Mincho", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Command1_4.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Command1_4.Location = New System.Drawing.Point(36, 348)
        Me._Command1_4.Name = "_Command1_4"
        Me._Command1_4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Command1_4.Size = New System.Drawing.Size(419, 51)
        Me._Command1_4.TabIndex = 4
        Me._Command1_4.Text = "�O�@���@��@��"
        Me._Command1_4.UseVisualStyleBackColor = False
        '
        '_Command1_3
        '
        Me._Command1_3.BackColor = System.Drawing.SystemColors.Control
        Me._Command1_3.Cursor = System.Windows.Forms.Cursors.Default
        Me._Command1_3.Font = New System.Drawing.Font("MS Mincho", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Command1_3.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Command1_3.Location = New System.Drawing.Point(36, 270)
        Me._Command1_3.Name = "_Command1_3"
        Me._Command1_3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Command1_3.Size = New System.Drawing.Size(419, 51)
        Me._Command1_3.TabIndex = 3
        Me._Command1_3.Text = "���c��O�������ꗗ"
        Me._Command1_3.UseVisualStyleBackColor = False
        '
        '_Command1_2
        '
        Me._Command1_2.BackColor = System.Drawing.SystemColors.Control
        Me._Command1_2.Cursor = System.Windows.Forms.Cursors.Default
        Me._Command1_2.Font = New System.Drawing.Font("MS Mincho", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Command1_2.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Command1_2.Location = New System.Drawing.Point(36, 192)
        Me._Command1_2.Name = "_Command1_2"
        Me._Command1_2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Command1_2.Size = New System.Drawing.Size(419, 51)
        Me._Command1_2.TabIndex = 2
        Me._Command1_2.Text = "�� �� �� �� ��"
        Me._Command1_2.UseVisualStyleBackColor = False
        '
        '_Command1_1
        '
        Me._Command1_1.BackColor = System.Drawing.SystemColors.Control
        Me._Command1_1.Cursor = System.Windows.Forms.Cursors.Default
        Me._Command1_1.Font = New System.Drawing.Font("MS Mincho", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Command1_1.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Command1_1.Location = New System.Drawing.Point(36, 114)
        Me._Command1_1.Name = "_Command1_1"
        Me._Command1_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Command1_1.Size = New System.Drawing.Size(419, 51)
        Me._Command1_1.TabIndex = 1
        Me._Command1_1.Text = "���c��O�����o���ꗗ"
        Me._Command1_1.UseVisualStyleBackColor = False
        '
        '_Command1_0
        '
        Me._Command1_0.BackColor = System.Drawing.SystemColors.Control
        Me._Command1_0.Cursor = System.Windows.Forms.Cursors.Default
        Me._Command1_0.Font = New System.Drawing.Font("MS Mincho", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Command1_0.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Command1_0.Location = New System.Drawing.Point(36, 26)
        Me._Command1_0.Name = "_Command1_0"
        Me._Command1_0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Command1_0.Size = New System.Drawing.Size(419, 39)
        Me._Command1_0.TabIndex = 0
        Me._Command1_0.Text = "�o���f�[�^���"
        Me._Command1_0.UseVisualStyleBackColor = False
        '
        '_Frame1_4
        '
        Me._Frame1_4.BackColor = System.Drawing.SystemColors.Control
        Me._Frame1_4.Controls.Add(Me._Picture2_14)
        Me._Frame1_4.Controls.Add(Me._Picture2_13)
        Me._Frame1_4.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Frame1_4.Location = New System.Drawing.Point(0, 502)
        Me._Frame1_4.Name = "_Frame1_4"
        Me._Frame1_4.Padding = New System.Windows.Forms.Padding(0)
        Me._Frame1_4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Frame1_4.Size = New System.Drawing.Size(989, 85)
        Me._Frame1_4.TabIndex = 55
        Me._Frame1_4.TabStop = False
        '
        '_Picture2_14
        '
        Me._Picture2_14.BackColor = System.Drawing.SystemColors.Control
        Me._Picture2_14.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Picture2_14.Cursor = System.Windows.Forms.Cursors.Default
        Me._Picture2_14.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Picture2_14.Location = New System.Drawing.Point(532, 20)
        Me._Picture2_14.Name = "_Picture2_14"
        Me._Picture2_14.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Picture2_14.Size = New System.Drawing.Size(431, 51)
        Me._Picture2_14.TabIndex = 57
        Me._Picture2_14.TabStop = False
        '
        '_Picture2_13
        '
        Me._Picture2_13.BackColor = System.Drawing.SystemColors.Control
        Me._Picture2_13.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Picture2_13.Cursor = System.Windows.Forms.Cursors.Default
        Me._Picture2_13.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Picture2_13.Location = New System.Drawing.Point(28, 20)
        Me._Picture2_13.Name = "_Picture2_13"
        Me._Picture2_13.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Picture2_13.Size = New System.Drawing.Size(431, 51)
        Me._Picture2_13.TabIndex = 56
        Me._Picture2_13.TabStop = False
        '
        '_Frame1_1
        '
        Me._Frame1_1.BackColor = System.Drawing.SystemColors.Control
        Me._Frame1_1.Controls.Add(Me._Picture2_5)
        Me._Frame1_1.Controls.Add(Me._Picture2_1)
        Me._Frame1_1.Controls.Add(Me._Picture2_2)
        Me._Frame1_1.Controls.Add(Me._Picture2_3)
        Me._Frame1_1.Controls.Add(Me._Picture2_4)
        Me._Frame1_1.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Frame1_1.Location = New System.Drawing.Point(2, 88)
        Me._Frame1_1.Name = "_Frame1_1"
        Me._Frame1_1.Padding = New System.Windows.Forms.Padding(0)
        Me._Frame1_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Frame1_1.Size = New System.Drawing.Size(485, 409)
        Me._Frame1_1.TabIndex = 49
        Me._Frame1_1.TabStop = False
        '
        '_Picture2_5
        '
        Me._Picture2_5.BackColor = System.Drawing.SystemColors.Control
        Me._Picture2_5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Picture2_5.Cursor = System.Windows.Forms.Cursors.Default
        Me._Picture2_5.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Picture2_5.Location = New System.Drawing.Point(28, 332)
        Me._Picture2_5.Name = "_Picture2_5"
        Me._Picture2_5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Picture2_5.Size = New System.Drawing.Size(431, 63)
        Me._Picture2_5.TabIndex = 54
        Me._Picture2_5.TabStop = False
        '
        '_Picture2_1
        '
        Me._Picture2_1.BackColor = System.Drawing.SystemColors.Control
        Me._Picture2_1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Picture2_1.Cursor = System.Windows.Forms.Cursors.Default
        Me._Picture2_1.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Picture2_1.Location = New System.Drawing.Point(28, 20)
        Me._Picture2_1.Name = "_Picture2_1"
        Me._Picture2_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Picture2_1.Size = New System.Drawing.Size(431, 63)
        Me._Picture2_1.TabIndex = 53
        Me._Picture2_1.TabStop = False
        '
        '_Picture2_2
        '
        Me._Picture2_2.BackColor = System.Drawing.SystemColors.Control
        Me._Picture2_2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Picture2_2.Cursor = System.Windows.Forms.Cursors.Default
        Me._Picture2_2.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Picture2_2.Location = New System.Drawing.Point(28, 98)
        Me._Picture2_2.Name = "_Picture2_2"
        Me._Picture2_2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Picture2_2.Size = New System.Drawing.Size(431, 63)
        Me._Picture2_2.TabIndex = 52
        Me._Picture2_2.TabStop = False
        '
        '_Picture2_3
        '
        Me._Picture2_3.BackColor = System.Drawing.SystemColors.Control
        Me._Picture2_3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Picture2_3.Cursor = System.Windows.Forms.Cursors.Default
        Me._Picture2_3.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Picture2_3.Location = New System.Drawing.Point(28, 176)
        Me._Picture2_3.Name = "_Picture2_3"
        Me._Picture2_3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Picture2_3.Size = New System.Drawing.Size(431, 63)
        Me._Picture2_3.TabIndex = 51
        Me._Picture2_3.TabStop = False
        '
        '_Picture2_4
        '
        Me._Picture2_4.BackColor = System.Drawing.SystemColors.Control
        Me._Picture2_4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Picture2_4.Cursor = System.Windows.Forms.Cursors.Default
        Me._Picture2_4.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Picture2_4.Location = New System.Drawing.Point(28, 254)
        Me._Picture2_4.Name = "_Picture2_4"
        Me._Picture2_4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Picture2_4.Size = New System.Drawing.Size(431, 63)
        Me._Picture2_4.TabIndex = 50
        Me._Picture2_4.TabStop = False
        '
        '_Frame1_3
        '
        Me._Frame1_3.BackColor = System.Drawing.SystemColors.Control
        Me._Frame1_3.Controls.Add(Me._Picture2_9)
        Me._Frame1_3.Controls.Add(Me._Picture2_7)
        Me._Frame1_3.Controls.Add(Me._Picture2_6)
        Me._Frame1_3.Controls.Add(Me._Picture2_8)
        Me._Frame1_3.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Frame1_3.Location = New System.Drawing.Point(504, 0)
        Me._Frame1_3.Name = "_Frame1_3"
        Me._Frame1_3.Padding = New System.Windows.Forms.Padding(0)
        Me._Frame1_3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Frame1_3.Size = New System.Drawing.Size(485, 279)
        Me._Frame1_3.TabIndex = 44
        Me._Frame1_3.TabStop = False
        '
        '_Picture2_9
        '
        Me._Picture2_9.BackColor = System.Drawing.SystemColors.Control
        Me._Picture2_9.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Picture2_9.Cursor = System.Windows.Forms.Cursors.Default
        Me._Picture2_9.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Picture2_9.Location = New System.Drawing.Point(28, 214)
        Me._Picture2_9.Name = "_Picture2_9"
        Me._Picture2_9.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Picture2_9.Size = New System.Drawing.Size(431, 51)
        Me._Picture2_9.TabIndex = 48
        Me._Picture2_9.TabStop = False
        '
        '_Picture2_7
        '
        Me._Picture2_7.BackColor = System.Drawing.SystemColors.Control
        Me._Picture2_7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Picture2_7.Cursor = System.Windows.Forms.Cursors.Default
        Me._Picture2_7.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Picture2_7.Location = New System.Drawing.Point(28, 84)
        Me._Picture2_7.Name = "_Picture2_7"
        Me._Picture2_7.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Picture2_7.Size = New System.Drawing.Size(431, 51)
        Me._Picture2_7.TabIndex = 47
        Me._Picture2_7.TabStop = False
        '
        '_Picture2_6
        '
        Me._Picture2_6.BackColor = System.Drawing.SystemColors.Control
        Me._Picture2_6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Picture2_6.Cursor = System.Windows.Forms.Cursors.Default
        Me._Picture2_6.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Picture2_6.Location = New System.Drawing.Point(28, 20)
        Me._Picture2_6.Name = "_Picture2_6"
        Me._Picture2_6.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Picture2_6.Size = New System.Drawing.Size(431, 51)
        Me._Picture2_6.TabIndex = 46
        Me._Picture2_6.TabStop = False
        '
        '_Picture2_8
        '
        Me._Picture2_8.BackColor = System.Drawing.SystemColors.Control
        Me._Picture2_8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Picture2_8.Cursor = System.Windows.Forms.Cursors.Default
        Me._Picture2_8.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Picture2_8.Location = New System.Drawing.Point(28, 148)
        Me._Picture2_8.Name = "_Picture2_8"
        Me._Picture2_8.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Picture2_8.Size = New System.Drawing.Size(431, 51)
        Me._Picture2_8.TabIndex = 45
        Me._Picture2_8.TabStop = False
        '
        '_Frame1_0
        '
        Me._Frame1_0.BackColor = System.Drawing.SystemColors.Control
        Me._Frame1_0.Controls.Add(Me._Picture2_0)
        Me._Frame1_0.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Frame1_0.Location = New System.Drawing.Point(2, 0)
        Me._Frame1_0.Name = "_Frame1_0"
        Me._Frame1_0.Padding = New System.Windows.Forms.Padding(0)
        Me._Frame1_0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Frame1_0.Size = New System.Drawing.Size(485, 85)
        Me._Frame1_0.TabIndex = 42
        Me._Frame1_0.TabStop = False
        '
        '_Picture2_0
        '
        Me._Picture2_0.BackColor = System.Drawing.SystemColors.Control
        Me._Picture2_0.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Picture2_0.Cursor = System.Windows.Forms.Cursors.Default
        Me._Picture2_0.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Picture2_0.Location = New System.Drawing.Point(28, 20)
        Me._Picture2_0.Name = "_Picture2_0"
        Me._Picture2_0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Picture2_0.Size = New System.Drawing.Size(431, 51)
        Me._Picture2_0.TabIndex = 43
        Me._Picture2_0.TabStop = False
        '
        '_Frame1_2
        '
        Me._Frame1_2.BackColor = System.Drawing.SystemColors.Control
        Me._Frame1_2.Controls.Add(Me._Picture2_12)
        Me._Frame1_2.Controls.Add(Me._Picture2_10)
        Me._Frame1_2.Controls.Add(Me._Picture2_11)
        Me._Frame1_2.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Frame1_2.Location = New System.Drawing.Point(504, 284)
        Me._Frame1_2.Name = "_Frame1_2"
        Me._Frame1_2.Padding = New System.Windows.Forms.Padding(0)
        Me._Frame1_2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Frame1_2.Size = New System.Drawing.Size(485, 213)
        Me._Frame1_2.TabIndex = 38
        Me._Frame1_2.TabStop = False
        '
        '_Picture2_12
        '
        Me._Picture2_12.BackColor = System.Drawing.SystemColors.Control
        Me._Picture2_12.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Picture2_12.Cursor = System.Windows.Forms.Cursors.Default
        Me._Picture2_12.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Picture2_12.Location = New System.Drawing.Point(28, 148)
        Me._Picture2_12.Name = "_Picture2_12"
        Me._Picture2_12.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Picture2_12.Size = New System.Drawing.Size(431, 51)
        Me._Picture2_12.TabIndex = 41
        Me._Picture2_12.TabStop = False
        '
        '_Picture2_10
        '
        Me._Picture2_10.BackColor = System.Drawing.SystemColors.Control
        Me._Picture2_10.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Picture2_10.Cursor = System.Windows.Forms.Cursors.Default
        Me._Picture2_10.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Picture2_10.Location = New System.Drawing.Point(28, 20)
        Me._Picture2_10.Name = "_Picture2_10"
        Me._Picture2_10.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Picture2_10.Size = New System.Drawing.Size(431, 51)
        Me._Picture2_10.TabIndex = 40
        Me._Picture2_10.TabStop = False
        '
        '_Picture2_11
        '
        Me._Picture2_11.BackColor = System.Drawing.SystemColors.Control
        Me._Picture2_11.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Picture2_11.Cursor = System.Windows.Forms.Cursors.Default
        Me._Picture2_11.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Picture2_11.Location = New System.Drawing.Point(28, 84)
        Me._Picture2_11.Name = "_Picture2_11"
        Me._Picture2_11.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Picture2_11.Size = New System.Drawing.Size(431, 51)
        Me._Picture2_11.TabIndex = 39
        Me._Picture2_11.TabStop = False
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label1.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(16, 44)
        Me.Label1.Name = "Label1"
        Me.Label1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label1.Size = New System.Drawing.Size(100, 23)
        Me.Label1.TabIndex = 31
        Me.Label1.Text = "���N��"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblTitle
        '
        Me.lblTitle.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblTitle.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTitle.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblTitle.Font = New System.Drawing.Font("MS Mincho", 20.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblTitle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.lblTitle.Location = New System.Drawing.Point(0, 0)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblTitle.Size = New System.Drawing.Size(1015, 34)
        Me.lblTitle.TabIndex = 29
        Me.lblTitle.Text = " �H���Ǘ����j���[�i�y�؁j"
        '
        'frmSYKD010
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(1016, 742)
        Me.Controls.Add(Me.VerPicture)
        Me.Controls.Add(Me.Picture3)
        Me.Controls.Add(Me.Picture1)
        Me.Controls.Add(Me.StatusBar1)
        Me.Controls.Add(Me.imText1)
        Me.Controls.Add(Me._imText2_2)
        Me.Controls.Add(Me._imText2_0)
        Me.Controls.Add(Me._imText2_1)
        Me.Controls.Add(Me.Picture4)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lblTitle)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.KeyPreview = True
        Me.Location = New System.Drawing.Point(4, 23)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmSYKD010"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "�H���Ǘ��V�X�e��"
        Me.VerPicture.ResumeLayout(False)
        Me.Picture3.ResumeLayout(False)
        Me.Picture1.ResumeLayout(False)
        Me.StatusBar1.ResumeLayout(False)
        Me.StatusBar1.PerformLayout()
        CType(Me.imText1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._imText2_2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._imText2_0, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._imText2_1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Picture4.ResumeLayout(False)
        Me._Frame1_4.ResumeLayout(False)
        CType(Me._Picture2_14, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._Picture2_13, System.ComponentModel.ISupportInitialize).EndInit()
        Me._Frame1_1.ResumeLayout(False)
        CType(Me._Picture2_5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._Picture2_1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._Picture2_2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._Picture2_3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._Picture2_4, System.ComponentModel.ISupportInitialize).EndInit()
        Me._Frame1_3.ResumeLayout(False)
        CType(Me._Picture2_9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._Picture2_7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._Picture2_6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._Picture2_8, System.ComponentModel.ISupportInitialize).EndInit()
        Me._Frame1_0.ResumeLayout(False)
        CType(Me._Picture2_0, System.ComponentModel.ISupportInitialize).EndInit()
        Me._Frame1_2.ResumeLayout(False)
        CType(Me._Picture2_12, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._Picture2_10, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._Picture2_11, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
#End Region
End Class