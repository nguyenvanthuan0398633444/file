Option Strict Off
Option Explicit On

Friend Class frmSYKD180
    Inherits System.Windows.Forms.Form
    '=============================================================
    ' ���[�U�[���@  �F  �R�z�H�Ɗ������
    ' �V�X�e�����@  �F  �H���Ǘ��V�X�e��
    ' ���W���[����  �F  �H������ꗗ
    ' ���W���[��ID�@�F  frmSYKD180.frm
    ' �쐬���@ �@�@ �F  ���� 13 �N 08 �� 06 ��
    ' �X�V���@�@  �@�F  ����    �N    ��    ��
    '=============================================================
    '

    '2021.08.11 UPGRADE S  AIT)hieutv
    'Private Const RowHeight As Short = 13
    Private Const RowHeight As Short = 18
    '2021.08.11 UPGRADE E

    Private Const InpMax As Short = 4 '���͔z�� �ő�l
    Private Const DspMax As Short = 2 '�\���z�� �ő�l

    Private UpMode As String '�X�V���[�h
    Private StopFlg As Short '�����I���t���O
    Private LoadFlg As Short '�N�����t���O

    '�H������f�[�^
    Private Structure GEPPOU_DATA_SUB
        '2021.07.26 UPGRADE S  AIT)Tool Convert
        '<VBFixedString(2),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=2)> Public GYOU_NO() As Char '�s�ԍ�
        '<VBFixedString(12),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=12)> Public BIKOU() As Char '���l
        <VBFixedStringAttribute(2)> Public GYOU_NO As String     '�s�ԍ�
        <VBFixedStringAttribute(12)> Public BIKOU As String  '���l
        '2021.07.26 UPGRADE E
        Dim UKEOI_GAKU As Decimal '�������z
        Dim YOSAN_GAKU As Decimal '���s�\�Z
        Dim RIEKI_GAKU As Decimal '�H�����v
        '2021.07.26 UPGRADE S  AIT)Tool Convert
        '<VBFixedString(6),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=6)> Public RIEKI_RITU() As Char '���v��
        <VBFixedStringAttribute(6)> Public RIEKI_RITU As String  '���v��
        '2021.07.26 UPGRADE E
    End Structure
    Private Structure GEPPOU_LIST_SUB
        '2021.07.26 UPGRADE S  AIT)Tool Convert
        '<VBFixedString(1),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=1)> Public KOUSYU_CD() As Char '�H������
        '<VBFixedString(2),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=2)> Public KOUSYU_NO() As Char '�H��ԍ�
        '<VBFixedString(40),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=40)> Public MEISYOU() As Char '�H�햼��
        <VBFixedStringAttribute(1)> Public KOUSYU_CD As String   '�H������
        <VBFixedStringAttribute(2)> Public KOUSYU_NO As String   '�H��ԍ�
        <VBFixedStringAttribute(40)> Public MEISYOU As String    '�H�햼��
        '2021.07.26 UPGRADE E
        Dim YOSAN_GAKU As Decimal '���s�\�Z
        Dim KINGAKU As Decimal '���ы��z
        Dim RUIGAKU As Decimal '�݌v���z
        Dim KONGO_GAKU As Decimal '���㌩��
        Dim JISSI_GAKU As Decimal '���{����
        Dim TAIHI_GAKU As Decimal '�\�Z�Δ�
        Dim ZOGEN_GAKU As Decimal '�ύX����
    End Structure

    Private PreSB() As GEPPOU_DATA_SUB '�ύX�O
    Private NowSB() As GEPPOU_DATA_SUB '�ύX��
    Private SelRow As Short '�I��\���s

    Private PreDT As GEPPOU_DATA_D_DBT '�ύX�O
    Private NowDT As GEPPOU_DATA_D_DBT '�ύX��

    Private WithEvents ctlEvents1 As clsEvents
    Private WithEvents ctlEvents2 As clsEvents
    Private WithEvents ctlEvents3 As clsEvents
    '

    '-------------------------------------------------------------------------------
    '   ����   :   �f�[�^�̃N���A
    '   �֐�   :   Sub DispClear()
    '   ����   :   �Ȃ�
    '   �@�\   :   �f�[�^���N���A���܂��B
    '-------------------------------------------------------------------------------
    Private Sub DispClear()

        Dim lp As Short

        '----- �H�����
        With KeyKouji
            imText2(0).Text = .KOUJI_NO
            If .EDA_NO = "0000" Then
                imText2(1).Text = ""
            Else
                imText2(1).Text = .EDA_NO
            End If
            imText2(2).Text = .MEISYOU
        End With
        '----- ���N��
        '2021.07.26 UPGRADE S  AIT)Tool Convert
        'imText3(0).Text = VB6.Format(CtlKouji.SYORI_YM, "0000/00")
        imText3(0).Text = Strings.Left(CtlKouji.SYORI_YM, 4) & "/" & Strings.Right(CtlKouji.SYORI_YM, 2)
        '2021.07.26 UPGRADE E

        '----- ���v���
        '2021.08.11 UPGRADE S  AIT)hieutv
        'imNumber1(0).Value = "" '����
        'imNumber1(1).Value = ""
        imNumber1(0).Value = 0 '����
        imNumber1(1).Value = 0
        '2021.08.11 UPGRADE E
        imText4(2).Text = ""
        imText4(3).Text = ""
        For lp = 0 To 3 '����
            imText5(lp).Text = ""
        Next lp
        For lp = 0 To DspMax
            Call ctlGeppo1(lp).DispClear()
        Next lp

        '----- ���̑�
        For lp = 0 To 2
            imDate1(lp).Number = 0
        Next lp
        imText1(0).Text = "" '���l
        imText1(1).Text = ""

        '----- �o�������
        '2021.08.11 UPGRADE S  AIT)hieutv
        'imNumber2(0).Value = ""
        'imNumber2(1).Value = ""
        'imNumber2(2).Value = ""
        'imNumber2(3).Value = ""
        imNumber2(0).Value = 0
        imNumber2(1).Value = 0
        imNumber2(2).Value = 0
        imNumber2(3).Value = 0
        '2021.08.11 UPGRADE E
        For lp = 0 To 5
            If lp <> 3 Then
                imText6(lp).Text = ""
            End If
        Next lp
        imText7(0).Text = ""
        imText7(1).Text = ""

        '----- �������
        '2021.08.11 UPGRADE S  AIT)hieutv
        'vaSpread1.MaxRows = 0
        'Call SpAllClear(vaSpread2)
        FpSpread1.ActiveSheet.RowCount = 0
        Call SpAllClear(FpSpread2)
        '2021.08.11 UPGRADE E

        '----- �Q�ƃ��[�h
        If INPMODE <> "2" Then
            cmdKey(1).Enabled = False
            '2021.08.11 UPGRADE S  AIT)hieutv
            'cmdKey(1).Text = "  F1  �@"
            cmdKey(1).Text = "F1"
            cmdKey(1).TextAlign = System.Drawing.ContentAlignment.TopCenter
            '2021.08.11 UPGRADE E
            Picture2(0).Enabled = False
            For lp = 0 To DspMax
                ctlGeppo1(lp).Enabled = False
                ctlGeppo1(lp).TabStop = False
            Next lp
            '2021.08.13 UPGRADE S  AIT)hieutv
            'Frame1(1).Enabled = False
            'Frame1(2).Enabled = False
            imText1(0).Enabled = False
            imText1(1).Enabled = False
            imText6(0).Enabled = False
            imText6(1).Enabled = False
            imText6(2).Enabled = False
            imText6(4).Enabled = False
            imText6(5).Enabled = False
            imText7(0).Enabled = False
            imText7(1).Enabled = False
            imNumber2(0).Enabled = False
            imNumber2(1).Enabled = False
            imNumber2(2).Enabled = False
            imNumber2(3).Enabled = False
            imDate1(0).Enabled = False
            imDate1(1).Enabled = False
            imDate1(2).Enabled = False
            '2021.08.11 UPGRADE E
            Check1.Enabled = False
        End If
        '2021.10.05  UPGRADE ADD S  AIT)dannnl
        Util.SetColorCalendar(imDate1(0))
        Util.SetColorCalendar(imDate1(1))
        Util.SetColorCalendar(imDate1(2))
        '2021.10.05 UPGRADE ADD E	

    End Sub

    '-------------------------------------------------------------------------------
    '   ����   :   GEPPOU_DATA_SUB �\���̃N���A����
    '   �֐�   :   Sub ClearGeppouSub()
    '   ����   :   DT   GEPPOU_DATA_SUB
    '   �@�\   :   �\���̂�����������
    '-------------------------------------------------------------------------------
    Private Sub ClearGeppouSub(ByRef DT As GEPPOU_DATA_SUB)
        With DT
            .GYOU_NO = "" '�s�ԍ�
            .BIKOU = "" '���l
            .UKEOI_GAKU = 0 '�������z
            .YOSAN_GAKU = 0 '���s�\�Z
            .RIEKI_GAKU = 0 '�H�����v
        End With
    End Sub

    '-------------------------------------------------------------------------------
    '   ����   :   �H��ʋ��z�̎擾
    '   �֐�   :   Function SelectJisseki()
    '   ����   :   DT()�@   GEPPOU_LIST_SUB
    '   �ߒl   :   �ް���   ����I��
    '   �@�@       -1�@     �ُ�I��
    '   �@�\   :   �H��ʂ̊��o�������o�����f�[�^���擾���܂��B
    '-------------------------------------------------------------------------------
    Private Function SelectJisseki(ByRef DT() As GEPPOU_LIST_SUB) As Integer

        Dim QRY1 As String
        Dim QRY2 As String
        Dim QRY3 As String
        Dim QRY4 As String
        Dim QRY5 As String
        Dim QRY6 As String
        Dim SQL As String
        '2021.08.11 UPGRADE S  AIT)hieutv
        'Dim Rs As ADODB.Recordset
        'Dim Fld As ADODB.Field
        Dim Rs As New DataTable
        Dim Fld As DataColumn
        '2021.08.11 UPGRADE E
        Dim Cnt As Integer
        Dim OpenFlg As Short

        Dim G_YOSAN_GAKU As Decimal
        Dim G_KINGAKU As Decimal
        Dim G_RUIGAKU As Decimal
        Dim G_KONGO_GAKU As Decimal
        Dim G_JISSI_GAKU As Decimal
        Dim G_TAIHI_GAKU As Decimal
        Dim G_ZOGEN_GAKU As Decimal
        Dim lp As Integer
        Dim Pos As Integer

        Dim TanGaku As Decimal '�P�����z
        Dim NinGaku As Decimal '�C�ӘJ��

        '2021.07.26 UPGRADE S  AIT)Tool Convert
        'On Error GoTo SelectJisseki_Err
        Try
            '2021.07.26 UPGRADE E

            '�O�����z�̏�����
            G_YOSAN_GAKU = 0
            G_KINGAKU = 0
            G_RUIGAKU = 0
            G_KONGO_GAKU = 0
            G_JISSI_GAKU = 0
            G_TAIHI_GAKU = 0
            G_ZOGEN_GAKU = 0

            '�߂�l�̏�����
            SelectJisseki = -1

            'QRY/SELECT���g��
            QRY1 = "(SELECT KOUSYU_CD, KOUSYU_NO, MEISYOU"
            QRY1 = QRY1 & " FROM KOUSYU_MAST"
            QRY1 = QRY1 & " WHERE GYOUSYU_KB = '" & GyosyuID & "'"
            QRY1 = QRY1 & ") AS MASTDT"

            'QRY/SELECT���g��
            QRY2 = "(SELECT KOUSYU_CD, KOUSYU_NO,"
            '----- 2001/10/29 �C�� -----------------------------------
            QRY2 = QRY2 & " SUM(T_KINGAKU + G_KINGAKU) AS YOSAN"
            '---------------------------------------------------------
            QRY2 = QRY2 & " FROM WARIDASI_DATA"
            QRY2 = QRY2 & " WHERE EDA_NO = '" & KeyKouji.EDA_NO & "'"
            QRY2 = QRY2 & " AND KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"
            QRY2 = QRY2 & " GROUP BY KOUSYU_CD, KOUSYU_NO"
            QRY2 = QRY2 & ") AS WARIDT"

            'QRY/SELECT���g��
            QRY3 = "(SELECT KOUSYU_CD, KOUSYU_NO,"
            QRY3 = QRY3 & " SUM(SI_GAKU)     AS KINGAKU,"
            QRY3 = QRY3 & " SUM(SI_KEI)      AS RUIGAKU,"
            QRY3 = QRY3 & " SUM(KONGO_GAKU)  AS KONGO,"
            QRY3 = QRY3 & " SUM(JISSI_GAKU)  AS JISSI,"
            QRY3 = QRY3 & " SUM(TAIHI_GAKU)  AS TAIHI,"
            QRY3 = QRY3 & " SUM(ZOUGEN_GAKU) AS ZOGEN"
            QRY3 = QRY3 & " FROM MIKOMI_DATA"
            QRY3 = QRY3 & " WHERE SIME_YM = '" & CtlKouji.SYORI_YM & "'"
            QRY3 = QRY3 & " AND EDA_NO = '" & KeyKouji.EDA_NO & "'"
            QRY3 = QRY3 & " AND KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"
            QRY3 = QRY3 & " GROUP BY KOUSYU_CD, KOUSYU_NO"
            QRY3 = QRY3 & ") AS MIKOMI"

            'QRY/SELECT���g��
            QRY4 = "(SELECT KOUSYU_CD, KOUSYU_NO,"
            QRY4 = QRY4 & " SUM(JITU_GAKU)   AS KINGAKU,"
            QRY4 = QRY4 & " SUM(RUI_GAKU)    AS RUIGAKU,"
            QRY4 = QRY4 & " SUM(KONGO_GAKU)  AS KONGO,"
            QRY4 = QRY4 & " SUM(JISSI_GAKU)  AS JISSI,"
            QRY4 = QRY4 & " SUM(TAIHI_GAKU)  AS TAIHI,"
            QRY4 = QRY4 & " SUM(ZOUGEN_GAKU) AS ZOGEN"
            QRY4 = QRY4 & " FROM DEKIDAKA_DATA"
            QRY4 = QRY4 & " WHERE SIME_YM = '" & CtlKouji.SYORI_YM & "'"
            QRY4 = QRY4 & " AND EDA_NO = '" & KeyKouji.EDA_NO & "'"
            QRY4 = QRY4 & " AND KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"
            QRY4 = QRY4 & " GROUP BY KOUSYU_CD, KOUSYU_NO"
            QRY4 = QRY4 & ") AS DEKIDT"

            'QRY/SELECT���g��
            QRY5 = "(SELECT KOUSYU_CD, KOUSYU_NO,"
            '----- 2001/10/29 �C�� -----------------------------------
            QRY5 = QRY5 & " SUM(T_KINGAKU + G_KINGAKU) AS YOSAN"
            '---------------------------------------------------------
            QRY5 = QRY5 & " FROM WARIDASI_DATA"
            QRY5 = QRY5 & " WHERE EDA_NO = '" & KeyKouji.EDA_NO & "'"
            QRY5 = QRY5 & " AND KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"
            QRY5 = QRY5 & " AND WARIDASI_KB <> '2'"
            QRY5 = QRY5 & " GROUP BY KOUSYU_CD, KOUSYU_NO"
            QRY5 = QRY5 & ") AS WARIDT_1"

            'QRY/SELECT���g��
            QRY6 = "(SELECT KOUSYU_CD, KOUSYU_NO,"
            '----- 2001/10/29 �C�� -----------------------------------
            QRY6 = QRY6 & " SUM(T_KINGAKU + G_KINGAKU) AS YOSAN"
            '---------------------------------------------------------
            QRY6 = QRY6 & " FROM WARIDASI_DATA"
            QRY6 = QRY6 & " WHERE EDA_NO = '" & KeyKouji.EDA_NO & "'"
            QRY6 = QRY6 & " AND KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"
            QRY6 = QRY6 & " AND WARIDASI_KB = '2'"
            QRY6 = QRY6 & " GROUP BY KOUSYU_CD, KOUSYU_NO"
            QRY6 = QRY6 & ") AS WARIDT_2"

            'SQL/SELECT���g��
            SQL = "SELECT"
            SQL = SQL & " WARIDT.KOUSYU_CD  AS F01," '�H������
            SQL = SQL & " WARIDT.KOUSYU_NO  AS F02," '�H��ԍ�
            SQL = SQL & " MASTDT.MEISYOU    AS F03," '�H�햼
            SQL = SQL & " WARIDT.YOSAN      AS F04," '���s�\�Z
            SQL = SQL & " WARIDT_1.YOSAN    AS F20," '���s�\�Z�i�O���ȊO�j
            SQL = SQL & " WARIDT_2.YOSAN    AS F21," '���s�\�Z�i�O���j
            SQL = SQL & " MIKOMI.KINGAKU    AS F05," '���ы��z�i���c�j
            SQL = SQL & " MIKOMI.RUIGAKU    AS F06," '���ї݌v
            SQL = SQL & " MIKOMI.KONGO      AS F07," '���㌩��
            SQL = SQL & " MIKOMI.JISSI      AS F08," '���{����
            SQL = SQL & " MIKOMI.TAIHI      AS F09," '�\�Z�Δ�
            SQL = SQL & " MIKOMI.ZOGEN      AS F10," '�ύX����
            SQL = SQL & " DEKIDT.KINGAKU    AS F11," '���ы��z�i�O���j
            SQL = SQL & " DEKIDT.RUIGAKU    AS F12," '���ї݌v
            SQL = SQL & " DEKIDT.KONGO      AS F13," '���㌩��
            SQL = SQL & " DEKIDT.JISSI      AS F14," '���{����
            SQL = SQL & " DEKIDT.TAIHI      AS F15," '�\�Z�Δ�
            SQL = SQL & " DEKIDT.ZOGEN      AS F16" '�ύX����
            SQL = SQL & " FROM ((((" & QRY2
            SQL = SQL & " LEFT JOIN " & QRY5
            SQL = SQL & " ON (WARIDT.KOUSYU_NO = WARIDT_1.KOUSYU_NO)"
            SQL = SQL & " AND (WARIDT.KOUSYU_CD = WARIDT_1.KOUSYU_CD))"
            SQL = SQL & " LEFT JOIN " & QRY6
            SQL = SQL & " ON (WARIDT.KOUSYU_NO = WARIDT_2.KOUSYU_NO)"
            SQL = SQL & " AND (WARIDT.KOUSYU_CD = WARIDT_2.KOUSYU_CD))"
            SQL = SQL & " LEFT JOIN " & QRY3
            SQL = SQL & " ON (WARIDT.KOUSYU_NO = MIKOMI.KOUSYU_NO)"
            SQL = SQL & " AND (WARIDT.KOUSYU_CD = MIKOMI.KOUSYU_CD))"
            SQL = SQL & " LEFT JOIN " & QRY4
            SQL = SQL & " ON (WARIDT.KOUSYU_NO = DEKIDT.KOUSYU_NO)"
            SQL = SQL & " AND (WARIDT.KOUSYU_CD = DEKIDT.KOUSYU_CD))"
            SQL = SQL & " LEFT JOIN " & QRY1
            SQL = SQL & " ON (WARIDT.KOUSYU_NO = MASTDT.KOUSYU_NO)"
            SQL = SQL & " AND (WARIDT.KOUSYU_CD = MASTDT.KOUSYU_CD)"
            SQL = SQL & " ORDER BY WARIDT.KOUSYU_CD, WARIDT.KOUSYU_NO"

            'SQL�����s
            '2021.08.11 UPGRADE S  AIT)hieutv
            'Rs = SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText)
            Rs = RsOpen(SQL)
            '2021.08.11 UPGRADE E
            OpenFlg = 1

            Cnt = 0
            '2021.08.11 UPGRADE S  AIT)hieutv
            'Do Until Rs.EOF
            For Each Row As DataRow In Rs.Rows
                '2021.08.11 UPGRADE E
                ReDim Preserve DT(Cnt)
                With DT(Cnt)
                    '----- ������
                    .KOUSYU_CD = "" '�H������
                    .KOUSYU_NO = "" '�H��ԍ�
                    .MEISYOU = "" '�H�햼��
                    .YOSAN_GAKU = 0 '���s�\�Z
                    .KINGAKU = 0 '���ы��z
                    .RUIGAKU = 0 '���ї݌v
                    .KONGO_GAKU = 0 '���㌩��
                    .JISSI_GAKU = 0 '���{����
                    .TAIHI_GAKU = 0 '�\�Z�Δ�
                    .ZOGEN_GAKU = 0 '�ύX����
                    '----- �\���̂�
                    '2021.08.11 UPGRADE S  AIT)hieutv
                    'For	Each Fld In Rs.Fields
                    '	If IsDbNull(Fld.Name) = False And IsDbNull(Fld.Value) = False Then
                    '		Select Case UCase(Fld.Name)
                    '			Case "F01" : .KOUSYU_CD = Fld.Value '�H������
                    '			Case "F02" : .KOUSYU_NO = Fld.Value '�H��ԍ�
                    '			Case "F03" : .MEISYOU = Fld.Value '�H�햼
                    '				'Case "F04": .YOSAN_GAKU = Fld.Value                 '���s�\�Z
                    '			Case "F20" : .YOSAN_GAKU = .YOSAN_GAKU + Fld.Value '���s�\�Z�i�O���ȊO�j
                    '				'Case "F21": .YOSAN_GAKU = .YOSAN_GAKU + Fld.Value   '���s�\�Z�i�O���j
                    '			Case "F21" : G_YOSAN_GAKU = G_YOSAN_GAKU + Fld.Value '���s�\�Z�i�O���j
                    '			Case "F05" : .KINGAKU = .KINGAKU + Fld.Value '���ы��z�i���c�j
                    '			Case "F06" : .RUIGAKU = .RUIGAKU + Fld.Value '���ї݌v
                    '			Case "F07" : .KONGO_GAKU = .KONGO_GAKU + Fld.Value '���㌩��
                    '			Case "F08" : .JISSI_GAKU = .JISSI_GAKU + Fld.Value '���{����
                    '			Case "F09" : .TAIHI_GAKU = .TAIHI_GAKU + Fld.Value '�\�Z�Δ�
                    '			Case "F10" : .ZOGEN_GAKU = .ZOGEN_GAKU + Fld.Value '�ύX����
                    '				'Case "F11": .KINGAKU = .KINGAKU + Fld.Value         '���ы��z�i�O���j
                    '				'Case "F12": .RUIGAKU = .RUIGAKU + Fld.Value         '���ї݌v
                    '				'Case "F13": .KONGO_GAKU = .KONGO_GAKU + Fld.Value   '���㌩��
                    '				'Case "F14": .JISSI_GAKU = .JISSI_GAKU + Fld.Value   '���{����
                    '				'Case "F15": .TAIHI_GAKU = .TAIHI_GAKU + Fld.Value   '�\�Z�Δ�
                    '				'Case "F16": .ZOGEN_GAKU = .ZOGEN_GAKU + Fld.Value   '�ύX����
                    '			Case "F11" : G_KINGAKU = G_KINGAKU + Fld.Value '���ы��z�i�O���j
                    '			Case "F12" : G_RUIGAKU = G_RUIGAKU + Fld.Value '���ї݌v
                    '			Case "F13" : G_KONGO_GAKU = G_KONGO_GAKU + Fld.Value '���㌩��
                    '			Case "F14" : G_JISSI_GAKU = G_JISSI_GAKU + Fld.Value '���{����
                    '			Case "F15" : G_TAIHI_GAKU = G_TAIHI_GAKU + Fld.Value '�\�Z�Δ�
                    '			Case "F16" : G_ZOGEN_GAKU = G_ZOGEN_GAKU + Fld.Value '�ύX����
                    '		End Select
                    '	End If
                    'Next Fld
                    For Each Fld In Row.Table.Columns
                        If IsDBNull(Fld.ColumnName) = False And IsDBNull(Row(Fld.ColumnName)) = False Then
                            Select Case UCase(Fld.ColumnName)
                                Case "F01" : .KOUSYU_CD = Row(Fld.ColumnName) '�H������
                                Case "F02" : .KOUSYU_NO = Row(Fld.ColumnName) '�H��ԍ�
                                Case "F03" : .MEISYOU = Row(Fld.ColumnName) '�H�햼
                                'Case "F04": .YOSAN_GAKU = Fld.Value                 '���s�\�Z
                                Case "F20" : .YOSAN_GAKU = .YOSAN_GAKU + Row(Fld.ColumnName) '���s�\�Z�i�O���ȊO�j
                                'Case "F21": .YOSAN_GAKU = .YOSAN_GAKU + Fld.Value   '���s�\�Z�i�O���j
                                Case "F21" : G_YOSAN_GAKU = G_YOSAN_GAKU + Row(Fld.ColumnName) '���s�\�Z�i�O���j
                                Case "F05" : .KINGAKU = .KINGAKU + Row(Fld.ColumnName) '���ы��z�i���c�j
                                Case "F06" : .RUIGAKU = .RUIGAKU + Row(Fld.ColumnName) '���ї݌v
                                Case "F07" : .KONGO_GAKU = .KONGO_GAKU + Row(Fld.ColumnName) '���㌩��
                                Case "F08" : .JISSI_GAKU = .JISSI_GAKU + Row(Fld.ColumnName) '���{����
                                Case "F09" : .TAIHI_GAKU = .TAIHI_GAKU + Row(Fld.ColumnName) '�\�Z�Δ�
                                Case "F10" : .ZOGEN_GAKU = .ZOGEN_GAKU + Row(Fld.ColumnName) '�ύX����
                                'Case "F11": .KINGAKU = .KINGAKU + Fld.Value         '���ы��z�i�O���j
                                'Case "F12": .RUIGAKU = .RUIGAKU + Fld.Value         '���ї݌v
                                'Case "F13": .KONGO_GAKU = .KONGO_GAKU + Fld.Value   '���㌩��
                                'Case "F14": .JISSI_GAKU = .JISSI_GAKU + Fld.Value   '���{����
                                'Case "F15": .TAIHI_GAKU = .TAIHI_GAKU + Fld.Value   '�\�Z�Δ�
                                'Case "F16": .ZOGEN_GAKU = .ZOGEN_GAKU + Fld.Value   '�ύX����
                                Case "F11" : G_KINGAKU = G_KINGAKU + Row(Fld.ColumnName) '���ы��z�i�O���j
                                Case "F12" : G_RUIGAKU = G_RUIGAKU + Row(Fld.ColumnName) '���ї݌v
                                Case "F13" : G_KONGO_GAKU = G_KONGO_GAKU + Row(Fld.ColumnName) '���㌩��
                                Case "F14" : G_JISSI_GAKU = G_JISSI_GAKU + Row(Fld.ColumnName) '���{����
                                Case "F15" : G_TAIHI_GAKU = G_TAIHI_GAKU + Row(Fld.ColumnName) '�\�Z�Δ�
                                Case "F16" : G_ZOGEN_GAKU = G_ZOGEN_GAKU + Row(Fld.ColumnName) '�ύX����
                            End Select
                        End If
                    Next Fld
                    '2021.08.11 UPGRADE E
                End With
                Cnt = Cnt + 1
                '	Rs.MoveNext()
                'Loop

                'Rs.Close()
            Next

            Rs.Dispose()
            Rs = Nothing

            '�W�v�����O�����z���wA-01�x�ɑ�������
            Pos = -1
            For lp = 0 To Cnt - 1
                If DT(lp).KOUSYU_CD = "A" And DT(lp).KOUSYU_NO = "01" Then
                    Pos = lp
                    Exit For
                End If
            Next lp
            If Pos > -1 Then
                With DT(Pos)
                    .YOSAN_GAKU = .YOSAN_GAKU + G_YOSAN_GAKU '���s�\�Z�i�O���j
                    .KINGAKU = .KINGAKU + G_KINGAKU '���ы��z�i�O���j
                    .RUIGAKU = .RUIGAKU + G_RUIGAKU '���ї݌v
                    .KONGO_GAKU = .KONGO_GAKU + G_KONGO_GAKU '���㌩��
                    .JISSI_GAKU = .JISSI_GAKU + G_JISSI_GAKU '���{����
                    .TAIHI_GAKU = .TAIHI_GAKU + G_TAIHI_GAKU '�\�Z�Δ�
                    .ZOGEN_GAKU = .ZOGEN_GAKU + G_ZOGEN_GAKU '�ύX����
                End With
            End If

            '2005/08/11 �P�����z�ƔC�ӘJ�Ђ��Z�o����
            TanGaku = GetCalcTankasa(NinGaku)
            '2005/08/11 �P�����z��ǉ�����
            If TanGaku <> 0 Then
                ReDim Preserve DT(Cnt)
                With DT(Cnt)
                    .KOUSYU_CD = "*" '�H������
                    .KOUSYU_NO = "*1" '�H��ԍ�
                    .MEISYOU = "���P�����z��" '�H�햼��
                    .YOSAN_GAKU = 0 '���s�\�Z
                    .KINGAKU = -TanGaku '���ы��z
                    .RUIGAKU = 0 '���ї݌v
                    .KONGO_GAKU = 0 '���㌩��
                    .JISSI_GAKU = -TanGaku '���{����
                    .TAIHI_GAKU = TanGaku '�\�Z�Δ�
                    .ZOGEN_GAKU = 0 '�ύX����
                End With
                Cnt = Cnt + 1
            End If
            '2005/08/11 �C�ӘJ�Ђ�ǉ�����
            If NinGaku <> 0 Then
                ReDim Preserve DT(Cnt)
                With DT(Cnt)
                    .KOUSYU_CD = "*" '�H������
                    .KOUSYU_NO = "*2" '�H��ԍ�
                    '.MEISYOU = "���C�ӘJ�Ё�"    '�H�햼��
                    .MEISYOU = "�����S�����" '�H�햼��
                    .YOSAN_GAKU = 0 '���s�\�Z
                    .KINGAKU = -NinGaku '���ы��z
                    .RUIGAKU = 0 '���ї݌v
                    .KONGO_GAKU = 0 '���㌩��
                    .JISSI_GAKU = -NinGaku '���{����
                    .TAIHI_GAKU = NinGaku '�\�Z�Δ�
                    .ZOGEN_GAKU = 0 '�ύX����
                End With
                Cnt = Cnt + 1
            End If

            '�߂�l�̃Z�b�g
            SelectJisseki = Cnt
            Exit Function

            '2021.07.26 UPGRADE S  AIT)Tool Convert
            'SelectJisseki_Err:
        Catch ex As Exception
            '2021.07.26 UPGRADE E

            If OpenFlg = 1 Then
                '2021.08.11 UPGRADE S  AIT)hieutv
                'Rs.Close()
                Rs.Dispose()
                '2021.08.11 UPGRADE E
            End If
            Rs = Nothing

            '2021.08.11 UPGRADE S  AIT)hieutv
            'Call Sql_Error_Msg("SelectJisseki")
            Call Sql_Error_Msg(ex, "SelectJisseki")
            '2021.08.11 UPGRADE E

        End Try     '2021.07.26 UPGRADE ADD AIT)Tool Convert
    End Function

    '-------------------------------------------------------------------------------
    '   ����   :   �f�[�^�̎擾
    '   �֐�   :   Function ListDataDisp()
    '   ����   :   �Ȃ�
    '   �ߒl   :   True    ����I��
    '   �@�@   :   False   �ُ�I��
    '   �@�\   :   �f�[�^�̎擾���s���܂��B
    '-------------------------------------------------------------------------------
    Private Function ListDataDisp() As Boolean

        Dim lp As Integer
        Dim Jouken As String
        Dim Order As String
        Dim Cnt As Integer
        Dim SB() As GEPPOU_LIST_SUB
        Dim DT() As GEPPOU_DATA_D_DBT
        Dim MS() As KOUJI_MAST_DBT
        Dim wkBuf As String
        Dim wkVal As Decimal
        Dim Kei() As Decimal
        Dim wkstr As String

        Dim TanGaku As Decimal '�P�����z
        Dim NinGaku As Decimal '�C�ӘJ��

        ' �߂�l�̏�����
        ListDataDisp = False

        ' �J�[�\���������v��
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
        wkBuf = StatusBar1.Items.Item("Message").Text
        StatusBar1.Items.Item("Message").Text = "�Y���f�[�^�������E�E�E"

        '----- ������
        ReDim Kei(8)

        '----- ���ы��z

        ' �e�[�u���̓Ǎ���
        Cnt = SelectJisseki(SB)
        If Cnt < 0 Then
            StatusBar1.Items.Item("Message").Text = wkBuf
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
            Exit Function
        End If
        ' �f�[�^�\��
        Call SprdDataSet(Cnt, SB, Kei)
        '2005/10/26 �P�����z�ƔC�ӘJ�Ђ̑O�����𒲐�����
        TanGaku = GetCalcTankasaZenMade(NinGaku)
        Kei(7) = Kei(7) - (TanGaku + NinGaku)
        Kei(6) = Kei(6) + (TanGaku + NinGaku)

        '----- �H������

        ' �f�[�^�̈�N���A
        Call CLEAR_GEPPOU_DATA_D(PreDT)
        Call CLEAR_GEPPOU_DATA_D(NowDT)
        For lp = 0 To InpMax
            Call ClearGeppouSub(NowSB(lp))
            '2021.07.26 UPGRADE S  AIT)Tool Convert
            'NowSB(lp).GYOU_NO = VB6.Format(lp + 1, "00")
            NowSB(lp).GYOU_NO = CDec(lp + 1).ToString("00")
            '2021.07.26 UPGRADE E
            PreSB(lp) = NowSB(lp)
        Next lp

        ' WHERE���̑g�ݗ���
        Jouken = "SIME_YM = '" & CtlKouji.SYORI_YM & "'"
        Jouken = Jouken & " AND EDA_NO = '" & KeyKouji.EDA_NO & "'"
        Jouken = Jouken & " AND KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"

        ' �e�[�u���̓Ǎ���
        Order = ""
        Cnt = SELECT_GEPPOU_DATA_D(Jouken, Order, DT)
        If Cnt < 0 Then
            StatusBar1.Items.Item("Message").Text = wkBuf
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
            Exit Function
        End If
        UpMode = "0"

        ' �f�[�^�̈�ɃZ�b�g
        If Cnt > 0 Then
            UpMode = "1"
            NowDT = DT(0)
            PreDT = NowDT
            With NowDT
                '----- �@
                NowSB(0).BIKOU = .H1_BIKOU '���l
                NowSB(0).UKEOI_GAKU = .H1_UKEOI_GAKU '�������z
                NowSB(0).YOSAN_GAKU = .H1_YOSAN_GAKU '���s�\�Z
                NowSB(0).RIEKI_GAKU = .H1_RIEKI_GAKU '�H�����v
                If .H1_UKEOI_GAKU = 0 Then wkVal = 0 Else wkVal = .H1_RIEKI_GAKU / .H1_UKEOI_GAKU
                '2021.07.26 UPGRADE S  AIT)Tool Convert
                'NowSB(0).RIEKI_RITU = VB6.Format(wkVal * 100, "0.0") & "%" '���v��
                NowSB(0).RIEKI_RITU = CDec(wkVal * 100).ToString("0.0") & "%" '���v��
                '2021.07.26 UPGRADE E
                If .H1_UKEOI_GAKU = 0 And .H1_YOSAN_GAKU = 0 Then NowSB(0).RIEKI_RITU = ""
                PreSB(0) = NowSB(0)
                Kei(8) = Kei(8) + .H1_UKEOI_GAKU
                '----- �A
                NowSB(1).BIKOU = .H2_BIKOU '���l
                NowSB(1).UKEOI_GAKU = .H2_UKEOI_GAKU '�������z
                NowSB(1).YOSAN_GAKU = .H2_YOSAN_GAKU '���s�\�Z
                NowSB(1).RIEKI_GAKU = .H2_RIEKI_GAKU '�H�����v
                If .H2_UKEOI_GAKU = 0 Then wkVal = 0 Else wkVal = .H2_RIEKI_GAKU / .H2_UKEOI_GAKU
                '2021.07.26 UPGRADE S  AIT)Tool Convert
                'NowSB(1).RIEKI_RITU = VB6.Format(wkVal * 100, "0.0") & "%" '���v��
                NowSB(1).RIEKI_RITU = CDec(wkVal * 100).ToString("0.0") & "%" '���v��
                '2021.07.26 UPGRADE E
                If .H2_UKEOI_GAKU = 0 And .H2_YOSAN_GAKU = 0 Then NowSB(1).RIEKI_RITU = ""
                PreSB(1) = NowSB(1)
                Kei(8) = Kei(8) + .H2_UKEOI_GAKU
                '----- �B
                NowSB(2).BIKOU = .H3_BIKOU '���l
                NowSB(2).UKEOI_GAKU = .H3_UKEOI_GAKU '�������z
                NowSB(2).YOSAN_GAKU = .H3_YOSAN_GAKU '���s�\�Z
                NowSB(2).RIEKI_GAKU = .H3_RIEKI_GAKU '�H�����v
                If .H3_UKEOI_GAKU = 0 Then wkVal = 0 Else wkVal = .H3_RIEKI_GAKU / .H3_UKEOI_GAKU
                '2021.07.26 UPGRADE S  AIT)Tool Convert
                'NowSB(2).RIEKI_RITU = VB6.Format(wkVal * 100, "0.0") & "%" '���v��
                NowSB(2).RIEKI_RITU = CDec(wkVal * 100).ToString("0.0") & "%" '���v��
                '2021.07.26 UPGRADE E
                If .H3_UKEOI_GAKU = 0 And .H3_YOSAN_GAKU = 0 Then NowSB(2).RIEKI_RITU = ""
                PreSB(2) = NowSB(2)
                Kei(8) = Kei(8) + .H3_UKEOI_GAKU
                '----- �C
                NowSB(3).BIKOU = .H4_BIKOU '���l
                NowSB(3).UKEOI_GAKU = .H4_UKEOI_GAKU '�������z
                NowSB(3).YOSAN_GAKU = .H4_YOSAN_GAKU '���s�\�Z
                NowSB(3).RIEKI_GAKU = .H4_RIEKI_GAKU '�H�����v
                If .H4_UKEOI_GAKU = 0 Then wkVal = 0 Else wkVal = .H4_RIEKI_GAKU / .H4_UKEOI_GAKU
                '2021.07.26 UPGRADE S  AIT)Tool Convert
                'NowSB(3).RIEKI_RITU = VB6.Format(wkVal * 100, "0.0") & "%" '���v��
                NowSB(3).RIEKI_RITU = CDec(wkVal * 100).ToString("0.0") & "%" '���v��
                '2021.07.26 UPGRADE E
                If .H4_UKEOI_GAKU = 0 And .H4_YOSAN_GAKU = 0 Then NowSB(3).RIEKI_RITU = ""
                PreSB(3) = NowSB(3)
                Kei(8) = Kei(8) + .H4_UKEOI_GAKU
                '----- �D
                NowSB(4).BIKOU = .H5_BIKOU '���l
                NowSB(4).UKEOI_GAKU = .H5_UKEOI_GAKU '�������z
                NowSB(4).YOSAN_GAKU = .H5_YOSAN_GAKU '���s�\�Z
                NowSB(4).RIEKI_GAKU = .H5_RIEKI_GAKU '�H�����v
                If .H5_UKEOI_GAKU = 0 Then wkVal = 0 Else wkVal = .H5_RIEKI_GAKU / .H5_UKEOI_GAKU
                '2021.07.26 UPGRADE S  AIT)Tool Convert
                'NowSB(4).RIEKI_RITU = VB6.Format(wkVal * 100, "0.0") & "%" '���v��
                NowSB(4).RIEKI_RITU = CDec(wkVal * 100).ToString("0.0") & "%" '���v��
                '2021.07.26 UPGRADE E
                If .H5_UKEOI_GAKU = 0 And .H5_YOSAN_GAKU = 0 Then NowSB(4).RIEKI_RITU = ""
                PreSB(4) = NowSB(4)
                Kei(8) = Kei(8) + .H5_UKEOI_GAKU
            End With
        End If

        '----- �Čv�Z��̋��z���Z�b�g
        With NowDT
            ' �������z(���Z����)
            .K_UKEOI_GAKU = .T_UKEOI_GAKU + Kei(8)
            ' ���s�\�Z(���Z����)�F���{�������z
            .K_YOSAN_GAKU = Kei(3)
            ' �H�����v(���Z����) = �������z - �\�Z���z
            .K_RIEKI_GAKU = .K_UKEOI_GAKU - .K_YOSAN_GAKU
            ' �݌v���{���z
            .JISSI_KEI = Kei(1)
            ' �O�񖘎��{���z
            .ZEN_JISSI_GAKU = Kei(7)
            ' �������{���z
            .KON_JISSI_GAKU = Kei(6)
            ' ����x���z
            wkstr = "S_FLG_GENKA = '1' AND " & Jouken
            wkVal = GetCalcIppan(wkstr)
            wkVal = wkVal + GetCalcGaichu(Jouken)
            .KON_HARAI_GAKU = wkVal
            ' �扺�c��
            .TORI_ZAN_GAKU = .K_UKEOI_GAKU - .TORISAGE_GAKU
            '----- �������o�������w0�x�̏ꍇ
            If .DEKI_GAKU = 0 Then
                ' �������o���� = �������z(���Z����) *�i�݌v���{���z / ���{�������z�j
                If .K_YOSAN_GAKU = 0 Then wkVal = 0 Else wkVal = .JISSI_KEI / .K_YOSAN_GAKU
                '2021.07.26 UPGRADE S  AIT)Tool Convert
                'wkVal = CCur2(VB6.Format(wkVal * 100, "0.0"))
                'wkVal = CCur2(VB6.Format(.K_UKEOI_GAKU * (wkVal / 100), "0"))
                wkVal = CCur2(CDec(wkVal * 100).ToString("0.0"))
                wkVal = CCur2(CDec(.K_UKEOI_GAKU * (wkVal / 100)).ToString("0"))
                '2021.07.26 UPGRADE E
                .DEKI_GAKU = wkVal
                ' ���񐿕��o���� = �������o���� - �O�񐿕��o����
                wkVal = .DEKI_GAKU - .ZEN_UKE_GAKU
                .KON_UKE_GAKU = wkVal
            End If
            '----- �V�K�쐬��
            If Cnt = 0 Then
                '----- �H�����̎擾
                Jouken = "EDA_NO = '" & KeyKouji.EDA_NO & "'"
                Jouken = Jouken & " AND KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"
                Cnt = SELECT_KOUJI_MAST(Jouken, Order, MS)
                If Cnt <= 0 Then
                    '2021.09.14 UPGRADE S  AIT)dannnl
                    'If Cnt = 0 Then MsgBox("�Y������H���}�X�^��񂪑��݂��܂���B", MsgBoxStyle.Information)
                    If Cnt = 0 Then MsgBox("�Y������H���}�X�^��񂪑��݂��܂���B", MsgBoxStyle.Information, SYSTEMNM)
                    '2021.09.14 UPGRADE E
                    StatusBar1.Items.Item("Message").Text = wkBuf
                    System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
                    Exit Function
                End If
                .T_UKEOI_GAKU = MS(0).KOUJI_GAKU '�������z(����)
                .T_YOSAN_GAKU = Kei(0) '���s�\�Z(����)
                .T_RIEKI_GAKU = MS(0).KOUJI_GAKU - Kei(0) '�H�����v(����)
                .KOUKI_S_YMD = MS(0).KOUKI_S_YMD '�H���i���H�j
                .KOUKI_E_YMD = MS(0).KOUKI_E_YMD '�H���i�v�H�j
                .KOUKI_K_YMD = MS(0).KOUKI_E_YMD '�H���i�����j
                .SYOUNIN_FLG = "0" '���F�t���O
                .K_UKEOI_GAKU = .T_UKEOI_GAKU '�������z(���Z)
                .K_RIEKI_GAKU = .K_UKEOI_GAKU - .K_YOSAN_GAKU '�H�����v(���Z)
                .TORI_ZAN_GAKU = .K_UKEOI_GAKU - .TORISAGE_GAKU '�扺�c��
                '----- �������o�������w0�x�̏ꍇ
                If .DEKI_GAKU = 0 Then
                    ' �������o���� = �������z(���Z����) *�i�݌v���{���z / ���{�������z�j
                    If .K_YOSAN_GAKU = 0 Then wkVal = 0 Else wkVal = .JISSI_KEI / .K_YOSAN_GAKU
                    '2021.07.26 UPGRADE S  AIT)Tool Convert
                    'wkVal = CCur2(VB6.Format(wkVal * 100, "0.0"))
                    'wkVal = CCur2(VB6.Format(.K_UKEOI_GAKU * (wkVal / 100), "0"))
                    wkVal = CCur2(CDec(wkVal * 100).ToString("0.0"))
                    wkVal = CCur2(CDec(.K_UKEOI_GAKU * (wkVal / 100)).ToString("0"))
                    '2021.07.26 UPGRADE E
                    .DEKI_GAKU = wkVal
                    ' ���񐿕��o���� = �������o���� - �O�񐿕��o����
                    wkVal = .DEKI_GAKU - .ZEN_UKE_GAKU
                    .KON_UKE_GAKU = wkVal
                End If
            End If
        End With
        PreDT = NowDT

        ' �f�[�^�\��
        Call MeisaiDataSet(0, 0)
        Call DispDataSet()

        StatusBar1.Items.Item("Message").Text = wkBuf
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default

        ' ����I��
        ListDataDisp = True

    End Function

    '-------------------------------------------------------------------------------
    '   ����   :   �X�v���b�h�\��
    '   �֐�   :   Sub SprdDataSet(DT())
    '   ����   :   Cnt      �f�[�^����
    '   �@�@       DT()     GEPPOU_LIST_SUB
    '   �@�@       wkVal    ���v���z
    '   �@�\   :   �f�[�^���X�v���b�h�ɕ\�����܂��B
    '-------------------------------------------------------------------------------
    Private Sub SprdDataSet(ByRef Cnt As Integer, ByRef DT() As GEPPOU_LIST_SUB, ByRef wkVal() As Decimal)

        Dim lp As Integer
        Dim Row As Integer
        Dim ssText As Object
        Dim wkGaku As Decimal

        '2021.08.11 UPGRADE S  AIT)hieutv
        'With vaSpread1
        With FpSpread1
            If Me.Visible = True Then
                '.ReDraw = False
                SuspendLayout()
            End If
            '.MaxRows = Cnt
            '.Col = 1 : .Col2 = .MaxCols
            '.Row = 1 : .Row2 = .MaxRows
            '.BlockMode = True
            '.Action = FPSpread.ActionConstants.ActionClearText
            '.BlockMode = False
            .ActiveSheet.RowCount = Cnt
            .ActiveSheet.ClearRange(0, 0, .ActiveSheet.RowCount, .ActiveSheet.ColumnCount, True)
            For lp = 0 To Cnt - 1
                '.set_RowHeight(lp + 1, RowHeight)
                .ActiveSheet.SetRowHeight(lp, RowHeight)
                'Row = lp + 1
                Row = lp
                '----- �H������
                If Trim(DT(lp).KOUSYU_CD) <> "*" Then
                    ssText = Trim(DT(lp).KOUSYU_CD) & "-" & Trim(DT(lp).KOUSYU_NO)
                Else
                    ssText = ""
                End If
                '.SetText(1, Row, ssText)
                .ActiveSheet.SetText(Row, 0, ssText)
                '----- �H�햼
                ssText = Trim(DT(lp).MEISYOU)
                '.SetText(2, Row, ssText)
                .ActiveSheet.SetText(Row, 1, ssText)
                '----- ���s�\�Z
                wkGaku = DT(lp).YOSAN_GAKU
                'ssText = VB6.Format(wkGaku, "#,###")
                'If wkGaku < 0 Then .Col = 3 : .Row = Row : .ForeColor = System.Drawing.Color.Red
                '.SetText(3, Row, ssText)
                ssText = wkGaku.ToString("#,###")
                If wkGaku < 0 Then .ActiveSheet.Cells.Get(Row, 2).ForeColor = System.Drawing.Color.Red
                .ActiveSheet.SetText(Row, 2, ssText)
                '----- ���ы��z
                wkGaku = DT(lp).KINGAKU + DT(lp).RUIGAKU
                'ssText = VB6.Format(wkGaku, "#,###")
                'If wkGaku < 0 Then .Col = 4 : .Row = Row : .ForeColor = System.Drawing.Color.Red
                '.SetText(4, Row, ssText)
                ssText = wkGaku.ToString("#,###")
                If wkGaku < 0 Then .ActiveSheet.Cells.Get(Row, 3).ForeColor = System.Drawing.Color.Red
                .ActiveSheet.SetText(Row, 3, ssText)
                '----- ���㌩��
                wkGaku = DT(lp).KONGO_GAKU
                'ssText = VB6.Format(wkGaku, "#,###")
                'If wkGaku < 0 Then .Col = 5 : .Row = Row : .ForeColor = System.Drawing.Color.Red
                '.SetText(5, Row, ssText)
                ssText = wkGaku.ToString("#,###")
                If wkGaku < 0 Then .ActiveSheet.Cells.Get(Row, 4).ForeColor = System.Drawing.Color.Red
                .ActiveSheet.SetText(Row, 4, ssText)
                '----- ���{����
                wkGaku = DT(lp).JISSI_GAKU
                'ssText = VB6.Format(wkGaku, "#,###")
                'If wkGaku < 0 Then .Col = 6 : .Row = Row : .ForeColor = System.Drawing.Color.Red
                '.SetText(6, Row, ssText)
                ssText = wkGaku.ToString("#,###")
                If wkGaku < 0 Then .ActiveSheet.Cells.Get(Row, 5).ForeColor = System.Drawing.Color.Red
                .ActiveSheet.SetText(Row, 5, ssText)
                '----- �\�Z�Δ�
                wkGaku = DT(lp).TAIHI_GAKU
                'ssText = VB6.Format(wkGaku, "#,###")
                'If wkGaku < 0 Then .Col = 7 : .Row = Row : .ForeColor = System.Drawing.Color.Red
                '.SetText(7, Row, ssText)
                ssText = wkGaku.ToString("#,###")
                If wkGaku < 0 Then .ActiveSheet.Cells.Get(Row, 6).ForeColor = System.Drawing.Color.Red
                .ActiveSheet.SetText(Row, 6, ssText)
                '----- �ύX����
                wkGaku = DT(lp).ZOGEN_GAKU
                'ssText = VB6.Format(wkGaku, "#,###")
                'If wkGaku < 0 Then .Col = 8 : .Row = Row : .ForeColor = System.Drawing.Color.Red
                '.SetText(8, Row, ssText)
                ssText = wkGaku.ToString("#,###")
                If wkGaku < 0 Then .ActiveSheet.Cells.Get(Row, 7).ForeColor = System.Drawing.Color.Red
                .ActiveSheet.SetText(Row, 7, ssText)
                '----- ������z
                wkGaku = DT(lp).KINGAKU
                'ssText = VB6.Format(wkGaku, "#,###")
                'If wkGaku < 0 Then .Col = 9 : .Row = Row : .ForeColor = System.Drawing.Color.Red
                '.SetText(9, Row, ssText)
                ssText = wkGaku.ToString("#,###")
                If wkGaku < 0 Then .ActiveSheet.Cells.Get(Row, 8).ForeColor = System.Drawing.Color.Red
                .ActiveSheet.SetText(Row, 8, ssText)
                '----- �݌v���z
                wkGaku = DT(lp).RUIGAKU
                'ssText = VB6.Format(wkGaku, "#,###")
                'If wkGaku < 0 Then .Col = 10 : .Row = Row : .ForeColor = System.Drawing.Color.Red
                '.SetText(10, Row, ssText)
                ssText = wkGaku.ToString("#,###")
                If wkGaku < 0 Then .ActiveSheet.Cells.Get(Row, 8).ForeColor = System.Drawing.Color.Red
                .ActiveSheet.SetText(Row, 9, ssText)
                '----- �W�v
                wkVal(0) = wkVal(0) + DT(lp).YOSAN_GAKU
                wkVal(1) = wkVal(1) + DT(lp).KINGAKU + DT(lp).RUIGAKU
                wkVal(2) = wkVal(2) + DT(lp).KONGO_GAKU
                wkVal(3) = wkVal(3) + DT(lp).JISSI_GAKU
                wkVal(4) = wkVal(4) + DT(lp).TAIHI_GAKU
                wkVal(5) = wkVal(5) + DT(lp).ZOGEN_GAKU
                wkVal(6) = wkVal(6) + DT(lp).KINGAKU
                wkVal(7) = wkVal(7) + DT(lp).RUIGAKU
            Next lp
            If Me.Visible = True Then
                '.CtlRefresh()
                '.ReDraw = True
                .Refresh()
                .ResumeLayout()
            End If
        End With
        '2021.08.11 UPGRADE E

        '----- ���v���z
        '2021.08.11 UPGRADE S  AIT)hieutv
        'With vaSpread2
        With FpSpread2
            If Me.Visible = True Then
                '.ReDraw = False
                SuspendLayout()
            End If
            '.Col = 1 : .Col2 = .MaxCols
            '.Row = 1 : .Row2 = .MaxRows
            '.BlockMode = True
            '.Action = FPSpread.ActionConstants.ActionClearText
            '.BlockMode = False
            .ActiveSheet.ClearRange(0, 0, .ActiveSheet.RowCount, .ActiveSheet.ColumnCount, True)
            '.SetText(2, Row, "���v")
            .ActiveSheet.SetText(0, 1, "���v")
            '----- ���s�\�Z
            'ssText = VB6.Format(wkVal(0), "#,###")
            'If wkVal(0) < 0 Then .Col = 3 : .Row = Row : .ForeColor = System.Drawing.Color.Red
            '.SetText(3, Row, ssText)
            ssText = wkVal(0).ToString("#,###")
            If wkVal(0) < 0 Then .ActiveSheet.Cells.Get(0, 2).ForeColor = System.Drawing.Color.Red
            .ActiveSheet.SetText(0, 2, ssText)
            '----- ���ы��z
            'ssText = VB6.Format(wkVal(1), "#,###")
            'If wkVal(1) < 0 Then .Col = 4 : .Row = Row : .ForeColor = System.Drawing.Color.Red
            '.SetText(4, Row, ssText)
            ssText = wkVal(1).ToString("#,###")
            If wkVal(1) < 0 Then .ActiveSheet.Cells.Get(0, 3).ForeColor = System.Drawing.Color.Red
            .ActiveSheet.SetText(0, 3, ssText)
            '----- ���㌩��
            'ssText = VB6.Format(wkVal(2), "#,###")
            'If wkVal(2) < 0 Then .Col = 5 : .Row = Row : .ForeColor = System.Drawing.Color.Red
            '.SetText(5, Row, ssText)
            ssText = wkVal(2).ToString("#,###")
            If wkVal(2) < 0 Then .ActiveSheet.Cells.Get(0, 4).ForeColor = System.Drawing.Color.Red
            .ActiveSheet.SetText(0, 4, ssText)
            '----- ���{����
            'ssText = VB6.Format(wkVal(3), "#,###")
            'If wkVal(3) < 0 Then .Col = 6 : .Row = Row : .ForeColor = System.Drawing.Color.Red
            '.SetText(6, Row, ssText)
            ssText = wkVal(3).ToString("#,###")
            If wkVal(3) < 0 Then .ActiveSheet.Cells.Get(0, 5).ForeColor = System.Drawing.Color.Red
            .ActiveSheet.SetText(0, 5, ssText)
            '----- �\�Z�Δ�
            'ssText = VB6.Format(wkVal(4), "#,###")
            'If wkVal(4) < 0 Then .Col = 7 : .Row = Row : .ForeColor = System.Drawing.Color.Red
            '.SetText(7, Row, ssText)
            ssText = wkVal(4).ToString("#,###")
            If wkVal(4) < 0 Then .ActiveSheet.Cells.Get(0, 6).ForeColor = System.Drawing.Color.Red
            .ActiveSheet.SetText(0, 6, ssText)
            '----- �ύX����
            'ssText = VB6.Format(wkVal(5), "#,###")
            'If wkVal(5) < 0 Then .Col = 8 : .Row = Row : .ForeColor = System.Drawing.Color.Red
            '.SetText(8, Row, ssText)
            ssText = wkVal(5).ToString("#,###")
            If wkVal(5) < 0 Then .ActiveSheet.Cells.Get(0, 7).ForeColor = System.Drawing.Color.Red
            .ActiveSheet.SetText(0, 7, ssText)
            '----- ������z
            'ssText = VB6.Format(wkVal(6), "#,###")
            'If wkVal(6) < 0 Then .Col = 9 : .Row = Row : .ForeColor = System.Drawing.Color.Red
            '.SetText(9, Row, ssText)
            ssText = wkVal(6).ToString("#,###")
            If wkVal(6) < 0 Then .ActiveSheet.Cells.Get(0, 8).ForeColor = System.Drawing.Color.Red
            .ActiveSheet.SetText(0, 8, ssText)
            '----- �݌v���z
            'ssText = VB6.Format(wkVal(7), "#,###")
            'If wkVal(7) < 0 Then .Col = 10 : .Row = Row : .ForeColor = System.Drawing.Color.Red
            '.SetText(10, Row, ssText)
            ssText = wkVal(7).ToString("#,###")
            If wkVal(7) < 0 Then .ActiveSheet.Cells.Get(0, 9).ForeColor = System.Drawing.Color.Red
            .ActiveSheet.SetText(0, 9, ssText)
            If Me.Visible = True Then
                '.CtlRefresh()
                '.ReDraw = True
                .Refresh()
                .ResumeLayout()
            End If
        End With
        '2021.08.11 UPGRADE E

    End Sub

    '-------------------------------------------------------------------------------
    '   ����   :   �H������f�[�^�̕\��
    '   �֐�   :   Sub DispDataSet()
    '   ����   :   �Ȃ�
    '   �@�\   :   �H������f�[�^��\�����܂��B
    '-------------------------------------------------------------------------------
    Private Sub DispDataSet()

        Dim wkVal As Decimal

        With NowDT
            '2021.07.26 UPGRADE S  AIT)Tool Convert
            'If IsDate(VB6.Format(.KOUKI_S_YMD, "0000/00/00")) = True Then
            If IsDate(Strings.Left(.KOUKI_S_YMD, 4) & "/" & Strings.Mid(.KOUKI_S_YMD, 5, 2)  & "/" & Strings.Right(.KOUKI_S_YMD, 2)) = True Then
                '2021.07.26 UPGRADE E
                '2021.08.12 UPGRADE S  AIT)hieutv
                'imDate1(0).Number = .KOUKI_S_YMD '�H���i���H�j
                imDate1(0).Value = Date.ParseExact(.KOUKI_S_YMD.ToString, "yyyyMMdd", System.Globalization.DateTimeFormatInfo.InvariantInfo)
                '2021.08.12 UPGRADE E
            End If
            '2021.07.26 UPGRADE S  AIT)Tool Convert
            'If IsDate(VB6.Format(.KOUKI_E_YMD, "0000/00/00")) = True Then
            If IsDate(Strings.Left(.KOUKI_E_YMD, 4) & "/" & Strings.Mid(.KOUKI_E_YMD, 5, 2)  & "/" & Strings.Right(.KOUKI_E_YMD, 2)) = True Then
                '2021.07.26 UPGRADE E
                '2021.08.12 UPGRADE S  AIT)hieutv
                'imDate1(1).Number = .KOUKI_E_YMD '�H���i�v�H�j
                imDate1(1).Value = Date.ParseExact(.KOUKI_E_YMD.ToString, "yyyyMMdd", System.Globalization.DateTimeFormatInfo.InvariantInfo)
                '2021.08.12 UPGRADE E
            End If
            '2021.07.26 UPGRADE S  AIT)Tool Convert
            'If IsDate(VB6.Format(.KOUKI_K_YMD, "0000/00/00")) = True Then
            If IsDate(Strings.Left(.KOUKI_K_YMD, 4) & "/" & Strings.Mid(.KOUKI_K_YMD, 5, 2)  & "/" & Strings.Right(.KOUKI_K_YMD, 2)) = True Then
                '2021.07.26 UPGRADE E
                '2021.08.12 UPGRADE S  AIT)hieutv
                'imDate1(2).Number = .KOUKI_K_YMD '�H���i�����j
                imDate1(2).Value = Date.ParseExact(.KOUKI_K_YMD.ToString, "yyyyMMdd", System.Globalization.DateTimeFormatInfo.InvariantInfo)
                '2021.08.12 UPGRADE E
            End If
            imText1(0).Text = Trim(.BIKOU1) '���l�P
            imText1(1).Text = Trim(.BIKOU2) '���l�Q
            '2021.08.11 UPGRADE S  AIT)hieutv
            'imNumber1(0).Value = VB6.Format(.T_UKEOI_GAKU) '�������z(����)
            'imNumber1(1).Value = VB6.Format(.T_YOSAN_GAKU) '���s�\�Z(����)
            imNumber1(0).Value = .T_UKEOI_GAKU.ToString '�������z(����)
            imNumber1(1).Value = .T_YOSAN_GAKU.ToString '���s�\�Z(����)
            '2021.08.11 UPGRADE E
            '2021.07.26 UPGRADE S  AIT)Tool Convert
            'imText4(2).Text = VB6.Format(.T_RIEKI_GAKU, "#,##0") '�H�����v(����)
            imText4(2).Text = CDec(.T_RIEKI_GAKU).ToString("#,##0") '�H�����v(����)
            '2021.07.26 UPGRADE E
            If .T_UKEOI_GAKU = 0 Then wkVal = 0 Else wkVal = Math.Round(.T_RIEKI_GAKU / .T_UKEOI_GAKU, 4)
            '2021.07.26 UPGRADE S  AIT)Tool Convert
            'imText4(3).Text = VB6.Format(wkVal * 100, "0.0") & "%"
            'imText5(0).Text = VB6.Format(.K_UKEOI_GAKU, "#,##0") '�������z(���Z����)
            'imText5(1).Text = VB6.Format(.K_YOSAN_GAKU, "#,##0") '���s�\�Z(���Z����)
            'imText5(2).Text = VB6.Format(.K_RIEKI_GAKU, "#,##0") '�H�����v(���Z����)
            imText4(3).Text = CDec(wkVal * 100).ToString("0.0") & "%"
            imText5(0).Text = CDec(.K_UKEOI_GAKU).ToString("#,##0") '�������z(���Z����)
            imText5(1).Text = CDec(.K_YOSAN_GAKU).ToString("#,##0") '���s�\�Z(���Z����)
            imText5(2).Text = CDec(.K_RIEKI_GAKU).ToString("#,##0") '�H�����v(���Z����)
            '2021.07.26 UPGRADE E
            If .K_UKEOI_GAKU = 0 Then wkVal = 0 Else wkVal = Math.Round(.K_RIEKI_GAKU / .K_UKEOI_GAKU, 4)
            '2021.07.26 UPGRADE S  AIT)Tool Convert
            'imText5(3).Text = VB6.Format(wkVal * 100, "0.0") & "%"
            'imText6(0).Text = VB6.Format(.JISSI_KEI, "#,##0") '�݌v���{���z
            imText5(3).Text = CDec(wkVal * 100).ToString("0.0") & "%"
            imText6(0).Text = CDec(.JISSI_KEI).ToString("#,##0") '�݌v���{���z
            '2021.07.26 UPGRADE E
            If .K_YOSAN_GAKU = 0 Then wkVal = 0 Else wkVal = Math.Round(.JISSI_KEI / .K_YOSAN_GAKU, 4)
            '2021.07.26 UPGRADE S  AIT)Tool Convert
            'imText7(0).Text = VB6.Format(wkVal * 100, "0.0") & "%"
            'imText6(1).Text = VB6.Format(.ZEN_JISSI_GAKU, "#,##0") '�O�񖘎��{���z
            'imText6(2).Text = VB6.Format(.KON_JISSI_GAKU, "#,##0") '�������{���z
            imText7(0).Text = CDec(wkVal * 100).ToString("0.0") & "%"
            imText6(1).Text = CDec(.ZEN_JISSI_GAKU).ToString("#,##0") '�O�񖘎��{���z
            imText6(2).Text = CDec(.KON_JISSI_GAKU).ToString("#,##0") '�������{���z
            '2021.07.26 UPGRADE E
            '2021.08.11 UPGRADE S  AIT)hieutv
            'imNumber2(0).Value = VB6.Format(.DEKI_GAKU) '�������o����
            imNumber2(0).Value = .DEKI_GAKU.ToString '�������o����
            '2021.08.11 UPGRADE E
            If .K_UKEOI_GAKU = 0 Then wkVal = 0 Else wkVal = Math.Round(.DEKI_GAKU / .K_UKEOI_GAKU, 4)
            '2021.07.26 UPGRADE S  AIT)Tool Convert
            'imText7(1).Text = VB6.Format(wkVal * 100, "0.0") & "%"
            imText7(1).Text = CDec(wkVal * 100).ToString("0.0") & "%"
            '2021.07.26 UPGRADE E
            '2021.08.11 UPGRADE S  AIT)hieutv
            'imNumber2(3).Value = VB6.Format(.ZEN_UKE_GAKU) '�O�񖘐����o����
            imNumber2(3).Value = .ZEN_UKE_GAKU.ToString '�O�񖘐����o����
            '2021.08.11 UPGRADE E
            '2021.07.26 UPGRADE S  AIT)Tool Convert
            'imText6(4).Text = VB6.Format(.KON_UKE_GAKU, "#,##0") '���񐿕��o����
            imText6(4).Text = CDec(.KON_UKE_GAKU).ToString("#,##0") '���񐿕��o����
            '2021.07.26 UPGRADE E
            '2021.08.11 UPGRADE S  AIT)hieutv
            'imNumber2(1).Value = VB6.Format(.MOKU_GAKU) '�����w�͖ڕW
            'imNumber2(2).Value = VB6.Format(.TORISAGE_GAKU) '�扺�z
            imNumber2(1).Value = CDec(.MOKU_GAKU).ToString("#,##0") '�����w�͖ڕW
            imNumber2(2).Value = .TORISAGE_GAKU.ToString '�扺�z
            '2021.08.11 UPGRADE E
            '2021.07.26 UPGRADE S  AIT)Tool Convert
            'imText6(5).Text = VB6.Format(.TORI_ZAN_GAKU, "#,##0") '�扺�c�z
            imText6(5).Text = CDec(.TORI_ZAN_GAKU).ToString("#,##0") '�扺�c�z
            '2021.07.26 UPGRADE E
            Check1.CheckState = CShort(.SYOUNIN_FLG) '���F�t���O
        End With

    End Sub

    '-------------------------------------------------------------------------------
    '   ����    :   �H������f�[�^�̎擾
    '   �֐�    :   Sub DispDataGet()
    '   ����    :   �Ȃ�
    '   �@�\    :   �H������f�[�^���擾���܂��B
    '-------------------------------------------------------------------------------
    Private Sub DispDataGet()

        With NowDT
            .KOUJI_NO = KeyKouji.KOUJI_NO '�H���ԍ�
            .EDA_NO = KeyKouji.EDA_NO '�H���}��
            .SIME_YM = CtlKouji.SYORI_YM '���N��
            .T_UKEOI_GAKU = CCur2(imNumber1(0).Value) '�������z(����)
            .T_YOSAN_GAKU = CCur2(imNumber1(1).Value) '���s�\�Z(����)
            .T_RIEKI_GAKU = CCur2(imText4(2).Text) '�H�����v(����)
            .K_UKEOI_GAKU = CCur2(imText5(0).Text) '�������z(���Z����)
            .K_YOSAN_GAKU = CCur2(imText5(1).Text) '���s�\�Z(���Z����)
            .K_RIEKI_GAKU = CCur2(imText5(2).Text) '�H�����v(���Z����)
            If IsDate(imDate1(0).Text) = True Then
                '2021.08.13 UPGRADE S  AIT)hieutv
                '.KOUKI_S_YMD = imDate1(0).Number '�H���i���H�j
                .KOUKI_S_YMD = Strings.Left(imDate1(0).Number, 8) '�H���i���H�j
                '2021.08.13 UPGRADE E
            End If
            If IsDate(imDate1(1).Text) = True Then
                '2021.08.13 UPGRADE S  AIT)hieutv
                '.KOUKI_E_YMD = imDate1(1).Number '�H���i�v�H�j
                .KOUKI_E_YMD = Strings.Left(imDate1(1).Number, 8) '�H���i�v�H�j
                '2021.08.13 UPGRADE E
            End If
            If IsDate(imDate1(2).Text) = True Then
                '2021.08.13 UPGRADE S  AIT)hieutv
                '.KOUKI_K_YMD = imDate1(2).Number '�H���i�����j
                .KOUKI_K_YMD = Strings.Left(imDate1(2).Number, 8) '�H���i�����j
                '2021.08.13 UPGRADE E
            End If
            .BIKOU1 = Trim(imText1(0).Text) '���l�P
            .BIKOU2 = Trim(imText1(1).Text) '���l�Q

            .JISSI_KEI = CCur2(imText6(0).Text) '�݌v���{���z
            .ZEN_JISSI_GAKU = CCur2(imText6(1).Text) '�O�񖘎��{���z
            .KON_JISSI_GAKU = CCur2(imText6(2).Text) '�������{���z
            .DEKI_GAKU = CCur2(imNumber2(0).Value) '�������o����
            .ZEN_UKE_GAKU = CCur2(imNumber2(3).Value) '�O�񖘐����o����
            .KON_UKE_GAKU = CCur2(imText6(4).Text) '���񐿕��o����
            .MOKU_GAKU = CCur2(imNumber2(1).Value) '�����w�͖ڕW
            .TORISAGE_GAKU = CCur2(imNumber2(2).Value) '�扺�z
            .TORI_ZAN_GAKU = CCur2(imText6(5).Text) '�扺�c�z
            .H1_BIKOU = Trim(NowSB(0).BIKOU) '���l(�P)
            .H1_UKEOI_GAKU = NowSB(0).UKEOI_GAKU '�������z(�P)
            .H1_YOSAN_GAKU = NowSB(0).YOSAN_GAKU '���s�\�Z(�P)
            .H1_RIEKI_GAKU = NowSB(0).RIEKI_GAKU '�H�����v(�P)
            .H2_BIKOU = Trim(NowSB(1).BIKOU) '���l(�Q)
            .H2_UKEOI_GAKU = NowSB(1).UKEOI_GAKU '�������z(�Q)
            .H2_YOSAN_GAKU = NowSB(1).YOSAN_GAKU '���s�\�Z(�Q)
            .H2_RIEKI_GAKU = NowSB(1).RIEKI_GAKU '�H�����v(�Q)
            .H3_BIKOU = Trim(NowSB(2).BIKOU) '���l(�R)
            .H3_UKEOI_GAKU = NowSB(2).UKEOI_GAKU '�������z(�R)
            .H3_YOSAN_GAKU = NowSB(2).YOSAN_GAKU '���s�\�Z(�R)
            .H3_RIEKI_GAKU = NowSB(2).RIEKI_GAKU '�H�����v(�R)
            .H4_BIKOU = Trim(NowSB(3).BIKOU) '���l(�S)
            .H4_UKEOI_GAKU = NowSB(3).UKEOI_GAKU '�������z(�S)
            .H4_YOSAN_GAKU = NowSB(3).YOSAN_GAKU '���s�\�Z(�S)
            .H4_RIEKI_GAKU = NowSB(3).RIEKI_GAKU '�H�����v(�S)
            .H5_BIKOU = Trim(NowSB(4).BIKOU) '���l(�T)
            .H5_UKEOI_GAKU = NowSB(4).UKEOI_GAKU '�������z(�T)
            .H5_YOSAN_GAKU = NowSB(4).YOSAN_GAKU '���s�\�Z(�T)
            .H5_RIEKI_GAKU = NowSB(4).RIEKI_GAKU '�H�����v(�T)
            .SYOUNIN_FLG = CStr(Check1.CheckState) '���F�t���O
        End With

    End Sub

    '-------------------------------------------------------------------------------
    '   ����    :   ���ח̈�̕\��
    '   �֐�    :   Sub MeisaiDataSet(FstPos, DspPos)
    '   ����    :   FstPos  �z��J�n�ԍ��i 0 �` InpMax �j
    '   �@�@        DspPos  �\���J�n�ԍ��i 0 �` DspMax �j
    '   �@�\    :   ���ח̈�̕\�����s���܂��B
    '-------------------------------------------------------------------------------
    Private Sub MeisaiDataSet(ByRef FstPos As Short, ByRef DspPos As Short)

        Dim lp As Short

        '----- �T���ׂ܂�
        For lp = DspPos To DspMax
            Call RowDataSet(lp, NowSB(FstPos + (lp - DspPos)))
        Next lp

    End Sub

    '-------------------------------------------------------------------------------
    '   ����   :   ���׍s�̕\��
    '   �֐�   :   Sub RowDataSet(DspPos, DT)
    '   ����   :   DspPos  �\���s�i 0 �` DspMax �j
    '   �@�@       DT      GEPPOU_DATA_SUB
    '   �@�\   :   ���׍s�̕\�����s���܂��B
    '-------------------------------------------------------------------------------
    Private Sub RowDataSet(ByRef DspPos As Short, ByRef DT As GEPPOU_DATA_SUB)

        With DT
            ctlGeppo1(DspPos).Value(0) = .GYOU_NO '�s�ԍ�
            ctlGeppo1(DspPos).Value(1) = Trim(.BIKOU) '���l
            '2021.08.11 UPGRADE S  AIT)hieutv
            'ctlGeppo1(DspPos).Value(2) = VB6.Format(.UKEOI_GAKU) '�������z
            'ctlGeppo1(DspPos).Value(3) = VB6.Format(.YOSAN_GAKU) '���s�\�Z
            'ctlGeppo1(DspPos).Value(4) = VB6.Format(.RIEKI_GAKU, "#,###") '�H�����v
            ctlGeppo1(DspPos).Value(2) = .UKEOI_GAKU.ToString("#,##0") '�������z
            ctlGeppo1(DspPos).Value(3) = .YOSAN_GAKU.ToString("#,##0") '���s�\�Z
            ctlGeppo1(DspPos).Value(4) = .RIEKI_GAKU.ToString("#,###") '�H�����v
            '2021.08.11 UPGRADE E
            ctlGeppo1(DspPos).Value(5) = Trim(.RIEKI_RITU) '���v��
        End With

    End Sub

    '-------------------------------------------------------------------------------
    '   ����    :   ���׍s�̎擾
    '   �֐�    :   Sub K_RowDataGet(DspPos, DT)
    '   ����    :   DspPos  �\���s�i 0 �` DspMax �j
    '   �@�@        DT      GEPPOU_DATA_SUB
    '   �@�\    :   ���׍s�̎擾���s���܂��B
    '-------------------------------------------------------------------------------
    Private Sub RowDataGet(ByRef DspPos As Short, ByRef DT As GEPPOU_DATA_SUB)

        With DT
            .BIKOU = ctlGeppo1(DspPos).Value(1) '���l
            .UKEOI_GAKU = ctlGeppo1(DspPos).Value(2) '�������z
            .YOSAN_GAKU = ctlGeppo1(DspPos).Value(3) '���s�\�Z
            .RIEKI_GAKU = ctlGeppo1(DspPos).Value(4) '�H�����v
            .RIEKI_RITU = ctlGeppo1(DspPos).Value(5) '���v��
        End With

    End Sub

    '-------------------------------------------------------------------------------
    '   ����   :   ���׍��ڕύX����
    '   �֐�   :   Sub MeisaiChange(Index, Mode, Value)
    '   ����   :   Index   �ύX���۰ٔz��ԍ��i 0 �` DspMax �j
    '   �@�@       Mode    0=�ŏI���ځ@1=���z�@2=�I��
    '   �@�@       Value   �ύX�l
    '   �@�\   :   ���ʓ��͌�^���z�ύX���@�ɍs���B
    '-------------------------------------------------------------------------------
    Private Sub MeisaiChange(ByRef Index As Short, ByRef Mode As Short, ByRef Value As Object)

        Dim SelPos As Short
        Dim lp As Short
        Dim wkVal As Double
        Dim wkCmp As Double

        If LoadFlg = 1 Then Exit Sub

        '----- �I���ʒu
        SelPos = CInt2(ctlGeppo1(Index).Value(0)) - 1
        If SelPos < 0 Then Exit Sub

        Select Case Mode
            Case 0 '----- �ŏI���ړ��͌�
                Select Case Index
                    Case 0 To DspMax - 1
                        ctlGeppo1(Index + 1).Focus()
                    Case DspMax
                        imDate1(0).Focus()
                        If SelPos < InpMax Then
                            VScroll1.Value = VScroll1.Value + 1
                            ctlGeppo1(DspMax).Focus()
                        End If
                End Select

            Case 1 '----- �������z�ύX��
                NowSB(SelPos).UKEOI_GAKU = Value
                wkVal = CCur2(imNumber1(0).Value)
                For lp = 0 To InpMax
                    wkVal = wkVal + NowSB(lp).UKEOI_GAKU
                Next lp
                ' ���v���z
                wkCmp = CDbl(imText5(0).Text)
                '2021.07.26 UPGRADE S  AIT)Tool Convert
                'imText5(0).Text = VB6.Format(wkVal, "#,##0")
                imText5(0).Text = CDec(wkVal).ToString("#,##0")
                '2021.07.26 UPGRADE E
                If wkCmp <> CDbl(imText5(0).Text) Then
                    ' �Čv�Z
                    Call CalcKingaku(0)
                End If

            Case 2 '----- ���͏I����
                Call RowDataGet(Index, NowSB(SelPos))
        End Select

    End Sub

    '-------------------------------------------------------------------------------
    '   ����    :   ���z�̎Z�o
    '   �֐�    :   Sub CalcKingaku()
    '   ����    :   Mode    0=�������z�@1=�������o�����@2=�扺�z�@3=�O�񖘐������o����
    '   �ߒl    :   �Ȃ�
    '   �@�\    :   ���z�̎Z�o���s���܂��B
    '-------------------------------------------------------------------------------
    Private Sub CalcKingaku(ByRef Mode As Short)

        Dim wkVal As Decimal

        Select Case Mode
            Case 0
                ' �H�����v = �������z - ���s�\�Z�z
                wkVal = CCur2(imText5(0).Text) - CCur2(imText5(1).Text)
                '2021.07.26 UPGRADE S  AIT)Tool Convert
                'imText5(2).Text = VB6.Format(wkVal, "#,##0")
                '' ���v�� = �H�����v / �������z
                imText5(2).Text = CDec(wkVal).ToString("#,##0")
                ' ���v�� = �H�����v / �������z
                '2021.07.26 UPGRADE E
                If CCur2(imText5(0).Text) = 0 Then wkVal = 0 Else wkVal = CCur2(imText5(2).Text) / CCur2(imText5(0).Text)
                '2021.07.26 UPGRADE S  AIT)Tool Convert
                'imText5(3).Text = VB6.Format(wkVal * 100, "0.0") & "%"
                '' �������o����
                imText5(3).Text = CDec(wkVal * 100).ToString("0.0") & "%"
                ' �������o����
                '2021.07.26 UPGRADE E
                If Len(imText7(0).Text) = 0 Then wkVal = 0 Else wkVal = CCur2(Mid(imText7(0).Text, 1, Len(imText7(0).Text) - 1))
                wkVal = CCur2(imText5(0).Text) * (wkVal / 100)
                '2021.08.11 UPGRADE S  AIT)hieutv
                'imNumber2(0).Value = VB6.Format(wkVal)
                imNumber2(0).Value = wkVal.ToString
                '2021.08.11 UPGRADE E
                ' �������o�����F��
                If CCur2(imText5(0).Text) = 0 Then wkVal = 0 Else wkVal = CCur2(imNumber2(0).Value) / CCur2(imText5(0).Text)
                '2021.07.26 UPGRADE S  AIT)Tool Convert
                'imText7(1).Text = VB6.Format(wkVal * 100, "0.0") & "%"
                '' ���񐿕��o����
                imText7(1).Text = CDec(wkVal * 100).ToString("0.0") & "%"
                ' ���񐿕��o����
                '2021.07.26 UPGRADE E
                wkVal = CCur2(imNumber2(0).Value) - CCur2(imNumber2(3).Value)
                '2021.07.26 UPGRADE S  AIT)Tool Convert
                'imText6(4).Text = VB6.Format(wkVal, "#,##0")
                '' �扺�c��
                imText6(4).Text = CDec(wkVal).ToString("#,##0")
                ' �扺�c��
                '2021.07.26 UPGRADE E
                wkVal = CCur2(imText5(0).Text) - CCur2(imNumber2(2).Value)
                '2021.07.26 UPGRADE S  AIT)Tool Convert
                'imText6(5).Text = VB6.Format(wkVal, "#,##0")
                imText6(5).Text = CDec(wkVal).ToString("#,##0")
                '2021.07.26 UPGRADE E

            Case 1
                ' �������o�����F��
                If CCur2(imText5(0).Text) = 0 Then wkVal = 0 Else wkVal = CCur2(imNumber2(0).Value) / CCur2(imText5(0).Text)
                '2021.07.26 UPGRADE S  AIT)Tool Convert
                'imText7(1).Text = VB6.Format(wkVal * 100, "0.0") & "%"
                '' ���񐿕��o����
                imText7(1).Text = CDec(wkVal * 100).ToString("0.0") & "%"
                ' ���񐿕��o����
                '2021.07.26 UPGRADE E
                wkVal = CCur2(imNumber2(0).Value) - CCur2(imNumber2(3).Value)
                '2021.07.26 UPGRADE S  AIT)Tool Convert
                'imText6(4).Text = VB6.Format(wkVal, "#,##0")
                imText6(4).Text = CDec(wkVal).ToString("#,##0")
                '2021.07.26 UPGRADE E

            Case 2
                ' �扺�c��
                wkVal = CCur2(imText5(0).Text) - CCur2(imNumber2(2).Value)
                '2021.07.26 UPGRADE S  AIT)Tool Convert
                'imText6(5).Text = VB6.Format(wkVal, "#,##0")
                imText6(5).Text = CDec(wkVal).ToString("#,##0")
                '2021.07.26 UPGRADE E

            Case 3
                ' ���񐿕��o����
                wkVal = CCur2(imNumber2(0).Value) - CCur2(imNumber2(3).Value)
                '2021.07.26 UPGRADE S  AIT)Tool Convert
                'imText6(4).Text = VB6.Format(wkVal, "#,##0")
                imText6(4).Text = CDec(wkVal).ToString("#,##0")
                '2021.07.26 UPGRADE E
        End Select

    End Sub

    '-------------------------------------------------------------------------------
    '   ����    :   ���̓f�[�^�̃`�F�b�N
    '   �֐�    :   Function DispDataCheck()
    '   ����    :   �Ȃ�
    '   �ߒl    :   True  ���͐���
    '   �@�@    :   False ���̓G���[
    '   �@�\    :   ���̓f�[�^���`�F�b�N���܂��B
    '-------------------------------------------------------------------------------
    Private Function DispDataCheck() As Boolean

        DispDataCheck = False

        '----- ���̑�
        If TextCharCheck(Trim(imText1(0).Text)) > 0 Then
            '2021.09.14 UPGRADE S  AIT)dannnl
            'MsgBox("���̑��ɂ́u ' �v�u " & Chr(34) & " �v���g�p�ł��܂���B", MsgBoxStyle.Information)
            MsgBox("���̑��ɂ́u ' �v�u " & Chr(34) & " �v���g�p�ł��܂���B", MsgBoxStyle.Information, SYSTEMNM)
            '2021.09.14 UPGRADE E
            imText1(0).Focus()
            Exit Function
        End If
        If TextCharCheck(Trim(imText1(1).Text)) > 0 Then
            '2021.09.14 UPGRADE S  AIT)dannnl
            'MsgBox("���̑��ɂ́u ' �v�u " & Chr(34) & " �v���g�p�ł��܂���B", MsgBoxStyle.Information)
            MsgBox("���̑��ɂ́u ' �v�u " & Chr(34) & " �v���g�p�ł��܂���B", MsgBoxStyle.Information, SYSTEMNM)
            '2021.09.14 UPGRADE E
            imText1(1).Focus()
            Exit Function
        End If

        DispDataCheck = True

    End Function

    '-------------------------------------------------------------------------------
    '   ����    :   �f�[�^�̎��X�V
    '   �֐�    :   Function DataUpdate()
    '   ����    :   �Ȃ�
    '   �ߒl    :   True    ����I��
    '   �@�@        False   �ُ�I��
    '   �@�\    :   �f�[�^�̍X�V���s���܂��B
    '-------------------------------------------------------------------------------
    Private Function DataUpdate() As Boolean

        Dim lp As Short
        Dim Jouken As String

        ' �߂�l�̏�����
        DataUpdate = False

        ' ���̓`�F�b�N
        If DispDataCheck() = False Then
            Exit Function
        End If

        ' �H������f�[�^�̎擾
        Call DispDataGet()

        ' �X�V����
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
        '----- ��ݻ޸��݂̊J�n
        '2021.07.26 UPGRADE S  AIT)Tool Convert
        'SYKDB.BeginTrans()
        BeginTrans()
        '2021.07.26 UPGRADE E
        Do
            '----- �f�[�^�̍X�V
            Select Case UpMode
                Case "0" ' �ǉ�
                    If INSERT_GEPPOU_DATA_D(NowDT) = False Then
                        '2021.08.11 UPGRADE S  AIT)hieutv
                        'SYKDB.RollbackTrans()
                        Rollback()
                        '2021.08.11 UPGRADE E
                        Exit Do
                    End If
                Case "1" ' �C��
                    Jouken = "SIME_YM = '" & CtlKouji.SYORI_YM & "'"
                    Jouken = Jouken & " AND EDA_NO = '" & KeyKouji.EDA_NO & "'"
                    Jouken = Jouken & " AND KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"
                    If UPDATE_GEPPOU_DATA_D(Jouken, NowDT) = False Then
                        '2021.08.11 UPGRADE S  AIT)hieutv
                        'SYKDB.RollbackTrans()
                        Rollback()
                        '2021.08.11 UPGRADE E
                        Exit Do
                    End If
            End Select
            '----- ����t���O�i�y�؁j
            If UpdateCtrlFlg(11) = False Then
                '2021.08.11 UPGRADE S  AIT)hieutv
                'SYKDB.RollbackTrans()
                Rollback()
                '2021.08.11 UPGRADE E
                Exit Do
            End If
            '----- ��ݻ޸��݂̊m��
            '2021.07.26 UPGRADE S  AIT)Tool Convert
            'SYKDB.CommitTrans()
            '' �f�[�^�ޔ�
            CommitTransaction()
            ' �f�[�^�ޔ�
            '2021.07.26 UPGRADE E
            PreDT = NowDT
            '2021.07.26 UPGRADE S  AIT)Tool Convert
            'PreSB = VB6.CopyArray(NowSB)
            '' ����I��
            PreSB = NowSB.Clone
            ' ����I��
            '2021.07.26 UPGRADE E
            DataUpdate = True
            Exit Do
        Loop
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default

    End Function

    '-------------------------------------------------------------------------------
    '   ����    :   �ύX�`�F�b�N
    '   �֐�    :   Function ChangeCheck()
    '   ����    :   �Ȃ�
    '   �ߒl    :   True    �ύX����
    '   �@�@        False   �ύX�Ȃ�
    '   �@�\    :   �f�[�^���ύX���ꂽ���ǂ����`�F�b�N���s���܂��B
    '-------------------------------------------------------------------------------
    Private Function ChangeCheck() As Boolean

        ' �߂�l�̏�����
        ChangeCheck = True

        ' �f�[�^�̎擾
        Call DispDataGet()

        With NowDT
            If .JISSI_KEI <> PreDT.JISSI_KEI Then Exit Function '�݌v���{���z
            If .ZEN_JISSI_GAKU <> PreDT.ZEN_JISSI_GAKU Then Exit Function '�O�񖘎��{���z
            If .KON_JISSI_GAKU <> PreDT.KON_JISSI_GAKU Then Exit Function '�������{���z
            If .DEKI_GAKU <> PreDT.DEKI_GAKU Then Exit Function '�������o����
            If .ZEN_UKE_GAKU <> PreDT.ZEN_UKE_GAKU Then Exit Function '�O�񖘐����o����
            If .KON_UKE_GAKU <> PreDT.KON_UKE_GAKU Then Exit Function '���񐿕��o����
            If .MOKU_GAKU <> PreDT.MOKU_GAKU Then Exit Function '�����w�͖ڕW
            If .TORISAGE_GAKU <> PreDT.TORISAGE_GAKU Then Exit Function '�扺�z
            If .TORI_ZAN_GAKU <> PreDT.TORI_ZAN_GAKU Then Exit Function '�扺�c�z
            If Trim(.KOUKI_S_YMD) <> Trim(PreDT.KOUKI_S_YMD) Then Exit Function '�H���i���H�j
            If Trim(.KOUKI_E_YMD) <> Trim(PreDT.KOUKI_E_YMD) Then Exit Function '�H���i�v�H�j
            If Trim(.KOUKI_K_YMD) <> Trim(PreDT.KOUKI_K_YMD) Then Exit Function '�H���i�����j
            If .T_UKEOI_GAKU <> PreDT.T_UKEOI_GAKU Then Exit Function '�������z(����)
            If .T_YOSAN_GAKU <> PreDT.T_YOSAN_GAKU Then Exit Function '���s�\�Z(����)
            If .T_RIEKI_GAKU <> PreDT.T_RIEKI_GAKU Then Exit Function '�H�����v(����)
            If .K_UKEOI_GAKU <> PreDT.K_UKEOI_GAKU Then Exit Function '�������z(���Z����)
            If .K_YOSAN_GAKU <> PreDT.K_YOSAN_GAKU Then Exit Function '���s�\�Z(���Z����)
            If .K_RIEKI_GAKU <> PreDT.K_RIEKI_GAKU Then Exit Function '�H�����v(���Z����)
            If Trim(.H1_BIKOU) <> Trim(PreDT.H1_BIKOU) Then Exit Function '���l(�P)
            If .H1_UKEOI_GAKU <> PreDT.H1_UKEOI_GAKU Then Exit Function '�������z(�P)
            If .H1_YOSAN_GAKU <> PreDT.H1_YOSAN_GAKU Then Exit Function '���s�\�Z(�P)
            If .H1_RIEKI_GAKU <> PreDT.H1_RIEKI_GAKU Then Exit Function '�H�����v(�P)
            If Trim(.H2_BIKOU) <> Trim(PreDT.H2_BIKOU) Then Exit Function '���l(�Q)
            If .H2_UKEOI_GAKU <> PreDT.H2_UKEOI_GAKU Then Exit Function '�������z(�Q)
            If .H2_YOSAN_GAKU <> PreDT.H2_YOSAN_GAKU Then Exit Function '���s�\�Z(�Q)
            If .H2_RIEKI_GAKU <> PreDT.H2_RIEKI_GAKU Then Exit Function '�H�����v(�Q)
            If Trim(.H3_BIKOU) <> Trim(PreDT.H3_BIKOU) Then Exit Function '���l(�R)
            If .H3_UKEOI_GAKU <> PreDT.H3_UKEOI_GAKU Then Exit Function '�������z(�R)
            If .H3_YOSAN_GAKU <> PreDT.H3_YOSAN_GAKU Then Exit Function '���s�\�Z(�R)
            If .H3_RIEKI_GAKU <> PreDT.H3_RIEKI_GAKU Then Exit Function '�H�����v(�R)
            If Trim(.H4_BIKOU) <> Trim(PreDT.H4_BIKOU) Then Exit Function '���l(�S)
            If .H4_UKEOI_GAKU <> PreDT.H4_UKEOI_GAKU Then Exit Function '�������z(�S)
            If .H4_YOSAN_GAKU <> PreDT.H4_YOSAN_GAKU Then Exit Function '���s�\�Z(�S)
            If .H4_RIEKI_GAKU <> PreDT.H4_RIEKI_GAKU Then Exit Function '�H�����v(�S)
            If Trim(.H5_BIKOU) <> Trim(PreDT.H5_BIKOU) Then Exit Function '���l(�T)
            If .H5_UKEOI_GAKU <> PreDT.H5_UKEOI_GAKU Then Exit Function '�������z(�T)
            If .H5_YOSAN_GAKU <> PreDT.H5_YOSAN_GAKU Then Exit Function '���s�\�Z(�T)
            If .H5_RIEKI_GAKU <> PreDT.H5_RIEKI_GAKU Then Exit Function '�H�����v(�T)
            If Trim(.BIKOU1) <> Trim(PreDT.BIKOU1) Then Exit Function '���l�P
            If Trim(.BIKOU2) <> Trim(PreDT.BIKOU2) Then Exit Function '���l�Q
            If Trim(.SYOUNIN_FLG) <> Trim(PreDT.SYOUNIN_FLG) Then Exit Function '���F�t���O
        End With

        ' �ύX�Ȃ�
        ChangeCheck = False

    End Function

    Private Sub Check1_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles Check1.Enter
        '2021.08.11 UPGRADE S  AIT)hieutv
        'Call GotFocus(Check1, StatusBar1)
        Call MtyTool.GotFocus(Check1, StatusBar1)
        '2021.08.11 UPGRADE E
    End Sub

    Private Sub Check1_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles Check1.KeyDown
        Dim KeyCode As Short = eventArgs.KeyCode
        Dim Shift As Short = eventArgs.KeyData \ &H10000
        If KeyCode = System.Windows.Forms.Keys.Return Then
            cmdKey(1).Focus()
        End If
    End Sub

    Private Sub Check1_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles Check1.Leave
        '2021.08.11 UPGRADE S  AIT)hieutv
        'Call LostFocus(Check1, StatusBar1)
        Call MtyTool.LostFocus(Check1, StatusBar1)
        '2021.08.11 UPGRADE E
    End Sub

    '2021.08.11 UPGRADE S  AIT)hieutv
    'Private Sub cmdKey_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Click
    '    Dim Index As Short = cmdKey.GetIndex(eventSender)    
    Private Sub cmdKey_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _cmdKey_1.Click, _cmdKey_2.Click, _cmdKey_3.Click _
        , _cmdKey_4.Click, _cmdKey_5.Click, _cmdKey_6.Click, _cmdKey_7.Click, _cmdKey_8.Click, _cmdKey_9.Click, _cmdKey_10.Click, _cmdKey_11.Click, _cmdKey_12.Click
        Dim Index As Short = cmdKey.IndexOf(eventSender)
    '2021.08.11 UPGRADE E

        Select Case Index
            Case 1 '----- �o�^
                ' �f�[�^���X�V
                If DataUpdate() = False Then
                    Exit Sub
                End If

            Case 12 '----- �I��
                If ChangeCheck() = True Then
                    '2021.09.14 UPGRADE S  AIT)dannnl
                    'If MsgBox("�f�[�^���ύX����Ă��܂��B�{���ɏI�����܂����H", MsgBoxStyle.YesNo + MsgBoxStyle.Information) = MsgBoxResult.No Then
                    If MsgBox("�f�[�^���ύX����Ă��܂��B�{���ɏI�����܂����H", MsgBoxStyle.YesNo + MsgBoxStyle.Information, SYSTEMNM) = MsgBoxResult.No Then
                        '2021.09.14 UPGRADE E
                        Exit Sub
                    End If
                End If
        End Select

        frmSYKD010.Show()
        Me.Dispose()

    End Sub

    '2021.08.11 UPGRADE S  AIT)hieutv
    'Private Sub cmdKey_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Enter
    '    Dim Index As Short = cmdKey.GetIndex(eventSender)
    '    Call GotFocus(cmdKey(Index), StatusBar1)
    'End Sub

    'Private Sub cmdKey_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Leave
    '    Dim Index As Short = cmdKey.GetIndex(eventSender)
    '    Call LostFocus(cmdKey(Index), StatusBar1)
    'End Sub
    Private Sub cmdKey_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _cmdKey_1.Enter, _cmdKey_2.Enter, _cmdKey_3.Enter _
        , _cmdKey_4.Enter, _cmdKey_5.Enter, _cmdKey_6.Enter, _cmdKey_7.Enter, _cmdKey_8.Enter, _cmdKey_9.Enter, _cmdKey_10.Enter, _cmdKey_11.Enter, _cmdKey_12.Enter
        Dim Index As Short = cmdKey.IndexOf(eventSender)
        Call MtyTool.GotFocus(cmdKey(Index), StatusBar1)
    End Sub

    Private Sub cmdKey_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _cmdKey_1.Leave, _cmdKey_2.Leave, _cmdKey_3.Leave _
        , _cmdKey_4.Leave, _cmdKey_5.Leave, _cmdKey_6.Leave, _cmdKey_7.Leave, _cmdKey_8.Leave, _cmdKey_9.Leave, _cmdKey_10.Leave, _cmdKey_11.Leave, _cmdKey_12.Leave
        Dim Index As Short = cmdKey.IndexOf(eventSender)
        Call MtyTool.LostFocus(cmdKey(Index), StatusBar1)
    End Sub
    '2021.08.11 UPGRADE E

    Private Sub ctlEvents1_Change(ByVal Mode As Short, ByRef Value As Object) Handles ctlEvents1.Change
        Call MeisaiChange(0, Mode, Value)
    End Sub

    Private Sub ctlEvents2_Change(ByVal Mode As Short, ByRef Value As Object) Handles ctlEvents2.Change
        Call MeisaiChange(1, Mode, Value)
    End Sub

    Private Sub ctlEvents3_Change(ByVal Mode As Short, ByRef Value As Object) Handles ctlEvents3.Change
        Call MeisaiChange(2, Mode, Value)
    End Sub

    '2021.08.11 UPGRADE S  AIT)hieutv
    'Private Sub ctlGeppo1_GotFocus(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles ctlGeppo1.GotFocus
    '    Dim Index As Short = ctlGeppo1.GetIndex(eventSender)
    '    SelRow = Index
    'End Sub
    Private Sub ctlGeppo1_GotFocus(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _ctlGeppo1_0.Enter, _ctlGeppo1_1.Enter, _ctlGeppo1_2.Enter
        Dim Index As Short = ctlGeppo1.IndexOf(eventSender)
        SelRow = Index
    End Sub
    '2021.08.11 UPGRADE E

    Private Sub frmSYKD180_Activated(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Activated
        ' �����I��
        If StopFlg = 1 Then
            frmSYKD010.Show()
            '2021.08.31  UPGRADE S  AIT)hieutv
			'Me.Close()
			Me.Dispose()
			'2021.08.31  UPGRADE E
            Exit Sub
        End If
    End Sub

    Private Sub frmSYKD180_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown
        Dim KeyCode As Short = eventArgs.KeyCode
        Dim Shift As Short = eventArgs.KeyData \ &H10000
        Select Case KeyCode
            Case System.Windows.Forms.Keys.F1
                If cmdKey(1).Enabled = True Then cmdKey(1).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(1), New System.EventArgs())
            Case System.Windows.Forms.Keys.F2
                If cmdKey(2).Enabled = True Then cmdKey(2).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(2), New System.EventArgs())
            Case System.Windows.Forms.Keys.F3
                If cmdKey(3).Enabled = True Then cmdKey(3).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(3), New System.EventArgs())
            Case System.Windows.Forms.Keys.F4
                If cmdKey(4).Enabled = True Then cmdKey(4).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(4), New System.EventArgs())
            Case System.Windows.Forms.Keys.F5
                If cmdKey(5).Enabled = True Then cmdKey(5).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(5), New System.EventArgs())
            Case System.Windows.Forms.Keys.F6
                If cmdKey(6).Enabled = True Then cmdKey(6).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(6), New System.EventArgs())
            Case System.Windows.Forms.Keys.F7
                If cmdKey(7).Enabled = True Then cmdKey(7).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(7), New System.EventArgs())
            Case System.Windows.Forms.Keys.F8
                If cmdKey(8).Enabled = True Then cmdKey(8).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(8), New System.EventArgs())
            Case System.Windows.Forms.Keys.F9
                If cmdKey(9).Enabled = True Then cmdKey(9).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(9), New System.EventArgs())
            Case System.Windows.Forms.Keys.F10
                If cmdKey(10).Enabled = True Then cmdKey(10).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(10), New System.EventArgs())
            Case System.Windows.Forms.Keys.F11
                If cmdKey(11).Enabled = True Then cmdKey(11).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(11), New System.EventArgs())
            Case System.Windows.Forms.Keys.F12
                If cmdKey(12).Enabled = True Then cmdKey(12).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(12), New System.EventArgs())
        End Select
    End Sub

    Private Sub frmSYKD180_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load

        Dim lp As Short

        Call FormDisp(Me)

        StopFlg = 0
        LoadFlg = 1

        ' �����ݒ�
        For lp = 0 To DspMax
            ctlGeppo1(lp).StatusBar = StatusBar1
        Next lp
        ctlEvents1 = ctlGeppo1(0).Events
        ctlEvents2 = ctlGeppo1(1).Events
        ctlEvents3 = ctlGeppo1(2).Events

        ' �f�[�^�̈�̊m��
        ReDim PreSB(InpMax)
        ReDim NowSB(InpMax)

        ' �����\��
        Call DispClear()
        If ListDataDisp() = False Then
            StopFlg = 1
            Exit Sub
        End If

        LoadFlg = 0

        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default

    End Sub

    Private Sub frmSYKD180_FormClosing(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Dim Cancel As Boolean = eventArgs.Cancel
        Dim UnloadMode As System.Windows.Forms.CloseReason = eventArgs.CloseReason
        If UnloadMode = System.Windows.Forms.CloseReason.UserClosing Then
            If ChangeCheck() = True Then
                '2021.09.14 UPGRADE S  AIT)dannnl
                'If MsgBox("�f�[�^���ύX����Ă��܂��B�{���ɏI�����܂����H", MsgBoxStyle.YesNo + MsgBoxStyle.Information) = MsgBoxResult.No Then
                If MsgBox("�f�[�^���ύX����Ă��܂��B�{���ɏI�����܂����H", MsgBoxStyle.YesNo + MsgBoxStyle.Information, SYSTEMNM) = MsgBoxResult.No Then
                    '2021.09.14 UPGRADE E
                    Cancel = True
                    Exit Sub
                End If
            End If
            frmSYKD010.Show()
        End If
        eventArgs.Cancel = Cancel
    End Sub

    'Private Sub imDate1_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles imDate1.Enter
    '    Dim Index As Short = imDate1.GetIndex(eventSender)
    '    Call GotFocus(imDate1(Index), StatusBar1)
    'End Sub
    Private Sub imDate1_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _imDate1_0.Enter, _imDate1_1.Enter, _imDate1_2.Enter
        Dim Index As Short = imDate1.IndexOf(eventSender)
        Call MtyTool.GotFocus(imDate1(Index), StatusBar1)
    End Sub

    '2021.08.11 UPGRADE S  AIT)hieutv
    'Private Sub imDate1_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles imDate1.KeyDown
    Private Sub imDate1_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles _imDate1_0.KeyDown, _imDate1_1.KeyDown, _imDate1_2.KeyDown
    '2021.08.11 UPGRADE E
        Dim KeyCode As Short = eventArgs.KeyCode
        Dim Shift As Short = eventArgs.KeyData \ &H10000
        '2021.08.11 UPGRADE S  AIT)hieutv
        'Dim Index As Short = imDate1.GetIndex(eventSender)
        Dim Index As Short = imDate1.IndexOf(eventSender)
        '2021.08.11 UPGRADE E
        Select Case KeyCode
            Case System.Windows.Forms.Keys.Return
                Select Case Index
                    Case 0, 1
                        imDate1(Index + 1).Focus()
                    Case 2
                        imText1(0).Focus()
                End Select
        End Select
    End Sub
    '2021.08.11 UPGRADE E

    '2021.08.11 UPGRADE S  AIT)hieutv
    'Private Sub imDate1_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles imDate1.Leave
    '    Dim Index As Short = imDate1.GetIndex(eventSender)
    '    Call LostFocus(imDate1(Index), StatusBar1)
    'End Sub
    Private Sub imDate1_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _imDate1_0.Leave, _imDate1_1.Leave, _imDate1_2.Leave
        Dim Index As Short = imDate1.IndexOf(eventSender)
        Call MtyTool.LostFocus(imDate1(Index), StatusBar1)
    End Sub
    '2021.08.11 UPGRADE E

    '2021.08.11 UPGRADE S  AIT)hieutv
    'Private Sub imNumber1_Change(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles imNumber1.Change
    '    Dim Index As Short = imNumber1.GetIndex(eventSender)    
    Private Sub imNumber1_Change(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _imNumber1_0.ValueChanged, _imNumber1_1.ValueChanged
        Dim Index As Short = imNumber1.IndexOf(eventSender)
    '2021.08.11 UPGRADE E

        Dim wkVal As Decimal
        Dim lp As Short

        If LoadFlg = 1 Then Exit Sub

        ' �H�����v�̎Z�o
        wkVal = CCur2(imNumber1(0).Value) - CCur2(imNumber1(1).Value)
        '2021.07.26 UPGRADE S  AIT)Tool Convert
        'imText4(2).Text = VB6.Format(wkVal, "#,##0")
        '' ���v���̎Z�o
        imText4(2).Text = CDec(wkVal).ToString("#,##0")
        ' ���v���̎Z�o
        '2021.07.26 UPGRADE E
        wkVal = 0
        If CCur2(imNumber1(0).Value) <> 0 Then
            wkVal = CCur2(imText4(2).Text) / CCur2(imNumber1(0).Value)
        End If
        '2021.07.26 UPGRADE S  AIT)Tool Convert
        'imText4(3).Text = VB6.Format(wkVal * 100, "0.0") & "%"
        imText4(3).Text = CDec(wkVal * 100).ToString("0.0") & "%"
        '2021.07.26 UPGRADE E

        '----- �������z�̏ꍇ
        If Index = 0 Then
            ' ���z�W�v
            wkVal = CCur2(imNumber1(0).Value)
            '2021.09.01 UPGRADE DEL S AIT)hieutv
            'For lp = 0 To InpMax
            '    wkVal = wkVal + NowSB(lp).UKEOI_GAKU
            'Next lp
            '2021.09.01 UPGRADE DEL E
            '2021.07.26 UPGRADE S  AIT)Tool Convert
            'imText5(0).Text = VB6.Format(wkVal, "#,##0")
            '' �Čv�Z
            imText5(0).Text = CDec(wkVal).ToString("#,##0")
            ' �Čv�Z
            '2021.07.26 UPGRADE E
            Call CalcKingaku(0)
        End If

    End Sub

    '2021.08.11 UPGRADE S  AIT)hieutv
    'Private Sub imNumber1_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles imNumber1.Enter
    '    Dim Index As Short = imNumber1.GetIndex(eventSender)
    '    Call GotFocus(imNumber1(Index), StatusBar1)
    'End Sub
    Private Sub imNumber1_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _imNumber1_0.Enter, _imNumber1_1.Enter
        Dim Index As Short = imNumber1.IndexOf(eventSender)
        Call MtyTool.GotFocus(imNumber1(Index), StatusBar1)
    End Sub
    '2021.08.11 UPGRADE E

    '2021.08.11 UPGRADE S  AIT)hieutv
    'Private Sub imNumber1_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles imNumber1.KeyDown
    Private Sub imNumber1_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles _imNumber1_0.KeyDown, _imNumber1_1.KeyDown
    '2021.08.11 UPGRADE E
        Dim KeyCode As Short = eventArgs.KeyCode
        Dim Shift As Short = eventArgs.KeyData \ &H10000
        '2021.08.11 UPGRADE S  AIT)hieutv
        'Dim Index As Short = imNumber1.GetIndex(eventSender)
        Dim Index As Short = imNumber1.IndexOf(eventSender)
        '2021.08.11 UPGRADE E
        Select Case KeyCode
            Case System.Windows.Forms.Keys.Return
                Select Case Index
                    Case 0 : imNumber1(1).Focus()
                    Case 1 : ctlGeppo1(0).Focus()
                End Select
        End Select
    End Sub

    '2021.08.11 UPGRADE S  AIT)hieutv
    'Private Sub imNumber1_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles imNumber1.Leave
    '    Dim Index As Short = imNumber1.GetIndex(eventSender)
    '    Call LostFocus(imNumber1(Index), StatusBar1)
    'End Sub
    Private Sub imNumber1_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _imNumber1_0.Leave, _imNumber1_1.Leave
        Dim Index As Short = imNumber1.IndexOf(eventSender)
        Call MtyTool.LostFocus(imNumber1(Index), StatusBar1)
    End Sub
    '2021.08.11 UPGRADE E

    '2021.08.11 UPGRADE S  AIT)hieutv
    'Private Sub imNumber2_Change(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles imNumber2.Change
    '    Dim Index As Short = imNumber2.GetIndex(eventSender)    
    Private Sub imNumber2_Change(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _imNumber2_0.ValueChanged, _imNumber2_1.ValueChanged, _imNumber2_2.ValueChanged, _imNumber2_3.ValueChanged
        Dim Index As Short = imNumber2.IndexOf(eventSender)
    '2021.08.11 UPGRADE E

        If LoadFlg = 1 Then Exit Sub

        Select Case Index
            Case 0 '----- �������o����
                Call CalcKingaku(1)
            Case 1 '----- �����w�͖ڕW
                '
            Case 2 '----- �扺�z
                Call CalcKingaku(2)
            Case 3 '----- �O�񖘐������o����
                Call CalcKingaku(3)
        End Select

    End Sub

    '2021.08.11 UPGRADE S  AIT)hieutv
    'Private Sub imNumber2_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles imNumber2.Enter
    '    Dim Index As Short = imNumber2.GetIndex(eventSender)
    '    Call GotFocus(imNumber2(Index), StatusBar1)
    'End Sub
    Private Sub imNumber2_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _imNumber2_0.Enter, _imNumber2_1.Enter, _imNumber2_2.Enter, _imNumber2_3.Enter
        Dim Index As Short = imNumber2.IndexOf(eventSender)
        Call MtyTool.GotFocus(imNumber2(Index), StatusBar1)
    End Sub
    '2021.08.11 UPGRADE E

    '2021.08.11 UPGRADE S  AIT)hieutv
    'Private Sub imNumber2_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles imNumber2.KeyDown
    Private Sub imNumber2_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles _imNumber2_0.KeyDown, _imNumber2_1.KeyDown, _imNumber2_2.KeyDown, _imNumber2_3.KeyDown
    '2021.08.11 UPGRADE E
        Dim KeyCode As Short = eventArgs.KeyCode
        Dim Shift As Short = eventArgs.KeyData \ &H10000
        '2021.08.11 UPGRADE S  AIT)hieutv
        'Dim Index As Short = imNumber2.GetIndex(eventSender)
        Dim Index As Short = imNumber2.IndexOf(eventSender)
        '2021.08.11 UPGRADE E
        Select Case KeyCode
            Case System.Windows.Forms.Keys.Return
                Select Case Index
                    Case 0
                        imNumber2(3).Focus()
                    Case 1
                        imNumber2(2).Focus()
                    Case 2
                        Check1.Focus()
                    Case 3
                        imNumber2(1).Focus()
                End Select
        End Select
    End Sub

    '2021.08.11 UPGRADE S  AIT)hieutv
    'Private Sub imNumber2_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles imNumber2.Leave
    '    Dim Index As Short = imNumber2.GetIndex(eventSender)
    '    Call LostFocus(imNumber2(Index), StatusBar1)
    'End Sub

    'Private Sub imText1_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles imText1.Enter
    '    Dim Index As Short = imText1.GetIndex(eventSender)
    '    Call GotFocus(imText1(Index), StatusBar1)
    'End Sub
    Private Sub imNumber2_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _imNumber2_0.Leave, _imNumber2_1.Leave, _imNumber2_2.Leave, _imNumber2_3.Leave
        Dim Index As Short = imNumber2.IndexOf(eventSender)
        Call MtyTool.LostFocus(imNumber2(Index), StatusBar1)
    End Sub

    Private Sub imText1_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _imText1_0.Enter, _imText1_1.Enter
        Dim Index As Short = imText1.IndexOf(eventSender)
        Call MtyTool.GotFocus(imText1(Index), StatusBar1)
    End Sub
    '2021.08.11 UPGRADE E

    '2021.08.11 UPGRADE S  AIT)hieutv
    'Private Sub imText1_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles imText1.KeyDown
    Private Sub imText1_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles _imText1_0.KeyDown, _imText1_1.KeyDown
        '2021.08.11 UPGRADE E
        Dim KeyCode As Short = eventArgs.KeyCode
        Dim Shift As Short = eventArgs.KeyData \ &H10000
        '2021.08.11 UPGRADE S  AIT)hieutv
        'Dim Index As Short = imText1.GetIndex(eventSender)
        Dim Index As Short = imText1.IndexOf(eventSender)
        '2021.08.11 UPGRADE E
        Select Case KeyCode
            Case System.Windows.Forms.Keys.Return
                Select Case Index
                    Case 0 : imText1(1).Focus()
                    Case 1 : imNumber2(0).Focus()
                End Select
        End Select
    End Sub

    '2021.08.11 UPGRADE S  AIT)hieutv
    'Private Sub imText1_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles imText1.Leave
    '    Dim Index As Short = imText1.GetIndex(eventSender)
    '    Call LostFocus(imText1(Index), StatusBar1)
    'End Sub
    Private Sub imText1_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _imText1_0.Leave, _imText1_1.Leave
        Dim Index As Short = imText1.IndexOf(eventSender)
        Call MtyTool.LostFocus(imText1(Index), StatusBar1)
    End Sub
    '2021.08.11 UPGRADE E

    '2021.09.08 UPGRADE S  AIT)hieutv
    'Private Sub VScroll1_Change(ByVal newScrollValue As Integer)
    Private Sub VScroll1_Change(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles VScroll1.ValueChanged
    '2021.09.08 UPGRADE E

        System.Windows.Forms.Application.DoEvents()

        ' ���̓f�[�^�̎擾
        Call MeisaiChange(SelRow, 2, 0)
        ' �ĕ\��
        '2021.09.08 UPGRADE S  AIT)hieutv
        'Call MeisaiDataSet((newScrollValue), 0)
        Call MeisaiDataSet((VScroll1.Value), 0)
        '2021.09.08 UPGRADE E

    End Sub
    Private Sub VScroll1_Scroll(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.ScrollEventArgs) Handles VScroll1.Scroll
        Select Case eventArgs.Type
            Case System.Windows.Forms.ScrollEventType.EndScroll
                '2021.09.08 UPGRADE S  AIT)hieutv
                'VScroll1_Change(eventArgs.NewValue)
                ' ���̓f�[�^�̎擾
                Call MeisaiChange(SelRow, 2, 0)
                ' �ĕ\��
                Call MeisaiDataSet((eventArgs.NewValue), 0)
                '2021.09.08 UPGRADE E
        End Select
    End Sub
End Class
