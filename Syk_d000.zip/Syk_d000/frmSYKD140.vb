Option Strict Off
Option Explicit On
Imports System.Data.Common

Friend Class frmSYKD140
    Inherits System.Windows.Forms.Form
    '=============================================================
    ' ���[�U�[���@  �F  �R�z�H�Ɗ������
    ' �V�X�e�����@  �F  �H���Ǘ��V�X�e��
    ' ���W���[����  �F  �O���ꗗ
    ' ���W���[��ID�@�F  frmSYKD140.frm
    ' �쐬���@ �@�@ �F  ���� 13 �N 07 �� 10 ��
    ' �X�V���@�@  �@�F  ����    �N    ��    ��
    '=============================================================
    '
    '2021.08.10 UPGRADE S  AIT)vyhnt
    'Private Const RowHeight As Short = 15
    Private Const RowHeight As Short = 20
    '2021.08.10 UPGRADE E   

    '�O����{�f�[�^
    Private Structure KIHON_DATA_QRY
        '2021.07.26 UPGRADE S  AIT)Tool Convert
        '<VBFixedString(2),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=2)> Public CHUUMON_NO() As Char '�����ԍ�
        '<VBFixedString(40),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=40)> Public C_MEISYOU() As Char '��������
        '<VBFixedString(8),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=8)> Public GYOUSYA_CD() As Char '�Ǝк���
        '<VBFixedString(40),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=40)> Public G_MEISYOU() As Char '�ƎЖ���
        <VBFixedStringAttribute(2)> Public CHUUMON_NO As String  '�����ԍ�
        <VBFixedStringAttribute(40)> Public C_MEISYOU As String  '��������
        <VBFixedStringAttribute(8)> Public GYOUSYA_CD As String  '�Ǝк���
        <VBFixedStringAttribute(40)> Public G_MEISYOU As String  '�ƎЖ���
        '2021.07.26 UPGRADE E
        Dim KINGAKU As Decimal '���z
        '2021.07.26 UPGRADE S  AIT)Tool Convert
        '<VBFixedString(1),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=1)> Public HENKOU_FLG() As Char '�ύX�t���O
        '<VBFixedString(1),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=1)> Public SEISAN_FLG() As Char '���Z�t���O
        <VBFixedStringAttribute(1)> Public HENKOU_FLG As String  '�ύX�t���O
        <VBFixedStringAttribute(1)> Public SEISAN_FLG As String  '���Z�t���O
        '2021.07.26 UPGRADE E
    End Structure
    '

    '-------------------------------------------------------------------------------
    '   ����   :   �O���ꗗ�ύX�t���O�̎擾
    '   �֐�   :   Function GetGaichuFlg()
    '   ����   :   �Ȃ�
    '   �ߒl   :   �ύX�t���O
    '   �@�\   :   �O���ꗗ�̕ύX�t���O���擾���܂��B
    '-------------------------------------------------------------------------------
    Private Function GetGaichuFlg() As String

        Dim lp As Integer
        Dim ssText As Object
        Dim wkVal As Short

        ' ������
        wkVal = 0
        '2021.08.02 UPGRADE S  AIT)vyhnt
        'For lp = 1 To vaSpread1.MaxRows
        '	vaSpread1.GetText(6, lp, ssText)
        For lp = 1 To vaSpread1.ActiveSheet.RowCount
            ssText = vaSpread1.ActiveSheet.GetText(lp - 1, 5)
            '2021.08.02 UPGRADE E 
            If Trim(ssText) <> "" Then
                wkVal = wkVal + 1
                Exit For
            End If
        Next lp

        ' �߂�l�ɃZ�b�g
        '2021.07.26 UPGRADE S  AIT)Tool Convert
        'GetGaichuFlg = VB6.Format(wkVal, "0")
        GetGaichuFlg = CDec(wkVal).ToString("0")
        '2021.07.26 UPGRADE E

    End Function

    '-------------------------------------------------------------------------------
    '   ����   :   �f�[�^�̃N���A
    '   �֐�   :   Sub DispClear()
    '   ����   :   �Ȃ�
    '   �@�\   :   �f�[�^���N���A���܂��B
    '-------------------------------------------------------------------------------
    Private Sub DispClear()

        '----- �H�����
        With KeyKouji
            imText2(0).Text = .KOUJI_NO
            If .EDA_NO = "0000" Then
                imText2(1).Text = ""
            Else
                imText2(1).Text = .EDA_NO
            End If
            imText2(2).Text = .MEISYOU
        End With

        '----- ���N��
        '2021.07.26 UPGRADE S  AIT)Tool Convert
        'imText1(0).Text = VB6.Format(CtlKouji.SYORI_YM, "0000/00")
        If Not String.IsNullOrEmpty(CtlKouji.SYORI_YM) AndAlso IsDate(CDec(CtlKouji.SYORI_YM).ToString("0000/00")) = True Then
            imText1(0).Text = CDec(CtlKouji.SYORI_YM).ToString("0000/00")
        End If
        '2021.07.26 UPGRADE E
        '2021.08.02 UPGRADE S  AIT)vyhnt
        'vaSpread1.MaxRows = 0
        vaSpread1.ActiveSheet.RowCount = 0
        '2021.08.02 UPGRADE E        
        imText1(1).Text = "0"

        '----- �Q�ƃ��[�h
        If INPMODE <> "2" Then
            '2021.08.10 UPGRADE S  AIT)vyhnt
            'cmdKey(1).Text = "  F1  �\ ��"
            cmdKey(1).Text = "F1" & vbCrLf & "�\ ��"
            '2021.08.10 UPGRADE E
        End If

    End Sub

    '-------------------------------------------------------------------------------
    '   ����   :   GAI_KIHON_DATA �ǂݍ��ݏ���
    '   �֐�   :   Function SelectGaiKihon()
    '   ����   :   DT()�@   KIHON_DATA_QRY
    '   �ߒl   :   �ް���   ����I��
    '   �@�@       -1�@     �ُ�I��
    '   �@�\   :   GAI_KIHON_DATA SELECT����
    '-------------------------------------------------------------------------------
    Private Function SelectGaiKihon(ByRef DT() As KIHON_DATA_QRY) As Integer

        Dim SQL As String
        '2021.08.03 UPGRADE S  AIT)vyhnt
        'Dim Rs As ADODB.Recordset
        'Dim Fld As ADODB.Field
        Dim Rs As DataTable
        Dim Fld As DataColumn
        '2021.08.03 UPGRADE E  
        Dim Cnt As Integer
        Dim OpenFlg As Short

        '2021.07.26 UPGRADE S  AIT)Tool Convert
        'On Error GoTo SelectGaiKihon_Err
        Try
            '2021.07.26 UPGRADE E

            '�߂�l�̏�����
            SelectGaiKihon = -1

            'SQL/SELECT���g��
            SQL = "SELECT"
            SQL = SQL & " GAI_KIHON_DATA.CHUUMON_NO  AS CHUUMON_NO," '�����ԍ�
            SQL = SQL & " WARIDASI_MAST.MEISYOU      AS C_MEISYOU," '��������
            SQL = SQL & " WARIDASI_MAST.GYOUSYA_CD   AS GYOUSYA_CD," '�Ǝк���
            SQL = SQL & " GYOUSYA_MAST.MEISYOU       AS G_MEISYOU," '�ƎЖ���
            SQL = SQL & " GAI_KIHON_DATA.KON_SI_GAKU AS KINGAKU," '���z
            SQL = SQL & " GAI_KIHON_DATA.HENKOU_FLG  AS HENKOU_FLG," '�ύX�t���O
            SQL = SQL & " GAI_KIHON_DATA.SEISAN_FLG  AS SEISAN_FLG" '���Z�t���O
            SQL = SQL & " FROM GAI_KIHON_DATA INNER JOIN"
            SQL = SQL & " (WARIDASI_MAST INNER JOIN GYOUSYA_MAST"
            SQL = SQL & " ON WARIDASI_MAST.GYOUSYA_CD = GYOUSYA_MAST.GYOUSYA_CD)"
            SQL = SQL & " ON  (GAI_KIHON_DATA.CHUUMON_NO = WARIDASI_MAST.WARIDASI_NO)"
            SQL = SQL & " AND (GAI_KIHON_DATA.EDA_NO     = WARIDASI_MAST.EDA_NO)"
            SQL = SQL & " AND (GAI_KIHON_DATA.KOUJI_NO   = WARIDASI_MAST.KOUJI_NO)"
            SQL = SQL & " WHERE GAI_KIHON_DATA.EDA_NO = '" & KeyKouji.EDA_NO & "'"
            SQL = SQL & " AND GAI_KIHON_DATA.KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"
            SQL = SQL & " AND GAI_KIHON_DATA.SIME_YM  = '" & CtlKouji.SYORI_YM & "'"
            SQL = SQL & " ORDER BY GAI_KIHON_DATA.CHUUMON_NO"

            'SQL�����s
            '2021.08.03 UPGRADE S  AIT)vyhnt
            'Rs = SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText)
            Rs = RsOpen(SQL)
            '2021.08.03 UPGRADE E  
            OpenFlg = 1

            Cnt = 0
            '2021.08.03 UPGRADE S  AIT)vyhnt
            'Do Until Rs.EOF
            For Each Row As DataRow In Rs.Rows
                ReDim Preserve DT(Cnt)
                With DT(Cnt)
                    '----- ������
                    .CHUUMON_NO = "" '�����ԍ�
                    .C_MEISYOU = "" '��������
                    .GYOUSYA_CD = "" '�Ǝк���
                    .G_MEISYOU = "" '�ƎЖ���
                    .KINGAKU = 0 '���z
                    .HENKOU_FLG = "" '�ύX�t���O
                    .SEISAN_FLG = "" '���Z�t���O
                    '----- �\���̂�
                    'For Each Fld In Rs.Fields
                    For Each Fld In Rs.Columns
                        Dim FldValue = Row(Fld.ColumnName)
                        'If IsDBNull(Fld.Name) = False And IsDBNull(Fld.Value) = False Then
                        If IsDBNull(Fld.ColumnName) = False And IsDBNull(FldValue) = False Then
                            'Select Case UCase(Fld.Name)
                            Select Case UCase(Fld.ColumnName)
                                'Case "CHUUMON_NO" : .CHUUMON_NO = Fld.Value '�����ԍ�
                                'Case "C_MEISYOU" : .C_MEISYOU = Fld.Value '��������
                                'Case "GYOUSYA_CD" : .GYOUSYA_CD = Fld.Value '�Ǝк���
                                'Case "G_MEISYOU" : .G_MEISYOU = Fld.Value '�ƎЖ���
                                'Case "KINGAKU" : .KINGAKU = Fld.Value '���z
                                'Case "HENKOU_FLG" : .HENKOU_FLG = Fld.Value '�ύX�t���O
                                'Case "SEISAN_FLG" : .SEISAN_FLG = Fld.Value '���Z�t���O
                                Case "CHUUMON_NO" : .CHUUMON_NO = FldValue '�����ԍ�
                                Case "C_MEISYOU" : .C_MEISYOU = FldValue '��������
                                Case "GYOUSYA_CD" : .GYOUSYA_CD = FldValue '�Ǝк���
                                Case "G_MEISYOU" : .G_MEISYOU = FldValue '�ƎЖ���
                                Case "KINGAKU" : .KINGAKU = FldValue '���z
                                Case "HENKOU_FLG" : .HENKOU_FLG = FldValue '�ύX�t���O
                                Case "SEISAN_FLG" : .SEISAN_FLG = FldValue '���Z�t���O
                            End Select
                        End If
                    Next Fld
                End With
                Cnt = Cnt + 1
                'Rs.MoveNext()
                'Loop
            Next
            '2021.08.03 UPGRADE E  
            '2021.08.03 UPGRADE S  AIT)vyhnt
            'Rs.Close()
            Rs.Dispose()
            '2021.08.03 UPGRADE E  
            Rs = Nothing

            '�߂�l�̃Z�b�g
            SelectGaiKihon = Cnt
            Exit Function

            '2021.07.26 UPGRADE S  AIT)Tool Convert
            'SelectGaiKihon_Err:
        Catch ex As DbException
            '2021.07.26 UPGRADE E

            If OpenFlg = 1 Then
                '2021.08.03 UPGRADE S  AIT)vyhnt
                'Rs.Close()
                Rs.Dispose()
                '2021.08.03 UPGRADE E  

            End If
            Rs = Nothing

            Call Sql_Error_Msg(ex, "GAI_KIHON_DATA SELECT")

        End Try     '2021.07.26 UPGRADE ADD AIT)Tool Convert
    End Function

    '-------------------------------------------------------------------------------
    '   ����    :   �f�[�^�̎擾
    '   �֐�    :   Sub ListDataDisp()
    '   ����    :   Mode    0 = MsgBox�\��
    '   �@�\    :   �f�[�^�̎擾���s���܂��B
    '-------------------------------------------------------------------------------
    Public Sub ListDataDisp(Optional ByRef Mode As Short = 0)

        Dim Cnt As Integer
        Dim DT() As KIHON_DATA_QRY
        Dim wkBuf As String

        ' �J�[�\���������v��
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
        wkBuf = StatusBar1.Items.Item("Message").Text
        StatusBar1.Items.Item("Message").Text = "�Y���f�[�^�������E�E�E"

        ' �e�[�u���̓Ǎ���
        Cnt = SelectGaiKihon(DT)
        If Cnt <= 0 Then
            '2021.08.02 UPGRADE S  AIT)vyhnt
            'vaSpread1.MaxRows = 0
            vaSpread1.ActiveSheet.RowCount = 0
            '2021.08.02 UPGRADE E

            cmdKey(1).Enabled = False
            StatusBar1.Items.Item("Message").Text = wkBuf
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
            Exit Sub
        End If

        ' �X�v���b�h�ɕ\��
        Call SprdDataSet(Cnt, DT)

        StatusBar1.Items.Item("Message").Text = wkBuf
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default

    End Sub

    '-------------------------------------------------------------------------------
    '   ����    :   �X�v���b�h�\��
    '   �֐�    :   Sub SprdDataSet(DT())
    '   ����    :   Cnt     �f�[�^����
    '   �@�@    :   DT()    KIHON_DATA_QRY
    '   �@�\    :   �f�[�^���X�v���b�h�ɕ\�����܂��B
    '-------------------------------------------------------------------------------
    Private Sub SprdDataSet(ByRef Cnt As Integer, ByRef DT() As KIHON_DATA_QRY)

        Dim lp As Integer
        Dim Row As Integer
        Dim ssText As Object
        Dim wkVal As Decimal

        With vaSpread1
            '2021.08.02 UPGRADE S  AIT)vyhnt
            If Me.Visible = True Then
                '.ReDraw = False
                .ResumeLayout(False)
            End If
            '.MaxRows = Cnt
            '.Col = 1 : .Col2 = .MaxCols
            '.Row = 1 : .Row2 = .MaxRows
            '.BlockMode = True
            '.Action = FPSpread.ActionConstants.ActionClearText
            .ActiveSheet.RowCount = Cnt
            .ActiveSheet.ClearRange(0, 0, .ActiveSheet.RowCount, .ActiveSheet.ColumnCount, True)
            .ForeColor = System.Drawing.Color.Black
            '.BlockMode = False
            wkVal = 0
            For lp = 0 To Cnt - 1
                '.set_RowHeight(lp + 1, RowHeight)
                .ActiveSheet.SetRowHeight(lp, RowHeight)
                'Row = lp + 1
                Row = lp
                '----- ������
                ssText = Trim(DT(lp).CHUUMON_NO)
                '.SetText(1, Row, ssText)
                .ActiveSheet.SetText(Row, 0, ssText)
                '----- ����
                ssText = Trim(DT(lp).C_MEISYOU)
                '.SetText(2, Row, ssText)
                .ActiveSheet.SetText(Row, 1, ssText)
                '----- �Ǝк���
                ssText = Trim(DT(lp).GYOUSYA_CD)
                '.SetText(3, Row, ssText)
                .ActiveSheet.SetText(Row, 2, ssText)
                '----- �ƎЖ�
                ssText = Trim(DT(lp).G_MEISYOU)
                '.SetText(4, Row, ssText)
                .ActiveSheet.SetText(Row, 3, ssText)
                '----- ���z
                '2021.07.26 UPGRADE S  AIT)Tool Convert
                'ssText = VB6.Format(DT(lp).KINGAKU, "#,##0")
                ssText = CDec(DT(lp).KINGAKU).ToString("#,##0")
                '2021.07.26 UPGRADE E
                '.SetText(5, Row, ssText)
                .ActiveSheet.SetText(Row, 4, ssText)
                '----- �ύX�t���O
                Select Case DT(lp).HENKOU_FLG
                    Case "1"
                        ssText = "�ύX����"
                        '.Col = 1 : .Col2 = .MaxCols
                        '.Row = Row : .Row2 = Row
                        '.BlockMode = True
                        '.ForeColor = System.Drawing.Color.Red
                        .ActiveSheet.Rows(Row).ForeColor = System.Drawing.Color.Red
                        '.BlockMode = False
                    Case Else
                        ssText = ""
                        .ActiveSheet.Rows(Row).ForeColor = System.Drawing.Color.Black '2021.11.15  UPGRADE ADD  AIT)vyhnt
                End Select
                '.SetText(6, Row, ssText)
                .ActiveSheet.SetText(Row, 5, ssText)
                '----- ���Z�t���O
                Select Case DT(lp).SEISAN_FLG
                    Case "1"
                        ssText = "��"
                    Case Else
                        ssText = ""
                End Select
                '.SetText(7, Row, ssText)
                .ActiveSheet.SetText(Row, 6, ssText)
                '----- �W�v
                wkVal = wkVal + DT(lp).KINGAKU
            Next lp
            If Me.Visible = True Then
                '.CtlRefresh()
                .Refresh()
                '.ReDraw = True
                .ResumeLayout(True)
            End If
            '2021.08.02 UPGRADE E
            '2021.08.02 UPGRADE ADD  AIT)vyhnt
            .ActiveSheet.AddSelection(.ActiveSheet.ActiveRowIndex, .ActiveSheet.ActiveColumnIndex, .ActiveSheet.RowCount, .ActiveSheet.ColumnCount)
            .ActiveSheet.Rows(.ActiveSheet.RowCount - 1).Border = New FarPoint.Win.LineBorder(Color.Black, 1, False, False, False, True)
            '2021.08.02 UPGRADE S  AIT)  
        End With

        '----- ���v���z
        '2021.07.26 UPGRADE S  AIT)Tool Convert
        'imText1(1).Text = VB6.Format(wkVal, "#,##0")
        imText1(1).Text = CDec(wkVal).ToString("#,##0")
        '2021.07.26 UPGRADE E

    End Sub
    '2021.08.02 UPGRADE S  AIT)vyhnt
    'Private Sub cmdKey_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Click
    '	Dim Index As Short = cmdKey.GetIndex(eventSender)
    Private Sub cmdKey_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _cmdKey_1.Click, _cmdKey_2.Click, _cmdKey_3.Click, _cmdKey_4.Click, _cmdKey_5.Click, _cmdKey_6.Click,
                                                                                                                    _cmdKey_7.Click, _cmdKey_8.Click, _cmdKey_9.Click, _cmdKey_10.Click, _cmdKey_11.Click, _cmdKey_12.Click
        Dim Index As Short = cmdKey.IndexOf(eventSender)
        '2021.08.02 UPGRADE E    

        Dim ssText As Object

        Select Case Index
            Case 1 '----- ����
                Call MtyTool.LostFocus(cmdKey(1), StatusBar1)
                With vaSpread1
                    '2021.08.02 UPGRADE S  AIT)vyhnt
                    '.GetText(1, .ActiveRow, ssText) '�����ԍ�
                    ssText = .ActiveSheet.GetText(.ActiveSheet.ActiveRowIndex, 0) '�����ԍ�
                    '2021.08.02 UPGRADE E    

                    frmSYKD150.ChumonID = CStr(ssText)
                End With
                System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
                frmSYKD150.ShowDialog()
                vaSpread1.Focus()
                Call MtyTool.LostFocus(cmdKey(1), StatusBar1)
            Case 12 '----- �I��
                ' �ύX�`�F�b�N
                If GetGaichuFlg() = "0" Then
                    ' ����t���O�i�y�؁j
                    If UpdateCtrlFlg(9) = False Then
                        Exit Sub
                    End If
                End If
                frmSYKD010.Show()
                'Me.Close()
                Me.Dispose()
        End Select

    End Sub

    '2021.08.02 UPGRADE S  AIT)vyhnt
    'Private Sub cmdKey_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Enter
    '	Dim Index As Short = cmdKey.GetIndex(eventSender)
    '	Call GotFocus(cmdKey(Index), StatusBar1)
    'End Sub
    Private Sub cmdKey_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _cmdKey_1.Enter, _cmdKey_2.Enter, _cmdKey_3.Enter, _cmdKey_4.Enter, _cmdKey_5.Enter, _cmdKey_6.Enter,
                                                                                                                _cmdKey_7.Enter, _cmdKey_8.Enter, _cmdKey_9.Enter, _cmdKey_10.Enter, _cmdKey_11.Enter, _cmdKey_12.Enter
        Dim Index As Short = cmdKey.IndexOf(eventSender)
        Call MtyTool.GotFocus(cmdKey(Index), StatusBar1)
    End Sub

    '2021.08.02 UPGRADE S  AIT)vyhnt	'Private Sub cmdKey_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Leave
    '	Dim Index As Short = cmdKey.GetIndex(eventSender)
    '	Call LostFocus(cmdKey(Index), StatusBar1)
    'End Sub
    Private Sub cmdKey_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _cmdKey_1.Leave, _cmdKey_2.Leave, _cmdKey_3.Leave, _cmdKey_4.Leave, _cmdKey_5.Leave, _cmdKey_6.Leave,
                                                                                                                _cmdKey_7.Leave, _cmdKey_8.Leave, _cmdKey_9.Leave, _cmdKey_10.Leave, _cmdKey_11.Leave, _cmdKey_12.Leave
        Dim Index As Short = cmdKey.IndexOf(eventSender)
        Call MtyTool.LostFocus(cmdKey(Index), StatusBar1)
    End Sub
    'End Sub


    Private Sub frmSYKD140_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown
        Dim KeyCode As Short = eventArgs.KeyCode
        Dim Shift As Short = eventArgs.KeyData \ &H10000
        Select Case KeyCode
            Case System.Windows.Forms.Keys.F1
                If cmdKey(1).Enabled = True Then cmdKey(1).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(1), New System.EventArgs())
            Case System.Windows.Forms.Keys.F2
                If cmdKey(2).Enabled = True Then cmdKey(2).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(2), New System.EventArgs())
            Case System.Windows.Forms.Keys.F3
                If cmdKey(3).Enabled = True Then cmdKey(3).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(3), New System.EventArgs())
            Case System.Windows.Forms.Keys.F4
                If cmdKey(4).Enabled = True Then cmdKey(4).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(4), New System.EventArgs())
            Case System.Windows.Forms.Keys.F5
                If cmdKey(5).Enabled = True Then cmdKey(5).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(5), New System.EventArgs())
            Case System.Windows.Forms.Keys.F6
                If cmdKey(6).Enabled = True Then cmdKey(6).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(6), New System.EventArgs())
            Case System.Windows.Forms.Keys.F7
                If cmdKey(7).Enabled = True Then cmdKey(7).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(7), New System.EventArgs())
            Case System.Windows.Forms.Keys.F8
                If cmdKey(8).Enabled = True Then cmdKey(8).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(8), New System.EventArgs())
            Case System.Windows.Forms.Keys.F9
                If cmdKey(9).Enabled = True Then cmdKey(9).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(9), New System.EventArgs())
            Case System.Windows.Forms.Keys.F10
                If cmdKey(10).Enabled = True Then cmdKey(10).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(10), New System.EventArgs())
            Case System.Windows.Forms.Keys.F11
                If cmdKey(11).Enabled = True Then cmdKey(11).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(11), New System.EventArgs())
            Case System.Windows.Forms.Keys.F12
                If cmdKey(12).Enabled = True Then cmdKey(12).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(12), New System.EventArgs())
        End Select
    End Sub

    Private Sub frmSYKD140_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load

        Call FormDisp(Me)

        ' �����\��
        Call DispClear()
        Call ListDataDisp(1)

    End Sub

    Private Sub frmSYKD140_FormClosing(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Dim Cancel As Boolean = eventArgs.Cancel
        Dim UnloadMode As System.Windows.Forms.CloseReason = eventArgs.CloseReason
        If UnloadMode = System.Windows.Forms.CloseReason.UserClosing Then
            ' �ύX�`�F�b�N
            If GetGaichuFlg() = "0" Then
                ' ����t���O�i�y�؁j
                If UpdateCtrlFlg(9) = False Then
                    Cancel = True
                    Exit Sub
                End If
            End If
            frmSYKD010.Show()
        End If
        eventArgs.Cancel = Cancel
    End Sub

    '2021.08.02 UPGRADE S  AIT)vyhnt
    'Private Sub vaSpread1_DblClick(ByVal eventSender As System.Object, ByVal eventArgs As AxFPSpread._DSpreadEvents_DblClickEvent) Handles vaSpread1.DblClick
    'Private Sub vaSpread1_DblClick(ByVal eventSender As System.Object, ByVal eventArgs As AxFPSpread._DSpreadEvents_DblClickEvent) Handles vaSpread1.DoubleClick
    Private Sub vaSpread1_DblClick(ByVal eventSender As System.Object, ByVal eventArgs As FarPoint.Win.Spread.CellClickEventArgs) Handles vaSpread1.CellDoubleClick
        '	If eventArgs.col > 0 And eventArgs.row > 0 Then
        If eventArgs.Column >= 0 AndAlso eventArgs.Row >= 0 AndAlso eventArgs.ColumnHeader = False AndAlso eventArgs.RowHeader = False Then
            Call cmdKey_Click(cmdKey.Item(1), New System.EventArgs())
        End If
    End Sub

    '2021.08.02 UPGRADE S  AIT)vyhnt
    'Private Sub vaSpread1_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles vaSpread1.Enter
    '	Call GotFocus(vaSpread1, StatusBar1)
    Private Sub vaSpread1_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles vaSpread1.Enter
        Call MtyTool.GotFocus(vaSpread1, StatusBar1)
        '2021.08.02 UPGRADE E    
    End Sub

    '2021.08.02 UPGRADE S  AIT)vyhnt
    'Private Sub vaSpread1_KeyDownEvent(ByVal eventSender As System.Object, ByVal eventArgs As AxFPSpread._DSpreadEvents_KeyDownEvent) Handles vaSpread1.KeyDownEvent
    Private Sub vaSpread1_KeyDownEvent(ByVal eventSender As System.Object, ByVal eventArgs As KeyEventArgs) Handles vaSpread1.KeyDown
        If eventArgs.KeyCode = System.Windows.Forms.Keys.Return Then
            'If vaSpread1.ActiveRow > 0 Then
            If vaSpread1.ActiveSheet.ActiveRowIndex >= 0 Then
                '2021.08.02 UPGRADE E    
                Call cmdKey_Click(cmdKey.Item(1), New System.EventArgs())
            End If
        End If
    End Sub

    Private Sub vaSpread1_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles vaSpread1.Leave
        '2021.08.02 UPGRADE S  AIT)vyhnt.
        'Call LostFocus(vaSpread1, StatusBar1)
        Call MtyTool.LostFocus(vaSpread1, StatusBar1)
        '2021.08.02 UPGRADE E   
    End Sub
End Class
