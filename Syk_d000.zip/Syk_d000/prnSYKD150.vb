Option Strict Off
Option Explicit On
Imports C1.Win.C1Document
Imports C1.Win.FlexReport
Imports System.Drawing.Printing
Module prnSYKD150
	'=============================================================
	' ���[�U�[���@  �F  �R�z�H�Ɗ������
	' �V�X�e�����@  �F  �H���Ǘ��V�X�e��
	' ���W���[����  �F  �O�����̓`�F�b�N���X�g�ꗗ���
	' ���W���[��ID�@�F  prnSYKD150.bas
	' �쐬���@ �@�@ �F  ���� 13 �N 07 �� 24 ��
	' �X�V���@�@  �@�F  ���� 13 �N 08 �� 29 ��
	'=============================================================
	'
	
	Private P_Cnt As Short ' ����y�[�W�J�E���g
	Private XX() As Single ' ����w�ʒu
	Private YY() As Single ' ����x�ʒu
	'
	
	'-------------------------------------------------------------------------------
	'   ����    :   �O�����̓`�F�b�N���X�g�ꗗ���
	'   �֐�    :   Function PrnMainD150()
	'   ����    :   ����
	'   �ߒl    :   True    ����I��
	'   �@�@        False   ���f
	'-------------------------------------------------------------------------------
	Public Function PrnMainD150() As Object
		
		Dim SQL As String
		Dim Jouken As String
		Dim Order As String
		Dim DT() As GAI_KIHON_DATA_DBT ' �O��(��{)�f�[�^�p
		Dim Cnt As Integer
		Dim lp As Integer
		Dim pryy As Single
		Dim R_Cnt As Integer
		Dim L_Length As Single
		
		' �����̐ݒ�
		Jouken = "KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"
		Jouken = Jouken & " AND EDA_NO = '" & KeyKouji.EDA_NO & "'"
		Jouken = Jouken & " AND SIME_YM = '" & CtlKouji.SYORI_YM & "'"
		''���܂�2007/09/06-------------------------------------------------------------------------����������-
		''����������ꍇ�Ɏx���z���O�~���ƃ`�F�b�N���X�g���������Ȃ��Ή�
		'    Jouken = Jouken & " AND (KON_SI_GAKU + ZEI_GAKU) <> 0 "
		''--------����������------------
		'    Jouken = Jouken & " AND ((KON_SI_GAKU + ZEI_GAKU) <> 0 OR KON_HIKI_GAKU<>0 ) "
		''���܂�2007/09/06-------------------------------------------------------------------------����������-
		'2013/12/09 �C�� ----------------------------------------------------------------------����������
		'����x���z���O OR ��������z���O OR �݌Ɂ��O �̊O����ΏۂƂ���
		Jouken = Jouken & " AND ((KON_SI_GAKU + ZEI_GAKU) <> 0 OR KON_HIKI_GAKU<>0 "
		Jouken = Jouken & " OR ( SELECT SUM(IPPAN_DATA.H_ZAIKO) FROM IPPAN_DATA "
		Jouken = Jouken & " WHERE"
		Jouken = Jouken & " KOUJI_NO = GAI_KIHON_DATA.KOUJI_NO"
		Jouken = Jouken & " AND EDA_NO = GAI_KIHON_DATA.EDA_NO"
		Jouken = Jouken & " AND SIME_YM = GAI_KIHON_DATA.SIME_YM"
		Jouken = Jouken & " AND CHUUMON_NO = GAI_KIHON_DATA.CHUUMON_NO"
		Jouken = Jouken & " AND MEISAI_KB = '2'"
		Jouken = Jouken & " AND S_FLG_GENKA = '1') <> 0 )"
		'--------------------------------------------------------------------------------------����������
		Order = "KOUJI_NO, EDA_NO, CHUUMON_NO"
		
		' �f�[�^�̒��o(�O���}�X�^)
		Cnt = 0
		Cnt = SELECT_GAI_KIHON_DATA(Jouken, Order, DT)
		
		If Cnt <= 0 Then
			PrnMainD150 = True
			Exit Function
		End If
		
		' �v�����^�[�f�o�C�X�̓ǂݍ���
		Call INI_PRN_Read(1)
		
		' �����ݒ�
		If PrnFirstD150() = False Then
			Exit Function
		End If
		
		' ����ʒu�̎擾
		Call PrXYGetD150()
		
		' ������
		P_Cnt = 1 : pryy = YY(0)
		
		' ���o����(�y�[�W���o��)
		Call PrItemPD150(pryy)
		'----- ���s
		pryy = pryy + ((P_YY * 1.5) * 5)
		
		If PrnCancel = 1 Then
			'----- ���f
			Call PRN_ErrEnd()
			Exit Function
		End If
		
		For lp = 0 To Cnt - 1
			' ���y�[�W�`�F�b�N
			'----- ���R�[�h�����̎擾
			R_Cnt = PrRcntD150(DT(lp))
			'----- �󎚕��̎擾(�f�[�^�s(R_Cnt) + ���o���s(10))
			L_Length = P_YY * (R_Cnt + 10) * 1.5 + P_YY * 5
			If NewPage_CHK(pryy, L_Length) = False Then
				'----- ���y�[�W
				Call PRN_NewPage()
				'----- �y�[�W���̍X�V
				P_Cnt = P_Cnt + 1
				'----- �󎚈ʒu�̃��Z�b�g
				pryy = YY(0)
				' ���o����(�y�[�W���o��)
				Call PrItemPD150(pryy)
				'----- ���s
				pryy = pryy + ((P_YY * 1.5) * 5)
			End If
			'----- ����(�d�؂��)
			Call PRN_LINE(XX(0), pryy, XX(UBound(XX)), pryy, 20, "")
			' ���o��(���ڌ��o��)
			Call PrItemD150(pryy, DT(lp))
			' �_��f�[�^
			Call PrDataD150(pryy, DT(lp))
			'----- ���s
			pryy = pryy + (P_YY * 1.5)
			' �_����z���f�[�^
			Call PrData2D150(pryy, DT(lp))
			'----- ���s
			pryy = pryy + ((P_YY * 1.5) * 4)
			' �����f�[�^
			Call PrData3D150(pryy, DT(lp))
			' �J�Ѓf�[�^
			Call PrData4D150(pryy, DT(lp))
			'----- ���s
			pryy = pryy + ((P_YY * 1.5) * 3)
		Next lp
		
		' ����t���O(�`�F�b�N���X�g)�̍X�V
		
		SQL = "UPDATE " & GAI_KIHON_DATA_TBLNAME
		SQL = SQL & " SET"
		SQL = SQL & " P_FLG_CHECK = '1'" ' ���FLG ����ؽ�
		SQL = SQL & " WHERE KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'" ' �H���ԍ�
		SQL = SQL & " AND EDA_NO = '" & KeyKouji.EDA_NO & "'" ' �H���}��
		SQL = SQL & " AND SIME_YM = '" & CtlKouji.SYORI_YM & "'" ' ���N��
		SQL = SQL & " AND NYUURYOKU_FLG = '01'" ' ���͒[���t���O(�y��"01")
		SQL = SQL & " AND P_FLG_CHECK <> '1'" ' ���FLG ����ؽ�

		' SQL�����s
		'2021.08.05 UPGRADE S  AIT)dannnl
		'SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText + ADODB.ExecuteOptionEnum.adExecuteNoRecords)
		ExecSQL(SQL)
		'2021.08.05 UPGRADE E

		' ����I��
		Call PRN_END()

		' �v���r���[�\��
		If ViewFlg = True Then
			frmSYKD075.StatusBar1.Items.Item("Message").Text = ""
			ViewForm.ShowDialog()
		End If

		'����I��
		PrnMainD150 = True
		
	End Function
	
	'-------------------------------------------------------------------------------
	'   ����    :   �����ݒ�
	'   �֐�    :   Sub     PrnFirstD150()
	'   ����    :   ����
	'   �ߒl    :   True    ����I��
	'   �@�@        False   �Y���Ȃ�
	'-------------------------------------------------------------------------------
	Private Function PrnFirstD150() As Boolean
		
		' �߂�l�̏�����
		PrnFirstD150 = False
		
		' �^�C�g���ݒ�
		DocName = "�O�����̓`�F�b�N���X�g�ꗗ"
		
		' �v�����^�[�f�o�C�X�̐ݒ�
		If Printer_Set(PRN1) = False Then
			'2021.09.14 UPGRADE S  AIT)dannnl
			'MsgBox("�ݒ�ɖ����v�����^�[�f�o�C�X���w�肳��܂����B")
			MsgBox("�ݒ�ɖ����v�����^�[�f�o�C�X���w�肳��܂����B", MsgBoxStyle.ApplicationModal, SYSTEMNM)
			'2021.09.14 UPGRADE E
			Exit Function
		End If

		' �p���ݒ�
		'2021.08.18 UPGRADE S  AIT)dannnl
		'P_SIZE = PrinterObjectConstants.vbPRPSA4 ' �`�S
		'P_ORIENT = VSPrinter7Lib.OrientationSettings.orPortrait ' ��:orLandscape,�c:orPortrait
		P_SIZE = PaperKind.A4 ' �`�S
		P_ORIENT = OrientationEnum.Portrait ' ��:orLandscape,�c:orPortrait
		'2021.08.18 UPGRADE E
		F_SIZE = 12
		
		' ����ďo��ʂ̃Z�b�g
		CallForm = frmSYKD150
		
		' ��������ݒ�
		If PRN_First(ViewForm) = False Then
			'2021.09.14 UPGRADE S  AIT)dannnl
			'MsgBox("�v�����^�̐ݒ�Ɏ��s���܂����B", MsgBoxStyle.Exclamation)
			MsgBox("�v�����^�̐ݒ�Ɏ��s���܂����B", MsgBoxStyle.Exclamation, SYSTEMNM)
			'2021.09.14 UPGRADE E
			Exit Function
		End If
		
		' ����I��
		PrnFirstD150 = True
		
	End Function
	
	'-------------------------------------------------------------------------------
	'   ����    :   ����ʒu�ݒ菈��
	'   �֐�    :   Sub PrXYGetD150()
	'   ����    :   ����
	'   �ߒl    :   ����
	'-------------------------------------------------------------------------------
	Private Sub PrXYGetD150()
		
		Dim PrLen As Short
		Dim xMargn As Short
		
		' ���ڐ��̐ݒ�
		ReDim XX(8)
		ReDim YY(1)
		
		' �����񒷂̎Z�o(PrLen=94)
		PrLen = 0
		PrLen = PrLen + Len(Space(4)) ' �H�����ށ{�H��ԍ�
		PrLen = PrLen + Len(Space(40)) ' �H�햼��
		PrLen = PrLen + Len(Space(10)) ' �_�񌈒�z
		PrLen = PrLen + Len(Space(10)) ' ����o����
		PrLen = PrLen + Len(Space(10)) ' �o�����݌v
		PrLen = PrLen + Len(Space(10)) ' ����x���z
		PrLen = PrLen + Len(Space(10)) ' �x���c�z
		
		' �t�H���g�T�C�Y�̎Z�o
		xMargn = 9
		'2021.08.19 UPGRADE S  AIT)dannnl
		'F_SIZE = PRN_FontGet(P_XX * xMargn * 2, P_WIDTH, Basic_F, Space(PrLen))
		F_SIZE = PRN_FontGet(P_XX * xMargn * 2, P_WIDTH, Basic_F, New String(")", PrLen))
		'2021.08.19 UPGRADE E

		' �P�������E�����̍Đݒ�
		'2021.08.18 UPGRADE S  AIT)dannnl
		'P_XX = PRN.TextWidth("M")
		'P_YY = PRN.TextHeight("M")
		P_XX = TextWidthToTwips("M")
		P_YY = TextHeightToTwips("M")
		'2021.08.18 UPGRADE E

		' ���ڈ󎚈ʒu�̐ݒ� Y��
		YY(0) = P_YY * 7
		YY(1) = YY(0) + P_YY * 1.5
		
		' ���ڈ󎚈ʒu�̐ݒ� X��
		XX(0) = P_XX * xMargn ' �r�����[
		XX(1) = XX(0) + P_XX * 1 ' �H�����ށ{�H��ԍ�
		XX(2) = XX(1) + P_XX * (4 + 4) ' �H�햼��
		XX(3) = XX(2) + P_XX * (40 + 4) ' �_�񌈒�z
		XX(4) = XX(3) + P_XX * (10 + 4) ' ����o����
		XX(5) = XX(4) + P_XX * (10 + 4) ' �o�����݌v
		XX(6) = XX(5) + P_XX * (10 + 4) ' ����x���z
		XX(7) = XX(6) + P_XX * (10 + 4) ' �x���c�z
		XX(8) = P_WIDTH - P_XX * xMargn ' �r���E�[
		
	End Sub
	
	'-------------------------------------------------------------------------------
	'   ����    :   ���ڈ������(�y�[�W���o��)
	'   �֐�    :   Sub PrItemPD150()
	'   ����    :   pryy    �󎚂x�ʒu
	'   �ߒl    :   �Ȃ�
	'-------------------------------------------------------------------------------
	Private Sub PrItemPD150(ByRef pryy As Single)
		
		Dim PR_WK_Renamed As PR_WK
		Dim PR_Text As String
		Dim yMargn As Single
		Dim i As Short
		
		' ���f
		If PrnCancel = 1 Then Exit Sub
		
		'----- �]��
		yMargn = P_YY * 0.25
		
		' dummy
		PR_WK_Renamed.DT = ""
		PR_WK_Renamed.FS = F_SIZE
		PR_WK_Renamed.X = XX(0)
		PR_WK_Renamed.Y = YY(0)
		Call PRN_DATA(PR_WK_Renamed)
		
		'----- �w�b�_
		' �^�C�g��
		PR_WK_Renamed.DT = "���� �O�����̓`�F�b�N���X�g�ꗗ ����"
		PR_WK_Renamed.FS = 12
		'2021.08.18 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.X = PRN_XGet(1, XX(0), XX(4), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
		PRN_XGet(1, XX(0), XX(4), PR_WK_Renamed)
		'2021.08.18 UPGRADE E
		PR_WK_Renamed.Y = pryy + yMargn
		Call PRN_DATA(PR_WK_Renamed, Nothing, Nothing, True)
		' ����
		Call PRN_LINE(XX(5), pryy, XX(UBound(XX)), pryy, 20, "")
		Call PRN_LINE(XX(5), YY(1), XX(UBound(XX)), YY(1), 20, "")
		Call PRN_LINE(XX(5), pryy + ((P_YY * 1.5) * 4), XX(UBound(XX)), pryy + ((P_YY * 1.5) * 4), 20, "")
		
		For i = 0 To 5
			Call PRN_LINE(XX(5) + (((XX(UBound(XX)) - XX(5)) / 5) * i), pryy, XX(5) + (((XX(UBound(XX)) - XX(5)) / 5) * i), pryy + ((P_YY * 1.5) * 4), 20, "")
		Next i
		For i = 0 To 4
			Select Case i
				Case 0 : PR_WK_Renamed.DT = Trim(CHECKLIST01)
				Case 1 : PR_WK_Renamed.DT = Trim(CHECKLIST02)
				Case 2 : PR_WK_Renamed.DT = Trim(CHECKLIST03)
				Case 3 : PR_WK_Renamed.DT = Trim(CHECKLIST04)
				Case 4 : PR_WK_Renamed.DT = Trim(CHECKLIST05)
			End Select
			PR_WK_Renamed.FS = 7.25
			'2021.08.19 UPGRADE S  AIT)dannnl
			'PR_WK_Renamed.X = PRN_XGet(1, XX(5) + (((XX(UBound(XX)) - XX(5)) / 5) * i), XX(5) + (((XX(UBound(XX)) - XX(5)) / 5) * (i + 1)), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
			PRN_XGet(1, XX(5) + (((XX(UBound(XX)) - XX(5)) / 5) * i), XX(5) + (((XX(UBound(XX)) - XX(5)) / 5) * (i + 1)), PR_WK_Renamed)
			'2021.08.19 UPGRADE E			
			PR_WK_Renamed.Y = YY(0) + yMargn
			Call PRN_DATA(PR_WK_Renamed)
		Next i

		' ����y�[�W
		'2021.08.05 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.DT = VB6.Format(P_Cnt) & " ��"
		PR_WK_Renamed.DT = P_Cnt & " ��"
		'2021.08.05 UPGRADE E
		PR_WK_Renamed.FS = F_SIZE
		'2021.08.19 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.X = PRN_XGet(2, XX(0), XX(4), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
		PRN_XGet(2, XX(0), XX(4), PR_WK_Renamed)
		'2021.08.19 UPGRADE E
		PR_WK_Renamed.Y = pryy + (P_YY * 1.5) + yMargn
		Call PRN_DATA(PR_WK_Renamed)
		' �����
		'2021.08.03 UPGRADE S  AIT)Tool Convert
		'PR_WK_Renamed.DT = "������t�F" & VB6.Format(Today, "yyyy/mm/dd")
		PR_WK_Renamed.DT = "������t�F" & Today.ToString("yyyy/MM/dd")
		'2021.08.03 UPGRADE E
		PR_WK_Renamed.FS = F_SIZE
		'2021.08.19 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.X = PRN_XGet(2, XX(0), XX(4), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
		PRN_XGet(2, XX(0), XX(4), PR_WK_Renamed)
		'2021.08.19 UPGRADE E
		PR_WK_Renamed.Y = pryy + ((P_YY * 1.5) * 2) + yMargn
		Call PRN_DATA(PR_WK_Renamed)
		' ����
		'2021.08.03 UPGRADE S  AIT)Tool Convert
		'PR_WK_Renamed.DT = "�����F" & VB6.Format(CtlKouji.SYORI_YM, "0000/00")
		PR_WK_Renamed.DT = "�����F" & CDec(CtlKouji.SYORI_YM).ToString("0000/00")
		'2021.08.03 UPGRADE E
		PR_WK_Renamed.FS = F_SIZE
		'2021.08.19 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.X = PRN_XGet(0, XX(0), XX(4), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
		PRN_XGet(0, XX(0), XX(4), PR_WK_Renamed)
		'2021.08.19 UPGRADE E
		PR_WK_Renamed.Y = pryy + ((P_YY * 1.5) * 2) + yMargn
		Call PRN_DATA(PR_WK_Renamed)
		' �H���ԍ��{�}�ԁ{�H������
		PR_Text = ""
		If CtlKouji.EDA_NO <> "0000" Then PR_Text = "- " & CtlKouji.EDA_NO & Space(1)
		PR_WK_Renamed.DT = "�H���ԍ��F" & CtlKouji.KOUJI_NO & Space(1) & PR_Text & "�H�����́F" & GetNameKouji(CtlKouji.KOUJI_NO, CtlKouji.EDA_NO)
		PR_WK_Renamed.FS = F_SIZE
		'2021.08.19 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.X = PRN_XGet(0, XX(0), XX(4), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
		PRN_XGet(0, XX(0), XX(4), PR_WK_Renamed)
		'2021.08.19 UPGRADE E
		PR_WK_Renamed.Y = pryy + ((P_YY * 1.5) * 3) + yMargn
		Call PRN_DATA(PR_WK_Renamed)

	End Sub

	'-------------------------------------------------------------------------------
	'   ����    :   ���ڈ������
	'   �֐�    :   Sub PrItemD150(�ƎЁ`���ڌ��o��)
	'   ����    :   pryy    �󎚂x�ʒu
	'   �@�@        DT()    GAI_KIHON_DATA_DBT
	'   �ߒl    :   �Ȃ�
	'-------------------------------------------------------------------------------
	Private Sub PrItemD150(ByRef pryy As Single, ByRef DT As GAI_KIHON_DATA_DBT)

		Dim SQL As String
		'2021.08.05 UPGRADE S  AIT)dannnl
		'Dim Rs As ADODB.Recordset
		'Dim Cnt As Integer
		Dim Rs As New DataTable
		'2021.08.05 UPGRADE E
		Dim OpenFlg As Short

		Dim PR_WK_Renamed As PR_WK
		Dim PR_Text As String
		Dim yMargn As Single

		' ���f
		If PrnCancel = 1 Then Exit Sub

		'----- �]��
		yMargn = P_YY * 0.25

		'----- ���s
		pryy = pryy + (P_YY * 0.5)

		' �񍀖�
		'----- 1�s��
		' �����ԍ�
		PR_WK_Renamed.DT = "����No." & Space(1) & DT.CHUUMON_NO
		PR_WK_Renamed.FS = F_SIZE
		'2021.08.19 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.X = PRN_XGet(0, XX(0), XX(1), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
		PRN_XGet(0, XX(0), XX(2) + P_XX * (2), PR_WK_Renamed)
		'2021.08.19 UPGRADE E
		PR_WK_Renamed.Y = pryy + yMargn
		Call PRN_DATA(PR_WK_Renamed)
		' �Ǝк��ށ{�ƎЖ���
		PR_Text = ""
		'(���o���}�X�^���Ǝк��ނ��擾����)
		SQL = "SELECT"
		SQL = SQL & " GYOUSYA_CD"
		SQL = SQL & " FROM WARIDASI_MAST"
		SQL = SQL & " WHERE"
		SQL = SQL & " KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"
		SQL = SQL & " AND EDA_NO = '" & KeyKouji.EDA_NO & "'"
		SQL = SQL & " AND WARIDASI_NO = '" & DT.CHUUMON_NO & "'"
		'SQL�����s
		'2021.08.05 UPGRADE S  AIT)dannnl
		'Rs = SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText)
		Rs = RsOpen(SQL)
		'2021.08.05 UPGRADE E
		OpenFlg = 1
		'2021.08.05 UPGRADE S  AIT)dannnl
		'PR_Text = Rs.Fields("GYOUSYA_CD").Value
		'Rs.Close()
		If Rs.Rows.Count > 0 Then PR_Text = Rs.Rows(0)("GYOUSYA_CD")
		Rs.Dispose()
		'2021.08.05 UPGRADE E
		Rs = Nothing
		PR_WK_Renamed.DT = "�Ǝк���:" & Space(1) & PR_Text & Space(2) & "�ƎЖ���:" & Space(1) & GetNameGyousya(PR_Text)
		PR_WK_Renamed.FS = F_SIZE
		'2021.08.19 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.X = PRN_XGet(0, XX(2) + P_XX * (2), XX(6), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
		PRN_XGet(0, XX(2) + P_XX * (2), XX(6), PR_WK_Renamed)
		'2021.08.19 UPGRADE E
		PR_WK_Renamed.Y = pryy + yMargn
		Call PRN_DATA(PR_WK_Renamed)
		' �x���䗦
		PR_WK_Renamed.DT = "�U��:" & Space(1) & DT.HIRITU_FURI & Space(2) & "����:" & Space(1) & DT.HIRITU_GEN & Space(2) & "��`:" & Space(1) & DT.HIRITU_TE
		PR_WK_Renamed.FS = F_SIZE
		'2021.08.19 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.X = PRN_XGet(1, XX(6), XX(8), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
		PRN_XGet(1, XX(6), XX(8), PR_WK_Renamed)
		'2021.08.19 UPGRADE E
		PR_WK_Renamed.Y = pryy + yMargn
		Call PRN_DATA(PR_WK_Renamed)

		' ���Z��    2003/04/21 �ǉ�
		If DT.SEISAN_FLG = "1" Then
			PR_WK_Renamed.DT = "�y���Z�ρz"
			PR_WK_Renamed.FS = F_SIZE
			'2021.08.19 UPGRADE S  AIT)dannnl
			'PR_WK_Renamed.X = PRN_XGet(2, XX(2), XX(6), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
			PRN_XGet(2, XX(2), XX(6), PR_WK_Renamed)
			'2021.08.19 UPGRADE E
			PR_WK_Renamed.Y = pryy + yMargn
			Call PRN_DATA(PR_WK_Renamed)
		End If

		'----- ���s
		pryy = pryy + ((P_YY * 1.5) * 1.5)
		'----- ����
		Call PRN_LINE(XX(0), pryy, XX(UBound(XX)), pryy, 20, "")

		'----- 2�s��
		' �H�����ށ{�H��ԍ�
		PR_WK_Renamed.DT = "�H��"
		PR_WK_Renamed.FS = F_SIZE
		'2021.08.19 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.X = PRN_XGet(0, XX(1), XX(2), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
		PRN_XGet(0, XX(1), XX(2), PR_WK_Renamed)
		'2021.08.19 UPGRADE E
		PR_WK_Renamed.Y = pryy + yMargn
		Call PRN_DATA(PR_WK_Renamed)
		' �H�햼��
		PR_WK_Renamed.DT = "�H�햼��"
		PR_WK_Renamed.FS = F_SIZE
		'2021.08.19 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.X = PRN_XGet(0, XX(2), XX(3), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
		PRN_XGet(0, XX(2), XX(3), PR_WK_Renamed)
		'2021.08.19 UPGRADE E
		PR_WK_Renamed.Y = pryy + yMargn
		Call PRN_DATA(PR_WK_Renamed)
		' �_�񌈒�z
		PR_WK_Renamed.DT = "�_�񌈒�z"
		PR_WK_Renamed.FS = F_SIZE
		'2021.08.19 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.X = PRN_XGet(2, XX(3), XX(4), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
		PRN_XGet(2, XX(3), XX(4), PR_WK_Renamed)
		'2021.08.19 UPGRADE E
		PR_WK_Renamed.Y = pryy + yMargn
		Call PRN_DATA(PR_WK_Renamed)
		' ����o����
		PR_WK_Renamed.DT = "����o����"
		PR_WK_Renamed.FS = F_SIZE
		'2021.08.19 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.X = PRN_XGet(2, XX(4), XX(5), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
		PRN_XGet(2, XX(4), XX(5), PR_WK_Renamed)
		'2021.08.19 UPGRADE E
		PR_WK_Renamed.Y = pryy + yMargn
		Call PRN_DATA(PR_WK_Renamed)
		' �o�����݌v
		PR_WK_Renamed.DT = "�o�����݌v"
		PR_WK_Renamed.FS = F_SIZE
		'2021.08.19 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.X = PRN_XGet(2, XX(5), XX(6), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
		PRN_XGet(2, XX(5), XX(6), PR_WK_Renamed)
		'2021.08.19 UPGRADE E
		PR_WK_Renamed.Y = pryy + yMargn
		Call PRN_DATA(PR_WK_Renamed)
		' ����x���z
		PR_WK_Renamed.DT = "����x���z"
		PR_WK_Renamed.FS = F_SIZE
		'2021.08.19 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.X = PRN_XGet(2, XX(6), XX(7), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
		PRN_XGet(2, XX(6), XX(7), PR_WK_Renamed)
		'2021.08.19 UPGRADE E
		PR_WK_Renamed.Y = pryy + yMargn
		Call PRN_DATA(PR_WK_Renamed)
		' �x���c�z
		PR_WK_Renamed.DT = "�x���c�z"
		PR_WK_Renamed.FS = F_SIZE
		'2021.08.19 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.X = PRN_XGet(2, XX(7), XX(8), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
		PRN_XGet(2, XX(7), XX(8), PR_WK_Renamed)
		'2021.08.19 UPGRADE E
		PR_WK_Renamed.Y = pryy + yMargn
		Call PRN_DATA(PR_WK_Renamed)

		'----- ���s
		pryy = pryy + (P_YY * 1.5)
		'----- ����
		Call PRN_LINE(XX(0), pryy, XX(UBound(XX)), pryy, 20, "")

	End Sub

	'-------------------------------------------------------------------------------
	'   ����    :   �O��(�_��)�f�[�^�������
	'   �֐�    :   Sub PrDataD150()
	'   ����    :   pryy    ����x�ʒu
	'   �@�@        DT()    GAI_KEIYAKU_DATA_DBT
	'   �ߒl    :   �Ȃ�
	'-------------------------------------------------------------------------------
	Private Sub PrDataD150(ByRef pryy As Single, ByRef DT As GAI_KIHON_DATA_DBT)

		Dim SQL As String
		'2021.08.05 UPGRADE S  AIT)dannnl
		'Dim Rs As ADODB.Recordset
		Dim Rs As New DataTable
		'2021.08.05 UPGRADE E
		Dim OpenFlg As Short
		Dim DT2() As GAI_KEIYAKU_DATA_DBT ' �O��(�_��)�f�[�^�p
		Dim Cnt2 As Integer : Cnt2 = 0
		Dim lp2 As Integer
		Dim PR_WK_Renamed As PR_WK
		Dim yMargn As Single
		Dim G_KETTEI As Integer : G_KETTEI = 0 ' �_�񌈒�z���v
		Dim G_DEKI_KON As Integer : G_DEKI_KON = 0 ' ����o�������v
		Dim G_DEKI_RUI As Integer : G_DEKI_RUI = 0 ' �o�����݌v���v
		Dim G_SIHA_KON As Integer : G_SIHA_KON = 0 ' ����x���z���v
		Dim G_SIHA_ZAN As Integer : G_SIHA_ZAN = 0 ' �x���c�z���v

		' �O��(�_��)�f�[�^�̓ǂݍ���
		' SQL/SELECT���g��
		SQL = "SELECT"
		SQL = SQL & " CHUUMON_NO,"
		SQL = SQL & " KOUSYU_CD,"
		SQL = SQL & " KOUSYU_NO,"
		SQL = SQL & " KETTEI_GAKU,"
		SQL = SQL & " KON_DEKI_GAKU,"
		SQL = SQL & " DEKI_KEI,"
		SQL = SQL & " KON_SI_GAKU"
		SQL = SQL & " FROM " & GAI_KEIYAKU_DATA_TBLNAME
		SQL = SQL & " WHERE GAI_KEIYAKU_DATA.KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"
		SQL = SQL & " AND GAI_KEIYAKU_DATA.EDA_NO = '" & KeyKouji.EDA_NO & "'"
		SQL = SQL & " AND GAI_KEIYAKU_DATA.CHUUMON_NO = '" & DT.CHUUMON_NO & "'"
		SQL = SQL & " AND GAI_KEIYAKU_DATA.SIME_YM = '" & CtlKouji.SYORI_YM & "'"

		'SQL�����s
		'2021.08.05 UPGRADE S  AIT)dannnl
		'Rs = SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText)
		Rs = RsOpen(SQL)
		'2021.08.05 UPGRADE E
		OpenFlg = 1

		'2021.08.05 UPGRADE S  AIT)dannnl
		'Do Until Rs.EOF
		For Each Row As DataRow In Rs.Rows
			'2021.08.05 UPGRADE E
			ReDim Preserve DT2(Cnt2)
			'2021.08.05 UPGRADE S  AIT)dannnl
			'Call DATSET_GAI_KEIYAKU_DATA(Rs, DT2(Cnt2))
			Call DATSET_GAI_KEIYAKU_DATA(Row, DT2(Cnt2))
			'2021.08.05 UPGRADE E
			Cnt2 = Cnt2 + 1
			'2021.08.05 UPGRADE S  AIT)dannnl
			'	Rs.MoveNext()
			'Loop

			'Rs.Close()
		Next

		Rs.Dispose()
		'2021.08.05 UPGRADE E
		Rs = Nothing

		If Cnt2 <= 0 Then
			Exit Sub
		End If

		'----- �]��
		yMargn = P_YY * 0.25

		For lp2 = 0 To Cnt2 - 1
			'���y�[�W�`�F�b�N(�����y�[�W�ɂȂ�ꍇ)
			If NewPage_CHK(pryy, P_YY * 5) = False Then
				'----- ���y�[�W
				Call PRN_NewPage()
				'----- �y�[�W���̍X�V
				P_Cnt = P_Cnt + 1
				'----- �󎚈ʒu�̃��Z�b�g
				pryy = YY(0)
				' ���o����(�y�[�W���o��)
				Call PrItemPD150(pryy)
				'----- ���s
				pryy = pryy + ((P_YY * 1.5) * 5)
				'----- ����(�d�؂��)
				Call PRN_LINE(XX(0), pryy, XX(UBound(XX)), pryy, 20, "")
				' ���o����(���ڌ��o��)
				Call PrItemD150(pryy, DT)
			End If
			' �H�����ށ{�H��ԍ�
			PR_WK_Renamed.DT = DT2(lp2).KOUSYU_CD & "-" & DT2(lp2).KOUSYU_NO
			PR_WK_Renamed.FS = F_SIZE
			'2021.08.19 UPGRADE S  AIT)dannnl
			'PR_WK_Renamed.X = PRN_XGet(0, XX(1), XX(2), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
			PRN_XGet(0, XX(1), XX(2), PR_WK_Renamed)
			'2021.08.19 UPGRADE E
			PR_WK_Renamed.Y = pryy + yMargn
			Call PRN_DATA(PR_WK_Renamed)
			' �H�햼��
			PR_WK_Renamed.DT = GetNameKousyu("01", DT2(lp2).KOUSYU_CD, "00") & " - " & GetNameKousyu("01", DT2(lp2).KOUSYU_CD, DT2(lp2).KOUSYU_NO)
			PR_WK_Renamed.FS = F_SIZE
			'2021.08.19 UPGRADE S  AIT)dannnl
			'PR_WK_Renamed.X = PRN_XGet(0, XX(2), XX(3), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
			PRN_XGet(0, XX(2), XX(3), PR_WK_Renamed)
			'2021.08.19 UPGRADE E
			PR_WK_Renamed.Y = pryy + yMargn
			Call PRN_DATA(PR_WK_Renamed)
			' �_�񌈒�z
			'2021.08.05 UPGRADE S  AIT)dannnl
			'PR_WK_Renamed.DT = VB6.Format(DT2(lp2).KETTEI_GAKU, "#,###,###,##0")
			PR_WK_Renamed.DT = DT2(lp2).KETTEI_GAKU.ToString("#,###,###,##0")
			'2021.08.05 UPGRADE E
			PR_WK_Renamed.FS = F_SIZE
			'2021.08.19 UPGRADE S  AIT)dannnl
			'PR_WK_Renamed.X = PRN_XGet(2, XX(3), XX(4), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
			PRN_XGet(2, XX(3), XX(4), PR_WK_Renamed)
			'2021.08.19 UPGRADE E
			PR_WK_Renamed.Y = pryy + yMargn
			Call PRN_DATA(PR_WK_Renamed)
			' ����o����
			'2021.08.05 UPGRADE S  AIT)dannnl
			'PR_WK_Renamed.DT = VB6.Format(DT2(lp2).KON_DEKI_GAKU, "#,###,###,##0")
			PR_WK_Renamed.DT = DT2(lp2).KON_DEKI_GAKU.ToString("#,###,###,##0")
			'2021.08.05 UPGRADE E
			PR_WK_Renamed.FS = F_SIZE
			'2021.08.19 UPGRADE S  AIT)dannnl
			'PR_WK_Renamed.X = PRN_XGet(2, XX(4), XX(5), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
			PRN_XGet(2, XX(4), XX(5), PR_WK_Renamed)
			'2021.08.19 UPGRADE E
			PR_WK_Renamed.Y = pryy + yMargn
			Call PRN_DATA(PR_WK_Renamed)
			' �o�����݌v
			'2021.08.05 UPGRADE S  AIT)dannnl
			'PR_WK_Renamed.DT = VB6.Format(DT2(lp2).DEKI_KEI + DT2(lp2).KON_DEKI_GAKU, "#,###,###,##0")
			PR_WK_Renamed.DT = (DT2(lp2).DEKI_KEI + DT2(lp2).KON_DEKI_GAKU).ToString("#,###,###,##0")
			'2021.08.05 UPGRADE E
			PR_WK_Renamed.FS = F_SIZE
			'2021.08.19 UPGRADE S  AIT)dannnl
			'PR_WK_Renamed.X = PRN_XGet(2, XX(5), XX(6), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
			PRN_XGet(2, XX(5), XX(6), PR_WK_Renamed)
			'2021.08.19 UPGRADE E
			PR_WK_Renamed.Y = pryy + yMargn
			Call PRN_DATA(PR_WK_Renamed)
			' ����x���z
			'2021.08.05 UPGRADE S  AIT)dannnl
			'PR_WK_Renamed.DT = VB6.Format(DT2(lp2).KON_SI_GAKU, "#,###,###,##0")
			PR_WK_Renamed.DT = DT2(lp2).KON_SI_GAKU.ToString("#,###,###,##0")
			'2021.08.05 UPGRADE E
			PR_WK_Renamed.FS = F_SIZE
			'2021.08.19 UPGRADE S  AIT)dannnl
			'PR_WK_Renamed.X = PRN_XGet(2, XX(6), XX(7), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
			PRN_XGet(2, XX(6), XX(7), PR_WK_Renamed)
			'2021.08.19 UPGRADE E
			PR_WK_Renamed.Y = pryy + yMargn
			Call PRN_DATA(PR_WK_Renamed)
			' �e���z���v����
			G_KETTEI = G_KETTEI + DT2(lp2).KETTEI_GAKU
			G_DEKI_KON = G_DEKI_KON + DT2(lp2).KON_DEKI_GAKU
			G_DEKI_RUI = G_DEKI_RUI + DT2(lp2).DEKI_KEI + DT2(lp2).KON_DEKI_GAKU
			G_SIHA_KON = G_SIHA_KON + DT2(lp2).KON_SI_GAKU
			G_SIHA_ZAN = G_SIHA_ZAN + DT2(lp2).SI_ZAN

			'----- ���s
			pryy = pryy + (P_YY * 1.5)
			'----- ����
			'2021.08.18 UPGRADE S  AIT)dannnl
			'Call PRN_LINE(XX(0), pryy, XX(UBound(XX)), pryy, 1, "", VSDraw7Lib.PenStyleSettings.psDot)
			Call PRN_LINE(XX(0), pryy, XX(UBound(XX)), pryy, 1, "", DashStyle.Dot)
			'2021.08.18 UPGRADE E

		Next lp2

		' ���v��
		Call PrDataGD150(pryy, G_KETTEI, G_DEKI_KON, G_DEKI_RUI, G_SIHA_KON, G_SIHA_ZAN)

	End Sub

	'-------------------------------------------------------------------------------
	'   ����    :   �O��(�_��)�f�[�^���v�������
	'   �֐�    :   Sub PrDataGD150()
	'   ����    :   pryy            ����x�ʒu
	'   �@�@        G_KETTEI        �_�񌈒�z(���v)
	'   �@�@        G_DEKI_KON      ����o����(���v)
	'   �@�@        G_DEKI_RUI      �o�����݌v(���v)
	'   �@�@        G_SIHA_KON      ����x���z(���v)
	'   �ߒl    :   �Ȃ�
	'-------------------------------------------------------------------------------
	Private Sub PrDataGD150(ByRef pryy As Single, ByRef G_KETTEI As Integer, ByRef G_DEKI_KON As Integer, ByRef G_DEKI_RUI As Integer, ByRef G_SIHA_KON As Integer, ByRef G_SIHA_ZAN As Integer)

		Dim PR_WK_Renamed As PR_WK
		Dim yMargn As Single

		'----- ����(�d�؂��)
		Call PRN_LINE(XX(0), pryy, XX(UBound(XX)), pryy, 10, "")

		'----- �]��
		yMargn = P_YY * 0.25

		' ���o��(���v)
		PR_WK_Renamed.DT = "���v"
		PR_WK_Renamed.FS = F_SIZE
		'2021.08.19 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.X = PRN_XGet(2, XX(2), XX(3), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
		PRN_XGet(2, XX(2), XX(3), PR_WK_Renamed)
		'2021.08.19 UPGRADE E
		PR_WK_Renamed.Y = pryy + yMargn
		Call PRN_DATA(PR_WK_Renamed)
		' �_�񌈒�z(���v)
		'2021.08.05 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.DT = VB6.Format(G_KETTEI, "#,###,###,##0")
		PR_WK_Renamed.DT = G_KETTEI.ToString("#,###,###,##0")
		'2021.08.05 UPGRADE E
		PR_WK_Renamed.FS = F_SIZE
		'2021.08.19 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.X = PRN_XGet(2, XX(3), XX(4), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
		PRN_XGet(2, XX(3), XX(4), PR_WK_Renamed)
		'2021.08.19 UPGRADE E
		PR_WK_Renamed.Y = pryy + yMargn
		Call PRN_DATA(PR_WK_Renamed)
		' ����o����(���v)
		'2021.08.05 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.DT = VB6.Format(G_DEKI_KON, "#,###,###,##0")
		PR_WK_Renamed.DT = G_DEKI_KON.ToString("#,###,###,##0")
		'2021.08.05 UPGRADE E
		PR_WK_Renamed.FS = F_SIZE
		'2021.08.19 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.X = PRN_XGet(2, XX(4), XX(5), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
		PRN_XGet(2, XX(4), XX(5), PR_WK_Renamed)
		'2021.08.19 UPGRADE E
		PR_WK_Renamed.Y = pryy + yMargn
		Call PRN_DATA(PR_WK_Renamed)
		' �o�����݌v(���v)
		'2021.08.05 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.DT = VB6.Format(G_DEKI_RUI, "#,###,###,##0")
		PR_WK_Renamed.DT = G_DEKI_RUI.ToString("#,###,###,##0")
		'2021.08.05 UPGRADE E
		PR_WK_Renamed.FS = F_SIZE
		'2021.08.19 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.X = PRN_XGet(2, XX(5), XX(6), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
		PRN_XGet(2, XX(5), XX(6), PR_WK_Renamed)
		'2021.08.19 UPGRADE E
		PR_WK_Renamed.Y = pryy + yMargn
		Call PRN_DATA(PR_WK_Renamed)
		' ����x���z(���v)
		'2021.08.05 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.DT = VB6.Format(G_SIHA_KON, "#,###,###,##0")
		PR_WK_Renamed.DT = G_SIHA_KON.ToString("#,###,###,##0")
		'2021.08.05 UPGRADE E
		PR_WK_Renamed.FS = F_SIZE
		'2021.08.19 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.X = PRN_XGet(2, XX(6), XX(7), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
		PRN_XGet(2, XX(6), XX(7), PR_WK_Renamed)
		'2021.08.19 UPGRADE E
		PR_WK_Renamed.Y = pryy + yMargn
		Call PRN_DATA(PR_WK_Renamed)
		' �x���c�z(���v)
		'2021.08.05 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.DT = VB6.Format(G_SIHA_ZAN, "#,###,###,##0")
		PR_WK_Renamed.DT = G_SIHA_ZAN.ToString("#,###,###,##0")
		'2021.08.05 UPGRADE E
		PR_WK_Renamed.FS = F_SIZE
		'2021.08.19 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.X = PRN_XGet(2, XX(7), XX(8), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
		PRN_XGet(2, XX(7), XX(8), PR_WK_Renamed)
		'2021.08.19 UPGRADE E
		PR_WK_Renamed.Y = pryy + yMargn
		Call PRN_DATA(PR_WK_Renamed)

	End Sub

	'-------------------------------------------------------------------------------
	'   ����    :   �_����z���f�[�^�������
	'   �֐�    :   Sub PrData2D150()
	'   ����    :   pryy    ����x�ʒu
	'   �@�@        DT      GAI_KIHON_DATA_DBT
	'   �ߒl    :   �Ȃ�
	'-------------------------------------------------------------------------------
	Private Sub PrData2D150(ByRef pryy As Single, ByRef DT As GAI_KIHON_DATA_DBT)

		Dim PR_WK_Renamed As PR_WK
		Dim yMargn As Single
		'Dim PR_Text As String�@�@�@�@�@'2021.08.05 UPGRADE DEL  AIT)dannnl

		'----- ����
		Call PRN_LINE(XX(2) + P_XX * (30), pryy, XX(UBound(XX)), pryy, 10, "")

		'----- �]��
		yMargn = P_YY * 0.25

		'----- 1�s��
		' �_����z
		PR_WK_Renamed.DT = "�_����z"
		PR_WK_Renamed.FS = F_SIZE
		'2021.08.19 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.X = PRN_XGet(2, XX(2) + P_XX * (30), XX(3), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
		PRN_XGet(2, XX(2) + P_XX * (30), XX(3), PR_WK_Renamed)
		'2021.08.19 UPGRADE E
		PR_WK_Renamed.Y = pryy + yMargn
		Call PRN_DATA(PR_WK_Renamed)

		'2021.08.05 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.DT = VB6.Format(DT.KEIYAKU_GAKU, "#,###,###,##0")
		PR_WK_Renamed.DT = DT.KEIYAKU_GAKU.ToString("#,###,###,##0")
		'2021.08.05 UPGRADE E
		PR_WK_Renamed.FS = F_SIZE
		'2021.08.19 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.X = PRN_XGet(2, XX(2) + P_XX * (30), XX(3), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
		PRN_XGet(2, XX(2) + P_XX * (30), XX(3), PR_WK_Renamed)
		'2021.08.19 UPGRADE E
		PR_WK_Renamed.Y = pryy + (P_YY * 1.5) + yMargn
		Call PRN_DATA(PR_WK_Renamed)
		' ���o����
		PR_WK_Renamed.DT = "���o����"
		PR_WK_Renamed.FS = F_SIZE
		'2021.08.19 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.X = PRN_XGet(2, XX(3), XX(4), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
		PRN_XGet(2, XX(3), XX(4), PR_WK_Renamed)
		'2021.08.19 UPGRADE E
		PR_WK_Renamed.Y = pryy + yMargn
		Call PRN_DATA(PR_WK_Renamed)

		'2021.08.05 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.DT = VB6.Format(DT.SOU_DEKI_GAKU, "#,###,###,##0")
		PR_WK_Renamed.DT = DT.SOU_DEKI_GAKU.ToString("#,###,###,##0")
		'2021.08.05 UPGRADE E
		PR_WK_Renamed.FS = F_SIZE
		'2021.08.19 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.X = PRN_XGet(2, XX(3), XX(4), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
		PRN_XGet(2, XX(3), XX(4), PR_WK_Renamed)
		'2021.08.19 UPGRADE E
		PR_WK_Renamed.Y = pryy + (P_YY * 1.5) + yMargn
		Call PRN_DATA(PR_WK_Renamed)
		' �O�񖘈�����
		PR_WK_Renamed.DT = "�O�񖘈�����"
		PR_WK_Renamed.FS = F_SIZE
		'2021.08.19 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.X = PRN_XGet(2, XX(4), XX(5), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
		PRN_XGet(2, XX(4), XX(5), PR_WK_Renamed)
		'2021.08.19 UPGRADE E
		PR_WK_Renamed.Y = pryy + yMargn
		Call PRN_DATA(PR_WK_Renamed)

		'2021.08.05 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.DT = VB6.Format(DT.ZEN_HIKI_GAKU, "#,###,###,##0")
		PR_WK_Renamed.DT = DT.ZEN_HIKI_GAKU.ToString("#,###,###,##0")
		'2021.08.05 UPGRADE E
		PR_WK_Renamed.FS = F_SIZE
		'2021.08.19 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.X = PRN_XGet(2, XX(4), XX(5), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
		PRN_XGet(2, XX(4), XX(5), PR_WK_Renamed)
		'2021.08.19 UPGRADE E
		PR_WK_Renamed.Y = pryy + (P_YY * 1.5) + yMargn
		Call PRN_DATA(PR_WK_Renamed)
		' ���������
		PR_WK_Renamed.DT = "���������"
		PR_WK_Renamed.FS = F_SIZE
		'2021.08.19 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.X = PRN_XGet(2, XX(5), XX(6), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
		PRN_XGet(2, XX(5), XX(6), PR_WK_Renamed)
		'2021.08.19 UPGRADE E
		PR_WK_Renamed.Y = pryy + yMargn
		Call PRN_DATA(PR_WK_Renamed)

		'2021.08.05 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.DT = VB6.Format(DT.KON_HIKI_GAKU, "#,###,###,##0")
		PR_WK_Renamed.DT = DT.KON_HIKI_GAKU.ToString("#,###,###,##0")
		'2021.08.05 UPGRADE E
		PR_WK_Renamed.FS = F_SIZE
		'2021.08.19 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.X = PRN_XGet(2, XX(5), XX(6), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
		PRN_XGet(2, XX(5), XX(6), PR_WK_Renamed)
		'2021.08.19 UPGRADE E
		PR_WK_Renamed.Y = pryy + (P_YY * 1.5) + yMargn
		Call PRN_DATA(PR_WK_Renamed)
		' �����v
		PR_WK_Renamed.DT = "�����v"
		PR_WK_Renamed.FS = F_SIZE
		'2021.08.19 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.X = PRN_XGet(2, XX(6), XX(7), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
		PRN_XGet(2, XX(6), XX(7), PR_WK_Renamed)
		'2021.08.19 UPGRADE E
		PR_WK_Renamed.Y = pryy + yMargn
		Call PRN_DATA(PR_WK_Renamed)

		'2021.08.05 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.DT = VB6.Format(DT.SASI_GAKU, "#,###,###,##0")
		PR_WK_Renamed.DT = DT.SASI_GAKU.ToString("#,###,###,##0")
		'2021.08.05 UPGRADE E
		PR_WK_Renamed.FS = F_SIZE
		'2021.08.19 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.X = PRN_XGet(2, XX(6), XX(7), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
		PRN_XGet(2, XX(6), XX(7), PR_WK_Renamed)
		'2021.08.19 UPGRADE E
		PR_WK_Renamed.Y = pryy + (P_YY * 1.5) + yMargn
		Call PRN_DATA(PR_WK_Renamed)
		' ������
		PR_WK_Renamed.DT = "�����v" & Space(1) & DT.RITU & "%"
		PR_WK_Renamed.FS = F_SIZE
		'2021.08.19 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.X = PRN_XGet(2, XX(7), XX(8), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
		PRN_XGet(2, XX(7), XX(8), PR_WK_Renamed)
		'2021.08.19 UPGRADE E
		PR_WK_Renamed.Y = pryy + yMargn
		Call PRN_DATA(PR_WK_Renamed)

		'2021.08.05 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.DT = VB6.Format(DT.SASI_RITU, "#,###,###,##0")
		PR_WK_Renamed.DT = DT.SASI_RITU.ToString("#,###,###,##0")
		'2021.08.05 UPGRADE E
		PR_WK_Renamed.FS = F_SIZE
		'2021.08.19 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.X = PRN_XGet(2, XX(7), XX(8), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
		PRN_XGet(2, XX(7), XX(8), PR_WK_Renamed)
		'2021.08.19 UPGRADE E
		PR_WK_Renamed.Y = pryy + (P_YY * 1.5) + yMargn
		Call PRN_DATA(PR_WK_Renamed)

		'----- ����
		Call PRN_LINE(XX(2) + P_XX * (30), pryy + ((P_YY * 1.5) * 2), XX(UBound(XX)), pryy + ((P_YY * 1.5) * 2), 10, "")

		'----- 2�s��
		'2013/12/09 �ǉ� -------------------------------------------------------------------����������
		' ����Ŋz
		'2021.08.03 UPGRADE S  AIT)Tool Convert
		'PR_WK_Renamed.DT = "����Ŋz(" & Right("  " & VB6.Format(DT.ZEIRITU, "#0"), 2) & "%)"
		PR_WK_Renamed.DT = "����Ŋz(" & Right("  " & CDec(DT.ZEIRITU).ToString("#0"), 2) & "%)"
		'2021.08.03 UPGRADE E
		PR_WK_Renamed.FS = F_SIZE
		'2021.08.19 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.X = PRN_XGet(2, XX(2) + P_XX * (5), XX(3) - P_XX * (25), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
		PRN_XGet(2, XX(2) + P_XX * (5), XX(3) - P_XX * (25), PR_WK_Renamed)
		'2021.08.19 UPGRADE E
		PR_WK_Renamed.Y = pryy + ((P_YY * 1.5) * 2) + yMargn
		Call PRN_DATA(PR_WK_Renamed)

		'2021.08.05 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.DT = VB6.Format(DT.ZEI_GAKU, "#,###,###,##0")
		PR_WK_Renamed.DT = DT.ZEI_GAKU.ToString("#,###,###,##0")
		'2021.08.05 UPGRADE E
		PR_WK_Renamed.FS = F_SIZE
		'2021.08.19 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.X = PRN_XGet(2, XX(2) + P_XX * (5), XX(3) - P_XX * (25), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
		PRN_XGet(2, XX(2) + P_XX * (5), XX(3) - P_XX * (25), PR_WK_Renamed)
		'2021.08.19 UPGRADE E
		PR_WK_Renamed.Y = pryy + ((P_YY * 1.5) * 3) + yMargn
		Call PRN_DATA(PR_WK_Renamed)
		'-----------------------------------------------------------------------------------����������

		' �O�񖘎x���z
		PR_WK_Renamed.DT = "�O�񖘎x���z"
		PR_WK_Renamed.FS = F_SIZE
		'2021.08.19 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.X = PRN_XGet(2, XX(2) + P_XX * (30), XX(3), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
		PRN_XGet(2, XX(2) + P_XX * (30), XX(3), PR_WK_Renamed)
		'2021.08.19 UPGRADE E
		PR_WK_Renamed.Y = pryy + ((P_YY * 1.5) * 2) + yMargn
		Call PRN_DATA(PR_WK_Renamed)

		'2021.08.05 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.DT = VB6.Format(DT.ZEN_SI_GAKU, "#,###,###,##0")
		PR_WK_Renamed.DT = DT.ZEN_SI_GAKU.ToString("#,###,###,##0")
		'2021.08.05 UPGRADE E
		PR_WK_Renamed.FS = F_SIZE
		'2021.08.19 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.X = PRN_XGet(2, XX(2) + P_XX * (30), XX(3), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
		PRN_XGet(2, XX(2) + P_XX * (30), XX(3), PR_WK_Renamed)
		'2021.08.19 UPGRADE E
		PR_WK_Renamed.Y = pryy + ((P_YY * 1.5) * 3) + yMargn
		Call PRN_DATA(PR_WK_Renamed)
		' ����x���ϊz
		PR_WK_Renamed.DT = "�x�������z"
		PR_WK_Renamed.FS = F_SIZE
		'2021.08.19 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.X = PRN_XGet(2, XX(3), XX(4), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
		PRN_XGet(2, XX(3), XX(4), PR_WK_Renamed)
		'2021.08.19 UPGRADE E
		PR_WK_Renamed.Y = pryy + ((P_YY * 1.5) * 2) + yMargn
		Call PRN_DATA(PR_WK_Renamed)

		'2021.08.05 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.DT = VB6.Format(DT.KON_SUMI_GAKU, "#,###,###,##0")
		PR_WK_Renamed.DT = DT.KON_SUMI_GAKU.ToString("#,###,###,##0")
		'2021.08.05 UPGRADE E
		PR_WK_Renamed.FS = F_SIZE
		'2021.08.19 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.X = PRN_XGet(2, XX(3), XX(4), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
		PRN_XGet(2, XX(3), XX(4), PR_WK_Renamed)
		'2021.08.19 UPGRADE E
		PR_WK_Renamed.Y = pryy + ((P_YY * 1.5) * 3) + yMargn
		Call PRN_DATA(PR_WK_Renamed)
		' �x���\�z
		PR_WK_Renamed.DT = "�x���\�z"
		PR_WK_Renamed.FS = F_SIZE
		'2021.08.19 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.X = PRN_XGet(2, XX(4), XX(5), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
		PRN_XGet(2, XX(4), XX(5), PR_WK_Renamed)
		'2021.08.19 UPGRADE E
		PR_WK_Renamed.Y = pryy + ((P_YY * 1.5) * 2) + yMargn
		Call PRN_DATA(PR_WK_Renamed)

		'2021.08.05 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.DT = VB6.Format(DT.KANOU_GAKU, "#,###,###,##0")
		PR_WK_Renamed.DT = DT.KANOU_GAKU.ToString("#,###,###,##0")
		'2021.08.05 UPGRADE E
		PR_WK_Renamed.FS = F_SIZE
		'2021.08.19 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.X = PRN_XGet(2, XX(4), XX(5), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
		PRN_XGet(2, XX(4), XX(5), PR_WK_Renamed)
		'2021.08.19 UPGRADE E
		PR_WK_Renamed.Y = pryy + ((P_YY * 1.5) * 3) + yMargn
		Call PRN_DATA(PR_WK_Renamed)
		' ���񐿋��z
		PR_WK_Renamed.DT = "���񐿋��z"
		PR_WK_Renamed.FS = F_SIZE
		'2021.08.19 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.X = PRN_XGet(2, XX(5), XX(6), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
		PRN_XGet(2, XX(5), XX(6), PR_WK_Renamed)
		'2021.08.19 UPGRADE E
		PR_WK_Renamed.Y = pryy + ((P_YY * 1.5) * 2) + yMargn
		Call PRN_DATA(PR_WK_Renamed)

		'2021.08.05 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.DT = VB6.Format(DT.KON_SEI_GAKU, "#,###,###,##0")
		PR_WK_Renamed.DT = DT.KON_SEI_GAKU.ToString("#,###,###,##0")
		'2021.08.05 UPGRADE E
		PR_WK_Renamed.FS = F_SIZE
		'2021.08.19 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.X = PRN_XGet(2, XX(5), XX(6), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
		PRN_XGet(2, XX(5), XX(6), PR_WK_Renamed)
		PR_WK_Renamed.Y = pryy + ((P_YY * 1.5) * 3) + yMargn
		Call PRN_DATA(PR_WK_Renamed)
		' ����x���z
		PR_WK_Renamed.DT = "����x���z"
		PR_WK_Renamed.FS = F_SIZE
		'2021.08.19 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.X = PRN_XGet(2, XX(6), XX(7), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
		PRN_XGet(2, XX(6), XX(7), PR_WK_Renamed)
		'2021.08.19 UPGRADE E
		PR_WK_Renamed.Y = pryy + ((P_YY * 1.5) * 2) + yMargn
		Call PRN_DATA(PR_WK_Renamed)

		'2021.08.05 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.DT = VB6.Format(DT.KON_SI_GAKU, "#,###,###,##0")
		PR_WK_Renamed.DT = DT.KON_SI_GAKU.ToString("#,###,###,##0")
		'2021.08.05 UPGRADE E
		PR_WK_Renamed.FS = F_SIZE
		'2021.08.19 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.X = PRN_XGet(2, XX(6), XX(7), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
		PRN_XGet(2, XX(6), XX(7), PR_WK_Renamed)
		'2021.08.19 UPGRADE E
		PR_WK_Renamed.Y = pryy + ((P_YY * 1.5) * 3) + yMargn
		Call PRN_DATA(PR_WK_Renamed)
		' �x���c�z
		PR_WK_Renamed.DT = "�x���c�z"
		PR_WK_Renamed.FS = F_SIZE
		'2021.08.19 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.X = PRN_XGet(2, XX(7), XX(8), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
		PRN_XGet(2, XX(7), XX(8), PR_WK_Renamed)
		'2021.08.19 UPGRADE E
		PR_WK_Renamed.Y = pryy + ((P_YY * 1.5) * 2) + yMargn
		Call PRN_DATA(PR_WK_Renamed)

		'2021.08.05 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.DT = VB6.Format(DT.SIHARAI_ZAN, "#,###,###,##0")
		PR_WK_Renamed.DT = DT.SIHARAI_ZAN.ToString("#,###,###,##0")
		'2021.08.05 UPGRADE E
		PR_WK_Renamed.FS = F_SIZE
		'2021.08.19 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.X = PRN_XGet(2, XX(7), XX(8), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
		PRN_XGet(2, XX(7), XX(8), PR_WK_Renamed)
		'2021.08.19 UPGRADE E
		PR_WK_Renamed.Y = pryy + ((P_YY * 1.5) * 3) + yMargn
		Call PRN_DATA(PR_WK_Renamed)

	End Sub

	'-------------------------------------------------------------------------------
	'   ����    :   �O��(����)�f�[�^�������
	'   �֐�    :   Sub PrData3D150()
	'   ����    :   pryy    ����x�ʒu
	'   �@�@        DT()    GAI_KIHON_DATA_DBT
	'   �ߒl    :   �Ȃ�
	'-------------------------------------------------------------------------------
	Private Function PrData3D150(ByRef pryy As Single, ByRef DT As GAI_KIHON_DATA_DBT) As Object

		Dim SQL As String
		'2021.08.05 UPGRADE S  AIT)dannnl
		'Dim Rs As ADODB.Recordset
		Dim Rs As New DataTable
		'2021.08.05 UPGRADE E
		Dim OpenFlg As Short
		Dim DT3() As IPPAN_DATA_DBT ' �O��(����)�f�[�^�p
		Dim Cnt3 As Integer
		Dim lp3 As Integer
		Dim PR_WK_Renamed As PR_WK
		Dim yMargn As Single
		Dim PR_Text As String

		' �O��(����)�f�[�^�̓Ǎ���
		' SQL/SELECT���g��
		SQL = "SELECT"
		SQL = SQL & " GYOUSYA_CD,"
		SQL = SQL & " BIKOU,"
		SQL = SQL & " H_SUURYOU,"
		SQL = SQL & " H_ZAIKO,"
		SQL = SQL & " H_TANKA,"
		SQL = SQL & " H_KINGAKU"
		SQL = SQL & " FROM " & IPPAN_DATA_TBLNAME
		SQL = SQL & " WHERE KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"
		SQL = SQL & " AND EDA_NO = '" & KeyKouji.EDA_NO & "'"
		SQL = SQL & " AND SIME_YM = '" & CtlKouji.SYORI_YM & "'"
		SQL = SQL & " AND MEISAI_KB = '2'"
		SQL = SQL & " AND CHUUMON_NO = '" & Trim(DT.CHUUMON_NO) & "'"
		SQL = SQL & " AND S_FLG_GENKA = '1'"

		' SQL�����s
		'2021.08.05 UPGRADE S  AIT)dannnl
		'Rs = SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText)
		Rs = RsOpen(SQL)
		'2021.08.05 UPGRADE E
		OpenFlg = 1

		Cnt3 = 0
		'2021.08.05 UPGRADE S  AIT)dannnl
		'Do Until Rs.EOF
		For Each Row As DataRow In Rs.Rows
			'2021.08.05 UPGRADE E
			ReDim Preserve DT3(Cnt3)
			'2021.08.05 UPGRADE S  AIT)dannnl
			'Call DATSET_IPPAN_DATA(Rs, DT3(Cnt3))
			Call DATSET_IPPAN_DATA(Row, DT3(Cnt3))
			'2021.08.05 UPGRADE E
			Cnt3 = Cnt3 + 1
			'2021.08.05 UPGRADE S  AIT)dannnl
			'	Rs.MoveNext()
			'Loop

			'Rs.Close()
		Next

		Rs.Dispose()
		'2021.08.05 UPGRADE E
		Rs = Nothing

		'----- �]��
		yMargn = P_YY * 0.25

		'----- ����
		Call PRN_LINE(XX(0), pryy, XX(UBound(XX)), pryy, 10, "")

		' �Ǝк���
		PR_WK_Renamed.DT = "�Ǝк���"
		PR_WK_Renamed.FS = F_SIZE
		'2021.08.19 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.X = PRN_XGet(0, XX(1), XX(2), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
		PRN_XGet(0, XX(1), XX(2) + P_XX, PR_WK_Renamed)
		'2021.08.19 UPGRADE E
		PR_WK_Renamed.Y = pryy + yMargn
		Call PRN_DATA(PR_WK_Renamed)
		' �ƎЖ���
		PR_WK_Renamed.DT = "�ƎЖ���"
		PR_WK_Renamed.FS = F_SIZE
		'2021.08.19 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.X = PRN_XGet(0, XX(2), XX(2) + P_XX * (30), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
		PRN_XGet(0, XX(2), XX(2) + P_XX * (30), PR_WK_Renamed)
		'2021.08.19 UPGRADE E
		PR_WK_Renamed.Y = pryy + yMargn
		Call PRN_DATA(PR_WK_Renamed)
		' �i���E�K�i
		PR_WK_Renamed.DT = "�i���E�K�i"
		PR_WK_Renamed.FS = F_SIZE
		'2021.08.19 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.X = PRN_XGet(0, XX(2) + P_XX * (30), XX(4), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
		PRN_XGet(0, XX(2) + P_XX * (30), XX(4), PR_WK_Renamed)
		'2021.08.19 UPGRADE E
		PR_WK_Renamed.Y = pryy + yMargn
		Call PRN_DATA(PR_WK_Renamed)
		' ����
		PR_WK_Renamed.DT = "����"
		PR_WK_Renamed.FS = F_SIZE
		'2021.08.19 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.X = PRN_XGet(2, XX(4), XX(5), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
		PRN_XGet(2, XX(4), XX(5), PR_WK_Renamed)
		'2021.08.19 UPGRADE E
		PR_WK_Renamed.Y = pryy + yMargn
		Call PRN_DATA(PR_WK_Renamed)
		' �݌�
		PR_WK_Renamed.DT = "�݌�"
		PR_WK_Renamed.FS = F_SIZE
		'2021.08.19 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.X = PRN_XGet(2, XX(5), XX(6), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
		PRN_XGet(2, XX(5), XX(6), PR_WK_Renamed)
		'2021.08.19 UPGRADE E
		PR_WK_Renamed.Y = pryy + yMargn
		Call PRN_DATA(PR_WK_Renamed)
		' �P��
		PR_WK_Renamed.DT = "�P��"
		PR_WK_Renamed.FS = F_SIZE
		'2021.08.19 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.X = PRN_XGet(2, XX(6), XX(7), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
		PRN_XGet(2, XX(6), XX(7), PR_WK_Renamed)
		'2021.08.19 UPGRADE E
		PR_WK_Renamed.Y = pryy + yMargn
		Call PRN_DATA(PR_WK_Renamed)
		' ���z
		PR_WK_Renamed.DT = "���z"
		PR_WK_Renamed.FS = F_SIZE
		'2021.08.19 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.X = PRN_XGet(2, XX(7), XX(8), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
		PRN_XGet(2, XX(7), XX(8), PR_WK_Renamed)
		'2021.08.19 UPGRADE E
		PR_WK_Renamed.Y = pryy + yMargn
		Call PRN_DATA(PR_WK_Renamed)

		'----- ���s
		pryy = pryy + (P_YY * 1.5)
		'----- ����
		Call PRN_LINE(XX(0), pryy, XX(UBound(XX)), pryy, 10, "")

		If Cnt3 <= 0 Then
			'----- ���s
			pryy = pryy + (P_YY * 1.5) ' 1�s��
			Exit Function
		End If

		For lp3 = 0 To Cnt3 - 1
			'���y�[�W�`�F�b�N(�����y�[�W�ɂȂ�ꍇ)
			If NewPage_CHK(pryy, P_YY * 5) = False Then
				'----- ���y�[�W
				Call PRN_NewPage()
				'----- �y�[�W���̍X�V
				P_Cnt = P_Cnt + 1
				'----- �󎚈ʒu�̃��Z�b�g
				pryy = YY(0)
				' ���o����(�y�[�W���o��)
				Call PrItemPD150(pryy)
				'----- ���s
				pryy = pryy + ((P_YY * 1.5) * 5)
				'----- ����(�d�؂��)
				Call PRN_LINE(XX(0), pryy, XX(UBound(XX)), pryy, 20, "")
				' ���o��(���ڌ��o��)
				Call PrItemD150(pryy, DT)
			End If
			' �Ǝк���
			PR_WK_Renamed.DT = DT3(lp3).GYOUSYA_CD
			PR_WK_Renamed.FS = F_SIZE
			'2021.08.19 UPGRADE S  AIT)dannnl
			'PR_WK_Renamed.X = PRN_XGet(1, XX(1), XX(2), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
			PRN_XGet(1, XX(1) - P_XX, XX(2), PR_WK_Renamed)
			'2021.08.19 UPGRADE E
			PR_WK_Renamed.Y = pryy + yMargn
			Call PRN_DATA(PR_WK_Renamed)
			' �ƎЖ���
			'2014/01/15 �C�� ----------------------------------------------------����������
			'PR_WK.DT = GetNameGyousya(DT3(lp3).GYOUSYA_CD)
			PR_Text = GetNameGyousya(DT3(lp3).GYOUSYA_CD)
			'2021.08.03 UPGRADE S  AIT)Tool Convert
			'If LenB(PR_Text) > 30 Then
			If Util.LenB(PR_Text) > 30 Then
				'PR_Text = LeftB(PR_Text, 30)
				PR_Text = Util.LeftB(PR_Text, 30)
				'2021.08.03 UPGRADE E
				If Right(PR_Text, 1) <> Mid(PR_Text, Len(PR_Text), 1) Then
					PR_Text = Left(PR_Text, Len(PR_Text) - 1)
				End If
			End If
			PR_WK_Renamed.DT = PR_Text
			'--------------------------------------------------------------------����������
			PR_WK_Renamed.FS = F_SIZE
			'2021.08.19 UPGRADE S  AIT)dannnl
			'PR_WK_Renamed.X = PRN_XGet(0, XX(2), XX(2) + P_XX * (30), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
			PRN_XGet(0, XX(2), XX(2) + P_XX * (30), PR_WK_Renamed)
			'2021.08.19 UPGRADE E
			PR_WK_Renamed.Y = pryy + yMargn
			Call PRN_DATA(PR_WK_Renamed)
			' �i���E�K�i
			PR_WK_Renamed.DT = DT3(lp3).BIKOU
			PR_WK_Renamed.FS = F_SIZE
			'2021.08.19 UPGRADE S  AIT)dannnl
			'PR_WK_Renamed.X = PRN_XGet(0, XX(2) + P_XX * (30), XX(4), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
			PRN_XGet(0, XX(2) + P_XX * (30), XX(5), PR_WK_Renamed)
			'2021.08.19 UPGRADE E
			PR_WK_Renamed.Y = pryy + yMargn
			Call PRN_DATA(PR_WK_Renamed)
			' ����
			'2021.08.03 UPGRADE S  AIT)Tool Convert
			'PR_Text = VB6.Format(DT3(lp3).H_SUURYOU, "##,###.##")
			PR_Text = DT3(lp3).H_SUURYOU.ToString("##,###.##")
			'2021.08.03 UPGRADE E
			If Right(PR_Text, 1) = "." Then PR_Text = Left(PR_Text, Len(PR_Text) - 1)
			If Left(PR_Text, 1) = "." Then PR_Text = "0" & PR_Text
			PR_WK_Renamed.DT = PR_Text
			PR_WK_Renamed.FS = F_SIZE
			'2021.08.19 UPGRADE S  AIT)dannnl
			'PR_WK_Renamed.X = PRN_XGet(2, XX(4), XX(5), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
			PRN_XGet(2, XX(4), XX(5), PR_WK_Renamed)
			'2021.08.19 UPGRADE E
			PR_WK_Renamed.Y = pryy + yMargn
			Call PRN_DATA(PR_WK_Renamed)
			' �݌�
			'2021.08.03 UPGRADE S  AIT)Tool Convert
			'PR_Text = VB6.Format(DT3(lp3).H_ZAIKO, "##,###.##")
			PR_Text = DT3(lp3).H_ZAIKO.ToString("##,###.##")
			'2021.08.03 UPGRADE E
			If Right(PR_Text, 1) = "." Then PR_Text = Left(PR_Text, Len(PR_Text) - 1)
			If Left(PR_Text, 1) = "." Then PR_Text = "0" & PR_Text
			PR_WK_Renamed.DT = PR_Text
			PR_WK_Renamed.FS = F_SIZE
			'2021.08.19 UPGRADE S  AIT)dannnl
			'PR_WK_Renamed.X = PRN_XGet(2, XX(5), XX(6), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
			PRN_XGet(2, XX(5), XX(6), PR_WK_Renamed)
			'2021.08.19 UPGRADE E
			PR_WK_Renamed.Y = pryy + yMargn
			Call PRN_DATA(PR_WK_Renamed)
			' �P��
			'2021.08.05 UPGRADE S  AIT)dannnl
			'PR_WK_Renamed.DT = VB6.Format(DT3(lp3).H_TANKA, "#,###,###,##0")
			PR_WK_Renamed.DT = DT3(lp3).H_TANKA.ToString("#,###,###,##0")
			'2021.08.05 UPGRADE E
			PR_WK_Renamed.FS = F_SIZE
			'2021.08.19 UPGRADE S  AIT)dannnl
			'PR_WK_Renamed.X = PRN_XGet(2, XX(6), XX(7), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
			PRN_XGet(2, XX(6), XX(7), PR_WK_Renamed)
			'2021.08.19 UPGRADE E
			PR_WK_Renamed.Y = pryy + yMargn
			Call PRN_DATA(PR_WK_Renamed)
			' ���z
			'2021.08.05 UPGRADE S  AIT)dannnl
			'PR_WK_Renamed.DT = VB6.Format(DT3(lp3).H_KINGAKU, "#,###,###,##0")
			PR_WK_Renamed.DT = DT3(lp3).H_KINGAKU.ToString("#,###,###,##0")
			'2021.08.05 UPGRADE E
			PR_WK_Renamed.FS = F_SIZE
			'2021.08.19 UPGRADE S  AIT)dannnl
			'PR_WK_Renamed.X = PRN_XGet(2, XX(7), XX(8), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
			PRN_XGet(2, XX(7), XX(8), PR_WK_Renamed)
			'2021.08.19 UPGRADE E
			PR_WK_Renamed.Y = pryy + yMargn
			Call PRN_DATA(PR_WK_Renamed)

			'----- ���s
			pryy = pryy + (P_YY * 1.5)
			'----- ����
			'2021.08.18 UPGRADE S  AIT)dannnl
			'Call PRN_LINE(XX(0), pryy, XX(UBound(XX)), pryy, 1, "", VSDraw7Lib.PenStyleSettings.psDot)
			Call PRN_LINE(XX(0), pryy, XX(UBound(XX)), pryy, 1, "", DashStyle.Dot)
			'2021.08.18 UPGRADE E

		Next lp3

	End Function

	'-------------------------------------------------------------------------------
	'   ����    :   �C�ӘJ�ЁE����������f�[�^�������
	'   �֐�    :   Sub PrData4D150()
	'   ����    :   pryy    ����x�ʒu
	'   �@�@        DT()    GAI_KIHON_DATA_DBT
	'   �ߒl    :   �Ȃ�
	'-------------------------------------------------------------------------------
	Private Function PrData4D150(ByRef pryy As Single, ByRef DT As GAI_KIHON_DATA_DBT) As Object

		Dim PR_WK_Renamed As PR_WK
		Dim yMargn As Single

		'----- �]��
		yMargn = P_YY * 0.25

		'----- ����
		Call PRN_LINE(XX(0), pryy, XX(UBound(XX)), pryy, 10, "")

		'----- 1�s��
		' �C�ӘJ�З݌v
		'PR_WK.DT = "�C�ӘJ�З݌v"
		PR_WK_Renamed.DT = "���S������݌v"
		PR_WK_Renamed.FS = F_SIZE
		'2021.08.19 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.X = PRN_XGet(2, XX(2), XX(3), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
		PRN_XGet(2, XX(2), XX(3), PR_WK_Renamed)
		'2021.08.19 UPGRADE E
		PR_WK_Renamed.Y = pryy + yMargn
		Call PRN_DATA(PR_WK_Renamed)

		'2021.08.05 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.DT = VB6.Format(DT.NIN_ROU_KEI + DT.NIN_ROU_GAKU, "#,###,###,##0")
		PR_WK_Renamed.DT = (DT.NIN_ROU_KEI + DT.NIN_ROU_GAKU).ToString("#,###,###,##0")
		'2021.08.05 UPGRADE E
		PR_WK_Renamed.FS = F_SIZE
		'2021.08.19 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.X = PRN_XGet(2, XX(3), XX(4), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
		PRN_XGet(2, XX(3), XX(4), PR_WK_Renamed)
		'2021.08.19 UPGRADE E
		PR_WK_Renamed.Y = pryy + yMargn
		Call PRN_DATA(PR_WK_Renamed)
		' �C�ӘJ��
		'PR_WK.DT = "�C�ӘJ��"
		PR_WK_Renamed.DT = "���S������"
		PR_WK_Renamed.FS = F_SIZE
		'2021.08.19 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.X = PRN_XGet(2, XX(4), XX(5), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
		PRN_XGet(2, XX(4), XX(5), PR_WK_Renamed)
		'2021.08.19 UPGRADE E
		PR_WK_Renamed.Y = pryy + yMargn
		Call PRN_DATA(PR_WK_Renamed)

		'2021.08.05 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.DT = VB6.Format(DT.NIN_ROU_GAKU, "#,###,###,##0")
		PR_WK_Renamed.DT = DT.NIN_ROU_GAKU.ToString("#,###,###,##0")
		'2021.08.05 UPGRADE E
		PR_WK_Renamed.FS = F_SIZE
		'2021.08.19 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.X = PRN_XGet(2, XX(5), XX(6), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
		PRN_XGet(2, XX(5), XX(6), PR_WK_Renamed)
		'2021.08.19 UPGRADE E
		PR_WK_Renamed.Y = pryy + yMargn
		Call PRN_DATA(PR_WK_Renamed)
		' ���������
		PR_WK_Renamed.DT = "���������"
		PR_WK_Renamed.FS = F_SIZE
		'2021.08.19 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.X = PRN_XGet(2, XX(6), XX(7), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
		PRN_XGet(2, XX(6), XX(7), PR_WK_Renamed)
		'2021.08.19 UPGRADE E
		PR_WK_Renamed.Y = pryy + yMargn
		Call PRN_DATA(PR_WK_Renamed)

		'2021.08.05 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.DT = VB6.Format(DT.KON_HIKI_GAKU, "#,###,###,##0")
		PR_WK_Renamed.DT = DT.KON_HIKI_GAKU.ToString("#,###,###,##0")
		'2021.08.05 UPGRADE E
		PR_WK_Renamed.FS = F_SIZE
		'2021.08.19 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.X = PRN_XGet(2, XX(7), XX(8), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
		PRN_XGet(2, XX(7), XX(8), PR_WK_Renamed)
		'2021.08.19 UPGRADE E
		PR_WK_Renamed.Y = pryy + yMargn
		Call PRN_DATA(PR_WK_Renamed)

		'----- 2�s��
		' ��s�����c�z
		PR_WK_Renamed.DT = "��s�����c�z"
		PR_WK_Renamed.FS = F_SIZE
		'2021.08.19 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.X = PRN_XGet(2, XX(2), XX(3), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
		PRN_XGet(2, XX(2), XX(3), PR_WK_Renamed)
		'2021.08.19 UPGRADE E
		PR_WK_Renamed.Y = pryy + yMargn + (P_YY * 1.5)
		Call PRN_DATA(PR_WK_Renamed)

		'2021.08.05 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.DT = VB6.Format(DT.SEN_HIKI_ZAN + DT.SEN_HIKI_GAKU, "#,###,###,##0")
		PR_WK_Renamed.DT = (DT.SEN_HIKI_ZAN + DT.SEN_HIKI_GAKU).ToString("#,###,###,##0")
		'2021.08.05 UPGRADE E
		PR_WK_Renamed.FS = F_SIZE
		'2021.08.19 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.X = PRN_XGet(2, XX(3), XX(4), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
		PRN_XGet(2, XX(3), XX(4), PR_WK_Renamed)
		'2021.08.19 UPGRADE E
		PR_WK_Renamed.Y = pryy + yMargn + (P_YY * 1.5)
		Call PRN_DATA(PR_WK_Renamed)
		' ��s������
		PR_WK_Renamed.DT = "��s������"
		PR_WK_Renamed.FS = F_SIZE
		'2021.08.19 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.X = PRN_XGet(2, XX(4), XX(5), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
		PRN_XGet(2, XX(4), XX(5), PR_WK_Renamed)
		'2021.08.19 UPGRADE E
		PR_WK_Renamed.Y = pryy + yMargn + (P_YY * 1.5)
		Call PRN_DATA(PR_WK_Renamed)

		'2021.08.05 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.DT = VB6.Format(DT.SEN_HIKI_GAKU, "#,###,###,##0")
		PR_WK_Renamed.DT = DT.SEN_HIKI_GAKU.ToString("#,###,###,##0")
		'2021.08.05 UPGRADE E
		PR_WK_Renamed.FS = F_SIZE
		'2021.08.19 UPGRADE S  AIT)dannnl
		'PR_WK_Renamed.X = PRN_XGet(2, XX(5), XX(6), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
		PRN_XGet(2, XX(5), XX(6), PR_WK_Renamed)
		'2021.08.19 UPGRADE E
		PR_WK_Renamed.Y = pryy + yMargn + (P_YY * 1.5)
		Call PRN_DATA(PR_WK_Renamed)
		
	End Function
	
	'-------------------------------------------------------------------------------
	'   ����    :   ���y�[�W�`�F�b�N�p���R�[�h�������o����
	'   �֐�    :   Sub PrRcntD150()
	'   ����    :   DT()    GAI_KIHON_DATA_DBT(�O����{�}�X�^)
	'   �ߒl    :   R_Cnt   ���o���R�[�h����
	'-------------------------------------------------------------------------------
	Private Function PrRcntD150(ByRef DT As GAI_KIHON_DATA_DBT) As Integer
		
		Dim Jouken As String
		Dim Cnt As Integer
		
		' �߂�l�̏�����
		PrRcntD150 = 0
		
		' <�_��f�[�^����>
		' �����̐ݒ�
		Jouken = "KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"
		Jouken = Jouken & " AND EDA_NO = '" & KeyKouji.EDA_NO & "'"
		Jouken = Jouken & " AND CHUUMON_NO = '" & Trim(DT.CHUUMON_NO) & "'"
		Jouken = Jouken & " AND SIME_YM = '" & CtlKouji.SYORI_YM & "'"
		
		' ���R�[�h�����̎擾
		Cnt = CNTGET_GAI_KEIYAKU_DATA(Jouken)
		
		If Cnt < 0 Then
			Exit Function
		End If
		
		' �߂�l�̃Z�b�g
		PrRcntD150 = PrRcntD150 + Cnt
		
		'<�����f�[�^����>
		' �����̐ݒ�
		Jouken = "KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"
		Jouken = Jouken & " AND EDA_NO = '" & KeyKouji.EDA_NO & "'"
		Jouken = Jouken & " AND SIME_YM = '" & CtlKouji.SYORI_YM & "'"
		Jouken = Jouken & " AND MEISAI_KB = '2'"
		Jouken = Jouken & " AND CHUUMON_NO = '" & Trim(DT.CHUUMON_NO) & "'"
		Jouken = Jouken & " AND S_FLG_GENKA = '1'"
		
		' ���R�[�h�����̎擾
		Cnt = CNTGET_IPPAN_DATA(Jouken)
		
		If Cnt < 0 Then
			Exit Function
		End If
		
		' �߂�l�̃Z�b�g
		PrRcntD150 = PrRcntD150 + Cnt
		
	End Function
End Module
