Option Strict Off
Option Explicit On
Imports System.Drawing.Printing
Imports C1.Win.C1Document
Imports C1.Win.FlexReport

Module prnSYKD075
    '=============================================================
    ' ���[�U�[���@  �F  �R�z�H�Ɗ������
    ' �V�X�e�����@  �F  �H���Ǘ��V�X�e��
    ' ���W���[����  �F  ��ʕ����̓`�F�b�N���X�g�ꗗ���
    ' ���W���[��ID�@�F  prnSYKD075.bas
    ' �쐬���@ �@�@ �F  ���� 13 �N 07 �� 19 ��
    ' �X�V���@�@  �@�F  ���� 13 �N 08 �� 29 ��
    '=============================================================
    '

    Private P_Cnt As Short ' ����y�[�W�J�E���g
    Private XX() As Single ' ����w�ʒu
    Private YY() As Single ' ����x�ʒu
    '

    '-------------------------------------------------------------------------------
    '   ����    :   ��ʕ����̓`�F�b�N���X�g�ꗗ���
    '   �֐�    :   Function PrnMainD075()
    '   ����    :   ����
    '   �ߒl    :   True    ����I��
    '   �@�@        False   ���f
    '-------------------------------------------------------------------------------
    Public Function PrnMainD075() As Object

        Dim SQL As String
        Dim Jouken As String
        Dim Order As String
        Dim DT() As IPPAN_DATA_DBT
        Dim Cnt As Integer
        Dim lp As Integer
        Dim pryy As Single
        Dim CmpKey As String
        Dim R_Cnt As Integer
        Dim L_Length As Single
        Dim KinKei As Decimal

        ' �����̐ݒ�
        Jouken = "KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"
        Jouken = Jouken & " AND EDA_NO = '" & KeyKouji.EDA_NO & "'"
        Jouken = Jouken & " AND SIME_YM = '" & CtlKouji.SYORI_YM & "'"
        Jouken = Jouken & " AND NYUURYOKU_FLG = '01'"
        Jouken = Jouken & " AND S_FLG_GENKA = '1'"
        Jouken = Jouken & " AND NOT(MEISAI_KB = '2' AND SUURYOU <> (H_SUURYOU + H_ZAIKO))"
        Order = "GYOUSYA_CD, DENPYOU_KB, DEN_EDA_NO"

        Cnt = 0
        ' �f�[�^�̓ǂݍ���(��ʃ}�X�^)
        Cnt = SELECT_IPPAN_DATA(Jouken, Order, DT)
        If Cnt <= 0 Then
            Exit Function
        End If

        ' �v�����^�[�f�o�C�X�̓ǂݍ���
        Call INI_PRN_Read(1)

        ' �����ݒ�
        If PrnFirstD075() = False Then
            Exit Function
        End If

        ' ����ʒu�̎擾
        Call PrXYGetD075()

        ' ������
        P_Cnt = 1 : pryy = YY(0)
        CmpKey = DT(0).GYOUSYA_CD & DT(0).DENPYOU_KB

        ' ���o����(�y�[�W���o��)
        Call PrItemPD075(pryy, DT(0))
        '----- ���s
        pryy = pryy + ((P_YY * 1.5) * 5)
        ' ���o����(���ڌ��o��)
        Call PrItemD075(pryy, DT(0))

        If PrnCancel = 1 Then
            '----- ���f
            Call PRN_ErrEnd()
            Exit Function
        End If

        KinKei = 0
        For lp = 0 To Cnt - 1
            ' �Ǝ� Or �x���敪 ���Ⴄ�ꍇ
            If CmpKey <> DT(lp).GYOUSYA_CD & DT(lp).DENPYOU_KB Then
                ' ���v���
                Call PrGokeiD075(pryy, KinKei)
                KinKei = 0
                ' ���y�[�W�`�F�b�N
                '----- ���R�[�h�����̎擾
                R_Cnt = PrRcntD075(DT(lp))
                '----- �󎚕��̎擾(�f�[�^�s(R_Cnt) + ���o���s(2) + ���v�s(1))
                L_Length = P_YY * (R_Cnt * 2 + 2 + 1) * 1.5 + P_YY * 5
                If NewPage_CHK(pryy, L_Length) = False Then
                    '----- ���y�[�W
                    Call PRN_NewPage()
                    '----- �y�[�W���̍X�V
                    P_Cnt = P_Cnt + 1
                    '----- �󎚈ʒu�̃��Z�b�g
                    pryy = YY(0)
                    ' ���o����(�y�[�W���o��)
                    Call PrItemPD075(pryy, DT(lp))
                    '----- ���s
                    pryy = pryy + ((P_YY * 1.5) * 5)
                    ' ���o����(���ڌ��o��)
                    Call PrItemD075(pryy, DT(lp))
                    If PrnCancel = 1 Then
                        '----- ���f
                        Call PRN_ErrEnd()
                        Exit Function
                    End If
                Else
                    ' ���o����(���ڌ��o��)
                    Call PrItemD075(pryy, DT(lp))
                End If
                ' �Đݒ�
                CmpKey = DT(lp).GYOUSYA_CD & DT(lp).DENPYOU_KB
            End If
            ' ���y�[�W�`�F�b�N
            If NewPage_CHK(pryy, P_YY * 5) = False Then
                '----- ���y�[�W
                Call PRN_NewPage()
                '----- �y�[�W���̍X�V
                P_Cnt = P_Cnt + 1
                '----- �󎚈ʒu�̃��Z�b�g
                pryy = YY(0)
                ' ���o����(�y�[�W���o��)
                Call PrItemPD075(pryy, DT(lp))
                '----- ���s
                pryy = pryy + ((P_YY * 1.5) * 5)
                ' ���o����(���ڌ��o��)
                Call PrItemD075(pryy, DT(lp))
                If PrnCancel = 1 Then
                    '----- ���f
                    Call PRN_ErrEnd()
                    Exit Function
                End If
            End If
            ' �f�[�^��
            Call PrDataD075(pryy, DT(lp))
            KinKei = KinKei + DT(lp).KINGAKU
            If PrnCancel = 1 Then
                '----- ���f
                Call PRN_ErrEnd()
                Exit Function
            End If
            '----- ���s
            pryy = pryy + (P_YY * 1.5)
            '----- ����
            '2021.08.18 UPGRADE S  AIT)hieutv
            'Call PRN_LINE(XX(0), pryy, XX(UBound(XX)), pryy, 1, "", VSDraw7Lib.PenStyleSettings.psDot)
            Call PRN_LINE(XX(0), pryy, XX(UBound(XX)), pryy, 1, "", DashStyle.Dot)
            '2021.08.18 UPGRADE E
        Next lp
        ' ���v���
        Call PrGokeiD075(pryy, KinKei)

        ' ����t���O(�`�F�b�N���X�g)�̍X�V
        SQL = "UPDATE " & IPPAN_DATA_TBLNAME
        SQL = SQL & " SET"
        SQL = SQL & " P_FLG_CHECK = '1'" ' ���FLG ����ؽ�
        SQL = SQL & " WHERE KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'" ' �H���ԍ�
        SQL = SQL & " AND EDA_NO = '" & KeyKouji.EDA_NO & "'" ' �H���}��
        SQL = SQL & " AND SIME_YM = '" & CtlKouji.SYORI_YM & "'" ' ���N��
        SQL = SQL & " AND NYUURYOKU_FLG = '01'" ' ���͒[���t���O
        SQL = SQL & " AND (DENPYOU_KB = '1' OR DENPYOU_KB = '2')" ' �x���敪
        SQL = SQL & " AND P_FLG_CHECK <> '1'"
        SQL = SQL & " AND S_FLG_GENKA = '1'"

        ' SQL�����s
        '2021.08.12 UPGRADE S  AIT)hieutv
        'SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText + ADODB.ExecuteOptionEnum.adExecuteNoRecords)
        ExecSQL(SQL)
        '2021.08.12 UPGRADE E

        ' ����I��
        Call PRN_END()

        ' �v���r���[�\��
        If ViewFlg = True Then
            frmSYKD075.StatusBar1.Items.Item("Message").Text = ""
            ViewForm.ShowDialog()
        End If

        ' ����I��
        PrnMainD075 = True

    End Function

    '-------------------------------------------------------------------------------
    '   ����    :   �����ݒ�
    '   �֐�    :   Sub     PrnFirstD075()
    '   ����    :   ����
    '   �ߒl    :   True    ����I��
    '   �@�@        False   �Y���Ȃ�
    '-------------------------------------------------------------------------------
    Private Function PrnFirstD075() As Boolean

        ' �߂�l�̏�����
        PrnFirstD075 = False

        ' �^�C�g���ݒ�
        DocName = "��ʕ����̓`�F�b�N���X�g�ꗗ"

        ' �v�����^�[�f�o�C�X�̐ݒ�
        If Printer_Set(PRN1) = False Then
            '2021.09.14 UPGRADE S  AIT)dannnl
            'MsgBox("�ݒ�ɖ����v�����^�[�f�o�C�X���w�肳��܂����B")
            MsgBox("�ݒ�ɖ����v�����^�[�f�o�C�X���w�肳��܂����B", MsgBoxStyle.ApplicationModal, SYSTEMNM)
            '2021.09.14 UPGRADE E
            Exit Function
        End If

        ' �p���ݒ�
        '2021.08.18 UPGRADE S  AIT)hieutv
        'P_SIZE = PrinterObjectConstants.vbPRPSA4 ' �`�S
        'P_ORIENT = VSPrinter7Lib.OrientationSettings.orPortrait ' ��:orLandscape,�c:orPortrait
        P_SIZE = PaperKind.A4  ' �`�S
        P_ORIENT = OrientationEnum.Portrait  ' ��:orLandscape,�c:orPortrait
        '2021.08.18 UPGRADE E
        F_SIZE = 12

        ' ����ďo��ʂ̃Z�b�g
        CallForm = frmSYKD075

        ' ��������ݒ�
        If PRN_First(ViewForm) = False Then
            '2021.09.14 UPGRADE S  AIT)dannnl
            'MsgBox("�v�����^�̐ݒ�Ɏ��s���܂����B", MsgBoxStyle.Exclamation)
            MsgBox("�v�����^�̐ݒ�Ɏ��s���܂����B", MsgBoxStyle.Exclamation, SYSTEMNM)
            '2021.09.14 UPGRADE E
            Exit Function
        End If

        ' ����I��
        PrnFirstD075 = True

    End Function

    '-------------------------------------------------------------------------------
    '   ����    :   ����ʒu�ݒ菈��
    '   �֐�    :   Sub PrXYGetD075()
    '   ����    :   ����
    '   �ߒl    :   ����
    '-------------------------------------------------------------------------------
    Private Sub PrXYGetD075()

        Dim PrLen As Short
        Dim xMargn As Short

        ' ���ڐ��̐ݒ�
        ReDim XX(13)
        ReDim YY(1)

        ' �����񒷂̎Z�o(PrLen=92)
        PrLen = 0
        PrLen = PrLen + Len(Space(10)) ' �x���敪
        PrLen = PrLen + Len(Space(2)) ' �����ԍ�
        PrLen = PrLen + Len(Space(40)) ' �i���E�K�i
        PrLen = PrLen + Len(Space(10)) ' �P��
        PrLen = PrLen + Len(Space(7)) ' ����
        PrLen = PrLen + Len(Space(10)) ' ���z
        PrLen = PrLen + Len(Space(18)) ' 2013/12/11 �ǉ�
        PrLen = PrLen + Len(Space(3)) ' <�x���䗦>�U��
        PrLen = PrLen + Len(Space(3)) ' <�x���䗦>����
        PrLen = PrLen + Len(Space(3)) ' <�x���䗦>��`
        PrLen = PrLen + Len(Space(4)) ' ���E�敪

        ' �t�H���g�T�C�Y�̎Z�o
        xMargn = 9
        'F_SIZE = PRN_FontGet(P_XX * xMargn * 2, P_WIDTH, Basic_F, Space(PrLen))
        F_SIZE = PRN_FontGet(P_XX * xMargn * 2, P_WIDTH, Basic_F, New String(")", PrLen)) - 0.475
        PRN.Font.Size = F_SIZE

        ' �P�������E�����̍Đݒ�
        '2021.08.18 UPGRADE S  AIT)hieutv
        'P_XX = PRN.TextWidth("M")
        'P_YY = PRN.TextHeight("M")
        P_XX = TextWidthToTwips("M") - 0.05
        P_YY = TextHeightToTwips("M") + 3.9
        '2021.08.18 UPGRADE E

        ' ���ڈ󎚈ʒu�̐ݒ� Y��
        YY(0) = P_YY * 7 ' ���ڏ��
        YY(1) = YY(0) + P_YY * 1.5 ' ���ډ���

        ' ���ڈ󎚈ʒu�̐ݒ� X��
        XX(0) = P_XX * xMargn ' �r�����[
        XX(1) = XX(0) + P_XX * 1 ' �x���敪
        XX(2) = XX(1) + P_XX * (10 + 4) ' �����ԍ�
        XX(3) = XX(2) + P_XX * (2 + 7) ' �i���E�K�i
        XX(4) = XX(3) + P_XX * (40 + 4) ' �P��
        XX(5) = XX(4) + P_XX * (10 + 4) ' ����
        XX(6) = XX(5) + P_XX * (7 + 4) ' ���z
        XX(7) = XX(6) + P_XX * (10 + 4) ' ����ŗ� 2013/12/11 �ǉ�
        XX(8) = XX(7) + P_XX * (4 + 4) ' ����Ŋz 2013/12/11 �ǉ�
        XX(9) = XX(8) + P_XX * (10 + 4) ' <�x���䗦>�U��
        XX(10) = XX(9) + P_XX * (3 + 2) ' <�x���䗦>����
        XX(11) = XX(10) + P_XX * (3 + 2) ' <�x���䗦>��`
        XX(12) = XX(11) + P_XX * (3 + 2) ' ���E�敪
        XX(13) = P_WIDTH - P_XX * xMargn ' �r���E�[

    End Sub

    '-------------------------------------------------------------------------------
    '   ����    :   ���ڈ������(�y�[�W���o��)
    '   �֐�    :   Sub PrItemPD075()
    '   ����    :   pryy    �󎚂x�ʒu
    '   �@�@        DT()    IPPAN_DATA_DBT(��ʃ}�X�^)
    '   �ߒl    :   �Ȃ�
    '-------------------------------------------------------------------------------
    Private Sub PrItemPD075(ByRef pryy As Single, ByRef DT As IPPAN_DATA_DBT)

        Dim PR_WK_Renamed As PR_WK
        Dim PR_Text As String
        Dim yMargn As Single
        Dim i As Short

        ' ���f
        If PrnCancel = 1 Then Exit Sub

        '----- �]��
        yMargn = P_YY * 0.25

        ' dummy
        PR_WK_Renamed.DT = ""
        PR_WK_Renamed.FS = F_SIZE
        PR_WK_Renamed.X = XX(0)
        PR_WK_Renamed.Y = YY(0)
        Call PRN_DATA(PR_WK_Renamed)

        '----- �w�b�_
        ' �^�C�g��
        PR_WK_Renamed.DT = "���� ��ʕ����̓`�F�b�N���X�g�ꗗ ����"
        PR_WK_Renamed.FS = 12
        '2021.08.18 UPGRADE S  AIT)hieutv
		'PR_WK_Renamed.X = PRN_XGet(1, XX(1), XX(4), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(0, XX(1), XX(5), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed, Nothing, Nothing, True)
        ' ����
        Call PRN_LINE(XX(7), pryy, XX(UBound(XX)), pryy, 20, "")
        Call PRN_LINE(XX(7), YY(1), XX(UBound(XX)), YY(1), 20, "")
        Call PRN_LINE(XX(7), pryy + ((P_YY * 1.5) * 4), XX(UBound(XX)), pryy + ((P_YY * 1.5) * 4), 20, "")

        For i = 0 To 5
            Call PRN_LINE(XX(7) + (((XX(UBound(XX)) - XX(7)) / 5) * i), pryy, XX(7) + (((XX(UBound(XX)) - XX(7)) / 5) * i), pryy + ((P_YY * 1.5) * 4), 20, "")
        Next i
        For i = 0 To 4
            Select Case i
                Case 0 : PR_WK_Renamed.DT = Trim(CHECKLIST01)
                Case 1 : PR_WK_Renamed.DT = Trim(CHECKLIST02)
                Case 2 : PR_WK_Renamed.DT = Trim(CHECKLIST03)
                Case 3 : PR_WK_Renamed.DT = Trim(CHECKLIST04)
                Case 4 : PR_WK_Renamed.DT = Trim(CHECKLIST05)
            End Select
            PR_WK_Renamed.FS = 7.25
            '2021.08.18 UPGRADE S  AIT)hieutv
			'PR_WK_Renamed.X = PRN_XGet(1, XX(7) + (((XX(UBound(XX)) - XX(7)) / 5) * i), XX(7) + (((XX(UBound(XX)) - XX(7)) / 5) * (i + 1)), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
            PRN_XGet(1, XX(7) + (((XX(UBound(XX)) - XX(7)) / 5) * i), XX(7) + (((XX(UBound(XX)) - XX(7)) / 5) * (i + 1)), PR_WK_Renamed)
            '2021.08.18 UPGRADE E
            PR_WK_Renamed.Y = YY(0) + yMargn
            Call PRN_DATA(PR_WK_Renamed)
        Next i

        ' ����y�[�W
        '2021.08.12 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.DT = VB6.Format(P_Cnt) & " ��"
        PR_WK_Renamed.DT = P_Cnt.ToString & " ��"
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
		'PR_WK_Renamed.X = PRN_XGet(2, XX(0), XX(6), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(0), XX(6), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + (P_YY * 1.5) + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' �����
        '2021.08.03 UPGRADE S  AIT)Tool Convert
        'PR_WK_Renamed.DT = "������t�F" & VB6.Format(Today, "yyyy/mm/dd")
        PR_WK_Renamed.DT = "������t�F" & Today.ToString("yyyy/MM/dd")
        '2021.08.03 UPGRADE E
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
		'PR_WK_Renamed.X = PRN_XGet(2, XX(0), XX(6), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(0), XX(6), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + ((P_YY * 1.5) * 2) + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' ����
        '2021.08.03 UPGRADE S  AIT)Tool Convert
        'PR_WK_Renamed.DT = "�����F" & VB6.Format(DT.SIME_YM, "0000/00")
        PR_WK_Renamed.DT = "�����F" & CDec(DT.SIME_YM).ToString("0000/00")
        '2021.08.03 UPGRADE E
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
		'PR_WK_Renamed.X = PRN_XGet(0, XX(0), XX(6), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(0, XX(0), XX(6), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + ((P_YY * 1.5) * 2) + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' �H���ԍ��{�}�ԁ{�H������
        PR_Text = ""
        If DT.EDA_NO <> "0000" Then PR_Text = "- " & DT.EDA_NO & Space(1)
        PR_WK_Renamed.DT = "�H���ԍ��F" & DT.KOUJI_NO & Space(1) & PR_Text & "�H�����́F" & GetNameKouji(DT.KOUJI_NO, DT.EDA_NO)
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
		'PR_WK_Renamed.X = PRN_XGet(0, XX(0), XX(6), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(0, XX(0), XX(6), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + ((P_YY * 1.5) * 3) + yMargn
        Call PRN_DATA(PR_WK_Renamed)

    End Sub

    '-------------------------------------------------------------------------------
    '   ����    :   ���ڈ������(���ڌ��o��)
    '   �֐�    :   Sub PrItemD075()
    '   ����    :   pryy    �󎚂x�ʒu
    '   �@�@        DT()    IPPAN_DATA_DBT(��ʃ}�X�^)
    '   �ߒl    :   �Ȃ�
    '-------------------------------------------------------------------------------
    Private Sub PrItemD075(ByRef pryy As Single, ByRef DT As IPPAN_DATA_DBT)

        Dim PR_WK_Renamed As PR_WK
        Dim PR_Text As String
        Dim yMargn As Single

        ' ���f
        If PrnCancel = 1 Then Exit Sub

        '----- �]��
        yMargn = P_YY * 0.25

        '----- ����
        Call PRN_LINE(XX(0), pryy, XX(UBound(XX)), pryy, 40, "")

        ' �񍀖�
        '----- 1�s��
        ' �Ǝк���
        PR_WK_Renamed.DT = "�Ǝк���:" & DT.GYOUSYA_CD
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
		'PR_WK_Renamed.X = PRN_XGet(0, XX(1), XX(2), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(0, XX(1), XX(3), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' �ƎЖ���
        PR_WK_Renamed.DT = "�ƎЖ���:" & GetNameGyousya(DT.GYOUSYA_CD)
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
		'PR_WK_Renamed.X = PRN_XGet(0, XX(3), XX(4), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(0, XX(3), XX(5), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' �x���敪
        PR_Text = ""
        Select Case DT.DENPYOU_KB
            Case CStr(1) : PR_Text = "20������"
            Case CStr(2) : PR_Text = "27������"
            Case CStr(3) : PR_Text = "���̑�"
            Case CStr(4) : PR_Text = "�x���Ȃ�"
            Case CStr(5) : PR_Text = "�U��"
        End Select
        PR_WK_Renamed.DT = "�x���敪:" & PR_Text
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
		'PR_WK_Renamed.X = PRN_XGet(0, XX(5), XX(6), PR_WK_Renamed.FS, PR_WK_Renamed.DT) - P_XX * 5
        PRN_XGet(0, XX(5), XX(6) + P_XX * 8, PR_WK_Renamed)
        PR_WK_Renamed.X -= P_XX * 5
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)

        '----- ���s
        pryy = pryy + (P_YY * 1.5)

        '----- 2�s��
        ' �敪
        PR_WK_Renamed.DT = "�敪"
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
		'PR_WK_Renamed.X = PRN_XGet(0, XX(1) + P_XX * 4, XX(2), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(0, XX(1) + P_XX * 4, XX(2), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' �i���E�K�i
        PR_WK_Renamed.DT = "�i���E�K�i"
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
		'PR_WK_Renamed.X = PRN_XGet(0, XX(3), XX(4), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(0, XX(3), XX(4), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' �P��
        PR_WK_Renamed.DT = "�P��"
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
		'PR_WK_Renamed.X = PRN_XGet(2, XX(4), XX(5), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(4), XX(5), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' ����
        PR_WK_Renamed.DT = "����"
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
		'PR_WK_Renamed.X = PRN_XGet(2, XX(5), XX(6), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(5), XX(6), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' ���z
        PR_WK_Renamed.DT = "���z"
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
		'PR_WK_Renamed.X = PRN_XGet(2, XX(6), XX(7), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(6), XX(7), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        '2013/12/11 �ǉ� --------------------------------------------------------------����������
        ' �ŗ�
        PR_WK_Renamed.DT = "�ŗ�"
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
		'PR_WK_Renamed.X = PRN_XGet(2, XX(7), XX(8), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(7), XX(8), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' ����Ŋz
        PR_WK_Renamed.DT = "����Ŋz"
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
		'PR_WK_Renamed.X = PRN_XGet(2, XX(8), XX(9), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(8), XX(9), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        '------------------------------------------------------------------------------����������
        ' �U��
        PR_WK_Renamed.DT = "�U��"
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
		'PR_WK_Renamed.X = PRN_XGet(1, XX(9), XX(10), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(1, XX(9), XX(10), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' ����
        PR_WK_Renamed.DT = "����"
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
		'PR_WK_Renamed.X = PRN_XGet(1, XX(10), XX(11), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(1, XX(10), XX(11), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' ��`
        PR_WK_Renamed.DT = "��`"
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
		'PR_WK_Renamed.X = PRN_XGet(1, XX(11), XX(12), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(1, XX(11), XX(12), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)

        '----- ���s
        pryy = pryy + (P_YY * 1.5)
        '----- ����
        Call PRN_LINE(XX(0), pryy, XX(UBound(XX)), pryy, 20, "")

    End Sub

    '-------------------------------------------------------------------------------
    '   ����    :   �f�[�^�������
    '   �֐�    :   Sub PrDataD075()
    '   ����    :   pryy    ����x�ʒu
    '   �@�@        DT()    IPPAN_DATA_DBT
    '   �ߒl    :   �Ȃ�
    '-------------------------------------------------------------------------------
    Private Sub PrDataD075(ByRef pryy As Single, ByRef DT As IPPAN_DATA_DBT)

        Dim PR_WK_Renamed As PR_WK
        Dim yMargn As Single
        Dim PR_Text As String

        '----- �]��
        yMargn = P_YY * 0.25
        '----- �f�[�^�敪
        If DT.MEISAI_KB = "1" Then
            PR_Text = DT.KOUSYU_CD & "-" & DT.KOUSYU_NO & " " & GetNameKousyu(GetKubunGyosyu(DT.KOUJI_NO, DT.EDA_NO), DT.KOUSYU_CD, DT.KOUSYU_NO)
        Else
            PR_Text = "���o��" & DT.CHUUMON_NO & " " & GetNameWaridasi(DT.KOUJI_NO, DT.EDA_NO, DT.CHUUMON_NO)
        End If
        PR_WK_Renamed.DT = PR_Text
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
		'PR_WK_Renamed.X = PRN_XGet(0, XX(1), XX(2), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(0, XX(1), XX(2), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)

        '----- ���s
        pryy = pryy + P_YY * 1.5
        ' �敪
        PR_Text = ""
        Select Case DT.MEISAI_KB
            Case CStr(1) : PR_Text = "1:�x����"
            Case CStr(2) : PR_Text = "2:�O������"
            Case CStr(3) : PR_Text = "3:���c�x��"
        End Select
        PR_WK_Renamed.DT = PR_Text
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
		'PR_WK_Renamed.X = PRN_XGet(0, XX(1) + P_XX * 4, XX(2), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(0, XX(1) + P_XX * 4, XX(2) + P_XX * 1, PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' �i���E�K�i
        PR_WK_Renamed.DT = DT.BIKOU
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
		'PR_WK_Renamed.X = PRN_XGet(0, XX(3), XX(4), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(0, XX(3), XX(4), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' �P��
        '2021.08.12 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.DT = VB6.Format(DT.TANKA, "#,###,###,##0")
        PR_WK_Renamed.DT = DT.TANKA.ToString("#,###,###,##0")
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
		'PR_WK_Renamed.X = PRN_XGet(2, XX(4), XX(5), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(4), XX(5), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' ����
        PR_Text = ""
        '2021.08.03 UPGRADE S  AIT)Tool Convert
        'PR_Text = VB6.Format(DT.SUURYOU, "##,###.##")
        PR_Text = DT.SUURYOU.ToString("##,###.##")
        '2021.08.03 UPGRADE E
        If Right(PR_Text, 1) = "." Then PR_Text = Left(PR_Text, Len(PR_Text) - 1)
        If Left(PR_Text, 1) = "." Then PR_Text = "0" & PR_Text
        PR_WK_Renamed.DT = PR_Text
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
		'PR_WK_Renamed.X = PRN_XGet(2, XX(5), XX(6), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(5), XX(6), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' ���z
        '2021.08.12 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.DT = VB6.Format(DT.KINGAKU, "#,###,###,##0")
        PR_WK_Renamed.DT = DT.KINGAKU.ToString("#,###,###,##0")
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
		'PR_WK_Renamed.X = PRN_XGet(2, XX(6), XX(7), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(6), XX(7), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        '2013/12/11 �ǉ� --------------------------------------------------------------����������
        ' �ŗ�
        '2021.08.03 UPGRADE S  AIT)Tool Convert
        'PR_WK_Renamed.DT = VB6.Format(DT.ZEIRITU, "#0") & "%"
        PR_WK_Renamed.DT = CDec(DT.ZEIRITU).ToString("#0") & "%"
        '2021.08.03 UPGRADE E
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
		'PR_WK_Renamed.X = PRN_XGet(2, XX(7), XX(8), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(7), XX(8), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' ����Ŋz
        '2021.08.12 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.DT = VB6.Format(DT.ZEI_GAKU, "#,###,###,##0")
        PR_WK_Renamed.DT = DT.ZEI_GAKU.ToString("#,###,###,##0")
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
		'PR_WK_Renamed.X = PRN_XGet(2, XX(8), XX(9), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(8), XX(9), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        '------------------------------------------------------------------------------����������
        ' �U��
        PR_WK_Renamed.DT = CStr(DT.HIRITU_FURI)
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
		'PR_WK_Renamed.X = PRN_XGet(2, XX(9), XX(10), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(9), XX(10), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' ����
        PR_WK_Renamed.DT = CStr(DT.HIRITU_GEN)
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
		'PR_WK_Renamed.X = PRN_XGet(2, XX(10), XX(11), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(10), XX(11), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' ��`
        PR_WK_Renamed.DT = CStr(DT.HIRITU_TE)
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
		'PR_WK_Renamed.X = PRN_XGet(2, XX(11), XX(12), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(11), XX(12), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' ���E
        If DT.SOUSAI_FLG = "1" Then
            PR_Text = "���E"
        Else
            PR_Text = ""
        End If
        PR_WK_Renamed.DT = PR_Text
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
		'PR_WK_Renamed.X = PRN_XGet(1, XX(12), XX(13), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(1, XX(12), XX(13), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)

    End Sub

    '-------------------------------------------------------------------------------
    '   ����    :   ���v�f�[�^�������
    '   �֐�    :   Sub PrGokeiD075()
    '   ����    :   pryy    ����x�ʒu
    '   �@�@        Kingaku ���v���z
    '   �ߒl    :   �Ȃ�
    '-------------------------------------------------------------------------------
    Private Sub PrGokeiD075(ByRef pryy As Single, ByRef KINGAKU As Decimal)

        Dim PR_WK_Renamed As PR_WK
        Dim yMargn As Single

        '----- �]��
        yMargn = P_YY * 0.25

        PR_WK_Renamed.DT = "���@�v"
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
		'PR_WK_Renamed.X = PRN_XGet(2, XX(5), XX(6), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(5), XX(6), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' ���z
        '2021.08.12 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.DT = VB6.Format(KINGAKU, "#,###,###,##0")
        PR_WK_Renamed.DT = KINGAKU.ToString("#,###,###,##0")
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
		'PR_WK_Renamed.X = PRN_XGet(2, XX(6), XX(7), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(6), XX(7), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)

        '----- ���s
        pryy = pryy + P_YY * 1.5

    End Sub

    '-------------------------------------------------------------------------------
    '   ����    :   ���y�[�W�`�F�b�N�p���R�[�h�������o����
    '   �֐�    :   Sub PrRcntD075()
    '   ����    :   DT()    IPPAN_DATA_DBT(��ʃ}�X�^)
    '   �ߒl    :   R_Cnt   ���o���R�[�h����
    '-------------------------------------------------------------------------------
    Private Function PrRcntD075(ByRef DT As IPPAN_DATA_DBT) As Object

        Dim Jouken As String
        Dim Cnt As Integer

        ' �߂�l�̏�����
        PrRcntD075 = 0

        ' �����̐ݒ�
        Jouken = "KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"
        Jouken = Jouken & " AND EDA_NO = '" & KeyKouji.EDA_NO & "'"
        Jouken = Jouken & " AND GYOUSYA_CD = '" & DT.GYOUSYA_CD & "'"
        Jouken = Jouken & " AND DENPYOU_KB = '" & DT.DENPYOU_KB & "'"
        Jouken = Jouken & " AND SIME_YM = '" & CtlKouji.SYORI_YM & "'"

        ' ���R�[�h�����̎擾
        Cnt = 0
        Cnt = CNTGET_IPPAN_DATA(Jouken)

        If Cnt <= 0 Then
            Exit Function
        End If

        ' �߂�l�̃Z�b�g
        PrRcntD075 = Cnt

    End Function
End Module
