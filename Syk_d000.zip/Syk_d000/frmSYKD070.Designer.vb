Imports GrapeCity.Win.Editors

<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frmSYKD070
#Region "Windows Form Designer generated code "
    <System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
        MyBase.New()
        'This call is required by the Windows Form Designer.
        InitializeComponent()

        Frame1 = New ArrayList()
        Frame1.Add(_Frame1_0)
        Frame1.Add(_Frame1_1)
        Frame1.Add(_Frame1_2)

        Label1 = New ArrayList()
        Label1.Add(_Label1_0)
        Label1.Add(_Label1_1)
        Label1.Add(_Label1_2)
        Label1.Add(_Label1_3)
        Label1.Add(_Label1_4)
        Label1.Add(_Label1_5)
        Label1.Add(_Label1_6)
        Label1.Add(_Label1_7)
        Label1.Add(_Label1_8)
        Label1.Add(_Label1_9)
        Label1.Add(_Label1_10)
        Label1.Add(_Label1_11)
        Label1.Add(_Label1_12)
        Label1.Add(_Label1_13)
        Label1.Add(_Label1_14)
        Label1.Add(_Label1_15)
        Label1.Add(_Label1_16)
        Label1.Add(_Label1_17)
        Label1.Add(_Label1_18)
        Label1.Add(_Label1_19)

        Picture2 = New ArrayList()
        Picture2.Add(Nothing)
        Picture2.Add(_Picture2_1)

        cmdKey = New ArrayList()
        cmdKey.Add(Nothing)
        cmdKey.Add(_cmdKey_1)
        cmdKey.Add(_cmdKey_2)
        cmdKey.Add(_cmdKey_3)
        cmdKey.Add(_cmdKey_4)
        cmdKey.Add(_cmdKey_5)
        cmdKey.Add(_cmdKey_6)
        cmdKey.Add(_cmdKey_7)
        cmdKey.Add(_cmdKey_8)
        cmdKey.Add(_cmdKey_9)
        cmdKey.Add(_cmdKey_10)
        cmdKey.Add(_cmdKey_11)
        cmdKey.Add(_cmdKey_12)

        cmdLook = New ArrayList()
        cmdLook.Add(_cmdLook_0)

        ctlMeisai1 = New ArrayList()
        ctlMeisai1.Add(_ctlMeisai1_0)
        ctlMeisai1.Add(_ctlMeisai1_1)
        ctlMeisai1.Add(_ctlMeisai1_2)
        ctlMeisai1.Add(_ctlMeisai1_3)
        ctlMeisai1.Add(_ctlMeisai1_4)
        ctlMeisai1.Add(_ctlMeisai1_5)
        ctlMeisai1.Add(_ctlMeisai1_6)
        ctlMeisai1.Add(_ctlMeisai1_7)

        imNumber1 = New ArrayList()
        imNumber1.Add(_imNumber1_0)
        imNumber1.Add(_imNumber1_1)
        imNumber1.Add(_imNumber1_2)

        imText1 = New ArrayList()
        imText1.Add(_imText1_0)

        imText2 = New ArrayList()
        imText2.Add(_imText2_0)
        imText2.Add(_imText2_1)
        imText2.Add(_imText2_2)

        imText3 = New ArrayList()
        imText3.Add(_imText3_0)
        imText3.Add(_imText3_1)
        imText3.Add(_imText3_2)
    End Sub
    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
        If Disposing Then
            If Not components Is Nothing Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(Disposing)
    End Sub
    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer
    Public ToolTip1 As System.Windows.Forms.ToolTip
    Public WithEvents _Picture2_1 As System.Windows.Forms.Panel
    Public WithEvents Combo1 As System.Windows.Forms.ComboBox
    Public WithEvents _cmdLook_0 As System.Windows.Forms.Button
    Public WithEvents _imText3_1 As GcTextBox
    Public WithEvents _imText3_0 As GcTextBox
    Public WithEvents _imText1_0 As GcTextBox
    Public WithEvents _Label1_2 As System.Windows.Forms.Label
    Public WithEvents _Label1_0 As System.Windows.Forms.Label
    Public WithEvents _Label1_1 As System.Windows.Forms.Label
    Public WithEvents _Frame1_0 As System.Windows.Forms.GroupBox
    Public WithEvents _ctlMeisai1_0 As ctlMeisai
    Public WithEvents VScroll1 As System.Windows.Forms.VScrollBar
    Public WithEvents _imText3_2 As GcTextBox
    Public WithEvents _ctlMeisai1_1 As ctlMeisai
    Public WithEvents _ctlMeisai1_2 As ctlMeisai
    Public WithEvents _ctlMeisai1_3 As ctlMeisai
    Public WithEvents _ctlMeisai1_4 As ctlMeisai
    Public WithEvents _ctlMeisai1_5 As ctlMeisai
    Public WithEvents _ctlMeisai1_6 As ctlMeisai
    Public WithEvents _ctlMeisai1_7 As ctlMeisai
    Public WithEvents _Label1_19 As System.Windows.Forms.Label
    Public WithEvents _Label1_18 As System.Windows.Forms.Label
    Public WithEvents _Label1_17 As System.Windows.Forms.Label
    Public WithEvents _Label1_16 As System.Windows.Forms.Label
    Public WithEvents _Label1_12 As System.Windows.Forms.Label
    Public WithEvents _Label1_13 As System.Windows.Forms.Label
    Public WithEvents _Label1_14 As System.Windows.Forms.Label
    Public WithEvents _Label1_9 As System.Windows.Forms.Label
    Public WithEvents _Label1_10 As System.Windows.Forms.Label
    Public WithEvents _Label1_7 As System.Windows.Forms.Label
    Public WithEvents _Label1_6 As System.Windows.Forms.Label
    Public WithEvents _Label1_8 As System.Windows.Forms.Label
    Public WithEvents _Label1_15 As System.Windows.Forms.Label
    Public WithEvents _Label1_11 As System.Windows.Forms.Label
    Public WithEvents _Frame1_2 As System.Windows.Forms.GroupBox
    Public WithEvents _cmdKey_3 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_12 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_4 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_10 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_6 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_7 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_8 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_9 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_1 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_11 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_2 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_5 As System.Windows.Forms.Button
    Public WithEvents Picture1 As System.Windows.Forms.Panel
    Public WithEvents _StatusBar1_Panel2 As System.Windows.Forms.ToolStripStatusLabel
    Public WithEvents Message As System.Windows.Forms.ToolStripStatusLabel
    Public WithEvents StatusBar1 As System.Windows.Forms.StatusStrip
    Public WithEvents _imText2_2 As GcTextBox
    Public WithEvents _imText2_0 As GcTextBox
    Public WithEvents _imText2_1 As GcTextBox
    Public WithEvents lblTitle As System.Windows.Forms.Label
    Public WithEvents Frame1 As ArrayList
    Public WithEvents Label1 As ArrayList
    Public WithEvents Picture2 As ArrayList
    Public WithEvents cmdKey As ArrayList
    Public WithEvents cmdLook As ArrayList
    Public WithEvents ctlMeisai1 As ArrayList
    Public WithEvents imNumber1 As ArrayList
    Public WithEvents imText1 As ArrayList
    Public WithEvents imText2 As ArrayList
    Public WithEvents imText3 As ArrayList
    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmSYKD070))
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me._Picture2_1 = New System.Windows.Forms.Panel()
        Me._Frame1_1 = New System.Windows.Forms.GroupBox()
        Me._imNumber1_0 = New GrapeCity.Win.Editors.GcNumber(Me.components)
        Me._imNumber1_1 = New GrapeCity.Win.Editors.GcNumber(Me.components)
        Me._imNumber1_2 = New GrapeCity.Win.Editors.GcNumber(Me.components)
        Me._Label1_3 = New System.Windows.Forms.Label()
        Me._Label1_4 = New System.Windows.Forms.Label()
        Me._Label1_5 = New System.Windows.Forms.Label()
        Me._Frame1_0 = New System.Windows.Forms.GroupBox()
        Me.Combo1 = New System.Windows.Forms.ComboBox()
        Me._cmdLook_0 = New System.Windows.Forms.Button()
        Me._imText3_1 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._imText3_0 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._imText1_0 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._Label1_2 = New System.Windows.Forms.Label()
        Me._Label1_0 = New System.Windows.Forms.Label()
        Me._Label1_1 = New System.Windows.Forms.Label()
        Me._Frame1_2 = New System.Windows.Forms.GroupBox()
        Me.VScroll1 = New System.Windows.Forms.VScrollBar()
        Me._imText3_2 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._Label1_19 = New System.Windows.Forms.Label()
        Me._Label1_18 = New System.Windows.Forms.Label()
        Me._Label1_17 = New System.Windows.Forms.Label()
        Me._Label1_16 = New System.Windows.Forms.Label()
        Me._Label1_12 = New System.Windows.Forms.Label()
        Me._Label1_13 = New System.Windows.Forms.Label()
        Me._Label1_14 = New System.Windows.Forms.Label()
        Me._Label1_9 = New System.Windows.Forms.Label()
        Me._Label1_10 = New System.Windows.Forms.Label()
        Me._Label1_7 = New System.Windows.Forms.Label()
        Me._Label1_6 = New System.Windows.Forms.Label()
        Me._Label1_8 = New System.Windows.Forms.Label()
        Me._Label1_15 = New System.Windows.Forms.Label()
        Me._Label1_11 = New System.Windows.Forms.Label()
        Me.Picture1 = New System.Windows.Forms.Panel()
        Me._cmdKey_3 = New System.Windows.Forms.Button()
        Me._cmdKey_12 = New System.Windows.Forms.Button()
        Me._cmdKey_4 = New System.Windows.Forms.Button()
        Me._cmdKey_10 = New System.Windows.Forms.Button()
        Me._cmdKey_6 = New System.Windows.Forms.Button()
        Me._cmdKey_7 = New System.Windows.Forms.Button()
        Me._cmdKey_8 = New System.Windows.Forms.Button()
        Me._cmdKey_9 = New System.Windows.Forms.Button()
        Me._cmdKey_1 = New System.Windows.Forms.Button()
        Me._cmdKey_11 = New System.Windows.Forms.Button()
        Me._cmdKey_2 = New System.Windows.Forms.Button()
        Me._cmdKey_5 = New System.Windows.Forms.Button()
        Me.StatusBar1 = New System.Windows.Forms.StatusStrip()
        Me._StatusBar1_Panel2 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.Message = New System.Windows.Forms.ToolStripStatusLabel()
        Me._imText2_2 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._imText2_0 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._imText2_1 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.GcShortcut1 = New GrapeCity.Win.Editors.GcShortcut(Me.components)
        Me._ctlMeisai1_0 = New Syk_d000.ctlMeisai()
        Me._ctlMeisai1_1 = New Syk_d000.ctlMeisai()
        Me._ctlMeisai1_2 = New Syk_d000.ctlMeisai()
        Me._ctlMeisai1_3 = New Syk_d000.ctlMeisai()
        Me._ctlMeisai1_4 = New Syk_d000.ctlMeisai()
        Me._ctlMeisai1_5 = New Syk_d000.ctlMeisai()
        Me._ctlMeisai1_6 = New Syk_d000.ctlMeisai()
        Me._ctlMeisai1_7 = New Syk_d000.ctlMeisai()
        Me._Picture2_1.SuspendLayout()
        Me._Frame1_1.SuspendLayout()
        CType(Me._imNumber1_0, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imNumber1_1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imNumber1_2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me._Frame1_0.SuspendLayout()
        CType(Me._imText3_1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imText3_0, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imText1_0, System.ComponentModel.ISupportInitialize).BeginInit()
        Me._Frame1_2.SuspendLayout()
        CType(Me._imText3_2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Picture1.SuspendLayout()
        Me.StatusBar1.SuspendLayout()
        CType(Me._imText2_2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imText2_0, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imText2_1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        '_Picture2_1
        '
        Me._Picture2_1.BackColor = System.Drawing.SystemColors.Control
        Me._Picture2_1.Controls.Add(Me._Frame1_1)
        Me._Picture2_1.Cursor = System.Windows.Forms.Cursors.Default
        Me._Picture2_1.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Picture2_1.Location = New System.Drawing.Point(674, 44)
        Me._Picture2_1.Name = "_Picture2_1"
        Me._Picture2_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Picture2_1.Size = New System.Drawing.Size(339, 61)
        Me._Picture2_1.TabIndex = 52
        '
        '_Frame1_1
        '
        Me._Frame1_1.BackColor = System.Drawing.SystemColors.Control
        Me._Frame1_1.Controls.Add(Me._imNumber1_0)
        Me._Frame1_1.Controls.Add(Me._imNumber1_1)
        Me._Frame1_1.Controls.Add(Me._imNumber1_2)
        Me._Frame1_1.Controls.Add(Me._Label1_3)
        Me._Frame1_1.Controls.Add(Me._Label1_4)
        Me._Frame1_1.Controls.Add(Me._Label1_5)
        Me._Frame1_1.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Frame1_1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me._Frame1_1.Location = New System.Drawing.Point(0, 0)
        Me._Frame1_1.Name = "_Frame1_1"
        Me._Frame1_1.Padding = New System.Windows.Forms.Padding(0)
        Me._Frame1_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Frame1_1.Size = New System.Drawing.Size(335, 59)
        Me._Frame1_1.TabIndex = 53
        Me._Frame1_1.TabStop = False
        Me._Frame1_1.Text = "�x���䗦"
        '
        '_imNumber1_0
        '
        Me._imNumber1_0.AlternateText.Zero.ForeColor = System.Drawing.SystemColors.WindowText
        Me._imNumber1_0.AlternateText.Zero.Text = "0"
        Me._imNumber1_0.BackColor = System.Drawing.SystemColors.Control
        Me._imNumber1_0.DisabledForeColor = System.Drawing.SystemColors.MenuText
        Me._imNumber1_0.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Bold)
        Me._imNumber1_0.Location = New System.Drawing.Point(69, 22)
        Me._imNumber1_0.MaxValue = New Decimal(New Integer() {100, 0, 0, 0})
        Me._imNumber1_0.MinValue = New Decimal(New Integer() {0, 0, 0, 0})
        Me._imNumber1_0.Name = "_imNumber1_0"
        Me._imNumber1_0.ReadOnly = True
        Me._imNumber1_0.Size = New System.Drawing.Size(39, 23)
        Me._imNumber1_0.TabIndex = 54
        Me._imNumber1_0.TabStop = False
        '
        '_imNumber1_1
        '
        Me._imNumber1_1.AlternateText.Zero.ForeColor = System.Drawing.SystemColors.WindowText
        Me._imNumber1_1.AlternateText.Zero.Text = "0"
        Me._imNumber1_1.BackColor = System.Drawing.SystemColors.Control
        Me._imNumber1_1.DisabledForeColor = System.Drawing.SystemColors.MenuText
        Me._imNumber1_1.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Bold)
        Me._imNumber1_1.Location = New System.Drawing.Point(175, 22)
        Me._imNumber1_1.MaxValue = New Decimal(New Integer() {100, 0, 0, 0})
        Me._imNumber1_1.MinValue = New Decimal(New Integer() {0, 0, 0, 0})
        Me._imNumber1_1.Name = "_imNumber1_1"
        Me._imNumber1_1.ReadOnly = True
        Me._imNumber1_1.Size = New System.Drawing.Size(39, 23)
        Me._imNumber1_1.TabIndex = 55
        Me._imNumber1_1.TabStop = False
        '
        '_imNumber1_2
        '
        Me._imNumber1_2.AlternateText.Zero.ForeColor = System.Drawing.SystemColors.WindowText
        Me._imNumber1_2.AlternateText.Zero.Text = "0"
        Me._imNumber1_2.BackColor = System.Drawing.SystemColors.Control
        Me._imNumber1_2.DisabledForeColor = System.Drawing.SystemColors.MenuText
        Me._imNumber1_2.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Bold)
        Me._imNumber1_2.Location = New System.Drawing.Point(281, 22)
        Me._imNumber1_2.MaxValue = New Decimal(New Integer() {100, 0, 0, 0})
        Me._imNumber1_2.MinValue = New Decimal(New Integer() {0, 0, 0, 0})
        Me._imNumber1_2.Name = "_imNumber1_2"
        Me._imNumber1_2.ReadOnly = True
        Me._imNumber1_2.Size = New System.Drawing.Size(39, 23)
        Me._imNumber1_2.TabIndex = 56
        Me._imNumber1_2.TabStop = False
        '
        '_Label1_3
        '
        Me._Label1_3.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_3.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_3.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_3.ForeColor = System.Drawing.Color.White
        Me._Label1_3.Location = New System.Drawing.Point(16, 22)
        Me._Label1_3.Name = "_Label1_3"
        Me._Label1_3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_3.Size = New System.Drawing.Size(50, 23)
        Me._Label1_3.TabIndex = 59
        Me._Label1_3.Text = "�U��"
        Me._Label1_3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_4
        '
        Me._Label1_4.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_4.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_4.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_4.ForeColor = System.Drawing.Color.White
        Me._Label1_4.Location = New System.Drawing.Point(122, 22)
        Me._Label1_4.Name = "_Label1_4"
        Me._Label1_4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_4.Size = New System.Drawing.Size(50, 23)
        Me._Label1_4.TabIndex = 58
        Me._Label1_4.Text = "����"
        Me._Label1_4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_5
        '
        Me._Label1_5.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_5.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_5.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_5.ForeColor = System.Drawing.Color.White
        Me._Label1_5.Location = New System.Drawing.Point(228, 22)
        Me._Label1_5.Name = "_Label1_5"
        Me._Label1_5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_5.Size = New System.Drawing.Size(50, 23)
        Me._Label1_5.TabIndex = 57
        Me._Label1_5.Text = "��`"
        Me._Label1_5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Frame1_0
        '
        Me._Frame1_0.BackColor = System.Drawing.SystemColors.Control
        Me._Frame1_0.Controls.Add(Me.Combo1)
        Me._Frame1_0.Controls.Add(Me._cmdLook_0)
        Me._Frame1_0.Controls.Add(Me._imText3_1)
        Me._Frame1_0.Controls.Add(Me._imText3_0)
        Me._Frame1_0.Controls.Add(Me._imText1_0)
        Me._Frame1_0.Controls.Add(Me._Label1_2)
        Me._Frame1_0.Controls.Add(Me._Label1_0)
        Me._Frame1_0.Controls.Add(Me._Label1_1)
        Me._Frame1_0.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Frame1_0.Location = New System.Drawing.Point(4, 34)
        Me._Frame1_0.Name = "_Frame1_0"
        Me._Frame1_0.Padding = New System.Windows.Forms.Padding(0)
        Me._Frame1_0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Frame1_0.Size = New System.Drawing.Size(663, 71)
        Me._Frame1_0.TabIndex = 30
        Me._Frame1_0.TabStop = False
        '
        'Combo1
        '
        Me.Combo1.BackColor = System.Drawing.Color.White
        Me.Combo1.CausesValidation = False
        Me.Combo1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Combo1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Combo1.Font = New System.Drawing.Font("MS Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Combo1.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Combo1.Location = New System.Drawing.Point(326, 14)
        Me.Combo1.Name = "Combo1"
        Me.Combo1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Combo1.Size = New System.Drawing.Size(114, 23)
        Me.Combo1.TabIndex = 0
        Me.Combo1.Tag = "�x���敪��I�����ĉ������B"
        '
        '_cmdLook_0
        '
        Me._cmdLook_0.BackColor = System.Drawing.SystemColors.Control
        Me._cmdLook_0.CausesValidation = False
        Me._cmdLook_0.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdLook_0.Font = New System.Drawing.Font("MS PGothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdLook_0.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdLook_0.Image = CType(resources.GetObject("_cmdLook_0.Image"), System.Drawing.Image)
        Me._cmdLook_0.Location = New System.Drawing.Point(196, 40)
        Me._cmdLook_0.Name = "_cmdLook_0"
        Me._cmdLook_0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdLook_0.Size = New System.Drawing.Size(25, 23)
        Me._cmdLook_0.TabIndex = 45
        Me._cmdLook_0.TabStop = False
        Me._cmdLook_0.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me._cmdLook_0.UseVisualStyleBackColor = False
        '
        '_imText3_1
        '
        Me._imText3_1.BackColor = System.Drawing.SystemColors.Control
        Me._imText3_1.CausesValidation = False
        Me._imText3_1.ContentAlignment = System.Drawing.ContentAlignment.MiddleCenter
        Me._imText3_1.DisabledForeColor = System.Drawing.SystemColors.MenuText
        Me._imText3_1.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Bold)
        Me._imText3_1.ImeMode = System.Windows.Forms.ImeMode.Off
        Me._imText3_1.Location = New System.Drawing.Point(112, 14)
        Me._imText3_1.Name = "_imText3_1"
        Me._imText3_1.ReadOnly = True
        Me._imText3_1.Size = New System.Drawing.Size(73, 23)
        Me._imText3_1.TabIndex = 22
        Me._imText3_1.TabStop = False
        '
        '_imText3_0
        '
        Me._imText3_0.BackColor = System.Drawing.SystemColors.Control
        Me._imText3_0.CausesValidation = False
        Me._imText3_0.DisabledForeColor = System.Drawing.SystemColors.MenuText
        Me._imText3_0.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Bold)
        Me._imText3_0.ImeMode = System.Windows.Forms.ImeMode.Off
        Me._imText3_0.Location = New System.Drawing.Point(222, 40)
        Me._imText3_0.Name = "_imText3_0"
        Me._imText3_0.Size = New System.Drawing.Size(335, 23)
        Me._imText3_0.TabIndex = 46
        Me._imText3_0.TabStop = False
        '
        '_imText1_0
        '
        Me._imText1_0.CausesValidation = False
        Me._imText1_0.ContentAlignment = System.Drawing.ContentAlignment.MiddleCenter
        Me._imText1_0.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Bold)
        Me._imText1_0.Format = "9"
        Me._imText1_0.HighlightText = True
        Me._imText1_0.ImeMode = System.Windows.Forms.ImeMode.Disable
        Me._imText1_0.Location = New System.Drawing.Point(112, 40)
        Me._imText1_0.MaxLength = 8
        Me._imText1_0.Name = "_imText1_0"
        Me._imText1_0.Size = New System.Drawing.Size(83, 23)
        Me._imText1_0.TabIndex = 20
        Me._imText1_0.Tag = "�Ǝк��ނ���͂��ĉ������B�@����߰����F������"
        '
        '_Label1_2
        '
        Me._Label1_2.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_2.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_2.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_2.ForeColor = System.Drawing.Color.White
        Me._Label1_2.Location = New System.Drawing.Point(8, 40)
        Me._Label1_2.Name = "_Label1_2"
        Me._Label1_2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_2.Size = New System.Drawing.Size(100, 23)
        Me._Label1_2.TabIndex = 47
        Me._Label1_2.Text = "�Ɓ@��"
        Me._Label1_2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_0
        '
        Me._Label1_0.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_0.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_0.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_0.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_0.ForeColor = System.Drawing.Color.White
        Me._Label1_0.Location = New System.Drawing.Point(8, 14)
        Me._Label1_0.Name = "_Label1_0"
        Me._Label1_0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_0.Size = New System.Drawing.Size(100, 23)
        Me._Label1_0.TabIndex = 44
        Me._Label1_0.Text = "���N��"
        Me._Label1_0.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_1
        '
        Me._Label1_1.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_1.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_1.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_1.ForeColor = System.Drawing.Color.White
        Me._Label1_1.Location = New System.Drawing.Point(222, 14)
        Me._Label1_1.Name = "_Label1_1"
        Me._Label1_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_1.Size = New System.Drawing.Size(100, 23)
        Me._Label1_1.TabIndex = 31
        Me._Label1_1.Text = "�x���敪"
        Me._Label1_1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Frame1_2
        '
        Me._Frame1_2.BackColor = System.Drawing.SystemColors.Control
        Me._Frame1_2.Controls.Add(Me._ctlMeisai1_0)
        Me._Frame1_2.Controls.Add(Me.VScroll1)
        Me._Frame1_2.Controls.Add(Me._imText3_2)
        Me._Frame1_2.Controls.Add(Me._ctlMeisai1_1)
        Me._Frame1_2.Controls.Add(Me._ctlMeisai1_2)
        Me._Frame1_2.Controls.Add(Me._ctlMeisai1_3)
        Me._Frame1_2.Controls.Add(Me._ctlMeisai1_4)
        Me._Frame1_2.Controls.Add(Me._ctlMeisai1_5)
        Me._Frame1_2.Controls.Add(Me._ctlMeisai1_6)
        Me._Frame1_2.Controls.Add(Me._ctlMeisai1_7)
        Me._Frame1_2.Controls.Add(Me._Label1_19)
        Me._Frame1_2.Controls.Add(Me._Label1_18)
        Me._Frame1_2.Controls.Add(Me._Label1_17)
        Me._Frame1_2.Controls.Add(Me._Label1_16)
        Me._Frame1_2.Controls.Add(Me._Label1_12)
        Me._Frame1_2.Controls.Add(Me._Label1_13)
        Me._Frame1_2.Controls.Add(Me._Label1_14)
        Me._Frame1_2.Controls.Add(Me._Label1_9)
        Me._Frame1_2.Controls.Add(Me._Label1_10)
        Me._Frame1_2.Controls.Add(Me._Label1_7)
        Me._Frame1_2.Controls.Add(Me._Label1_6)
        Me._Frame1_2.Controls.Add(Me._Label1_8)
        Me._Frame1_2.Controls.Add(Me._Label1_15)
        Me._Frame1_2.Controls.Add(Me._Label1_11)
        Me._Frame1_2.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Frame1_2.Location = New System.Drawing.Point(4, 104)
        Me._Frame1_2.Name = "_Frame1_2"
        Me._Frame1_2.Padding = New System.Windows.Forms.Padding(0)
        Me._Frame1_2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Frame1_2.Size = New System.Drawing.Size(1005, 557)
        Me._Frame1_2.TabIndex = 54
        Me._Frame1_2.TabStop = False
        '
        'VScroll1
        '
        Me.VScroll1.Cursor = System.Windows.Forms.Cursors.Default
        Me.VScroll1.LargeChange = 8
        Me.VScroll1.Location = New System.Drawing.Point(979, 59)
        Me.VScroll1.Maximum = 98
        Me.VScroll1.Name = "VScroll1"
        Me.VScroll1.Size = New System.Drawing.Size(17, 466)
        Me.VScroll1.TabIndex = 9
        Me.VScroll1.TabStop = True
        '
        '_imText3_2
        '
        Me._imText3_2.BackColor = System.Drawing.SystemColors.Control
        Me._imText3_2.ContentAlignment = System.Drawing.ContentAlignment.MiddleRight
        Me._imText3_2.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Bold)
        Me._imText3_2.ImeMode = System.Windows.Forms.ImeMode.Off
        Me._imText3_2.Location = New System.Drawing.Point(846, 528)
        Me._imText3_2.Name = "_imText3_2"
        Me._imText3_2.ReadOnly = True
        Me._imText3_2.Size = New System.Drawing.Size(126, 23)
        Me._imText3_2.TabIndex = 33
        Me._imText3_2.TabStop = False
        '
        '_Label1_19
        '
        Me._Label1_19.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_19.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_19.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_19.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_19.ForeColor = System.Drawing.Color.White
        Me._Label1_19.Location = New System.Drawing.Point(150, 14)
        Me._Label1_19.Name = "_Label1_19"
        Me._Label1_19.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_19.Size = New System.Drawing.Size(59, 21)
        Me._Label1_19.TabIndex = 51
        Me._Label1_19.Text = "���o��"
        Me._Label1_19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_18
        '
        Me._Label1_18.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_18.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_18.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_18.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_18.ForeColor = System.Drawing.Color.White
        Me._Label1_18.Location = New System.Drawing.Point(745, 14)
        Me._Label1_18.Name = "_Label1_18"
        Me._Label1_18.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_18.Size = New System.Drawing.Size(50, 21)
        Me._Label1_18.TabIndex = 50
        Me._Label1_18.Text = "�U��"
        Me._Label1_18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_17
        '
        Me._Label1_17.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_17.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_17.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_17.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_17.ForeColor = System.Drawing.Color.White
        Me._Label1_17.Location = New System.Drawing.Point(799, 14)
        Me._Label1_17.Name = "_Label1_17"
        Me._Label1_17.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_17.Size = New System.Drawing.Size(50, 21)
        Me._Label1_17.TabIndex = 49
        Me._Label1_17.Text = "����"
        Me._Label1_17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_16
        '
        Me._Label1_16.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_16.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_16.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_16.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_16.ForeColor = System.Drawing.Color.White
        Me._Label1_16.Location = New System.Drawing.Point(853, 14)
        Me._Label1_16.Name = "_Label1_16"
        Me._Label1_16.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_16.Size = New System.Drawing.Size(50, 21)
        Me._Label1_16.TabIndex = 48
        Me._Label1_16.Text = "��`"
        Me._Label1_16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_12
        '
        Me._Label1_12.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_12.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_12.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_12.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_12.ForeColor = System.Drawing.Color.White
        Me._Label1_12.Location = New System.Drawing.Point(586, 36)
        Me._Label1_12.Name = "_Label1_12"
        Me._Label1_12.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_12.Size = New System.Drawing.Size(127, 21)
        Me._Label1_12.TabIndex = 43
        Me._Label1_12.Text = "�P ��"
        Me._Label1_12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_13
        '
        Me._Label1_13.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_13.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_13.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_13.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_13.ForeColor = System.Drawing.Color.White
        Me._Label1_13.Location = New System.Drawing.Point(717, 36)
        Me._Label1_13.Name = "_Label1_13"
        Me._Label1_13.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_13.Size = New System.Drawing.Size(127, 21)
        Me._Label1_13.TabIndex = 42
        Me._Label1_13.Text = "�� ��"
        Me._Label1_13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_14
        '
        Me._Label1_14.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_14.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_14.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_14.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_14.ForeColor = System.Drawing.Color.White
        Me._Label1_14.Location = New System.Drawing.Point(848, 36)
        Me._Label1_14.Name = "_Label1_14"
        Me._Label1_14.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_14.Size = New System.Drawing.Size(127, 21)
        Me._Label1_14.TabIndex = 41
        Me._Label1_14.Text = "�� �z"
        Me._Label1_14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_9
        '
        Me._Label1_9.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_9.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_9.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_9.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_9.ForeColor = System.Drawing.Color.White
        Me._Label1_9.Location = New System.Drawing.Point(212, 14)
        Me._Label1_9.Name = "_Label1_9"
        Me._Label1_9.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_9.Size = New System.Drawing.Size(78, 21)
        Me._Label1_9.TabIndex = 40
        Me._Label1_9.Text = "�H������"
        Me._Label1_9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_10
        '
        Me._Label1_10.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_10.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_10.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_10.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_10.ForeColor = System.Drawing.Color.White
        Me._Label1_10.Location = New System.Drawing.Point(292, 14)
        Me._Label1_10.Name = "_Label1_10"
        Me._Label1_10.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_10.Size = New System.Drawing.Size(179, 21)
        Me._Label1_10.TabIndex = 39
        Me._Label1_10.Text = " �H�햼"
        Me._Label1_10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        '_Label1_7
        '
        Me._Label1_7.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_7.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_7.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_7.ForeColor = System.Drawing.Color.White
        Me._Label1_7.Location = New System.Drawing.Point(42, 14)
        Me._Label1_7.Name = "_Label1_7"
        Me._Label1_7.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_7.Size = New System.Drawing.Size(106, 21)
        Me._Label1_7.TabIndex = 38
        Me._Label1_7.Text = "�� ��"
        Me._Label1_7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_6
        '
        Me._Label1_6.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_6.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_6.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_6.ForeColor = System.Drawing.Color.White
        Me._Label1_6.Location = New System.Drawing.Point(12, 14)
        Me._Label1_6.Name = "_Label1_6"
        Me._Label1_6.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_6.Size = New System.Drawing.Size(28, 21)
        Me._Label1_6.TabIndex = 37
        Me._Label1_6.Text = "��"
        Me._Label1_6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_8
        '
        Me._Label1_8.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_8.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_8.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_8.ForeColor = System.Drawing.Color.White
        Me._Label1_8.Location = New System.Drawing.Point(42, 36)
        Me._Label1_8.Name = "_Label1_8"
        Me._Label1_8.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_8.Size = New System.Drawing.Size(429, 21)
        Me._Label1_8.TabIndex = 36
        Me._Label1_8.Text = " �i���E�K�i"
        Me._Label1_8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        '_Label1_15
        '
        Me._Label1_15.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me._Label1_15.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_15.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_15.ForeColor = System.Drawing.Color.White
        Me._Label1_15.Location = New System.Drawing.Point(715, 528)
        Me._Label1_15.Name = "_Label1_15"
        Me._Label1_15.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_15.Size = New System.Drawing.Size(128, 23)
        Me._Label1_15.TabIndex = 35
        Me._Label1_15.Text = "���v���z"
        Me._Label1_15.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        '_Label1_11
        '
        Me._Label1_11.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_11.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_11.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_11.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_11.ForeColor = System.Drawing.Color.White
        Me._Label1_11.Location = New System.Drawing.Point(473, 14)
        Me._Label1_11.Name = "_Label1_11"
        Me._Label1_11.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_11.Size = New System.Drawing.Size(268, 21)
        Me._Label1_11.TabIndex = 34
        Me._Label1_11.Text = " ����"
        Me._Label1_11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Picture1
        '
        Me.Picture1.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Picture1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Picture1.Controls.Add(Me._cmdKey_3)
        Me.Picture1.Controls.Add(Me._cmdKey_12)
        Me.Picture1.Controls.Add(Me._cmdKey_4)
        Me.Picture1.Controls.Add(Me._cmdKey_10)
        Me.Picture1.Controls.Add(Me._cmdKey_6)
        Me.Picture1.Controls.Add(Me._cmdKey_7)
        Me.Picture1.Controls.Add(Me._cmdKey_8)
        Me.Picture1.Controls.Add(Me._cmdKey_9)
        Me.Picture1.Controls.Add(Me._cmdKey_1)
        Me.Picture1.Controls.Add(Me._cmdKey_11)
        Me.Picture1.Controls.Add(Me._cmdKey_2)
        Me.Picture1.Controls.Add(Me._cmdKey_5)
        Me.Picture1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Picture1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Picture1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Picture1.Location = New System.Drawing.Point(0, 668)
        Me.Picture1.Name = "Picture1"
        Me.Picture1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Picture1.Size = New System.Drawing.Size(1016, 51)
        Me.Picture1.TabIndex = 60
        '
        '_cmdKey_3
        '
        Me._cmdKey_3.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_3.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_3.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_3.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_3.Location = New System.Drawing.Point(166, 4)
        Me._cmdKey_3.Name = "_cmdKey_3"
        Me._cmdKey_3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_3.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_3.TabIndex = 12
        Me._cmdKey_3.Tag = "���ׂ̍폜���s���܂��B"
        Me._cmdKey_3.Text = "F3" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "�s�폜"
        Me._cmdKey_3.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_3.UseVisualStyleBackColor = False
        '
        '_cmdKey_12
        '
        Me._cmdKey_12.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_12.CausesValidation = False
        Me._cmdKey_12.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_12.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_12.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_12.Location = New System.Drawing.Point(929, 4)
        Me._cmdKey_12.Name = "_cmdKey_12"
        Me._cmdKey_12.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_12.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_12.TabIndex = 21
        Me._cmdKey_12.Tag = "�������I�����܂��B"
        Me._cmdKey_12.Text = "F12" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "�I ��"
        Me._cmdKey_12.UseVisualStyleBackColor = False
        '
        '_cmdKey_4
        '
        Me._cmdKey_4.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_4.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_4.Enabled = False
        Me._cmdKey_4.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_4.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_4.Location = New System.Drawing.Point(246, 4)
        Me._cmdKey_4.Name = "_cmdKey_4"
        Me._cmdKey_4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_4.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_4.TabIndex = 13
        Me._cmdKey_4.Text = "F4"
        Me._cmdKey_4.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_4.UseVisualStyleBackColor = False
        '
        '_cmdKey_10
        '
        Me._cmdKey_10.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_10.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_10.Enabled = False
        Me._cmdKey_10.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_10.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_10.Location = New System.Drawing.Point(769, 4)
        Me._cmdKey_10.Name = "_cmdKey_10"
        Me._cmdKey_10.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_10.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_10.TabIndex = 19
        Me._cmdKey_10.Text = "F10"
        Me._cmdKey_10.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_10.UseVisualStyleBackColor = False
        '
        '_cmdKey_6
        '
        Me._cmdKey_6.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_6.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_6.Enabled = False
        Me._cmdKey_6.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_6.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_6.Location = New System.Drawing.Point(428, 4)
        Me._cmdKey_6.Name = "_cmdKey_6"
        Me._cmdKey_6.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_6.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_6.TabIndex = 15
        Me._cmdKey_6.Text = "F6"
        Me._cmdKey_6.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_6.UseVisualStyleBackColor = False
        '
        '_cmdKey_7
        '
        Me._cmdKey_7.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_7.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_7.Enabled = False
        Me._cmdKey_7.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_7.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_7.Location = New System.Drawing.Point(508, 4)
        Me._cmdKey_7.Name = "_cmdKey_7"
        Me._cmdKey_7.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_7.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_7.TabIndex = 16
        Me._cmdKey_7.Text = "F7"
        Me._cmdKey_7.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_7.UseVisualStyleBackColor = False
        '
        '_cmdKey_8
        '
        Me._cmdKey_8.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_8.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_8.Enabled = False
        Me._cmdKey_8.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_8.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_8.Location = New System.Drawing.Point(588, 4)
        Me._cmdKey_8.Name = "_cmdKey_8"
        Me._cmdKey_8.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_8.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_8.TabIndex = 17
        Me._cmdKey_8.Text = "F8"
        Me._cmdKey_8.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_8.UseVisualStyleBackColor = False
        '
        '_cmdKey_9
        '
        Me._cmdKey_9.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_9.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_9.Enabled = False
        Me._cmdKey_9.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_9.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_9.Location = New System.Drawing.Point(689, 4)
        Me._cmdKey_9.Name = "_cmdKey_9"
        Me._cmdKey_9.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_9.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_9.TabIndex = 18
        Me._cmdKey_9.Text = "F9"
        Me._cmdKey_9.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_9.UseVisualStyleBackColor = False
        '
        '_cmdKey_1
        '
        Me._cmdKey_1.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_1.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_1.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_1.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_1.Location = New System.Drawing.Point(6, 4)
        Me._cmdKey_1.Name = "_cmdKey_1"
        Me._cmdKey_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_1.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_1.TabIndex = 10
        Me._cmdKey_1.Tag = "���̓f�[�^��o�^���܂��B"
        Me._cmdKey_1.Text = "F1" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "�o �^"
        Me._cmdKey_1.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_1.UseVisualStyleBackColor = False
        '
        '_cmdKey_11
        '
        Me._cmdKey_11.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_11.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_11.Enabled = False
        Me._cmdKey_11.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_11.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_11.Location = New System.Drawing.Point(849, 4)
        Me._cmdKey_11.Name = "_cmdKey_11"
        Me._cmdKey_11.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_11.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_11.TabIndex = 20
        Me._cmdKey_11.Text = "F11"
        Me._cmdKey_11.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_11.UseVisualStyleBackColor = False
        '
        '_cmdKey_2
        '
        Me._cmdKey_2.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_2.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_2.Enabled = False
        Me._cmdKey_2.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_2.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_2.Location = New System.Drawing.Point(86, 4)
        Me._cmdKey_2.Name = "_cmdKey_2"
        Me._cmdKey_2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_2.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_2.TabIndex = 11
        Me._cmdKey_2.Text = "F2"
        Me._cmdKey_2.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_2.UseVisualStyleBackColor = False
        '
        '_cmdKey_5
        '
        Me._cmdKey_5.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_5.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_5.Enabled = False
        Me._cmdKey_5.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_5.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_5.Location = New System.Drawing.Point(348, 4)
        Me._cmdKey_5.Name = "_cmdKey_5"
        Me._cmdKey_5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_5.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_5.TabIndex = 14
        Me._cmdKey_5.Text = "F5"
        Me._cmdKey_5.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_5.UseVisualStyleBackColor = False
        '
        'StatusBar1
        '
        Me.StatusBar1.Font = New System.Drawing.Font("MS Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.StatusBar1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me._StatusBar1_Panel2, Me.Message})
        Me.StatusBar1.Location = New System.Drawing.Point(0, 719)
        Me.StatusBar1.Name = "StatusBar1"
        Me.StatusBar1.Size = New System.Drawing.Size(1016, 23)
        Me.StatusBar1.SizingGrip = False
        Me.StatusBar1.TabIndex = 24
        '
        '_StatusBar1_Panel2
        '
        Me._StatusBar1_Panel2.AutoSize = False
        Me._StatusBar1_Panel2.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me._StatusBar1_Panel2.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter
        Me._StatusBar1_Panel2.Margin = New System.Windows.Forms.Padding(0)
        Me._StatusBar1_Panel2.Name = "_StatusBar1_Panel2"
        Me._StatusBar1_Panel2.Size = New System.Drawing.Size(117, 23)
        '
        'Message
        '
        Me.Message.AutoSize = False
        Me.Message.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me.Message.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter
        Me.Message.Margin = New System.Windows.Forms.Padding(0)
        Me.Message.Name = "Message"
        Me.Message.Size = New System.Drawing.Size(902, 23)
        Me.Message.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        '_imText2_2
        '
        Me._imText2_2.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me._imText2_2.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Bold)
        Me._imText2_2.ImeMode = System.Windows.Forms.ImeMode.Off
        Me._imText2_2.Location = New System.Drawing.Point(576, 6)
        Me._imText2_2.Multiline = True
        Me._imText2_2.Name = "_imText2_2"
        Me._imText2_2.ReadOnly = True
        Me._imText2_2.Size = New System.Drawing.Size(433, 23)
        Me._imText2_2.TabIndex = 26
        Me._imText2_2.TabStop = False
        '
        '_imText2_0
        '
        Me._imText2_0.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me._imText2_0.ContentAlignment = System.Drawing.ContentAlignment.MiddleCenter
        Me._imText2_0.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._imText2_0.ImeMode = System.Windows.Forms.ImeMode.Off
        Me._imText2_0.Location = New System.Drawing.Point(440, 6)
        Me._imText2_0.Name = "_imText2_0"
        Me._imText2_0.ReadOnly = True
        Me._imText2_0.Size = New System.Drawing.Size(83, 23)
        Me._imText2_0.TabIndex = 27
        Me._imText2_0.TabStop = False
        '
        '_imText2_1
        '
        Me._imText2_1.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me._imText2_1.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._imText2_1.ImeMode = System.Windows.Forms.ImeMode.Off
        Me._imText2_1.Location = New System.Drawing.Point(527, 6)
        Me._imText2_1.Multiline = True
        Me._imText2_1.Name = "_imText2_1"
        Me._imText2_1.ReadOnly = True
        Me._imText2_1.Size = New System.Drawing.Size(45, 23)
        Me._imText2_1.TabIndex = 28
        Me._imText2_1.TabStop = False
        '
        'lblTitle
        '
        Me.lblTitle.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblTitle.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTitle.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblTitle.Font = New System.Drawing.Font("MS Mincho", 20.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblTitle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.lblTitle.Location = New System.Drawing.Point(0, 0)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblTitle.Size = New System.Drawing.Size(1015, 34)
        Me.lblTitle.TabIndex = 25
        Me.lblTitle.Text = " ��ʕ����́i�y�؁j"
        '
        '_ctlMeisai1_0
        '
        Me._ctlMeisai1_0.Location = New System.Drawing.Point(8, 60)
        Me._ctlMeisai1_0.Name = "_ctlMeisai1_0"
        Me._ctlMeisai1_0.Size = New System.Drawing.Size(971, 59)
        Me._ctlMeisai1_0.TabIndex = 1
        '
        '_ctlMeisai1_1
        '
        Me._ctlMeisai1_1.Location = New System.Drawing.Point(8, 118)
        Me._ctlMeisai1_1.Name = "_ctlMeisai1_1"
        Me._ctlMeisai1_1.Size = New System.Drawing.Size(971, 59)
        Me._ctlMeisai1_1.TabIndex = 2
        '
        '_ctlMeisai1_2
        '
        Me._ctlMeisai1_2.Location = New System.Drawing.Point(8, 176)
        Me._ctlMeisai1_2.Name = "_ctlMeisai1_2"
        Me._ctlMeisai1_2.Size = New System.Drawing.Size(971, 59)
        Me._ctlMeisai1_2.TabIndex = 3
        '
        '_ctlMeisai1_3
        '
        Me._ctlMeisai1_3.Location = New System.Drawing.Point(8, 234)
        Me._ctlMeisai1_3.Name = "_ctlMeisai1_3"
        Me._ctlMeisai1_3.Size = New System.Drawing.Size(971, 59)
        Me._ctlMeisai1_3.TabIndex = 4
        '
        '_ctlMeisai1_4
        '
        Me._ctlMeisai1_4.Location = New System.Drawing.Point(8, 292)
        Me._ctlMeisai1_4.Name = "_ctlMeisai1_4"
        Me._ctlMeisai1_4.Size = New System.Drawing.Size(969, 59)
        Me._ctlMeisai1_4.TabIndex = 5
        '
        '_ctlMeisai1_5
        '
        Me._ctlMeisai1_5.Location = New System.Drawing.Point(8, 350)
        Me._ctlMeisai1_5.Name = "_ctlMeisai1_5"
        Me._ctlMeisai1_5.Size = New System.Drawing.Size(969, 59)
        Me._ctlMeisai1_5.TabIndex = 6
        '
        '_ctlMeisai1_6
        '
        Me._ctlMeisai1_6.Location = New System.Drawing.Point(8, 408)
        Me._ctlMeisai1_6.Name = "_ctlMeisai1_6"
        Me._ctlMeisai1_6.Size = New System.Drawing.Size(969, 59)
        Me._ctlMeisai1_6.TabIndex = 7
        '
        '_ctlMeisai1_7
        '
        Me._ctlMeisai1_7.Location = New System.Drawing.Point(8, 466)
        Me._ctlMeisai1_7.Name = "_ctlMeisai1_7"
        Me._ctlMeisai1_7.Size = New System.Drawing.Size(969, 59)
        Me._ctlMeisai1_7.TabIndex = 8
        '
        'frmSYKD070
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(1016, 742)
        Me.Controls.Add(Me._Picture2_1)
        Me.Controls.Add(Me._Frame1_0)
        Me.Controls.Add(Me._Frame1_2)
        Me.Controls.Add(Me.Picture1)
        Me.Controls.Add(Me.StatusBar1)
        Me.Controls.Add(Me._imText2_2)
        Me.Controls.Add(Me._imText2_0)
        Me.Controls.Add(Me._imText2_1)
        Me.Controls.Add(Me.lblTitle)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.KeyPreview = True
        Me.Location = New System.Drawing.Point(4, 23)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmSYKD070"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "�H���Ǘ��V�X�e��"
        Me._Picture2_1.ResumeLayout(False)
        Me._Frame1_1.ResumeLayout(False)
        CType(Me._imNumber1_0, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._imNumber1_1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._imNumber1_2, System.ComponentModel.ISupportInitialize).EndInit()
        Me._Frame1_0.ResumeLayout(False)
        CType(Me._imText3_1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._imText3_0, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._imText1_0, System.ComponentModel.ISupportInitialize).EndInit()
        Me._Frame1_2.ResumeLayout(False)
        CType(Me._imText3_2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Picture1.ResumeLayout(False)
        Me.StatusBar1.ResumeLayout(False)
        Me.StatusBar1.PerformLayout()
        CType(Me._imText2_2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._imText2_0, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._imText2_1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents GcShortcut1 As GcShortcut
    Friend WithEvents _Frame1_1 As GroupBox
    Public WithEvents _imNumber1_0 As GcNumber
    Public WithEvents _imNumber1_1 As GcNumber
    Public WithEvents _imNumber1_2 As GcNumber
    Public WithEvents _Label1_3 As Label
    Public WithEvents _Label1_4 As Label
    Public WithEvents _Label1_5 As Label
#End Region
End Class