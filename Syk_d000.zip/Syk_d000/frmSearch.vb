Option Strict Off
Option Explicit On

Friend Class frmSearch
    Inherits System.Windows.Forms.Form
    '=============================================================
    ' ���[�U�[���@  �F  �Ђ났��L���b�V���T�[�r�X
    ' �V�X�e�����@  �F  �Ɩ��V�X�e��
    ' ���W���[����  �F  �}�X�^����
    ' ���W���[��ID�@�F  frmSearch.frm
    ' �쐬���@ �@�@ �F  ���� 13 �N 05 �� 08 ��
    ' �X�V���@�@  �@�F  ����    �N    ��    ��
    '=============================================================
    '

    Public MastNo As Short ' 1:�H��}�X�^
    ' 2:�Ј��}�X�^
    ' 3:�ƎЃ}�X�^
    ' 4:��s�}�X�^
    ' 5:���Z�@��
    ' 6:����}�X�^
    ' 7:�Ȗڃ}�X�^
    ' 8:�Ȗڃ}�X�^�i�זڊ܂ށj
    ' 9:�H���}�X�^
    '10:�H��ז�
    '11:�������
    '12:���o���
    '13:�H���}�X�^�i�}�ԂȂ��j

    '��ʕ\���p�\����
    Private Structure DspList
        Dim Code As String
        Dim Name_Renamed As String
        Dim Yobi As String
    End Structure

    '2021.08.11 UPGRADE S  AIT)dannnl
    'Public ZENTEI As String ' �O�񌟍�����
    'Public GetCD As String ' �I���R�[�h
    'Public GetNM As String ' �I�𖼏�
    'Public GetYB As String ' �\������
    Public Shared ZENTEI As String ' �O�񌟍�����
    Public Shared GetCD As String ' �I���R�[�h
    Public Shared GetNM As String ' �I�𖼏�
    Public Shared GetYB As String ' �\������
    '2021.08.11 UPGRADE E

    Private SortMode(1) As Short ' ���� Or �~��
    Private selectHeader As Short
    '

    '-------------------------------------------------------------------------------
    '   ����    :   ��ʃN���A
    '   �֐�    :   Sub DispClear()
    '   ����    :   ����
    '   �@�\    :   ��ʂ��N���A���܂��B
    '-------------------------------------------------------------------------------
    Private Sub DispClear()
        SortMode(0) = -1
        SortMode(1) = 0
        '2021.08.05 UPGRADE S  AIT)hieutv
        'vaSpread1.MaxRows = 0
        'vaSpread1.set_SortKey(1, 1)
        FpSpread1.ActiveSheet.RowCount = 0
        FpSpread1.ActiveSheet.SetColumnAutoSortIndex(0, 0)
        '2021.08.05 UPGRADE E
        imText1(0).Text = ""
        imText1(1).Text = ""
        imText1(2).Text = ""
        cmdKey(1).Enabled = False
    End Sub

    '-------------------------------------------------------------------------------
    '   ����    :   �������ʕ\��
    '   �֐�    :   Function FormFirstSet()
    '   ����    :   ����
    '   �ߒl    :   True    �f�[�^����
    '   �@�@        False   �f�[�^�Ȃ�
    '   �@�\    :   MastNo���e�}�X�^�̌������ʂ�\������B
    '-------------------------------------------------------------------------------
    Private Function FormFirstSet() As Boolean

        Dim lp As Integer
        Dim Cnt As Integer
        Dim DT() As DspList

        '��ʏ����ݒ�
        '2021.08.05 UPGRADE S  AIT)hieutv
        'vaSpread1.MaxRows = 0
        FpSpread1.ActiveSheet.RowCount = 0
        '2021.08.05 UPGRADE E
        cmdKey(1).Enabled = False

        ReDim DT(0)

        Select Case MastNo
            Case 1 '----- �H��}�X�^
                Cnt = GetKousyuMast(DT)
            Case 2 '----- �Ј��}�X�^
                Cnt = GetSyainMast(DT)
            Case 3 '----- �ƎЃ}�X�^
                Cnt = GetGyosyaMast(DT)
            Case 4 '----- ��s�}�X�^
                Cnt = GetGinkouMast(DT)
            Case 5 '----- ���Z�@��
                Cnt = GetKinyuMast(DT)
            Case 6 '----- ����}�X�^
                Cnt = GetBumonMast(DT)
            Case 7 '----- �Ȗڃ}�X�^
                Cnt = GetKamokuMast(DT)
            Case 8 '----- �Ȗڃ}�X�^�i�זڊ܂ށj
                Cnt = GetKamokuMast2(DT)
            Case 9 '----- �H���}�X�^
                Cnt = GetKoujiMast(DT)
            Case 10 '----- �H��ז�
                Cnt = GetSaimokuMast(DT)
            Case 11 '----- �������
                Cnt = GetChumonMast(DT)
            Case 12 '----- ���o���
                Cnt = GetWaridasiMast(DT)
            Case 13 '----- �H���}�X�^�i�}�ԂȂ��j
                Cnt = GetKoujiMast2(DT)
        End Select

        If Cnt <= 0 Then
            If Me.Visible = True Then
                MsgBox("�Y���f�[�^���P��������܂���", MsgBoxStyle.OkOnly, "����")
            End If
            FormFirstSet = False
            Exit Function
        ElseIf Cnt > 500 Then
            'MsgBox "�\�������͂T�O�O���܂łƂ��܂��B", vbOKOnly, "����"
            Cnt = 500
        End If

        '2021.08.05 UPGRADE S  AIT)hieutv
        'vaSpread1.ReDraw = False
        'vaSpread1.MaxRows = Cnt
        FpSpread1.SuspendLayout()
        FpSpread1.ActiveSheet.RowCount = Cnt
        '2021.08.05 UPGRADE E
        cmdKey(1).Enabled = True

        '�f�[�^�\��
        '2021.08.05 UPGRADE S  AIT)hieutv
        'With vaSpread1
        With FpSpread1
            'For lp = 1 To Cnt
            For lp = 0 To Cnt - 1
                '.Col = 1 : .Col2 = .MaxCols
                '.Row = lp : .Row2 = lp
                '.set_RowHeight(lp, 15#)
                '.BlockMode = True
                .ActiveSheet.SetRowHeight(lp, 21)
                '2021.07.26 UPGRADE S  AIT)Tool Convert
                '.Font = VB6.FontChangeBold(.Font, True)
                .Font = New Font(.Font, FontStyle.Bold)
                '2021.07.26 UPGRADE E
                '.BlockMode = False
                '.SetText(1, lp, CObj(DT(lp - 1).Code))
                '.SetText(2, lp, CObj(DT(lp - 1).Name_Renamed))
                '.SetText(3, lp, CObj(DT(lp - 1).Yobi))
                .ActiveSheet.SetText(lp, 0, CObj(DT(lp).Code))
                .ActiveSheet.SetText(lp, 1, CObj(DT(lp).Name_Renamed))
                .ActiveSheet.SetText(lp, 2, CObj(DT(lp).Yobi))
                '2021.08.05 UPGRADE E
            Next lp
        End With
        '2021.08.05 UPGRADE S  AIT)hieutv
        'vaSpread1.ReDraw = True
        'If vaSpread1.Visible = True Then
        '	vaSpread1.Focus()
        'End If
        FpSpread1.ResumeLayout(True)
        If FpSpread1.Visible = True Then
            FpSpread1.Focus()
            FpSpread1.ActiveSheet.AddSelection(0, 0, 1, FpSpread1.ActiveSheet.ColumnCount)
        End If
        '2021.08.05 UPGRADE E

        FormFirstSet = True

    End Function

    '-------------------------------------------------------------------------------
    '   ����    :   �I���f�[�^�̎擾
    '   �֐�    :   Function GetData()
    '   ����    :   ����
    '   �ߒl    :   ����
    '   �@�\    :   �I�����ꂽ�f�[�^��Public�ϐ���GetCD�^GetNM�ɃZ�b�g���܂��B
    '-------------------------------------------------------------------------------
    Private Sub GetData()

        Dim ssText As Object

        '2021.08.05 UPGRADE S  AIT)hieutv
        'Call vaSpread1.GetText(1, vaSpread1.ActiveRow, ssText)
        'GetCD = Trim(ssText)
        'Call vaSpread1.GetText(2, vaSpread1.ActiveRow, ssText)
        'GetNM = Trim(ssText)
        'Call vaSpread1.GetText(3, vaSpread1.ActiveRow, ssText)
        'GetYB = Trim(ssText)
        ssText = FpSpread1.ActiveSheet.GetText(FpSpread1.ActiveSheet.ActiveRowIndex, 0)
        GetCD = Trim(ssText)
        ssText = FpSpread1.ActiveSheet.GetText(FpSpread1.ActiveSheet.ActiveRowIndex, 1)
        GetNM = Trim(ssText)
        ssText = FpSpread1.ActiveSheet.GetText(FpSpread1.ActiveSheet.ActiveRowIndex, 2)
        GetYB = Trim(ssText)
        '2021.08.05 UPGRADE E

    End Sub

    '-------------------------------------------------------------------------------
    '   ����    :   ��ʏ����ݒ�
    '   �֐�    :   Sub DispFirstSet()
    '   ����    :   ����
    '   �ߒl    :   ����
    '   �@�\    :   MastNo���e�}�X�^�ɊY������ݒ���s���B
    '-------------------------------------------------------------------------------
    Private Sub DispFirstSet()

        Dim lp As Short

        Select Case MastNo
            Case 1 '----- �H��}�X�^
                Call DispClear()
                lblTitle.Text = " �H��}�X�^����"
                '2021.08.05 UPGRADE S  AIT)hieutv
                'Call vaSpread1.SetText(1, 0, "�H������")
                'Call vaSpread1.SetText(2, 0, "�H�@�@��@�@��")
                FpSpread1.ActiveSheet.ColumnHeader.Columns(0).Label = "�H������"
                FpSpread1.ActiveSheet.ColumnHeader.Columns(1).Label = "�H�@�@��@�@��"
                '2021.08.05 UPGRADE E
                For lp = 1 To 2
                    imText1(lp).MaxLength = 3
                    imText1(lp).Format = "A9"
                    'imText1(lp).FormatMode = 0�@�@�@�@�@'2021.08.10 UPGRADE DEL  AIT)dannnl
                Next lp
            Case 2 '----- �Ј��}�X�^
                Call DispClear()
                lblTitle.Text = " �Ј��}�X�^����"
                '2021.08.05 UPGRADE S  AIT)hieutv
                'Call vaSpread1.SetText(1, 0, "�Ј�����")
                'Call vaSpread1.SetText(2, 0, "�Ё@�@���@�@��")
                FpSpread1.ActiveSheet.ColumnHeader.Columns(0).Label = "�Ј�����"
                FpSpread1.ActiveSheet.ColumnHeader.Columns(1).Label = "�Ё@�@���@�@��"
                '2021.08.05 UPGRADE E
                For lp = 1 To 2
                    imText1(lp).MaxLength = 8
                    imText1(lp).Format = "9"
                    'imText1(lp).FormatMode = 0�@�@�@�@�@'2021.08.10 UPGRADE DEL  AIT)dannnl
                Next lp
            Case 3 '----- �ƎЃ}�X�^
                Call DispClear()
                lblTitle.Text = " �ƎЃ}�X�^����"
                '2021.08.05 UPGRADE S  AIT)hieutv
                'Call vaSpread1.SetText(1, 0, "�Ǝк���")
                'Call vaSpread1.SetText(2, 0, "�Ɓ@�@�Ё@�@��")
                FpSpread1.ActiveSheet.ColumnHeader.Columns(0).Label = "�Ǝк���"
                FpSpread1.ActiveSheet.ColumnHeader.Columns(1).Label = "�Ɓ@�@�Ё@�@��"
                '2021.08.05 UPGRADE E
                For lp = 1 To 2
                    imText1(lp).MaxLength = 8
                    imText1(lp).Format = "9"
                    'imText1(lp).FormatMode = 0�@�@�@�@�@'2021.08.10 UPGRADE DEL  AIT)dannnl
                Next lp
            Case 4 '----- ��s�}�X�^
                Call DispClear()
                lblTitle.Text = " ��s�}�X�^����"
                '2021.08.05 UPGRADE S  AIT)hieutv
                'Call vaSpread1.SetText(1, 0, "��s����")
                'Call vaSpread1.SetText(2, 0, "��@�@�s�@�@��")
                FpSpread1.ActiveSheet.ColumnHeader.Columns(0).Label = "��s����"
                FpSpread1.ActiveSheet.ColumnHeader.Columns(1).Label = "��@�@�s�@�@��"
                '2021.08.05 UPGRADE E
                For lp = 1 To 2
                    imText1(lp).MaxLength = 4
                    imText1(lp).Format = "9"
                    'imText1(lp).FormatMode = 0�@�@�@�@�@'2021.08.10 UPGRADE DEL  AIT)dannnl
                Next lp
            Case 5 '----- ��s�}�X�^
                Call DispClear()
                lblTitle.Text = " ��s�}�X�^����"
                '2021.08.05 UPGRADE S  AIT)hieutv
                'Call vaSpread1.SetText(1, 0, "��s��x�X����")
                'Call vaSpread1.SetText(2, 0, "�� �Z �@ �� ��")
                FpSpread1.ActiveSheet.ColumnHeader.Columns(0).Label = "��s��x�X����"
                FpSpread1.ActiveSheet.ColumnHeader.Columns(1).Label = "�� �Z �@ �� ��"
                '2021.08.05 UPGRADE E
                For lp = 1 To 2
                    imText1(lp).MaxLength = 7
                    imText1(lp).Format = "9"
                    'imText1(lp).FormatMode = 0�@�@�@�@�@'2021.08.10 UPGRADE DEL  AIT)dannnl
                Next lp
            Case 6 '----- �H���ԍ��}�X�^
                Call DispClear()
                lblTitle.Text = " ����}�X�^����"
                '2021.08.05 UPGRADE S  AIT)hieutv
                'Call vaSpread1.SetText(1, 0, "���庰��")
                'Call vaSpread1.SetText(2, 0, "���@�@��@�@��")
                FpSpread1.ActiveSheet.ColumnHeader.Columns(0).Label = "���庰��"
                FpSpread1.ActiveSheet.ColumnHeader.Columns(1).Label = "���@�@��@�@��"
                '2021.08.05 UPGRADE E
                For lp = 1 To 2
                    imText1(lp).MaxLength = 8
                    imText1(lp).Format = "9"
                    'imText1(lp).FormatMode = 0�@�@�@�@�@'2021.08.10 UPGRADE DEL  AIT)dannnl
                Next lp
            Case 7 '----- �Ȗڃ}�X�^
                Call DispClear()
                lblTitle.Text = " �Ȗڃ}�X�^����"
                '2021.08.05 UPGRADE S  AIT)hieutv
                'Call vaSpread1.SetText(1, 0, "�Ȗں���")
                'Call vaSpread1.SetText(2, 0, "�ȁ@�@�ځ@�@��")
                FpSpread1.ActiveSheet.ColumnHeader.Columns(0).Label = "�Ȗں���"
                FpSpread1.ActiveSheet.ColumnHeader.Columns(1).Label = "�ȁ@�@�ځ@�@��"
                '2021.08.05 UPGRADE E
                For lp = 1 To 2
                    imText1(lp).MaxLength = 6
                    imText1(lp).Format = "9"
                    'imText1(lp).FormatMode = 0�@�@�@�@�@'2021.08.10 UPGRADE DEL  AIT)dannnl
                Next lp
            Case 8 '----- �Ȗڃ}�X�^
                Call DispClear()
                lblTitle.Text = " �Ȗڃ}�X�^����"
                '2021.08.05 UPGRADE S  AIT)hieutv
                'Call vaSpread1.SetText(1, 0, "�Ȗ�-�זں���")
                'Call vaSpread1.SetText(2, 0, "�ȁ@�@�ځ@�@��")
                FpSpread1.ActiveSheet.ColumnHeader.Columns(0).Label = "�Ȗ�-�זں���"
                FpSpread1.ActiveSheet.ColumnHeader.Columns(1).Label = "�ȁ@�@�ځ@�@��"
                '2021.08.05 UPGRADE E
                For lp = 1 To 2
                    imText1(lp).MaxLength = 14
                    imText1(lp).Format = "9"
                    'imText1(lp).FormatMode = 0�@�@�@�@�@'2021.08.10 UPGRADE DEL  AIT)dannnl
                Next lp
            Case 9 '----- �H���ԍ��}�X�^
                Call DispClear()
                lblTitle.Text = " �H����񌟍�"
                '2021.08.05 UPGRADE S  AIT)hieutv
                'Call vaSpread1.SetText(1, 0, "�H���ԍ�-�}��")
                'Call vaSpread1.SetText(2, 0, "�H�@�@���@�@��")
                FpSpread1.ActiveSheet.ColumnHeader.Columns(0).Label = "�H���ԍ�-�}��"
                FpSpread1.ActiveSheet.ColumnHeader.Columns(1).Label = "�H�@�@���@�@��"
                '2021.08.05 UPGRADE E
                For lp = 1 To 2
                    imText1(lp).MaxLength = 12
                    imText1(lp).Format = "9"
                    'imText1(lp).FormatMode = 0�@�@�@�@�@'2021.08.10 UPGRADE DEL  AIT)dannnl
                Next lp
            Case 10 '----- �H��זڃ}�X�^
                Call DispClear()
                lblTitle.Text = " �H��זڃ}�X�^����"
                '2021.08.05 UPGRADE S  AIT)hieutv
                'Call vaSpread1.SetText(1, 0, "�H��זں���")
                'Call vaSpread1.SetText(2, 0, "�H �� �� �� ��")
                FpSpread1.ActiveSheet.ColumnHeader.Columns(0).Label = "�H��זں���"
                FpSpread1.ActiveSheet.ColumnHeader.Columns(1).Label = "�H �� �� �� ��"
                '2021.08.05 UPGRADE E
                For lp = 1 To 2
                    imText1(lp).MaxLength = 5
                    imText1(lp).Format = "A9"
                    'imText1(lp).FormatMode = 0�@�@�@�@�@'2021.08.10 UPGRADE DEL  AIT)dannnl
                Next lp
            Case 11 '----- �������
                Call DispClear()
                lblTitle.Text = " �������}�X�^����"
                '2021.08.05 UPGRADE S  AIT)hieutv
                'Call vaSpread1.SetText(1, 0, "�����ԍ�")
                'Call vaSpread1.SetText(2, 0, "���@�@�@��")
                FpSpread1.ActiveSheet.ColumnHeader.Columns(0).Label = "�����ԍ�"
                FpSpread1.ActiveSheet.ColumnHeader.Columns(1).Label = "���@�@�@��"
                '2021.08.05 UPGRADE E
                For lp = 1 To 2
                    imText1(lp).MaxLength = 2
                    imText1(lp).Format = "A9"
                    'imText1(lp).FormatMode = 0�@�@�@�@�@'2021.08.10 UPGRADE DEL  AIT)dannnl
                Next lp
            Case 12 '----- ���o���
                Call DispClear()
                lblTitle.Text = " ���o���}�X�^����"
                '2021.08.05 UPGRADE S  AIT)hieutv
                'Call vaSpread1.SetText(1, 0, "���o�ԍ�")
                'Call vaSpread1.SetText(2, 0, "���@�@�@��")
                FpSpread1.ActiveSheet.ColumnHeader.Columns(0).Label = "���o�ԍ�"
                FpSpread1.ActiveSheet.ColumnHeader.Columns(1).Label = "���@�@�@��"
                '2021.08.05 UPGRADE E
                For lp = 1 To 2
                    imText1(lp).MaxLength = 2
                    imText1(lp).Format = "A9"
                    'imText1(lp).FormatMode = 0�@�@�@�@�@'2021.08.10 UPGRADE DEL  AIT)dannnl
                Next lp
            Case 13 '----- �H���ԍ��}�X�^�i�}�ԂȂ��j
                Call DispClear()
                lblTitle.Text = " �H����񌟍�"
                '2021.08.05 UPGRADE S  AIT)hieutv
                'Call vaSpread1.SetText(1, 0, "�H���ԍ�")
                'Call vaSpread1.SetText(2, 0, "�H�@�@���@�@��")
                FpSpread1.ActiveSheet.ColumnHeader.Columns(0).Label = "�H���ԍ�"
                FpSpread1.ActiveSheet.ColumnHeader.Columns(1).Label = "�H�@�@���@�@��"
                '2021.08.05 UPGRADE E
                For lp = 1 To 2
                    imText1(lp).MaxLength = 8
                    imText1(lp).Format = "9"
                    'imText1(lp).FormatMode = 0�@�@�@�@�@'2021.08.10 UPGRADE DEL  AIT)dannnl
                Next lp
        End Select

    End Sub

    '-------------------------------------------------------------------------------
    '   ����    :   �H�팟���f�[�^�̎擾
    '   �֐�    :   Function GetKousyuMast()
    '   ����    :   DT()    DspList
    '   �ߒl    :   Cnt     ���o����
    '   �@�@        -1      �ُ�I��
    '   �@�\    :   �����ɊY������R�[�h�^���̂̎擾���s���B
    '-------------------------------------------------------------------------------
    Private Function GetKousyuMast(ByRef DT() As DspList) As Integer

        Dim SQL As String
        '2021.08.05 UPGRADE S  AIT)hieutv
        'Dim Rs As ADODB.Recordset
        Dim Rs As New DataTable
        '2021.08.05 UPGRADE E
        Dim OpenFlg As Short
        Dim Cnt As Integer
        Dim Jouken As String
        Dim wkMei As String
        Dim wkCD1 As String
        Dim wkCD2 As String

        '2021.07.26 UPGRADE S  AIT)Tool Convert
        'On Error GoTo GetKousyuMast_Err
        Try
            '2021.07.26 UPGRADE E

            '�߂�l�̏�����
            GetKousyuMast = -1

            '----- �ϐ��̏�����
            wkMei = ""
            wkCD1 = ""
            wkCD2 = ""

            '----- ���o���̎擾
            wkMei = Trim(imText1(0).Text)
            wkCD1 = Trim(imText1(1).Text)
            wkCD2 = Trim(imText1(2).Text)

            '----- WHERE���̑g�ݗ���
            Jouken = ""
            If Trim(ZENTEI) <> "" Then
                Jouken = "(" & ZENTEI & ")"
            End If
            If wkCD1 <> "" Or wkCD2 <> "" Then
                If Jouken <> "" Then Jouken = Jouken & " AND "
                If wkCD1 = wkCD2 Then
                    Jouken = Jouken & "KOUSYU_CD + KOUSYU_NO = '" & wkCD1 & "'"
                ElseIf wkCD1 <> "" And wkCD2 = "" Then
                    Jouken = Jouken & "KOUSYU_CD + KOUSYU_NO >= '" & wkCD1 & "'"
                ElseIf wkCD2 <> "" And wkCD1 = "" Then
                    Jouken = Jouken & "KOUSYU_CD + KOUSYU_NO <= '" & wkCD2 & "'"
                Else
                    Jouken = Jouken & "KOUSYU_CD + KOUSYU_NO BETWEEN '" & wkCD1 & "' AND '" & wkCD2 & "'"
                End If
            End If
            If wkMei <> "" Then
                If Jouken <> "" Then Jouken = Jouken & " AND "
                Jouken = Jouken & "MEISYOU Like '%" & wkMei & "%'"
            End If

            '----- SQL/SELECT���̑g�ݗ���
            SQL = "SELECT"
            SQL = SQL & " KOUSYU_CD AS F01,"
            SQL = SQL & " KOUSYU_NO AS F02,"
            SQL = SQL & " MEISYOU   AS F03"
            SQL = SQL & " FROM KOUSYU_MAST"
            If Jouken <> "" Then
                SQL = SQL & " WHERE " & Jouken
            End If
            SQL = SQL & " ORDER BY KOUSYU_CD, KOUSYU_NO"

            '----- SQL�����s
            '2021.08.05 UPGRADE S  AIT)hieutv
            'Rs = SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText)
            Rs = RsOpen(SQL)
            '2021.08.05 UPGRADE E
            OpenFlg = 1

            Cnt = 0
            '2021.08.05 UPGRADE S  AIT)hieutv
            'Do Until Rs.EOF
            '	ReDim Preserve DT(Cnt)
            '	DT(Cnt).Code = RsNull(Rs, "F01") & "-" & RsNull(Rs, "F02")
            '	DT(Cnt).Name_Renamed = RsNull(Rs, "F03")
            '	DT(Cnt).Yobi = RsNull(Rs, "F02")
            '	Cnt = Cnt + 1
            '	Rs.MoveNext()
            'Loop

            'Rs.Close()
            For Each Row As DataRow In Rs.Rows
                ReDim Preserve DT(Cnt)
                DT(Cnt).Code = RsNull(Row, "F01") & "-" & RsNull(Row, "F02")
                DT(Cnt).Name_Renamed = RsNull(Row, "F03")
                DT(Cnt).Yobi = RsNull(Row, "F02")
                Cnt = Cnt + 1
            Next

            Rs.Dispose()
            '2021.08.05 UPGRADE E
            Rs = Nothing

            '�߂�l�Ɍ������Z�b�g
            GetKousyuMast = Cnt

            Exit Function

            '2021.07.26 UPGRADE S  AIT)Tool Convert
            'GetKousyuMast_Err:
        Catch ex As Exception
            '2021.07.26 UPGRADE E

            If OpenFlg = 1 Then
                '2021.08.05 UPGRADE S  AIT)hieutv
                'Rs.Close()
                Rs.Dispose()
                '2021.08.05 UPGRADE E
            End If
            Rs = Nothing
            '2021.08.05 UPGRADE S  AIT)hieutv
            'Call Sql_Error_Msg("KOUSYU_MAST SELECT")
            Call Sql_Error_Msg(ex, "KOUSYU_MAST SELECT")
            '2021.08.05 UPGRADE E

        End Try     '2021.07.26 UPGRADE ADD AIT)Tool Convert
    End Function

    '-------------------------------------------------------------------------------
    '   ����    :   �Ј������f�[�^�̎擾
    '   �֐�    :   Function GetSyainMast()
    '   ����    :   DT()    DspList
    '   �ߒl    :   Cnt     ���o����
    '   �@�@        -1      �ُ�I��
    '   �@�\    :   �����ɊY������R�[�h�^���̂̎擾���s���B
    '-------------------------------------------------------------------------------
    Private Function GetSyainMast(ByRef DT() As DspList) As Integer

        Dim SQL As String
        '2021.08.05 UPGRADE S  AIT)hieutv
        'Dim Rs As ADODB.Recordset
        Dim Rs As New DataTable
        '2021.08.05 UPGRADE E
        Dim OpenFlg As Short
        Dim Cnt As Integer
        Dim Jouken As String
        Dim wkMei As String
        Dim wkCD1 As String
        Dim wkCD2 As String

        '2021.07.26 UPGRADE S  AIT)Tool Convert
        'On Error GoTo GetSyainMast_Err
        Try
            '2021.07.26 UPGRADE E

            '�߂�l�̏�����
            GetSyainMast = -1

            '----- �ϐ��̏�����
            wkMei = ""
            wkCD1 = ""
            wkCD2 = ""

            '----- ���o���̎擾
            wkMei = Trim(imText1(0).Text)
            wkCD1 = Trim(imText1(1).Text)
            wkCD2 = Trim(imText1(2).Text)

            '----- WHERE���̑g�ݗ���
            Jouken = ""
            If Trim(ZENTEI) <> "" Then
                Jouken = "(" & ZENTEI & ")"
            End If
            If wkCD1 <> "" Or wkCD2 <> "" Then
                If Jouken <> "" Then Jouken = Jouken & " AND "
                If wkCD1 = wkCD2 Then
                    Jouken = Jouken & "SYAIN_CD = '" & wkCD1 & "'"
                ElseIf wkCD1 <> "" And wkCD2 = "" Then
                    Jouken = Jouken & "SYAIN_CD >= '" & wkCD1 & "'"
                ElseIf wkCD2 <> "" And wkCD1 = "" Then
                    Jouken = Jouken & "SYAIN_CD <= '" & wkCD2 & "'"
                Else
                    Jouken = Jouken & "SYAIN_CD BETWEEN '" & wkCD1 & "' AND '" & wkCD2 & "'"
                End If
            End If
            If wkMei <> "" Then
                If Jouken <> "" Then Jouken = Jouken & " AND "
                Jouken = Jouken & "MEISYOU Like '%" & wkMei & "%'"
            End If

            '----- SQL/SELECT���̑g�ݗ���
            SQL = "SELECT"
            SQL = SQL & " SYAIN_CD AS F01,"
            SQL = SQL & " MEISYOU  AS F02"
            SQL = SQL & " FROM SYAIN_MAST"
            If Jouken <> "" Then
                SQL = SQL & " WHERE " & Jouken
            End If
            SQL = SQL & " ORDER BY SYAIN_CD"

            '----- SQL�����s
            '2021.08.05 UPGRADE S  AIT)hieutv
            'Rs = SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText)
            Rs = RsOpen(SQL)
            '2021.08.05 UPGRADE E
            OpenFlg = 1

            Cnt = 0
            '2021.08.05 UPGRADE S  AIT)hieutv
            'Do Until Rs.EOF
            '    ReDim Preserve DT(Cnt)
            '    DT(Cnt).Code = RsNull(Rs, "F01")
            '    DT(Cnt).Name_Renamed = RsNull(Rs, "F02")
            '    Cnt = Cnt + 1
            '    Rs.MoveNext()
            'Loop

            'Rs.Close()
            For Each Row As DataRow In Rs.Rows
                ReDim Preserve DT(Cnt)
                DT(Cnt).Code = RsNull(Row, "F01")
                DT(Cnt).Name_Renamed = RsNull(Row, "F02")
                Cnt = Cnt + 1
            Next

            Rs.Dispose()
            '2021.08.05 UPGRADE E
            Rs = Nothing

            '�߂�l�Ɍ������Z�b�g
            GetSyainMast = Cnt

            Exit Function

            '2021.07.26 UPGRADE S  AIT)Tool Convert
            'GetSyainMast_Err:
        Catch ex As Exception
            '2021.07.26 UPGRADE E

            If OpenFlg = 1 Then
                '2021.08.05 UPGRADE S  AIT)hieutv
                'Rs.Close()
                Rs.Dispose()
                '2021.08.05 UPGRADE E
            End If
            Rs = Nothing

            '2021.08.05 UPGRADE S  AIT)hieutv
            'Call Sql_Error_Msg("SYAIN_MAST SELECT")
            Call Sql_Error_Msg(ex, "SYAIN_MAST SELECT")
            '2021.08.05 UPGRADE E

        End Try     '2021.07.26 UPGRADE ADD AIT)Tool Convert
    End Function

    '-------------------------------------------------------------------------------
    '   ����    :   �ƎЌ����f�[�^�̎擾
    '   �֐�    :   Function GetGyosyaMast()
    '   ����    :   DT()    DspList
    '   �ߒl    :   Cnt     ���o����
    '   �@�@        -1      �ُ�I��
    '   �@�\    :   �����ɊY������R�[�h�^���̂̎擾���s���B
    '-------------------------------------------------------------------------------
    Private Function GetGyosyaMast(ByRef DT() As DspList) As Integer

        Dim SQL As String
        '2021.08.05 UPGRADE S  AIT)hieutv
        'Dim Rs As ADODB.Recordset
        Dim Rs As New DataTable
        '2021.08.05 UPGRADE E
        Dim OpenFlg As Short
        Dim Cnt As Integer
        Dim Jouken As String
        Dim wkMei As String
        Dim wkCD1 As String
        Dim wkCD2 As String

        '2021.07.26 UPGRADE S  AIT)Tool Convert
        'On Error GoTo GetGyosyaMast_Err
        Try
            '2021.07.26 UPGRADE E

            '�߂�l�̏�����
            GetGyosyaMast = -1

            '----- �ϐ��̏�����
            wkMei = ""
            wkCD1 = ""
            wkCD2 = ""

            '----- ���o���̎擾
            wkMei = Trim(imText1(0).Text)
            wkCD1 = Trim(imText1(1).Text)
            wkCD2 = Trim(imText1(2).Text)

            '----- WHERE���̑g�ݗ���
            Jouken = ""
            If Trim(ZENTEI) <> "" Then
                Jouken = "(" & ZENTEI & ")"
            End If
            If wkCD1 <> "" Or wkCD2 <> "" Then
                If Jouken <> "" Then Jouken = Jouken & " AND "
                If wkCD1 = wkCD2 Then
                    Jouken = Jouken & "GYOUSYA_CD = '" & wkCD1 & "'"
                ElseIf wkCD1 <> "" And wkCD2 = "" Then
                    Jouken = Jouken & "GYOUSYA_CD >= '" & wkCD1 & "'"
                ElseIf wkCD2 <> "" And wkCD1 = "" Then
                    Jouken = Jouken & "GYOUSYA_CD <= '" & wkCD2 & "'"
                Else
                    Jouken = Jouken & "GYOUSYA_CD BETWEEN '" & wkCD1 & "' AND '" & wkCD2 & "'"
                End If
            End If
            If wkMei <> "" Then
                If Jouken <> "" Then Jouken = Jouken & " AND "
                Jouken = Jouken & "MEISYOU Like '%" & wkMei & "%'"
            End If

            '----- SQL/SELECT���̑g�ݗ���
            SQL = "SELECT"
            SQL = SQL & " GYOUSYA_CD AS F01,"
            SQL = SQL & " MEISYOU    AS F02"
            SQL = SQL & " FROM GYOUSYA_MAST"
            If Jouken <> "" Then
                SQL = SQL & " WHERE " & Jouken
            End If
            SQL = SQL & " ORDER BY GYOUSYA_CD"

            '----- SQL�����s
            '2021.08.05 UPGRADE S  AIT)hieutv
            'Rs = SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText)
            Rs = RsOpen(SQL)
            '2021.08.05 UPGRADE E
            OpenFlg = 1

            Cnt = 0
            '2021.08.05 UPGRADE S  AIT)hieutv
            'Do Until Rs.EOF
            '    ReDim Preserve DT(Cnt)
            '    DT(Cnt).Code = RsNull(Rs, "F01")
            '    DT(Cnt).Name_Renamed = RsNull(Rs, "F02")
            '    Cnt = Cnt + 1
            '    Rs.MoveNext()
            'Loop

            'Rs.Close()
            For Each Row As DataRow In Rs.Rows
                ReDim Preserve DT(Cnt)
                DT(Cnt).Code = RsNull(Row, "F01")
                DT(Cnt).Name_Renamed = RsNull(Row, "F02")
                Cnt = Cnt + 1
            Next

            Rs.Dispose()
            '2021.08.05 UPGRADE E
            Rs = Nothing

            '�߂�l�Ɍ������Z�b�g
            GetGyosyaMast = Cnt

            Exit Function

            '2021.07.26 UPGRADE S  AIT)Tool Convert
            'GetGyosyaMast_Err:
        Catch ex As Exception
            '2021.07.26 UPGRADE E

            If OpenFlg = 1 Then
                '2021.08.05 UPGRADE S  AIT)hieutv
                'Rs.Close()
                Rs.Dispose()
                '2021.08.05 UPGRADE E
            End If
            Rs = Nothing

            '2021.08.05 UPGRADE S  AIT)hieutv
            'Call Sql_Error_Msg("GYOUSYA_MAST SELECT")
            Call Sql_Error_Msg(ex, "GYOUSYA_MAST SELECT")
            '2021.08.05 UPGRADE E

        End Try     '2021.07.26 UPGRADE ADD AIT)Tool Convert
    End Function

    '-------------------------------------------------------------------------------
    '   ����    :   ��s�����f�[�^�̎擾
    '   �֐�    :   Function GetGinkouMast()
    '   ����    :   DT()    DspList
    '   �ߒl    :   Cnt     ���o����
    '   �@�@        -1      �ُ�I��
    '   �@�\    :   �����ɊY������R�[�h�^���̂̎擾���s���B
    '-------------------------------------------------------------------------------
    Private Function GetGinkouMast(ByRef DT() As DspList) As Integer

        Dim SQL As String
        '2021.08.05 UPGRADE S  AIT)hieutv
        'Dim Rs As ADODB.Recordset
        Dim Rs As New DataTable
        '2021.08.05 UPGRADE E
        Dim OpenFlg As Short
        Dim Cnt As Integer
        Dim Jouken As String
        Dim wkMei As String
        Dim wkCD1 As String
        Dim wkCD2 As String

        '2021.07.26 UPGRADE S  AIT)Tool Convert
        'On Error GoTo GetGinkouMast_Err
        Try
            '2021.07.26 UPGRADE E

            '�߂�l�̏�����
            GetGinkouMast = -1

            '----- �ϐ��̏�����
            wkMei = ""
            wkCD1 = ""
            wkCD2 = ""

            '----- ���o���̎擾
            wkMei = Trim(imText1(0).Text)
            wkCD1 = Trim(imText1(1).Text)
            wkCD2 = Trim(imText1(2).Text)

            '----- WHERE���̑g�ݗ���
            Jouken = ""
            If Trim(ZENTEI) <> "" Then
                Jouken = "(" & ZENTEI & ")"
            End If
            If wkCD1 <> "" Or wkCD2 <> "" Then
                If Jouken <> "" Then Jouken = Jouken & " AND "
                If wkCD1 = wkCD2 Then
                    Jouken = Jouken & "GINKOU_CD = '" & wkCD1 & "'"
                ElseIf wkCD1 <> "" And wkCD2 = "" Then
                    Jouken = Jouken & "GINKOU_CD >= '" & wkCD1 & "'"
                ElseIf wkCD2 <> "" And wkCD1 = "" Then
                    Jouken = Jouken & "GINKOU_CD <= '" & wkCD2 & "'"
                Else
                    Jouken = Jouken & "GINKOU_CD BETWEEN '" & wkCD1 & "' AND '" & wkCD2 & "'"
                End If
            End If
            If wkMei <> "" Then
                If Jouken <> "" Then Jouken = Jouken & " AND "
                Jouken = Jouken & "MEISYOU Like '%" & wkMei & "%'"
            End If
            If Jouken <> "" Then Jouken = Jouken & " AND "
            Jouken = Jouken & "SITEN_CD = '000'"

            '----- SQL/SELECT���̑g�ݗ���
            SQL = "SELECT"
            SQL = SQL & " GINKOU_CD AS F01,"
            SQL = SQL & " MEISYOU   AS F02"
            SQL = SQL & " FROM GINKOU_MAST"
            If Jouken <> "" Then
                SQL = SQL & " WHERE " & Jouken
            End If
            SQL = SQL & " ORDER BY GINKOU_CD"

            '----- SQL�����s
            '2021.08.05 UPGRADE S  AIT)hieutv
            'Rs = SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText)
            Rs = RsOpen(SQL)
            '2021.08.05 UPGRADE E
            OpenFlg = 1

            Cnt = 0
            '2021.08.05 UPGRADE S  AIT)hieutv
            'Do Until Rs.EOF
            '    ReDim Preserve DT(Cnt)
            '    DT(Cnt).Code = RsNull(Rs, "F01")
            '    DT(Cnt).Name_Renamed = RsNull(Rs, "F02")
            '    Cnt = Cnt + 1
            '    Rs.MoveNext()
            'Loop

            'Rs.Close()
            For Each Row As DataRow In Rs.Rows
                ReDim Preserve DT(Cnt)
                DT(Cnt).Code = RsNull(Row, "F01")
                DT(Cnt).Name_Renamed = RsNull(Row, "F02")
                Cnt = Cnt + 1
            Next

            Rs.Dispose()
            '2021.08.05 UPGRADE E
            Rs = Nothing

            '�߂�l�Ɍ������Z�b�g
            GetGinkouMast = Cnt

            Exit Function

            '2021.07.26 UPGRADE S  AIT)Tool Convert
            'GetGinkouMast_Err:
        Catch ex As Exception
            '2021.07.26 UPGRADE E

            If OpenFlg = 1 Then
                '2021.08.05 UPGRADE S  AIT)hieutv
                'Rs.Close()
                Rs.Dispose()
                '2021.08.05 UPGRADE E
            End If
            Rs = Nothing

            '2021.08.05 UPGRADE S  AIT)hieutv
            'Call Sql_Error_Msg("GINKOU_MAST SELECT")
            Call Sql_Error_Msg(ex, "GINKOU_MAST SELECT")
            '2021.08.05 UPGRADE E

        End Try     '2021.07.26 UPGRADE ADD AIT)Tool Convert
    End Function

    '-------------------------------------------------------------------------------
    '   ����    :   ���Z�@�֌����f�[�^�̎擾
    '   �֐�    :   Function GetKinyuMast()
    '   ����    :   DT()    DspList
    '   �ߒl    :   Cnt     ���o����
    '   �@�@        -1      �ُ�I��
    '   �@�\    :   �����ɊY������R�[�h�^���̂̎擾���s���B
    '-------------------------------------------------------------------------------
    Private Function GetKinyuMast(ByRef DT() As DspList) As Integer

        Dim QRY1 As String
        Dim QRY2 As String
        Dim SQL As String
        '2021.08.05 UPGRADE S  AIT)hieutv
        'Dim Rs As ADODB.Recordset
        Dim Rs As New DataTable
        '2021.08.05 UPGRADE E
        Dim OpenFlg As Short
        Dim Cnt As Integer
        Dim Jouken As String
        Dim wkMei As String
        Dim wkCD1 As String
        Dim wkCD2 As String

        '2021.07.26 UPGRADE S  AIT)Tool Convert
        'On Error GoTo GetKinyuMast_Err
        Try
            '2021.07.26 UPGRADE E

            '�߂�l�̏�����
            GetKinyuMast = -1

            '----- �ϐ��̏�����
            wkMei = ""
            wkCD1 = ""
            wkCD2 = ""

            '----- ���o���̎擾
            wkMei = Trim(imText1(0).Text)
            wkCD1 = Trim(imText1(1).Text)
            wkCD2 = Trim(imText1(2).Text)

            '----- WHERE���̑g�ݗ���
            Jouken = ""
            If Trim(ZENTEI) <> "" Then
                Jouken = "(" & ZENTEI & ")"
            End If
            If wkCD1 <> "" Or wkCD2 <> "" Then
                If Jouken <> "" Then Jouken = Jouken & " AND "
                If wkCD1 = wkCD2 Then
                    If Len(wkCD1) < 5 Then
                        Jouken = Jouken & "GIN.GINKOU_CD = '" & wkCD1 & "'"
                    Else
                        Jouken = Jouken & "SHI.GINKOU_CD + SHI.SITEN_CD = '" & wkCD1 & "'"
                    End If
                ElseIf wkCD1 <> "" And wkCD2 = "" Then
                    If Len(wkCD1) < 5 Then
                        Jouken = Jouken & "GIN.GINKOU_CD >= '" & wkCD1 & "'"
                    Else
                        Jouken = Jouken & "SHI.GINKOU_CD + SHI.SITEN_CD >= '" & wkCD1 & "'"
                    End If
                ElseIf wkCD2 <> "" And wkCD1 = "" Then
                    If Len(wkCD2) < 5 Then
                        Jouken = Jouken & "GIN.GINKOU_CD <= '" & wkCD2 & "'"
                    Else
                        Jouken = Jouken & "SHI.GINKOU_CD + SHI.SITEN_CD <= '" & wkCD2 & "'"
                    End If
                Else
                    If Len(wkCD1) < 5 And Len(wkCD2) < 5 Then
                        Jouken = Jouken & "GIN.GINKOU_CD BETWEEN '" & wkCD1 & "' AND '" & wkCD2 & "'"
                    Else
                        Jouken = Jouken & "SHI.GINKOU_CD + SHI.SITEN_CD BETWEEN '" & wkCD1 & "' AND '" & wkCD2 & "'"
                    End If
                End If
            End If
            If wkMei <> "" Then
                If Jouken <> "" Then Jouken = Jouken & " AND "
                Jouken = Jouken & "(GIN.MEISYOU Like '%" & wkMei & "%' OR SHI.MEISYOU Like '%" & wkMei & "%')"
            End If

            '----- QRY/SELECT���̑g�ݗ���
            QRY1 = "(SELECT GINKOU_MAST.*"
            QRY1 = QRY1 & " FROM GINKOU_MAST"
            QRY1 = QRY1 & " WHERE SITEN_CD = '000') AS GIN"
            QRY2 = "(SELECT GINKOU_MAST.*"
            QRY2 = QRY2 & " FROM GINKOU_MAST"
            QRY2 = QRY2 & " WHERE SITEN_CD <> '000') AS SHI"

            '----- SQL/SELECT���̑g�ݗ���
            SQL = "SELECT"
            SQL = SQL & " GIN.GINKOU_CD AS F01,"
            SQL = SQL & " SHI.SITEN_CD  AS F02,"
            SQL = SQL & " GIN.MEISYOU   AS F03,"
            SQL = SQL & " SHI.MEISYOU   AS F04"
            SQL = SQL & " FROM " & QRY1 & " INNER JOIN " & QRY2
            SQL = SQL & " ON GIN.GINKOU_CD = SHI.GINKOU_CD"
            If Jouken <> "" Then
                SQL = SQL & " WHERE " & Jouken
            End If
            SQL = SQL & " ORDER BY GIN.GINKOU_CD, SHI.SITEN_CD"

            '----- SQL�����s
            '2021.08.05 UPGRADE S  AIT)hieutv
            'Rs = SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText)
            Rs = RsOpen(SQL)
            '2021.08.05 UPGRADE E
            OpenFlg = 1

            Cnt = 0
            '2021.08.05 UPGRADE S  AIT)hieutv
            'Do Until Rs.EOF
            '    ReDim Preserve DT(Cnt)
            '    DT(Cnt).Code = RsNull(Rs, "F01") & RsNull(Rs, "F02")
            '    DT(Cnt).Name_Renamed = Trim(RsNull(Rs, "F03")) & "�@" & Trim(RsNull(Rs, "F04"))
            '    Cnt = Cnt + 1
            '    Rs.MoveNext()
            'Loop

            'Rs.Close()
            For Each Row As DataRow In Rs.Rows
                ReDim Preserve DT(Cnt)
                DT(Cnt).Code = RsNull(Row, "F01") & RsNull(Row, "F02")
                DT(Cnt).Name_Renamed = Trim(RsNull(Row, "F03")) & "�@" & Trim(RsNull(Row, "F04"))
                Cnt = Cnt + 1
            Next

            Rs.Dispose()
            '2021.08.05 UPGRADE E
            Rs = Nothing

            '�߂�l�Ɍ������Z�b�g
            GetKinyuMast = Cnt

            Exit Function

            '2021.07.26 UPGRADE S  AIT)Tool Convert
            'GetKinyuMast_Err:
        Catch ex As Exception
            '2021.07.26 UPGRADE E

            If OpenFlg = 1 Then
                '2021.08.05 UPGRADE S  AIT)hieutv
                'Rs.Close()
                Rs.Dispose()
                '2021.08.05 UPGRADE E
            End If
            Rs = Nothing

            '2021.08.05 UPGRADE S  AIT)hieutv
            'Call Sql_Error_Msg("GINKOU_MAST SELECT")
            Call Sql_Error_Msg(ex, "GINKOU_MAST SELECT")
            '2021.08.05 UPGRADE E

        End Try     '2021.07.26 UPGRADE ADD AIT)Tool Convert
    End Function

    '-------------------------------------------------------------------------------
    '   ����    :   ���匟���f�[�^�̎擾
    '   �֐�    :   Function GetBumonMast()
    '   ����    :   DT()    DspList
    '   �ߒl    :   Cnt     ���o����
    '   �@�@        -1      �ُ�I��
    '   �@�\    :   �����ɊY������R�[�h�^���̂̎擾���s���B
    '-------------------------------------------------------------------------------
    Private Function GetBumonMast(ByRef DT() As DspList) As Integer

        Dim SQL As String
        '2021.08.05 UPGRADE S  AIT)hieutv
        'Dim Rs As ADODB.Recordset
        Dim Rs As New DataTable
        '2021.08.05 UPGRADE E
        Dim OpenFlg As Short
        Dim Cnt As Integer
        Dim Jouken As String
        Dim wkMei As String
        Dim wkCD1 As String
        Dim wkCD2 As String

        '2021.07.26 UPGRADE S  AIT)Tool Convert
        'On Error GoTo GetBumonMast_Err
        Try
            '2021.07.26 UPGRADE E

            '�߂�l�̏�����
            GetBumonMast = -1

            '----- �ϐ��̏�����
            wkMei = ""
            wkCD1 = ""
            wkCD2 = ""

            '----- ���o���̎擾
            wkMei = Trim(imText1(0).Text)
            wkCD1 = Trim(imText1(1).Text)
            wkCD2 = Trim(imText1(2).Text)

            '----- WHERE���̑g�ݗ���
            Jouken = ""
            If Trim(ZENTEI) <> "" Then
                Jouken = "(" & ZENTEI & ")"
            End If
            If wkCD1 <> "" Or wkCD2 <> "" Then
                If Jouken <> "" Then Jouken = Jouken & " AND "
                If wkCD1 = wkCD2 Then
                    Jouken = Jouken & "KOUJI_NO = '" & wkCD1 & "'"
                ElseIf wkCD1 <> "" And wkCD2 = "" Then
                    Jouken = Jouken & "KOUJI_NO >= '" & wkCD1 & "'"
                ElseIf wkCD2 <> "" And wkCD1 = "" Then
                    Jouken = Jouken & "KOUJI_NO <= '" & wkCD2 & "'"
                Else
                    Jouken = Jouken & "KOUJI_NO BETWEEN '" & wkCD1 & "' AND '" & wkCD2 & "'"
                End If
            End If
            If wkMei <> "" Then
                If Jouken <> "" Then Jouken = Jouken & " AND "
                Jouken = Jouken & "MEISYOU Like '%" & wkMei & "%'"
            End If
            If Jouken <> "" Then Jouken = Jouken & " AND "
            Jouken = Jouken & "GYOUSYU_KB = '05'"

            '----- SQL/SELECT���̑g�ݗ���
            SQL = "SELECT"
            SQL = SQL & " KOUJI_NO AS F01,"
            SQL = SQL & " MEISYOU  AS F02"
            SQL = SQL & " FROM KOUJI_NO_MAST"
            If Jouken <> "" Then
                SQL = SQL & " WHERE " & Jouken
            End If
            SQL = SQL & " ORDER BY KOUJI_NO"

            '----- SQL�����s
            '2021.08.05 UPGRADE S  AIT)hieutv
            'Rs = SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText)
            Rs = RsOpen(SQL)
            '2021.08.05 UPGRADE E
            OpenFlg = 1

            Cnt = 0
            '2021.08.05 UPGRADE S  AIT)hieutv
            'Do Until Rs.EOF
            '    ReDim Preserve DT(Cnt)
            '    DT(Cnt).Code = RsNull(Rs, "F01")
            '    DT(Cnt).Name_Renamed = RsNull(Rs, "F02")
            '    Cnt = Cnt + 1
            '    Rs.MoveNext()
            'Loop

            'Rs.Close()
            For Each Row As DataRow In Rs.Rows
                ReDim Preserve DT(Cnt)
                DT(Cnt).Code = RsNull(Row, "F01")
                DT(Cnt).Name_Renamed = RsNull(Row, "F02")
                Cnt = Cnt + 1
            Next

            Rs.Dispose()
            '2021.08.05 UPGRADE E
            Rs = Nothing

            '�߂�l�Ɍ������Z�b�g
            GetBumonMast = Cnt

            Exit Function

            '2021.07.26 UPGRADE S  AIT)Tool Convert
            'GetBumonMast_Err:
        Catch ex As Exception
            '2021.07.26 UPGRADE E

            If OpenFlg = 1 Then
                '2021.08.05 UPGRADE S  AIT)hieutv
                'Rs.Close()
                Rs.Dispose()
                '2021.08.05 UPGRADE E
            End If
            Rs = Nothing

            '2021.08.05 UPGRADE S  AIT)hieutv
            'Call Sql_Error_Msg("KOUJI_NO_MAST SELECT")
            Call Sql_Error_Msg(ex, "KOUJI_NO_MAST SELECT")
            '2021.08.05 UPGRADE E

        End Try     '2021.07.26 UPGRADE ADD AIT)Tool Convert
    End Function

    '-------------------------------------------------------------------------------
    '   ����    :   �Ȗڌ����f�[�^�̎擾
    '   �֐�    :   Function GetKamokuMast()
    '   ����    :   DT()    DspList
    '   �ߒl    :   Cnt     ���o����
    '   �@�@        -1      �ُ�I��
    '   �@�\    :   �����ɊY������R�[�h�^���̂̎擾���s���B
    '-------------------------------------------------------------------------------
    Private Function GetKamokuMast(ByRef DT() As DspList) As Integer

        Dim SQL As String
        '2021.08.05 UPGRADE S  AIT)hieutv
        'Dim Rs As ADODB.Recordset
        Dim Rs As New DataTable
        '2021.08.05 UPGRADE E
        Dim OpenFlg As Short
        Dim Cnt As Integer
        Dim Jouken As String
        Dim wkMei As String
        Dim wkCD1 As String
        Dim wkCD2 As String

        '2021.07.26 UPGRADE S  AIT)Tool Convert
        'On Error GoTo GetKamokuMast_Err
        Try
            '2021.07.26 UPGRADE E

            '�߂�l�̏�����
            GetKamokuMast = -1

            '----- �ϐ��̏�����
            wkMei = ""
            wkCD1 = ""
            wkCD2 = ""

            '----- ���o���̎擾
            wkMei = Trim(imText1(0).Text)
            wkCD1 = Trim(imText1(1).Text)
            wkCD2 = Trim(imText1(2).Text)

            '----- WHERE���̑g�ݗ���
            Jouken = ""
            If Trim(ZENTEI) <> "" Then
                Jouken = "(" & ZENTEI & ")"
            End If
            If wkCD1 <> "" Or wkCD2 <> "" Then
                If Jouken <> "" Then Jouken = Jouken & " AND "
                If wkCD1 = wkCD2 Then
                    Jouken = Jouken & "KAMOKU_CD = '" & wkCD1 & "'"
                ElseIf wkCD1 <> "" And wkCD2 = "" Then
                    Jouken = Jouken & "KAMOKU_CD >= '" & wkCD1 & "'"
                ElseIf wkCD2 <> "" And wkCD1 = "" Then
                    Jouken = Jouken & "KAMOKU_CD <= '" & wkCD2 & "'"
                Else
                    Jouken = Jouken & "KAMOKU_CD BETWEEN '" & wkCD1 & "' AND '" & wkCD2 & "'"
                End If
            End If
            If wkMei <> "" Then
                If Jouken <> "" Then Jouken = Jouken & " AND "
                Jouken = Jouken & "MEISYOU Like '%" & wkMei & "%'"
            End If
            If Jouken <> "" Then Jouken = Jouken & " AND "
            Jouken = Jouken & "(SAIMOKU_CD Is Null Or SAIMOKU_CD = '')"

            '----- SQL/SELECT���̑g�ݗ���
            SQL = "SELECT"
            SQL = SQL & " KAMOKU_CD AS F01,"
            SQL = SQL & " MEISYOU   AS F02"
            SQL = SQL & " FROM KAMOKU_MAST"
            If Jouken <> "" Then
                SQL = SQL & " WHERE " & Jouken
            End If
            SQL = SQL & " ORDER BY KAMOKU_CD"

            '----- SQL�����s
            '2021.08.05 UPGRADE S  AIT)hieutv
            'Rs = SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText)
            Rs = RsOpen(SQL)
            '2021.08.05 UPGRADE E
            OpenFlg = 1

            Cnt = 0
            '2021.08.05 UPGRADE S  AIT)hieutv
            'Do Until Rs.EOF
            '    ReDim Preserve DT(Cnt)
            '    DT(Cnt).Code = RsNull(Rs, "F01")
            '    DT(Cnt).Name_Renamed = RsNull(Rs, "F02")
            '    Cnt = Cnt + 1
            '    Rs.MoveNext()
            'Loop

            'Rs.Close()
            For Each Row As DataRow In Rs.Rows
                ReDim Preserve DT(Cnt)
                DT(Cnt).Code = RsNull(Row, "F01")
                DT(Cnt).Name_Renamed = RsNull(Row, "F02")
                Cnt = Cnt + 1
            Next

            Rs.Dispose()
            '2021.08.05 UPGRADE E
            Rs = Nothing

            '�߂�l�Ɍ������Z�b�g
            GetKamokuMast = Cnt

            Exit Function

            '2021.07.26 UPGRADE S  AIT)Tool Convert
            'GetKamokuMast_Err:
        Catch ex As Exception
            '2021.07.26 UPGRADE E

            If OpenFlg = 1 Then
                '2021.08.05 UPGRADE S  AIT)hieutv
                'Rs.Close()
                Rs.Dispose()
                '2021.08.05 UPGRADE E
            End If
            Rs = Nothing

            '2021.08.05 UPGRADE S  AIT)hieutv
            'Call Sql_Error_Msg("KAMOKU_MAST SELECT")
            Call Sql_Error_Msg(ex, "KAMOKU_MAST SELECT")
            '2021.08.05 UPGRADE E

        End Try     '2021.07.26 UPGRADE ADD AIT)Tool Convert
    End Function

    '-------------------------------------------------------------------------------
    '   ����    :   �Ȗڥ�זڌ����f�[�^�̎擾
    '   �֐�    :   Function GetKamokuMast2()
    '   ����    :   DT()    DspList
    '   �ߒl    :   Cnt     ���o����
    '   �@�@        -1      �ُ�I��
    '   �@�\    :   �����ɊY������R�[�h�^���̂̎擾���s���B
    '-------------------------------------------------------------------------------
    Private Function GetKamokuMast2(ByRef DT() As DspList) As Integer

        Dim QRY1 As String
        Dim QRY2 As String
        Dim SQL As String
        '2021.08.05 UPGRADE S  AIT)hieutv
        'Dim Rs As ADODB.Recordset
        Dim Rs As New DataTable
        '2021.08.05 UPGRADE E
        Dim OpenFlg As Short
        Dim Cnt As Integer
        Dim Jouken As String
        Dim wkMei As String
        Dim wkCD1 As String
        Dim wkCD2 As String

        '2021.07.26 UPGRADE S  AIT)Tool Convert
        'On Error GoTo GetKamokuMast2_Err
        Try
            '2021.07.26 UPGRADE E

            '�߂�l�̏�����
            GetKamokuMast2 = -1

            '----- �ϐ��̏�����
            wkMei = ""
            wkCD1 = ""
            wkCD2 = ""

            '----- ���o���̎擾
            wkMei = Trim(imText1(0).Text)
            wkCD1 = Trim(imText1(1).Text)
            wkCD2 = Trim(imText1(2).Text)

            '----- WHERE���̑g�ݗ���
            Jouken = ""
            If Trim(ZENTEI) <> "" Then
                Jouken = "(" & ZENTEI & ")"
            End If
            If wkCD1 <> "" Or wkCD2 <> "" Then
                If Jouken <> "" Then Jouken = Jouken & " AND "
                If wkCD1 = wkCD2 Then
                    If Len(wkCD1) > 6 Then
                        Jouken = Jouken & "SAI.KAMOKU_CD + SAI.SAIMOKU_CD = '" & wkCD1 & "'"
                    Else
                        Jouken = Jouken & "(KAM.KAMOKU_CD + KAM.SAIMOKU_CD = '" & wkCD1 & "'"
                        Jouken = Jouken & " OR SAI.KAMOKU_CD + SAI.SAIMOKU_CD = '" & wkCD1 & "')"
                    End If
                ElseIf wkCD1 <> "" And wkCD2 = "" Then
                    If Len(wkCD1) > 6 Then
                        Jouken = Jouken & "SAI.KAMOKU_CD + SAI.SAIMOKU_CD >= '" & wkCD1 & "'"
                    Else
                        Jouken = Jouken & "(KAM.KAMOKU_CD + KAM.SAIMOKU_CD >= '" & wkCD1 & "'"
                        Jouken = Jouken & " OR SAI.KAMOKU_CD + SAI.SAIMOKU_CD >= '" & wkCD1 & "')"
                    End If
                ElseIf wkCD2 <> "" And wkCD1 = "" Then
                    If Len(wkCD2) > 6 Then
                        Jouken = Jouken & "SAI.KAMOKU_CD + SAI.SAIMOKU_CD <= '" & wkCD2 & "'"
                    Else
                        Jouken = Jouken & "(KAM.KAMOKU_CD + KAM.SAIMOKU_CD <= '" & wkCD2 & "'"
                        Jouken = Jouken & " OR SAI.KAMOKU_CD + SAI.SAIMOKU_CD <= '" & wkCD2 & "')"
                    End If
                Else
                    If Len(wkCD1) > 6 And Len(wkCD2) > 6 Then
                        Jouken = Jouken & "SAI.KAMOKU_CD + SAI.SAIMOKU_CD BETWEEN '" & wkCD1 & "' AND '" & wkCD2 & "'"
                    Else
                        Jouken = Jouken & "(KAM.KAMOKU_CD + KAM.SAIMOKU_CD BETWEEN '" & wkCD1 & "' AND '" & wkCD2 & "'"
                        Jouken = Jouken & " OR SAI.KAMOKU_CD + SAI.SAIMOKU_CD BETWEEN '" & wkCD1 & "' AND '" & wkCD2 & "')"
                    End If
                End If
            End If
            If wkMei <> "" Then
                If Jouken <> "" Then Jouken = Jouken & " AND "
                Jouken = Jouken & "(KAM.MEISYOU Like '%" & wkMei & "%' OR SAI.MEISYOU Like '%" & wkMei & "%')"
            End If

            '----- QRY/SELECT���̑g�ݗ���
            QRY1 = "(SELECT KAMOKU_MAST.*"
            QRY1 = QRY1 & " FROM KAMOKU_MAST"
            QRY1 = QRY1 & " WHERE (SAIMOKU_CD Is Null Or SAIMOKU_CD = '')) AS KAM"
            QRY2 = "(SELECT KAMOKU_MAST.*"
            QRY2 = QRY2 & " FROM KAMOKU_MAST"
            QRY2 = QRY2 & " WHERE SAIMOKU_CD <> '') AS SAI"

            '----- SQL/SELECT���̑g�ݗ���
            SQL = "SELECT"
            SQL = SQL & " KAM.KAMOKU_CD  AS F01,"
            SQL = SQL & " SAI.SAIMOKU_CD AS F02,"
            SQL = SQL & " KAM.MEISYOU    AS F03,"
            SQL = SQL & " SAI.MEISYOU    AS F04"
            SQL = SQL & " FROM " & QRY1 & " LEFT JOIN " & QRY2
            SQL = SQL & " ON KAM.KAMOKU_CD = SAI.KAMOKU_CD"
            If Jouken <> "" Then
                SQL = SQL & " WHERE " & Jouken
            End If
            SQL = SQL & " ORDER BY KAM.KAMOKU_CD, SAI.SAIMOKU_CD"

            '----- SQL�����s
            '2021.08.05 UPGRADE S  AIT)hieutv
            'Rs = SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText)
            Rs = RsOpen(SQL)
            '2021.08.05 UPGRADE E
            OpenFlg = 1

            Cnt = 0
            '2021.08.05 UPGRADE S  AIT)hieutv
            'Do Until Rs.EOF
            '    ReDim Preserve DT(Cnt)
            '    If Trim(RsNull(Rs, "F02")) = "" Then
            '        DT(Cnt).Code = RsNull(Rs, "F01") & Space(9)
            '    Else
            '        DT(Cnt).Code = RsNull(Rs, "F01") & "-" & RsNull(Rs, "F02")
            '    End If
            '    DT(Cnt).Name_Renamed = Trim(RsNull(Rs, "F03")) & "�@" & Trim(RsNull(Rs, "F04"))
            '    DT(Cnt).Yobi = CStr(Len(Trim(RsNull(Rs, "F03"))))
            '    Cnt = Cnt + 1
            '    Rs.MoveNext()
            'Loop

            'Rs.Close()
            For Each Row As DataRow In Rs.Rows
                ReDim Preserve DT(Cnt)
                If Trim(RsNull(Row, "F02")) = "" Then
                    DT(Cnt).Code = RsNull(Row, "F01") & Space(9)
                Else
                    DT(Cnt).Code = RsNull(Row, "F01") & "-" & RsNull(Row, "F02")
                End If
                DT(Cnt).Name_Renamed = Trim(RsNull(Row, "F03")) & "�@" & Trim(RsNull(Row, "F04"))
                DT(Cnt).Yobi = CStr(Len(Trim(RsNull(Row, "F03"))))
                Cnt = Cnt + 1
            Next

            Rs.Dispose()
            '2021.08.05 UPGRADE E
            Rs = Nothing

            '�߂�l�Ɍ������Z�b�g
            GetKamokuMast2 = Cnt

            Exit Function

            '2021.07.26 UPGRADE S  AIT)Tool Convert
            'GetKamokuMast2_Err:
        Catch ex As Exception
            '2021.07.26 UPGRADE E

            If OpenFlg = 1 Then
                '2021.08.05 UPGRADE S  AIT)hieutv
                'Rs.Close()
                Rs.Dispose()
                '2021.08.05 UPGRADE E
            End If
            Rs = Nothing

            '2021.08.05 UPGRADE S  AIT)hieutv
            'Call Sql_Error_Msg("KAMOKU_MAST SELECT")
            Call Sql_Error_Msg(ex, "KAMOKU_MAST SELECT")
            '2021.08.05 UPGRADE E

        End Try     '2021.07.26 UPGRADE ADD AIT)Tool Convert
    End Function

    '-------------------------------------------------------------------------------
    '   ����    :   �H�������f�[�^�̎擾
    '   �֐�    :   Function GetKoujiMast()
    '   ����    :   DT()    DspList
    '   �ߒl    :   Cnt     ���o����
    '   �@�@        -1      �ُ�I��
    '   �@�\    :   �����ɊY������R�[�h�^���̂̎擾���s���B
    '-------------------------------------------------------------------------------
    Private Function GetKoujiMast(ByRef DT() As DspList) As Integer

        Dim SQL As String
        '2021.08.05 UPGRADE S  AIT)hieutv
        'Dim Rs As ADODB.Recordset
        Dim Rs As New DataTable
        '2021.08.05 UPGRADE E
        Dim OpenFlg As Short
        Dim Cnt As Integer
        Dim Jouken As String
        Dim wkMei As String
        Dim wkCD1 As String
        Dim wkCD2 As String

        '2021.07.26 UPGRADE S  AIT)Tool Convert
        'On Error GoTo GetKoujiMast_Err
        Try
            '2021.07.26 UPGRADE E

            '�߂�l�̏�����
            GetKoujiMast = -1

            '----- �ϐ��̏�����
            wkMei = ""
            wkCD1 = ""
            wkCD2 = ""

            '----- ���o���̎擾
            wkMei = Trim(imText1(0).Text)
            wkCD1 = Trim(imText1(1).Text)
            wkCD2 = Trim(imText1(2).Text)

            '----- WHERE���̑g�ݗ���
            Jouken = ""
            If Trim(ZENTEI) <> "" Then
                Jouken = "(" & ZENTEI & ")"
            End If
            If wkCD1 <> "" Or wkCD2 <> "" Then
                If Jouken <> "" Then Jouken = Jouken & " AND "
                If wkCD1 = wkCD2 Then
                    Jouken = Jouken & "KOUJI_NO + EDA_NO = '" & wkCD1 & "'"
                ElseIf wkCD1 <> "" And wkCD2 = "" Then
                    Jouken = Jouken & "KOUJI_NO + EDA_NO >= '" & wkCD1 & "'"
                ElseIf wkCD2 <> "" And wkCD1 = "" Then
                    Jouken = Jouken & "KOUJI_NO + EDA_NO <= '" & wkCD2 & "'"
                Else
                    Jouken = Jouken & "KOUJI_NO + EDA_NO BETWEEN '" & wkCD1 & "' AND '" & wkCD2 & "'"
                End If
            End If
            If wkMei <> "" Then
                If Jouken <> "" Then Jouken = Jouken & " AND "
                Jouken = Jouken & "MEISYOU Like '%" & wkMei & "%'"
            End If

            '----- SQL/SELECT���̑g�ݗ���
            SQL = "SELECT"
            SQL = SQL & " KOUJI_NO   AS F01,"
            SQL = SQL & " EDA_NO     AS F02,"
            SQL = SQL & " MEISYOU    AS F03,"
            SQL = SQL & " GYOUSYU_KB AS F04"
            SQL = SQL & " FROM KOUJI_NO_MAST"
            If Jouken <> "" Then
                SQL = SQL & " WHERE " & Jouken
            End If
            SQL = SQL & " ORDER BY KOUJI_NO, EDA_NO"

            '----- SQL�����s
            '2021.08.05 UPGRADE S  AIT)hieutv
            'Rs = SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText)
            Rs = RsOpen(SQL)
            '2021.08.05 UPGRADE E
            OpenFlg = 1

            Cnt = 0
            '2021.08.05 UPGRADE S  AIT)hieutv
            'Do Until Rs.EOF
            '    ReDim Preserve DT(Cnt)
            '    If Val(RsNull(Rs, "F02")) = 0 Then
            '        DT(Cnt).Code = RsNull(Rs, "F01") & Space(5)
            '    Else
            '        DT(Cnt).Code = RsNull(Rs, "F01") & "-" & RsNull(Rs, "F02")
            '    End If
            '    DT(Cnt).Name_Renamed = RsNull(Rs, "F03")
            '    DT(Cnt).Yobi = RsNull(Rs, "F04")
            '    Cnt = Cnt + 1
            '    Rs.MoveNext()
            'Loop

            'Rs.Close()
            For Each Row As DataRow In Rs.Rows
                ReDim Preserve DT(Cnt)
                If Val(RsNull(Row, "F02")) = 0 Then
                    DT(Cnt).Code = RsNull(Row, "F01") & Space(5)
                Else
                    DT(Cnt).Code = RsNull(Row, "F01") & "-" & RsNull(Row, "F02")
                End If
                DT(Cnt).Name_Renamed = RsNull(Row, "F03")
                DT(Cnt).Yobi = RsNull(Row, "F04")
                Cnt = Cnt + 1
            Next

            Rs.Dispose()
            '2021.08.05 UPGRADE E
            Rs = Nothing

            '�߂�l�Ɍ������Z�b�g
            GetKoujiMast = Cnt

            Exit Function

            '2021.07.26 UPGRADE S  AIT)Tool Convert
            'GetKoujiMast_Err:
        Catch ex As Exception
            '2021.07.26 UPGRADE E

            If OpenFlg = 1 Then
                '2021.08.05 UPGRADE S  AIT)hieutv
                'Rs.Close()
                Rs.Dispose()
                '2021.08.05 UPGRADE E
            End If
            Rs = Nothing

            '2021.08.05 UPGRADE S  AIT)hieutv
            'Call Sql_Error_Msg("KOUJI_NO_MAST SELECT")
            Call Sql_Error_Msg(ex, "KOUJI_NO_MAST SELECT")
            '2021.08.05 UPGRADE E

        End Try     '2021.07.26 UPGRADE ADD AIT)Tool Convert
    End Function

    '-------------------------------------------------------------------------------
    '   ����    :   �H��זڌ����f�[�^�̎擾
    '   �֐�    :   Function GetSaimokuMast()
    '   ����    :   DT()    DspList
    '   �ߒl    :   Cnt     ���o����
    '   �@�@        -1      �ُ�I��
    '   �@�\    :   �����ɊY������R�[�h�^���̂̎擾���s���B
    '-------------------------------------------------------------------------------
    Private Function GetSaimokuMast(ByRef DT() As DspList) As Integer

        Dim SQL As String
        '2021.08.05 UPGRADE S  AIT)hieutv
        'Dim Rs As ADODB.Recordset
        Dim Rs As New DataTable
        '2021.08.05 UPGRADE E
        Dim OpenFlg As Short
        Dim Cnt As Integer
        Dim Jouken As String
        Dim wkMei As String
        Dim wkCD1 As String
        Dim wkCD2 As String

        '2021.07.26 UPGRADE S  AIT)Tool Convert
        'On Error GoTo GetSaimokuMast_Err
        Try
            '2021.07.26 UPGRADE E

            '�߂�l�̏�����
            GetSaimokuMast = -1

            '----- �ϐ��̏�����
            wkMei = ""
            wkCD1 = ""
            wkCD2 = ""

            '----- ���o���̎擾
            wkMei = Trim(imText1(0).Text)
            wkCD1 = Trim(imText1(1).Text)
            wkCD2 = Trim(imText1(2).Text)

            '----- WHERE���̑g�ݗ���
            Jouken = ""
            If Trim(ZENTEI) <> "" Then
                Jouken = "(" & ZENTEI & ")"
            End If
            If wkCD1 <> "" Or wkCD2 <> "" Then
                If Jouken <> "" Then Jouken = Jouken & " AND "
                If wkCD1 = wkCD2 Then
                    Jouken = Jouken & "SAIMOKU_CD = '" & wkCD1 & "'"
                ElseIf wkCD1 <> "" And wkCD2 = "" Then
                    Jouken = Jouken & "SAIMOKU_CD >= '" & wkCD1 & "'"
                ElseIf wkCD2 <> "" And wkCD1 = "" Then
                    Jouken = Jouken & "SAIMOKU_CD <= '" & wkCD2 & "'"
                Else
                    Jouken = Jouken & "SAIMOKU_CD BETWEEN '" & wkCD1 & "' AND '" & wkCD2 & "'"
                End If
            End If
            If wkMei <> "" Then
                If Jouken <> "" Then Jouken = Jouken & " AND "
                Jouken = Jouken & "MEISYOU Like '%" & wkMei & "%'"
            End If

            '----- SQL/SELECT���̑g�ݗ���
            SQL = "SELECT"
            SQL = SQL & " SAIMOKU_CD AS F01,"
            SQL = SQL & " MEISYOU    AS F02"
            SQL = SQL & " FROM SAIMOKU_MAST"
            If Jouken <> "" Then
                SQL = SQL & " WHERE " & Jouken
            End If
            SQL = SQL & " ORDER BY SAIMOKU_CD"

            '----- SQL�����s
            '2021.08.05 UPGRADE S  AIT)hieutv
            'Rs = SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText)
            Rs = RsOpen(SQL)
            '2021.08.05 UPGRADE E
            OpenFlg = 1

            Cnt = 0
            '2021.08.05 UPGRADE S  AIT)hieutv
            'Do Until Rs.EOF
            '    ReDim Preserve DT(Cnt)
            '    DT(Cnt).Code = RsNull(Rs, "F01")
            '    DT(Cnt).Name_Renamed = RsNull(Rs, "F02")
            '    Cnt = Cnt + 1
            '    Rs.MoveNext()
            'Loop

            'Rs.Close()
            For Each Row As DataRow In Rs.Rows
                ReDim Preserve DT(Cnt)
                DT(Cnt).Code = RsNull(Row, "F01")
                DT(Cnt).Name_Renamed = RsNull(Row, "F02")
                Cnt = Cnt + 1
            Next

            Rs.Dispose()
            '2021.08.05 UPGRADE E
            Rs = Nothing

            '�߂�l�Ɍ������Z�b�g
            GetSaimokuMast = Cnt

            Exit Function

            '2021.07.26 UPGRADE S  AIT)Tool Convert
            'GetSaimokuMast_Err:
        Catch ex As Exception
            '2021.07.26 UPGRADE E

            If OpenFlg = 1 Then
                '2021.08.05 UPGRADE S  AIT)hieutv
                'Rs.Close()
                Rs.Dispose()
                '2021.08.05 UPGRADE E
            End If
            Rs = Nothing

            '2021.08.05 UPGRADE S  AIT)hieutv
            'Call Sql_Error_Msg("SAIMOKU_MAST SELECT")
            Call Sql_Error_Msg(ex, "SAIMOKU_MAST SELECT")
            '2021.08.05 UPGRADE E

        End Try     '2021.07.26 UPGRADE ADD AIT)Tool Convert
    End Function

    '-------------------------------------------------------------------------------
    '   ����    :   ������񌟍��f�[�^�̎擾
    '   �֐�    :   Function GetChumonMast()
    '   ����    :   DT()    DspList
    '   �ߒl    :   Cnt     ���o����
    '   �@�@        -1      �ُ�I��
    '   �@�\    :   �����ɊY������R�[�h�^���̂̎擾���s���B
    '-------------------------------------------------------------------------------
    Private Function GetChumonMast(ByRef DT() As DspList) As Integer

        Dim SQL As String
        '2021.08.05 UPGRADE S  AIT)hieutv
        'Dim Rs As ADODB.Recordset
        Dim Rs As New DataTable
        '2021.08.05 UPGRADE E
        Dim OpenFlg As Short
        Dim Cnt As Integer
        Dim Jouken As String
        Dim wkMei As String
        Dim wkCD1 As String
        Dim wkCD2 As String

        '2021.07.26 UPGRADE S  AIT)Tool Convert
        'On Error GoTo GetChumonMast_Err
        Try
            '2021.07.26 UPGRADE E

            '�߂�l�̏�����
            GetChumonMast = -1

            '----- �ϐ��̏�����
            wkMei = ""
            wkCD1 = ""
            wkCD2 = ""

            '----- ���o���̎擾
            wkMei = Trim(imText1(0).Text)
            wkCD1 = Trim(imText1(1).Text)
            wkCD2 = Trim(imText1(2).Text)

            '----- WHERE���̑g�ݗ���
            Jouken = ""
            If Trim(ZENTEI) <> "" Then
                Jouken = "(" & ZENTEI & ")"
            End If
            If wkCD1 <> "" Or wkCD2 <> "" Then
                If Jouken <> "" Then Jouken = Jouken & " AND "
                If wkCD1 = wkCD2 Then
                    Jouken = Jouken & "CHUUMON_NO = '" & wkCD1 & "'"
                ElseIf wkCD1 <> "" And wkCD2 = "" Then
                    Jouken = Jouken & "CHUUMON_NO >= '" & wkCD1 & "'"
                ElseIf wkCD2 <> "" And wkCD1 = "" Then
                    Jouken = Jouken & "CHUUMON_NO <= '" & wkCD2 & "'"
                Else
                    Jouken = Jouken & "CHUUMON_NO BETWEEN '" & wkCD1 & "' AND '" & wkCD2 & "'"
                End If
            End If
            If wkMei <> "" Then
                If Jouken <> "" Then Jouken = Jouken & " AND "
                Jouken = Jouken & "MEISYOU Like '%" & wkMei & "%'"
            End If

            '----- SQL/SELECT���̑g�ݗ���
            SQL = "SELECT"
            SQL = SQL & " CHUUMON_NO AS F01,"
            SQL = SQL & " MEISYOU    AS F02,"
            SQL = SQL & " HARAI_KB   AS F03"
            SQL = SQL & " FROM CHUUMON_MAST"
            If Jouken <> "" Then
                SQL = SQL & " WHERE " & Jouken
            End If
            SQL = SQL & " ORDER BY CHUUMON_NO"

            '----- SQL�����s
            '2021.08.05 UPGRADE S  AIT)hieutv
            'Rs = SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText)
            Rs = RsOpen(SQL)
            '2021.08.05 UPGRADE E
            OpenFlg = 1

            Cnt = 0
            '2021.08.05 UPGRADE S  AIT)hieutv
            'Do Until Rs.EOF
            '    ReDim Preserve DT(Cnt)
            '    DT(Cnt).Code = RsNull(Rs, "F01")
            '    DT(Cnt).Name_Renamed = RsNull(Rs, "F02")
            '    DT(Cnt).Yobi = RsNull(Rs, "F03")
            '    Cnt = Cnt + 1
            '    Rs.MoveNext()
            'Loop

            'Rs.Close()
            For Each Row As DataRow In Rs.Rows
                ReDim Preserve DT(Cnt)
                DT(Cnt).Code = RsNull(Row, "F01")
                DT(Cnt).Name_Renamed = RsNull(Row, "F02")
                DT(Cnt).Yobi = RsNull(Row, "F03")
                Cnt = Cnt + 1
            Next

            Rs.Dispose()
            '2021.08.05 UPGRADE E
            Rs = Nothing

            '�߂�l�Ɍ������Z�b�g
            GetChumonMast = Cnt

            Exit Function

            '2021.07.26 UPGRADE S  AIT)Tool Convert
            'GetChumonMast_Err:
        Catch ex As Exception
            '2021.07.26 UPGRADE E

            If OpenFlg = 1 Then
                '2021.08.05 UPGRADE S  AIT)hieutv
                'Rs.Close()
                Rs.Dispose()
                '2021.08.05 UPGRADE E
            End If
            Rs = Nothing

            '2021.08.05 UPGRADE S  AIT)hieutv
            'Call Sql_Error_Msg("CHUUMON_MAST SELECT")
            Call Sql_Error_Msg(ex, "CHUUMON_MAST SELECT")
            '2021.08.05 UPGRADE E

        End Try     '2021.07.26 UPGRADE ADD AIT)Tool Convert
    End Function

    '-------------------------------------------------------------------------------
    '   ����    :   ���o��񌟍��f�[�^�̎擾
    '   �֐�    :   Function GetWaridasiMast()
    '   ����    :   DT()    DspList
    '   �ߒl    :   Cnt     ���o����
    '   �@�@        -1      �ُ�I��
    '   �@�\    :   �����ɊY������R�[�h�^���̂̎擾���s���B
    '-------------------------------------------------------------------------------
    Private Function GetWaridasiMast(ByRef DT() As DspList) As Integer

        Dim SQL As String
        '2021.08.05 UPGRADE S  AIT)hieutv
        'Dim Rs As ADODB.Recordset
        Dim Rs As New DataTable
        '2021.08.05 UPGRADE E
        Dim OpenFlg As Short
        Dim Cnt As Integer
        Dim Jouken As String
        Dim wkMei As String
        Dim wkCD1 As String
        Dim wkCD2 As String

        '2021.07.26 UPGRADE S  AIT)Tool Convert
        'On Error GoTo GetWaridasiMast_Err
        Try
            '2021.07.26 UPGRADE E

            '�߂�l�̏�����
            GetWaridasiMast = -1

            '----- �ϐ��̏�����
            wkMei = ""
            wkCD1 = ""
            wkCD2 = ""

            '----- ���o���̎擾
            wkMei = Trim(imText1(0).Text)
            wkCD1 = Trim(imText1(1).Text)
            wkCD2 = Trim(imText1(2).Text)

            '----- WHERE���̑g�ݗ���
            Jouken = ""
            If Trim(ZENTEI) <> "" Then
                Jouken = "(" & ZENTEI & ")"
            End If
            If wkCD1 <> "" Or wkCD2 <> "" Then
                If Jouken <> "" Then Jouken = Jouken & " AND "
                If wkCD1 = wkCD2 Then
                    Jouken = Jouken & "WARIDASI_NO = '" & wkCD1 & "'"
                ElseIf wkCD1 <> "" And wkCD2 = "" Then
                    Jouken = Jouken & "WARIDASI_NO >= '" & wkCD1 & "'"
                ElseIf wkCD2 <> "" And wkCD1 = "" Then
                    Jouken = Jouken & "WARIDASI_NO <= '" & wkCD2 & "'"
                Else
                    Jouken = Jouken & "WARIDASI_NO BETWEEN '" & wkCD1 & "' AND '" & wkCD2 & "'"
                End If
            End If
            If wkMei <> "" Then
                If Jouken <> "" Then Jouken = Jouken & " AND "
                Jouken = Jouken & "MEISYOU Like '%" & wkMei & "%'"
            End If

            '----- SQL/SELECT���̑g�ݗ���
            SQL = "SELECT"
            SQL = SQL & " WARIDASI_NO AS F01,"
            SQL = SQL & " MEISYOU     AS F02,"
            SQL = SQL & " CHOKUEI_KB  AS F03"
            SQL = SQL & " FROM WARIDASI_MAST"
            If Jouken <> "" Then
                SQL = SQL & " WHERE " & Jouken
            End If
            SQL = SQL & " ORDER BY WARIDASI_NO"

            '----- SQL�����s
            '2021.08.05 UPGRADE S  AIT)hieutv
            'Rs = SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText)
            Rs = RsOpen(SQL)
            '2021.08.05 UPGRADE E
            OpenFlg = 1

            Cnt = 0
            '2021.08.05 UPGRADE S  AIT)hieutv
            'Do Until Rs.EOF
            '    ReDim Preserve DT(Cnt)
            '    DT(Cnt).Code = RsNull(Rs, "F01")
            '    DT(Cnt).Name_Renamed = RsNull(Rs, "F02")
            '    DT(Cnt).Yobi = RsNull(Rs, "F03")
            '    Cnt = Cnt + 1
            '    Rs.MoveNext()
            'Loop

            'Rs.Close()
            For Each Row As DataRow In Rs.Rows
                ReDim Preserve DT(Cnt)
                DT(Cnt).Code = RsNull(Row, "F01")
                DT(Cnt).Name_Renamed = RsNull(Row, "F02")
                DT(Cnt).Yobi = RsNull(Row, "F03")
                Cnt = Cnt + 1
            Next

            Rs.Dispose()
            '2021.08.05 UPGRADE E
            Rs = Nothing

            '�߂�l�Ɍ������Z�b�g
            GetWaridasiMast = Cnt

            Exit Function

            '2021.07.26 UPGRADE S  AIT)Tool Convert
            'GetWaridasiMast_Err:
        Catch ex As Exception
            '2021.07.26 UPGRADE E

            If OpenFlg = 1 Then
                '2021.08.05 UPGRADE S  AIT)hieutv
                'Rs.Close()
                Rs.Dispose()
                '2021.08.05 UPGRADE E
            End If
            Rs = Nothing

            '2021.08.05 UPGRADE S  AIT)hieutv
            'Call Sql_Error_Msg("WARIDASI_MAST SELECT")
            Call Sql_Error_Msg(ex, "WARIDASI_MAST SELECT")
            '2021.08.05 UPGRADE E

        End Try     '2021.07.26 UPGRADE ADD AIT)Tool Convert
    End Function

    '-------------------------------------------------------------------------------
    '   ����    :   �H�������f�[�^�̎擾
    '   �֐�    :   Function GetKoujiMast2()
    '   ����    :   DT()    DspList
    '   �ߒl    :   Cnt     ���o����
    '   �@�@        -1      �ُ�I��
    '   �@�\    :   �����ɊY������R�[�h�^���̂̎擾���s���B
    '-------------------------------------------------------------------------------
    Private Function GetKoujiMast2(ByRef DT() As DspList) As Integer

        Dim SQL As String
        '2021.08.05 UPGRADE S  AIT)hieutv
        'Dim Rs As ADODB.Recordset
        Dim Rs As New DataTable
        '2021.08.05 UPGRADE E
        Dim OpenFlg As Short
        Dim Cnt As Integer
        Dim Jouken As String
        Dim wkMei As String
        Dim wkCD1 As String
        Dim wkCD2 As String

        '2021.07.26 UPGRADE S  AIT)Tool Convert
        'On Error GoTo GetKoujiMast2_Err
        Try
            '2021.07.26 UPGRADE E

            '�߂�l�̏�����
            GetKoujiMast2 = -1

            '----- �ϐ��̏�����
            wkMei = ""
            wkCD1 = ""
            wkCD2 = ""

            '----- ���o���̎擾
            wkMei = Trim(imText1(0).Text)
            wkCD1 = Trim(imText1(1).Text)
            wkCD2 = Trim(imText1(2).Text)

            '----- WHERE���̑g�ݗ���
            Jouken = ""
            If Trim(ZENTEI) <> "" Then
                Jouken = "(" & ZENTEI & ")"
            End If
            If wkCD1 <> "" Or wkCD2 <> "" Then
                If Jouken <> "" Then Jouken = Jouken & " AND "
                If wkCD1 = wkCD2 Then
                    Jouken = Jouken & "KOUJI_NO = '" & wkCD1 & "'"
                ElseIf wkCD1 <> "" And wkCD2 = "" Then
                    Jouken = Jouken & "KOUJI_NO >= '" & wkCD1 & "'"
                ElseIf wkCD2 <> "" And wkCD1 = "" Then
                    Jouken = Jouken & "KOUJI_NO <= '" & wkCD2 & "'"
                Else
                    Jouken = Jouken & "KOUJI_NO BETWEEN '" & wkCD1 & "' AND '" & wkCD2 & "'"
                End If
            End If
            If wkMei <> "" Then
                If Jouken <> "" Then Jouken = Jouken & " AND "
                Jouken = Jouken & "MEISYOU Like '%" & wkMei & "%'"
            End If

            '----- SQL/SELECT���̑g�ݗ���
            SQL = "SELECT"
            SQL = SQL & " KOUJI_NO        AS F01,"
            SQL = SQL & " MIN(MEISYOU)    AS F02,"
            SQL = SQL & " MIN(GYOUSYU_KB) AS F03"
            SQL = SQL & " FROM KOUJI_NO_MAST"
            If Jouken <> "" Then
                SQL = SQL & " WHERE " & Jouken
            End If
            SQL = SQL & " GROUP BY KOUJI_NO"
            SQL = SQL & " ORDER BY KOUJI_NO"

            '----- SQL�����s
            '2021.08.05 UPGRADE S  AIT)hieutv
            'Rs = SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText)
            Rs = RsOpen(SQL)
            '2021.08.05 UPGRADE E
            OpenFlg = 1

            Cnt = 0
            '2021.08.05 UPGRADE S  AIT)hieutv
            'Do Until Rs.EOF
            '    ReDim Preserve DT(Cnt)
            '    DT(Cnt).Code = RsNull(Rs, "F01")
            '    DT(Cnt).Yobi = RsNull(Rs, "F03")
            '    Select Case DT(Cnt).Yobi
            '        Case "03" : DT(Cnt).Name_Renamed = "���j���[�A��"
            '        Case "04" : DT(Cnt).Name_Renamed = "�����x�X"
            '        Case Else
            '            DT(Cnt).Name_Renamed = RsNull(Rs, "F02")
            '    End Select
            '    Cnt = Cnt + 1
            '    Rs.MoveNext()
            'Loop

            'Rs.Close()
            For Each Row As DataRow In Rs.Rows
                ReDim Preserve DT(Cnt)
                DT(Cnt).Code = RsNull(Row, "F01")
                DT(Cnt).Yobi = RsNull(Row, "F03")
                Select Case DT(Cnt).Yobi
                    Case "03" : DT(Cnt).Name_Renamed = "���j���[�A��"
                    Case "04" : DT(Cnt).Name_Renamed = "�����x�X"
                    Case Else
                        DT(Cnt).Name_Renamed = RsNull(Row, "F02")
                End Select
                Cnt = Cnt + 1
            Next

            Rs.Dispose()
            '2021.08.05 UPGRADE E
            Rs = Nothing

            '�߂�l�Ɍ������Z�b�g
            GetKoujiMast2 = Cnt

            Exit Function

            '2021.07.26 UPGRADE S  AIT)Tool Convert
            'GetKoujiMast2_Err:
        Catch ex As Exception
            '2021.07.26 UPGRADE E

            If OpenFlg = 1 Then
                '2021.08.05 UPGRADE S  AIT)hieutv
                'Rs.Close()
                Rs.Dispose()
                '2021.08.05 UPGRADE E
            End If
            Rs = Nothing

            '2021.08.05 UPGRADE S  AIT)hieutv
            'Call Sql_Error_Msg("KOUJI_NO_MAST SELECT")
            Call Sql_Error_Msg(ex, "KOUJI_NO_MAST SELECT")
            '2021.08.05 UPGRADE E

        End Try     '2021.07.26 UPGRADE ADD AIT)Tool Convert
    End Function

    '2021.08.05 UPGRADE S  AIT)hieutv
    'Private Sub cmdKey_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Click
    '    Dim Index As Short = cmdKey.GetIndex(eventSender)    
    Private Sub cmdKey_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _cmdKey_1.Click, _cmdKey_5.Click, _cmdKey_12.Click
        Dim Index As Short = cmdKey.IndexOf(eventSender)
    '2021.08.05 UPGRADE E

        Select Case Index
            Case 1 '----- ����
                Call GetData()
                ZENTEI = ""
                '2021.08.11 UPGRADE S  AIT)dannnl
                'Me.Close()
                Me.Dispose()
                '2021.08.11 UPGRADE E

            Case 5 '----- ����
                Call HaniCheck("1", imText1(1), imText1(1), imText1(2), imText1(2))
                System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
                If FormFirstSet() = False Then
                    If imText1(0).Visible = True Then
                        imText1(0).Focus()
                    End If
                End If
                System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default

            Case 12 '----- �I��
                ZENTEI = ""
                GetCD = ""
                GetNM = ""
                GetYB = ""
                '2021.08.11 UPGRADE S  AIT)dannnl
                'Me.Close()
                Me.Dispose()
                '2021.08.11 UPGRADE E
        End Select

    End Sub

    '2021.08.05 UPGRADE S  AIT)hieutv
    'Private Sub cmdKey_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Enter
    '    Dim Index As Short = cmdKey.GetIndex(eventSender)
    '    Call GotFocus(cmdKey(Index), StatusBar1)
    'End Sub

    'Private Sub cmdKey_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Leave
    '    Dim Index As Short = cmdKey.GetIndex(eventSender)
    '    Call LostFocus(cmdKey(Index), StatusBar1)
    'End Sub 
    Private Sub cmdKey_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _cmdKey_1.Enter, _cmdKey_5.Enter, _cmdKey_12.Enter
        Dim Index As Short = cmdKey.IndexOf(eventSender)
        Call MtyTool.GotFocus(cmdKey(Index), StatusBar1)
    End Sub

    Private Sub cmdKey_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _cmdKey_1.Leave, _cmdKey_5.Leave, _cmdKey_12.Leave
        Dim Index As Short = cmdKey.IndexOf(eventSender)
        Call MtyTool.LostFocus(cmdKey(Index), StatusBar1)
    End Sub
    '2021.08.05 UPGRADE E

    Private Sub frmSearch_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown
        Dim KeyCode As Short = eventArgs.KeyCode
        Dim Shift As Short = eventArgs.KeyData \ &H10000
        Select Case KeyCode
            Case System.Windows.Forms.Keys.F1 '----- ����
                If cmdKey(1).Enabled = True Then cmdKey(1).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(1), New System.EventArgs())
            Case System.Windows.Forms.Keys.F5 '----- ����
                If cmdKey(5).Enabled = True Then cmdKey(5).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(5), New System.EventArgs())
            Case System.Windows.Forms.Keys.F12 '----- �I��
                If cmdKey(12).Enabled = True Then cmdKey(12).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(12), New System.EventArgs())
        End Select
    End Sub

    Private Sub frmSearch_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
        Call FormDisp(Me)
        GetCD = ""
        GetNM = ""
        GetYB = ""
        Call DispFirstSet()
        Call cmdKey_Click(cmdKey.Item(5), New System.EventArgs())
    End Sub

    Private Sub frmSearch_FormClosing(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Dim Cancel As Boolean = eventArgs.Cancel
        Dim UnloadMode As System.Windows.Forms.CloseReason = eventArgs.CloseReason
        If UnloadMode = System.Windows.Forms.CloseReason.UserClosing Then
            '----- �I������
            Call cmdKey_Click(cmdKey.Item(12), New System.EventArgs())
        End If
        eventArgs.Cancel = Cancel
    End Sub

    '2021.08.05 UPGRADE S  AIT)hieutv
    'Private Sub imText1_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles imText1.Enter
    '    Dim Index As Short = imText1.GetIndex(eventSender)
    '    Call GotFocus(imText1(Index), StatusBar1)
    'End Sub
    Private Sub imText1_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _imText1_0.Enter, _imText1_1.Enter, _imText1_2.Enter
        Dim Index As Short = imText1.IndexOf(eventSender)
        Call MtyTool.GotFocus(imText1(Index), StatusBar1)
    End Sub
    '2021.08.05 UPGRADE E

    '2021.08.05 UPGRADE S  AIT)hieutv
    'Private Sub imText1_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles imText1.KeyDown
    Private Sub imText1_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles _imText1_0.KeyDown, _imText1_1.KeyDown, _imText1_2.KeyDown
    '2021.08.05 UPGRADE E
        Dim KeyCode As Short = eventArgs.KeyCode
        Dim Shift As Short = eventArgs.KeyData \ &H10000
        '2021.08.05 UPGRADE S  AIT)hieutv
        'Dim Index As Short = imText1.GetIndex(eventSender)
        Dim Index As Short = imText1.IndexOf(eventSender)
        '2021.08.05 UPGRADE E
        If KeyCode = System.Windows.Forms.Keys.Return Then
            Select Case Index
                Case 0, 1
                    imText1(Index + 1).Focus()
                Case 2
                    cmdKey(5).Focus()
            End Select
        End If
    End Sub

    '2021.08.05 UPGRADE S  AIT)hieutv
    'Private Sub imText1_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles imText1.Leave
    '    Dim Index As Short = imText1.GetIndex(eventSender)

    '    Dim Fmt As String

    '    Call LostFocus(imText1(Index), StatusBar1)    
    Private Sub imText1_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _imText1_0.Leave, _imText1_1.Leave, _imText1_2.Leave
        Dim Index As Short = imText1.IndexOf(eventSender)

        Dim Fmt As String

        Call MtyTool.LostFocus(imText1(Index), StatusBar1)
    '2021.08.05 UPGRADE E

        '----- �R�[�h���͂̏ꍇ
        If Index <> 0 Then
            If Trim(imText1(Index).Text) <> "" Then
                If imText1(1).Format = "9" And Not (MastNo = 5 Or MastNo = 8 Or MastNo = 9) Then
                    Fmt = New String("0", imText1(Index).MaxLength)
                    '2021.08.05 UPGRADE S  AIT)hieutv
                    'imText1(Index).Text = VB6.Format(Val(imText1(Index).Text), Fmt)
                    imText1(Index).Text = CDec(Val(imText1(Index).Text)).ToString(Fmt)
                    '2021.08.05 UPGRADE E
                End If
            End If
        End If

    End Sub

    '2021.08.05 UPGRADE S  AIT)hieutv
    'Private Sub vaSpread1_ClickEvent(ByVal eventSender As System.Object, ByVal eventArgs As AxFPSpread._DSpreadEvents_ClickEvent) Handles vaSpread1.ClickEvent
    Private Sub vaSpread1_ClickEvent(ByVal eventSender As System.Object, ByVal eventArgs As FarPoint.Win.Spread.CellClickEventArgs) Handles FpSpread1.CellClick
        '2021.08.05 UPGRADE E
        If eventArgs.ColumnHeader = True Then
            '2021.08.05 UPGRADE S  AIT)hieutv
            'If vaSpread1.get_SortKey(1) = eventArgs.Col Then
            '    SortMode(eventArgs.Col - 1) = Not SortMode(eventArgs.Col - 1)
            'Else
            '    SortMode(eventArgs.Col - 1) = -1
            'End If
            'With vaSpread1
            '    .eventArgs.Col = 1
            '    .eventArgs.Row = 1
            '    .Col2 = .MaxCols
            '    .Row2 = .MaxRows
            '    .SortBy = FPSpread.SortByConstants.SortByRow
            '    .set_SortKey(1, eventArgs.Col)
            '    .set_SortKeyOrder(1, SortMode(eventArgs.Col - 1) + 2)
            '    .Action = FPSpread.ActionConstants.ActionSort
            'End With           
            With FpSpread1
                Dim sort(eventArgs.Column) As FarPoint.Win.Spread.SortInfo
                If eventArgs.Column <> selectHeader Then
                    SortMode(eventArgs.Column) = 0
                End If
                selectHeader = eventArgs.Column
                If SortMode(eventArgs.Column) = -1 Then
                    sort(0) = New FarPoint.Win.Spread.SortInfo(eventArgs.Column, False, System.Collections.Comparer.Default)
                    SortMode(eventArgs.Column) = 0
                Else
                    sort(0) = New FarPoint.Win.Spread.SortInfo(eventArgs.Column, True, System.Collections.Comparer.Default)
                    SortMode(eventArgs.Column) = -1
                End If
                .ActiveSheet.SortRange(0, 0, .ActiveSheet.RowCount, .ActiveSheet.ColumnCount, True, sort)
            End With
            '2021.08.05 UPGRADE E
        End If
    End Sub

    '2021.08.05 UPGRADE S  AIT)hieutv
    'Private Sub vaSpread1_DblClick(ByVal eventSender As System.Object, ByVal eventArgs As AxFPSpread._DSpreadEvents_DblClickEvent) Handles vaSpread1.DblClick
    Private Sub vaSpread1_DblClick(ByVal eventSender As System.Object, ByVal eventArgs As FarPoint.Win.Spread.CellClickEventArgs) Handles FpSpread1.CellDoubleClick
        'If eventArgs.Col > 0 And eventArgs.Row > 0 Then
        '2021.08.05 UPGRADE E
        If eventArgs.Column >= 0 And eventArgs.Row >= 0 AndAlso eventArgs.ColumnHeader = False And eventArgs.RowHeader = False Then
            Call frmSearch_KeyDown(Me, New System.Windows.Forms.KeyEventArgs(System.Windows.Forms.Keys.F1 Or 0 * &H10000))
        End If
    End Sub

    '2021.08.05 UPGRADE S  AIT)hieutv
    'Private Sub vaSpread1_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles vaSpread1.Enter
    '    Call GotFocus(vaSpread1, StatusBar1)
    'End Sub
    Private Sub vaSpread1_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles FpSpread1.Enter
        Call MtyTool.GotFocus(FpSpread1, StatusBar1)
    End Sub
    '2021.08.05 UPGRADE E

    '2021.08.05 UPGRADE S  AIT)hieutv
    'Private Sub vaSpread1_KeyDownEvent(ByVal eventSender As System.Object, ByVal eventArgs As AxFPSpread._DSpreadEvents_KeyDownEvent) Handles vaSpread1.KeyDownEvent
    Private Sub vaSpread1_KeyDownEvent(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles FpSpread1.KeyDown
    '2021.08.05 UPGRADE E
        If eventArgs.KeyCode = System.Windows.Forms.Keys.Return Then
            '2021.08.05 UPGRADE S  AIT)hieutv
            'If vaSpread1.ActiveRow > 0 Then
            If FpSpread1.ActiveSheet.ActiveRowIndex >= 0 Then
            '2021.08.05 UPGRADE E
                Call frmSearch_KeyDown(Me, New System.Windows.Forms.KeyEventArgs(System.Windows.Forms.Keys.F1 Or 0 * &H10000))
            End If
        End If
    End Sub

    '2021.08.11 UPGRADE S  AIT)dannnl
    'Private Sub vaSpread1_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles vaSpread1.Leave
    '    Call LostFocus(vaSpread1, StatusBar1)
    'End Sub
    Private Sub vaSpread1_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles FpSpread1.Leave
        Call MtyTool.LostFocus(FpSpread1, StatusBar1)
    End Sub
    '2021.08.11 UPGRADE E
End Class
