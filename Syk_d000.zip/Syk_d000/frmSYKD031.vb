Option Strict Off
Option Explicit On
Friend Class frmSYKD031
	Inherits System.Windows.Forms.Form
	'=============================================================
	' ���[�U�[���@  �F  �R�z�H�Ɗ������
	' �V�X�e�����@  �F  �H���Ǘ��V�X�e��
	' ���W���[����  �F  ���c��O�����o����
	' ���W���[��ID�@�F  frmSYKD031.frm
	' �쐬���@ �@�@ �F  ���� 13 �N 06 �� 19 ��
	' �X�V���@�@  �@�F  ����    �N    ��    ��
	'=============================================================
	'

	Private UpMode As String
	Private PreDT As WARIDASI_DATA_DBT
	Private StopFlg As Short '�����I���t���O
	Private InpRow As Integer '�C���s�ԍ�
	Private PreVal As Decimal
	'

	'-------------------------------------------------------------------------------
	'   ����    :   �C���f�[�^�̎擾
	'   �֐�    :   Function SprdDataGet(DT)
	'   ����    :   DT      WARIDASI_DATA_DBT
	'   �ߒl    :   True    ����I��
	'   �@�@    :   False   �ُ�I��
	'   �@�\    :   �C���f�[�^���X�v���b�h����擾���܂��B
	'-------------------------------------------------------------------------------
	Private Function SprdDataGet(ByRef DT As WARIDASI_DATA_DBT) As Boolean

		'2021.08.09 DELETE S  AIT)Hoangtx
		'Dim ssText As Object
		'2021.08.09 DELETE E
		Dim Jouken As String
		Dim Order As String
		Dim Cnt As Integer
		Dim WK() As WARIDASI_DATA_DBT
		Dim Bango As Double

		' �߂�l�̏�����
		SprdDataGet = True

		' �f�[�^�̈�̏�����
		Call CLEAR_WARIDASI_DATA(DT)
		With DT
			.KOUJI_NO = KeyKouji.KOUJI_NO '�H���ԍ�
			.EDA_NO = KeyKouji.EDA_NO '�H���}��
			.KOUSYU_CD = Mid(frmSYKD030.KousyuID, 1, 1) '�H������
			.KOUSYU_NO = Mid(frmSYKD030.KousyuID, 3, 2) '�H��ԍ�
			.MEISAI_NO = frmSYKD030.MeisaiNO '���הԍ�
			.KISO_FLG = "0" '��b�t���O
			.WARIDASI_KB = "0" '���o�敪
		End With

		With frmSYKD030
			' �ǉ��̏ꍇ
			'2021.08.09 UPGRADE S  AIT)Hoangtx
			'If .vaSpread1.Row = -1 And .MeisaiNO = 0 Then
			If .FpSpread1.ActiveSheet.SelectionCount = 0 AndAlso .MeisaiNO = 0 Then
				.FpSpread1.ActiveSheet.AddSelection(.FpSpread1.ActiveSheet.ActiveRowIndex, .FpSpread1.ActiveSheet.ActiveColumnIndex, 1, .FpSpread1.ActiveSheet.ColumnCount)
				'2021.08.09 UPGRADE E
				lblTitle.Text = " �ǉ�"
				UpMode = "0"
				'----- ���הԍ��̐ݒ�
				Bango = GetMaxMeisai(DT.KOUSYU_CD, DT.KOUSYU_NO)
				DT.MEISAI_NO = Bango + 1.0#
				Exit Function
			End If
			' �}���̏ꍇ
			'2021.08.09 UPGRADE S  AIT)Hoangtx
			'If .vaSpread1.Row = -1 And .MeisaiNO > 0 Then
			If .FpSpread1.ActiveSheet.SelectionCount = 0 AndAlso .MeisaiNO > 0 Then
				.FpSpread1.ActiveSheet.AddSelection(.FpSpread1.ActiveSheet.ActiveRowIndex, .FpSpread1.ActiveSheet.ActiveColumnIndex, 1, .FpSpread1.ActiveSheet.ColumnCount)
				'2021.08.09 UPGRADE E
				lblTitle.Text = " �}��"
				UpMode = "2"
				Exit Function
			End If
		End With

		' �C���̏ꍇ
		lblTitle.Text = " �C��"
		UpMode = "1"
		If INPMODE <> "2" Then
			lblTitle.Text = " �ڍ�"
		End If

		' ���o�����̎擾
		With DT
			Jouken = "MEISAI_NO = " & .MEISAI_NO
			Jouken = Jouken & " AND KOUSYU_NO = '" & .KOUSYU_NO & "'"
			Jouken = Jouken & " AND KOUSYU_CD = '" & .KOUSYU_CD & "'"
			Jouken = Jouken & " AND EDA_NO = '" & .EDA_NO & "'"
			Jouken = Jouken & " AND KOUJI_NO = '" & .KOUJI_NO & "'"
		End With

		' �f�[�^�̎擾
		Order = ""
		Cnt = SELECT_WARIDASI_DATA(Jouken, Order, WK)
		If Cnt <= 0 Then
			SprdDataGet = False
			Exit Function
		End If
		DT = WK(0)

	End Function

	'-------------------------------------------------------------------------------
	'   ����    :   �f�[�^�̃N���A
	'   �֐�    :   Sub DispClear()
	'   ����    :   �Ȃ�
	'   �@�\    :   �f�[�^���N���A���܂��B
	'-------------------------------------------------------------------------------
	Private Sub DispClear(Optional ByRef Mode As Short = 0)

		If Mode = 0 Then
			imText3(0).Text = "" '�H���ԍ�
			imText3(1).Text = "" '�H���}��
			imText3(2).Text = "" '�H������
			imText3(3).Text = "" '�H������
			imText3(4).Text = "" '�H�햼��
		End If

		imText4(0).Text = "" '���הԍ�
		imText4(1).Text = "0" '��b�t���O
		imText4(5).Text = "0" '���o�敪
		'----- 2004/03/16 �C�� ----------------------------------
		'imText4(2).Text = "0"          '���ʁi�ώZ�����j
		'imText4(3).Text = "0"          '�P���i�ώZ�����j
		'imText4(4).Text = "0"          '���z�i�ώZ�����j
		imNumber3(0).Value = "0" '���ʁi�ώZ�����j
		imNumber3(1).Value = "0" '�P���i�ώZ�����j
		imNumber3(2).Value = "0" '���z�i�ώZ�����j
		'--------------------------------------------------------

		imText1(0).Text = "" '����
		imText1(3).Text = "" '�P��
		imNumber1(0).Value = "0" '���ʁi���s�\�Z�j
		imNumber1(1).Value = "0" '�P���i���s�\�Z�j
		imNumber1(2).Value = "0" '���z�i���s�\�Z�j
		imNumber2(0).Value = "0" '���ʁi���c�O���j
		imNumber2(1).Value = "0" '�P���i���c�O���j
		imNumber2(2).Value = "0" '���z�i���c�O���j
		imText1(5).Text = "" '���o�ԍ�
		imText2(5).Text = ""
		imText2(6).Text = ""

		'----- �Q�ƃ��[�h
		If INPMODE <> "2" Then
			cmdKey(1).Visible = False

			'2021.08.18 UPGRADE S  AIT)Hoangtx
			'Picture2.Enabled = False
			Dim i As Int16
			For i = 0 To 2
				imNumber1(i).Enabled = False
				imNumber2(i).Enabled = False
				imNumber3(i).Enabled = False
			Next
			imText1(0).enabled = False
			imText1(3).enabled = False
			imText1(5).enabled = False

			imText2(5).enabled = False
			imText2(6).enabled = False

			_imText4_0.Enabled = False
			_imText4_1.Enabled = False
			_imText4_5.Enabled = False

			_cmdLook_5.Enabled = False
			'2021.08.18 UPGRADE E
		End If

	End Sub

	'-------------------------------------------------------------------------------
	'   ����    :   �f�[�^�̕\��
	'   �֐�    :   Sub DispDataSet()
	'   ����    :   DT  WARIDASI_DATA_DBT
	'   �@�\    :   �f�[�^��\�����܂��B
	'-------------------------------------------------------------------------------
	Private Sub DispDataSet(ByRef DT As WARIDASI_DATA_DBT)

		With KeyKouji
			imText3(0).Text = Trim(.KOUJI_NO) '�H���ԍ�
			If Trim(.EDA_NO) <> "0000" Then
				imText3(1).Text = Trim(.EDA_NO) '�H���}��
			End If
			imText3(2).Text = Trim(.MEISYOU) '�H������
		End With
		With frmSYKD030
			imText3(3).Text = .imMask1(0).Text '�H������
			imText3(4).Text = .imText1(0).Text '�H�햼��
		End With
		With DT
			'2021.08.09 UPGRADE S  AIT)Hoangtx
			'imText4(0).Text = VB6.Format(.MEISAI_NO) '���הԍ�
			imText4(0).Text = .MEISAI_NO.ToString '���הԍ�
			imText4(1).Text = Trim(.KISO_FLG) '��b�t���O
			'----- 2004/03/16 �C�� -----------------------------------------------------------
			'imText4(2).Text = Format$(.S_SUURYOU, "#,##0.00")          '���ʁi�ώZ�����j
			'imText4(3).Text = Format$(.S_TANKA, "#,##0")               '�P���i�ώZ�����j
			'imText4(4).Text = Format$(.S_KINGAKU, "#,##0")             '���z�i�ώZ�����j
			'imNumber3(0).Value = VB6.Format(.S_SUURYOU) '���ʁi�ώZ�����j
			imNumber3(0).Value = (.S_SUURYOU).ToString '���ʁi�ώZ�����j
			'imNumber3(1).Value = VB6.Format(.S_TANKA) '�P���i�ώZ�����j
			imNumber3(1).Value = (.S_TANKA).ToString '�P���i�ώZ�����j
			'imNumber3(2).Value = VB6.Format(.S_KINGAKU) '���z�i�ώZ�����j
			imNumber3(2).Value = .S_KINGAKU.ToString '���z�i�ώZ�����j
			'---------------------------------------------------------------------------------
			imText4(5).Text = Trim(.WARIDASI_KB) '���o�敪
			imText1(0).Text = Trim(.MEISYOU) '����
			imText1(3).Text = Trim(.TANI) '�P��
			'imNumber1(0).Value = VB6.Format(.J_SUURYOU) '���ʁi���s�\�Z�j
			imNumber1(0).Value = (.J_SUURYOU).ToString '���ʁi���s�\�Z�j
			'imNumber1(1).Value = VB6.Format(.J_TANKA) '�P���i���s�\�Z�j
			imNumber1(1).Value = (.J_TANKA).ToString '�P���i���s�\�Z�j
			'imNumber1(2).Value = VB6.Format(.J_KINGAKU) '���z�i���s�\�Z�j
			imNumber1(2).Value = (.J_KINGAKU).ToString '���z�i���s�\�Z�j
			Select Case .WARIDASI_KB
				Case "1" '----- ���c
					'imNumber2(0).Value = VB6.Format(.T_SUURYOU) '����
					imNumber2(0).Value = (.T_SUURYOU).ToString '����
					'imNumber2(1).Value = VB6.Format(.T_TANKA) '�P��
					imNumber2(1).Value = .T_TANKA.ToString '�P��
					'imNumber2(2).Value = VB6.Format(.T_KINGAKU) '���z
					imNumber2(2).Value = .T_KINGAKU.ToString '���z
				Case "2" '----- �O��
					'imNumber2(0).Value = VB6.Format(.G_SUURYOU) '����
					imNumber2(0).Value = .G_SUURYOU.ToString '����
					'imNumber2(1).Value = VB6.Format(.G_TANKA) '�P��
					imNumber2(1).Value = .G_TANKA.ToString '�P��
					'imNumber2(2).Value = VB6.Format(.G_KINGAKU) '���z
					imNumber2(2).Value = .G_KINGAKU.ToString '���z

			End Select
			'2021.08.09 UPGRADE E
			imText1(5).Text = Trim(.WARIDASI_NO) '���o�ԍ�
			imText2(5).Text = GetNameWaridasi(.KOUJI_NO, .EDA_NO, Trim(imText1(5).Text))
			imText2(6).Text = GetNameChokuei(Trim(imText4(5).Text))
		End With

	End Sub

	'-------------------------------------------------------------------------------
	'   ����    :   �f�[�^�̎擾
	'   �֐�    :   Sub DispDataGet()
	'   ����    :   DT   WARIDASI_DATA_DBT
	'   �@�\    :   �f�[�^���擾���܂��B
	'-------------------------------------------------------------------------------
	Private Sub DispDataGet(ByRef DT As WARIDASI_DATA_DBT)

		Call CLEAR_WARIDASI_DATA(DT)

		With KeyKouji
			DT.KOUJI_NO = .KOUJI_NO '�H���ԍ�
			DT.EDA_NO = .EDA_NO '�H���}��
		End With
		With frmSYKD030
			DT.KOUSYU_CD = Mid(.imMask1(0).Text, 1, 1) '�H������
			DT.KOUSYU_NO = Mid(.imMask1(0).Text, 3, 2) '�H��ԍ�
		End With
		With DT
			.MEISAI_NO = CDbl2(imText4(0).Text) '���הԍ�
			.KISO_FLG = Trim(imText4(1).Text) '��b�t���O
			'----- 2004/03/16 �C�� --------------------------------------------------
			'.S_SUURYOU = CCur2(imText4(2).Text)                '���ʁi�ώZ�����j
			'.S_TANKA = CCur2(imText4(3).Text)                  '�P���i�ώZ�����j
			'.S_KINGAKU = CCur2(imText4(4).Text)                '���z�i�ώZ�����j
			.S_SUURYOU = CCur2(imNumber3(0).Value) '���ʁi�ώZ�����j
			.S_TANKA = CCur2(imNumber3(1).Value) '�P���i�ώZ�����j
			.S_KINGAKU = CCur2(imNumber3(2).Value) '���z�i�ώZ�����j
			'------------------------------------------------------------------------
			.MEISYOU = Trim(imText1(0).Text) '����
			.TANI = Trim(imText1(3).Text) '�P��
			.J_SUURYOU = CCur2(imNumber1(0).Value) '���ʁi���s�\�Z�j
			.J_TANKA = CCur2(imNumber1(1).Value) '�P���i���s�\�Z�j
			.J_KINGAKU = CCur2(imNumber1(2).Value) '���z�i���s�\�Z�j
			.WARIDASI_NO = Trim(imText1(5).Text) '���o�ԍ�
			.WARIDASI_KB = Trim(imText4(5).Text) '���o�敪
			Select Case .WARIDASI_KB
				Case "1" '----- ���c
					.T_SUURYOU = CCur2(imNumber2(0).Value) '���ʁi���c�j
					.T_TANKA = CCur2(imNumber2(1).Value) '�P���i���c�j
					.T_KINGAKU = CCur2(imNumber2(2).Value) '���z�i���c�j
				Case "2" '----- �O��
					.G_SUURYOU = CCur2(imNumber2(0).Value) '���ʁi�O���j
					.G_TANKA = CCur2(imNumber2(1).Value) '�P���i�O���j
					.G_KINGAKU = CCur2(imNumber2(2).Value) '���z�i�O���j
			End Select
		End With

	End Sub

	'-------------------------------------------------------------------------------
	'   ����    :   ���̓f�[�^�̃`�F�b�N
	'   �֐�    :   Function DispDataCheck()
	'   ����    :   �Ȃ�
	'   �ߒl    :   True  ���͐���
	'   �@�@    :   False ���̓G���[
	'   �@�\    :   ���̓f�[�^���`�F�b�N���܂��B
	'-------------------------------------------------------------------------------
	Private Function DispDataCheck() As Boolean

		DispDataCheck = False

		'----- ����
		If Trim(imText1(0).Text) = "" Then
			'2021.09.14 UPGRADE S  AIT)dannnl
			'MsgBox("���̂����͂���Ă��܂���B", MsgBoxStyle.Information)
			MsgBox("���̂����͂���Ă��܂���B", MsgBoxStyle.Information, Me.Text)
			'2021.09.14 UPGRADE E
			imText1(0).Focus()
			Exit Function
		End If
		If TextCharCheck(Trim(imText1(0).Text)) > 0 Then
			'2021.09.14 UPGRADE S  AIT)dannnl
			'MsgBox("���̂ɂ́u ' �v�u " & Chr(34) & " �v���g�p�ł��܂���B", MsgBoxStyle.Information)
			MsgBox("���̂ɂ́u ' �v�u " & Chr(34) & " �v���g�p�ł��܂���B", MsgBoxStyle.Information, Me.Text)
			'2021.09.14 UPGRADE E
			imText1(0).Focus()
			Exit Function
		End If

		'----- �P��
		'    If Trim$(imText1(3).Text) = "" Then
		'        MsgBox "�P�ʂ����͂���Ă��܂���B", vbInformation
		'        imText1(3).SetFocus
		'        Exit Function
		'    End If
		If TextCharCheck(Trim(imText1(3).Text)) > 0 Then
			'2021.09.14 UPGRADE S  AIT)dannnl
			'MsgBox("�P�ʂɂ́u ' �v�u " & Chr(34) & " �v���g�p�ł��܂���B", MsgBoxStyle.Information)
			MsgBox("�P�ʂɂ́u ' �v�u " & Chr(34) & " �v���g�p�ł��܂���B", MsgBoxStyle.Information, Me.Text)
			'2021.09.14 UPGRADE E
			imText1(3).Focus()
			Exit Function
		End If

		DispDataCheck = True

	End Function

	'-------------------------------------------------------------------------------
	'   ����    :   �f�[�^�̎��X�V
	'   �֐�    :   Function DataUpdate()
	'   ����    :   �Ȃ�
	'   �ߒl    :   True    ����I��
	'   �@�@        False   �ُ�I��
	'   �@�\    :   �f�[�^�̍X�V���s���܂��B
	'-------------------------------------------------------------------------------
	Private Function DataUpdate() As Boolean

		Dim Jouken As String
		Dim Cnt As Integer
		Dim DT As WARIDASI_DATA_DBT
		Dim Mode As Short

		' �߂�l�̏�����
		DataUpdate = False

		' ���̓`�F�b�N
		If DispDataCheck() = False Then
			Exit Function
		End If

		' ���͓��e�̎擾
		Call DispDataGet(DT)

		' �X�V����
		System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
		'----- ��ݻ޸��݂̊J�n
		'2021.07.26 UPGRADE S  AIT)Tool Convert
		'SYKDB.BeginTrans()
		BeginTrans()
		'2021.07.26 UPGRADE E
		Do
			'----- ���o�}�X�^���
			If Trim(DT.WARIDASI_NO) <> "" Then
				With DT
					Jouken = "WARIDASI_NO = '" & Trim(.WARIDASI_NO) & "'"
					Jouken = Jouken & " AND EDA_NO = '" & .EDA_NO & "'"
					Jouken = Jouken & " AND KOUJI_NO = '" & .KOUJI_NO & "'"
					Cnt = CNTGET_WARIDASI_MAST(Jouken)
					If Cnt < 0 Then
						'2021.08.04 UPGRADE S  AIT)Hoangtx
						'SYKDB.RollbackTrans()
						RollBack()
						'2021.08.04 UPGRADE E
						Exit Do
					End If
					If Cnt = 0 Then
						' ���o�����͉�ʂ̕\��
						frmSYKD040.SetCode = Trim(.WARIDASI_NO)
						System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
						'2021.08.04 ADD S  AIT)Hoangtx
						Call MtyTool.LostFocus(cmdKey(1), StatusBar1)
						'2021.08.04 ADD E
						frmSYKD040.ShowDialog()
						'2021.08.04 ADD S  AIT)Hoangtx
						Call MtyTool.GotFocus(cmdKey(1), StatusBar1)
						'2021.08.04 ADD E
						System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
						If frmSYKD040.SetKubun = "" Then
							'2021.08.04 UPGRADE S  AIT)Hoangtx
							'SYKDB.RollbackTrans()
							RollBack()
							'2021.08.04 UPGRADE E
							Exit Do
						Else
							.WARIDASI_KB = frmSYKD040.SetKubun
							Select Case DT.WARIDASI_KB
								Case "1" '----- ���c
									.T_SUURYOU = CCur2(imNumber2(0).Value) '����
									.T_TANKA = CCur2(imNumber2(1).Value) '�P��
									.T_KINGAKU = CCur2(imNumber2(2).Value) '���z
								Case "2" '----- �O��
									.G_SUURYOU = CCur2(imNumber2(0).Value) '����
									.G_TANKA = CCur2(imNumber2(1).Value) '�P��
									.G_KINGAKU = CCur2(imNumber2(2).Value) '���z
							End Select
						End If
					End If
				End With
			End If

			Select Case UpMode
				'----- �ǉ�
				Case "0", "2"
					'----- ���c��O�����o�f�[�^
					If INSERT_WARIDASI_DATA(DT) = False Then
						'2021.08.04 UPGRADE S  AIT)Hoangtx
						'SYKDB.RollbackTrans()
						RollBack()
						'2021.08.04 UPGRADE E
						Exit Do
					End If

					'----- �C��
				Case "1"
					'----- 2004/04/16 �����݃f�[�^�̂�����̂́A���o���ԍ����X�y�[�X�ɕύX�ł��Ȃ��l�ɂ���
					If Trim(PreDT.WARIDASI_NO) <> Trim(DT.WARIDASI_NO) Then
						If Trim(DT.WARIDASI_NO) = "" Then
							With DT
								Jouken = "MEISAI_NO = " & .MEISAI_NO
								Jouken = Jouken & " AND KOUSYU_NO = '" & .KOUSYU_NO & "'"
								Jouken = Jouken & " AND KOUSYU_CD = '" & .KOUSYU_CD & "'"
								Jouken = Jouken & " AND EDA_NO = '" & .EDA_NO & "'"
								Jouken = Jouken & " AND KOUJI_NO = '" & .KOUJI_NO & "'"
							End With
							'----- ������
							If CNTGET_MIKOMI_DATA(Jouken) > 0 Then
								'2021.08.04 UPGRADE S  AIT)Hoangtx
								'MsgBox("���c������񂪓o�^����Ă���̂Ŋ��o�ԍ����폜�ł��܂���B", MsgBoxStyle.OkOnly + MsgBoxStyle.Information)
								'SYKDB.RollbackTrans()
								MsgBox("���c������񂪓o�^����Ă���̂Ŋ��o�ԍ����폜�ł��܂���B", MsgBoxStyle.OkOnly + MsgBoxStyle.Information, Me.Text)
								RollBack()
								'2021.08.04 UPGRADE E
								Exit Do
							End If
						End If
					End If

					'----- ���c��O�����o�f�[�^
					With DT
						Jouken = "MEISAI_NO = " & .MEISAI_NO
						Jouken = Jouken & " AND KOUSYU_NO = '" & .KOUSYU_NO & "'"
						Jouken = Jouken & " AND KOUSYU_CD = '" & .KOUSYU_CD & "'"
						Jouken = Jouken & " AND EDA_NO = '" & .EDA_NO & "'"
						Jouken = Jouken & " AND KOUJI_NO = '" & .KOUJI_NO & "'"
					End With
					If UPDATE_WARIDASI_DATA(Jouken, DT) = False Then
						'2021.08.04 UPGRADE S  AIT)Hoangtx
						'SYKDB.RollbackTrans()
						RollBack()
						'2021.08.04 UPGRADE E
						Exit Do
					End If

					' ���o�ԍ����ύX�ς̏ꍇ
					If Trim(PreDT.WARIDASI_NO) <> Trim(DT.WARIDASI_NO) Then
						With PreDT
							'----- ����t���O�i�y�؁j
							If .WARIDASI_KB > "0" Then
								Mode = Val(.WARIDASI_KB)
								If UpdateCtrlFlg(Mode) = False Then
									'2021.08.04 UPGRADE S  AIT)Hoangtx
									'SYKDB.RollbackTrans()
									RollBack()
									'2021.08.04 UPGRADE E
									Exit Do
								End If
							End If
							'----- ���o�ύX�t���O
							If .WARIDASI_KB > "0" Then
								Jouken = "WARIDASI_NO = '" & Trim(.WARIDASI_NO) & "'"
								Jouken = Jouken & " AND EDA_NO = '" & .EDA_NO & "'"
								Jouken = Jouken & " AND KOUJI_NO = '" & .KOUJI_NO & "'"
								If UpdateHenkoFlg("WARIDASI_MAST", Jouken, "1") = False Then
									'2021.08.04 UPGRADE S  AIT)Hoangtx
									'SYKDB.RollbackTrans()
									RollBack()
									'2021.08.04 UPGRADE E
									Exit Do
								End If
							End If
							'----- �O���ύX�t���O
							If .WARIDASI_KB = "2" Then
								Jouken = "SIME_YM = '" & CtlKouji.SYORI_YM & "'"
								Jouken = Jouken & " AND CHUUMON_NO = '" & Trim(.WARIDASI_NO) & "'"
								Jouken = Jouken & " AND EDA_NO = '" & .EDA_NO & "'"
								Jouken = Jouken & " AND KOUJI_NO = '" & .KOUJI_NO & "'"
								If UpdateHenkoFlg("GAI_KIHON_DATA", Jouken, "1") = False Then
									'2021.08.04 UPGRADE S  AIT)Hoangtx
									'SYKDB.RollbackTrans()
									RollBack()
									'2021.08.04 UPGRADE E
									Exit Do
								End If
							End If
						End With
					End If
			End Select

			' �t���O�X�V
			With DT
				'----- ����t���O�i�y�؁j
				If .WARIDASI_KB > "0" Then
					Mode = Val(.WARIDASI_KB)
					If UpdateCtrlFlg(Mode) = False Then
						'2021.08.04 UPGRADE S  AIT)Hoangtx
						'SYKDB.RollbackTrans()
						RollBack()
						'2021.08.04 UPGRADE E
						Exit Do
					End If
				End If
				'----- ���o�ύX�t���O
				If .WARIDASI_KB > "0" Then
					Jouken = "WARIDASI_NO = '" & Trim(.WARIDASI_NO) & "'"
					Jouken = Jouken & " AND EDA_NO = '" & .EDA_NO & "'"
					Jouken = Jouken & " AND KOUJI_NO = '" & .KOUJI_NO & "'"
					If UpdateHenkoFlg("WARIDASI_MAST", Jouken, "1") = False Then
						'2021.08.04 UPGRADE S  AIT)Hoangtx
						'SYKDB.RollbackTrans()
						RollBack()
						'2021.08.04 UPGRADE E
						Exit Do
					End If
				End If
				'----- �O���ύX�t���O
				If .WARIDASI_KB = "2" Then
					Jouken = "SIME_YM = '" & CtlKouji.SYORI_YM & "'"
					Jouken = Jouken & " AND CHUUMON_NO = '" & Trim(.WARIDASI_NO) & "'"
					Jouken = Jouken & " AND EDA_NO = '" & .EDA_NO & "'"
					Jouken = Jouken & " AND KOUJI_NO = '" & .KOUJI_NO & "'"
					If UpdateHenkoFlg("GAI_KIHON_DATA", Jouken, "1") = False Then
						'2021.08.04 UPGRADE S  AIT)Hoangtx
						'SYKDB.RollbackTrans()
						RollBack()
						'2021.08.04 UPGRADE E
						Exit Do
					End If
				End If
			End With

			'----- ��ݻ޸��݂̊m��
			'2021.07.26 UPGRADE S  AIT)Tool Convert
			'SYKDB.CommitTrans()
			'' �f�[�^�ޔ�
			CommitTransaction()
			' �f�[�^�ޔ�
			'2021.07.26 UPGRADE E
			PreDT = DT
			' ����I��
			DataUpdate = True
			Exit Do
		Loop
		System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default

	End Function

	'-------------------------------------------------------------------------------
	'   ����    :   �ύX�`�F�b�N
	'   �֐�    :   Function ChangeCheck()
	'   ����    :   �Ȃ�
	'   �ߒl    :   True    �ύX����
	'   �@�@        False   �ύX�Ȃ�
	'   �@�\    :   �f�[�^���ύX���ꂽ���ǂ����`�F�b�N���s���܂��B
	'-------------------------------------------------------------------------------
	Private Function ChangeCheck() As Boolean

		Dim DT As WARIDASI_DATA_DBT

		' �߂�l�̏�����
		ChangeCheck = True

		' ���͓��e�̎擾
		Call DispDataGet(DT)

		With DT
			If Trim(.MEISYOU) <> Trim(PreDT.MEISYOU) Then Exit Function '����
			If Trim(.TANI) <> Trim(PreDT.TANI) Then Exit Function '�P��
			If .J_SUURYOU <> PreDT.J_SUURYOU Then Exit Function '���ʁi���s�\�Z�j
			If .J_TANKA <> PreDT.J_TANKA Then Exit Function '�P���i���s�\�Z�j
			If .J_KINGAKU <> PreDT.J_KINGAKU Then Exit Function '���z�i���s�\�Z�j
			If .T_SUURYOU <> PreDT.T_SUURYOU Then Exit Function '���ʁi���c�j
			If .T_TANKA <> PreDT.T_TANKA Then Exit Function '�P���i���c�j
			If .T_KINGAKU <> PreDT.T_KINGAKU Then Exit Function '���z�i���c�j
			If .G_SUURYOU <> PreDT.G_SUURYOU Then Exit Function '���ʁi�O���j
			If .G_TANKA <> PreDT.G_TANKA Then Exit Function '�P���i�O���j
			If .G_KINGAKU <> PreDT.G_KINGAKU Then Exit Function '���z�i�O���j
			If Not String.IsNullOrEmpty(.WARIDASI_NO) AndAlso Trim(.WARIDASI_NO) <> Trim(PreDT.WARIDASI_NO) Then Exit Function '���o�ԍ�
			If Not String.IsNullOrEmpty(.WARIDASI_KB) AndAlso Trim(.WARIDASI_KB) <> Trim(PreDT.WARIDASI_KB) Then Exit Function '���o�敪
		End With

		' �ύX�Ȃ�
		ChangeCheck = False

	End Function

	'2021.08.02 UPGRADE S  AIT)Hoangtx
	'Private Sub cmdKey_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Click
	Private Sub cmdKey_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _cmdKey_12.Click, _cmdKey_1.Click
		'Dim Index As Short = cmdKey.GetIndex(eventSender)
		Dim Index As Short = cmdKey.IndexOf(eventSender)

		Dim wkBango As Double
		Dim ssText As Object

		Select Case Index
			Case 1 '----- �o�^
				' �f�[�^���X�V
				If DataUpdate() = False Then
					Exit Sub
				End If
				' �f�[�^�ĕ\��
				Call frmSYKD020.ListDataDisp(1)
				Call frmSYKD030.ListDataDisp(1)
				Select Case UpMode
					Case "0" '----- �V�K�̏ꍇ
						Call DispClear(1)
						wkBango = PreDT.MEISAI_NO + 1.0#
						Call CLEAR_WARIDASI_DATA(PreDT)
						With PreDT
							.KOUJI_NO = KeyKouji.KOUJI_NO '�H���ԍ�
							.EDA_NO = KeyKouji.EDA_NO '�H���}��
							.KOUSYU_CD = Mid(frmSYKD030.KousyuID, 1, 1) '�H������
							.KOUSYU_NO = Mid(frmSYKD030.KousyuID, 3, 2) '�H��ԍ�
							.MEISAI_NO = wkBango '���הԍ�
							'2021.08.03 UPGRADE S  AIT)Hoangtx
							'imText4(0).Text = VB6.Format(.MEISAI_NO)
							imText4(0).Text = (.MEISAI_NO).ToString
							'2021.08.03 UPGRADE E
							.KISO_FLG = "0" '��b�t���O
							.WARIDASI_KB = "0" '���o�敪
						End With
						imText1(5).Focus()
						Exit Sub

					Case "1" '----- �C���̏ꍇ
						With frmSYKD030
							'2021.08.03 UPGRADE S  AIT)Hoangtx
							InpRow = InpRow + 1
							'If InpRow < .vaSpread1.MaxRows Then
							If InpRow < .FpSpread1.ActiveSheet.RowCount Then
								'.vaSpread1.GetText(15, InpRow, ssText) '���הԍ��̎擾
								ssText = .FpSpread1.ActiveSheet.GetText(InpRow, 14) '���הԍ��̎擾
								.MeisaiNO = CDbl2(ssText)
								'.vaSpread1.Row = InpRow
								'.vaSpread1.Action = FPSpread.ActionConstants.ActionActiveCell
								.FpSpread1.ActiveSheet.OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
								.Focus()
								.FpSpread1.ActiveSheet.ActiveRowIndex = InpRow
								.FpSpread1.ShowRow(0, InpRow, FarPoint.Win.Spread.VerticalPosition.Bottom)
								.FpSpread1.ActiveSheet.AddSelection(.FpSpread1.ActiveSheet.ActiveRowIndex, -1, 1, -1)
								'2021.08.03 UPGRADE E

								Call DispClear(1)
								If SprdDataGet(PreDT) = False Then
									'2021.08.03 UPGRADE S  AIT)Hoangtx
									'MsgBox("�Y�����钼�c��O�����o�f�[�^�͊��ɑ��݂��܂���B", MsgBoxStyle.OkOnly)
									'Me.Close()
									MsgBox("�Y�����钼�c��O�����o�f�[�^�͊��ɑ��݂��܂���B", MsgBoxStyle.OkOnly, Me.Text)
									Me.Dispose()
									'2021.08.03 UPGRADE E
									Exit Sub
								End If
								Call DispDataSet(PreDT)
								imText1(5).Focus()
								Exit Sub
							End If
						End With
				End Select

			Case 12 '----- �I��
				' �ύX�`�F�b�N
				If ChangeCheck() = True Then
					'2021.09.14 UPGRADE S  AIT)dannnl
					'If MsgBox("�f�[�^���ύX����Ă��܂��B�{���ɏI�����܂����H", MsgBoxStyle.YesNo + MsgBoxStyle.Information) = MsgBoxResult.No Then
					If MsgBox("�f�[�^���ύX����Ă��܂��B�{���ɏI�����܂����H", MsgBoxStyle.YesNo + MsgBoxStyle.Information, SYSTEMNM) = MsgBoxResult.No Then
						'2021.09.14 UPGRADE E
						Exit Sub
					End If
				End If
		End Select

		'2021.08.03 UPGRADE S  AIT)Hoangtx
		'Me.Close()
		Me.Dispose()
		'2021.08.03 UPGRADE E

	End Sub

	'2021.08.02 UPGRADE S  AIT)Hoangtx
	'Private Sub cmdKey_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Enter

	Private Sub cmdKey_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _cmdKey_12.Enter, _cmdKey_1.Enter
		'Dim Index As Short = cmdKey.GetIndex(eventSender)
		Dim Index As Short = cmdKey.IndexOf(eventSender)
		'Call GotFocus(cmdKey(Index), StatusBar1)
		Call MtyTool.GotFocus(cmdKey(Index), StatusBar1)
		'2021.08.02 UPGRADE E
	End Sub

	'2021.08.02 UPGRADE S  AIT)Hoangtx
	'Private Sub cmdKey_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Leave

	Private Sub cmdKey_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _cmdKey_12.Leave, _cmdKey_1.Leave
		'Dim Index As Short = cmdKey.GetIndex(eventSender)
		Dim Index As Short = cmdKey.IndexOf(eventSender)
		'Call LostFocus(cmdKey(Index), StatusBar1)
		Call MtyTool.LostFocus(cmdKey(Index), StatusBar1)
		'2021.08.02 UPGRADE E
	End Sub

	'2021.08.02 UPGRADE S  AIT)Hoangtx
	'Private Sub cmdLook_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdLook.Click
	Private Sub cmdLook_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _cmdLook_5.Click
		'Dim Index As Short = cmdLook.GetIndex(eventSender)
		Dim Index As Short = cmdLook.IndexOf(eventSender)
		'2021.08.02 UPGRADE E

		Select Case Index
			Case 5 ' ���o���}�X�^����
				frmSearch.MastNo = 12
				frmSearch.ZENTEI = "KOUJI_NO = '" & KeyKouji.KOUJI_NO & "' AND EDA_NO = '" & KeyKouji.EDA_NO & "'"
				frmSearch.ShowDialog()
				If frmSearch.GetCD <> "" Then
					imText1(Index).Text = Trim(frmSearch.GetCD)
					imText2(Index).Text = Trim(frmSearch.GetNM)
					imText4(Index).Text = Trim(frmSearch.GetYB)
					imText2(6).Text = GetNameChokuei(Trim(imText4(Index).Text))
					imText1(0).Focus()
					Exit Sub
				End If
				imText1(Index).Focus()
		End Select

	End Sub

	Private Sub frmSYKD031_Activated(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Activated
		' �����I��
		If StopFlg = 1 Then
			'2021.08.03 UPGRADE S  AIT)Hoangtx
			'Me.Close()
			Me.Dispose()
			'2021.08.03 UPGRADE E
			Exit Sub
		End If
	End Sub

	Private Sub frmSYKD031_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown
		Dim KeyCode As Short = eventArgs.KeyCode
		Dim Shift As Short = eventArgs.KeyData \ &H10000
		Select Case KeyCode
			Case System.Windows.Forms.Keys.Return
				'Call NextCntlGet(Me, Me.ActiveControl.TabIndex)
			Case System.Windows.Forms.Keys.F1
				If cmdKey(1).Enabled = True Then cmdKey(1).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(1), New System.EventArgs())
			Case System.Windows.Forms.Keys.F12
				If cmdKey(12).Enabled = True Then cmdKey(12).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(12), New System.EventArgs())
		End Select
	End Sub

	Private Sub frmSYKD031_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load

		Call FormDisp(Me)

		' �t���O������
		StopFlg = 0

		' �I���f�[�^�̕\��
		Call DispClear()
		If SprdDataGet(PreDT) = False Then
			'2021.09.14 UPGRADE S  AIT)dannnl
			'MsgBox("�Y�����钼�c��O�����o�f�[�^�͊��ɑ��݂��܂���B", MsgBoxStyle.OkOnly)
			MsgBox("�Y�����钼�c��O�����o�f�[�^�͊��ɑ��݂��܂���B", MsgBoxStyle.OkOnly, Me.Text)
			'2021.09.14 UPGRADE E
			StopFlg = 1
			Exit Sub
		End If
		Call DispDataSet(PreDT)

		' �C���s�ԍ��̎擾
		'2021.08.03 UPGRADE S  AIT)Hoangtx
		'InpRow = frmSYKD030.vaSpread1.Row
		InpRow = frmSYKD030.FpSpread1.ActiveSheet.ActiveRowIndex
		'2021.08.03 UPGRADE E
	End Sub

	Private Sub frmSYKD031_FormClosing(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
		Dim Cancel As Boolean = eventArgs.Cancel
		Dim UnloadMode As System.Windows.Forms.CloseReason = eventArgs.CloseReason
		If UnloadMode = System.Windows.Forms.CloseReason.UserClosing Then
			' �ύX�`�F�b�N
			If ChangeCheck() = True Then
				'2021.09.14 UPGRADE S  AIT)dannnl
				'If MsgBox("�f�[�^���ύX����Ă��܂��B�{���ɏI�����܂����H", MsgBoxStyle.YesNo + MsgBoxStyle.Information) = MsgBoxResult.No Then
				If MsgBox("�f�[�^���ύX����Ă��܂��B�{���ɏI�����܂����H", MsgBoxStyle.YesNo + MsgBoxStyle.Information, SYSTEMNM) = MsgBoxResult.No Then
					'2021.09.14 UPGRADE E
					Cancel = True
					Exit Sub
				End If
			End If
		End If
		eventArgs.Cancel = Cancel
	End Sub

	'2021.08.02 UPGRADE S  AIT)Hoangtx
	'Private Sub imNumber1_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles imNumber1.Enter
	Private Sub imNumber1_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _imNumber1_0.Enter, _imNumber1_1.Enter, _imNumber1_2.Enter
		'Dim Index As Short = imNumber1.GetIndex(eventSender)
		Dim Index As Short = imNumber1.IndexOf(eventSender)
		'Call GotFocus(imNumber1(Index), StatusBar1)
		Call MtyTool.GotFocus(imNumber1(Index), StatusBar1)
		'2021.08.02 UPGRADE E
		PreVal = CCur2(imNumber1(Index).Value)
		'2021.08.02 ADD S  AIT)Hoangtx
		If Index = 2 AndAlso _imNumber1_2.Value = 0 Then
		Else
			imNumber1(Index).SelectAll()
		End If
		'2021.08.02 ADD E
	End Sub

	'2021.08.02 UPGRADE S  AIT)Hoangtx
	'Private Sub imNumber1_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles imNumber1.KeyDown
	Private Sub imNumber1_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles _imNumber1_0.KeyDown, _imNumber1_1.KeyDown, _imNumber1_2.KeyDown
		Dim KeyCode As Short = eventArgs.KeyCode
		Dim Shift As Short = eventArgs.KeyData \ &H10000
		'Dim Index As Short = imNumber1.GetIndex(eventSender)
		Dim Index As Short = imNumber1.IndexOf(eventSender)
		'2021.08.02 UPGRADE E
		Select Case KeyCode
			Case System.Windows.Forms.Keys.Return
				Select Case Index
					Case 0 : imText1(3).Focus()
					Case 1 : imNumber1(2).Focus()
					Case 2 : imNumber2(0).Focus()
				End Select
		End Select
	End Sub

	'2021.08.02 UPGRADE S  AIT)Hoangtx
	'Private Sub imNumber1_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles imNumber1.Leave
	Private Sub imNumber1_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _imNumber1_0.Leave, _imNumber1_1.Leave, _imNumber1_2.Leave
		'Dim Index As Short = imNumber1.GetIndex(eventSender)
		Dim Index As Short = imNumber1.IndexOf(eventSender)
		Dim wkVal As Double
		'Call LostFocus(imNumber1(Index), StatusBar1)
		Call MtyTool.LostFocus(imNumber1(Index), StatusBar1)
		'2021.08.02 UPGRADE E
		Select Case Index
			Case 0, 1 '----- ���ʁE�P��
				wkVal = CDbl2(imNumber1(0).Value) * CDbl2(imNumber1(1).Value)
				If wkVal <> 0 Then
					'2021.08.02 UPGRADE S  AIT)Hoangtx
					'If wkVal <= imNumber1(2).MaxValue And wkVal >= imNumber1(2).MinValue Then
					If imNumber1(2).MinValue <= wkVal AndAlso wkVal <= imNumber1(2).MaxValue Then
						'imNumber1(2).Value = VB6.Format(wkVal)
						imNumber1(2).Value = (wkVal).ToString
					Else
						'2021.09.14 UPGRADE S  AIT)dannnl
						'MsgBox("���z�̌������I�[�o�[���܂����B", MsgBoxStyle.OkOnly + MsgBoxStyle.Exclamation)
						MsgBox("���z�̌������I�[�o�[���܂����B", MsgBoxStyle.OkOnly + MsgBoxStyle.Exclamation, Me.Text)
						'2021.09.14 UPGRADE E
						'imNumber1(Index).Value = VB6.Format(PreVal)
						imNumber1(Index).Value = (PreVal).ToString
						'2021.08.02 UPGRADE E
						imNumber1(Index).Focus()
					End If
				End If
		End Select
	End Sub


	'2021.08.02 UPGRADE S  AIT)Hoangtx
	'Private Sub imNumber2_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles imNumber2.Enter
	Private Sub imNumber2_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _imNumber2_0.Enter, _imNumber2_1.Enter, _imNumber2_2.Enter
		Dim Index As Short = imNumber2.IndexOf(eventSender)
		'Call GotFocus(imNumber2(Index), StatusBar1)
		Call MtyTool.GotFocus(imNumber2(Index), StatusBar1)
		PreVal = CCur2(imNumber2(Index).Value)
		'2021.08.02 ADD S  AIT)Hoangtx
		If Index = 2 AndAlso _imNumber2_2.Value = 0 Then
		Else
			imNumber2(Index).SelectAll()
		End If
		'2021.08.02 ADD E
	End Sub
	'2021.08.02 UPGRADE E

	'2021.08.02 UPGRADE S  AIT)Hoangtx
	'Private Sub imNumber2_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles imNumber2.KeyDown
	Private Sub imNumber2_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles _imNumber2_0.KeyDown, _imNumber2_1.KeyDown, _imNumber2_2.KeyDown
		Dim KeyCode As Short = eventArgs.KeyCode
		Dim Shift As Short = eventArgs.KeyData \ &H10000
		'Dim Index As Short = imNumber2.GetIndex(eventSender)
		Dim Index As Short = imNumber2.IndexOf(eventSender)
		'2021.08.02 UPGRADE E
		Select Case KeyCode
			Case System.Windows.Forms.Keys.Return
				Select Case Index
					Case 0 : imNumber2(1).Focus()
					Case 1 : imNumber2(2).Focus()
					Case 2 : cmdKey(1).Focus()
				End Select
		End Select
	End Sub

	'2021.08.02 UPGRADE S  AIT)Hoangtx
	'Private Sub imText1_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles imNumber2.Leave
	Private Sub imNumber2_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _imNumber2_0.Leave, _imNumber2_1.Leave, _imNumber2_2.Leave
		'Dim Index As Short = imNumber2.IndexOf(eventSender)
		Dim Index As Short = imNumber2.IndexOf(eventSender)
		Dim wkVal As Double
		'Call LostFocus(imNumber2(Index), StatusBar1)
		Call MtyTool.LostFocus(imNumber2(Index), StatusBar1)
		'2021.08.02 UPGRADE E
		Select Case Index
			Case 0, 1 '----- ���ʁE�P��
				wkVal = CDbl2(imNumber2(0).Value) * CDbl2(imNumber2(1).Value)
				If wkVal <> 0 Then
					'If wkVal <= imNumber2(2).MaxValue Or wkVal >= imNumber2(2).MinValue Then
					'2021.08.02 UPGRADE S  AIT)Hoangtx
					'If imNumber1(2).MinValue <= wkVal And wkVal <= imNumber1(2).MaxValue Then
					If imNumber2(2).MinValue <= wkVal AndAlso wkVal <= imNumber2(2).MaxValue Then
						'imNumber2(2).Value = VB6.Format(wkVal)
						imNumber2(2).Value = (wkVal).ToString
					Else
						'2021.09.14 UPGRADE S  AIT)dannnl
						'MsgBox("���z�̌������I�[�o�[���܂����B", MsgBoxStyle.OkOnly + MsgBoxStyle.Exclamation)
						MsgBox("���z�̌������I�[�o�[���܂����B", MsgBoxStyle.OkOnly + MsgBoxStyle.Exclamation, Me.Text)
						'2021.09.14 UPGRADE E
						'imNumber2(Index).Value = VB6.Format(PreVal)
						imNumber2(Index).Value = (PreVal).ToString
						'2021.08.02 UPGRADE E
						imNumber2(Index).Focus()
					End If
				End If
		End Select
	End Sub

	'2021.08.02 UPGRADE S  AIT)Hoangtx
	'Private Sub imNumber3_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles imNumber3.Enter
	Private Sub imNumber3_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _imNumber3_0.Enter, _imNumber3_1.Enter, _imNumber3_2.Enter
		'Dim Index As Short = imNumber3.GetIndex(eventSender)
		Dim Index As Short = imNumber3.IndexOf(eventSender)
		'2021.08.02 UPGRADE E
		StatusBar1.Items.Item("Message").Text = imNumber3(Index).Tag
		PreVal = CCur2(imNumber3(Index).Value)
	End Sub

	'2021.08.02 UPGRADE S  AIT)Hoangtx
	'Private Sub imNumber3_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles imNumber3.KeyDown
	Private Sub imNumber3_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles _imNumber3_0.KeyDown, _imNumber3_1.KeyDown, _imNumber3_2.KeyDown
		Dim KeyCode As Short = eventArgs.KeyCode
		Dim Shift As Short = eventArgs.KeyData \ &H10000
		'Dim Index As Short = imNumber3.GetIndex(eventSender)
		Dim Index As Short = imNumber3.IndexOf(eventSender)
		'2021.08.02 UPGRADE E
		Select Case KeyCode
			Case System.Windows.Forms.Keys.Return
				Select Case Index
					Case 0 : imNumber3(1).Focus()
					Case 1 : imNumber3(2).Focus()
					Case 2 : imNumber1(0).Focus()
				End Select
		End Select
	End Sub

	'2021.08.02 UPGRADE S  AIT)Hoangtx
	'Private Sub imNumber3_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles imNumber3.Leave
	Private Sub imNumber3_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _imNumber3_0.Leave, _imNumber3_1.Leave, _imNumber3_2.Leave
		'Dim Index As Short = imNumber3.GetIndex(eventSender)
		Dim Index As Short = imNumber3.IndexOf(eventSender)
		'2021.08.02 UPGRADE E
		Dim wkVal As Double
		StatusBar1.Items.Item("Message").Text = ""
		Select Case Index
			Case 0, 1 '----- ���ʁE�P��
				wkVal = CDbl2(imNumber3(0).Value) * CDbl2(imNumber3(1).Value)
				If wkVal <> 0 Then
					'2021.08.02 UPGRADE S  AIT)Hoangtx
					'If wkVal <= imNumber3(2).MaxValue Or wkVal >= imNumber3(2).MinValue Then
					If wkVal <= imNumber3(2).MaxValue OrElse wkVal >= imNumber3(2).MinValue Then
						'imNumber3(2).Value = VB6.Format(wkVal)
						imNumber3(2).Value = (wkVal).ToString
					Else
						'2021.09.14 UPGRADE S  AIT)dannnl
						'MsgBox("���z�̌������I�[�o�[���܂����B", MsgBoxStyle.OkOnly + MsgBoxStyle.Exclamation)
						MsgBox("���z�̌������I�[�o�[���܂����B", MsgBoxStyle.OkOnly + MsgBoxStyle.Exclamation, Me.Text)
						'2021.09.14 UPGRADE E
						'imNumber3(Index).Value = VB6.Format(PreVal)
						imNumber3(Index).Value = (PreVal).ToString
						'2021.08.02 UPGRADE E
						imNumber3(Index).Focus()
					End If
				End If
		End Select
	End Sub

	'2021.08.02 UPGRADE S  AIT)Hoangtx
	'Private Sub imText1_Change(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles imText1.Change
	Private Sub imText1_Change(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _imText1_0.TextChanged, _imText1_3.TextChanged, _imText1_5.TextChanged
		'Dim Index As Short = imText1.GetIndex(eventSender)
		Dim Index As Short = imText1.IndexOf(eventSender)
		'2021.08.02 UPGRADE E
		Select Case Index
			Case 5 '----- ���o�ԍ�
				imText2(5).Text = ""
				imText2(6).Text = ""
		End Select
	End Sub

	'2021.08.02 UPGRADE S  AIT)Hoangtx
	'Private Sub imText1_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles imText1.Enter
	Private Sub imText1_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _imText1_0.Enter, _imText1_3.Enter, _imText1_5.Enter
		'Dim Index As Short = imText1.GetIndex(eventSender)
		Dim Index As Short = imText1.IndexOf(eventSender)
		'Call GotFocus(imText1(Index), StatusBar1)
		Call MtyTool.GotFocus(imText1(Index), StatusBar1)
		'2021.08.02 UPGRADE E
	End Sub

	'2021.08.02 UPGRADE S  AIT)Hoangtx
	'Private Sub imText1_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles imText1.KeyDown
	Private Sub imText1_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles _imText1_0.KeyDown, _imText1_3.KeyDown, _imText1_5.KeyDown
		Dim KeyCode As Short = eventArgs.KeyCode
		Dim Shift As Short = eventArgs.KeyData \ &H10000
		'Dim Index As Short = imText1.GetIndex(eventSender)
		Dim Index As Short = imText1.IndexOf(eventSender)
		'2021.08.02 UPGRADE E
		'2021.09.15 ADD S  AIT)Hoangtx
		Dim text As String = imText1(Index).text
		'2021.09.15 ADD E
		Select Case KeyCode
			Case System.Windows.Forms.Keys.Return
				Select Case Index
					Case 0 : imNumber1(0).Focus()
					Case 3 : imNumber1(1).Focus()
					Case 5 : imText1(0).Focus()
				End Select
			Case System.Windows.Forms.Keys.Space
				Call cmdLook_Click(cmdLook.Item(Index), New System.EventArgs())
				'2021.09.15 ADD S  AIT)Hoangtx
				If Trim(imText1(Index).text) = text.ToString Or imText1(Index).text.Contains(" ") Then
					imText1(Index).text = text
					imText1_Leave(imText1(Index), eventArgs)
					imText1(Index).selectall()
				End If
				'2021.09.15 ADD E
		End Select
	End Sub

	'2021.08.02 UPGRADE S  AIT)Hoangtx
	'Private Sub imText1_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles imText1.Leave
	Private Sub imText1_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _imText1_0.Leave, _imText1_3.Leave, _imText1_5.Leave
		'Dim Index As Short = imText1.GetIndex(eventSender)
		Dim Index As Short = imText1.IndexOf(eventSender)
		'Call LostFocus(imText1(Index), StatusBar1)
		Call MtyTool.LostFocus(imText1(Index), StatusBar1)
		'If imText1(Index).Format = "9" Then
		'imText1(Index).Text = VB6.Format(imText1(Index).Text, New String("0", imText1(Index).MaxLength))
		If imText1(Index) IsNot Nothing AndAlso imText1(Index).Format = "9" Then
			If imText1(Index).Text <> "" Then
				imText1(Index).Text = Strings.Right(New String("0", imText1(Index).MaxLength) & Trim(imText1(Index).Text), imText1(Index).MaxLength)
			End If
		End If
		'2021.08.02 UPGRADE E
		Select Case Index
			Case 5 '----- ���o�ԍ�
				With KeyKouji
					imText4(5).Text = GetKubunChokuei(.KOUJI_NO, .EDA_NO, Trim(imText1(Index).Text))
					imText2(5).Text = GetNameWaridasi(.KOUJI_NO, .EDA_NO, Trim(imText1(Index).Text))
					imText2(6).Text = GetNameChokuei(Trim(imText4(Index).Text))
				End With
				'----- ���s�\�Z���̕���
				If Trim(imText1(Index).Text) = "" Then
					imNumber2(0).Value = "0"
					imNumber2(1).Value = "0"
					imNumber2(2).Value = "0"
					'2021.08.02 UPGRADE S  AIT)Hoangtx
					'ElseIf imNumber2(0).Value = "0" And imNumber2(1).Value = "0" And imNumber2(2).Value = "0" Then
				ElseIf imNumber2(0).Value = "0" AndAlso imNumber2(1).Value = "0" AndAlso imNumber2(2).Value = "0" Then
					'2021.08.02 UPGRADE E
					imNumber2(0).Value = imNumber1(0).Value
					imNumber2(1).Value = imNumber1(1).Value
					imNumber2(2).Value = imNumber1(2).Value
				End If
		End Select
	End Sub

	'2021.08.02 UPGRADE S  AIT)Hoangtx
	'Private Sub Label1_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles Label1.Click

	Private Sub Label1_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _Label1_0.Click, _Label1_1.Click, _Label1_2.Click,
		_Label1_3.Click, _Label1_4.Click, _Label1_5.Click, _Label1_6.Click, _Label1_7.Click, _Label1_8.Click, _Label1_9.Click, _Label1_10.Click,
		_Label1_11.Click, _Label1_12.Click, _Label1_14.Click
		'Dim Index As Short = Label1.GetIndex(eventSender)
		Dim Index As Short = Label1.IndexOf(eventSender)
		'2021.08.02 UPGRADE E
		'2014/01/10 �ǉ� -----------------------����������
		Select Case Index
			Case 11 : imNumber3(2).ReadOnly = False
			Case 12 : imNumber3(1).ReadOnly = False
			Case 14 : imNumber3(0).ReadOnly = False
		End Select
		'---------------------------------------����������
	End Sub
End Class
