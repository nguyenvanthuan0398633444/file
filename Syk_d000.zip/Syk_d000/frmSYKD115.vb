Option Strict Off
Option Explicit On
Friend Class frmSYKD115
	Inherits System.Windows.Forms.Form
	'=============================================================
	' ���[�U�[���@  �F  �R�z�H�Ɗ������
	' �V�X�e�����@  �F  �H���Ǘ��V�X�e��
	' ���W���[����  �F  �O���o�����񍐏�������j���[���
	' ���W���[��ID�@�F  frmSYKD115.frm
	' �쐬���@ �@�@ �F  ���� 13 �N 07 �� 24 ��
	' �X�V���@�@  �@�F  ����    �N    ��    ��
	'=============================================================
	'
	'2021.08.09 UPGRADE S  AIT)hieunv
	'Private Const RowHeight As Short = 15
	Private Const RowHeight As Short = 20
	'2021.08.09 UPGRADE E

	Private himc As Integer
	'

	'-------------------------------------------------------------------------------
	'   ����    :   �f�[�^�̎擾
	'   �֐�    :   Sub ListDataDisp()
	'   ����    :   Mode    0 = MsgBox�\��
	'   �@�\    :   �f�[�^�̎擾���s���܂��B
	'-------------------------------------------------------------------------------
	Public Sub ListDataDisp(Optional ByRef Mode As Short = 0)

		Dim Cnt As Integer
		Dim Jouken As String
		Dim Order As String
		Dim DT() As WARIDASI_MAST_DBT
		Dim wkBuf As String

		' �J�[�\���������v��
		System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
		wkBuf = StatusBar1.Items.Item("Message").Text
		StatusBar1.Items.Item("Message").Text = "�Y���f�[�^�������E�E�E"

		' �e�[�u���̓Ǎ���
		Jouken = "EDA_NO = '" & KeyKouji.EDA_NO & "'"
		Jouken = Jouken & " AND KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"
		Jouken = Jouken & " AND CHOKUEI_KB = '2'"
		Order = "WARIDASI_NO"
		Cnt = SELECT_WARIDASI_MAST(Jouken, Order, DT)

		If Cnt <= 0 Then
			'2021.08.03 UPGRADE S  AIT)hieunv
			'vaSpread1.MaxRows = 0
			vaSpread1.ActiveSheet.RowCount = 0
			'2021.08.03 UPGRADE E
			_cmdKey_1.Enabled = False
			StatusBar1.Items.Item("Message").Text = wkBuf
			System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
			Exit Sub
		End If

		' �X�v���b�h�ɕ\��
		Call SprdDataSet(Cnt, DT)

		StatusBar1.Items.Item("Message").Text = wkBuf
		System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default

	End Sub

	'-------------------------------------------------------------------------------
	'   ����    :   �X�v���b�h�\��
	'   �֐�    :   Sub SprdDataSet(DT())
	'   ����    :   Cnt     �f�[�^����
	'   �@�@    :   DT()    WARIDASI_MAST_DBT
	'   �@�\    :   �f�[�^���X�v���b�h�ɕ\�����܂��B
	'-------------------------------------------------------------------------------
	Private Sub SprdDataSet(ByRef Cnt As Integer, ByRef DT() As WARIDASI_MAST_DBT)

		Dim lp As Integer
		Dim Row As Integer
		Dim ssText As Object

		With vaSpread1
			If Me.Visible = True Then
				'2021.08.02 UPGRADE S  AIT)hieunv
				'.ReDraw = False
				.SuspendLayout()
			End If
			'2021.08.02 UPGRADE S  AIT)hieunv
			'.MaxRows = Cnt
			'.Col = 1 : .Col2 = .MaxCols
			'.Row = 1 : .Row2 = .MaxRows
			'.BlockMode = True
			'.Action = FPSpread.ActionConstants.ActionClearText
			'.ForeColor = System.Drawing.Color.Black
			'.BlockMode = False
			.ActiveSheet.RowCount = Cnt
			.ActiveSheet.ClearRange(0, 0, .ActiveSheet.RowCount, .ActiveSheet.ColumnCount, True)
			.ActiveSheet.OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
			.ActiveSheet.AddSelection(0, 0, 1, 1)
			'2021.08.03 UPGRADE E
			For lp = 0 To Cnt - 1
				'2021.08.03 UPGRADE S  AIT)hieunv
				'.set_RowHeight(lp + 1, RowHeight)
				.ActiveSheet.SetRowHeight(lp, RowHeight)
				'2021.08.03 UPGRADE E
				Row = lp
				'----- CheckBox
				'2021.08.03 UPGRADE S  AIT)hieunv
				'.SetText(1, Row, "1")
				.ActiveSheet.SetText(Row, 0, "1")
				'2021.08.03 UPGRADE E
				'----- ������
				ssText = Trim(DT(lp).WARIDASI_NO)
				'2021.08.03 UPGRADE S  AIT)hieunv
				'.SetText(2, Row, ssText)
				.ActiveSheet.SetText(Row, 1, ssText)
				'2021.08.03 UPGRADE E
				'----- ����
				ssText = Trim(DT(lp).MEISYOU)
				'2021.08.03 UPGRADE S  AIT)hieunv
				'.SetText(3, Row, ssText)
				.ActiveSheet.SetText(Row, 2, ssText)
				'2021.08.03 UPGRADE E
				'----- �Ǝк���
				ssText = Trim(DT(lp).GYOUSYA_CD)
				'2021.08.03 UPGRADE S  AIT)hieunv
				'.SetText(4, Row, ssText)
				.ActiveSheet.SetText(Row, 3, ssText)
				'2021.08.03 UPGRADE E
				'----- �ƎЖ�
				If Trim(DT(lp).GYOUSYA_CD) <> "" Then
					ssText = Trim(GetNameGyousya(DT(lp).GYOUSYA_CD))
					'2021.08.03 UPGRADE S  AIT)hieunv
					'.SetText(5, Row, ssText)
					.ActiveSheet.SetText(Row, 4, ssText)
					'2021.08.03 UPGRADE E
				End If
			Next lp
			If Me.Visible = True Then
				'2021.08.02 UPGRADE S  AIT)hieunv
				'.CtlRefresh()
				'.ReDraw = True
				.Refresh()
				.ResumeLayout()
				'2021.08.02 UPGRADE E
			End If
		End With

	End Sub
	'2021.08.02 UPGRADE S  AIT)hieunv
	'Private Sub cmdKey_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Click
	Private Sub cmdKey_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _cmdKey_1.Click, _cmdKey_12.Click
		'2021.08.02 UPGRADE E
		Dim Index As Short = cmdKey.IndexOf(eventSender)

		Dim lp As Integer
		Dim CDT() As String
		Dim Jouken As String
		Dim Msg As String
		'2021.08.04 DEL S  AIT)hieunv
		'Dim Col As Integer
		'Dim Row As Integer
		'2021.08.04 DEL E
		Select Case Index
			Case 1 '----- ���
				'2021.09.14 UPGRADE S  AIT)dannnl
				'If MsgBox("�񍐏���������܂��B��낵���ł����H", MsgBoxStyle.YesNo) = MsgBoxResult.No Then
				If MsgBox("�񍐏���������܂��B��낵���ł����H", MsgBoxStyle.YesNo, SYSTEMNM) = MsgBoxResult.No Then
				'2021.09.14 UPGRADE E
					Exit Sub
				End If '2021.08.02 UPGRADE E
				With vaSpread1
					ReDim Preserve CDT(.ActiveSheet.RowCount)
					For lp = 1 To .ActiveSheet.RowCount
						'2021.08.13 UPGRADE S  AIT)hieunv
						'.Col = 1 : .Row = lp
						'If .Text = "1" Then
						'.Col = 2 : .Row = lp
						'CDT(lp) = .Text
						If .ActiveSheet.Cells(lp - 1, 0).Text = "1" Then
							CDT(lp) = .ActiveSheet.Cells(lp - 1, 1).Value
							'2021.08.13 UPGRADE E
						End If
					Next lp
				End With
				System.Windows.Forms.Application.DoEvents()
				System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
				StatusBar1.Items.Item("Message").Text = "����f�[�^�쐬���E�E�E"
				System.Windows.Forms.Application.DoEvents()
				If PrnMainD115(CDT) = True Then
					'2001/01/21 �ҏW�̏ꍇ�̂ݍX�V����
					If INPMODE = "2" Then '�ҏW��
						' �H�����i����j�y�؂̍X�V
						CtlKouji.P_FLG_DEKIDAKA = "1" '���FLG �O���o�����񍐏�
						Jouken = "KOUJI_NO = '" & CtlKouji.KOUJI_NO & "' AND EDA_NO = '" & CtlKouji.EDA_NO & "'"
						If UPDATE_KOUJI_CTRL_D(Jouken, CtlKouji) = False Then
							Msg = "�H�����i����j�y�؂̍X�V�Ɏ��s���܂����B"
							'2021.09.14 UPGRADE S  AIT)dannnl
							'MsgBox(Msg, MsgBoxStyle.OkOnly)
							MsgBox(Msg, MsgBoxStyle.OkOnly, SYSTEMNM)
							'2021.09.14 UPGRADE E
							Exit Sub
						End If
					End If
				End If
				System.Windows.Forms.Application.DoEvents()
				StatusBar1.Items.Item("Message").Text = ""
				System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
				System.Windows.Forms.Application.DoEvents()
			Case 12 '----- �I��
				'2021.08.31 ADD S  AIT)hieunv
				cmdKey(1).Focus()
				'2021.08.31 ADD S  AIT)hieunv
				'Me.Close()
				Me.Dispose()
		End Select

	End Sub

	Private Sub cmdKey_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _cmdKey_1.Enter, _cmdKey_12.Enter
		'2021.08.02 UPGRADE S  AIT)hieunv
		'Dim Index As Short = cmdKey.GetIndex(eventSender)
		'Call GotFocus(cmdKey(Index), StatusBar1)
		Dim Index As Short = cmdKey.IndexOf(eventSender)
		Call MtyTool.GotFocus(cmdKey(Index), StatusBar1)
		'2021.08.02 UPGRADE E
	End Sub

	Private Sub cmdKey_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _cmdKey_1.Leave, _cmdKey_12.Leave
		'2021.08.02 UPGRADE S  AIT)hieunv
		'Dim Index As Short = cmdKey.GetIndex(eventSender)
		'Call LostFocus(cmdKey(Index), StatusBar1)
		Dim Index As Short = cmdKey.IndexOf(eventSender)
		Call MtyTool.LostFocus(cmdKey(Index), StatusBar1)
	End Sub

	Private Sub frmSYKD115_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As KeyEventArgs) Handles MyBase.KeyDown
		Dim KeyCode As Short = eventArgs.KeyCode
		Dim Shift As Short = eventArgs.KeyData \ &H10000
		Select Case KeyCode
			Case System.Windows.Forms.Keys.Return
				'2021.08.17 UPGRADE S  AIT)dannnl
				'Call NextCntlGet(Me, Me.ActiveControl.TabIndex)
				Call NextCntlGet()
				'2021.08.17 UPGRADE E
			Case System.Windows.Forms.Keys.F1
				If cmdKey(1).Enabled = True Then cmdKey(1).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(1), New System.EventArgs())
			Case System.Windows.Forms.Keys.F12
				If cmdKey(12).Enabled = True Then cmdKey(12).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(12), New System.EventArgs())
		End Select
	End Sub

	Private Sub frmSYKD115_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load

		Call FormDisp(Me)

		'�X�v���b�h��IME�N���n�e�e
		'2021.08.02 UPGRADE S  AIT)hieunv
		'himc = ImmGetContext(vaSpread1.hWnd)
		himc = ImmGetContext(vaSpread1.Handle)
		'2021.08.02 UPGRADE E
		Call ListDataDisp(1)

	End Sub

	Private Sub frmSYKD115_FormClosing(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
		Dim Cancel As Boolean = eventArgs.Cancel
		Dim UnloadMode As System.Windows.Forms.CloseReason = eventArgs.CloseReason
		If UnloadMode = System.Windows.Forms.CloseReason.UserClosing Then
			'
		End If
		eventArgs.Cancel = Cancel
	End Sub

	'Private Sub vaSpread1_ClickEvent(ByVal eventSender As System.Object, ByVal eventArgs As AxFPSpread._DSpreadEvents_ClickEvent) Handles vaSpread1.ClickEvent
	Private Sub vaSpread1_ClickEvent(ByVal eventSender As System.Object, ByVal eventArgs As FarPoint.Win.Spread.CellClickEventArgs) Handles vaSpread1.CellClick

		Dim lp As Integer
		Dim ssText As Object
		If eventArgs.Column = 0 Then
			'2021.08.02 UPGRADE E
			With vaSpread1
				'If eventArgs.Row = 0 Then
				If eventArgs.ColumnHeader = True AndAlso eventArgs.RowHeader = False Then
					' �S�I��
					'2021.08.02 UPGRADE S  AIT)hieunv
					'For lp = 1 To .MaxRows
					'	.GetText(1, lp, ssText)
					For lp = 1 To .ActiveSheet.RowCount
						ssText = .ActiveSheet.GetText(lp - 1, 0)
						If ssText = "1" Then Exit For
						'2021.08.02 UPGRADE E
					Next lp
					If ssText = "1" Then
						ssText = "0"
					Else
						ssText = "1"
					End If
					'2021.08.02 UPGRADE S  AIT)hieunv
					'For lp = 1 To .MaxRows
					'.Col = Col : .Row = lp
					'.Text = ssText
					For lp = 1 To .ActiveSheet.RowCount
						'2021.08.10 UPGRADE S  AIT)hieunv
						'.Text = ssText
						.ActiveSheet.Cells(lp - 1, 0).Text = ssText
						'2021.08.10 UPGRADE E  
					Next lp
				ElseIf eventArgs.ColumnHeader = False AndAlso eventArgs.RowHeader = False Then
					'2021.08.10 UPGRADE DEL  AIT)hieunv
					'.Col = Col : .Row = Row
					'2021.08.10 DEL  E 
					'2021.08.10 UPGRADE S  AIT)hieunv
					If .ActiveSheet.Cells(eventArgs.Row, 0).Text = "0" Then
						.ActiveSheet.Cells(eventArgs.Row, 0).Text = "1"
					Else
						.ActiveSheet.Cells(eventArgs.Row, 0).Text = "0"
					End If
					'2021.08.10 UPGRADE E  
				End If
			End With
		End If
		'2021.08.10 UPGRADE S  AIT)hieunv
	End Sub

	Private Sub vaSpread1_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles vaSpread1.Enter
		'2021.08.02 UPGRADE S  AIT)hieunv
		'Call GotFocus(vaSpread1, StatusBar1)
		Call MtyTool.GotFocus(vaSpread1, StatusBar1)
		'2021.08.02 UPGRADE E
		ImmSetOpenStatus(himc, False)
	End Sub
	'2021.08.02 UPGRADE S  AIT)hieunv
	'Private Sub vaSpread1_KeyDownEvent(ByVal eventSender As System.Object, ByVal eventArgs As AxFPSpread._DSpreadEvents_KeyDownEvent) Handles vaSpread1.KeyDownEvent
	'	If eventArgs.KeyCode = System.Windows.Forms.Keys.Space Then
	'		Call vaSpread1_ClickEvent(vaSpread1, New AxFPSpread._DSpreadEvents_ClickEvent(1, vaSpread1.ActiveRow))
	'	End If
	'End Sub
	Private Sub vaSpread1_KeyDownEvent(ByVal eventSender As System.Object, ByVal eventArgs As KeyEventArgs) Handles vaSpread1.KeyDown
		If eventArgs.KeyData = System.Windows.Forms.Keys.Space Then
			Call vaSpread1_ClickEvent(vaSpread1, New FarPoint.Win.Spread.CellClickEventArgs(
										vaSpread1.GetRootWorkbook, vaSpread1.ActiveSheet.ActiveRow.Index, 0, 1, 1, New MouseButtons, False, False))
		End If
	End Sub
	'2021.08.02 UPGRADE E
	Private Sub vaSpread1_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles vaSpread1.Leave
		'2021.08.02 UPGRADE S  AIT)hieunv
		'Call LostFocus(vaSpread1, StatusBar1)
		Call MtyTool.LostFocus(vaSpread1, StatusBar1)
		'2021.08.02 UPGRADE E
	End Sub

End Class
