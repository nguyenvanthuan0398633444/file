Imports GrapeCity.Win.Editors

<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frmSYKD301
#Region "Windows Form Designer generated code "
    <System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
        MyBase.New()
        InitializeComponent()

        Frame1 = New ArrayList()
        Frame1.Add(_Frame1_0)

        Label1 = New ArrayList(New Object(6){})
        Label1(6) = _Label1_6

        cmdKey = New ArrayList(New Object(12){})
        cmdKey(1) = _cmdKey_1
        cmdKey(12) = _cmdKey_12

        imText1 = New ArrayList()
        imText1.Add(_imText1_0)

    End Sub
    <System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
        If Disposing Then
            If Not components Is Nothing Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(Disposing)
    End Sub
    Private components As System.ComponentModel.IContainer
    Public ToolTip1 As System.Windows.Forms.ToolTip
    Public WithEvents Command1 As System.Windows.Forms.Button
    Public WithEvents Picture2 As System.Windows.Forms.Panel
    'Public WithEvents File1 As Microsoft.VisualBasic.Compatibility.VB6.FileListBox
    'Public WithEvents Dir1 As Microsoft.VisualBasic.Compatibility.VB6.DirListBox
    'Public WithEvents Drive1 As Microsoft.VisualBasic.Compatibility.VB6.DriveListBox
    'Public WithEvents _imText1_0 As imText6.imText
    Public WithEvents File1 As ListBox
    Public WithEvents Dir1 As TreeView
    Public WithEvents Drive1 As ComboBox
    Public WithEvents _imText1_0 As GcTextBox
    Public WithEvents _Label1_6 As System.Windows.Forms.Label
    Public WithEvents _Frame1_0 As System.Windows.Forms.GroupBox
    Public WithEvents _cmdKey_1 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_12 As System.Windows.Forms.Button
    Public WithEvents Picture1 As System.Windows.Forms.Panel
    Public WithEvents _StatusBar1_Panel1 As System.Windows.Forms.ToolStripStatusLabel
    Public WithEvents Message As System.Windows.Forms.ToolStripStatusLabel
    Public WithEvents StatusBar1 As System.Windows.Forms.StatusStrip
    Public WithEvents lblTitle As System.Windows.Forms.Label
    'Public WithEvents Frame1 As Microsoft.VisualBasic.Compatibility.VB6.GroupBoxArray
    'Public WithEvents Label1 As Microsoft.VisualBasic.Compatibility.VB6.LabelArray
    'Public WithEvents cmdKey As Microsoft.VisualBasic.Compatibility.VB6.ButtonArray
    'Public WithEvents imText1 As imTextArray
    Public WithEvents Frame1 As ArrayList
    Public WithEvents Label1 As ArrayList
    Public WithEvents cmdKey As ArrayList
    Public WithEvents imText1 As ArrayList

    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmSYKD301))
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.Picture2 = New System.Windows.Forms.Panel()
        Me.Command1 = New System.Windows.Forms.Button()
        Me._Frame1_0 = New System.Windows.Forms.GroupBox()
        Me.File1 = New System.Windows.Forms.ListBox()
        Me.Dir1 = New System.Windows.Forms.TreeView()
        Me.ImageList1 = New System.Windows.Forms.ImageList(Me.components)
        Me.Drive1 = New System.Windows.Forms.ComboBox()
        Me._imText1_0 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._Label1_6 = New System.Windows.Forms.Label()
        Me.Picture1 = New System.Windows.Forms.Panel()
        Me._cmdKey_1 = New System.Windows.Forms.Button()
        Me._cmdKey_12 = New System.Windows.Forms.Button()
        Me.StatusBar1 = New System.Windows.Forms.StatusStrip()
        Me._StatusBar1_Panel1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.Message = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.ImageList2 = New System.Windows.Forms.ImageList(Me.components)
        Me.ImageList3 = New System.Windows.Forms.ImageList(Me.components)
        Me.Picture2.SuspendLayout
        Me._Frame1_0.SuspendLayout
        CType(Me._imText1_0,System.ComponentModel.ISupportInitialize).BeginInit
        Me.Picture1.SuspendLayout
        Me.StatusBar1.SuspendLayout
        Me.SuspendLayout
        '
        'Picture2
        '
        Me.Picture2.BackColor = System.Drawing.SystemColors.Control
        Me.Picture2.Controls.Add(Me.Command1)
        Me.Picture2.Cursor = System.Windows.Forms.Cursors.Default
        Me.Picture2.Enabled = false
        Me.Picture2.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Picture2.Location = New System.Drawing.Point(164, 34)
        Me.Picture2.Name = "Picture2"
        Me.Picture2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Picture2.Size = New System.Drawing.Size(311, 43)
        Me.Picture2.TabIndex = 10
        Me.Picture2.Visible = false
        '
        'Command1
        '
        Me.Command1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255,Byte),Integer), CType(CType(192,Byte),Integer), CType(CType(255,Byte),Integer))
        Me.Command1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Command1.Font = New System.Drawing.Font("MS Mincho", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128,Byte))
        Me.Command1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Command1.Location = New System.Drawing.Point(0, 0)
        Me.Command1.Name = "Command1"
        Me.Command1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Command1.Size = New System.Drawing.Size(311, 43)
        Me.Command1.TabIndex = 11
        Me.Command1.TabStop = false
        Me.Command1.Text = "�f�[�^�̓]�������     "
        Me.Command1.UseVisualStyleBackColor = false
        '
        '_Frame1_0
        '
        Me._Frame1_0.BackColor = System.Drawing.SystemColors.Control
        Me._Frame1_0.Controls.Add(Me.File1)
        Me._Frame1_0.Controls.Add(Me.Dir1)
        Me._Frame1_0.Controls.Add(Me.Drive1)
        Me._Frame1_0.Controls.Add(Me._imText1_0)
        Me._Frame1_0.Controls.Add(Me._Label1_6)
        Me._Frame1_0.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Frame1_0.Location = New System.Drawing.Point(6, 38)
        Me._Frame1_0.Name = "_Frame1_0"
        Me._Frame1_0.Padding = New System.Windows.Forms.Padding(0)
        Me._Frame1_0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Frame1_0.Size = New System.Drawing.Size(465, 281)
        Me._Frame1_0.TabIndex = 0
        Me._Frame1_0.TabStop = false
        Me._Frame1_0.Tag = "���̓t�@�C����I�����܂��B"
        '
        'File1
        '
        Me.File1.BackColor = System.Drawing.SystemColors.Window
        Me.File1.Cursor = System.Windows.Forms.Cursors.Default
        Me.File1.Font = New System.Drawing.Font("MS PGothic", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.File1.ForeColor = System.Drawing.SystemColors.WindowText
        Me.File1.IntegralHeight = false
        Me.File1.ItemHeight = 12
        Me.File1.Location = New System.Drawing.Point(247, 56)
        Me.File1.Name = "File1"
        Me.File1.Size = New System.Drawing.Size(203, 194)
        Me.File1.Sorted = true
        Me.File1.TabIndex = 2
        Me.File1.Tag = "���̓t�@�C����I�����܂��B"
        '
        'Dir1
        '
        Me.Dir1.BackColor = System.Drawing.Color.White
        Me.Dir1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Dir1.Font = New System.Drawing.Font("MS PGothic", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.Dir1.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Dir1.ImageIndex = 0
        Me.Dir1.ImageList = Me.ImageList1
        Me.Dir1.Location = New System.Drawing.Point(18, 90)
        Me.Dir1.Name = "Dir1"
        Me.Dir1.SelectedImageIndex = 1
        Me.Dir1.ShowLines = false
        Me.Dir1.ShowPlusMinus = false
        Me.Dir1.ShowRootLines = false
        Me.Dir1.Size = New System.Drawing.Size(223, 160)
        Me.Dir1.TabIndex = 1
        Me.Dir1.Tag = "���͐�f�B���N�g����I�����܂��B"
        '
        'ImageList1
        '
        Me.ImageList1.ImageStream = CType(resources.GetObject("ImageList1.ImageStream"),System.Windows.Forms.ImageListStreamer)
        Me.ImageList1.TransparentColor = System.Drawing.Color.Transparent
        Me.ImageList1.Images.SetKeyName(0, "closedfolder.bmp")
        Me.ImageList1.Images.SetKeyName(1, "openfolder.bmp")
        '
        'Drive1
        '
        Me.Drive1.BackColor = System.Drawing.SystemColors.Window
        Me.Drive1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Drive1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Drive1.Font = New System.Drawing.Font("MS PGothic", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.Drive1.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Drive1.Location = New System.Drawing.Point(18, 56)
        Me.Drive1.Name = "Drive1"
        Me.Drive1.Size = New System.Drawing.Size(223, 20)
        Me.Drive1.TabIndex = 0
        Me.Drive1.Tag = "���͐�h���C�u��I�����܂��B"
        '
        '_imText1_0
        '
        Me._imText1_0.Font = New System.Drawing.Font("MS Mincho", 12!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me._imText1_0.ImeMode = System.Windows.Forms.ImeMode.Off
        Me._imText1_0.Location = New System.Drawing.Point(130, 20)
        Me._imText1_0.MaxLength = 128
        Me._imText1_0.Name = "_imText1_0"
        Me._imText1_0.ReadOnly = true
        Me._imText1_0.ReadOnlyBackColor = System.Drawing.SystemColors.Control
        Me._imText1_0.Size = New System.Drawing.Size(195, 23)
        Me._imText1_0.TabIndex = 12
        Me._imText1_0.TabStop = false
        Me._imText1_0.Tag = "�t�@�C��������͂��ĉ������B"
        '
        '_Label1_6
        '
        Me._Label1_6.BackColor = System.Drawing.Color.FromArgb(CType(CType(0,Byte),Integer), CType(CType(128,Byte),Integer), CType(CType(128,Byte),Integer))
        Me._Label1_6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_6.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_6.Font = New System.Drawing.Font("MS Mincho", 12!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128,Byte))
        Me._Label1_6.ForeColor = System.Drawing.Color.White
        Me._Label1_6.Location = New System.Drawing.Point(18, 20)
        Me._Label1_6.Name = "_Label1_6"
        Me._Label1_6.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_6.Size = New System.Drawing.Size(106, 23)
        Me._Label1_6.TabIndex = 9
        Me._Label1_6.Text = "�t�@�C����"
        Me._Label1_6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Picture1
        '
        Me.Picture1.BackColor = System.Drawing.Color.FromArgb(CType(CType(128,Byte),Integer), CType(CType(128,Byte),Integer), CType(CType(128,Byte),Integer))
        Me.Picture1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Picture1.Controls.Add(Me._cmdKey_1)
        Me.Picture1.Controls.Add(Me._cmdKey_12)
        Me.Picture1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Picture1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Picture1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Picture1.Location = New System.Drawing.Point(0, 325)
        Me.Picture1.Name = "Picture1"
        Me.Picture1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Picture1.Size = New System.Drawing.Size(481, 51)
        Me.Picture1.TabIndex = 6
        '
        '_cmdKey_1
        '
        Me._cmdKey_1.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_1.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_1.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128,Byte))
        Me._cmdKey_1.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_1.Location = New System.Drawing.Point(4, 4)
        Me._cmdKey_1.Name = "_cmdKey_1"
        Me._cmdKey_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_1.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_1.TabIndex = 3
        Me._cmdKey_1.Tag = "���͐悩��f�[�^��]�����܂��B"
        Me._cmdKey_1.Text = "F1"&Global.Microsoft.VisualBasic.ChrW(13)&Global.Microsoft.VisualBasic.ChrW(10)&"�] ��"
        Me._cmdKey_1.UseVisualStyleBackColor = false
        '
        '_cmdKey_12
        '
        Me._cmdKey_12.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_12.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_12.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128,Byte))
        Me._cmdKey_12.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_12.Location = New System.Drawing.Point(394, 4)
        Me._cmdKey_12.Name = "_cmdKey_12"
        Me._cmdKey_12.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_12.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_12.TabIndex = 4
        Me._cmdKey_12.Tag = "�I�����܂��B"
        Me._cmdKey_12.Text = "F12"&Global.Microsoft.VisualBasic.ChrW(13)&Global.Microsoft.VisualBasic.ChrW(10)&"�I ��"
        Me._cmdKey_12.UseVisualStyleBackColor = false
        '
        'StatusBar1
        '
        Me.StatusBar1.Font = New System.Drawing.Font("MS Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128,Byte))
        Me.StatusBar1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me._StatusBar1_Panel1, Me.Message})
        Me.StatusBar1.Location = New System.Drawing.Point(0, 376)
        Me.StatusBar1.Name = "StatusBar1"
        Me.StatusBar1.Size = New System.Drawing.Size(481, 23)
        Me.StatusBar1.TabIndex = 5
        '
        '_StatusBar1_Panel1
        '
        Me._StatusBar1_Panel1.AutoSize = false
        Me._StatusBar1_Panel1.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top)  _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right)  _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom),System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me._StatusBar1_Panel1.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter
        Me._StatusBar1_Panel1.Margin = New System.Windows.Forms.Padding(0)
        Me._StatusBar1_Panel1.Name = "_StatusBar1_Panel1"
        Me._StatusBar1_Panel1.Size = New System.Drawing.Size(117, 23)
        '
        'Message
        '
        Me.Message.AutoSize = false
        Me.Message.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top)  _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right)  _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom),System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me.Message.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter
        Me.Message.Margin = New System.Windows.Forms.Padding(0)
        Me.Message.Name = "Message"
        Me.Message.Size = New System.Drawing.Size(345, 23)
        Me.Message.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblTitle
        '
        Me.lblTitle.BackColor = System.Drawing.Color.FromArgb(CType(CType(192,Byte),Integer), CType(CType(255,Byte),Integer), CType(CType(255,Byte),Integer))
        Me.lblTitle.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTitle.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblTitle.Font = New System.Drawing.Font("MS Mincho", 20.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic),System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(128,Byte))
        Me.lblTitle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0,Byte),Integer), CType(CType(0,Byte),Integer), CType(CType(128,Byte),Integer))
        Me.lblTitle.Location = New System.Drawing.Point(0, 0)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblTitle.Size = New System.Drawing.Size(479, 31)
        Me.lblTitle.TabIndex = 8
        Me.lblTitle.Text = " ���͐�I��"
        '
        'ImageList2
        '
        Me.ImageList2.ImageStream = CType(resources.GetObject("ImageList2.ImageStream"),System.Windows.Forms.ImageListStreamer)
        Me.ImageList2.TransparentColor = System.Drawing.Color.Transparent
        Me.ImageList2.Images.SetKeyName(0, "closedfolder.bmp")
        Me.ImageList2.Images.SetKeyName(1, "openfolder.bmp")
        '
        'ImageList3
        '
        Me.ImageList3.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit
        Me.ImageList3.ImageSize = New System.Drawing.Size(16, 16)
        Me.ImageList3.TransparentColor = System.Drawing.Color.Transparent
        '
        'frmSYKD301
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(481, 399)
        Me.Controls.Add(Me.Picture2)
        Me.Controls.Add(Me._Frame1_0)
        Me.Controls.Add(Me.Picture1)
        Me.Controls.Add(Me.StatusBar1)
        Me.Controls.Add(Me.lblTitle)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"),System.Drawing.Icon)
        Me.KeyPreview = true
        Me.Location = New System.Drawing.Point(228, 217)
        Me.MaximizeBox = false
        Me.MinimizeBox = false
        Me.Name = "frmSYKD301"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "�H���Ǘ��V�X�e��"
        Me.Picture2.ResumeLayout(false)
        Me._Frame1_0.ResumeLayout(false)
        CType(Me._imText1_0,System.ComponentModel.ISupportInitialize).EndInit
        Me.Picture1.ResumeLayout(false)
        Me.StatusBar1.ResumeLayout(false)
        Me.StatusBar1.PerformLayout
        Me.ResumeLayout(false)
        Me.PerformLayout

End Sub

    Friend WithEvents ImageList1 As ImageList
    Friend WithEvents ImageList2 As ImageList
    Friend WithEvents ImageList3 As ImageList
#End Region
End Class