Imports GrapeCity.Win.Editors

<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frmSYKD025
#Region "Windows Form Designer generated code "
    <System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
        MyBase.New()
        'This call is required by the Windows Form Designer.
        InitializeComponent()
        Command1 = New ArrayList()
        Command1.Add(_Command1_0)
        Command1.Add(_Command1_1)
        Command1.Add(_Command1_2)
        Command1.Add(_Command1_3)
        Command1.Add(_Command1_4)
        Command1.Add(_Command1_5)
        Command1.Add(_Command1_6)
        Command1.Add(_Command1_7)
        Command1.Add(_Command1_8)
        Command1.Add(_Command1_9)

        Picture2 = New ArrayList()
        Picture2.Add(_Picture2_0)
        Picture2.Add(_Picture2_1)

        cmdKey = New ArrayList()
        cmdKey.Add(Nothing)
        cmdKey.Add(_cmdKey_1)
        cmdKey.Add(_cmdKey_2)
        cmdKey.Add(_cmdKey_3)
        cmdKey.Add(_cmdKey_4)
        cmdKey.Add(_cmdKey_5)
        cmdKey.Add(_cmdKey_6)
        cmdKey.Add(_cmdKey_7)
        cmdKey.Add(_cmdKey_8)
        cmdKey.Add(_cmdKey_9)
        cmdKey.Add(_cmdKey_10)
        cmdKey.Add(_cmdKey_11)
        cmdKey.Add(_cmdKey_12)

        imText2 = New ArrayList()
        imText2.Add(_imText2_0)
        imText2.Add(_imText2_1)
        imText2.Add(_imText2_2)
    End Sub
    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
        If Disposing Then
            If Not components Is Nothing Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(Disposing)
    End Sub
    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer
    Public ToolTip1 As System.Windows.Forms.ToolTip
    Public WithEvents _Command1_9 As System.Windows.Forms.Button
    Public WithEvents _Command1_8 As System.Windows.Forms.Button
    Public WithEvents _Command1_7 As System.Windows.Forms.Button
    Public WithEvents _Command1_6 As System.Windows.Forms.Button
    Public WithEvents _Command1_5 As System.Windows.Forms.Button
    Public WithEvents _Picture2_1 As System.Windows.Forms.Panel
    Public WithEvents _Command1_4 As System.Windows.Forms.Button
    Public WithEvents _Command1_3 As System.Windows.Forms.Button
    Public WithEvents _Command1_2 As System.Windows.Forms.Button
    Public WithEvents _Command1_0 As System.Windows.Forms.Button
    Public WithEvents _Command1_1 As System.Windows.Forms.Button
    Public WithEvents _Picture2_0 As System.Windows.Forms.Panel
    Public WithEvents _cmdKey_3 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_12 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_4 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_10 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_6 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_7 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_8 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_9 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_1 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_11 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_2 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_5 As System.Windows.Forms.Button
    Public WithEvents Picture1 As System.Windows.Forms.Panel
    Public WithEvents _StatusBar1_Panel1 As System.Windows.Forms.ToolStripStatusLabel
    Public WithEvents Message As System.Windows.Forms.ToolStripStatusLabel
    Public WithEvents StatusBar1 As System.Windows.Forms.StatusStrip
    Public WithEvents _imText2_2 As GcTextBox
    Public WithEvents _imText2_0 As GcTextBox
    Public WithEvents _imText2_1 As GcTextBox
    'Public WithEvents vaSpread1 As AxFPSpread.AxvaSpread
    Public WithEvents lblTitle As System.Windows.Forms.Label
    Public WithEvents Command1 As ArrayList
    Public WithEvents Picture2 As ArrayList
    Public WithEvents cmdKey As ArrayList
    Public WithEvents imText2 As ArrayList
    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim CustomSpdHeader As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim CustomSpdHeader1 As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim CustomSpdHeader2 As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim CustomSpdHeader3 As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim CustomSpdHeader4 As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim CustomSpdHeader5 As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim CustomSpdHeader6 As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim CustomSpdHeader7 As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim CustomSpdHeader8 As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim CustomSpdHeader9 As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim CustomSpdHeader10 As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim CustomSpdHeader11 As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim CustomSpdHeader12 As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim CustomSpdHeader13 As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim CustomSpdHeader14 As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim CustomSpdHeader15 As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim CustomSpdHeader16 As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim CustomSpdHeader17 As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim CustomSpdHeader18 As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim CustomSpdHeader19 As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim CustomSpdHeader20 As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim DefaultFocusIndicatorRenderer1 As FarPoint.Win.Spread.DefaultFocusIndicatorRenderer = New FarPoint.Win.Spread.DefaultFocusIndicatorRenderer()
        Dim DefaultScrollBarRenderer1 As FarPoint.Win.Spread.DefaultScrollBarRenderer = New FarPoint.Win.Spread.DefaultScrollBarRenderer()
        Dim NamedStyle1 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("Color65637634892816600574")
        Dim NamedStyle2 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("Font193637634892816600574")
        Dim TipAppearance1 As FarPoint.Win.Spread.TipAppearance = New FarPoint.Win.Spread.TipAppearance()
        Dim DefaultScrollBarRenderer2 As FarPoint.Win.Spread.DefaultScrollBarRenderer = New FarPoint.Win.Spread.DefaultScrollBarRenderer()
        Dim TextCellType1 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType()
        Dim TextCellType2 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType()
        Dim TextCellType3 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType()
        Dim TextCellType4 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType()
        Dim ComplexBorder1 As FarPoint.Win.ComplexBorder = New FarPoint.Win.ComplexBorder(New FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThinLine))
        Dim TextCellType5 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType()
        Dim TextCellType6 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmSYKD025))
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me._Picture2_1 = New System.Windows.Forms.Panel()
        Me._Command1_9 = New System.Windows.Forms.Button()
        Me._Command1_8 = New System.Windows.Forms.Button()
        Me._Command1_7 = New System.Windows.Forms.Button()
        Me._Command1_6 = New System.Windows.Forms.Button()
        Me._Command1_5 = New System.Windows.Forms.Button()
        Me._Picture2_0 = New System.Windows.Forms.Panel()
        Me._Command1_4 = New System.Windows.Forms.Button()
        Me._Command1_3 = New System.Windows.Forms.Button()
        Me._Command1_2 = New System.Windows.Forms.Button()
        Me._Command1_0 = New System.Windows.Forms.Button()
        Me._Command1_1 = New System.Windows.Forms.Button()
        Me.Picture1 = New System.Windows.Forms.Panel()
        Me._cmdKey_3 = New System.Windows.Forms.Button()
        Me._cmdKey_12 = New System.Windows.Forms.Button()
        Me._cmdKey_4 = New System.Windows.Forms.Button()
        Me._cmdKey_10 = New System.Windows.Forms.Button()
        Me._cmdKey_6 = New System.Windows.Forms.Button()
        Me._cmdKey_7 = New System.Windows.Forms.Button()
        Me._cmdKey_8 = New System.Windows.Forms.Button()
        Me._cmdKey_9 = New System.Windows.Forms.Button()
        Me._cmdKey_1 = New System.Windows.Forms.Button()
        Me._cmdKey_11 = New System.Windows.Forms.Button()
        Me._cmdKey_2 = New System.Windows.Forms.Button()
        Me._cmdKey_5 = New System.Windows.Forms.Button()
        Me.StatusBar1 = New System.Windows.Forms.StatusStrip()
        Me._StatusBar1_Panel1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.Message = New System.Windows.Forms.ToolStripStatusLabel()
        Me._imText2_2 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._imText2_0 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._imText2_1 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.vaSpread1 = New FarPoint.Win.Spread.FpSpread()
        Me.vaSpread1_Sheet1 = New FarPoint.Win.Spread.SheetView()
        Me._Picture2_1.SuspendLayout()
        Me._Picture2_0.SuspendLayout()
        Me.Picture1.SuspendLayout()
        Me.StatusBar1.SuspendLayout()
        CType(Me._imText2_2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imText2_0, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imText2_1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.vaSpread1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.vaSpread1_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        CustomSpdHeader.Name = "CustomSpdHeader"
        CustomSpdHeader.PictureZoomEffect = False
        CustomSpdHeader.TextRotationAngle = 0R
        CustomSpdHeader.ZoomFactor = 1.0!
        CustomSpdHeader1.Name = "CustomSpdHeader1"
        CustomSpdHeader1.PictureZoomEffect = False
        CustomSpdHeader1.TextRotationAngle = 0R
        CustomSpdHeader1.ZoomFactor = 1.0!
        CustomSpdHeader2.Name = "CustomSpdHeader2"
        CustomSpdHeader2.PictureZoomEffect = False
        CustomSpdHeader2.TextRotationAngle = 0R
        CustomSpdHeader2.ZoomFactor = 1.0!
        CustomSpdHeader3.Name = "CustomSpdHeader3"
        CustomSpdHeader3.PictureZoomEffect = False
        CustomSpdHeader3.TextRotationAngle = 0R
        CustomSpdHeader3.ZoomFactor = 1.0!
        CustomSpdHeader4.Name = "CustomSpdHeader4"
        CustomSpdHeader4.PictureZoomEffect = False
        CustomSpdHeader4.TextRotationAngle = 0R
        CustomSpdHeader4.ZoomFactor = 1.0!
        CustomSpdHeader5.Name = "CustomSpdHeader5"
        CustomSpdHeader5.PictureZoomEffect = False
        CustomSpdHeader5.TextRotationAngle = 0R
        CustomSpdHeader5.ZoomFactor = 1.0!
        CustomSpdHeader6.Name = "CustomSpdHeader6"
        CustomSpdHeader6.PictureZoomEffect = False
        CustomSpdHeader6.TextRotationAngle = 0R
        CustomSpdHeader6.ZoomFactor = 1.0!
        CustomSpdHeader7.Name = "CustomSpdHeader7"
        CustomSpdHeader7.PictureZoomEffect = False
        CustomSpdHeader7.TextRotationAngle = 0R
        CustomSpdHeader7.ZoomFactor = 1.0!
        CustomSpdHeader8.Name = "CustomSpdHeader8"
        CustomSpdHeader8.PictureZoomEffect = False
        CustomSpdHeader8.TextRotationAngle = 0R
        CustomSpdHeader8.ZoomFactor = 1.0!
        CustomSpdHeader9.Name = "CustomSpdHeader9"
        CustomSpdHeader9.PictureZoomEffect = False
        CustomSpdHeader9.TextRotationAngle = 0R
        CustomSpdHeader9.ZoomFactor = 1.0!
        CustomSpdHeader10.Name = "CustomSpdHeader10"
        CustomSpdHeader10.PictureZoomEffect = False
        CustomSpdHeader10.TextRotationAngle = 0R
        CustomSpdHeader10.ZoomFactor = 1.0!
        CustomSpdHeader11.Name = "CustomSpdHeader11"
        CustomSpdHeader11.PictureZoomEffect = False
        CustomSpdHeader11.TextRotationAngle = 0R
        CustomSpdHeader11.ZoomFactor = 1.0!
        CustomSpdHeader12.Name = "CustomSpdHeader12"
        CustomSpdHeader12.PictureZoomEffect = False
        CustomSpdHeader12.TextRotationAngle = 0R
        CustomSpdHeader12.ZoomFactor = 1.0!
        CustomSpdHeader13.Name = "CustomSpdHeader13"
        CustomSpdHeader13.PictureZoomEffect = False
        CustomSpdHeader13.TextRotationAngle = 0R
        CustomSpdHeader13.ZoomFactor = 1.0!
        CustomSpdHeader14.Name = "CustomSpdHeader14"
        CustomSpdHeader14.PictureZoomEffect = False
        CustomSpdHeader14.TextRotationAngle = 0R
        CustomSpdHeader14.ZoomFactor = 1.0!
        CustomSpdHeader15.Name = "CustomSpdHeader15"
        CustomSpdHeader15.PictureZoomEffect = False
        CustomSpdHeader15.TextRotationAngle = 0R
        CustomSpdHeader15.ZoomFactor = 1.0!
        CustomSpdHeader16.Name = "CustomSpdHeader16"
        CustomSpdHeader16.PictureZoomEffect = False
        CustomSpdHeader16.TextRotationAngle = 0R
        CustomSpdHeader16.ZoomFactor = 1.0!
        CustomSpdHeader17.Name = "CustomSpdHeader17"
        CustomSpdHeader17.PictureZoomEffect = False
        CustomSpdHeader17.TextRotationAngle = 0R
        CustomSpdHeader17.ZoomFactor = 1.0!
        CustomSpdHeader18.Name = "CustomSpdHeader18"
        CustomSpdHeader18.PictureZoomEffect = False
        CustomSpdHeader18.TextRotationAngle = 0R
        CustomSpdHeader18.ZoomFactor = 1.0!
        CustomSpdHeader19.Name = "CustomSpdHeader19"
        CustomSpdHeader19.PictureZoomEffect = False
        CustomSpdHeader19.TextRotationAngle = 0R
        CustomSpdHeader19.ZoomFactor = 1.0!
        CustomSpdHeader20.Name = "CustomSpdHeader20"
        CustomSpdHeader20.PictureZoomEffect = False
        CustomSpdHeader20.TextRotationAngle = 0R
        CustomSpdHeader20.ZoomFactor = 1.0!
        '
        '_Picture2_1
        '
        Me._Picture2_1.BackColor = System.Drawing.SystemColors.Window
        Me._Picture2_1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me._Picture2_1.Controls.Add(Me._Command1_9)
        Me._Picture2_1.Controls.Add(Me._Command1_8)
        Me._Picture2_1.Controls.Add(Me._Command1_7)
        Me._Picture2_1.Controls.Add(Me._Command1_6)
        Me._Picture2_1.Controls.Add(Me._Command1_5)
        Me._Picture2_1.Cursor = System.Windows.Forms.Cursors.Default
        Me._Picture2_1.ForeColor = System.Drawing.SystemColors.WindowText
        Me._Picture2_1.Location = New System.Drawing.Point(693, 50)
        Me._Picture2_1.Name = "_Picture2_1"
        Me._Picture2_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Picture2_1.Size = New System.Drawing.Size(290, 39)
        Me._Picture2_1.TabIndex = 25
        '
        '_Command1_9
        '
        Me._Command1_9.BackColor = System.Drawing.SystemColors.Control
        Me._Command1_9.Cursor = System.Windows.Forms.Cursors.Default
        Me._Command1_9.Font = New System.Drawing.Font("MS Mincho", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Command1_9.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Command1_9.Location = New System.Drawing.Point(0, 19)
        Me._Command1_9.Margin = New System.Windows.Forms.Padding(0)
        Me._Command1_9.Name = "_Command1_9"
        Me._Command1_9.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Command1_9.Size = New System.Drawing.Size(75, 19)
        Me._Command1_9.TabIndex = 30
        Me._Command1_9.TabStop = False
        Me._Command1_9.Text = "����"
        Me._Command1_9.UseVisualStyleBackColor = False
        '
        '_Command1_8
        '
        Me._Command1_8.BackColor = System.Drawing.SystemColors.Control
        Me._Command1_8.Cursor = System.Windows.Forms.Cursors.Default
        Me._Command1_8.Font = New System.Drawing.Font("MS Mincho", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Command1_8.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Command1_8.Location = New System.Drawing.Point(0, 0)
        Me._Command1_8.Margin = New System.Windows.Forms.Padding(0)
        Me._Command1_8.Name = "_Command1_8"
        Me._Command1_8.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Command1_8.Size = New System.Drawing.Size(289, 19)
        Me._Command1_8.TabIndex = 29
        Me._Command1_8.TabStop = False
        Me._Command1_8.Text = "��� ���� ��ɗ\��"
        Me._Command1_8.UseVisualStyleBackColor = False
        '
        '_Command1_7
        '
        Me._Command1_7.BackColor = System.Drawing.SystemColors.Control
        Me._Command1_7.Cursor = System.Windows.Forms.Cursors.Default
        Me._Command1_7.Font = New System.Drawing.Font("MS Mincho", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Command1_7.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Command1_7.Location = New System.Drawing.Point(75, 19)
        Me._Command1_7.Margin = New System.Windows.Forms.Padding(0)
        Me._Command1_7.Name = "_Command1_7"
        Me._Command1_7.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Command1_7.Size = New System.Drawing.Size(40, 19)
        Me._Command1_7.TabIndex = 28
        Me._Command1_7.TabStop = False
        Me._Command1_7.Text = "�P��"
        Me._Command1_7.UseVisualStyleBackColor = False
        '
        '_Command1_6
        '
        Me._Command1_6.BackColor = System.Drawing.SystemColors.Control
        Me._Command1_6.Cursor = System.Windows.Forms.Cursors.Default
        Me._Command1_6.Font = New System.Drawing.Font("MS Mincho", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Command1_6.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Command1_6.Location = New System.Drawing.Point(115, 19)
        Me._Command1_6.Margin = New System.Windows.Forms.Padding(0)
        Me._Command1_6.Name = "_Command1_6"
        Me._Command1_6.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Command1_6.Size = New System.Drawing.Size(78, 19)
        Me._Command1_6.TabIndex = 27
        Me._Command1_6.TabStop = False
        Me._Command1_6.Text = "�P ��"
        Me._Command1_6.UseVisualStyleBackColor = False
        '
        '_Command1_5
        '
        Me._Command1_5.BackColor = System.Drawing.SystemColors.Control
        Me._Command1_5.Cursor = System.Windows.Forms.Cursors.Default
        Me._Command1_5.Font = New System.Drawing.Font("MS Mincho", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Command1_5.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Command1_5.Location = New System.Drawing.Point(193, 19)
        Me._Command1_5.Margin = New System.Windows.Forms.Padding(0)
        Me._Command1_5.Name = "_Command1_5"
        Me._Command1_5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Command1_5.Size = New System.Drawing.Size(96, 19)
        Me._Command1_5.TabIndex = 26
        Me._Command1_5.TabStop = False
        Me._Command1_5.Text = "�� �z"
        Me._Command1_5.UseVisualStyleBackColor = False
        '
        '_Picture2_0
        '
        Me._Picture2_0.BackColor = System.Drawing.SystemColors.Window
        Me._Picture2_0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me._Picture2_0.Controls.Add(Me._Command1_4)
        Me._Picture2_0.Controls.Add(Me._Command1_3)
        Me._Picture2_0.Controls.Add(Me._Command1_2)
        Me._Picture2_0.Controls.Add(Me._Command1_0)
        Me._Picture2_0.Controls.Add(Me._Command1_1)
        Me._Picture2_0.Cursor = System.Windows.Forms.Cursors.Default
        Me._Picture2_0.ForeColor = System.Drawing.SystemColors.WindowText
        Me._Picture2_0.Location = New System.Drawing.Point(410, 50)
        Me._Picture2_0.Name = "_Picture2_0"
        Me._Picture2_0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Picture2_0.Size = New System.Drawing.Size(283, 39)
        Me._Picture2_0.TabIndex = 19
        '
        '_Command1_4
        '
        Me._Command1_4.BackColor = System.Drawing.SystemColors.Control
        Me._Command1_4.Cursor = System.Windows.Forms.Cursors.Default
        Me._Command1_4.Font = New System.Drawing.Font("MS Mincho", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Command1_4.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Command1_4.Location = New System.Drawing.Point(190, 19)
        Me._Command1_4.Margin = New System.Windows.Forms.Padding(0)
        Me._Command1_4.Name = "_Command1_4"
        Me._Command1_4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Command1_4.Size = New System.Drawing.Size(92, 19)
        Me._Command1_4.TabIndex = 24
        Me._Command1_4.TabStop = False
        Me._Command1_4.Text = "�� �z"
        Me._Command1_4.UseVisualStyleBackColor = False
        '
        '_Command1_3
        '
        Me._Command1_3.BackColor = System.Drawing.SystemColors.Control
        Me._Command1_3.Cursor = System.Windows.Forms.Cursors.Default
        Me._Command1_3.Font = New System.Drawing.Font("MS Mincho", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Command1_3.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Command1_3.Location = New System.Drawing.Point(114, 19)
        Me._Command1_3.Margin = New System.Windows.Forms.Padding(0)
        Me._Command1_3.Name = "_Command1_3"
        Me._Command1_3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Command1_3.Size = New System.Drawing.Size(76, 19)
        Me._Command1_3.TabIndex = 23
        Me._Command1_3.TabStop = False
        Me._Command1_3.Text = "�P ��"
        Me._Command1_3.UseVisualStyleBackColor = False
        '
        '_Command1_2
        '
        Me._Command1_2.BackColor = System.Drawing.SystemColors.Control
        Me._Command1_2.Cursor = System.Windows.Forms.Cursors.Default
        Me._Command1_2.Font = New System.Drawing.Font("MS Mincho", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Command1_2.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Command1_2.Location = New System.Drawing.Point(74, 19)
        Me._Command1_2.Margin = New System.Windows.Forms.Padding(0)
        Me._Command1_2.Name = "_Command1_2"
        Me._Command1_2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Command1_2.Size = New System.Drawing.Size(40, 19)
        Me._Command1_2.TabIndex = 22
        Me._Command1_2.TabStop = False
        Me._Command1_2.Text = "�P��"
        Me._Command1_2.UseVisualStyleBackColor = False
        '
        '_Command1_0
        '
        Me._Command1_0.BackColor = System.Drawing.SystemColors.Control
        Me._Command1_0.Cursor = System.Windows.Forms.Cursors.Default
        Me._Command1_0.Font = New System.Drawing.Font("MS Mincho", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Command1_0.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Command1_0.Location = New System.Drawing.Point(0, 0)
        Me._Command1_0.Margin = New System.Windows.Forms.Padding(0)
        Me._Command1_0.Name = "_Command1_0"
        Me._Command1_0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Command1_0.Size = New System.Drawing.Size(282, 19)
        Me._Command1_0.TabIndex = 21
        Me._Command1_0.TabStop = False
        Me._Command1_0.Text = "���@�s�@�\�@�Z"
        Me._Command1_0.UseVisualStyleBackColor = False
        '
        '_Command1_1
        '
        Me._Command1_1.BackColor = System.Drawing.SystemColors.Control
        Me._Command1_1.Cursor = System.Windows.Forms.Cursors.Default
        Me._Command1_1.Font = New System.Drawing.Font("MS Mincho", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Command1_1.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Command1_1.Location = New System.Drawing.Point(0, 19)
        Me._Command1_1.Margin = New System.Windows.Forms.Padding(0)
        Me._Command1_1.Name = "_Command1_1"
        Me._Command1_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Command1_1.Size = New System.Drawing.Size(74, 19)
        Me._Command1_1.TabIndex = 20
        Me._Command1_1.TabStop = False
        Me._Command1_1.Text = "����"
        Me._Command1_1.UseVisualStyleBackColor = False
        '
        'Picture1
        '
        Me.Picture1.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Picture1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Picture1.Controls.Add(Me._cmdKey_3)
        Me.Picture1.Controls.Add(Me._cmdKey_12)
        Me.Picture1.Controls.Add(Me._cmdKey_4)
        Me.Picture1.Controls.Add(Me._cmdKey_10)
        Me.Picture1.Controls.Add(Me._cmdKey_6)
        Me.Picture1.Controls.Add(Me._cmdKey_7)
        Me.Picture1.Controls.Add(Me._cmdKey_8)
        Me.Picture1.Controls.Add(Me._cmdKey_9)
        Me.Picture1.Controls.Add(Me._cmdKey_1)
        Me.Picture1.Controls.Add(Me._cmdKey_11)
        Me.Picture1.Controls.Add(Me._cmdKey_2)
        Me.Picture1.Controls.Add(Me._cmdKey_5)
        Me.Picture1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Picture1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Picture1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Picture1.Location = New System.Drawing.Point(0, 668)
        Me.Picture1.Name = "Picture1"
        Me.Picture1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Picture1.Size = New System.Drawing.Size(1016, 51)
        Me.Picture1.TabIndex = 11
        '
        '_cmdKey_3
        '
        Me._cmdKey_3.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_3.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_3.Enabled = False
        Me._cmdKey_3.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_3.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_3.Location = New System.Drawing.Point(166, 4)
        Me._cmdKey_3.Name = "_cmdKey_3"
        Me._cmdKey_3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_3.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_3.TabIndex = 2
        Me._cmdKey_3.Tag = "�I���f�[�^���폜���܂��B"
        Me._cmdKey_3.Text = "F3"
        Me._cmdKey_3.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_3.UseVisualStyleBackColor = False
        '
        '_cmdKey_12
        '
        Me._cmdKey_12.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_12.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_12.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_12.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_12.Location = New System.Drawing.Point(929, 4)
        Me._cmdKey_12.Name = "_cmdKey_12"
        Me._cmdKey_12.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_12.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_12.TabIndex = 13
        Me._cmdKey_12.Tag = "�Ǎ��ݏ����𒆎~���܂��B"
        Me._cmdKey_12.Text = "F12" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "�� �~"
        Me._cmdKey_12.UseVisualStyleBackColor = False
        '
        '_cmdKey_4
        '
        Me._cmdKey_4.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_4.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_4.Enabled = False
        Me._cmdKey_4.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_4.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_4.Location = New System.Drawing.Point(246, 4)
        Me._cmdKey_4.Name = "_cmdKey_4"
        Me._cmdKey_4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_4.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_4.TabIndex = 3
        Me._cmdKey_4.Text = "F4"
        Me._cmdKey_4.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_4.UseVisualStyleBackColor = False
        '
        '_cmdKey_10
        '
        Me._cmdKey_10.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_10.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_10.Enabled = False
        Me._cmdKey_10.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_10.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_10.Location = New System.Drawing.Point(769, 4)
        Me._cmdKey_10.Name = "_cmdKey_10"
        Me._cmdKey_10.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_10.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_10.TabIndex = 9
        Me._cmdKey_10.Text = "F10"
        Me._cmdKey_10.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_10.UseVisualStyleBackColor = False
        '
        '_cmdKey_6
        '
        Me._cmdKey_6.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_6.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_6.Enabled = False
        Me._cmdKey_6.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_6.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_6.Location = New System.Drawing.Point(428, 4)
        Me._cmdKey_6.Name = "_cmdKey_6"
        Me._cmdKey_6.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_6.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_6.TabIndex = 5
        Me._cmdKey_6.Text = "F6"
        Me._cmdKey_6.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_6.UseVisualStyleBackColor = False
        '
        '_cmdKey_7
        '
        Me._cmdKey_7.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_7.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_7.Enabled = False
        Me._cmdKey_7.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_7.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_7.Location = New System.Drawing.Point(508, 4)
        Me._cmdKey_7.Name = "_cmdKey_7"
        Me._cmdKey_7.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_7.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_7.TabIndex = 6
        Me._cmdKey_7.Text = "F7"
        Me._cmdKey_7.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_7.UseVisualStyleBackColor = False
        '
        '_cmdKey_8
        '
        Me._cmdKey_8.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_8.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_8.Enabled = False
        Me._cmdKey_8.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_8.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_8.Location = New System.Drawing.Point(588, 4)
        Me._cmdKey_8.Name = "_cmdKey_8"
        Me._cmdKey_8.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_8.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_8.TabIndex = 7
        Me._cmdKey_8.Text = "F8"
        Me._cmdKey_8.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_8.UseVisualStyleBackColor = False
        '
        '_cmdKey_9
        '
        Me._cmdKey_9.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_9.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_9.Enabled = False
        Me._cmdKey_9.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_9.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_9.Location = New System.Drawing.Point(689, 4)
        Me._cmdKey_9.Name = "_cmdKey_9"
        Me._cmdKey_9.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_9.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_9.TabIndex = 8
        Me._cmdKey_9.Text = "F9"
        Me._cmdKey_9.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_9.UseVisualStyleBackColor = False
        '
        '_cmdKey_1
        '
        Me._cmdKey_1.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_1.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_1.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_1.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_1.Location = New System.Drawing.Point(6, 4)
        Me._cmdKey_1.Name = "_cmdKey_1"
        Me._cmdKey_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_1.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_1.TabIndex = 1
        Me._cmdKey_1.Tag = "�Ǎ��݃f�[�^���m�肵�܂��B"
        Me._cmdKey_1.Text = "F1" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "�m ��"
        Me._cmdKey_1.UseVisualStyleBackColor = False
        '
        '_cmdKey_11
        '
        Me._cmdKey_11.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_11.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_11.Enabled = False
        Me._cmdKey_11.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_11.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_11.Location = New System.Drawing.Point(849, 4)
        Me._cmdKey_11.Name = "_cmdKey_11"
        Me._cmdKey_11.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_11.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_11.TabIndex = 10
        Me._cmdKey_11.Text = "F11"
        Me._cmdKey_11.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_11.UseVisualStyleBackColor = False
        '
        '_cmdKey_2
        '
        Me._cmdKey_2.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_2.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_2.Enabled = False
        Me._cmdKey_2.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_2.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_2.Location = New System.Drawing.Point(86, 4)
        Me._cmdKey_2.Name = "_cmdKey_2"
        Me._cmdKey_2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_2.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_2.TabIndex = 1
        Me._cmdKey_2.Tag = "�I���f�[�^���C�����܂��B"
        Me._cmdKey_2.Text = "F2"
        Me._cmdKey_2.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_2.UseVisualStyleBackColor = False
        '
        '_cmdKey_5
        '
        Me._cmdKey_5.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_5.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_5.Enabled = False
        Me._cmdKey_5.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_5.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_5.Location = New System.Drawing.Point(348, 4)
        Me._cmdKey_5.Name = "_cmdKey_5"
        Me._cmdKey_5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_5.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_5.TabIndex = 4
        Me._cmdKey_5.Tag = "�f�[�^��}�����܂��B"
        Me._cmdKey_5.Text = "F5"
        Me._cmdKey_5.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_5.UseVisualStyleBackColor = False
        '
        'StatusBar1
        '
        Me.StatusBar1.Font = New System.Drawing.Font("MS Mincho", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.StatusBar1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me._StatusBar1_Panel1, Me.Message})
        Me.StatusBar1.Location = New System.Drawing.Point(0, 719)
        Me.StatusBar1.Name = "StatusBar1"
        Me.StatusBar1.Size = New System.Drawing.Size(1016, 23)
        Me.StatusBar1.SizingGrip = False
        Me.StatusBar1.TabIndex = 13
        '
        '_StatusBar1_Panel1
        '
        Me._StatusBar1_Panel1.AutoSize = False
        Me._StatusBar1_Panel1.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me._StatusBar1_Panel1.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter
        Me._StatusBar1_Panel1.Margin = New System.Windows.Forms.Padding(0)
        Me._StatusBar1_Panel1.Name = "_StatusBar1_Panel1"
        Me._StatusBar1_Panel1.Size = New System.Drawing.Size(117, 23)
        '
        'Message
        '
        Me.Message.AutoSize = False
        Me.Message.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me.Message.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter
        Me.Message.Margin = New System.Windows.Forms.Padding(0)
        Me.Message.Name = "Message"
        Me.Message.Size = New System.Drawing.Size(894, 23)
        Me.Message.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        '_imText2_2
        '
        Me._imText2_2.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me._imText2_2.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._imText2_2.Location = New System.Drawing.Point(576, 6)
        Me._imText2_2.Name = "_imText2_2"
        Me._imText2_2.ReadOnly = True
        Me._imText2_2.Size = New System.Drawing.Size(433, 23)
        Me._imText2_2.TabIndex = 15
        Me._imText2_2.TabStop = False
        '
        '_imText2_0
        '
        Me._imText2_0.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me._imText2_0.ContentAlignment = System.Drawing.ContentAlignment.TopCenter
        Me._imText2_0.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._imText2_0.Location = New System.Drawing.Point(440, 6)
        Me._imText2_0.Name = "_imText2_0"
        Me._imText2_0.ReadOnly = True
        Me._imText2_0.Size = New System.Drawing.Size(83, 23)
        Me._imText2_0.TabIndex = 16
        Me._imText2_0.TabStop = False
        '
        '_imText2_1
        '
        Me._imText2_1.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me._imText2_1.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._imText2_1.Location = New System.Drawing.Point(527, 6)
        Me._imText2_1.Name = "_imText2_1"
        Me._imText2_1.ReadOnly = True
        Me._imText2_1.Size = New System.Drawing.Size(45, 23)
        Me._imText2_1.TabIndex = 17
        Me._imText2_1.TabStop = False
        '
        'lblTitle
        '
        Me.lblTitle.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblTitle.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTitle.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblTitle.Font = New System.Drawing.Font("MS Mincho", 20.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblTitle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.lblTitle.Location = New System.Drawing.Point(0, 0)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblTitle.Size = New System.Drawing.Size(1015, 34)
        Me.lblTitle.TabIndex = 14
        Me.lblTitle.Text = " �e�L�X�g�Ǎ��ݏ��m�F"
        '
        'vaSpread1
        '
        Me.vaSpread1.AccessibleDescription = "vaSpread1, Sheet1, Row 0, Column 0"
        Me.vaSpread1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.vaSpread1.FocusRenderer = DefaultFocusIndicatorRenderer1
        Me.vaSpread1.HorizontalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.vaSpread1.HorizontalScrollBar.Name = ""
        Me.vaSpread1.HorizontalScrollBar.Renderer = DefaultScrollBarRenderer1
        Me.vaSpread1.HorizontalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.Never
        Me.vaSpread1.Location = New System.Drawing.Point(9, 50)
        Me.vaSpread1.Margin = New System.Windows.Forms.Padding(0)
        Me.vaSpread1.Name = "vaSpread1"
        NamedStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        NamedStyle1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        NamedStyle1.Locked = False
        NamedStyle2.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        NamedStyle2.Font = New System.Drawing.Font("MS Mincho", 11.0!, System.Drawing.FontStyle.Bold)
        NamedStyle2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        NamedStyle2.Locked = False
        Me.vaSpread1.RowSplitBoxPolicy = FarPoint.Win.Spread.SplitBoxPolicy.Never
        Me.vaSpread1.ScrollBarTrackPolicy = FarPoint.Win.Spread.ScrollBarTrackPolicy.Vertical
        Me.vaSpread1.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.vaSpread1_Sheet1})
        Me.vaSpread1.Size = New System.Drawing.Size(995, 581)
        Me.vaSpread1.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Classic
        Me.vaSpread1.NamedStyles.AddRange(New FarPoint.Win.Spread.NamedStyle() {NamedStyle1, NamedStyle2})
        Me.vaSpread1.TabIndex = 13
        Me.vaSpread1.Tag = "�f�[�^��I�����ĉ������B"
        TipAppearance1.BackColor = System.Drawing.SystemColors.Info
        TipAppearance1.Font = New System.Drawing.Font("MS PMincho", 9.0!)
        TipAppearance1.ForeColor = System.Drawing.SystemColors.InfoText
        Me.vaSpread1.TextTipAppearance = TipAppearance1
        Me.vaSpread1.VerticalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.vaSpread1.VerticalScrollBar.Name = ""
        Me.vaSpread1.VerticalScrollBar.Renderer = DefaultScrollBarRenderer2
        Me.vaSpread1.VerticalScrollBarWidth = 20
        Me.vaSpread1.VisualStyles = FarPoint.Win.VisualStyles.Off
        '
        'vaSpread1_Sheet1
        '
        Me.vaSpread1_Sheet1.Reset()
        Me.vaSpread1_Sheet1.SheetName = "Sheet1"
        'Formulas and custom names must be loaded with R1C1 reference style
        Me.vaSpread1_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1
        Me.vaSpread1_Sheet1.ColumnCount = 10
        Me.vaSpread1_Sheet1.RowCount = 100
        Me.vaSpread1_Sheet1.ActiveSkin = FarPoint.Win.Spread.DefaultSkins.Default
        TextCellType1.Static = True
        Me.vaSpread1_Sheet1.Cells.Get(0, 0).CellType = TextCellType1
        Me.vaSpread1_Sheet1.Cells.Get(0, 0).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.vaSpread1_Sheet1.Cells.Get(0, 0).TabStop = True
        Me.vaSpread1_Sheet1.Cells.Get(0, 0).Tag = "�f�[�^��I�����ĉ������B"
        Me.vaSpread1_Sheet1.Cells.Get(0, 0).Value = "Z-99"
        Me.vaSpread1_Sheet1.Cells.Get(0, 0).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        TextCellType2.Static = True
        Me.vaSpread1_Sheet1.Cells.Get(0, 1).CellType = TextCellType2
        Me.vaSpread1_Sheet1.Cells.Get(0, 1).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Left
        Me.vaSpread1_Sheet1.Cells.Get(0, 1).Value = "1234567890123456789012345678901234567890"
        Me.vaSpread1_Sheet1.Cells.Get(0, 1).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        TextCellType3.Static = True
        Me.vaSpread1_Sheet1.Cells.Get(0, 2).CellType = TextCellType3
        Me.vaSpread1_Sheet1.Cells.Get(0, 2).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Right
        Me.vaSpread1_Sheet1.Cells.Get(0, 2).Value = "99,999.99"
        Me.vaSpread1_Sheet1.Cells.Get(0, 2).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        TextCellType4.Static = True
        Me.vaSpread1_Sheet1.Cells.Get(0, 3).CellType = TextCellType4
        Me.vaSpread1_Sheet1.Cells.Get(0, 3).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.vaSpread1_Sheet1.Cells.Get(0, 3).Value = "1234"
        Me.vaSpread1_Sheet1.Cells.Get(0, 3).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.vaSpread1_Sheet1.Cells.Get(0, 4).CellType = TextCellType3
        Me.vaSpread1_Sheet1.Cells.Get(0, 4).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Right
        Me.vaSpread1_Sheet1.Cells.Get(0, 4).Value = "9,999,999"
        Me.vaSpread1_Sheet1.Cells.Get(0, 4).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.vaSpread1_Sheet1.Cells.Get(0, 5).CellType = TextCellType3
        Me.vaSpread1_Sheet1.Cells.Get(0, 5).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Right
        Me.vaSpread1_Sheet1.Cells.Get(0, 5).Value = "999,999,999"
        Me.vaSpread1_Sheet1.Cells.Get(0, 5).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.vaSpread1_Sheet1.Cells.Get(0, 6).CellType = TextCellType3
        Me.vaSpread1_Sheet1.Cells.Get(0, 6).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Right
        Me.vaSpread1_Sheet1.Cells.Get(0, 6).Value = "99,999.99"
        Me.vaSpread1_Sheet1.Cells.Get(0, 6).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.vaSpread1_Sheet1.Cells.Get(0, 7).CellType = TextCellType4
        Me.vaSpread1_Sheet1.Cells.Get(0, 7).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.vaSpread1_Sheet1.Cells.Get(0, 7).Value = "1234"
        Me.vaSpread1_Sheet1.Cells.Get(0, 7).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.vaSpread1_Sheet1.Cells.Get(0, 8).CellType = TextCellType3
        Me.vaSpread1_Sheet1.Cells.Get(0, 8).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Right
        Me.vaSpread1_Sheet1.Cells.Get(0, 8).Value = "9,999,999"
        Me.vaSpread1_Sheet1.Cells.Get(0, 8).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.vaSpread1_Sheet1.Cells.Get(0, 9).CellType = TextCellType3
        Me.vaSpread1_Sheet1.Cells.Get(0, 9).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Right
        Me.vaSpread1_Sheet1.Cells.Get(0, 9).Value = "999,999,999"
        Me.vaSpread1_Sheet1.Cells.Get(0, 9).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.vaSpread1_Sheet1.Cells.Get(1, 1).CellType = TextCellType2
        Me.vaSpread1_Sheet1.Cells.Get(1, 1).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Left
        Me.vaSpread1_Sheet1.Cells.Get(1, 1).Value = "�P�Q�R�S�T�U�V�W�X�O�P�Q�R�S�T�U�V�W�X�O"
        Me.vaSpread1_Sheet1.Cells.Get(1, 1).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.vaSpread1_Sheet1.Cells.Get(1, 2).Value = "1"
        Me.vaSpread1_Sheet1.Cells.Get(1, 3).Value = "��"
        Me.vaSpread1_Sheet1.Cells.Get(1, 5).Value = "30,000"
        Me.vaSpread1_Sheet1.Cells.Get(1, 6).Value = "1"
        Me.vaSpread1_Sheet1.Cells.Get(1, 7).Value = "��"
        Me.vaSpread1_Sheet1.Cells.Get(1, 9).Value = "30,000"
        Me.vaSpread1_Sheet1.Cells.Get(2, 1).Value = "���i��"
        Me.vaSpread1_Sheet1.Cells.Get(2, 2).Value = "1"
        Me.vaSpread1_Sheet1.Cells.Get(2, 3).Value = "��"
        Me.vaSpread1_Sheet1.Cells.Get(2, 4).Value = "1,950"
        Me.vaSpread1_Sheet1.Cells.Get(2, 5).Value = "1,950"
        Me.vaSpread1_Sheet1.Cells.Get(2, 6).Value = "1"
        Me.vaSpread1_Sheet1.Cells.Get(2, 7).Value = "��"
        Me.vaSpread1_Sheet1.Cells.Get(2, 8).Value = "1,950"
        Me.vaSpread1_Sheet1.Cells.Get(2, 9).Value = "1,950"
        Me.vaSpread1_Sheet1.Cells.Get(3, 1).Value = "���i��"
        Me.vaSpread1_Sheet1.Cells.Get(3, 3).Value = "��"
        Me.vaSpread1_Sheet1.Cells.Get(3, 5).Value = "0"
        Me.vaSpread1_Sheet1.Cells.Get(3, 7).Value = "��"
        Me.vaSpread1_Sheet1.Cells.Get(3, 9).Value = "0"
        Me.vaSpread1_Sheet1.Cells.Get(4, 1).Value = "���i��"
        Me.vaSpread1_Sheet1.Cells.Get(4, 2).Value = "3"
        Me.vaSpread1_Sheet1.Cells.Get(4, 3).Value = "��"
        Me.vaSpread1_Sheet1.Cells.Get(4, 4).Value = "1,170"
        Me.vaSpread1_Sheet1.Cells.Get(4, 5).Value = "3,510"
        Me.vaSpread1_Sheet1.Cells.Get(4, 6).Value = "3"
        Me.vaSpread1_Sheet1.Cells.Get(4, 7).Value = "��"
        Me.vaSpread1_Sheet1.Cells.Get(4, 8).Value = "1,170"
        Me.vaSpread1_Sheet1.Cells.Get(4, 9).Value = "3,510"
        Me.vaSpread1_Sheet1.Cells.Get(5, 1).Value = "���i��"
        Me.vaSpread1_Sheet1.Cells.Get(5, 2).Value = "1"
        Me.vaSpread1_Sheet1.Cells.Get(5, 3).Value = "��"
        Me.vaSpread1_Sheet1.Cells.Get(5, 4).Value = "630"
        Me.vaSpread1_Sheet1.Cells.Get(5, 5).Value = "630"
        Me.vaSpread1_Sheet1.Cells.Get(5, 6).Value = "1"
        Me.vaSpread1_Sheet1.Cells.Get(5, 7).Value = "��"
        Me.vaSpread1_Sheet1.Cells.Get(5, 8).Value = "630"
        Me.vaSpread1_Sheet1.Cells.Get(5, 9).Value = "630"
        Me.vaSpread1_Sheet1.Cells.Get(6, 1).Value = "���i��"
        Me.vaSpread1_Sheet1.Cells.Get(6, 2).Value = "6"
        Me.vaSpread1_Sheet1.Cells.Get(6, 3).Value = "��"
        Me.vaSpread1_Sheet1.Cells.Get(6, 4).Value = "315"
        Me.vaSpread1_Sheet1.Cells.Get(6, 5).Value = "1,890"
        Me.vaSpread1_Sheet1.Cells.Get(6, 6).Value = "6"
        Me.vaSpread1_Sheet1.Cells.Get(6, 7).Value = "��"
        Me.vaSpread1_Sheet1.Cells.Get(6, 8).Value = "315"
        Me.vaSpread1_Sheet1.Cells.Get(6, 9).Value = "1,890"
        Me.vaSpread1_Sheet1.Cells.Get(7, 1).Value = "���i��"
        Me.vaSpread1_Sheet1.Cells.Get(7, 2).Value = "1"
        Me.vaSpread1_Sheet1.Cells.Get(7, 3).Value = "��"
        Me.vaSpread1_Sheet1.Cells.Get(7, 4).Value = "1,560"
        Me.vaSpread1_Sheet1.Cells.Get(7, 5).Value = "1,560"
        Me.vaSpread1_Sheet1.Cells.Get(7, 6).Value = "1"
        Me.vaSpread1_Sheet1.Cells.Get(7, 7).Value = "��"
        Me.vaSpread1_Sheet1.Cells.Get(7, 8).Value = "1,560"
        Me.vaSpread1_Sheet1.Cells.Get(7, 9).Value = "1,560"
        Me.vaSpread1_Sheet1.Cells.Get(8, 1).Value = "���i��"
        Me.vaSpread1_Sheet1.Cells.Get(8, 2).Value = "1"
        Me.vaSpread1_Sheet1.Cells.Get(8, 3).Value = "��"
        Me.vaSpread1_Sheet1.Cells.Get(8, 4).Value = "7,020"
        Me.vaSpread1_Sheet1.Cells.Get(8, 5).Value = "7,020"
        Me.vaSpread1_Sheet1.Cells.Get(8, 6).Value = "1"
        Me.vaSpread1_Sheet1.Cells.Get(8, 7).Value = "��"
        Me.vaSpread1_Sheet1.Cells.Get(8, 8).Value = "7,020"
        Me.vaSpread1_Sheet1.Cells.Get(8, 9).Value = "7,020"
        Me.vaSpread1_Sheet1.Cells.Get(9, 1).Value = "���i��"
        Me.vaSpread1_Sheet1.Cells.Get(9, 3).Value = "��"
        Me.vaSpread1_Sheet1.Cells.Get(9, 5).Value = "0"
        Me.vaSpread1_Sheet1.Cells.Get(9, 7).Value = "��"
        Me.vaSpread1_Sheet1.Cells.Get(9, 9).Value = "0"
        Me.vaSpread1_Sheet1.Cells.Get(10, 1).Value = "���i��"
        Me.vaSpread1_Sheet1.Cells.Get(10, 2).Value = "1"
        Me.vaSpread1_Sheet1.Cells.Get(10, 3).Value = "��"
        Me.vaSpread1_Sheet1.Cells.Get(10, 5).Value = "0"
        Me.vaSpread1_Sheet1.Cells.Get(10, 6).Value = "1"
        Me.vaSpread1_Sheet1.Cells.Get(10, 7).Value = "��"
        Me.vaSpread1_Sheet1.Cells.Get(10, 9).Value = "0"
        Me.vaSpread1_Sheet1.Cells.Get(11, 1).Value = "���ݕ֏�"
        Me.vaSpread1_Sheet1.Cells.Get(11, 2).Value = "3"
        Me.vaSpread1_Sheet1.Cells.Get(11, 3).Value = "����"
        Me.vaSpread1_Sheet1.Cells.Get(11, 5).Value = "0"
        Me.vaSpread1_Sheet1.Cells.Get(11, 6).Value = "3"
        Me.vaSpread1_Sheet1.Cells.Get(11, 7).Value = "����"
        Me.vaSpread1_Sheet1.Cells.Get(11, 9).Value = "0"
        Me.vaSpread1_Sheet1.Cells.Get(12, 1).Value = "�^����"
        Me.vaSpread1_Sheet1.Cells.Get(12, 2).Value = "1"
        Me.vaSpread1_Sheet1.Cells.Get(12, 3).Value = "��"
        Me.vaSpread1_Sheet1.Cells.Get(12, 5).Value = "0"
        Me.vaSpread1_Sheet1.Cells.Get(12, 6).Value = "1"
        Me.vaSpread1_Sheet1.Cells.Get(12, 7).Value = "��"
        Me.vaSpread1_Sheet1.Cells.Get(12, 9).Value = "0"
        Me.vaSpread1_Sheet1.Cells.Get(13, 1).Value = "�g�[�ݔ�"
        Me.vaSpread1_Sheet1.Cells.Get(13, 3).Value = "��"
        Me.vaSpread1_Sheet1.Cells.Get(13, 5).Value = "0"
        Me.vaSpread1_Sheet1.Cells.Get(13, 7).Value = "��"
        Me.vaSpread1_Sheet1.Cells.Get(13, 9).Value = "0"
        Me.vaSpread1_Sheet1.Cells.Get(14, 1).Value = "�g�[�ݔ�"
        Me.vaSpread1_Sheet1.Cells.Get(14, 2).Value = "1"
        Me.vaSpread1_Sheet1.Cells.Get(14, 3).Value = "��"
        Me.vaSpread1_Sheet1.Cells.Get(14, 4).Value = "2,340"
        Me.vaSpread1_Sheet1.Cells.Get(14, 5).Value = "2,340"
        Me.vaSpread1_Sheet1.Cells.Get(14, 6).Value = "1"
        Me.vaSpread1_Sheet1.Cells.Get(14, 7).Value = "��"
        Me.vaSpread1_Sheet1.Cells.Get(14, 8).Value = "2,340"
        Me.vaSpread1_Sheet1.Cells.Get(14, 9).Value = "2,340"
        Me.vaSpread1_Sheet1.Cells.Get(15, 1).Value = "������"
        Me.vaSpread1_Sheet1.Cells.Get(15, 2).Value = "1"
        Me.vaSpread1_Sheet1.Cells.Get(15, 3).Value = "��"
        Me.vaSpread1_Sheet1.Cells.Get(15, 5).Value = "0"
        Me.vaSpread1_Sheet1.Cells.Get(15, 6).Value = "1"
        Me.vaSpread1_Sheet1.Cells.Get(15, 7).Value = "��"
        Me.vaSpread1_Sheet1.Cells.Get(15, 9).Value = "0"
        Me.vaSpread1_Sheet1.Cells.Get(16, 1).Value = "���ݎ���"
        Me.vaSpread1_Sheet1.Cells.Get(16, 2).Value = "3"
        Me.vaSpread1_Sheet1.Cells.Get(16, 3).Value = "����"
        Me.vaSpread1_Sheet1.Cells.Get(16, 5).Value = "0"
        Me.vaSpread1_Sheet1.Cells.Get(16, 6).Value = "3"
        Me.vaSpread1_Sheet1.Cells.Get(16, 7).Value = "����"
        Me.vaSpread1_Sheet1.Cells.Get(16, 9).Value = "0"
        Me.vaSpread1_Sheet1.Cells.Get(17, 1).Value = "���M��"
        Me.vaSpread1_Sheet1.Cells.Get(17, 2).Value = "3"
        Me.vaSpread1_Sheet1.Cells.Get(17, 3).Value = "����"
        Me.vaSpread1_Sheet1.Cells.Get(17, 4).Value = "10,000"
        Me.vaSpread1_Sheet1.Cells.Get(17, 5).Value = "30,000"
        Me.vaSpread1_Sheet1.Cells.Get(17, 6).Value = "3"
        Me.vaSpread1_Sheet1.Cells.Get(17, 7).Value = "����"
        Me.vaSpread1_Sheet1.Cells.Get(17, 8).Value = "10,000"
        Me.vaSpread1_Sheet1.Cells.Get(17, 9).Value = "30,000"
        Me.vaSpread1_Sheet1.ColumnFooter.Columns.Default.Resizable = True
        Me.vaSpread1_Sheet1.ColumnFooter.Columns.Default.SortIndicator = FarPoint.Win.Spread.Model.SortIndicator.None
        Me.vaSpread1_Sheet1.ColumnFooter.Columns.Default.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.vaSpread1_Sheet1.ColumnFooter.DefaultStyle.BackColor = System.Drawing.Color.Empty
        Me.vaSpread1_Sheet1.ColumnFooter.DefaultStyle.ForeColor = System.Drawing.Color.Empty
        Me.vaSpread1_Sheet1.ColumnFooter.DefaultStyle.Locked = False
        Me.vaSpread1_Sheet1.ColumnFooter.DefaultStyle.Parent = "HeaderDefault"
        Me.vaSpread1_Sheet1.ColumnFooter.DefaultStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.vaSpread1_Sheet1.ColumnFooter.Rows.Default.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.vaSpread1_Sheet1.ColumnFooterSheetCornerStyle.BackColor = System.Drawing.Color.Empty
        Me.vaSpread1_Sheet1.ColumnFooterSheetCornerStyle.ForeColor = System.Drawing.Color.Empty
        Me.vaSpread1_Sheet1.ColumnFooterSheetCornerStyle.Locked = False
        Me.vaSpread1_Sheet1.ColumnFooterSheetCornerStyle.Parent = "RowHeaderDefault"
        Me.vaSpread1_Sheet1.ColumnFooterSheetCornerStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.vaSpread1_Sheet1.ColumnHeader.Cells.Get(0, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.vaSpread1_Sheet1.ColumnHeader.Cells.Get(0, 0).Value = "�H��"
        Me.vaSpread1_Sheet1.ColumnHeader.Cells.Get(0, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.vaSpread1_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = "���@�@��"
        Me.vaSpread1_Sheet1.ColumnHeader.Cells.Get(0, 2).Value = "����"
        Me.vaSpread1_Sheet1.ColumnHeader.Cells.Get(0, 3).Value = "�P��"
        Me.vaSpread1_Sheet1.ColumnHeader.Cells.Get(0, 4).Value = "�P ��"
        Me.vaSpread1_Sheet1.ColumnHeader.Cells.Get(0, 5).Value = "���@�z"
        Me.vaSpread1_Sheet1.ColumnHeader.Cells.Get(0, 6).Value = "����"
        Me.vaSpread1_Sheet1.ColumnHeader.Cells.Get(0, 7).Value = "�P��"
        Me.vaSpread1_Sheet1.ColumnHeader.Cells.Get(0, 8).Value = "�P ��"
        Me.vaSpread1_Sheet1.ColumnHeader.Cells.Get(0, 9).Value = "���@�z"
        Me.vaSpread1_Sheet1.ColumnHeader.Columns.Default.CanFocus = True
        Me.vaSpread1_Sheet1.ColumnHeader.Columns.Default.Resizable = True
        Me.vaSpread1_Sheet1.ColumnHeader.Columns.Default.SortIndicator = FarPoint.Win.Spread.Model.SortIndicator.None
        Me.vaSpread1_Sheet1.ColumnHeader.Columns.Default.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.vaSpread1_Sheet1.ColumnHeader.DefaultStyle.BackColor = System.Drawing.Color.Empty
        Me.vaSpread1_Sheet1.ColumnHeader.DefaultStyle.Border = ComplexBorder1
        Me.vaSpread1_Sheet1.ColumnHeader.DefaultStyle.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.vaSpread1_Sheet1.ColumnHeader.DefaultStyle.ForeColor = System.Drawing.Color.Black
        Me.vaSpread1_Sheet1.ColumnHeader.DefaultStyle.Locked = False
        Me.vaSpread1_Sheet1.ColumnHeader.DefaultStyle.LockFont = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.vaSpread1_Sheet1.ColumnHeader.DefaultStyle.LockForeColor = System.Drawing.Color.Black
        Me.vaSpread1_Sheet1.ColumnHeader.DefaultStyle.Parent = "HeaderDefault"
        Me.vaSpread1_Sheet1.ColumnHeader.DefaultStyle.Renderer = CustomSpdHeader19
        Me.vaSpread1_Sheet1.ColumnHeader.DefaultStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.vaSpread1_Sheet1.ColumnHeader.Rows.Default.CanFocus = True
        Me.vaSpread1_Sheet1.ColumnHeader.Rows.Default.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.vaSpread1_Sheet1.ColumnHeader.Rows.Get(0).Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.vaSpread1_Sheet1.ColumnHeader.Rows.Get(0).ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.vaSpread1_Sheet1.ColumnHeader.Rows.Get(0).Height = 39.0!
        Me.vaSpread1_Sheet1.ColumnHeader.Rows.Get(0).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.General
        Me.vaSpread1_Sheet1.ColumnHeader.Rows.Get(0).Locked = True
        Me.vaSpread1_Sheet1.ColumnHeader.Rows.Get(0).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.vaSpread1_Sheet1.Columns.Default.Resizable = True
        Me.vaSpread1_Sheet1.Columns.Default.SortIndicator = FarPoint.Win.Spread.Model.SortIndicator.None
        TextCellType5.Static = True
        Me.vaSpread1_Sheet1.Columns.Get(0).CellType = TextCellType5
        Me.vaSpread1_Sheet1.Columns.Get(0).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.vaSpread1_Sheet1.Columns.Get(0).Label = "�H��"
        Me.vaSpread1_Sheet1.Columns.Get(0).Locked = True
        Me.vaSpread1_Sheet1.Columns.Get(0).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.vaSpread1_Sheet1.Columns.Get(0).Width = 40.0!
        Me.vaSpread1_Sheet1.Columns.Get(1).CellType = TextCellType2
        Me.vaSpread1_Sheet1.Columns.Get(1).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Left
        Me.vaSpread1_Sheet1.Columns.Get(1).Label = "���@�@��"
        Me.vaSpread1_Sheet1.Columns.Get(1).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.vaSpread1_Sheet1.Columns.Get(1).Width = 326.0!
        Me.vaSpread1_Sheet1.Columns.Get(2).CellType = TextCellType3
        Me.vaSpread1_Sheet1.Columns.Get(2).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Right
        Me.vaSpread1_Sheet1.Columns.Get(2).Label = "����"
        Me.vaSpread1_Sheet1.Columns.Get(2).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.vaSpread1_Sheet1.Columns.Get(2).Width = 76.0!
        Me.vaSpread1_Sheet1.Columns.Get(3).CellType = TextCellType4
        Me.vaSpread1_Sheet1.Columns.Get(3).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.vaSpread1_Sheet1.Columns.Get(3).Label = "�P��"
        Me.vaSpread1_Sheet1.Columns.Get(3).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.vaSpread1_Sheet1.Columns.Get(3).Width = 40.0!
        Me.vaSpread1_Sheet1.Columns.Get(4).CellType = TextCellType3
        Me.vaSpread1_Sheet1.Columns.Get(4).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Right
        Me.vaSpread1_Sheet1.Columns.Get(4).Label = "�P ��"
        Me.vaSpread1_Sheet1.Columns.Get(4).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.vaSpread1_Sheet1.Columns.Get(4).Width = 76.0!
        Me.vaSpread1_Sheet1.Columns.Get(5).CellType = TextCellType3
        Me.vaSpread1_Sheet1.Columns.Get(5).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Right
        Me.vaSpread1_Sheet1.Columns.Get(5).Label = "���@�z"
        Me.vaSpread1_Sheet1.Columns.Get(5).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.vaSpread1_Sheet1.Columns.Get(5).Width = 92.0!
        Me.vaSpread1_Sheet1.Columns.Get(6).CellType = TextCellType3
        Me.vaSpread1_Sheet1.Columns.Get(6).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Right
        Me.vaSpread1_Sheet1.Columns.Get(6).Label = "����"
        Me.vaSpread1_Sheet1.Columns.Get(6).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.vaSpread1_Sheet1.Columns.Get(6).Width = 76.0!
        Me.vaSpread1_Sheet1.Columns.Get(7).CellType = TextCellType4
        Me.vaSpread1_Sheet1.Columns.Get(7).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.vaSpread1_Sheet1.Columns.Get(7).Label = "�P��"
        Me.vaSpread1_Sheet1.Columns.Get(7).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.vaSpread1_Sheet1.Columns.Get(7).Width = 40.0!
        Me.vaSpread1_Sheet1.Columns.Get(8).CellType = TextCellType3
        Me.vaSpread1_Sheet1.Columns.Get(8).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Right
        Me.vaSpread1_Sheet1.Columns.Get(8).Label = "�P ��"
        Me.vaSpread1_Sheet1.Columns.Get(8).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.vaSpread1_Sheet1.Columns.Get(8).Width = 78.0!
        Me.vaSpread1_Sheet1.Columns.Get(9).CellType = TextCellType3
        Me.vaSpread1_Sheet1.Columns.Get(9).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Right
        Me.vaSpread1_Sheet1.Columns.Get(9).Label = "���@�z"
        Me.vaSpread1_Sheet1.Columns.Get(9).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.vaSpread1_Sheet1.Columns.Get(9).Width = 94.0!
        Me.vaSpread1_Sheet1.DefaultStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        TextCellType6.MaxLength = 60
        Me.vaSpread1_Sheet1.DefaultStyle.CellType = TextCellType6
        Me.vaSpread1_Sheet1.DefaultStyle.Font = New System.Drawing.Font("MS Mincho", 11.0!)
        Me.vaSpread1_Sheet1.DefaultStyle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.vaSpread1_Sheet1.DefaultStyle.Locked = False
        Me.vaSpread1_Sheet1.DefaultStyle.Parent = "DataAreaDefault"
        Me.vaSpread1_Sheet1.DefaultStyle.Renderer = TextCellType6
        Me.vaSpread1_Sheet1.FilterBar.DefaultStyle.BackColor = System.Drawing.Color.Empty
        Me.vaSpread1_Sheet1.FilterBar.DefaultStyle.ForeColor = System.Drawing.Color.Empty
        Me.vaSpread1_Sheet1.FilterBar.DefaultStyle.Locked = False
        Me.vaSpread1_Sheet1.FilterBar.DefaultStyle.Parent = "FilterBarDefault"
        Me.vaSpread1_Sheet1.FilterBar.DefaultStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.vaSpread1_Sheet1.FilterBarHeaderStyle.BackColor = System.Drawing.Color.Empty
        Me.vaSpread1_Sheet1.FilterBarHeaderStyle.ForeColor = System.Drawing.Color.Empty
        Me.vaSpread1_Sheet1.FilterBarHeaderStyle.Locked = False
        Me.vaSpread1_Sheet1.FilterBarHeaderStyle.Parent = "RowHeaderDefault"
        Me.vaSpread1_Sheet1.FilterBarHeaderStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.vaSpread1_Sheet1.OperationMode = FarPoint.Win.Spread.OperationMode.[ReadOnly]
        Me.vaSpread1_Sheet1.Protect = True
        Me.vaSpread1_Sheet1.RowHeader.Columns.Default.Resizable = False
        Me.vaSpread1_Sheet1.RowHeader.Columns.Default.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.vaSpread1_Sheet1.RowHeader.Columns.Get(0).Width = 34.0!
        Me.vaSpread1_Sheet1.RowHeader.DefaultStyle.BackColor = System.Drawing.Color.Empty
        Me.vaSpread1_Sheet1.RowHeader.DefaultStyle.Border = ComplexBorder1
        Me.vaSpread1_Sheet1.RowHeader.DefaultStyle.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.vaSpread1_Sheet1.RowHeader.DefaultStyle.ForeColor = System.Drawing.Color.Empty
        Me.vaSpread1_Sheet1.RowHeader.DefaultStyle.Locked = False
        Me.vaSpread1_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderDefault"
        Me.vaSpread1_Sheet1.RowHeader.DefaultStyle.Renderer = CustomSpdHeader20
        Me.vaSpread1_Sheet1.RowHeader.DefaultStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.vaSpread1_Sheet1.RowHeader.Rows.Default.Resizable = False
        Me.vaSpread1_Sheet1.RowHeader.Rows.Default.Visible = True
        Me.vaSpread1_Sheet1.RowHeader.Rows.Default.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.vaSpread1_Sheet1.Rows.Default.Resizable = False
        Me.vaSpread1_Sheet1.Rows.Default.Visible = True
        Me.vaSpread1_Sheet1.SheetCornerStyle.BackColor = System.Drawing.Color.Empty
        Me.vaSpread1_Sheet1.SheetCornerStyle.ForeColor = System.Drawing.Color.Empty
        Me.vaSpread1_Sheet1.SheetCornerStyle.Locked = False
        Me.vaSpread1_Sheet1.SheetCornerStyle.Parent = "RowHeaderDefault"
        Me.vaSpread1_Sheet1.SheetCornerStyle.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.vaSpread1_Sheet1.SheetCornerStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.vaSpread1_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1
        '
        'frmSYKD025
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(1016, 742)
        Me.Controls.Add(Me._Picture2_1)
        Me.Controls.Add(Me._Picture2_0)
        Me.Controls.Add(Me.Picture1)
        Me.Controls.Add(Me.StatusBar1)
        Me.Controls.Add(Me._imText2_2)
        Me.Controls.Add(Me._imText2_0)
        Me.Controls.Add(Me._imText2_1)
        Me.Controls.Add(Me.lblTitle)
        Me.Controls.Add(Me.vaSpread1)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.KeyPreview = True
        Me.Location = New System.Drawing.Point(4, 23)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmSYKD025"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "�H���Ǘ��V�X�e��"
        Me._Picture2_1.ResumeLayout(False)
        Me._Picture2_0.ResumeLayout(False)
        Me.Picture1.ResumeLayout(False)
        Me.StatusBar1.ResumeLayout(False)
        Me.StatusBar1.PerformLayout()
        CType(Me._imText2_2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._imText2_0, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._imText2_1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.vaSpread1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.vaSpread1_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents vaSpread1 As FarPoint.Win.Spread.FpSpread
    Friend WithEvents vaSpread1_Sheet1 As FarPoint.Win.Spread.SheetView
#End Region
End Class