Option Strict Off
Option Explicit On
Friend Class frmSYKD075
	Inherits System.Windows.Forms.Form
	'

	'2021.08.02 UPGRADE S  AIT)Hoangtx
	'Private Sub Check1_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles Check1.Enter
	Private Sub Check1_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _Check1_0.Enter, _Check1_1.Enter, _Check1_2.Enter
		'Dim Index As Short = Check1.GetIndex(eventSender)
		Dim Index As Short = Check1.IndexOf(eventSender)
		'Call GotFocus(Check1(Index), StatusBar1)
		Call MtyTool.GotFocus(Check1(Index), StatusBar1)
		'2021.08.02 UPGRADE E
	End Sub

	'2021.08.02 UPGRADE S  AIT)Hoangtx
	'	Private Sub Check1_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles Check1.Leave
	Private Sub Check1_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _Check1_0.Leave, _Check1_1.Leave, _Check1_2.Leave
		'Dim Index As Short = Check1.GetIndex(eventSender)
		Dim Index As Short = Check1.IndexOf(eventSender)
		'Call LostFocus(Check1(Index), StatusBar1)
		Call MtyTool.LostFocus(Check1(Index), StatusBar1)
		'2021.08.02 UPGRADE E
	End Sub

	'2021.08.02 UPGRADE S  AIT)Hoangtx
	'	Private Sub cmdKey_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Click
	Private Sub cmdKey_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _cmdKey_12.Click, _cmdKey_1.Click
		'Dim Index As Short = cmdKey.GetIndex(eventSender)
		Dim Index As Short = cmdKey.IndexOf(eventSender)
		'2021.08.02 UPGRADE E

		Dim Jouken As String
		Dim Msg As String

		Select Case Index
			Case 1 '----- �������
				'2021.08.05 UPGRADE S  AIT)Hoangtx
				'If Check1(0).CheckState = CDbl("1") Or Check1(1).CheckState = CDbl("1") Or Check1(2).CheckState = CDbl("1") Then
				'If MsgBox("�`�F�b�N���X�g��������܂��B��낵���ł����H", MsgBoxStyle.YesNo) = MsgBoxResult.No Then
				If Check1(0).CheckState = CDbl("1") OrElse Check1(1).CheckState = CDbl("1") OrElse Check1(2).CheckState = CDbl("1") Then
					If MsgBox("�`�F�b�N���X�g��������܂��B��낵���ł����H", MsgBoxStyle.YesNo, SYSTEMNM) = MsgBoxResult.No Then
						'2021.08.05 UPGRADE E
						Exit Sub
					End If

					If Check1(0).CheckState = 1 Then
						System.Windows.Forms.Application.DoEvents()
						System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
						StatusBar1.Items.Item("Message").Text = "����f�[�^�i��ʁj�쐬���E�E�E"
						System.Windows.Forms.Application.DoEvents()
						If PrnMainD075() = True Then
							'2001/01/21 �ҏW�̏ꍇ�̂ݍX�V����
							If INPMODE = "2" Then '�ҏW��
								' �H�����i����j�y�؂̍X�V
								CtlKouji.P_FLG_CHECK = "1" '���FLG ��ʕ���������ؽ�
								Jouken = "KOUJI_NO = '" & CtlKouji.KOUJI_NO & "' AND EDA_NO = '" & CtlKouji.EDA_NO & "'"
								If UPDATE_KOUJI_CTRL_D(Jouken, CtlKouji) = False Then
									Msg = "�H�����i����j�y�؂̍X�V�Ɏ��s���܂����B"
									'2021.09.14 UPGRADE S  AIT)dannnl
									'MsgBox(Msg, MsgBoxStyle.OkOnly)
									MsgBox(Msg, MsgBoxStyle.OkOnly, SYSTEMNM)
									'2021.09.14 UPGRADE E
									Exit Sub
								End If
							End If
						End If
					End If
					If Check1(1).CheckState = 1 Then
						System.Windows.Forms.Application.DoEvents()
						System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
						StatusBar1.Items.Item("Message").Text = "����f�[�^�i�O���j�쐬���E�E�E"
						System.Windows.Forms.Application.DoEvents()
						If PrnMainD150() = True Then
							'2001/01/21 �ҏW�̏ꍇ�̂ݍX�V����
							If INPMODE = "2" Then '�ҏW��
								' �H�����i����j�y�؂̍X�V
								CtlKouji.P_FLG_CHECK = "1" '���FLG ��ʕ���������ؽ�
								Jouken = "KOUJI_NO = '" & CtlKouji.KOUJI_NO & "' AND EDA_NO = '" & CtlKouji.EDA_NO & "'"
								If UPDATE_KOUJI_CTRL_D(Jouken, CtlKouji) = False Then
									Msg = "�H�����i����j�y�؂̍X�V�Ɏ��s���܂����B"
									'2021.09.14 UPGRADE S  AIT)dannnl
									'MsgBox(Msg, MsgBoxStyle.OkOnly)
									MsgBox(Msg, MsgBoxStyle.OkOnly, SYSTEMNM)
									'2021.09.14 UPGRADE E
									Exit Sub
								End If
							End If
						End If
					End If
					If Check1(2).CheckState = 1 Then
						System.Windows.Forms.Application.DoEvents()
						System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
						StatusBar1.Items.Item("Message").Text = "����f�[�^�i�x���j�쐬���E�E�E"
						System.Windows.Forms.Application.DoEvents()
						If PrnMainD076() = True Then
							'
						End If
					End If
				Else
					Exit Sub
				End If
				System.Windows.Forms.Application.DoEvents()
				StatusBar1.Items.Item("Message").Text = ""
				System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
				System.Windows.Forms.Application.DoEvents()

			Case 12 '----- �����I��
				'Me.Close()
				Me.Dispose()
		End Select

	End Sub

	'2021.08.02 UPGRADE S  AIT)Hoangtx
	'Private Sub cmdKey_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Enter
	Private Sub cmdKey_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _cmdKey_12.Enter, _cmdKey_1.Enter
		'Dim Index As Short = cmdKey.GetIndex(eventSender)
		Dim Index As Short = cmdKey.IndexOf(eventSender)
		'Call GotFocus(cmdKey(Index), StatusBar1)
		Call MtyTool.GotFocus(cmdKey(Index), StatusBar1)
		'2021.08.02 UPGRADE E
	End Sub

	'2021.08.02 UPGRADE S  AIT)Hoangtx
	'Private Sub cmdKey_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Leave
	Private Sub cmdKey_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _cmdKey_12.Leave, _cmdKey_1.Leave
		'Dim Index As Short = cmdKey.GetIndex(eventSender)
		Dim Index As Short = cmdKey.IndexOf(eventSender)
		'Call LostFocus(cmdKey(Index), StatusBar1)
		Call MtyTool.LostFocus(cmdKey(Index), StatusBar1)
		'2021.08.02 UPGRADE E
	End Sub

	Private Sub frmSYKD075_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown
		Dim KeyCode As Short = eventArgs.KeyCode
		Dim Shift As Short = eventArgs.KeyData \ &H10000
		Select Case KeyCode
			Case System.Windows.Forms.Keys.Return
				'2021.08.17 UPGRADE S  AIT)dannnl
				'Call NextCntlGet(Me, Me.ActiveControl.TabIndex)
				Call NextCntlGet()
				'2021.08.17 UPGRADE E
			Case System.Windows.Forms.Keys.F1
				If cmdKey(1).Enabled = True Then cmdKey(1).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(1), New System.EventArgs())
			Case System.Windows.Forms.Keys.F12
				If cmdKey(12).Enabled = True Then cmdKey(12).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(12), New System.EventArgs())
		End Select
	End Sub
	
	Private Sub frmSYKD075_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
		Call FormDisp(Me)
	End Sub
End Class
