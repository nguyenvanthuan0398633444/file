Option Strict Off
Option Explicit On

Module DB_KESIKOMI_DATA

    Public Const KESIKOMI_DATA_TBLNAME As String = "KESIKOMI_DATA"

    '�����f�[�^
    Structure KESIKOMI_DATA_DBT
        '2021.07.26 UPGRADE S  AIT)Tool Convert
        '<VBFixedString(6),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=6)> Public SIME_YM() As Char '���N��
        '<VBFixedString(2),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=2)> Public SIME_DAY() As Char '����
        '<VBFixedString(6),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=6)> Public DENPYOU_NO() As Char '�`�[�ԍ�
        <VBFixedStringAttribute(6)> Public SIME_YM As String     '���N��
        <VBFixedStringAttribute(2)> Public SIME_DAY As String    '����
        <VBFixedStringAttribute(6)> Public DENPYOU_NO As String  '�`�[�ԍ�
        '2021.07.26 UPGRADE E
        Dim DEN_EDA_NO As Single '�`�[�}��
        '2021.07.26 UPGRADE S  AIT)Tool Convert
        '<VBFixedString(2),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=2)> Public GYOU_NO() As Char '�s�ԍ�
        '<VBFixedString(8),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=8)> Public KOUJI_NO() As Char '�H���ԍ�
        '<VBFixedString(4),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=4)> Public EDA_NO() As Char '�H���}��
        '<VBFixedString(8),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=8)> Public NYUUKIN_YMD() As Char '������
        <VBFixedStringAttribute(2)> Public GYOU_NO As String     '�s�ԍ�
        <VBFixedStringAttribute(8)> Public KOUJI_NO As String    '�H���ԍ�
        <VBFixedStringAttribute(4)> Public EDA_NO As String  '�H���}��
        <VBFixedStringAttribute(8)> Public NYUUKIN_YMD As String     '������
        '2021.07.26 UPGRADE E
        Dim KINGAKU As Decimal '���z
    End Structure

    '-------------------------------------------------------------------------------
    '   ����   :   KESIKOMI_DATA_DBT �\���̃N���A����
    '   �֐�   :   Sub CLEAR_KESIKOMI_DATA()
    '   ����   :   DT  KESIKOMI_DATA_DBT
    '   �@�\   :   �\���̂�����������
    '-------------------------------------------------------------------------------
    Public Sub CLEAR_KESIKOMI_DATA(ByRef DT As KESIKOMI_DATA_DBT)

        With DT
            .SIME_YM = "" '���N��
            .SIME_DAY = "" '����
            .DENPYOU_NO = "" '�`�[�ԍ�
            .DEN_EDA_NO = 0 '�`�[�}��
            .GYOU_NO = "" '�s�ԍ�
            .KOUJI_NO = "" '�H���ԍ�
            .EDA_NO = "" '�H���}��
            .NYUUKIN_YMD = "" '������
            .KINGAKU = 0 '���z
        End With

    End Sub

    '-------------------------------------------------------------------------------
    '   ����   :   KESIKOMI_DATA Delete
    '   �֐�   :   Function DELETE_KESIKOMI_DATA()
    '   ����   :   Jouken   ������
    '   �ߒl   :   True     ����I��
    '   �@�@       False    �ُ�I��
    '   �@�\   :   KESIKOMI_DATA DELETE����
    '-------------------------------------------------------------------------------
    Public Function DELETE_KESIKOMI_DATA(ByRef Jouken As String) As Boolean

        Dim SQL As String

        '2021.07.26 UPGRADE S  AIT)Tool Convert
        'On Error GoTo DELETE_KESIKOMI_DATA_Err
        Try
            '2021.07.26 UPGRADE E

            '�߂�l�̏�����
            DELETE_KESIKOMI_DATA = False

            'SQL/DELETE���g��
            SQL = "DELETE FROM " & KESIKOMI_DATA_TBLNAME
            If Trim(Jouken) <> "" Then
                SQL = SQL & " WHERE " & Jouken
            End If

            'SQL�����s
            '2021.08.04 UPGRADE S  AIT)hieutv
            'SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText + ADODB.ExecuteOptionEnum.adExecuteNoRecords)
            ExecSQL(SQL)
            '2021.08.04 UPGRADE E

            '�߂�l�̃Z�b�g
            DELETE_KESIKOMI_DATA = True
            Exit Function

            '2021.07.26 UPGRADE S  AIT)Tool Convert
            'DELETE_KESIKOMI_DATA_Err:
        Catch ex As Exception
            '2021.07.26 UPGRADE E

            '2021.08.04 UPGRADE S  AIT)hieutv
            'Call Sql_Error_Msg("KESIKOMI_DATA DELETE")
            Call Sql_Error_Msg(ex, "KESIKOMI_DATA DELETE")
            '2021.08.04 UPGRADE E

        End Try     '2021.07.26 UPGRADE ADD AIT)Tool Convert
    End Function

    '-------------------------------------------------------------------------------
    '   ����   :   KESIKOMI_DATA INSERT����
    '   �֐�   :   Function INSERT_KESIKOMI_DATA()
    '   ����   :   DT       KESIKOMI_DATA_DBT
    '   �ߒl   :   True     ����I��
    '   �@�@       False    �ُ�I��
    '   �@�\   :   KESIKOMI_DATA INSERT����
    '-------------------------------------------------------------------------------
    Public Function INSERT_KESIKOMI_DATA(ByRef DT As KESIKOMI_DATA_DBT) As Boolean

        Dim SQL As String

        '2021.07.26 UPGRADE S  AIT)Tool Convert
        'On Error GoTo INSERT_KESIKOMI_DATA_Err
        Try
            '2021.07.26 UPGRADE E

            '�߂�l�̏�����
            INSERT_KESIKOMI_DATA = False

            'SQL/INSERT���g��
            SQL = "INSERT INTO " & KESIKOMI_DATA_TBLNAME
            SQL = SQL & " ("
            SQL = SQL & " SIME_YM,"
            SQL = SQL & " SIME_DAY,"
            SQL = SQL & " DENPYOU_NO,"
            SQL = SQL & " DEN_EDA_NO,"
            SQL = SQL & " GYOU_NO,"
            SQL = SQL & " KOUJI_NO,"
            SQL = SQL & " EDA_NO,"
            SQL = SQL & " NYUUKIN_YMD,"
            SQL = SQL & " KINGAKU"
            SQL = SQL & " ) VALUES("
            SQL = SQL & " '" & Trim(DT.SIME_YM) & "'," '���N��
            SQL = SQL & " '" & Trim(DT.SIME_DAY) & "'," '����
            SQL = SQL & " '" & Trim(DT.DENPYOU_NO) & "'," '�`�[�ԍ�
            SQL = SQL & " " & DT.DEN_EDA_NO & "," '�`�[�}��
            SQL = SQL & " '" & Trim(DT.GYOU_NO) & "'," '�s�ԍ�
            SQL = SQL & " '" & Trim(DT.KOUJI_NO) & "'," '�H���ԍ�
            SQL = SQL & " '" & Trim(DT.EDA_NO) & "'," '�H���}��
            SQL = SQL & " '" & Trim(DT.NYUUKIN_YMD) & "'," '������
            SQL = SQL & " " & DT.KINGAKU & "" '���z
            SQL = SQL & " )"

            'SQL�����s
            '2021.08.04 UPGRADE S  AIT)hieutv
            'SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText + ADODB.ExecuteOptionEnum.adExecuteNoRecords)
            ExecSQL(SQL)
            '2021.08.04 UPGRADE E

            '�߂�l�̃Z�b�g
            INSERT_KESIKOMI_DATA = True
            Exit Function

            '2021.07.26 UPGRADE S  AIT)Tool Convert
            'INSERT_KESIKOMI_DATA_Err:
        Catch ex As Exception
            '2021.07.26 UPGRADE E

            '2021.08.04 UPGRADE S  AIT)hieutv
            'Call Sql_Error_Msg("KESIKOMI_DATA INSERT")
            Call Sql_Error_Msg(ex, "KESIKOMI_DATA INSERT")
            '2021.08.04 UPGRADE E

        End Try     '2021.07.26 UPGRADE ADD AIT)Tool Convert
    End Function

    '-------------------------------------------------------------------------------
    '   ����   :   KESIKOMI_DATA UPDATE
    '   �֐�   :   Function UPDATE_KESIKOMI_DATA()
    '   ����   :   Jouken   ������
    '   �@�@       DT       KESIKOMI_DATA_DBT
    '   �ߒl   :   True     ����I��
    '   �@�@       False    �ُ�I��
    '   �@�\   :   KESIKOMI_DATA UPDATE����
    '-------------------------------------------------------------------------------
    Public Function UPDATE_KESIKOMI_DATA(ByRef Jouken As String, ByRef DT As KESIKOMI_DATA_DBT) As Boolean

        Dim SQL As String

        '2021.07.26 UPGRADE S  AIT)Tool Convert
        'On Error GoTo UPDATE_KESIKOMI_DATA_Err
        Try
            '2021.07.26 UPGRADE E

            '�߂�l�̏�����
            UPDATE_KESIKOMI_DATA = False

            'SQL/UPDATE���g��
            SQL = "UPDATE " & KESIKOMI_DATA_TBLNAME
            SQL = SQL & " SET"
            SQL = SQL & " SIME_YM = '" & Trim(DT.SIME_YM) & "'," '���N��
            SQL = SQL & " SIME_DAY = '" & Trim(DT.SIME_DAY) & "'," '����
            SQL = SQL & " DENPYOU_NO = '" & Trim(DT.DENPYOU_NO) & "'," '�`�[�ԍ�
            SQL = SQL & " DEN_EDA_NO = " & DT.DEN_EDA_NO & "," '�`�[�}��
            SQL = SQL & " GYOU_NO = '" & Trim(DT.GYOU_NO) & "'," '�s�ԍ�
            SQL = SQL & " KOUJI_NO = '" & Trim(DT.KOUJI_NO) & "'," '�H���ԍ�
            SQL = SQL & " EDA_NO = '" & Trim(DT.EDA_NO) & "'," '�H���}��
            SQL = SQL & " NYUUKIN_YMD = '" & Trim(DT.NYUUKIN_YMD) & "'," '������
            SQL = SQL & " KINGAKU = " & DT.KINGAKU & "" '���z
            If Trim(Jouken) <> "" Then
                SQL = SQL & " WHERE " & Jouken
            End If

            'SQL�����s
            '2021.08.04 UPGRADE S  AIT)hieutv
            'SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText + ADODB.ExecuteOptionEnum.adExecuteNoRecords)
            ExecSQL(SQL)
            '2021.08.04 UPGRADE E

            '�߂�l�̃Z�b�g
            UPDATE_KESIKOMI_DATA = True
            Exit Function

            '2021.07.26 UPGRADE S  AIT)Tool Convert
            'UPDATE_KESIKOMI_DATA_Err:
        Catch ex As Exception
            '2021.07.26 UPGRADE E

            '2021.08.04 UPGRADE S  AIT)hieutv
            'Call Sql_Error_Msg("KESIKOMI_DATA UPDATE")
            Call Sql_Error_Msg(ex, "KESIKOMI_DATA UPDATE")
            '2021.08.04 UPGRADE E

        End Try     '2021.07.26 UPGRADE ADD AIT)Tool Convert
    End Function

    '-------------------------------------------------------------------------------
    '   ����   :   KESIKOMI_DATA �f�[�^�Z�b�g����
    '   �֐�   :   Sub DATSET_KESIKOMI_DATA()
    '   ����   :   Rs  ADODB.Recordset
    '   �@�@       DT  KESIKOMI_DATA_DBT
    '   �@�\   :   �\���̂Ƀf�[�^���Z�b�g����
    '-------------------------------------------------------------------------------
    '2021.08.04 UPGRADE S  AIT)hieutv
    'Public Sub DATSET_KESIKOMI_DATA(ByRef Rs As ADODB.Recordset, ByRef DT As KESIKOMI_DATA_DBT)

    '    Dim Fld As ADODB.Field    
    Public Sub DATSET_KESIKOMI_DATA(ByRef Rs As DataRow, ByRef DT As KESIKOMI_DATA_DBT)

        Dim Fld As DataColumn
        '2021.08.04 UPGRADE E

        '�\���̂̏�����
        Call CLEAR_KESIKOMI_DATA(DT)

        '�t�B�[���h�����������s
        '2021.08.04 UPGRADE S  AIT)hieutv
        'For Each Fld In Rs.Fields
        '    If IsDBNull(Fld.Name) = False And IsDBNull(Fld.Value) = False Then
        '        Select Case UCase(Fld.Name)
        '            Case "SIME_YM" : DT.SIME_YM = Fld.Value '���N��
        '            Case "SIME_DAY" : DT.SIME_DAY = Fld.Value '����
        '            Case "DENPYOU_NO" : DT.DENPYOU_NO = Fld.Value '�`�[�ԍ�
        '            Case "DEN_EDA_NO" : DT.DEN_EDA_NO = Fld.Value '�`�[�}��
        '            Case "GYOU_NO" : DT.GYOU_NO = Fld.Value '�s�ԍ�
        '            Case "KOUJI_NO" : DT.KOUJI_NO = Fld.Value '�H���ԍ�
        '            Case "EDA_NO" : DT.EDA_NO = Fld.Value '�H���}��
        '            Case "NYUUKIN_YMD" : DT.NYUUKIN_YMD = Fld.Value '������
        '            Case "KINGAKU" : DT.KINGAKU = Fld.Value '���z
        '        End Select
        '    End If
        'Next Fld
        For Each Fld In Rs.Table.Columns
            If IsDBNull(Fld.ColumnName) = False And IsDBNull(Rs(Fld.ColumnName)) = False Then
                Select Case UCase(Fld.ColumnName)
                    Case "SIME_YM" : DT.SIME_YM = Rs(Fld.ColumnName) '���N��
                    Case "SIME_DAY" : DT.SIME_DAY = Rs(Fld.ColumnName) '����
                    Case "DENPYOU_NO" : DT.DENPYOU_NO = Rs(Fld.ColumnName) '�`�[�ԍ�
                    Case "DEN_EDA_NO" : DT.DEN_EDA_NO = Rs(Fld.ColumnName) '�`�[�}��
                    Case "GYOU_NO" : DT.GYOU_NO = Rs(Fld.ColumnName) '�s�ԍ�
                    Case "KOUJI_NO" : DT.KOUJI_NO = Rs(Fld.ColumnName) '�H���ԍ�
                    Case "EDA_NO" : DT.EDA_NO = Rs(Fld.ColumnName) '�H���}��
                    Case "NYUUKIN_YMD" : DT.NYUUKIN_YMD = Rs(Fld.ColumnName) '������
                    Case "KINGAKU" : DT.KINGAKU = Rs(Fld.ColumnName) '���z
                End Select
            End If
        Next Fld
        '2021.08.04 UPGRADE E

    End Sub

    '-------------------------------------------------------------------------------
    '   ����   :   KESIKOMI_DATA �ǂݍ��ݏ���
    '   �֐�   :   Function SELECT_KESIKOMI_DATA()
    '   ����   :   Jouken�@ ������
    '   �@�@       strSort�@�\�[�g����
    '   �@�@       DT()�@   KESIKOMI_DATA_DBT
    '   �ߒl   :   �ް���   ����I��
    '   �@�@       -1�@     �ُ�I��
    '   �@�\   :   KESIKOMI_DATA SELECT����
    '-------------------------------------------------------------------------------
    Public Function SELECT_KESIKOMI_DATA(ByRef Jouken As String, ByRef strSort As String, ByRef DT() As KESIKOMI_DATA_DBT) As Integer

        Dim SQL As String
        '2021.08.04 UPGRADE S  AIT)hieutv
        'Dim Rs As ADODB.Recordset
        Dim Rs As New DataTable
        '2021.08.04 UPGRADE E
        Dim Cnt As Integer
        Dim OpenFlg As Short

        '2021.07.26 UPGRADE S  AIT)Tool Convert
        'On Error GoTo SELECT_KESIKOMI_DATA_Err
        Try
            '2021.07.26 UPGRADE E

            '�߂�l�̏�����
            SELECT_KESIKOMI_DATA = -1

            'SQL/SELECT���g��
            SQL = "SELECT * FROM " & KESIKOMI_DATA_TBLNAME
            If Trim(Jouken) <> "" Then
                SQL = SQL & " WHERE " & Jouken
            End If
            If Trim(strSort) <> "" Then
                SQL = SQL & " ORDER BY " & strSort
            End If

            'SQL�����s
            '2021.08.04 UPGRADE S  AIT)hieutv
            'Rs = SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText)
            Rs = RsOpen(SQL)
            '2021.08.04 UPGRADE E
            OpenFlg = 1

            Cnt = 0
            '2021.08.04 UPGRADE S  AIT)hieutv
            'Do Until Rs.EOF
            '    ReDim Preserve DT(Cnt)
            '    Call DATSET_KESIKOMI_DATA(Rs, DT(Cnt))
            '    Cnt = Cnt + 1
            '    Rs.MoveNext()
            'Loop

            'Rs.Close()
            For Each Row As DataRow In Rs.Rows
                ReDim Preserve DT(Cnt)
                Call DATSET_KESIKOMI_DATA(Row, DT(Cnt))
                Cnt = Cnt + 1
            Next

            Rs.Dispose()
            '2021.08.04 UPGRADE E
            Rs = Nothing

            '�߂�l�̃Z�b�g
            SELECT_KESIKOMI_DATA = Cnt
            Exit Function

            '2021.07.26 UPGRADE S  AIT)Tool Convert
            'SELECT_KESIKOMI_DATA_Err:
        Catch ex As Exception
            '2021.07.26 UPGRADE E

            If OpenFlg = 1 Then
                '2021.08.04 UPGRADE S  AIT)hieutv
                'Rs.Close()
                Rs.Dispose()
                '2021.08.04 UPGRADE E
            End If
            Rs = Nothing

            '2021.08.04 UPGRADE S  AIT)hieutv
            'Call Sql_Error_Msg("KESIKOMI_DATA SELECT")
            Call Sql_Error_Msg(ex, "KESIKOMI_DATA SELECT")
            '2021.08.04 UPGRADE E

        End Try     '2021.07.26 UPGRADE ADD AIT)Tool Convert
    End Function

    '-------------------------------------------------------------------------------
    '   ����   :   KESIKOMI_DATA �ǂݍ��݌����擾����
    '   �֐�   :   Function CNTGET_KESIKOMI_DATA()
    '   ����   :   Jouken�@ ������
    '   �ߒl   :   �ް���   ����I��
    '   �@�@       -1�@     �ُ�I��
    '   �@�\   :   KESIKOMI_DATA CNTGET����
    '-------------------------------------------------------------------------------
    Public Function CNTGET_KESIKOMI_DATA(ByRef Jouken As String) As Integer

        Dim SQL As String
        '2021.08.04 UPGRADE S  AIT)hieutv
        'Dim Rs As ADODB.Recordset
        Dim Rs As New DataTable
        '2021.08.04 UPGRADE E
        Dim Cnt As Integer
        Dim OpenFlg As Short

        '2021.07.26 UPGRADE S  AIT)Tool Convert
        'On Error GoTo CNTGET_KESIKOMI_DATA_Err
        Try
            '2021.07.26 UPGRADE E

            '�߂�l�̏�����
            CNTGET_KESIKOMI_DATA = -1

            'SQL/SELECT���g��
            '2021.08.10 UPGRADE S  AIT)hieutv
            'SQL = "SELECT COUNT(*) FROM " & KESIKOMI_DATA_TBLNAME
            SQL = "SELECT COUNT(*) AS COUNTDATA FROM " & KESIKOMI_DATA_TBLNAME
            '2021.08.10 UPGRADE E
            If Trim(Jouken) <> "" Then
                SQL = SQL & " WHERE " & Jouken
            End If

            'SQL�����s
            '2021.08.04 UPGRADE S  AIT)hieutv
            'Rs = SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText)
            Rs = RsOpen(SQL)
            '2021.08.04 UPGRADE E
            OpenFlg = 1

            Cnt = 0
            '2021.08.04 UPGRADE S  AIT)hieutv
            'If Rs.EOF = False Then
            '    If IsDBNull(Rs.Fields(0).Value) = False Then
            '        Cnt = Rs.Fields(0).Value
            '    End If
            'End If

            'Rs.Close()
            If Rs.Rows.Count > 0 Then
                If IsDBNull(Rs.Rows(0)("COUNTDATA")) = False Then
                    Cnt = Rs.Rows(0)("COUNTDATA")
                End If
            End If

            Rs.Dispose()
            '2021.08.04 UPGRADE E
            Rs = Nothing

            '�߂�l�̃Z�b�g
            CNTGET_KESIKOMI_DATA = Cnt
            Exit Function

            '2021.07.26 UPGRADE S  AIT)Tool Convert
            'CNTGET_KESIKOMI_DATA_Err:
        Catch ex As Exception
            '2021.07.26 UPGRADE E

            If OpenFlg = 1 Then
                '2021.08.04 UPGRADE S  AIT)hieutv
                'Rs.Close()
                Rs.Dispose()
                '2021.08.04 UPGRADE E
            End If
            Rs = Nothing

            '2021.08.04 UPGRADE S  AIT)hieutv
            'Call Sql_Error_Msg("KESIKOMI_DATA CNTGET")
            Call Sql_Error_Msg(ex, "KESIKOMI_DATA CNTGET")
            '2021.08.04 UPGRADE E

        End Try     '2021.07.26 UPGRADE ADD AIT)Tool Convert
    End Function

    '-------------------------------------------------------------------------------
    '   ����   :   KESIKOMI_DATA CREATE
    '   �֐�   :   Function CREATE_KESIKOMI_DATA()
    '   �ߒl   :   True     ����I��
    '   �@�@       False    �ُ�I��
    '   �@�\   :   KESIKOMI_DATA CREATE����
    '-------------------------------------------------------------------------------
    Public Function CREATE_KESIKOMI_DATA() As Boolean

        Dim SQL As String

        '2021.07.26 UPGRADE S  AIT)Tool Convert
        'On Error GoTo CREATE_KESIKOMI_DATA_Err
        Try
            '2021.07.26 UPGRADE E

            '�߂�l�̏�����
            CREATE_KESIKOMI_DATA = False

            'SQL/CREATE���g��
            SQL = "CREATE TABLE " & KESIKOMI_DATA_TBLNAME
            SQL = SQL & " ("
            SQL = SQL & " SIME_YM        Text(6)," '���N��
            SQL = SQL & " SIME_DAY       Text(2)," '����
            SQL = SQL & " DENPYOU_NO     Text(6)," '�`�[�ԍ�
            SQL = SQL & " DEN_EDA_NO     Single," '�`�[�}��
            SQL = SQL & " GYOU_NO        Text(2)," '�s�ԍ�
            SQL = SQL & " KOUJI_NO       Text(8)," '�H���ԍ�
            SQL = SQL & " EDA_NO         Text(4)," '�H���}��
            SQL = SQL & " NYUUKIN_YMD    Text(8)," '������
            SQL = SQL & " KINGAKU        Currency," '���z
            SQL = SQL & " CONSTRAINT KESIKOMI_DATA_UNIQUE PRIMARY KEY ("
            SQL = SQL & " SIME_YM," '���N��
            SQL = SQL & " SIME_DAY," '����
            SQL = SQL & " DENPYOU_NO," '�`�[�ԍ�
            SQL = SQL & " DEN_EDA_NO," '�`�[�}��
            SQL = SQL & " GYOU_NO" '�s�ԍ�
            SQL = SQL & " ))"

            'SQL�����s
            '2021.08.04 UPGRADE S  AIT)hieutv
            'SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText + ADODB.ExecuteOptionEnum.adExecuteNoRecords)
            ExecSQL(SQL)
            '2021.08.04 UPGRADE E

            '�߂�l�̃Z�b�g
            CREATE_KESIKOMI_DATA = True
            Exit Function

            '2021.07.26 UPGRADE S  AIT)Tool Convert
            'CREATE_KESIKOMI_DATA_Err:
        Catch ex As Exception
            '2021.07.26 UPGRADE E

            '2021.08.04 UPGRADE S  AIT)hieutv
            'Call Sql_Error_Msg("KESIKOMI_DATA CREATE")
            Call Sql_Error_Msg(ex, "KESIKOMI_DATA CREATE")
            '2021.08.04 UPGRADE E

        End Try     '2021.07.26 UPGRADE ADD AIT)Tool Convert
    End Function

    '-------------------------------------------------------------------------------
    '   ����   :   KESIKOMI_DATA TEXT WRITE
    '   �֐�   :   Sub TXT_WRITE_KESIKOMI_DATA()
    '   ����   :   TextName �e�L�X�g�t�@�C����
    '   �@�@       DT()�@   KESIKOMI_DATA_DBT
    '   �@�\   :   KESIKOMI_DATA TEXT WRITE ����(CSV�`��)
    '-------------------------------------------------------------------------------
    Public Sub TXT_WRITE_KESIKOMI_DATA(ByRef TextName As String, ByRef DT() As KESIKOMI_DATA_DBT)

        Dim Msg As String
        Dim lp As Integer
        Dim Out_Buf As String
        Dim FNo As Short

        On Error Resume Next

        '�e�L�X�g�t�@�C���̍폜
        If Dir(Trim(TextName)) <> "" Then
            Msg = "���ɓ����̃t�@�C�������݂��܂��B�㏑�����Ă���낵���ł����H"
            Msg = Msg & vbCrLf & vbCrLf & Trim(TextName)
            '2021.09.14 UPGRADE S  AIT)dannnl
            'If MsgBox(Msg, MsgBoxStyle.YesNo) = MsgBoxResult.No Then Exit Sub
            If MsgBox(Msg, MsgBoxStyle.YesNo, SYSTEMNM) = MsgBoxResult.No Then Exit Sub
            '2021.09.14 UPGRADE E
            Kill(Trim(TextName))
        End If

        '�e�L�X�g�t�@�C���I�[�v��
        FNo = FreeFile
        FileOpen(FNo, Trim(TextName), OpenMode.Output, OpenAccess.Write)

        '-----------------
        '�e�L�X�g���o������
        '-----------------
        For lp = 0 To UBound(DT)
            '�e�L�X�g�f�[�^���쐬���e�L�X�g�t�@�C������������
            Out_Buf = ""
            Out_Buf = Out_Buf & Chr(34) & CRSet(DT(lp).SIME_YM) & Chr(34) & "," '���N��
            Out_Buf = Out_Buf & Chr(34) & CRSet(DT(lp).SIME_DAY) & Chr(34) & "," '����
            Out_Buf = Out_Buf & Chr(34) & CRSet(DT(lp).DENPYOU_NO) & Chr(34) & "," '�`�[�ԍ�
            Out_Buf = Out_Buf & Chr(34) & CRSet(DT(lp).DEN_EDA_NO) & Chr(34) & "," '�`�[�}��
            Out_Buf = Out_Buf & Chr(34) & CRSet(DT(lp).GYOU_NO) & Chr(34) & "," '�s�ԍ�
            Out_Buf = Out_Buf & Chr(34) & CRSet(DT(lp).KOUJI_NO) & Chr(34) & "," '�H���ԍ�
            Out_Buf = Out_Buf & Chr(34) & CRSet(DT(lp).EDA_NO) & Chr(34) & "," '�H���}��
            Out_Buf = Out_Buf & Chr(34) & CRSet(DT(lp).NYUUKIN_YMD) & Chr(34) & "," '������
            Out_Buf = Out_Buf & Chr(34) & CRSet(DT(lp).KINGAKU) & Chr(34) & "" '���z
            PrintLine(FNo, Out_Buf)
        Next lp

        '�e�L�X�g�t�@�C���N���[�Y
        FileClose(FNo)

    End Sub

    '-------------------------------------------------------------------------------
    '   ����   :   KESIKOMI_DATA TEXT READ
    '   �֐�   :   Function TXT_READ_KESIKOMI_DATA()
    '   ����   :   TextName �e�L�X�g�t�@�C����
    '   �ߒl   :   �ް���   ����I��
    '   �@�@       -1�@     �ُ�I��
    '   �@�\   :   KESIKOMI_DATA TEXT READ ����(CSV�`��)
    '-------------------------------------------------------------------------------
    Public Function TXT_READ_KESIKOMI_DATA(ByRef TextName As String) As Integer

        Dim Jouken As String
        Dim FNo As Short
        Dim IB As String
        Dim Bp As Short
        Dim Sp As Short
        Dim Cnt As Integer
        Dim FLen As Integer
        Dim DT As KESIKOMI_DATA_DBT

        On Error Resume Next

        '�߂�l�̏�����
        TXT_READ_KESIKOMI_DATA = -1

        '�t�@�C�����݃`�F�b�N
        Err.Clear()
        FLen = FileLen(TextName)
        If Err.Number <> 0 Then
            TXT_READ_KESIKOMI_DATA = 0
            Exit Function
        End If

        '�e�L�X�g�t�@�C���I�[�v��
        FNo = FreeFile
        FileOpen(FNo, Trim(TextName), OpenMode.Input, OpenAccess.Read)

        '�e�L�X�g�t�@�C����ǂݍ���
        Do
            IB = LineInput(FNo)

            '�G���[�̏ꍇ�̓��[�v�𔲂���
            If Err.Number <> 0 Then Exit Do

            IB = IB & "," & Chr(34)
            Do
                Sp = InStr(IB, "~|")
                If Sp > 0 Then Mid(IB, Sp, 2) = Chr(13) & Chr(10) Else Exit Do
            Loop

            '�\���̂ɃZ�b�g
            Bp = 2
            Sp = InStr(Bp, IB, "," & Chr(34)) : DT.SIME_YM = Mid(IB, Bp, Sp - Bp - 1) : Bp = Sp + 2 '���N��
            Sp = InStr(Bp, IB, "," & Chr(34)) : DT.SIME_DAY = Mid(IB, Bp, Sp - Bp - 1) : Bp = Sp + 2 '����
            Sp = InStr(Bp, IB, "," & Chr(34)) : DT.DENPYOU_NO = Mid(IB, Bp, Sp - Bp - 1) : Bp = Sp + 2 '�`�[�ԍ�
            Sp = InStr(Bp, IB, "," & Chr(34)) : DT.DEN_EDA_NO = CSng(Mid(IB, Bp, Sp - Bp - 1)) : Bp = Sp + 2 '�`�[�}��
            Sp = InStr(Bp, IB, "," & Chr(34)) : DT.GYOU_NO = Mid(IB, Bp, Sp - Bp - 1) : Bp = Sp + 2 '�s�ԍ�
            Sp = InStr(Bp, IB, "," & Chr(34)) : DT.KOUJI_NO = Mid(IB, Bp, Sp - Bp - 1) : Bp = Sp + 2 '�H���ԍ�
            Sp = InStr(Bp, IB, "," & Chr(34)) : DT.EDA_NO = Mid(IB, Bp, Sp - Bp - 1) : Bp = Sp + 2 '�H���}��
            Sp = InStr(Bp, IB, "," & Chr(34)) : DT.NYUUKIN_YMD = Mid(IB, Bp, Sp - Bp - 1) : Bp = Sp + 2 '������
            Sp = InStr(Bp, IB, "," & Chr(34)) : DT.KINGAKU = CDec(Mid(IB, Bp, Sp - Bp - 1)) : Bp = Sp + 2 '���z

            '�f�[�^��o�^
            Jouken = ""
            Jouken = Jouken & " SIME_YM = '" & DT.SIME_YM & "' AND" '���N��
            Jouken = Jouken & " SIME_DAY = '" & DT.SIME_DAY & "' AND" '����
            Jouken = Jouken & " DENPYOU_NO = '" & DT.DENPYOU_NO & "' AND" '�`�[�ԍ�
            Jouken = Jouken & " DEN_EDA_NO = " & DT.DEN_EDA_NO & " AND" '�`�[�}��
            Jouken = Jouken & " GYOU_NO = '" & DT.GYOU_NO & "' AND" '�s�ԍ�
            If Right(Jouken, 4) = " AND" Then Jouken = Left(Jouken, Len(Jouken) - 4)
            If CNTGET_KESIKOMI_DATA(Jouken) = 0 Then
                If INSERT_KESIKOMI_DATA(DT) = False Then
                    Cnt = -1
                    Exit Do
                End If
            Else
                If UPDATE_KESIKOMI_DATA(Jouken, DT) = False Then
                    Cnt = -1
                    Exit Do
                End If
            End If

            '�f�[�^���J�E���g
            Cnt = Cnt + 1
        Loop

        '�e�L�X�g�t�@�C���N���[�Y
        FileClose(FNo)

        '�߂�l�̃Z�b�g
        TXT_READ_KESIKOMI_DATA = Cnt

    End Function
End Module
