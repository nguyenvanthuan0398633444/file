Imports GrapeCity.Win.Editors

<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frmSYKD020
#Region "Windows Form Designer generated code "
    <System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
        MyBase.New()
        'This call is required by the Windows Form Designer.
        InitializeComponent()
        '2021.02.02 UPGRADE ADD S AIT)hieutv
        cmdKey = New ArrayList()
        cmdKey.Add(Nothing)
        cmdKey.Add(_cmdKey_1)
        cmdKey.Add(_cmdKey_2)
        cmdKey.Add(_cmdKey_3)
        cmdKey.Add(_cmdKey_4)
        cmdKey.Add(_cmdKey_5)
        cmdKey.Add(_cmdKey_6)
        cmdKey.Add(_cmdKey_7)
        cmdKey.Add(_cmdKey_8)
        cmdKey.Add(_cmdKey_9)
        cmdKey.Add(_cmdKey_10)
        cmdKey.Add(_cmdKey_11)
        cmdKey.Add(_cmdKey_12)

        imText2 = New ArrayList()
        imText2.Add(_imText2_0)
        imText2.Add(_imText2_1)
        imText2.Add(_imText2_2)
        '2021.02.02 UPGRADE ADD E
    End Sub
    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
        If Disposing Then
            If Not components Is Nothing Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(Disposing)
    End Sub
    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer
    Public ToolTip1 As System.Windows.Forms.ToolTip
    Public WithEvents Command1 As System.Windows.Forms.Button
    Public WithEvents Picture2 As System.Windows.Forms.Panel
    Public WithEvents _cmdKey_5 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_2 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_11 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_1 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_9 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_8 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_7 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_6 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_10 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_4 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_12 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_3 As System.Windows.Forms.Button
    Public WithEvents Picture1 As System.Windows.Forms.Panel
    Public WithEvents _StatusBar1_Panel1 As System.Windows.Forms.ToolStripStatusLabel
    Public WithEvents Message As System.Windows.Forms.ToolStripStatusLabel
    Public WithEvents StatusBar1 As System.Windows.Forms.StatusStrip
    '2021.08.02 UPGRADE S  AIT)hieutv
    'Public WithEvents _imText2_2 As imText6.imText
    'Public WithEvents _imText2_0 As imText6.imText
    'Public WithEvents _imText2_1 As imText6.imText
    Public WithEvents _imText2_2 As GcTextBox
    Public WithEvents _imText2_0 As GcTextBox
    Public WithEvents _imText2_1 As GcTextBox
    'Public WithEvents vaSpread1 As AxFPSpread.AxvaSpread
    'Public WithEvents vaSpread2 As AxFPSpread.AxvaSpread
    '2021.08.02 UPGRADE E
    Public CommonDialog1Open As System.Windows.Forms.OpenFileDialog
    Public WithEvents lblTitle As System.Windows.Forms.Label
    '2021.08.02 UPGRADE S  AIT)hieutv
    'Public WithEvents cmdKey As Microsoft.VisualBasic.Compatibility.VB6.ButtonArray
    'Public WithEvents imText2 As imTextArray
    Public WithEvents cmdKey As ArrayList
    Public WithEvents imText2 As ArrayList
    '2021.08.02 UPGRADE E
    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim CustomSpdHeader As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim CustomSpdHeader1 As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim CustomSpdHeader2 As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim CustomSpdHeader3 As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim CustomSpdHeader4 As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim CustomSpdHeader5 As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim CustomSpdHeader6 As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim CustomSpdHeader15 As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim CustomSpdHeader16 As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim CustomSpdHeader17 As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim CustomSpdHeader18 As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim CustomSpdHeader7 As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim CustomSpdHeader8 As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim DefaultFocusIndicatorRenderer1 As FarPoint.Win.Spread.DefaultFocusIndicatorRenderer = New FarPoint.Win.Spread.DefaultFocusIndicatorRenderer()
        Dim DefaultScrollBarRenderer1 As FarPoint.Win.Spread.DefaultScrollBarRenderer = New FarPoint.Win.Spread.DefaultScrollBarRenderer()
        Dim NamedStyle1 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("Color65637634921916668362")
        Dim NamedStyle2 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("Font193637634921916688368")
        Dim TipAppearance1 As FarPoint.Win.Spread.TipAppearance = New FarPoint.Win.Spread.TipAppearance()
        Dim DefaultScrollBarRenderer2 As FarPoint.Win.Spread.DefaultScrollBarRenderer = New FarPoint.Win.Spread.DefaultScrollBarRenderer()
        Dim TextCellType1 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType()
        Dim ComplexBorder1 As FarPoint.Win.ComplexBorder = New FarPoint.Win.ComplexBorder(New FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThinLine))
        Dim TextCellType2 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType()
        Dim TextCellType3 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType()
        Dim TextCellType4 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType()
        Dim DefaultScrollBarRenderer3 As FarPoint.Win.Spread.DefaultScrollBarRenderer = New FarPoint.Win.Spread.DefaultScrollBarRenderer()
        Dim NamedStyle3 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("Color65637634924376310900")
        Dim NamedStyle4 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("Font193637634924376310900")
        Dim TipAppearance2 As FarPoint.Win.Spread.TipAppearance = New FarPoint.Win.Spread.TipAppearance()
        Dim DefaultScrollBarRenderer4 As FarPoint.Win.Spread.DefaultScrollBarRenderer = New FarPoint.Win.Spread.DefaultScrollBarRenderer()
        Dim ComplexBorder2 As FarPoint.Win.ComplexBorder = New FarPoint.Win.ComplexBorder(New FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.None), New FarPoint.Win.ComplexBorderSide(System.Drawing.Color.FromArgb(CType(CType(0,Byte),Integer), CType(CType(0,Byte),Integer), CType(CType(0,Byte),Integer))), New FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.None), New FarPoint.Win.ComplexBorderSide(System.Drawing.Color.FromArgb(CType(CType(0,Byte),Integer), CType(CType(0,Byte),Integer), CType(CType(0,Byte),Integer))), New FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.None), false, false)
        Dim TextCellType5 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType()
        Dim TextCellType6 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType()
        Dim TextCellType7 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType()
        Dim TextCellType8 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType()
        Dim ComplexBorder3 As FarPoint.Win.ComplexBorder = New FarPoint.Win.ComplexBorder(New FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.None), New FarPoint.Win.ComplexBorderSide(System.Drawing.Color.FromArgb(CType(CType(0,Byte),Integer), CType(CType(0,Byte),Integer), CType(CType(0,Byte),Integer))), New FarPoint.Win.ComplexBorderSide(System.Drawing.Color.FromArgb(CType(CType(0,Byte),Integer), CType(CType(0,Byte),Integer), CType(CType(0,Byte),Integer))), New FarPoint.Win.ComplexBorderSide(System.Drawing.Color.FromArgb(CType(CType(0,Byte),Integer), CType(CType(0,Byte),Integer), CType(CType(0,Byte),Integer))), New FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.None), false, false)
        Dim TextCellType9 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType()
        Dim TextCellType10 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType()
        Dim ComplexBorder4 As FarPoint.Win.ComplexBorder = New FarPoint.Win.ComplexBorder(New FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThinLine))
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmSYKD020))
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.Picture2 = New System.Windows.Forms.Panel()
        Me.Command1 = New System.Windows.Forms.Button()
        Me.Picture1 = New System.Windows.Forms.Panel()
        Me._cmdKey_5 = New System.Windows.Forms.Button()
        Me._cmdKey_2 = New System.Windows.Forms.Button()
        Me._cmdKey_11 = New System.Windows.Forms.Button()
        Me._cmdKey_1 = New System.Windows.Forms.Button()
        Me._cmdKey_9 = New System.Windows.Forms.Button()
        Me._cmdKey_8 = New System.Windows.Forms.Button()
        Me._cmdKey_7 = New System.Windows.Forms.Button()
        Me._cmdKey_6 = New System.Windows.Forms.Button()
        Me._cmdKey_10 = New System.Windows.Forms.Button()
        Me._cmdKey_4 = New System.Windows.Forms.Button()
        Me._cmdKey_12 = New System.Windows.Forms.Button()
        Me._cmdKey_3 = New System.Windows.Forms.Button()
        Me.StatusBar1 = New System.Windows.Forms.StatusStrip()
        Me._StatusBar1_Panel1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.Message = New System.Windows.Forms.ToolStripStatusLabel()
        Me._imText2_2 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._imText2_0 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._imText2_1 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me.CommonDialog1Open = New System.Windows.Forms.OpenFileDialog()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.FpSpread1 = New FarPoint.Win.Spread.FpSpread()
        Me.FpSpread1_Sheet1 = New FarPoint.Win.Spread.SheetView()
        Me.FpSpread2 = New FarPoint.Win.Spread.FpSpread()
        Me.FpSpread2_Sheet1 = New FarPoint.Win.Spread.SheetView()
        Me.Picture2.SuspendLayout
        Me.Picture1.SuspendLayout
        Me.StatusBar1.SuspendLayout
        CType(Me._imText2_2,System.ComponentModel.ISupportInitialize).BeginInit
        CType(Me._imText2_0,System.ComponentModel.ISupportInitialize).BeginInit
        CType(Me._imText2_1,System.ComponentModel.ISupportInitialize).BeginInit
        CType(Me.FpSpread1,System.ComponentModel.ISupportInitialize).BeginInit
        CType(Me.FpSpread1_Sheet1,System.ComponentModel.ISupportInitialize).BeginInit
        CType(Me.FpSpread2,System.ComponentModel.ISupportInitialize).BeginInit
        CType(Me.FpSpread2_Sheet1,System.ComponentModel.ISupportInitialize).BeginInit
        Me.SuspendLayout
        CustomSpdHeader.Name = "CustomSpdHeader"
        CustomSpdHeader.PictureZoomEffect = false
        CustomSpdHeader.TextRotationAngle = 0R
        CustomSpdHeader.ZoomFactor = 1!
        CustomSpdHeader1.Name = "CustomSpdHeader1"
        CustomSpdHeader1.PictureZoomEffect = false
        CustomSpdHeader1.TextRotationAngle = 0R
        CustomSpdHeader1.ZoomFactor = 1!
        CustomSpdHeader2.Name = "CustomSpdHeader2"
        CustomSpdHeader2.PictureZoomEffect = false
        CustomSpdHeader2.TextRotationAngle = 0R
        CustomSpdHeader2.ZoomFactor = 1!
        CustomSpdHeader3.Name = "CustomSpdHeader3"
        CustomSpdHeader3.PictureZoomEffect = false
        CustomSpdHeader3.TextRotationAngle = 0R
        CustomSpdHeader3.ZoomFactor = 1!
        CustomSpdHeader4.Name = "CustomSpdHeader4"
        CustomSpdHeader4.PictureZoomEffect = false
        CustomSpdHeader4.TextRotationAngle = 0R
        CustomSpdHeader4.ZoomFactor = 1!
        CustomSpdHeader5.Name = "CustomSpdHeader5"
        CustomSpdHeader5.PictureZoomEffect = false
        CustomSpdHeader5.TextRotationAngle = 0R
        CustomSpdHeader5.ZoomFactor = 1!
        CustomSpdHeader6.Name = "CustomSpdHeader6"
        CustomSpdHeader6.PictureZoomEffect = false
        CustomSpdHeader6.TextRotationAngle = 0R
        CustomSpdHeader6.ZoomFactor = 1!
        CustomSpdHeader15.Name = "CustomSpdHeader15"
        CustomSpdHeader15.PictureZoomEffect = false
        CustomSpdHeader15.TextRotationAngle = 0R
        CustomSpdHeader15.ZoomFactor = 1!
        CustomSpdHeader16.Name = "CustomSpdHeader16"
        CustomSpdHeader16.PictureZoomEffect = false
        CustomSpdHeader16.TextRotationAngle = 0R
        CustomSpdHeader16.ZoomFactor = 1!
        CustomSpdHeader17.Name = "CustomSpdHeader17"
        CustomSpdHeader17.PictureZoomEffect = false
        CustomSpdHeader17.TextRotationAngle = 0R
        CustomSpdHeader17.ZoomFactor = 1!
        CustomSpdHeader18.Name = "CustomSpdHeader18"
        CustomSpdHeader18.PictureZoomEffect = false
        CustomSpdHeader18.TextRotationAngle = 0R
        CustomSpdHeader18.ZoomFactor = 1!
        CustomSpdHeader7.Name = "CustomSpdHeader7"
        CustomSpdHeader7.PictureZoomEffect = false
        CustomSpdHeader7.TextRotationAngle = 0R
        CustomSpdHeader7.ZoomFactor = 1!
        CustomSpdHeader8.Name = "CustomSpdHeader8"
        CustomSpdHeader8.PictureZoomEffect = false
        CustomSpdHeader8.TextRotationAngle = 0R
        CustomSpdHeader8.ZoomFactor = 1!
        '
        'Picture2
        '
        Me.Picture2.BackColor = System.Drawing.SystemColors.Control
        Me.Picture2.Controls.Add(Me.Command1)
        Me.Picture2.Cursor = System.Windows.Forms.Cursors.Default
        Me.Picture2.Enabled = false
        Me.Picture2.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Picture2.Location = New System.Drawing.Point(698, 136)
        Me.Picture2.Name = "Picture2"
        Me.Picture2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Picture2.Size = New System.Drawing.Size(311, 43)
        Me.Picture2.TabIndex = 100
        Me.Picture2.Visible = false
        '
        'Command1
        '
        Me.Command1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255,Byte),Integer), CType(CType(192,Byte),Integer), CType(CType(255,Byte),Integer))
        Me.Command1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Command1.Font = New System.Drawing.Font("MS Mincho", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128,Byte))
        Me.Command1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Command1.Location = New System.Drawing.Point(0, 0)
        Me.Command1.Name = "Command1"
        Me.Command1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Command1.Size = New System.Drawing.Size(311, 43)
        Me.Command1.TabIndex = 101
        Me.Command1.TabStop = false
        Me.Command1.Text = "�e�L�X�g�Ǎ��ݒ����     "
        Me.Command1.UseVisualStyleBackColor = false
        '
        'Picture1
        '
        Me.Picture1.BackColor = System.Drawing.Color.FromArgb(CType(CType(128,Byte),Integer), CType(CType(128,Byte),Integer), CType(CType(128,Byte),Integer))
        Me.Picture1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Picture1.Controls.Add(Me._cmdKey_5)
        Me.Picture1.Controls.Add(Me._cmdKey_2)
        Me.Picture1.Controls.Add(Me._cmdKey_11)
        Me.Picture1.Controls.Add(Me._cmdKey_1)
        Me.Picture1.Controls.Add(Me._cmdKey_9)
        Me.Picture1.Controls.Add(Me._cmdKey_8)
        Me.Picture1.Controls.Add(Me._cmdKey_7)
        Me.Picture1.Controls.Add(Me._cmdKey_6)
        Me.Picture1.Controls.Add(Me._cmdKey_10)
        Me.Picture1.Controls.Add(Me._cmdKey_4)
        Me.Picture1.Controls.Add(Me._cmdKey_12)
        Me.Picture1.Controls.Add(Me._cmdKey_3)
        Me.Picture1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Picture1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Picture1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Picture1.Location = New System.Drawing.Point(0, 668)
        Me.Picture1.Name = "Picture1"
        Me.Picture1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Picture1.Size = New System.Drawing.Size(1016, 51)
        Me.Picture1.TabIndex = 102
        '
        '_cmdKey_5
        '
        Me._cmdKey_5.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_5.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_5.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128,Byte))
        Me._cmdKey_5.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_5.Location = New System.Drawing.Point(348, 4)
        Me._cmdKey_5.Name = "_cmdKey_5"
        Me._cmdKey_5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_5.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_5.TabIndex = 6
        Me._cmdKey_5.Tag = "�e�L�X�g�t�@�C����Ǎ��݂܂��B"
        Me._cmdKey_5.Text = "F5"&Global.Microsoft.VisualBasic.ChrW(13)&Global.Microsoft.VisualBasic.ChrW(10)&"�Ǎ���"
        Me._cmdKey_5.UseVisualStyleBackColor = false
        '
        '_cmdKey_2
        '
        Me._cmdKey_2.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_2.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_2.Enabled = false
        Me._cmdKey_2.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128,Byte))
        Me._cmdKey_2.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_2.Location = New System.Drawing.Point(86, 4)
        Me._cmdKey_2.Name = "_cmdKey_2"
        Me._cmdKey_2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_2.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_2.TabIndex = 3
        Me._cmdKey_2.Text = "F2"
        Me._cmdKey_2.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_2.UseVisualStyleBackColor = false
        '
        '_cmdKey_11
        '
        Me._cmdKey_11.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_11.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_11.Enabled = false
        Me._cmdKey_11.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128,Byte))
        Me._cmdKey_11.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_11.Location = New System.Drawing.Point(849, 4)
        Me._cmdKey_11.Name = "_cmdKey_11"
        Me._cmdKey_11.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_11.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_11.TabIndex = 12
        Me._cmdKey_11.Text = "F11"
        Me._cmdKey_11.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_11.UseVisualStyleBackColor = false
        '
        '_cmdKey_1
        '
        Me._cmdKey_1.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_1.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_1.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128,Byte))
        Me._cmdKey_1.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_1.Location = New System.Drawing.Point(6, 4)
        Me._cmdKey_1.Name = "_cmdKey_1"
        Me._cmdKey_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_1.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_1.TabIndex = 2
        Me._cmdKey_1.Tag = "���c��O�����o�̓��͂��s���܂��B"
        Me._cmdKey_1.Text = "F1"&Global.Microsoft.VisualBasic.ChrW(13)&Global.Microsoft.VisualBasic.ChrW(10)&"���o����"
        Me._cmdKey_1.UseVisualStyleBackColor = false
        '
        '_cmdKey_9
        '
        Me._cmdKey_9.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_9.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_9.Enabled = false
        Me._cmdKey_9.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128,Byte))
        Me._cmdKey_9.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_9.Location = New System.Drawing.Point(689, 4)
        Me._cmdKey_9.Name = "_cmdKey_9"
        Me._cmdKey_9.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_9.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_9.TabIndex = 10
        Me._cmdKey_9.Text = "F9"
        Me._cmdKey_9.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_9.UseVisualStyleBackColor = false
        '
        '_cmdKey_8
        '
        Me._cmdKey_8.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_8.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_8.Enabled = false
        Me._cmdKey_8.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128,Byte))
        Me._cmdKey_8.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_8.Location = New System.Drawing.Point(588, 4)
        Me._cmdKey_8.Name = "_cmdKey_8"
        Me._cmdKey_8.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_8.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_8.TabIndex = 9
        Me._cmdKey_8.Text = "F8"
        Me._cmdKey_8.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_8.UseVisualStyleBackColor = false
        '
        '_cmdKey_7
        '
        Me._cmdKey_7.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_7.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_7.Enabled = false
        Me._cmdKey_7.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128,Byte))
        Me._cmdKey_7.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_7.Location = New System.Drawing.Point(508, 4)
        Me._cmdKey_7.Name = "_cmdKey_7"
        Me._cmdKey_7.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_7.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_7.TabIndex = 8
        Me._cmdKey_7.Text = "F7"
        Me._cmdKey_7.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_7.UseVisualStyleBackColor = false
        '
        '_cmdKey_6
        '
        Me._cmdKey_6.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_6.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_6.Enabled = false
        Me._cmdKey_6.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128,Byte))
        Me._cmdKey_6.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_6.Location = New System.Drawing.Point(428, 4)
        Me._cmdKey_6.Name = "_cmdKey_6"
        Me._cmdKey_6.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_6.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_6.TabIndex = 7
        Me._cmdKey_6.Text = "F6"
        Me._cmdKey_6.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_6.UseVisualStyleBackColor = false
        '
        '_cmdKey_10
        '
        Me._cmdKey_10.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_10.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_10.Enabled = false
        Me._cmdKey_10.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128,Byte))
        Me._cmdKey_10.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_10.Location = New System.Drawing.Point(769, 4)
        Me._cmdKey_10.Name = "_cmdKey_10"
        Me._cmdKey_10.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_10.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_10.TabIndex = 11
        Me._cmdKey_10.Text = "F10"
        Me._cmdKey_10.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_10.UseVisualStyleBackColor = false
        '
        '_cmdKey_4
        '
        Me._cmdKey_4.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_4.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_4.Enabled = false
        Me._cmdKey_4.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128,Byte))
        Me._cmdKey_4.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_4.Location = New System.Drawing.Point(246, 4)
        Me._cmdKey_4.Name = "_cmdKey_4"
        Me._cmdKey_4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_4.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_4.TabIndex = 5
        Me._cmdKey_4.Text = "F4"
        Me._cmdKey_4.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_4.UseVisualStyleBackColor = false
        '
        '_cmdKey_12
        '
        Me._cmdKey_12.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_12.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_12.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128,Byte))
        Me._cmdKey_12.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_12.Location = New System.Drawing.Point(929, 4)
        Me._cmdKey_12.Name = "_cmdKey_12"
        Me._cmdKey_12.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_12.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_12.TabIndex = 13
        Me._cmdKey_12.Tag = "�������I�����܂��B"
        Me._cmdKey_12.Text = "F12"&Global.Microsoft.VisualBasic.ChrW(13)&Global.Microsoft.VisualBasic.ChrW(10)&"�I��"
        Me._cmdKey_12.UseVisualStyleBackColor = false
        '
        '_cmdKey_3
        '
        Me._cmdKey_3.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_3.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_3.Enabled = false
        Me._cmdKey_3.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128,Byte))
        Me._cmdKey_3.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_3.Location = New System.Drawing.Point(166, 4)
        Me._cmdKey_3.Name = "_cmdKey_3"
        Me._cmdKey_3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_3.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_3.TabIndex = 4
        Me._cmdKey_3.Text = "F3"
        Me._cmdKey_3.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_3.UseVisualStyleBackColor = false
        '
        'StatusBar1
        '
        Me.StatusBar1.Font = New System.Drawing.Font("MS Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128,Byte))
        Me.StatusBar1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me._StatusBar1_Panel1, Me.Message})
        Me.StatusBar1.Location = New System.Drawing.Point(0, 719)
        Me.StatusBar1.Name = "StatusBar1"
        Me.StatusBar1.Size = New System.Drawing.Size(1016, 23)
        Me.StatusBar1.TabIndex = 2
        '
        '_StatusBar1_Panel1
        '
        Me._StatusBar1_Panel1.AutoSize = false
        Me._StatusBar1_Panel1.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top)  _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right)  _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom),System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me._StatusBar1_Panel1.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter
        Me._StatusBar1_Panel1.Margin = New System.Windows.Forms.Padding(0)
        Me._StatusBar1_Panel1.Name = "_StatusBar1_Panel1"
        Me._StatusBar1_Panel1.Size = New System.Drawing.Size(117, 23)
        '
        'Message
        '
        Me.Message.AutoSize = false
        Me.Message.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top)  _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right)  _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom),System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me.Message.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter
        Me.Message.Margin = New System.Windows.Forms.Padding(0)
        Me.Message.Name = "Message"
        Me.Message.Size = New System.Drawing.Size(886, 23)
        Me.Message.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        '_imText2_2
        '
        Me._imText2_2.BackColor = System.Drawing.Color.FromArgb(CType(CType(192,Byte),Integer), CType(CType(192,Byte),Integer), CType(CType(255,Byte),Integer))
        Me._imText2_2.Font = New System.Drawing.Font("MS Mincho", 12!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me._imText2_2.ImeMode = System.Windows.Forms.ImeMode.Off
        Me._imText2_2.Location = New System.Drawing.Point(576, 6)
        Me._imText2_2.Name = "_imText2_2"
        Me._imText2_2.ReadOnly = true
        Me._imText2_2.ReadOnlyBackColor = System.Drawing.Color.FromArgb(CType(CType(192,Byte),Integer), CType(CType(192,Byte),Integer), CType(CType(255,Byte),Integer))
        Me._imText2_2.Size = New System.Drawing.Size(433, 23)
        Me._imText2_2.TabIndex = 3
        Me._imText2_2.TabStop = false
        '
        '_imText2_0
        '
        Me._imText2_0.BackColor = System.Drawing.Color.FromArgb(CType(CType(192,Byte),Integer), CType(CType(192,Byte),Integer), CType(CType(255,Byte),Integer))
        Me._imText2_0.ContentAlignment = System.Drawing.ContentAlignment.TopCenter
        Me._imText2_0.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._imText2_0.ImeMode = System.Windows.Forms.ImeMode.Off
        Me._imText2_0.Location = New System.Drawing.Point(440, 6)
        Me._imText2_0.Name = "_imText2_0"
        Me._imText2_0.ReadOnly = True
        Me._imText2_0.ReadOnlyBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me._imText2_0.Size = New System.Drawing.Size(83, 23)
        Me._imText2_0.TabIndex = 4
        Me._imText2_0.TabStop = False
        '
        '_imText2_1
        '
        Me._imText2_1.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me._imText2_1.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._imText2_1.ImeMode = System.Windows.Forms.ImeMode.Off
        Me._imText2_1.Location = New System.Drawing.Point(527, 6)
        Me._imText2_1.Name = "_imText2_1"
        Me._imText2_1.ReadOnly = True
        Me._imText2_1.ReadOnlyBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me._imText2_1.Size = New System.Drawing.Size(45, 23)
        Me._imText2_1.TabIndex = 5
        Me._imText2_1.TabStop = False
        '
        'lblTitle
        '
        Me.lblTitle.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblTitle.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTitle.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblTitle.Font = New System.Drawing.Font("MS Mincho", 20.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblTitle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.lblTitle.Location = New System.Drawing.Point(0, 0)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblTitle.Size = New System.Drawing.Size(1015, 34)
        Me.lblTitle.TabIndex = 6
        Me.lblTitle.Text = " ���c��O�����o�ꗗ"
        '
        'FpSpread1
        '
        Me.FpSpread1.AccessibleDescription = "FpSpread1, Sheet1, Row 0, Column 0"
        Me.FpSpread1.AllowUserToTouchZoom = False
        Me.FpSpread1.AllowUserZoom = False
        Me.FpSpread1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.FpSpread1.FocusRenderer = DefaultFocusIndicatorRenderer1
        Me.FpSpread1.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FpSpread1.HorizontalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.FpSpread1.HorizontalScrollBar.Name = ""
        Me.FpSpread1.HorizontalScrollBar.Renderer = DefaultScrollBarRenderer1
        Me.FpSpread1.HorizontalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.Never
        Me.FpSpread1.Location = New System.Drawing.Point(18, 54)
        Me.FpSpread1.Name = "FpSpread1"
        NamedStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        NamedStyle1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        NamedStyle1.Locked = False
        NamedStyle2.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        NamedStyle2.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold)
        NamedStyle2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        NamedStyle2.Locked = False
        Me.FpSpread1.RowSplitBoxPolicy = FarPoint.Win.Spread.SplitBoxPolicy.Never
        Me.FpSpread1.ScrollBarTrackPolicy = FarPoint.Win.Spread.ScrollBarTrackPolicy.Vertical
        Me.FpSpread1.SelectionBlockOptions = FarPoint.Win.Spread.SelectionBlockOptions.None
        Me.FpSpread1.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.FpSpread1_Sheet1})
        Me.FpSpread1.Size = New System.Drawing.Size(956, 574)
        Me.FpSpread1.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Classic
        Me.FpSpread1.NamedStyles.AddRange(New FarPoint.Win.Spread.NamedStyle() {NamedStyle1, NamedStyle2})
        Me.FpSpread1.TabIndex = 1
        Me.FpSpread1.Tag = "�H���I�����ĉ������B"
        TipAppearance1.BackColor = System.Drawing.SystemColors.Info
        TipAppearance1.Font = New System.Drawing.Font("MS PGothic", 9!)
        TipAppearance1.ForeColor = System.Drawing.SystemColors.InfoText
        Me.FpSpread1.TextTipAppearance = TipAppearance1
        Me.FpSpread1.VerticalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.FpSpread1.VerticalScrollBar.Name = ""
        Me.FpSpread1.VerticalScrollBar.Renderer = DefaultScrollBarRenderer2
        Me.FpSpread1.VisualStyles = FarPoint.Win.VisualStyles.Off
        '
        'FpSpread1_Sheet1
        '
        Me.FpSpread1_Sheet1.Reset
        Me.FpSpread1_Sheet1.SheetName = "Sheet1"
        'Formulas and custom names must be loaded with R1C1 reference style
        Me.FpSpread1_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1
        Me.FpSpread1_Sheet1.ColumnCount = 7
        Me.FpSpread1_Sheet1.RowCount = 100
        Me.FpSpread1_Sheet1.ActiveSkin = FarPoint.Win.Spread.DefaultSkins.Default
        Me.FpSpread1_Sheet1.Cells.Get(0, 0).Value = "A-00"
        TextCellType1.Static = true
        Me.FpSpread1_Sheet1.Cells.Get(0, 2).CellType = TextCellType1
        Me.FpSpread1_Sheet1.Cells.Get(0, 2).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Left
        Me.FpSpread1_Sheet1.Cells.Get(0, 2).Value = "�P�Q�R�S�T�U�V�W�X�O�P�Q�R�S�T�U�V�W�X�O"
        Me.FpSpread1_Sheet1.Cells.Get(0, 2).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread1_Sheet1.Cells.Get(0, 3).Value = "104,137,784"
        Me.FpSpread1_Sheet1.Cells.Get(0, 4).Value = "1,080,000"
        Me.FpSpread1_Sheet1.Cells.Get(0, 5).Value = "101,408,660"
        Me.FpSpread1_Sheet1.Cells.Get(0, 6).Value = "1,649,124"
        Me.FpSpread1_Sheet1.Cells.Get(1, 0).Value = "B-00"
        Me.FpSpread1_Sheet1.Cells.Get(1, 2).CellType = TextCellType1
        Me.FpSpread1_Sheet1.Cells.Get(1, 2).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Left
        Me.FpSpread1_Sheet1.Cells.Get(1, 2).Value = "1234567890123456789012345678901234567890"
        Me.FpSpread1_Sheet1.Cells.Get(1, 2).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread1_Sheet1.Cells.Get(1, 3).Value = "11,403,080"
        Me.FpSpread1_Sheet1.Cells.Get(1, 4).Value = "3,403,080"
        Me.FpSpread1_Sheet1.Cells.Get(1, 5).Value = "9,591,340"
        Me.FpSpread1_Sheet1.Cells.Get(1, 6).Value = "-1,591,340"
        Me.FpSpread1_Sheet1.Cells.Get(2, 1).Value = "B-01"
        Me.FpSpread1_Sheet1.Cells.Get(2, 2).CellType = TextCellType1
        Me.FpSpread1_Sheet1.Cells.Get(2, 2).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Left
        Me.FpSpread1_Sheet1.Cells.Get(2, 2).Value = "�@1234567890123456789012345678901234567890"
        Me.FpSpread1_Sheet1.Cells.Get(2, 2).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread1_Sheet1.Cells.Get(2, 3).Value = "246,500"
        Me.FpSpread1_Sheet1.Cells.Get(2, 4).Value = "246,500"
        Me.FpSpread1_Sheet1.Cells.Get(2, 5).Value = "0"
        Me.FpSpread1_Sheet1.Cells.Get(2, 6).Value = "0"
        Me.FpSpread1_Sheet1.Cells.Get(3, 1).Value = "B-02"
        Me.FpSpread1_Sheet1.Cells.Get(3, 2).CellType = TextCellType1
        Me.FpSpread1_Sheet1.Cells.Get(3, 2).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Left
        Me.FpSpread1_Sheet1.Cells.Get(3, 2).Value = "�@�P�Q�R�S�T�U�V�W�X�O�P�Q�R�S�T�U�V�W�X�O"
        Me.FpSpread1_Sheet1.Cells.Get(3, 2).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread1_Sheet1.Cells.Get(3, 3).Value = "670,000"
        Me.FpSpread1_Sheet1.Cells.Get(3, 4).Value = "670,000"
        Me.FpSpread1_Sheet1.Cells.Get(3, 5).Value = "0"
        Me.FpSpread1_Sheet1.Cells.Get(3, 6).Value = "0"
        Me.FpSpread1_Sheet1.Cells.Get(4, 1).Value = "B-03"
        Me.FpSpread1_Sheet1.Cells.Get(4, 2).Value = "�@���ݘJ����"
        Me.FpSpread1_Sheet1.Cells.Get(4, 3).Value = "360,000"
        Me.FpSpread1_Sheet1.Cells.Get(4, 4).Value = "360,000"
        Me.FpSpread1_Sheet1.Cells.Get(4, 5).Value = "0"
        Me.FpSpread1_Sheet1.Cells.Get(4, 6).Value = "0"
        Me.FpSpread1_Sheet1.Cells.Get(5, 1).Value = "B-04"
        Me.FpSpread1_Sheet1.Cells.Get(5, 2).Value = "�@�n��A�ƒ�"
        Me.FpSpread1_Sheet1.Cells.Get(5, 3).Value = "228,000"
        Me.FpSpread1_Sheet1.Cells.Get(5, 4).Value = "228,000"
        Me.FpSpread1_Sheet1.Cells.Get(5, 5).Value = "0"
        Me.FpSpread1_Sheet1.Cells.Get(5, 6).Value = "0"
        Me.FpSpread1_Sheet1.Cells.Get(6, 1).Value = "B-05"
        Me.FpSpread1_Sheet1.Cells.Get(6, 2).Value = "�@�c�U��"
        Me.FpSpread1_Sheet1.Cells.Get(6, 3).Value = "575,580"
        Me.FpSpread1_Sheet1.Cells.Get(6, 4).Value = "575,580"
        Me.FpSpread1_Sheet1.Cells.Get(6, 5).Value = "0"
        Me.FpSpread1_Sheet1.Cells.Get(6, 6).Value = "0"
        Me.FpSpread1_Sheet1.Cells.Get(7, 1).Value = "B-06"
        Me.FpSpread1_Sheet1.Cells.Get(7, 2).Value = "�@���ݓ���"
        Me.FpSpread1_Sheet1.Cells.Get(7, 3).Value = "90,000"
        Me.FpSpread1_Sheet1.Cells.Get(7, 4).Value = "90,000"
        Me.FpSpread1_Sheet1.Cells.Get(7, 5).Value = "0"
        Me.FpSpread1_Sheet1.Cells.Get(7, 6).Value = "0"
        Me.FpSpread1_Sheet1.Cells.Get(8, 1).Value = "B-07"
        Me.FpSpread1_Sheet1.Cells.Get(8, 2).Value = "�@�⏞��"
        Me.FpSpread1_Sheet1.Cells.Get(8, 3).Value = "120,000"
        Me.FpSpread1_Sheet1.Cells.Get(8, 4).Value = "120,000"
        Me.FpSpread1_Sheet1.Cells.Get(8, 5).Value = "0"
        Me.FpSpread1_Sheet1.Cells.Get(8, 6).Value = "0"
        Me.FpSpread1_Sheet1.Cells.Get(9, 1).Value = "B-08"
        Me.FpSpread1_Sheet1.Cells.Get(9, 2).Value = "�@�{�H�i���Ǘ���"
        Me.FpSpread1_Sheet1.Cells.Get(9, 3).Value = "556,000"
        Me.FpSpread1_Sheet1.Cells.Get(9, 4).Value = "556,000"
        Me.FpSpread1_Sheet1.Cells.Get(9, 5).Value = "0"
        Me.FpSpread1_Sheet1.Cells.Get(9, 6).Value = "0"
        Me.FpSpread1_Sheet1.Cells.Get(10, 1).Value = "B-09"
        Me.FpSpread1_Sheet1.Cells.Get(10, 2).Value = "�@�G�H���"
        Me.FpSpread1_Sheet1.Cells.Get(10, 3).Value = "30,000"
        Me.FpSpread1_Sheet1.Cells.Get(10, 4).Value = "30,000"
        Me.FpSpread1_Sheet1.Cells.Get(10, 5).Value = "0"
        Me.FpSpread1_Sheet1.Cells.Get(10, 6).Value = "0"
        Me.FpSpread1_Sheet1.Cells.Get(11, 1).Value = "B-10"
        Me.FpSpread1_Sheet1.Cells.Get(11, 2).Value = "�@�@�B�Ǘ���"
        Me.FpSpread1_Sheet1.Cells.Get(11, 3).Value = "30,000"
        Me.FpSpread1_Sheet1.Cells.Get(11, 4).Value = "30,000"
        Me.FpSpread1_Sheet1.Cells.Get(11, 5).Value = "0"
        Me.FpSpread1_Sheet1.Cells.Get(11, 6).Value = "0"
        Me.FpSpread1_Sheet1.Cells.Get(12, 1).Value = "B-11"
        Me.FpSpread1_Sheet1.Cells.Get(12, 2).Value = "�@���S�Ǘ���"
        Me.FpSpread1_Sheet1.Cells.Get(12, 3).Value = "497,000"
        Me.FpSpread1_Sheet1.Cells.Get(12, 4).Value = "497,000"
        Me.FpSpread1_Sheet1.Cells.Get(12, 5).Value = "0"
        Me.FpSpread1_Sheet1.Cells.Get(12, 6).Value = "0"
        Me.FpSpread1_Sheet1.Cells.Get(13, 1).Value = "B-12"
        Me.FpSpread1_Sheet1.Cells.Get(13, 2).Value = "�@�����o��"
        Me.FpSpread1_Sheet1.Cells.Get(13, 3).Value = "8,000,000"
        Me.FpSpread1_Sheet1.Cells.Get(13, 4).Value = "0"
        Me.FpSpread1_Sheet1.Cells.Get(13, 5).Value = "9,591,340"
        Me.FpSpread1_Sheet1.Cells.Get(13, 6).Value = "-1,591,340"
        Me.FpSpread1_Sheet1.Cells.Get(14, 0).Value = "C-00"
        Me.FpSpread1_Sheet1.Cells.Get(14, 2).Value = "����o��"
        Me.FpSpread1_Sheet1.Cells.Get(14, 3).Value = "10,759,136"
        Me.FpSpread1_Sheet1.Cells.Get(14, 4).Value = "10,816,920"
        Me.FpSpread1_Sheet1.Cells.Get(14, 5).Value = "0"
        Me.FpSpread1_Sheet1.Cells.Get(14, 6).Value = "-57,784"
        Me.FpSpread1_Sheet1.Cells.Get(15, 1).Value = "C-01"
        Me.FpSpread1_Sheet1.Cells.Get(15, 2).Value = "�@���͗p�����M��"
        Me.FpSpread1_Sheet1.Cells.Get(15, 3).Value = "198,000"
        Me.FpSpread1_Sheet1.Cells.Get(15, 4).Value = "198,000"
        Me.FpSpread1_Sheet1.Cells.Get(15, 5).Value = "0"
        Me.FpSpread1_Sheet1.Cells.Get(15, 6).Value = "0"
        Me.FpSpread1_Sheet1.Cells.Get(16, 1).Value = "C-02"
        Me.FpSpread1_Sheet1.Cells.Get(16, 2).Value = "�@�d�Ō���"
        Me.FpSpread1_Sheet1.Cells.Get(16, 3).Value = "120,000"
        Me.FpSpread1_Sheet1.Cells.Get(16, 4).Value = "120,000"
        Me.FpSpread1_Sheet1.Cells.Get(16, 5).Value = "0"
        Me.FpSpread1_Sheet1.Cells.Get(16, 6).Value = "0"
        Me.FpSpread1_Sheet1.Cells.Get(17, 1).Value = "C-03"
        Me.FpSpread1_Sheet1.Cells.Get(17, 2).Value = "�@�@�蕟����"
        Me.FpSpread1_Sheet1.Cells.Get(17, 3).Value = "1,520,000"
        Me.FpSpread1_Sheet1.Cells.Get(17, 4).Value = "1,520,000"
        Me.FpSpread1_Sheet1.Cells.Get(17, 5).Value = "0"
        Me.FpSpread1_Sheet1.Cells.Get(17, 6).Value = "0"
        Me.FpSpread1_Sheet1.Cells.Get(18, 1).Value = "C-04"
        Me.FpSpread1_Sheet1.Cells.Get(18, 2).Value = "�@����������"
        Me.FpSpread1_Sheet1.Cells.Get(18, 3).Value = "18,200"
        Me.FpSpread1_Sheet1.Cells.Get(18, 4).Value = "18,200"
        Me.FpSpread1_Sheet1.Cells.Get(18, 5).Value = "0"
        Me.FpSpread1_Sheet1.Cells.Get(18, 6).Value = "0"
        Me.FpSpread1_Sheet1.Cells.Get(19, 1).Value = "C-05"
        Me.FpSpread1_Sheet1.Cells.Get(19, 2).Value = "�@�����p�i��"
        Me.FpSpread1_Sheet1.Cells.Get(19, 3).Value = "186,000"
        Me.FpSpread1_Sheet1.Cells.Get(19, 4).Value = "186,000"
        Me.FpSpread1_Sheet1.Cells.Get(19, 5).Value = "0"
        Me.FpSpread1_Sheet1.Cells.Get(19, 6).Value = "0"
        Me.FpSpread1_Sheet1.Cells.Get(20, 1).Value = "C-06"
        Me.FpSpread1_Sheet1.Cells.Get(20, 2).Value = "�@�����ʔ�"
        Me.FpSpread1_Sheet1.Cells.Get(20, 3).Value = "195,000"
        Me.FpSpread1_Sheet1.Cells.Get(20, 4).Value = "195,000"
        Me.FpSpread1_Sheet1.Cells.Get(20, 5).Value = "0"
        Me.FpSpread1_Sheet1.Cells.Get(20, 6).Value = "0"
        Me.FpSpread1_Sheet1.Cells.Get(21, 1).Value = "C-07"
        Me.FpSpread1_Sheet1.Cells.Get(21, 2).Value = "�@�l����"
        Me.FpSpread1_Sheet1.Cells.Get(21, 3).Value = "7,150,000"
        Me.FpSpread1_Sheet1.Cells.Get(21, 4).Value = "7,150,000"
        Me.FpSpread1_Sheet1.Cells.Get(21, 5).Value = "0"
        Me.FpSpread1_Sheet1.Cells.Get(21, 6).Value = "0"
        Me.FpSpread1_Sheet1.Cells.Get(22, 1).Value = "C-08"
        Me.FpSpread1_Sheet1.Cells.Get(22, 2).Value = "�@�J���Ǘ���"
        Me.FpSpread1_Sheet1.Cells.Get(22, 3).Value = "493,500"
        Me.FpSpread1_Sheet1.Cells.Get(22, 4).Value = "493,500"
        Me.FpSpread1_Sheet1.Cells.Get(22, 5).Value = "0"
        Me.FpSpread1_Sheet1.Cells.Get(22, 6).Value = "0"
        Me.FpSpread1_Sheet1.Cells.Get(23, 1).Value = "C-09"
        Me.FpSpread1_Sheet1.Cells.Get(23, 2).Value = "�@�ʐM��"
        Me.FpSpread1_Sheet1.Cells.Get(23, 3).Value = "60,000"
        Me.FpSpread1_Sheet1.Cells.Get(23, 4).Value = "60,000"
        Me.FpSpread1_Sheet1.Cells.Get(23, 5).Value = "0"
        Me.FpSpread1_Sheet1.Cells.Get(23, 6).Value = "0"
        Me.FpSpread1_Sheet1.Cells.Get(24, 1).Value = "C-10"
        Me.FpSpread1_Sheet1.Cells.Get(24, 2).Value = "�@�ł����킹���"
        Me.FpSpread1_Sheet1.Cells.Get(24, 3).Value = "120,000"
        Me.FpSpread1_Sheet1.Cells.Get(24, 4).Value = "120,000"
        Me.FpSpread1_Sheet1.Cells.Get(24, 5).Value = "0"
        Me.FpSpread1_Sheet1.Cells.Get(24, 6).Value = "0"
        Me.FpSpread1_Sheet1.Cells.Get(25, 1).Value = "C-11"
        Me.FpSpread1_Sheet1.Cells.Get(25, 2).Value = "�@�G��"
        Me.FpSpread1_Sheet1.Cells.Get(25, 3).Value = "698,436"
        Me.FpSpread1_Sheet1.Cells.Get(25, 4).Value = "756,220"
        Me.FpSpread1_Sheet1.Cells.Get(25, 5).Value = "0"
        Me.FpSpread1_Sheet1.Cells.Get(25, 6).Value = "-57,784"
        Me.FpSpread1_Sheet1.ColumnFooter.Columns.Default.Resizable = true
        Me.FpSpread1_Sheet1.ColumnFooter.Columns.Default.SortIndicator = FarPoint.Win.Spread.Model.SortIndicator.None
        Me.FpSpread1_Sheet1.ColumnFooter.Columns.Default.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread1_Sheet1.ColumnFooter.DefaultStyle.BackColor = System.Drawing.Color.Empty
        Me.FpSpread1_Sheet1.ColumnFooter.DefaultStyle.ForeColor = System.Drawing.Color.Empty
        Me.FpSpread1_Sheet1.ColumnFooter.DefaultStyle.Locked = false
        Me.FpSpread1_Sheet1.ColumnFooter.DefaultStyle.Parent = "HeaderDefault"
        Me.FpSpread1_Sheet1.ColumnFooter.DefaultStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread1_Sheet1.ColumnFooter.Rows.Default.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread1_Sheet1.ColumnFooterSheetCornerStyle.BackColor = System.Drawing.Color.Empty
        Me.FpSpread1_Sheet1.ColumnFooterSheetCornerStyle.ForeColor = System.Drawing.Color.Empty
        Me.FpSpread1_Sheet1.ColumnFooterSheetCornerStyle.Locked = false
        Me.FpSpread1_Sheet1.ColumnFooterSheetCornerStyle.Parent = "RowHeaderDefault"
        Me.FpSpread1_Sheet1.ColumnFooterSheetCornerStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 0).Value = "�H��"
        Me.FpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = " "
        Me.FpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 2).Value = "��  ��"
        Me.FpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 3).Value = "��ɖ��͎�ɗ\��"
        Me.FpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 4).Value = "���@�c"
        Me.FpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 5).Value = "�O�@��"
        Me.FpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 6).Value = "���@�z"
        Me.FpSpread1_Sheet1.ColumnHeader.Columns.Default.Resizable = true
        Me.FpSpread1_Sheet1.ColumnHeader.Columns.Default.SortIndicator = FarPoint.Win.Spread.Model.SortIndicator.None
        Me.FpSpread1_Sheet1.ColumnHeader.Columns.Default.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread1_Sheet1.ColumnHeader.DefaultStyle.BackColor = System.Drawing.Color.Empty
        Me.FpSpread1_Sheet1.ColumnHeader.DefaultStyle.Border = ComplexBorder1
        Me.FpSpread1_Sheet1.ColumnHeader.DefaultStyle.Font = New System.Drawing.Font("MS Mincho", 12!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128,Byte))
        Me.FpSpread1_Sheet1.ColumnHeader.DefaultStyle.ForeColor = System.Drawing.Color.Empty
        Me.FpSpread1_Sheet1.ColumnHeader.DefaultStyle.Locked = false
        Me.FpSpread1_Sheet1.ColumnHeader.DefaultStyle.Parent = "HeaderDefault"
        Me.FpSpread1_Sheet1.ColumnHeader.DefaultStyle.Renderer = CustomSpdHeader7
        Me.FpSpread1_Sheet1.ColumnHeader.DefaultStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread1_Sheet1.ColumnHeader.Rows.Default.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread1_Sheet1.ColumnHeader.Rows.Get(0).Height = 26!
        Me.FpSpread1_Sheet1.Columns.Default.Resizable = true
        Me.FpSpread1_Sheet1.Columns.Default.SortIndicator = FarPoint.Win.Spread.Model.SortIndicator.None
        TextCellType2.Static = true
        Me.FpSpread1_Sheet1.Columns.Get(0).CellType = TextCellType2
        Me.FpSpread1_Sheet1.Columns.Get(0).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.FpSpread1_Sheet1.Columns.Get(0).Label = "�H��"
        Me.FpSpread1_Sheet1.Columns.Get(0).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread1_Sheet1.Columns.Get(0).Width = 53!
        Me.FpSpread1_Sheet1.Columns.Get(1).CellType = TextCellType2
        Me.FpSpread1_Sheet1.Columns.Get(1).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.FpSpread1_Sheet1.Columns.Get(1).Label = " "
        Me.FpSpread1_Sheet1.Columns.Get(1).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread1_Sheet1.Columns.Get(1).Width = 55!
        Me.FpSpread1_Sheet1.Columns.Get(2).CellType = TextCellType1
        Me.FpSpread1_Sheet1.Columns.Get(2).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Left
        Me.FpSpread1_Sheet1.Columns.Get(2).Label = "��  ��"
        Me.FpSpread1_Sheet1.Columns.Get(2).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread1_Sheet1.Columns.Get(2).Width = 260!
        TextCellType3.Static = true
        Me.FpSpread1_Sheet1.Columns.Get(3).CellType = TextCellType3
        Me.FpSpread1_Sheet1.Columns.Get(3).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Right
        Me.FpSpread1_Sheet1.Columns.Get(3).Label = "��ɖ��͎�ɗ\��"
        Me.FpSpread1_Sheet1.Columns.Get(3).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread1_Sheet1.Columns.Get(3).Width = 152!
        Me.FpSpread1_Sheet1.Columns.Get(4).CellType = TextCellType3
        Me.FpSpread1_Sheet1.Columns.Get(4).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Right
        Me.FpSpread1_Sheet1.Columns.Get(4).Label = "���@�c"
        Me.FpSpread1_Sheet1.Columns.Get(4).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread1_Sheet1.Columns.Get(4).Width = 124!
        Me.FpSpread1_Sheet1.Columns.Get(5).CellType = TextCellType3
        Me.FpSpread1_Sheet1.Columns.Get(5).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Right
        Me.FpSpread1_Sheet1.Columns.Get(5).Label = "�O�@��"
        Me.FpSpread1_Sheet1.Columns.Get(5).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread1_Sheet1.Columns.Get(5).Width = 124!
        Me.FpSpread1_Sheet1.Columns.Get(6).CellType = TextCellType3
        Me.FpSpread1_Sheet1.Columns.Get(6).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Right
        Me.FpSpread1_Sheet1.Columns.Get(6).Label = "���@�z"
        Me.FpSpread1_Sheet1.Columns.Get(6).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread1_Sheet1.Columns.Get(6).Width = 124!
        Me.FpSpread1_Sheet1.DefaultStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(255,Byte),Integer), CType(CType(255,Byte),Integer), CType(CType(255,Byte),Integer))
        TextCellType4.MaxLength = 60
        Me.FpSpread1_Sheet1.DefaultStyle.CellType = TextCellType4
        Me.FpSpread1_Sheet1.DefaultStyle.Font = New System.Drawing.Font("MS Mincho", 12!, System.Drawing.FontStyle.Bold)
        Me.FpSpread1_Sheet1.DefaultStyle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0,Byte),Integer), CType(CType(0,Byte),Integer), CType(CType(0,Byte),Integer))
        Me.FpSpread1_Sheet1.DefaultStyle.Locked = true
        Me.FpSpread1_Sheet1.DefaultStyle.Parent = "DataAreaDefault"
        Me.FpSpread1_Sheet1.DefaultStyle.Renderer = TextCellType4
        Me.FpSpread1_Sheet1.FilterBar.DefaultStyle.BackColor = System.Drawing.Color.Empty
        Me.FpSpread1_Sheet1.FilterBar.DefaultStyle.ForeColor = System.Drawing.Color.Empty
        Me.FpSpread1_Sheet1.FilterBar.DefaultStyle.Locked = false
        Me.FpSpread1_Sheet1.FilterBar.DefaultStyle.Parent = "FilterBarDefault"
        Me.FpSpread1_Sheet1.FilterBar.DefaultStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread1_Sheet1.FilterBarHeaderStyle.BackColor = System.Drawing.Color.Empty
        Me.FpSpread1_Sheet1.FilterBarHeaderStyle.ForeColor = System.Drawing.Color.Empty
        Me.FpSpread1_Sheet1.FilterBarHeaderStyle.Locked = false
        Me.FpSpread1_Sheet1.FilterBarHeaderStyle.Parent = "RowHeaderDefault"
        Me.FpSpread1_Sheet1.FilterBarHeaderStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread1_Sheet1.OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        Me.FpSpread1_Sheet1.Protect = true
        Me.FpSpread1_Sheet1.RowHeader.Columns.Default.Resizable = false
        Me.FpSpread1_Sheet1.RowHeader.Columns.Default.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread1_Sheet1.RowHeader.Columns.Get(0).Width = 44!
        Me.FpSpread1_Sheet1.RowHeader.DefaultStyle.BackColor = System.Drawing.Color.Empty
        Me.FpSpread1_Sheet1.RowHeader.DefaultStyle.Border = ComplexBorder1
        Me.FpSpread1_Sheet1.RowHeader.DefaultStyle.Font = New System.Drawing.Font("MS Mincho", 12!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128,Byte))
        Me.FpSpread1_Sheet1.RowHeader.DefaultStyle.ForeColor = System.Drawing.Color.Empty
        Me.FpSpread1_Sheet1.RowHeader.DefaultStyle.Locked = false
        Me.FpSpread1_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderDefault"
        Me.FpSpread1_Sheet1.RowHeader.DefaultStyle.Renderer = CustomSpdHeader8
        Me.FpSpread1_Sheet1.RowHeader.DefaultStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread1_Sheet1.RowHeader.Rows.Default.Resizable = false
        Me.FpSpread1_Sheet1.RowHeader.Rows.Default.Visible = true
        Me.FpSpread1_Sheet1.RowHeader.Rows.Default.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread1_Sheet1.Rows.Default.Height = 21!
        Me.FpSpread1_Sheet1.Rows.Default.Resizable = false
        Me.FpSpread1_Sheet1.Rows.Default.Visible = true
        Me.FpSpread1_Sheet1.SelectionUnit = FarPoint.Win.Spread.Model.SelectionUnit.Row
        Me.FpSpread1_Sheet1.SheetCornerStyle.BackColor = System.Drawing.Color.Empty
        Me.FpSpread1_Sheet1.SheetCornerStyle.ForeColor = System.Drawing.Color.Empty
        Me.FpSpread1_Sheet1.SheetCornerStyle.Locked = false
        Me.FpSpread1_Sheet1.SheetCornerStyle.Parent = "RowHeaderDefault"
        Me.FpSpread1_Sheet1.SheetCornerStyle.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread1_Sheet1.SheetCornerStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread1_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1
        '
        'FpSpread2
        '
        Me.FpSpread2.AccessibleDescription = "FpSpread2, Sheet1, Row 0, Column 0"
        Me.FpSpread2.AllowUserToTouchZoom = false
        Me.FpSpread2.AllowUserZoom = false
        Me.FpSpread2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.FpSpread2.FocusRenderer = DefaultFocusIndicatorRenderer1
        Me.FpSpread2.HorizontalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.FpSpread2.HorizontalScrollBar.Name = ""
        Me.FpSpread2.HorizontalScrollBar.Renderer = DefaultScrollBarRenderer3
        Me.FpSpread2.HorizontalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.Never
        Me.FpSpread2.Location = New System.Drawing.Point(18, 606)
        Me.FpSpread2.Name = "FpSpread2"
        NamedStyle3.BackColor = System.Drawing.Color.FromArgb(CType(CType(255,Byte),Integer), CType(CType(255,Byte),Integer), CType(CType(255,Byte),Integer))
        NamedStyle3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0,Byte),Integer), CType(CType(0,Byte),Integer), CType(CType(0,Byte),Integer))
        NamedStyle3.Locked = false
        NamedStyle4.BackColor = System.Drawing.Color.FromArgb(CType(CType(255,Byte),Integer), CType(CType(255,Byte),Integer), CType(CType(255,Byte),Integer))
        NamedStyle4.Font = New System.Drawing.Font("MS Mincho", 12!, System.Drawing.FontStyle.Bold)
        NamedStyle4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0,Byte),Integer), CType(CType(0,Byte),Integer), CType(CType(0,Byte),Integer))
        NamedStyle4.Locked = false
        Me.FpSpread2.ScrollBarTrackPolicy = FarPoint.Win.Spread.ScrollBarTrackPolicy.Vertical
        Me.FpSpread2.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.FpSpread2_Sheet1})
        Me.FpSpread2.Size = New System.Drawing.Size(956, 42)
        Me.FpSpread2.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Classic
        Me.FpSpread2.NamedStyles.AddRange(New FarPoint.Win.Spread.NamedStyle() {NamedStyle3, NamedStyle4})
        Me.FpSpread2.TabIndex = 22
        Me.FpSpread2.TabStop = false
        TipAppearance2.BackColor = System.Drawing.SystemColors.Info
        TipAppearance2.Font = New System.Drawing.Font("MS PGothic", 9!)
        TipAppearance2.ForeColor = System.Drawing.SystemColors.InfoText
        Me.FpSpread2.TextTipAppearance = TipAppearance2
        Me.FpSpread2.VerticalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.FpSpread2.VerticalScrollBar.Name = ""
        Me.FpSpread2.VerticalScrollBar.Renderer = DefaultScrollBarRenderer4
        Me.FpSpread2.VerticalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.Never
        Me.FpSpread2.VisualStyles = FarPoint.Win.VisualStyles.Off
        '
        'FpSpread2_Sheet1
        '
        Me.FpSpread2_Sheet1.Reset
        Me.FpSpread2_Sheet1.SheetName = "Sheet1"
        'Formulas and custom names must be loaded with R1C1 reference style
        Me.FpSpread2_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1
        Me.FpSpread2_Sheet1.ColumnCount = 7
        Me.FpSpread2_Sheet1.RowCount = 1
        Me.FpSpread2_Sheet1.ActiveSkin = FarPoint.Win.Spread.DefaultSkins.Default
        Me.FpSpread2_Sheet1.Cells.Get(0, 0).BackColor = System.Drawing.Color.FromArgb(CType(CType(255,Byte),Integer), CType(CType(255,Byte),Integer), CType(CType(255,Byte),Integer))
        Me.FpSpread2_Sheet1.Cells.Get(0, 0).Font = Nothing
        Me.FpSpread2_Sheet1.Cells.Get(0, 0).ForeColor = System.Drawing.Color.FromArgb(CType(CType(0,Byte),Integer), CType(CType(0,Byte),Integer), CType(CType(0,Byte),Integer))
        Me.FpSpread2_Sheet1.Cells.Get(0, 1).BackColor = System.Drawing.Color.FromArgb(CType(CType(255,Byte),Integer), CType(CType(255,Byte),Integer), CType(CType(255,Byte),Integer))
        Me.FpSpread2_Sheet1.Cells.Get(0, 1).Font = Nothing
        Me.FpSpread2_Sheet1.Cells.Get(0, 1).ForeColor = System.Drawing.Color.FromArgb(CType(CType(0,Byte),Integer), CType(CType(0,Byte),Integer), CType(CType(0,Byte),Integer))
        Me.FpSpread2_Sheet1.Cells.Get(0, 2).BackColor = System.Drawing.Color.FromArgb(CType(CType(255,Byte),Integer), CType(CType(255,Byte),Integer), CType(CType(255,Byte),Integer))
        Me.FpSpread2_Sheet1.Cells.Get(0, 2).Font = Nothing
        Me.FpSpread2_Sheet1.Cells.Get(0, 2).ForeColor = System.Drawing.Color.FromArgb(CType(CType(0,Byte),Integer), CType(CType(0,Byte),Integer), CType(CType(0,Byte),Integer))
        Me.FpSpread2_Sheet1.Cells.Get(0, 3).BackColor = System.Drawing.Color.FromArgb(CType(CType(223,Byte),Integer), CType(CType(255,Byte),Integer), CType(CType(255,Byte),Integer))
        Me.FpSpread2_Sheet1.Cells.Get(0, 3).Font = Nothing
        Me.FpSpread2_Sheet1.Cells.Get(0, 3).ForeColor = System.Drawing.Color.FromArgb(CType(CType(0,Byte),Integer), CType(CType(0,Byte),Integer), CType(CType(0,Byte),Integer))
        Me.FpSpread2_Sheet1.Cells.Get(0, 3).Value = "126,300,000"
        Me.FpSpread2_Sheet1.Cells.Get(0, 4).BackColor = System.Drawing.Color.FromArgb(CType(CType(223,Byte),Integer), CType(CType(255,Byte),Integer), CType(CType(255,Byte),Integer))
        Me.FpSpread2_Sheet1.Cells.Get(0, 4).Font = Nothing
        Me.FpSpread2_Sheet1.Cells.Get(0, 4).ForeColor = System.Drawing.Color.FromArgb(CType(CType(0,Byte),Integer), CType(CType(0,Byte),Integer), CType(CType(0,Byte),Integer))
        Me.FpSpread2_Sheet1.Cells.Get(0, 4).Value = "15,300,000"
        Me.FpSpread2_Sheet1.Cells.Get(0, 5).BackColor = System.Drawing.Color.FromArgb(CType(CType(223,Byte),Integer), CType(CType(255,Byte),Integer), CType(CType(255,Byte),Integer))
        Me.FpSpread2_Sheet1.Cells.Get(0, 5).Font = Nothing
        Me.FpSpread2_Sheet1.Cells.Get(0, 5).ForeColor = System.Drawing.Color.FromArgb(CType(CType(0,Byte),Integer), CType(CType(0,Byte),Integer), CType(CType(0,Byte),Integer))
        Me.FpSpread2_Sheet1.Cells.Get(0, 5).Value = "111,000,000"
        Me.FpSpread2_Sheet1.Cells.Get(0, 6).BackColor = System.Drawing.Color.FromArgb(CType(CType(223,Byte),Integer), CType(CType(255,Byte),Integer), CType(CType(255,Byte),Integer))
        Me.FpSpread2_Sheet1.Cells.Get(0, 6).Font = Nothing
        Me.FpSpread2_Sheet1.Cells.Get(0, 6).ForeColor = System.Drawing.Color.FromArgb(CType(CType(0,Byte),Integer), CType(CType(0,Byte),Integer), CType(CType(0,Byte),Integer))
        Me.FpSpread2_Sheet1.Cells.Get(0, 6).Value = "0"
        Me.FpSpread2_Sheet1.ColumnFooter.Columns.Default.Resizable = false
        Me.FpSpread2_Sheet1.ColumnFooter.Columns.Default.SortIndicator = FarPoint.Win.Spread.Model.SortIndicator.None
        Me.FpSpread2_Sheet1.ColumnFooter.Columns.Default.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread2_Sheet1.ColumnFooter.DefaultStyle.BackColor = System.Drawing.Color.Empty
        Me.FpSpread2_Sheet1.ColumnFooter.DefaultStyle.ForeColor = System.Drawing.Color.Empty
        Me.FpSpread2_Sheet1.ColumnFooter.DefaultStyle.Locked = false
        Me.FpSpread2_Sheet1.ColumnFooter.DefaultStyle.Parent = "HeaderDefault"
        Me.FpSpread2_Sheet1.ColumnFooter.DefaultStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread2_Sheet1.ColumnFooter.Rows.Default.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread2_Sheet1.ColumnFooterSheetCornerStyle.BackColor = System.Drawing.Color.Empty
        Me.FpSpread2_Sheet1.ColumnFooterSheetCornerStyle.ForeColor = System.Drawing.Color.Empty
        Me.FpSpread2_Sheet1.ColumnFooterSheetCornerStyle.Locked = false
        Me.FpSpread2_Sheet1.ColumnFooterSheetCornerStyle.Parent = "RowHeaderDefault"
        Me.FpSpread2_Sheet1.ColumnFooterSheetCornerStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread2_Sheet1.ColumnHeader.Cells.Get(0, 0).Value = "�H��"
        Me.FpSpread2_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = " "
        Me.FpSpread2_Sheet1.ColumnHeader.Cells.Get(0, 2).Value = " ��  ��                    "
        Me.FpSpread2_Sheet1.ColumnHeader.Cells.Get(0, 3).Value = "���s�\�Z"
        Me.FpSpread2_Sheet1.ColumnHeader.Cells.Get(0, 4).Value = "���@�c"
        Me.FpSpread2_Sheet1.ColumnHeader.Cells.Get(0, 5).Value = "�O�@��"
        Me.FpSpread2_Sheet1.ColumnHeader.Cells.Get(0, 6).Value = "���@�z"
        Me.FpSpread2_Sheet1.ColumnHeader.Columns.Default.Resizable = false
        Me.FpSpread2_Sheet1.ColumnHeader.Columns.Default.SortIndicator = FarPoint.Win.Spread.Model.SortIndicator.None
        Me.FpSpread2_Sheet1.ColumnHeader.Columns.Default.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread2_Sheet1.ColumnHeader.DefaultStyle.BackColor = System.Drawing.Color.Empty
        Me.FpSpread2_Sheet1.ColumnHeader.DefaultStyle.Font = New System.Drawing.Font("MS Mincho", 12!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128,Byte))
        Me.FpSpread2_Sheet1.ColumnHeader.DefaultStyle.ForeColor = System.Drawing.Color.Empty
        Me.FpSpread2_Sheet1.ColumnHeader.DefaultStyle.Locked = false
        Me.FpSpread2_Sheet1.ColumnHeader.DefaultStyle.Parent = "HeaderDefault"
        Me.FpSpread2_Sheet1.ColumnHeader.DefaultStyle.Renderer = CustomSpdHeader17
        Me.FpSpread2_Sheet1.ColumnHeader.DefaultStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread2_Sheet1.ColumnHeader.Rows.Default.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread2_Sheet1.Columns.Default.Resizable = false
        Me.FpSpread2_Sheet1.Columns.Default.SortIndicator = FarPoint.Win.Spread.Model.SortIndicator.None
        Me.FpSpread2_Sheet1.Columns.Get(0).Border = ComplexBorder2
        TextCellType5.CharacterSet = FarPoint.Win.Spread.CellType.CharacterSet.AlphaNumeric
        TextCellType5.MaxLength = 8
        Me.FpSpread2_Sheet1.Columns.Get(0).CellType = TextCellType5
        Me.FpSpread2_Sheet1.Columns.Get(0).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.FpSpread2_Sheet1.Columns.Get(0).Label = "�H��"
        Me.FpSpread2_Sheet1.Columns.Get(0).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread2_Sheet1.Columns.Get(0).Width = 53!
        Me.FpSpread2_Sheet1.Columns.Get(1).Border = ComplexBorder2
        TextCellType6.MaxLength = 60
        Me.FpSpread2_Sheet1.Columns.Get(1).CellType = TextCellType6
        Me.FpSpread2_Sheet1.Columns.Get(1).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.FpSpread2_Sheet1.Columns.Get(1).Label = " "
        Me.FpSpread2_Sheet1.Columns.Get(1).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Top
        Me.FpSpread2_Sheet1.Columns.Get(1).Width = 55!
        Me.FpSpread2_Sheet1.Columns.Get(2).Border = ComplexBorder2
        TextCellType7.MaxLength = 60
        Me.FpSpread2_Sheet1.Columns.Get(2).CellType = TextCellType7
        Me.FpSpread2_Sheet1.Columns.Get(2).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Left
        Me.FpSpread2_Sheet1.Columns.Get(2).Label = " ��  ��                    "
        Me.FpSpread2_Sheet1.Columns.Get(2).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread2_Sheet1.Columns.Get(2).Width = 260!
        Me.FpSpread2_Sheet1.Columns.Get(3).Border = ComplexBorder2
        TextCellType8.MaxLength = 60
        Me.FpSpread2_Sheet1.Columns.Get(3).CellType = TextCellType8
        Me.FpSpread2_Sheet1.Columns.Get(3).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Right
        Me.FpSpread2_Sheet1.Columns.Get(3).Label = "���s�\�Z"
        Me.FpSpread2_Sheet1.Columns.Get(3).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread2_Sheet1.Columns.Get(3).Width = 152!
        Me.FpSpread2_Sheet1.Columns.Get(4).Border = ComplexBorder2
        Me.FpSpread2_Sheet1.Columns.Get(4).CellType = TextCellType8
        Me.FpSpread2_Sheet1.Columns.Get(4).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Right
        Me.FpSpread2_Sheet1.Columns.Get(4).Label = "���@�c"
        Me.FpSpread2_Sheet1.Columns.Get(4).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread2_Sheet1.Columns.Get(4).Width = 124!
        Me.FpSpread2_Sheet1.Columns.Get(5).Border = ComplexBorder2
        Me.FpSpread2_Sheet1.Columns.Get(5).CellType = TextCellType8
        Me.FpSpread2_Sheet1.Columns.Get(5).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Right
        Me.FpSpread2_Sheet1.Columns.Get(5).Label = "�O�@��"
        Me.FpSpread2_Sheet1.Columns.Get(5).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread2_Sheet1.Columns.Get(5).Width = 124!
        Me.FpSpread2_Sheet1.Columns.Get(6).Border = ComplexBorder3
        TextCellType9.MaxLength = 60
        Me.FpSpread2_Sheet1.Columns.Get(6).CellType = TextCellType9
        Me.FpSpread2_Sheet1.Columns.Get(6).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Right
        Me.FpSpread2_Sheet1.Columns.Get(6).Label = "���@�z"
        Me.FpSpread2_Sheet1.Columns.Get(6).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread2_Sheet1.Columns.Get(6).Width = 124!
        Me.FpSpread2_Sheet1.DefaultStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(255,Byte),Integer), CType(CType(255,Byte),Integer), CType(CType(255,Byte),Integer))
        TextCellType10.MaxLength = 60
        Me.FpSpread2_Sheet1.DefaultStyle.CellType = TextCellType10
        Me.FpSpread2_Sheet1.DefaultStyle.Font = New System.Drawing.Font("MS Mincho", 12!, System.Drawing.FontStyle.Bold)
        Me.FpSpread2_Sheet1.DefaultStyle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0,Byte),Integer), CType(CType(0,Byte),Integer), CType(CType(0,Byte),Integer))
        Me.FpSpread2_Sheet1.DefaultStyle.Locked = true
        Me.FpSpread2_Sheet1.DefaultStyle.Parent = "DataAreaDefault"
        Me.FpSpread2_Sheet1.DefaultStyle.Renderer = TextCellType10
        Me.FpSpread2_Sheet1.FilterBar.DefaultStyle.BackColor = System.Drawing.Color.Empty
        Me.FpSpread2_Sheet1.FilterBar.DefaultStyle.ForeColor = System.Drawing.Color.Empty
        Me.FpSpread2_Sheet1.FilterBar.DefaultStyle.Locked = false
        Me.FpSpread2_Sheet1.FilterBar.DefaultStyle.Parent = "FilterBarDefault"
        Me.FpSpread2_Sheet1.FilterBar.DefaultStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread2_Sheet1.FilterBarHeaderStyle.BackColor = System.Drawing.Color.Empty
        Me.FpSpread2_Sheet1.FilterBarHeaderStyle.ForeColor = System.Drawing.Color.Empty
        Me.FpSpread2_Sheet1.FilterBarHeaderStyle.Locked = false
        Me.FpSpread2_Sheet1.FilterBarHeaderStyle.Parent = "RowHeaderDefault"
        Me.FpSpread2_Sheet1.FilterBarHeaderStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread2_Sheet1.OperationMode = FarPoint.Win.Spread.OperationMode.[ReadOnly]
        Me.FpSpread2_Sheet1.Protect = true
        Me.FpSpread2_Sheet1.RowHeader.Cells.Get(0, 0).Value = "���v"
        Me.FpSpread2_Sheet1.RowHeader.Columns.Default.Resizable = false
        Me.FpSpread2_Sheet1.RowHeader.Columns.Default.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread2_Sheet1.RowHeader.Columns.Get(0).Width = 44!
        Me.FpSpread2_Sheet1.RowHeader.DefaultStyle.BackColor = System.Drawing.Color.Empty
        Me.FpSpread2_Sheet1.RowHeader.DefaultStyle.Border = ComplexBorder4
        Me.FpSpread2_Sheet1.RowHeader.DefaultStyle.Font = New System.Drawing.Font("MS Mincho", 12!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128,Byte))
        Me.FpSpread2_Sheet1.RowHeader.DefaultStyle.ForeColor = System.Drawing.Color.Empty
        Me.FpSpread2_Sheet1.RowHeader.DefaultStyle.Locked = false
        Me.FpSpread2_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderDefault"
        Me.FpSpread2_Sheet1.RowHeader.DefaultStyle.Renderer = CustomSpdHeader18
        Me.FpSpread2_Sheet1.RowHeader.DefaultStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread2_Sheet1.RowHeader.Rows.Default.Resizable = false
        Me.FpSpread2_Sheet1.RowHeader.Rows.Default.Visible = true
        Me.FpSpread2_Sheet1.RowHeader.Rows.Default.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread2_Sheet1.RowHeader.Rows.Get(0).Label = "���v"
        Me.FpSpread2_Sheet1.Rows.Default.Height = 21!
        Me.FpSpread2_Sheet1.Rows.Default.Resizable = false
        Me.FpSpread2_Sheet1.Rows.Default.Visible = true
        Me.FpSpread2_Sheet1.SheetCornerStyle.BackColor = System.Drawing.Color.Empty
        Me.FpSpread2_Sheet1.SheetCornerStyle.ForeColor = System.Drawing.Color.Empty
        Me.FpSpread2_Sheet1.SheetCornerStyle.Locked = false
        Me.FpSpread2_Sheet1.SheetCornerStyle.Parent = "RowHeaderDefault"
        Me.FpSpread2_Sheet1.SheetCornerStyle.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread2_Sheet1.SheetCornerStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread2_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1
        '
        'frmSYKD020
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(1016, 742)
        Me.Controls.Add(Me.Picture2)
        Me.Controls.Add(Me.Picture1)
        Me.Controls.Add(Me.StatusBar1)
        Me.Controls.Add(Me._imText2_2)
        Me.Controls.Add(Me._imText2_0)
        Me.Controls.Add(Me._imText2_1)
        Me.Controls.Add(Me.lblTitle)
        Me.Controls.Add(Me.FpSpread1)
        Me.Controls.Add(Me.FpSpread2)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"),System.Drawing.Icon)
        Me.KeyPreview = true
        Me.Location = New System.Drawing.Point(4, 23)
        Me.MaximizeBox = false
        Me.MinimizeBox = false
        Me.Name = "frmSYKD020"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "�H���Ǘ��V�X�e��"
        Me.Picture2.ResumeLayout(false)
        Me.Picture1.ResumeLayout(false)
        Me.StatusBar1.ResumeLayout(false)
        Me.StatusBar1.PerformLayout
        CType(Me._imText2_2,System.ComponentModel.ISupportInitialize).EndInit
        CType(Me._imText2_0,System.ComponentModel.ISupportInitialize).EndInit
        CType(Me._imText2_1,System.ComponentModel.ISupportInitialize).EndInit
        CType(Me.FpSpread1,System.ComponentModel.ISupportInitialize).EndInit
        CType(Me.FpSpread1_Sheet1,System.ComponentModel.ISupportInitialize).EndInit
        CType(Me.FpSpread2,System.ComponentModel.ISupportInitialize).EndInit
        CType(Me.FpSpread2_Sheet1,System.ComponentModel.ISupportInitialize).EndInit
        Me.ResumeLayout(false)
        Me.PerformLayout

End Sub

    Friend WithEvents FpSpread1 As FarPoint.Win.Spread.FpSpread
    Friend WithEvents FpSpread1_Sheet1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents FpSpread2 As FarPoint.Win.Spread.FpSpread
    Friend WithEvents FpSpread2_Sheet1 As FarPoint.Win.Spread.SheetView
#End Region
End Class