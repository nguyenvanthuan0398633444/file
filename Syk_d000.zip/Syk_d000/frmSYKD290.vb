Option Strict Off
Option Explicit On
Friend Class frmSYKD290
    Inherits System.Windows.Forms.Form
    '=============================================================
    ' ���[�U�[���@  �F  �R�z�H�Ɗ������
    ' �V�X�e�����@  �F  �H���Ǘ��V�X�e��
    ' ���W���[����  �F  ���M�f�[�^�ꗗ
    ' ���W���[��ID�@�F  frmSYKD290.frm
    ' �쐬���@ �@�@ �F  ���� 13 �N 07 �� 05 ��
    ' �X�V���@�@  �@�F  ����    �N    ��    ��
    '=============================================================
    '
    '2021.08.10 UPGRADE S  AIT)vyhnt
    'Private Const RowHeight As Short = 15
    Private Const RowHeight As Short = 21
    '2021.08.10 UPGRADE E   
    Private himc As Integer
    '

    '-------------------------------------------------------------------------------
    '   ����    :   �f�[�^�̃N���A
    '   �֐�    :   Sub DispClear()
    '   ����    :   �Ȃ�
    '   �@�\    :   �f�[�^���N���A���܂��B
    '-------------------------------------------------------------------------------
    Private Sub DispClear()
        '2021.08.02 UPGRADE S  AIT)vyhnt
        'vaSpread1.MaxRows = 0
        vaSpread1.ActiveSheet.RowCount = 0
        '2021.08.02 UPGRADE E

        '----- �Q�ƃ��[�h
        If INPMODE <> "2" Then
            cmdKey(8).Enabled = False
            '2021.08.10 UPGRADE S  AIT)vyhnt
            'cmdKey(8).Text = "  F8  �@"
            cmdKey(8).Text = "F8"
            '2021.08.10 UPGRADE E   
        End If

    End Sub

    '-------------------------------------------------------------------------------
    '   ����    :   �e�L�X�g���̎擾
    '   �֐�    :   Function GetTextFile()
    '   ����    :   �Ȃ�
    '   �ߒl    :   True    ����I��
    '   �@�@    :   False   �ُ�I��
    '   �@�\    :   �e�L�X�g�t�@�C���̏����擾���܂��B
    '-------------------------------------------------------------------------------
    Private Function GetTextFile() As Boolean

        Dim wkPath As String
        Dim wkFile As String
        '2020.11.06 UPGRADE DEL  AIT)vyhnt
        'Dim lp As Integer
        Dim Cnt As Integer
        Dim DT() As KOUJI_NO_MAST_DBT

        '2021.07.26 UPGRADE S  AIT)Tool Convert
        'On Error GoTo FileErrD290
        Try
            '2021.07.26 UPGRADE E

            ' �߂�l�̏�����
            GetTextFile = False

            ' �����e�L�X�g�t�@�C�����̎擾
            wkPath = SENDPATH & "SYK_G*.LZH"

            ' �t�@�C�������擾
            Cnt = 0
            wkFile = Dir(wkPath, FileAttribute.Normal)
            '2021.08.03 UPGRADE S  AIT)vyhnt
            Do While Len(wkFile)
                '2021.08.03 UPGRADE E  
                ReDim Preserve DT(Cnt)
                Call CLEAR_KOUJI_NO_MAST(DT(Cnt))
                With DT(Cnt)
                    .KOUJI_NO = Mid(wkFile, 6, 8) '�H���ԍ�
                    .EDA_NO = Mid(wkFile, 14, 4) '�H���}��
                    .MEISYOU = GetNameKouji(.KOUJI_NO, .EDA_NO) '�H������
                    .GYOUSYU_KB = UCase(Mid(wkFile, 5, 1)) '���
                End With
                Cnt = Cnt + 1
                wkFile = Dir()
            Loop

            ' �f�[�^�\��
            If Cnt <> 0 Then
                Call SprdDataSet(Cnt, DT)
            End If

            ' ����I��
            GetTextFile = True
            Exit Function

            '2021.07.26 UPGRADE S  AIT)Tool Convert
            'FileErrD290:
        Catch ex As Exception
            '2021.07.26 UPGRADE E

            '----- �G���[����
            Call FileErrors(ex)

        End Try     '2021.07.26 UPGRADE ADD AIT)Tool Convert
    End Function

    '-------------------------------------------------------------------------------
    '   ����    :   �X�v���b�h�\��
    '   �֐�    :   Sub SprdDataSet(DT())
    '   ����    :   Cnt     �f�[�^����
    '   �@�@    :   DT()    KOUJI_NO_MAST_DBT
    '   �@�\    :   �f�[�^���X�v���b�h�ɕ\�����܂��B
    '-------------------------------------------------------------------------------
    Private Sub SprdDataSet(ByRef Cnt As Integer, ByRef DT() As KOUJI_NO_MAST_DBT)

        Dim lp As Integer
        Dim Row As Integer
        Dim ssText As Object
        '2021.08.02 UPGRADE S  AIT)vyhnt
        With vaSpread1
            If Me.Visible = True Then
                '.ReDraw = False
                .ResumeLayout(False)
            End If
            '.MaxRows = Cnt
            .ActiveSheet.RowCount = Cnt
            '.Row = 1
            '.Col = 1
            '.Col2 = .MaxCols
            '.Row2 = .MaxRows
            '.BlockMode = True
            '.Action = FPSpread.ActionConstants.ActionClearText
            .ActiveSheet.ClearRange(0, 0, .ActiveSheet.RowCount, .ActiveSheet.ColumnCount, True)
            '.BlockMode = False
            For lp = 0 To Cnt - 1
                '.set_RowHeight(lp + 1, RowHeight)
                .ActiveSheet.SetRowHeight(lp, RowHeight)
                'Row = lp + 1
                Row = lp
                '----- CheckBox
                '.SetText(1, Row, "0")
                .ActiveSheet.SetText(Row, 0, "0")
                '----- �H���ԍ�
                ssText = Trim(DT(lp).KOUJI_NO)
                '.SetText(2, Row, ssText)
                .ActiveSheet.SetText(Row, 1, ssText)
                '----- �}��
                ssText = Trim(DT(lp).EDA_NO)
                If ssText <> "0000" Then
                    '.SetText(3, Row, ssText)
                    .ActiveSheet.SetText(Row, 2, ssText)
                End If
                '----- ����
                ssText = Trim(DT(lp).MEISYOU)
                '.SetText(4, Row, ssText)
                .ActiveSheet.SetText(Row, 3, ssText)
                '----- �H���敪
                ssText = GetNameGyosyu(DT(lp).KOUJI_NO, DT(lp).EDA_NO)
                '.SetText(5, Row, ssText)
                .ActiveSheet.SetText(Row, 4, ssText)
                '----- �m��
                Select Case Trim(DT(lp).GYOUSYU_KB)
                    Case "K"
                        ssText = "�m��"
                    Case Else
                        ssText = ""
                End Select
                '.SetText(6, Row, ssText)
                .ActiveSheet.SetText(Row, 5, ssText)
            Next lp
            '.Row = 1 : .Row2 = .MaxRows
            '.Col = 1 : .Col2 = .MaxCols
            '.BlockMode = True
            Dim sort(1) As FarPoint.Win.Spread.SortInfo
            '.SortBy = FPSpread.SortByConstants.SortByRow
            '.set_SortKey(1, 2)
            '.set_SortKeyOrder(1, FPSpread.SortKeyOrderConstants.SortKeyOrderAscending)            
            '.set_SortKey(2, 3)
            '.set_SortKeyOrder(2, FPSpread.SortKeyOrderConstants.SortKeyOrderAscending)
            sort(0) = New FarPoint.Win.Spread.SortInfo(1, True, System.Collections.Comparer.Default)
            '.Action = FPSpread.ActionConstants.ActionSort
            '.BlockMode = False
            .ActiveSheet.SortRange(0, 0, .ActiveSheet.RowCount, .ActiveSheet.ColumnCount, True, sort)
            If Me.Visible = True Then
                '.CtlRefresh()
                .Refresh()
                '.ReDraw = True
                .ResumeLayout(True)
            End If
        End With
        '2021.08.02 UPGRADE E
        '2021.08.11 UPGRADE ADD  AIT)vyhnt
        vaSpread1.ActiveSheet.AddSelection(0, 0, vaSpread1.ActiveSheet.RowCount, vaSpread1.ActiveSheet.ColumnCount)
        '2021.08.11 UPGRADE S  AIT)*** 

    End Sub

    '-------------------------------------------------------------------------------
    '   ����    :   �I���f�[�^�i�j�d�x�j�̎擾
    '   �֐�    :   Sub SprdDataGet(DT)
    '   ����    :   DT  KOUJI_NO_MAST_DBT
    '   �@�\    :   �I���f�[�^���X�v���b�h����擾���܂��B
    '-------------------------------------------------------------------------------
    Private Sub SprdDataGet(ByRef DT As KOUJI_NO_MAST_DBT)

        Dim ssText As Object
        With vaSpread1
            '2021.08.02 UPGRADE S  AIT)vyhnt
            '.GetText(2, .ActiveRow, ssText) '�H���ԍ�
            ssText = .ActiveSheet.GetText(.ActiveSheet.ActiveColumnIndex, 1) '�H���ԍ�
            DT.KOUJI_NO = Trim(ssText)
            '.GetText(3, .ActiveRow, ssText) '�}��
            ssText = .ActiveSheet.GetText(.ActiveSheet.ActiveColumnIndex, 2) '�}��
            If Trim(ssText) = "" Then ssText = "0000"
            DT.EDA_NO = Trim(ssText)
            '.GetText(6, .ActiveRow, ssText) '�m��敪
            ssText = .ActiveSheet.GetText(.ActiveSheet.ActiveColumnIndex, 5)
            DT.MEISYOU = Trim(ssText)
            '2021.08.02 UPGRADE E
        End With

    End Sub

    '2021.08.02 UPGRADE S  AIT)vyhnt
    'Private Sub cmdKey_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Click
    '	Dim Index As Short = cmdKey.GetIndex(eventSender)
    Private Sub cmdKey_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _cmdKey_1.Click, _cmdKey_2.Click, _cmdKey_3.Click, _cmdKey_4.Click, _cmdKey_5.Click, _cmdKey_6.Click,
                                                                                                                    _cmdKey_7.Click, _cmdKey_8.Click, _cmdKey_9.Click, _cmdKey_10.Click, _cmdKey_11.Click, _cmdKey_12.Click
        Dim Index As Short = cmdKey.IndexOf(eventSender)

        '2021.08.02 UPGRADE E

        Dim ChkFlg As Short
        Dim lp As Integer
        Dim ssText As Object
        Dim fName As String

        Select Case Index
            Case 8 '----- �e�c�o��
                ' �o�͐��I������
                With vaSpread1
                    ChkFlg = 0
                    '2021.08.02 UPGRADE S  AIT)vyhnt
                    'For lp = 1 To .MaxRows
                    For lp = 1 To .ActiveSheet.RowCount
                        '.GetText(1, lp, ssText) ' CheckBox
                        ssText = .ActiveSheet.GetText(lp - 1, 0) ' CheckBox
                        '2021.08.02 UPGRADE E

                        If ssText = "1" Then
                            '.GetText(4, lp, ssText) ' �H������
                            ssText = .ActiveSheet.GetText(lp - 1, 3) ' �H������
                            fName = ssText
                            ChkFlg = 1
                            Exit For
                        End If
                    Next lp
                End With
                If ChkFlg = 0 Then
                    '2021.09.14 UPGRADE S  AIT)dannnl
                    'MsgBox("�o�͂���H������I�����ĉ������B")
                    MsgBox("�o�͂���H������I�����ĉ������B", MsgBoxStyle.ApplicationModal, SYSTEMNM)
                    '2021.09.14 UPGRADE E
                Else
                    '2021.08.19 UPGRADE ADD  AIT)vyhnt
                    Call MtyTool.LostFocus(cmdKey(Index), StatusBar1)
                    '2021.08.19 UPGRADE S  AIT)
                    frmSYKD291.imText1(0).Text = fName
                    frmSYKD291.ShowDialog()
                    ' �����\��
                    '2021.08.19 UPGRADE ADD  AIT)vyhnt
                    Call MtyTool.GotFocus(cmdKey(Index), StatusBar1)
                    '2021.08.19 UPGRADE S  AIT)
                    Call DispClear()
                    Call GetTextFile()
                End If

            Case 12 '----- �I��
                frmSYKD010.Show()
                '2021.09.14 UPGRADE S  AIT)dannnl
                'Me.Close()
                Me.Dispose()
                '2021.09.14 UPGRADE E
        End Select

    End Sub

    '2021.08.02 UPGRADE S  AIT)vyhnt
    'Private Sub cmdKey_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Enter
    '	Dim Index As Short = cmdKey.GetIndex(eventSender)
    '	Call GotFocus(cmdKey(Index), StatusBar1)
    Private Sub cmdKey_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _cmdKey_1.Enter, _cmdKey_2.Enter, _cmdKey_3.Enter, _cmdKey_4.Enter, _cmdKey_5.Enter, _cmdKey_6.Enter,
                                                                                                                _cmdKey_7.Enter, _cmdKey_8.Enter, _cmdKey_9.Enter, _cmdKey_10.Enter, _cmdKey_11.Enter, _cmdKey_12.Enter
        Dim Index As Short = cmdKey.IndexOf(eventSender)
        Call MtyTool.GotFocus(cmdKey(Index), StatusBar1)
        '2021.08.02 UPGRADE E

    End Sub

    '2021.08.02 UPGRADE S  AIT)vyhnt
    'Private Sub cmdKey_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Leave
    '	Dim Index As Short = cmdKey.GetIndex(eventSender)
    '	Call LostFocus(cmdKey(Index), StatusBar1)
    Private Sub cmdKey_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _cmdKey_1.Leave, _cmdKey_2.Leave, _cmdKey_3.Leave, _cmdKey_4.Leave, _cmdKey_5.Leave, _cmdKey_6.Leave,
                                                                                                                _cmdKey_7.Leave, _cmdKey_8.Leave, _cmdKey_9.Leave, _cmdKey_10.Leave, _cmdKey_11.Leave, _cmdKey_12.Leave
        Dim Index As Short = cmdKey.IndexOf(eventSender)
        Call MtyTool.LostFocus(cmdKey(Index), StatusBar1)
        '2021.08.02 UPGRADE E

    End Sub

    Private Sub frmSYKD290_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown
        Dim KeyCode As Short = eventArgs.KeyCode
        Dim Shift As Short = eventArgs.KeyData \ &H10000
        Select Case KeyCode
            Case System.Windows.Forms.Keys.F1
                If cmdKey(1).Enabled = True Then cmdKey(1).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(1), New System.EventArgs())
            Case System.Windows.Forms.Keys.F2
                If cmdKey(2).Enabled = True Then cmdKey(2).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(2), New System.EventArgs())
            Case System.Windows.Forms.Keys.F3
                If cmdKey(3).Enabled = True Then cmdKey(3).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(3), New System.EventArgs())
            Case System.Windows.Forms.Keys.F4
                If cmdKey(4).Enabled = True Then cmdKey(4).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(4), New System.EventArgs())
            Case System.Windows.Forms.Keys.F5
                If cmdKey(5).Enabled = True Then cmdKey(5).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(5), New System.EventArgs())
            Case System.Windows.Forms.Keys.F6
                If cmdKey(6).Enabled = True Then cmdKey(6).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(6), New System.EventArgs())
            Case System.Windows.Forms.Keys.F7
                If cmdKey(7).Enabled = True Then cmdKey(7).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(7), New System.EventArgs())
            Case System.Windows.Forms.Keys.F8
                If cmdKey(8).Enabled = True Then cmdKey(8).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(8), New System.EventArgs())
            Case System.Windows.Forms.Keys.F9
                If cmdKey(9).Enabled = True Then cmdKey(9).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(9), New System.EventArgs())
            Case System.Windows.Forms.Keys.F10
                If cmdKey(10).Enabled = True Then cmdKey(10).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(10), New System.EventArgs())
            Case System.Windows.Forms.Keys.F11
                If cmdKey(11).Enabled = True Then cmdKey(11).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(11), New System.EventArgs())
            Case System.Windows.Forms.Keys.F12
                If cmdKey(12).Enabled = True Then cmdKey(12).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(12), New System.EventArgs())
        End Select
    End Sub

    Private Sub frmSYKD290_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load

        Call FormDisp(Me)

        '�X�v���b�h��IME�N���n�e�e
        '2021.08.02 UPGRADE S  AIT)vyhnt
        'himc = ImmGetContext(vaSpread1.hWnd)
        himc = ImmGetContext(vaSpread1.Handle)
        '2021.08.02 UPGRADE E


        ' �����\��
        Call DispClear()
        Call GetTextFile()

    End Sub

    Private Sub frmSYKD290_FormClosing(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Dim Cancel As Boolean = eventArgs.Cancel
        Dim UnloadMode As System.Windows.Forms.CloseReason = eventArgs.CloseReason
        If UnloadMode = System.Windows.Forms.CloseReason.UserClosing Then
            frmSYKD010.Show()
        End If
        eventArgs.Cancel = Cancel
    End Sub


    '2021.08.02 UPGRADE S  AIT)vyhnt
    'Private Sub vaSpread1_ClickEvent(ByVal Col As System.Object, ByVal eventArgs As AxFPSpread._DSpreadEvents_ClickEvent) Handles vaSpread1.ClickEvent
    Private Sub vaSpread1_ClickEvent(ByVal eventSender As System.Object, ByVal eventArgs As FarPoint.Win.Spread.CellClickEventArgs) Handles vaSpread1.CellClick
        '2021.08.02 UPGRADE E

        Dim lp As Integer
        Dim ssText As Object

        'If eventArgs.Col = 1 Then
        If eventArgs.Column = 0 Then
            '2021.08.02 UPGRADE E

            With vaSpread1
                'If eventArgs.Row = 0 Then
                If eventArgs.ColumnHeader = True AndAlso eventArgs.RowHeader = False Then
                    ' �S�I��
                    '2021.08.02 UPGRADE S  AIT)vyhnt
                    'For lp = 1 To .MaxRows
                    '	.GetText(1, lp, ssText)
                    For lp = 1 To .ActiveSheet.RowCount
                        ssText = .ActiveSheet.GetText(lp - 1, 0)
                        If ssText = "1" Then Exit For
                        '2021.08.02 UPGRADE E
                    Next lp
                    If ssText = "1" Then
                        ssText = "0"
                    Else
                        ssText = "1"
                    End If
                    '2021.08.02 UPGRADE S  AIT)vyhnt
                    'For lp = 1 To .MaxRows
                    '.Col = Col : .Row = lp
                    '.Text = ssText
                    For lp = 1 To .ActiveSheet.RowCount
                        '2021.08.10 UPGRADE S  AIT)vyhnt
                        '.Text = ssText
                        .ActiveSheet.Cells(lp - 1, 0).Text = ssText
                        '2021.08.10 UPGRADE E  
                    Next lp
                ElseIf eventArgs.ColumnHeader = False AndAlso eventArgs.RowHeader = False Then
                    '2021.08.10 UPGRADE DEL  AIT)vyhnt
                    '.Col = Col : .Row = Row
                    '2021.08.10 DEL  E 
                    '2021.08.10 UPGRADE S  AIT)vyhnt
                    If .ActiveSheet.Cells(eventArgs.Row, 0).Text = "0" Then
                        .ActiveSheet.Cells(eventArgs.Row, 0).Text = "1"
                    Else
                        .ActiveSheet.Cells(eventArgs.Row, 0).Text = "0"
                    End If
                    '2021.08.10 UPGRADE E  
                End If
            End With
        End If
    End Sub


    Private Sub vaSpread1_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles vaSpread1.Enter
        '2021.08.02 UPGRADE S  AIT)vyhnt
        'Call GotFocus(vaSpread1, StatusBar1)
        Call MtyTool.GotFocus(vaSpread1, StatusBar1)
        '2021.08.02 UPGRADE E
        ImmSetOpenStatus(himc, False)
    End Sub

    '2021.08.02 UPGRADE S  AIT)vyhnt
    'Private Sub vaSpread1_KeyDownEvent(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles vaSpread1.KeyDownEvent
    '	If eventArgs.KeyCode = System.Windows.Forms.Keys.Space Then
    '		Call vaSpread1_ClickEvent(vaSpread1, New AxFPSpread._DSpreadEvents_ClickEvent(1, vaSpread1.ActiveRow))
    Private Sub vaSpread1_KeyDownEvent(ByVal eventSender As System.Object, ByVal eventArgs As KeyEventArgs) Handles vaSpread1.KeyDown
        If eventArgs.KeyCode = System.Windows.Forms.Keys.Space Then
            Call vaSpread1_ClickEvent(vaSpread1.ActiveSheet.ActiveCell, New FarPoint.Win.Spread.CellClickEventArgs(
                                        vaSpread1.GetRootWorkbook, vaSpread1.ActiveSheet.ActiveRow.Index, 0, 1, 1, New MouseButtons, False, False))
            '2021.08.02 UPGRADE E
        End If
    End Sub

    Private Sub vaSpread1_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles vaSpread1.Leave
        'Call LostFocus(vaSpread1, StatusBar1)
        Call MtyTool.LostFocus(vaSpread1, StatusBar1)
    End Sub
End Class
