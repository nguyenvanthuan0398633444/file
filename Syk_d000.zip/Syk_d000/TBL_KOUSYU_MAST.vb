Option Strict Off
Option Explicit On

Module DB_KOUSYU_MAST

    Public Const KOUSYU_MAST_TBLNAME As String = "KOUSYU_MAST"

    '�H��}�X�^
    Structure KOUSYU_MAST_DBT
        '2021.07.26 UPGRADE S  AIT)Tool Convert
        '<VBFixedString(2),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=2)> Public GYOUSYU_KB() As Char '�Ǝ�敪
        '<VBFixedString(1),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=1)> Public KOUSYU_CD() As Char '�H������
        '<VBFixedString(2),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=2)> Public KOUSYU_NO() As Char '�H��ԍ�
        '<VBFixedString(40),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=40)> Public MEISYOU() As Char '�H�햼��
        '<VBFixedString(6),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=6)> Public KAMOKU_CD() As Char '�Ȗں���
        '<VBFixedString(8),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=8)> Public LAST_YMD() As Char '�ŏI�X�V���t
        <VBFixedStringAttribute(2)> Public GYOUSYU_KB As String  '�Ǝ�敪
        <VBFixedStringAttribute(1)> Public KOUSYU_CD As String   '�H������
        <VBFixedStringAttribute(2)> Public KOUSYU_NO As String   '�H��ԍ�
        <VBFixedStringAttribute(40)> Public MEISYOU As String    '�H�햼��
        <VBFixedStringAttribute(6)> Public KAMOKU_CD As String   '�Ȗں���
        <VBFixedStringAttribute(8)> Public LAST_YMD As String    '�ŏI�X�V���t
        '2021.07.26 UPGRADE E
    End Structure

    '-------------------------------------------------------------------------------
    '   ����   :   KOUSYU_MAST_DBT �\���̃N���A����
    '   �֐�   :   Sub CLEAR_KOUSYU_MAST()
    '   ����   :   DT  KOUSYU_MAST_DBT
    '   �@�\   :   �\���̂�����������
    '-------------------------------------------------------------------------------
    Public Sub CLEAR_KOUSYU_MAST(ByRef DT As KOUSYU_MAST_DBT)

        With DT
            .GYOUSYU_KB = "" '�Ǝ�敪
            .KOUSYU_CD = "" '�H������
            .KOUSYU_NO = "" '�H��ԍ�
            .MEISYOU = "" '�H�햼��
            .KAMOKU_CD = "" '�Ȗں���
            .LAST_YMD = "" '�ŏI�X�V���t
        End With

    End Sub

    '-------------------------------------------------------------------------------
    '   ����   :   KOUSYU_MAST Delete
    '   �֐�   :   Function DELETE_KOUSYU_MAST()
    '   ����   :   Jouken   ������
    '   �ߒl   :   True     ����I��
    '   �@�@       False    �ُ�I��
    '   �@�\   :   KOUSYU_MAST DELETE����
    '-------------------------------------------------------------------------------
    Public Function DELETE_KOUSYU_MAST(ByRef Jouken As String) As Boolean

        Dim SQL As String

        '2021.07.26 UPGRADE S  AIT)Tool Convert
        'On Error GoTo DELETE_KOUSYU_MAST_Err
        Try
            '2021.07.26 UPGRADE E

            '�߂�l�̏�����
            DELETE_KOUSYU_MAST = False

            'SQL/DELETE���g��
            SQL = "DELETE FROM " & KOUSYU_MAST_TBLNAME
            If Trim(Jouken) <> "" Then
                SQL = SQL & " WHERE " & Jouken
            End If

            'SQL�����s
            '2021.08.04 UPGRADE S  AIT)hieutv
            'SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText + ADODB.ExecuteOptionEnum.adExecuteNoRecords)
            ExecSQL(SQL)
            '2021.08.04 UPGRADE E

            '�߂�l�̃Z�b�g
            DELETE_KOUSYU_MAST = True
            Exit Function

            '2021.07.26 UPGRADE S  AIT)Tool Convert
            'DELETE_KOUSYU_MAST_Err:
        Catch ex As Exception
            '2021.07.26 UPGRADE E

            '2021.08.04 UPGRADE S  AIT)hieutv
            'Call Sql_Error_Msg("KOUSYU_MAST DELETE")
            Call Sql_Error_Msg(ex, "KOUSYU_MAST DELETE")
            '2021.08.04 UPGRADE E

        End Try     '2021.07.26 UPGRADE ADD AIT)Tool Convert
    End Function

    '-------------------------------------------------------------------------------
    '   ����   :   KOUSYU_MAST INSERT����
    '   �֐�   :   Function INSERT_KOUSYU_MAST()
    '   ����   :   DT       KOUSYU_MAST_DBT
    '   �ߒl   :   True     ����I��
    '   �@�@       False    �ُ�I��
    '   �@�\   :   KOUSYU_MAST INSERT����
    '-------------------------------------------------------------------------------
    Public Function INSERT_KOUSYU_MAST(ByRef DT As KOUSYU_MAST_DBT) As Boolean

        Dim SQL As String

        '2021.07.26 UPGRADE S  AIT)Tool Convert
        'On Error GoTo INSERT_KOUSYU_MAST_Err
        Try
            '2021.07.26 UPGRADE E

            '�߂�l�̏�����
            INSERT_KOUSYU_MAST = False

            'SQL/INSERT���g��
            SQL = "INSERT INTO " & KOUSYU_MAST_TBLNAME
            SQL = SQL & " ("
            SQL = SQL & " GYOUSYU_KB,"
            SQL = SQL & " KOUSYU_CD,"
            SQL = SQL & " KOUSYU_NO,"
            SQL = SQL & " MEISYOU,"
            SQL = SQL & " KAMOKU_CD,"
            SQL = SQL & " LAST_YMD"
            SQL = SQL & " ) VALUES("
            SQL = SQL & " '" & Trim(DT.GYOUSYU_KB) & "'," '�Ǝ�敪
            SQL = SQL & " '" & Trim(DT.KOUSYU_CD) & "'," '�H������
            SQL = SQL & " '" & Trim(DT.KOUSYU_NO) & "'," '�H��ԍ�
            SQL = SQL & " '" & Trim(DT.MEISYOU) & "'," '�H�햼��
            SQL = SQL & " '" & Trim(DT.KAMOKU_CD) & "'," '�Ȗں���
            SQL = SQL & " '" & Trim(DT.LAST_YMD) & "'" '�ŏI�X�V���t
            SQL = SQL & " )"

            'SQL�����s
            '2021.08.04 UPGRADE S  AIT)hieutv
            'SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText + ADODB.ExecuteOptionEnum.adExecuteNoRecords)
            ExecSQL(SQL)
            '2021.08.04 UPGRADE E

            '�߂�l�̃Z�b�g
            INSERT_KOUSYU_MAST = True
            Exit Function

            '2021.07.26 UPGRADE S  AIT)Tool Convert
            'INSERT_KOUSYU_MAST_Err:
        Catch ex As Exception
            '2021.07.26 UPGRADE E

            '2021.08.04 UPGRADE S  AIT)hieutv
            'Call Sql_Error_Msg("KOUSYU_MAST INSERT")
            Call Sql_Error_Msg(ex, "KOUSYU_MAST INSERT")
            '2021.08.04 UPGRADE E

        End Try     '2021.07.26 UPGRADE ADD AIT)Tool Convert
    End Function

    '-------------------------------------------------------------------------------
    '   ����   :   KOUSYU_MAST UPDATE
    '   �֐�   :   Function UPDATE_KOUSYU_MAST()
    '   ����   :   Jouken   ������
    '   �@�@       DT       KOUSYU_MAST_DBT
    '   �ߒl   :   True     ����I��
    '   �@�@       False    �ُ�I��
    '   �@�\   :   KOUSYU_MAST UPDATE����
    '-------------------------------------------------------------------------------
    Public Function UPDATE_KOUSYU_MAST(ByRef Jouken As String, ByRef DT As KOUSYU_MAST_DBT) As Boolean

        Dim SQL As String

        '2021.07.26 UPGRADE S  AIT)Tool Convert
        'On Error GoTo UPDATE_KOUSYU_MAST_Err
        Try
            '2021.07.26 UPGRADE E

            '�߂�l�̏�����
            UPDATE_KOUSYU_MAST = False

            'SQL/UPDATE���g��
            SQL = "UPDATE " & KOUSYU_MAST_TBLNAME
            SQL = SQL & " SET"
            SQL = SQL & " GYOUSYU_KB = '" & Trim(DT.GYOUSYU_KB) & "'," '�Ǝ�敪
            SQL = SQL & " KOUSYU_CD = '" & Trim(DT.KOUSYU_CD) & "'," '�H������
            SQL = SQL & " KOUSYU_NO = '" & Trim(DT.KOUSYU_NO) & "'," '�H��ԍ�
            SQL = SQL & " MEISYOU = '" & Trim(DT.MEISYOU) & "'," '�H�햼��
            SQL = SQL & " KAMOKU_CD = '" & Trim(DT.KAMOKU_CD) & "'," '�Ȗں���
            SQL = SQL & " LAST_YMD = '" & Trim(DT.LAST_YMD) & "'" '�ŏI�X�V���t
            If Trim(Jouken) <> "" Then
                SQL = SQL & " WHERE " & Jouken
            End If

            'SQL�����s
            '2021.08.04 UPGRADE S  AIT)hieutv
            'SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText + ADODB.ExecuteOptionEnum.adExecuteNoRecords)
            ExecSQL(SQL)
            '2021.08.04 UPGRADE E

            '�߂�l�̃Z�b�g
            UPDATE_KOUSYU_MAST = True
            Exit Function

            '2021.07.26 UPGRADE S  AIT)Tool Convert
            'UPDATE_KOUSYU_MAST_Err:
        Catch ex As Exception
            '2021.07.26 UPGRADE E

            '2021.08.04 UPGRADE S  AIT)hieutv
            'Call Sql_Error_Msg("KOUSYU_MAST UPDATE")
            Call Sql_Error_Msg(ex, "KOUSYU_MAST UPDATE")
            '2021.08.04 UPGRADE E

        End Try     '2021.07.26 UPGRADE ADD AIT)Tool Convert
    End Function

    '-------------------------------------------------------------------------------
    '   ����   :   KOUSYU_MAST �f�[�^�Z�b�g����
    '   �֐�   :   Sub DATSET_KOUSYU_MAST()
    '   ����   :   Rs  ADODB.Recordset
    '   �@�@       DT  KOUSYU_MAST_DBT
    '   �@�\   :   �\���̂Ƀf�[�^���Z�b�g����
    '-------------------------------------------------------------------------------
    '2021.08.04 UPGRADE S  AIT)hieutv
    'Public Sub DATSET_KOUSYU_MAST(ByRef Rs As ADODB.Recordset, ByRef DT As KOUSYU_MAST_DBT)

    '    Dim Fld As ADODB.Field    
    Public Sub DATSET_KOUSYU_MAST(ByRef Rs As DataRow, ByRef DT As KOUSYU_MAST_DBT)

        Dim Fld As DataColumn
        '2021.08.04 UPGRADE E

        '�\���̂̏�����
        Call CLEAR_KOUSYU_MAST(DT)

        '�t�B�[���h�����������s
        '2021.08.04 UPGRADE S  AIT)hieutv
        'For Each Fld In Rs.Fields
        '    If IsDBNull(Fld.Name) = False And IsDBNull(Fld.Value) = False Then
        '        Select Case UCase(Fld.Name)
        '            Case "GYOUSYU_KB" : DT.GYOUSYU_KB = Fld.Value '�Ǝ�敪
        '            Case "KOUSYU_CD" : DT.KOUSYU_CD = Fld.Value '�H������
        '            Case "KOUSYU_NO" : DT.KOUSYU_NO = Fld.Value '�H��ԍ�
        '            Case "MEISYOU" : DT.MEISYOU = Fld.Value '�H�햼��
        '            Case "KAMOKU_CD" : DT.KAMOKU_CD = Fld.Value '�Ȗں���
        '            Case "LAST_YMD" : DT.LAST_YMD = Fld.Value '�ŏI�X�V���t
        '        End Select
        '    End If
        'Next Fld
        For Each Fld In Rs.Table.Columns
            If IsDBNull(Fld.ColumnName) = False And IsDBNull(Rs(Fld.ColumnName)) = False Then
                Select Case UCase(Fld.ColumnName)
                    Case "GYOUSYU_KB" : DT.GYOUSYU_KB = Rs(Fld.ColumnName) '�Ǝ�敪
                    Case "KOUSYU_CD" : DT.KOUSYU_CD = Rs(Fld.ColumnName) '�H������
                    Case "KOUSYU_NO" : DT.KOUSYU_NO = Rs(Fld.ColumnName) '�H��ԍ�
                    Case "MEISYOU" : DT.MEISYOU = Rs(Fld.ColumnName) '�H�햼��
                    Case "KAMOKU_CD" : DT.KAMOKU_CD = Rs(Fld.ColumnName) '�Ȗں���
                    Case "LAST_YMD" : DT.LAST_YMD = Rs(Fld.ColumnName) '�ŏI�X�V���t
                End Select
            End If
        Next Fld
        '2021.08.04 UPGRADE E

    End Sub

    '-------------------------------------------------------------------------------
    '   ����   :   KOUSYU_MAST �ǂݍ��ݏ���
    '   �֐�   :   Function SELECT_KOUSYU_MAST()
    '   ����   :   Jouken�@ ������
    '   �@�@       strSort�@�\�[�g����
    '   �@�@       DT()�@   KOUSYU_MAST_DBT
    '   �ߒl   :   �ް���   ����I��
    '   �@�@       -1�@     �ُ�I��
    '   �@�\   :   KOUSYU_MAST SELECT����
    '-------------------------------------------------------------------------------
    Public Function SELECT_KOUSYU_MAST(ByRef Jouken As String, ByRef strSort As String, ByRef DT() As KOUSYU_MAST_DBT) As Integer

        Dim SQL As String
        '2021.08.04 UPGRADE S  AIT)hieutv
        'Dim Rs As ADODB.Recordset
        Dim Rs As New DataTable
        '2021.08.04 UPGRADE E
        Dim Cnt As Integer
        Dim OpenFlg As Short

        '2021.07.26 UPGRADE S  AIT)Tool Convert
        'On Error GoTo SELECT_KOUSYU_MAST_Err
        Try
            '2021.07.26 UPGRADE E

            '�߂�l�̏�����
            SELECT_KOUSYU_MAST = -1

            'SQL/SELECT���g��
            SQL = "SELECT * FROM " & KOUSYU_MAST_TBLNAME
            If Trim(Jouken) <> "" Then
                SQL = SQL & " WHERE " & Jouken
            End If
            If Trim(strSort) <> "" Then
                SQL = SQL & " ORDER BY " & strSort
            End If

            'SQL�����s
            '2021.08.04 UPGRADE S  AIT)hieutv
            'Rs = SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText)
            Rs = RsOpen(SQL)
            '2021.08.04 UPGRADE E
            OpenFlg = 1

            Cnt = 0
            'Do Until Rs.EOF
            '    ReDim Preserve DT(Cnt)
            '    Call DATSET_KOUSYU_MAST(Rs, DT(Cnt))
            '    Cnt = Cnt + 1
            '    Rs.MoveNext()
            'Loop

            'Rs.Close()
            For Each Row As DataRow In Rs.Rows
                ReDim Preserve DT(Cnt)
                Call DATSET_KOUSYU_MAST(Row, DT(Cnt))
                Cnt = Cnt + 1
            Next

            Rs.Dispose()
            '2021.08.04 UPGRADE E
            Rs = Nothing

            '�߂�l�̃Z�b�g
            SELECT_KOUSYU_MAST = Cnt
            Exit Function

            '2021.07.26 UPGRADE S  AIT)Tool Convert
            'SELECT_KOUSYU_MAST_Err:
        Catch ex As Exception
            '2021.07.26 UPGRADE E

            If OpenFlg = 1 Then
                '2021.08.04 UPGRADE S  AIT)hieutv
                'Rs.Close()
                Rs.Dispose()
                '2021.08.04 UPGRADE E
            End If
            Rs = Nothing

            '2021.08.04 UPGRADE S  AIT)hieutv
            'Call Sql_Error_Msg("KOUSYU_MAST SELECT")
            Call Sql_Error_Msg(ex, "KOUSYU_MAST SELECT")
            '2021.08.04 UPGRADE E

        End Try     '2021.07.26 UPGRADE ADD AIT)Tool Convert
    End Function

    '-------------------------------------------------------------------------------
    '   ����   :   KOUSYU_MAST �ǂݍ��݌����擾����
    '   �֐�   :   Function CNTGET_KOUSYU_MAST()
    '   ����   :   Jouken�@ ������
    '   �ߒl   :   �ް���   ����I��
    '   �@�@       -1�@     �ُ�I��
    '   �@�\   :   KOUSYU_MAST CNTGET����
    '-------------------------------------------------------------------------------
    Public Function CNTGET_KOUSYU_MAST(ByRef Jouken As String) As Integer

        Dim SQL As String
        '2021.08.04 UPGRADE S  AIT)hieutv
        'Dim Rs As ADODB.Recordset
        Dim Rs As New DataTable
        '2021.08.04 UPGRADE E
        Dim Cnt As Integer
        Dim OpenFlg As Short

        '2021.07.26 UPGRADE S  AIT)Tool Convert
        'On Error GoTo CNTGET_KOUSYU_MAST_Err
        Try
            '2021.07.26 UPGRADE E

            '�߂�l�̏�����
            CNTGET_KOUSYU_MAST = -1

            'SQL/SELECT���g��
            '2021.08.10 UPGRADE S  AIT)hieutv
            'SQL = "SELECT COUNT(*) FROM " & KOUSYU_MAST_TBLNAME
            SQL = "SELECT COUNT(*) AS COUNTDATA FROM " & KOUSYU_MAST_TBLNAME
            '2021.08.10 UPGRADE E
            If Trim(Jouken) <> "" Then
                SQL = SQL & " WHERE " & Jouken
            End If

            'SQL�����s
            '2021.08.04 UPGRADE S  AIT)hieutv
            'Rs = SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText)
            Rs = RsOpen(SQL)
            '2021.08.04 UPGRADE E
            OpenFlg = 1

            Cnt = 0
            '2021.08.04 UPGRADE S  AIT)hieutv
            'If Rs.EOF = False Then
            '    If IsDBNull(Rs.Fields(0).Value) = False Then
            '        Cnt = Rs.Fields(0).Value
            '    End If
            'End If

            'Rs.Close()
            If Rs.Rows.Count > 0 Then
                If IsDBNull(Rs.Rows(0)("COUNTDATA")) = False Then
                    Cnt = Rs.Rows(0)("COUNTDATA")
                End If
            End If

            Rs.Dispose()
            '2021.08.04 UPGRADE E
            Rs = Nothing

            '�߂�l�̃Z�b�g
            CNTGET_KOUSYU_MAST = Cnt
            Exit Function

            '2021.07.26 UPGRADE S  AIT)Tool Convert
            'CNTGET_KOUSYU_MAST_Err:
        Catch ex As Exception
            '2021.07.26 UPGRADE E

            If OpenFlg = 1 Then
                '2021.08.04 UPGRADE S  AIT)hieutv
                'Rs.Close()
                Rs.Dispose()
                '2021.08.04 UPGRADE E
            End If
            Rs = Nothing

            '2021.08.04 UPGRADE S  AIT)hieutv
            'Call Sql_Error_Msg("KOUSYU_MAST CNTGET")
            Call Sql_Error_Msg(ex, "KOUSYU_MAST CNTGET")
            '2021.08.04 UPGRADE E

        End Try     '2021.07.26 UPGRADE ADD AIT)Tool Convert
    End Function

    '-------------------------------------------------------------------------------
    '   ����   :   KOUSYU_MAST CREATE
    '   �֐�   :   Function CREATE_KOUSYU_MAST()
    '   �ߒl   :   True     ����I��
    '   �@�@       False    �ُ�I��
    '   �@�\   :   KOUSYU_MAST CREATE����
    '-------------------------------------------------------------------------------
    Public Function CREATE_KOUSYU_MAST() As Boolean

        Dim SQL As String

        '2021.07.26 UPGRADE S  AIT)Tool Convert
        'On Error GoTo CREATE_KOUSYU_MAST_Err
        Try
            '2021.07.26 UPGRADE E

            '�߂�l�̏�����
            CREATE_KOUSYU_MAST = False

            'SQL/CREATE���g��
            SQL = "CREATE TABLE " & KOUSYU_MAST_TBLNAME
            SQL = SQL & " ("
            SQL = SQL & " GYOUSYU_KB     Text(2)," '�Ǝ�敪
            SQL = SQL & " KOUSYU_CD      Text(1)," '�H������
            SQL = SQL & " KOUSYU_NO      Text(2)," '�H��ԍ�
            SQL = SQL & " MEISYOU        Text(40)," '�H�햼��
            SQL = SQL & " KAMOKU_CD      Text(6)," '�Ȗں���
            SQL = SQL & " LAST_YMD       Text(8)," '�ŏI�X�V���t
            SQL = SQL & " CONSTRAINT KOUSYU_MAST_UNIQUE PRIMARY KEY ("
            SQL = SQL & " GYOUSYU_KB," '�Ǝ�敪
            SQL = SQL & " KOUSYU_CD," '�H������
            SQL = SQL & " KOUSYU_NO" '�H��ԍ�
            SQL = SQL & " ))"

            'SQL�����s
            '2021.08.04 UPGRADE S  AIT)hieutv
            'SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText + ADODB.ExecuteOptionEnum.adExecuteNoRecords)
            ExecSQL(SQL)
            '2021.08.04 UPGRADE E

            '�߂�l�̃Z�b�g
            CREATE_KOUSYU_MAST = True
            Exit Function

            '2021.07.26 UPGRADE S  AIT)Tool Convert
            'CREATE_KOUSYU_MAST_Err:
        Catch ex As Exception
            '2021.07.26 UPGRADE E

            '2021.08.04 UPGRADE S  AIT)hieutv
            'Call Sql_Error_Msg("KOUSYU_MAST CREATE")
            Call Sql_Error_Msg(ex, "KOUSYU_MAST CREATE")
            '2021.08.04 UPGRADE E

        End Try     '2021.07.26 UPGRADE ADD AIT)Tool Convert
    End Function

    '-------------------------------------------------------------------------------
    '   ����   :   KOUSYU_MAST TEXT WRITE
    '   �֐�   :   Sub TXT_WRITE_KOUSYU_MAST()
    '   ����   :   TextName �e�L�X�g�t�@�C����
    '   �@�@       DT()�@   KOUSYU_MAST_DBT
    '   �@�\   :   KOUSYU_MAST TEXT WRITE ����(CSV�`��)
    '-------------------------------------------------------------------------------
    Public Sub TXT_WRITE_KOUSYU_MAST(ByRef TextName As String, ByRef DT() As KOUSYU_MAST_DBT)

        Dim Msg As String
        Dim lp As Integer
        Dim Out_Buf As String
        Dim FNo As Short

        On Error Resume Next

        '�e�L�X�g�t�@�C���̍폜
        If Dir(Trim(TextName)) <> "" Then
            Msg = "���ɓ����̃t�@�C�������݂��܂��B�㏑�����Ă���낵���ł����H"
            Msg = Msg & vbCrLf & vbCrLf & Trim(TextName)
            '2021.09.14 UPGRADE S  AIT)dannnl
            'If MsgBox(Msg, MsgBoxStyle.YesNo) = MsgBoxResult.No Then Exit Sub
            If MsgBox(Msg, MsgBoxStyle.YesNo, SYSTEMNM) = MsgBoxResult.No Then Exit Sub
            '2021.09.14 UPGRADE E
            Kill(Trim(TextName))
        End If

        '�e�L�X�g�t�@�C���I�[�v��
        FNo = FreeFile
        FileOpen(FNo, Trim(TextName), OpenMode.Output, OpenAccess.Write)

        '-----------------
        '�e�L�X�g���o������
        '-----------------
        For lp = 0 To UBound(DT)
            '�e�L�X�g�f�[�^���쐬���e�L�X�g�t�@�C������������
            Out_Buf = ""
            Out_Buf = Out_Buf & Chr(34) & CRSet(DT(lp).GYOUSYU_KB) & Chr(34) & "," '�Ǝ�敪
            Out_Buf = Out_Buf & Chr(34) & CRSet(DT(lp).KOUSYU_CD) & Chr(34) & "," '�H������
            Out_Buf = Out_Buf & Chr(34) & CRSet(DT(lp).KOUSYU_NO) & Chr(34) & "," '�H��ԍ�
            Out_Buf = Out_Buf & Chr(34) & CRSet(DT(lp).MEISYOU) & Chr(34) & "," '�H�햼��
            Out_Buf = Out_Buf & Chr(34) & CRSet(DT(lp).KAMOKU_CD) & Chr(34) & "," '�Ȗں���
            Out_Buf = Out_Buf & Chr(34) & CRSet(DT(lp).LAST_YMD) & Chr(34) & "" '�ŏI�X�V���t
            PrintLine(FNo, Out_Buf)
        Next lp

        '�e�L�X�g�t�@�C���N���[�Y
        FileClose(FNo)

    End Sub

    '-------------------------------------------------------------------------------
    '   ����   :   KOUSYU_MAST TEXT READ
    '   �֐�   :   Function TXT_READ_KOUSYU_MAST()
    '   ����   :   TextName �e�L�X�g�t�@�C����
    '   �ߒl   :   �ް���   ����I��
    '   �@�@       -1�@     �ُ�I��
    '   �@�\   :   KOUSYU_MAST TEXT READ ����(CSV�`��)
    '-------------------------------------------------------------------------------
    Public Function TXT_READ_KOUSYU_MAST(ByRef TextName As String) As Integer

        Dim Jouken As String
        Dim FNo As Short
        Dim IB As String
        Dim Bp As Short
        Dim Sp As Short
        Dim Cnt As Integer
        Dim FLen As Integer
        Dim DT As KOUSYU_MAST_DBT

        On Error Resume Next

        '�߂�l�̏�����
        TXT_READ_KOUSYU_MAST = -1

        '�t�@�C�����݃`�F�b�N
        Err.Clear()
        FLen = FileLen(TextName)
        If Err.Number <> 0 Then
            TXT_READ_KOUSYU_MAST = 0
            Exit Function
        End If

        '�e�L�X�g�t�@�C���I�[�v��
        FNo = FreeFile
        FileOpen(FNo, Trim(TextName), OpenMode.Input, OpenAccess.Read)

        '�e�L�X�g�t�@�C����ǂݍ���
        Do
            IB = LineInput(FNo)

            '�G���[�̏ꍇ�̓��[�v�𔲂���
            If Err.Number <> 0 Then Exit Do

            IB = IB & "," & Chr(34)
            Do
                Sp = InStr(IB, "~|")
                If Sp > 0 Then Mid(IB, Sp, 2) = Chr(13) & Chr(10) Else Exit Do
            Loop

            '�\���̂ɃZ�b�g
            Bp = 2
            Sp = InStr(Bp, IB, "," & Chr(34)) : DT.GYOUSYU_KB = Mid(IB, Bp, Sp - Bp - 1) : Bp = Sp + 2 '�Ǝ�敪
            Sp = InStr(Bp, IB, "," & Chr(34)) : DT.KOUSYU_CD = Mid(IB, Bp, Sp - Bp - 1) : Bp = Sp + 2 '�H������
            Sp = InStr(Bp, IB, "," & Chr(34)) : DT.KOUSYU_NO = Mid(IB, Bp, Sp - Bp - 1) : Bp = Sp + 2 '�H��ԍ�
            Sp = InStr(Bp, IB, "," & Chr(34)) : DT.MEISYOU = Mid(IB, Bp, Sp - Bp - 1) : Bp = Sp + 2 '�H�햼��
            Sp = InStr(Bp, IB, "," & Chr(34)) : DT.KAMOKU_CD = Mid(IB, Bp, Sp - Bp - 1) : Bp = Sp + 2 '�Ȗں���
            Sp = InStr(Bp, IB, "," & Chr(34)) : DT.LAST_YMD = Mid(IB, Bp, Sp - Bp - 1) : Bp = Sp + 2 '�ŏI�X�V���t

            '�f�[�^��o�^
            Jouken = ""
            Jouken = Jouken & " GYOUSYU_KB = '" & DT.GYOUSYU_KB & "' AND" '�Ǝ�敪
            Jouken = Jouken & " KOUSYU_CD = '" & DT.KOUSYU_CD & "' AND" '�H������
            Jouken = Jouken & " KOUSYU_NO = '" & DT.KOUSYU_NO & "' AND" '�H��ԍ�
            If Right(Jouken, 4) = " AND" Then Jouken = Left(Jouken, Len(Jouken) - 4)
            If CNTGET_KOUSYU_MAST(Jouken) = 0 Then
                If INSERT_KOUSYU_MAST(DT) = False Then
                    Cnt = -1
                    Exit Do
                End If
            Else
                If UPDATE_KOUSYU_MAST(Jouken, DT) = False Then
                    Cnt = -1
                    Exit Do
                End If
            End If

            '�f�[�^���J�E���g
            Cnt = Cnt + 1
        Loop

        '�e�L�X�g�t�@�C���N���[�Y
        FileClose(FNo)

        '�߂�l�̃Z�b�g
        TXT_READ_KOUSYU_MAST = Cnt

    End Function
End Module
