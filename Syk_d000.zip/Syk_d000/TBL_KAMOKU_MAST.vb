Option Strict Off
Option Explicit On

Module DB_KAMOKU_MAST

    Public Const KAMOKU_MAST_TBLNAME As String = "KAMOKU_MAST"

    '�Ȗڃ}�X�^
    Structure KAMOKU_MAST_DBT
        '2021.07.26 UPGRADE S  AIT)Tool Convert
        '<VBFixedString(6),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=6)> Public KAMOKU_CD() As Char '�Ȗں���
        '<VBFixedString(8),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=8)> Public SAIMOKU_CD() As Char '�זں���
        '<VBFixedString(40),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=40)> Public MEISYOU() As Char '�Ȗڥ�זږ���
        '<VBFixedString(1),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=1)> Public KAMOKU_KB() As Char '�Ȗڋ敪
        '<VBFixedString(1),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=1)> Public EDABAN_KB() As Char '�}�ԋ敪
        '<VBFixedString(1),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=1)> Public BUMON_KB() As Char '����敪
        '<VBFixedString(1),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=1)> Public KOUJI_KB() As Char '�H���敪
        '<VBFixedString(1),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=1)> Public SYOUHIZEI_KB() As Char '����ŋ敪
        '<VBFixedString(1),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=1)> Public TORIHIKI_KB() As Char '����敪
        '<VBFixedString(6),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=6)> Public ZEI_KAMOKU_CD() As Char '����ŉȖں���
        '<VBFixedString(1),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=1)> Public SIIRE_KB() As Char '�d���敪
        <VBFixedStringAttribute(6)> Public KAMOKU_CD As String   '�Ȗں���
        <VBFixedStringAttribute(8)> Public SAIMOKU_CD As String  '�זں���
        <VBFixedStringAttribute(40)> Public MEISYOU As String    '�Ȗڥ�זږ���
        <VBFixedStringAttribute(1)> Public KAMOKU_KB As String   '�Ȗڋ敪
        <VBFixedStringAttribute(1)> Public EDABAN_KB As String   '�}�ԋ敪
        <VBFixedStringAttribute(1)> Public BUMON_KB As String    '����敪
        <VBFixedStringAttribute(1)> Public KOUJI_KB As String    '�H���敪
        <VBFixedStringAttribute(1)> Public SYOUHIZEI_KB As String    '����ŋ敪
        <VBFixedStringAttribute(1)> Public TORIHIKI_KB As String     '����敪
        <VBFixedStringAttribute(6)> Public ZEI_KAMOKU_CD As String   '����ŉȖں���
        <VBFixedStringAttribute(1)> Public SIIRE_KB As String    '�d���敪
        '2021.07.26 UPGRADE E
    End Structure

    '-------------------------------------------------------------------------------
    '   ����   :   KAMOKU_MAST_DBT �\���̃N���A����
    '   �֐�   :   Sub CLEAR_KAMOKU_MAST()
    '   ����   :   DT  KAMOKU_MAST_DBT
    '   �@�\   :   �\���̂�����������
    '-------------------------------------------------------------------------------
    Public Sub CLEAR_KAMOKU_MAST(ByRef DT As KAMOKU_MAST_DBT)

        With DT
            .KAMOKU_CD = "" '�Ȗں���
            .SAIMOKU_CD = "" '�זں���
            .MEISYOU = "" '�Ȗڥ�זږ���
            .KAMOKU_KB = "" '�Ȗڋ敪
            .EDABAN_KB = "" '�}�ԋ敪
            .BUMON_KB = "" '����敪
            .KOUJI_KB = "" '�H���敪
            .SYOUHIZEI_KB = "" '����ŋ敪
            .TORIHIKI_KB = "" '����敪
            .ZEI_KAMOKU_CD = "" '����ŉȖں���
            .SIIRE_KB = "" '�d���敪
        End With

    End Sub

    '-------------------------------------------------------------------------------
    '   ����   :   KAMOKU_MAST Delete
    '   �֐�   :   Function DELETE_KAMOKU_MAST()
    '   ����   :   Jouken   ������
    '   �ߒl   :   True     ����I��
    '   �@�@       False    �ُ�I��
    '   �@�\   :   KAMOKU_MAST DELETE����
    '-------------------------------------------------------------------------------
    Public Function DELETE_KAMOKU_MAST(ByRef Jouken As String) As Boolean

        Dim SQL As String

        '2021.07.26 UPGRADE S  AIT)Tool Convert
        'On Error GoTo DELETE_KAMOKU_MAST_Err
        Try
            '2021.07.26 UPGRADE E

            '�߂�l�̏�����
            DELETE_KAMOKU_MAST = False

            'SQL/DELETE���g��
            SQL = "DELETE FROM " & KAMOKU_MAST_TBLNAME
            If Trim(Jouken) <> "" Then
                SQL = SQL & " WHERE " & Jouken
            End If

            'SQL�����s
            '2021.08.04 UPGRADE S  AIT)hieutv
            'SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText + ADODB.ExecuteOptionEnum.adExecuteNoRecords)
            ExecSQL(SQL)
            '2021.08.04 UPGRADE E

            '�߂�l�̃Z�b�g
            DELETE_KAMOKU_MAST = True
            Exit Function

            '2021.07.26 UPGRADE S  AIT)Tool Convert
            'DELETE_KAMOKU_MAST_Err:
        Catch ex As Exception
            '2021.07.26 UPGRADE E

            '2021.08.04 UPGRADE S  AIT)hieutv
            'Call Sql_Error_Msg("KAMOKU_MAST DELETE")
            Call Sql_Error_Msg(ex, "KAMOKU_MAST DELETE")
            '2021.08.04 UPGRADE E

        End Try     '2021.07.26 UPGRADE ADD AIT)Tool Convert
    End Function

    '-------------------------------------------------------------------------------
    '   ����   :   KAMOKU_MAST INSERT����
    '   �֐�   :   Function INSERT_KAMOKU_MAST()
    '   ����   :   DT       KAMOKU_MAST_DBT
    '   �ߒl   :   True     ����I��
    '   �@�@       False    �ُ�I��
    '   �@�\   :   KAMOKU_MAST INSERT����
    '-------------------------------------------------------------------------------
    Public Function INSERT_KAMOKU_MAST(ByRef DT As KAMOKU_MAST_DBT) As Boolean

        Dim SQL As String

        '2021.07.26 UPGRADE S  AIT)Tool Convert
        'On Error GoTo INSERT_KAMOKU_MAST_Err
        Try
            '2021.07.26 UPGRADE E

            '�߂�l�̏�����
            INSERT_KAMOKU_MAST = False

            'SQL/INSERT���g��
            SQL = "INSERT INTO " & KAMOKU_MAST_TBLNAME
            SQL = SQL & " ("
            SQL = SQL & " KAMOKU_CD,"
            SQL = SQL & " SAIMOKU_CD,"
            SQL = SQL & " MEISYOU,"
            SQL = SQL & " KAMOKU_KB,"
            SQL = SQL & " EDABAN_KB,"
            SQL = SQL & " BUMON_KB,"
            SQL = SQL & " KOUJI_KB,"
            SQL = SQL & " SYOUHIZEI_KB,"
            SQL = SQL & " TORIHIKI_KB,"
            SQL = SQL & " ZEI_KAMOKU_CD,"
            SQL = SQL & " SIIRE_KB"
            SQL = SQL & " ) VALUES("
            SQL = SQL & " '" & Trim(DT.KAMOKU_CD) & "'," '�Ȗں���
            SQL = SQL & " '" & Trim(DT.SAIMOKU_CD) & "'," '�זں���
            SQL = SQL & " '" & Trim(DT.MEISYOU) & "'," '�Ȗڥ�זږ���
            SQL = SQL & " '" & Trim(DT.KAMOKU_KB) & "'," '�Ȗڋ敪
            SQL = SQL & " '" & Trim(DT.EDABAN_KB) & "'," '�}�ԋ敪
            SQL = SQL & " '" & Trim(DT.BUMON_KB) & "'," '����敪
            SQL = SQL & " '" & Trim(DT.KOUJI_KB) & "'," '�H���敪
            SQL = SQL & " '" & Trim(DT.SYOUHIZEI_KB) & "'," '����ŋ敪
            SQL = SQL & " '" & Trim(DT.TORIHIKI_KB) & "'," '����敪
            SQL = SQL & " '" & Trim(DT.ZEI_KAMOKU_CD) & "'," '����ŉȖں���
            SQL = SQL & " '" & Trim(DT.SIIRE_KB) & "'" '�d���敪
            SQL = SQL & " )"

            'SQL�����s
            '2021.08.04 UPGRADE S  AIT)hieutv
            'SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText + ADODB.ExecuteOptionEnum.adExecuteNoRecords)
            ExecSQL(SQL)
            '2021.08.04 UPGRADE E

            '�߂�l�̃Z�b�g
            INSERT_KAMOKU_MAST = True
            Exit Function

            '2021.07.26 UPGRADE S  AIT)Tool Convert
            'INSERT_KAMOKU_MAST_Err:
        Catch ex As Exception
            '2021.07.26 UPGRADE E

            '2021.08.04 UPGRADE S  AIT)hieutv
            'Call Sql_Error_Msg("KAMOKU_MAST INSERT")
            Call Sql_Error_Msg(ex, "KAMOKU_MAST INSERT")
            '2021.08.04 UPGRADE E

        End Try     '2021.07.26 UPGRADE ADD AIT)Tool Convert
    End Function

    '-------------------------------------------------------------------------------
    '   ����   :   KAMOKU_MAST UPDATE
    '   �֐�   :   Function UPDATE_KAMOKU_MAST()
    '   ����   :   Jouken   ������
    '   �@�@       DT       KAMOKU_MAST_DBT
    '   �ߒl   :   True     ����I��
    '   �@�@       False    �ُ�I��
    '   �@�\   :   KAMOKU_MAST UPDATE����
    '-------------------------------------------------------------------------------
    Public Function UPDATE_KAMOKU_MAST(ByRef Jouken As String, ByRef DT As KAMOKU_MAST_DBT) As Boolean

        Dim SQL As String

        '2021.07.26 UPGRADE S  AIT)Tool Convert
        'On Error GoTo UPDATE_KAMOKU_MAST_Err
        Try
            '2021.07.26 UPGRADE E

            '�߂�l�̏�����
            UPDATE_KAMOKU_MAST = False

            'SQL/UPDATE���g��
            SQL = "UPDATE " & KAMOKU_MAST_TBLNAME
            SQL = SQL & " SET"
            SQL = SQL & " KAMOKU_CD = '" & Trim(DT.KAMOKU_CD) & "'," '�Ȗں���
            SQL = SQL & " SAIMOKU_CD = '" & Trim(DT.SAIMOKU_CD) & "'," '�זں���
            SQL = SQL & " MEISYOU = '" & Trim(DT.MEISYOU) & "'," '�Ȗڥ�זږ���
            SQL = SQL & " KAMOKU_KB = '" & Trim(DT.KAMOKU_KB) & "'," '�Ȗڋ敪
            SQL = SQL & " EDABAN_KB = '" & Trim(DT.EDABAN_KB) & "'," '�}�ԋ敪
            SQL = SQL & " BUMON_KB = '" & Trim(DT.BUMON_KB) & "'," '����敪
            SQL = SQL & " KOUJI_KB = '" & Trim(DT.KOUJI_KB) & "'," '�H���敪
            SQL = SQL & " SYOUHIZEI_KB = '" & Trim(DT.SYOUHIZEI_KB) & "'," '����ŋ敪
            SQL = SQL & " TORIHIKI_KB = '" & Trim(DT.TORIHIKI_KB) & "'," '����敪
            SQL = SQL & " ZEI_KAMOKU_CD = '" & Trim(DT.ZEI_KAMOKU_CD) & "'," '����ŉȖں���
            SQL = SQL & " SIIRE_KB = '" & Trim(DT.SIIRE_KB) & "'" '�d���敪
            If Trim(Jouken) <> "" Then
                SQL = SQL & " WHERE " & Jouken
            End If

            'SQL�����s
            '2021.08.04 UPGRADE S  AIT)hieutv
            'SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText + ADODB.ExecuteOptionEnum.adExecuteNoRecords)
            ExecSQL(SQL)
            '2021.08.04 UPGRADE E

            '�߂�l�̃Z�b�g
            UPDATE_KAMOKU_MAST = True
            Exit Function

            '2021.07.26 UPGRADE S  AIT)Tool Convert
            'UPDATE_KAMOKU_MAST_Err:
        Catch ex As Exception
            '2021.07.26 UPGRADE E

            '2021.08.04 UPGRADE S  AIT)hieutv
            'Call Sql_Error_Msg("KAMOKU_MAST UPDATE")
            Call Sql_Error_Msg(ex, "KAMOKU_MAST UPDATE")
            '2021.08.04 UPGRADE E

        End Try     '2021.07.26 UPGRADE ADD AIT)Tool Convert
    End Function

    '-------------------------------------------------------------------------------
    '   ����   :   KAMOKU_MAST �f�[�^�Z�b�g����
    '   �֐�   :   Sub DATSET_KAMOKU_MAST()
    '   ����   :   Rs  ADODB.Recordset
    '   �@�@       DT  KAMOKU_MAST_DBT
    '   �@�\   :   �\���̂Ƀf�[�^���Z�b�g����
    '-------------------------------------------------------------------------------
    '2021.08.04 UPGRADE S  AIT)hieutv
    'Public Sub DATSET_KAMOKU_MAST(ByRef Rs As ADODB.Recordset, ByRef DT As KAMOKU_MAST_DBT)

    '    Dim Fld As ADODB.Field
    Public Sub DATSET_KAMOKU_MAST(ByRef Rs As DataRow, ByRef DT As KAMOKU_MAST_DBT)

        Dim Fld As DataColumn
        '2021.08.04 UPGRADE E

        '�\���̂̏�����
        Call CLEAR_KAMOKU_MAST(DT)

        '�t�B�[���h�����������s
        '2021.08.04 UPGRADE S  AIT)hieutv
        'For Each Fld In Rs.Fields
        '    If IsDBNull(Fld.Name) = False And IsDBNull(Fld.Value) = False Then
        '        Select Case UCase(Fld.Name)
        '            Case "KAMOKU_CD" : DT.KAMOKU_CD = Fld.Value '�Ȗں���
        '            Case "SAIMOKU_CD" : DT.SAIMOKU_CD = Fld.Value '�זں���
        '            Case "MEISYOU" : DT.MEISYOU = Fld.Value '�Ȗڥ�זږ���
        '            Case "KAMOKU_KB" : DT.KAMOKU_KB = Fld.Value '�Ȗڋ敪
        '            Case "EDABAN_KB" : DT.EDABAN_KB = Fld.Value '�}�ԋ敪
        '            Case "BUMON_KB" : DT.BUMON_KB = Fld.Value '����敪
        '            Case "KOUJI_KB" : DT.KOUJI_KB = Fld.Value '�H���敪
        '            Case "SYOUHIZEI_KB" : DT.SYOUHIZEI_KB = Fld.Value '����ŋ敪
        '            Case "TORIHIKI_KB" : DT.TORIHIKI_KB = Fld.Value '����敪
        '            Case "ZEI_KAMOKU_CD" : DT.ZEI_KAMOKU_CD = Fld.Value '����ŉȖں���
        '            Case "SIIRE_KB" : DT.SIIRE_KB = Fld.Value '�d���敪
        '        End Select
        '    End If
        'Next Fld
        For Each Fld In Rs.Table.Columns
            If IsDBNull(Fld.ColumnName) = False And IsDBNull(Rs(Fld.ColumnName)) = False Then
                Select Case UCase(Fld.ColumnName)
                    Case "KAMOKU_CD" : DT.KAMOKU_CD = Rs(Fld.ColumnName) '�Ȗں���
                    Case "SAIMOKU_CD" : DT.SAIMOKU_CD = Rs(Fld.ColumnName) '�זں���
                    Case "MEISYOU" : DT.MEISYOU = Rs(Fld.ColumnName) '�Ȗڥ�זږ���
                    Case "KAMOKU_KB" : DT.KAMOKU_KB = Rs(Fld.ColumnName) '�Ȗڋ敪
                    Case "EDABAN_KB" : DT.EDABAN_KB = Rs(Fld.ColumnName) '�}�ԋ敪
                    Case "BUMON_KB" : DT.BUMON_KB = Rs(Fld.ColumnName) '����敪
                    Case "KOUJI_KB" : DT.KOUJI_KB = Rs(Fld.ColumnName) '�H���敪
                    Case "SYOUHIZEI_KB" : DT.SYOUHIZEI_KB = Rs(Fld.ColumnName) '����ŋ敪
                    Case "TORIHIKI_KB" : DT.TORIHIKI_KB = Rs(Fld.ColumnName) '����敪
                    Case "ZEI_KAMOKU_CD" : DT.ZEI_KAMOKU_CD = Rs(Fld.ColumnName) '����ŉȖں���
                    Case "SIIRE_KB" : DT.SIIRE_KB = Rs(Fld.ColumnName) '�d���敪
                End Select
            End If
        Next Fld
        '2021.08.04 UPGRADE E

    End Sub

    '-------------------------------------------------------------------------------
    '   ����   :   KAMOKU_MAST �ǂݍ��ݏ���
    '   �֐�   :   Function SELECT_KAMOKU_MAST()
    '   ����   :   Jouken�@ ������
    '   �@�@       strSort�@�\�[�g����
    '   �@�@       DT()�@   KAMOKU_MAST_DBT
    '   �ߒl   :   �ް���   ����I��
    '   �@�@       -1�@     �ُ�I��
    '   �@�\   :   KAMOKU_MAST SELECT����
    '-------------------------------------------------------------------------------
    Public Function SELECT_KAMOKU_MAST(ByRef Jouken As String, ByRef strSort As String, ByRef DT() As KAMOKU_MAST_DBT) As Integer

        Dim SQL As String
        '2021.08.04 UPGRADE S  AIT)hieutv
        'Dim Rs As ADODB.Recordset
        Dim Rs As New DataTable
        '2021.08.04 UPGRADE E
        Dim Cnt As Integer
        Dim OpenFlg As Short

        '2021.07.26 UPGRADE S  AIT)Tool Convert
        'On Error GoTo SELECT_KAMOKU_MAST_Err
        Try
            '2021.07.26 UPGRADE E

            '�߂�l�̏�����
            SELECT_KAMOKU_MAST = -1

            'SQL/SELECT���g��
            SQL = "SELECT * FROM " & KAMOKU_MAST_TBLNAME
            If Trim(Jouken) <> "" Then
                SQL = SQL & " WHERE " & Jouken
            End If
            If Trim(strSort) <> "" Then
                SQL = SQL & " ORDER BY " & strSort
            End If

            'SQL�����s
            '2021.08.04 UPGRADE S  AIT)hieutv
            'Rs = SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText)
            Rs = RsOpen(SQL)
            '2021.08.04 UPGRADE E
            OpenFlg = 1

            Cnt = 0
            '2021.08.04 UPGRADE S  AIT)hieutv
            'Do Until Rs.EOF
            '    ReDim Preserve DT(Cnt)
            '    Call DATSET_KAMOKU_MAST(Rs, DT(Cnt))
            '    Cnt = Cnt + 1
            '    Rs.MoveNext()
            'Loop

            'Rs.Close()
            For Each Row As DataRow In Rs.Rows
                ReDim Preserve DT(Cnt)
                Call DATSET_KAMOKU_MAST(Row, DT(Cnt))
                Cnt = Cnt + 1
            Next

            Rs.Dispose()
            '2021.08.04 UPGRADE E
            Rs = Nothing

            '�߂�l�̃Z�b�g
            SELECT_KAMOKU_MAST = Cnt
            Exit Function

            '2021.07.26 UPGRADE S  AIT)Tool Convert
            'SELECT_KAMOKU_MAST_Err:
        Catch ex As Exception
            '2021.07.26 UPGRADE E

            If OpenFlg = 1 Then
                '2021.08.04 UPGRADE S  AIT)hieutv
                'Rs.Close()
                Rs.Dispose()
                '2021.08.04 UPGRADE E
            End If
            Rs = Nothing

            '2021.08.04 UPGRADE S  AIT)hieutv
            'Call Sql_Error_Msg("KAMOKU_MAST SELECT")
            Call Sql_Error_Msg(ex, "KAMOKU_MAST SELECT")
            '2021.08.04 UPGRADE E

        End Try     '2021.07.26 UPGRADE ADD AIT)Tool Convert
    End Function

    '-------------------------------------------------------------------------------
    '   ����   :   KAMOKU_MAST �ǂݍ��݌����擾����
    '   �֐�   :   Function CNTGET_KAMOKU_MAST()
    '   ����   :   Jouken�@ ������
    '   �ߒl   :   �ް���   ����I��
    '   �@�@       -1�@     �ُ�I��
    '   �@�\   :   KAMOKU_MAST CNTGET����
    '-------------------------------------------------------------------------------
    Public Function CNTGET_KAMOKU_MAST(ByRef Jouken As String) As Integer

        Dim SQL As String
        '2021.08.04 UPGRADE S  AIT)hieutv
        'Dim Rs As ADODB.Recordset
        Dim Rs As New DataTable
        '2021.08.04 UPGRADE E
        Dim Cnt As Integer
        Dim OpenFlg As Short

        '2021.07.26 UPGRADE S  AIT)Tool Convert
        'On Error GoTo CNTGET_KAMOKU_MAST_Err
        Try
            '2021.07.26 UPGRADE E

            '�߂�l�̏�����
            CNTGET_KAMOKU_MAST = -1

            'SQL/SELECT���g��
            '2021.08.10 UPGRADE S  AIT)hieutv
            'SQL = "SELECT COUNT(*) FROM " & KAMOKU_MAST_TBLNAME
            SQL = "SELECT COUNT(*) AS COUNTDATA FROM " & KAMOKU_MAST_TBLNAME
            '2021.08.10 UPGRADE E
            If Trim(Jouken) <> "" Then
                SQL = SQL & " WHERE " & Jouken
            End If

            'SQL�����s
            '2021.08.04 UPGRADE S  AIT)hieutv
            'Rs = SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText)
            Rs = RsOpen(SQL)
            '2021.08.04 UPGRADE E
            OpenFlg = 1

            Cnt = 0
            '2021.08.04 UPGRADE S  AIT)hieutv
            'If Rs.EOF = False Then
            '    If IsDBNull(Rs.Fields(0).Value) = False Then
            '        Cnt = Rs.Fields(0).Value
            '    End If
            'End If

            'Rs.Close()
            If Rs.Rows.Count > 0 Then
                If IsDBNull(Rs.Rows(0)("COUNTDATA")) = False Then
                    Cnt = Rs.Rows(0)("COUNTDATA")
                End If
            End If

            Rs.Dispose()
            '2021.08.04 UPGRADE E
            Rs = Nothing

            '�߂�l�̃Z�b�g
            CNTGET_KAMOKU_MAST = Cnt
            Exit Function

            '2021.07.26 UPGRADE S  AIT)Tool Convert
            'CNTGET_KAMOKU_MAST_Err:
        Catch ex As Exception
            '2021.07.26 UPGRADE E

            If OpenFlg = 1 Then
                '2021.08.04 UPGRADE S  AIT)hieutv
                'Rs.Close()
                Rs.Dispose()
                '2021.08.04 UPGRADE E
            End If
            Rs = Nothing

            '2021.08.04 UPGRADE S  AIT)hieutv
            'Call Sql_Error_Msg("KAMOKU_MAST CNTGET")
            Call Sql_Error_Msg(ex, "KAMOKU_MAST CNTGET")
            '2021.08.04 UPGRADE E

        End Try     '2021.07.26 UPGRADE ADD AIT)Tool Convert
    End Function

    '-------------------------------------------------------------------------------
    '   ����   :   KAMOKU_MAST CREATE
    '   �֐�   :   Function CREATE_KAMOKU_MAST()
    '   �ߒl   :   True     ����I��
    '   �@�@       False    �ُ�I��
    '   �@�\   :   KAMOKU_MAST CREATE����
    '-------------------------------------------------------------------------------
    Public Function CREATE_KAMOKU_MAST() As Boolean

        Dim SQL As String

        '2021.07.26 UPGRADE S  AIT)Tool Convert
        'On Error GoTo CREATE_KAMOKU_MAST_Err
        Try
            '2021.07.26 UPGRADE E

            '�߂�l�̏�����
            CREATE_KAMOKU_MAST = False

            'SQL/CREATE���g��
            SQL = "CREATE TABLE " & KAMOKU_MAST_TBLNAME
            SQL = SQL & " ("
            SQL = SQL & " KAMOKU_CD      Text(6)," '�Ȗں���
            SQL = SQL & " SAIMOKU_CD     Text(8)," '�זں���
            SQL = SQL & " MEISYOU        Text(40)," '�Ȗڥ�זږ���
            SQL = SQL & " KAMOKU_KB      Text(1)," '�Ȗڋ敪
            SQL = SQL & " EDABAN_KB      Text(1)," '�}�ԋ敪
            SQL = SQL & " BUMON_KB       Text(1)," '����敪
            SQL = SQL & " KOUJI_KB       Text(1)," '�H���敪
            SQL = SQL & " SYOUHIZEI_KB   Text(1)," '����ŋ敪
            SQL = SQL & " TORIHIKI_KB    Text(1)," '����敪
            SQL = SQL & " ZEI_KAMOKU_CD   Text(6)," '����ŉȖں���
            SQL = SQL & " SIIRE_KB       Text(1)," '�d���敪
            SQL = SQL & " CONSTRAINT KAMOKU_MAST_UNIQUE PRIMARY KEY ("
            SQL = SQL & " KAMOKU_CD," '�Ȗں���
            SQL = SQL & " SAIMOKU_CD" '�זں���
            SQL = SQL & " ))"

            'SQL�����s
            '2021.08.04 UPGRADE S  AIT)hieutv
            'SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText + ADODB.ExecuteOptionEnum.adExecuteNoRecords)
            ExecSQL(SQL)
            '2021.08.04 UPGRADE E

            '�߂�l�̃Z�b�g
            CREATE_KAMOKU_MAST = True
            Exit Function

            '2021.07.26 UPGRADE S  AIT)Tool Convert
            'CREATE_KAMOKU_MAST_Err:
        Catch ex As Exception
            '2021.07.26 UPGRADE E

            '2021.08.04 UPGRADE S  AIT)hieutv
            'Call Sql_Error_Msg("KAMOKU_MAST CREATE")
            Call Sql_Error_Msg(ex, "KAMOKU_MAST CREATE")
            '2021.08.04 UPGRADE E

        End Try     '2021.07.26 UPGRADE ADD AIT)Tool Convert
    End Function

    '-------------------------------------------------------------------------------
    '   ����   :   KAMOKU_MAST TEXT WRITE
    '   �֐�   :   Sub TXT_WRITE_KAMOKU_MAST()
    '   ����   :   TextName �e�L�X�g�t�@�C����
    '   �@�@       DT()�@   KAMOKU_MAST_DBT
    '   �@�\   :   KAMOKU_MAST TEXT WRITE ����(CSV�`��)
    '-------------------------------------------------------------------------------
    Public Sub TXT_WRITE_KAMOKU_MAST(ByRef TextName As String, ByRef DT() As KAMOKU_MAST_DBT)

        Dim Msg As String
        Dim lp As Integer
        Dim Out_Buf As String
        Dim FNo As Short

        On Error Resume Next

        '�e�L�X�g�t�@�C���̍폜
        If Dir(Trim(TextName)) <> "" Then
            Msg = "���ɓ����̃t�@�C�������݂��܂��B�㏑�����Ă���낵���ł����H"
            Msg = Msg & vbCrLf & vbCrLf & Trim(TextName)
            '2021.09.14 UPGRADE S  AIT)dannnl
            'If MsgBox(Msg, MsgBoxStyle.YesNo) = MsgBoxResult.No Then Exit Sub
            If MsgBox(Msg, MsgBoxStyle.YesNo, SYSTEMNM) = MsgBoxResult.No Then Exit Sub
            '2021.09.14 UPGRADE E
            Kill(Trim(TextName))
        End If

        '�e�L�X�g�t�@�C���I�[�v��
        FNo = FreeFile
        FileOpen(FNo, Trim(TextName), OpenMode.Output, OpenAccess.Write)

        '-----------------
        '�e�L�X�g���o������
        '-----------------
        For lp = 0 To UBound(DT)
            '�e�L�X�g�f�[�^���쐬���e�L�X�g�t�@�C������������
            Out_Buf = ""
            Out_Buf = Out_Buf & Chr(34) & CRSet(DT(lp).KAMOKU_CD) & Chr(34) & "," '�Ȗں���
            Out_Buf = Out_Buf & Chr(34) & CRSet(DT(lp).SAIMOKU_CD) & Chr(34) & "," '�זں���
            Out_Buf = Out_Buf & Chr(34) & CRSet(DT(lp).MEISYOU) & Chr(34) & "," '�Ȗڥ�זږ���
            Out_Buf = Out_Buf & Chr(34) & CRSet(DT(lp).KAMOKU_KB) & Chr(34) & "," '�Ȗڋ敪
            Out_Buf = Out_Buf & Chr(34) & CRSet(DT(lp).EDABAN_KB) & Chr(34) & "," '�}�ԋ敪
            Out_Buf = Out_Buf & Chr(34) & CRSet(DT(lp).BUMON_KB) & Chr(34) & "," '����敪
            Out_Buf = Out_Buf & Chr(34) & CRSet(DT(lp).KOUJI_KB) & Chr(34) & "," '�H���敪
            Out_Buf = Out_Buf & Chr(34) & CRSet(DT(lp).SYOUHIZEI_KB) & Chr(34) & "," '����ŋ敪
            Out_Buf = Out_Buf & Chr(34) & CRSet(DT(lp).TORIHIKI_KB) & Chr(34) & "," '����敪
            Out_Buf = Out_Buf & Chr(34) & CRSet(DT(lp).ZEI_KAMOKU_CD) & Chr(34) & "," '����ŉȖں���
            Out_Buf = Out_Buf & Chr(34) & CRSet(DT(lp).SIIRE_KB) & Chr(34) & "" '�d���敪
            PrintLine(FNo, Out_Buf)
        Next lp

        '�e�L�X�g�t�@�C���N���[�Y
        FileClose(FNo)

    End Sub

    '-------------------------------------------------------------------------------
    '   ����   :   KAMOKU_MAST TEXT READ
    '   �֐�   :   Function TXT_READ_KAMOKU_MAST()
    '   ����   :   TextName �e�L�X�g�t�@�C����
    '   �ߒl   :   �ް���   ����I��
    '   �@�@       -1�@     �ُ�I��
    '   �@�\   :   KAMOKU_MAST TEXT READ ����(CSV�`��)
    '-------------------------------------------------------------------------------
    Public Function TXT_READ_KAMOKU_MAST(ByRef TextName As String) As Integer

        Dim Jouken As String
        Dim FNo As Short
        Dim IB As String
        Dim Bp As Short
        Dim Sp As Short
        Dim Cnt As Integer
        Dim FLen As Integer
        Dim DT As KAMOKU_MAST_DBT

        On Error Resume Next

        '�߂�l�̏�����
        TXT_READ_KAMOKU_MAST = -1

        '�t�@�C�����݃`�F�b�N
        Err.Clear()
        FLen = FileLen(TextName)
        If Err.Number <> 0 Then
            TXT_READ_KAMOKU_MAST = 0
            Exit Function
        End If

        '�e�L�X�g�t�@�C���I�[�v��
        FNo = FreeFile
        FileOpen(FNo, Trim(TextName), OpenMode.Input, OpenAccess.Read)

        '�e�L�X�g�t�@�C����ǂݍ���
        Do
            IB = LineInput(FNo)

            '�G���[�̏ꍇ�̓��[�v�𔲂���
            If Err.Number <> 0 Then Exit Do

            IB = IB & "," & Chr(34)
            Do
                Sp = InStr(IB, "~|")
                If Sp > 0 Then Mid(IB, Sp, 2) = Chr(13) & Chr(10) Else Exit Do
            Loop

            '�\���̂ɃZ�b�g
            Bp = 2
            Sp = InStr(Bp, IB, "," & Chr(34)) : DT.KAMOKU_CD = Mid(IB, Bp, Sp - Bp - 1) : Bp = Sp + 2 '�Ȗں���
            Sp = InStr(Bp, IB, "," & Chr(34)) : DT.SAIMOKU_CD = Mid(IB, Bp, Sp - Bp - 1) : Bp = Sp + 2 '�זں���
            Sp = InStr(Bp, IB, "," & Chr(34)) : DT.MEISYOU = Mid(IB, Bp, Sp - Bp - 1) : Bp = Sp + 2 '�Ȗڥ�זږ���
            Sp = InStr(Bp, IB, "," & Chr(34)) : DT.KAMOKU_KB = Mid(IB, Bp, Sp - Bp - 1) : Bp = Sp + 2 '�Ȗڋ敪
            Sp = InStr(Bp, IB, "," & Chr(34)) : DT.EDABAN_KB = Mid(IB, Bp, Sp - Bp - 1) : Bp = Sp + 2 '�}�ԋ敪
            Sp = InStr(Bp, IB, "," & Chr(34)) : DT.BUMON_KB = Mid(IB, Bp, Sp - Bp - 1) : Bp = Sp + 2 '����敪
            Sp = InStr(Bp, IB, "," & Chr(34)) : DT.KOUJI_KB = Mid(IB, Bp, Sp - Bp - 1) : Bp = Sp + 2 '�H���敪
            Sp = InStr(Bp, IB, "," & Chr(34)) : DT.SYOUHIZEI_KB = Mid(IB, Bp, Sp - Bp - 1) : Bp = Sp + 2 '����ŋ敪
            Sp = InStr(Bp, IB, "," & Chr(34)) : DT.TORIHIKI_KB = Mid(IB, Bp, Sp - Bp - 1) : Bp = Sp + 2 '����敪
            Sp = InStr(Bp, IB, "," & Chr(34)) : DT.ZEI_KAMOKU_CD = Mid(IB, Bp, Sp - Bp - 1) : Bp = Sp + 2 '����ŉȖں���
            Sp = InStr(Bp, IB, "," & Chr(34)) : DT.SIIRE_KB = Mid(IB, Bp, Sp - Bp - 1) : Bp = Sp + 2 '�d���敪

            '�f�[�^��o�^
            Jouken = ""
            Jouken = Jouken & " KAMOKU_CD = '" & DT.KAMOKU_CD & "' AND" '�Ȗں���
            Jouken = Jouken & " SAIMOKU_CD = '" & DT.SAIMOKU_CD & "' AND" '�זں���
            If Right(Jouken, 4) = " AND" Then Jouken = Left(Jouken, Len(Jouken) - 4)
            If CNTGET_KAMOKU_MAST(Jouken) = 0 Then
                If INSERT_KAMOKU_MAST(DT) = False Then
                    Cnt = -1
                    Exit Do
                End If
            Else
                If UPDATE_KAMOKU_MAST(Jouken, DT) = False Then
                    Cnt = -1
                    Exit Do
                End If
            End If

            '�f�[�^���J�E���g
            Cnt = Cnt + 1
        Loop

        '�e�L�X�g�t�@�C���N���[�Y
        FileClose(FNo)

        '�߂�l�̃Z�b�g
        TXT_READ_KAMOKU_MAST = Cnt

    End Function
End Module
