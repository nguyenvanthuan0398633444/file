Imports GrapeCity.Win.Editors

<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frmSYKD150
#Region "Windows Form Designer generated code "
    <System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
        MyBase.New()
        'This call is required by the Windows Form Designer.
        InitializeComponent()
        Me.Frame1 = New ArrayList
        Me.Label1 = New ArrayList
        Me.cmdKey = New ArrayList
        Me.ctlMeisai1 = New ArrayList
        Me.ctlMeisai2 = New ArrayList
        Me.imNumber1 = New ArrayList
        Me.imNumber2 = New ArrayList
        Me.imText1 = New ArrayList
        Me.imText2 = New ArrayList
        Me.imText3 = New ArrayList
        Me.imText4 = New ArrayList
        Me.Frame1.Add(_Frame1_0)
        Me.Frame1.Add(_Frame1_1)
        Me.Frame1.Add(_Frame1_2)
        Me.Frame1.Add(_Frame1_3)
        Me.Frame1.Add(_Frame1_4)

        Me.Label1.Add(_Label1_0)
        Me.Label1.Add(_Label1_1)
        Me.Label1.Add(_Label1_2)
        Me.Label1.Add(_Label1_3)
        Me.Label1.Add(_Label1_4)
        Me.Label1.Add(_Label1_5)
        Me.Label1.Add(_Label1_6)
        Me.Label1.Add(_Label1_7)
        Me.Label1.Add(_Label1_8)
        Me.Label1.Add(_Label1_9)
        Me.Label1.Add(_Label1_10)
        Me.Label1.Add(_Label1_11)
        Me.Label1.Add(_Label1_12)
        Me.Label1.Add(_Label1_13)
        Me.Label1.Add(_Label1_14)
        Me.Label1.Add(_Label1_15)
        Me.Label1.Add(_Label1_16)
        Me.Label1.Add(_Label1_17)
        Me.Label1.Add(_Label1_18)
        Me.Label1.Add(_Label1_19)
        Me.Label1.Add(_Label1_20)
        Me.Label1.Add(_Label1_21)
        Me.Label1.Add(_Label1_22)
        Me.Label1.Add(_Label1_23)
        Me.Label1.Add(_Label1_24)
        Me.Label1.Add(_Label1_25)
        Me.Label1.Add(_Label1_26)
        Me.Label1.Add(_Label1_27)
        Me.Label1.Add(_Label1_28)
        Me.Label1.Add(_Label1_29)
        Me.Label1.Add(_Label1_30)
        Me.Label1.Add(_Label1_31)
        Me.Label1.Add(_Label1_32)
        Me.Label1.Add(_Label1_33)
        Me.Label1.Add(_Label1_34)
        Me.Label1.Add(_Label1_35)
        Me.Label1.Add(_Label1_36)
        Me.Label1.Add(_Label1_37)
        Me.Label1.Add(_Label1_38)
        Me.Label1.Add(_Label1_39)
        Me.Label1.Add(_Label1_40)
        Me.Label1.Add(_Label1_41)
        Me.Label1.Add(_Label1_42)
        Me.Label1.Add(_Label1_43)
        Me.Label1.Add(_Label1_44)
        Me.Label1.Add(_Label1_45)
        Me.Label1.Add(_Label1_46)

        Me.cmdKey.Add(Nothing)
        Me.cmdKey.Add(_cmdKey_1)
        Me.cmdKey.Add(_cmdKey_2)
        Me.cmdKey.Add(_cmdKey_3)
        Me.cmdKey.Add(_cmdKey_5)
        Me.cmdKey.Add(_cmdKey_4)
        Me.cmdKey.Add(_cmdKey_6)
        Me.cmdKey.Add(_cmdKey_7)
        Me.cmdKey.Add(_cmdKey_8)
        Me.cmdKey.Add(_cmdKey_9)
        Me.cmdKey.Add(_cmdKey_10)
        Me.cmdKey.Add(_cmdKey_11)
        Me.cmdKey.Add(_cmdKey_12)

        Me.imNumber1.Add(_imNumber1_0)
        Me.imNumber1.Add(_imNumber1_1)
        Me.imNumber1.Add(_imNumber1_2)

        Me.imNumber2.Add(_imNumber2_0)
        Me.imNumber2.Add(_imNumber2_1)
        Me.imNumber2.Add(_imNumber2_2)
        Me.imNumber2.Add(_imNumber2_3)
        Me.imNumber2.Add(_imNumber2_4)
        Me.imNumber2.Add(_imNumber2_5)
        Me.imNumber2.Add(_imNumber2_6)
        Me.imNumber2.Add(_imNumber2_7)
        Me.imNumber2.Add(_imNumber2_8)

        Me.imText1.Add(_imText1_0)
        Me.imText1.Add(_imText1_1)
        Me.imText1.Add(_imText1_2)
        Me.imText1.Add(_imText1_3)

        Me.imText2.Add(_imText2_0)
        Me.imText2.Add(_imText2_1)
        Me.imText2.Add(_imText2_2)

        Me.imText3.Add(_imText3_0)
        Me.imText3.Add(_imText3_1)
        Me.imText3.Add(_imText3_2)
        Me.imText3.Add(_imText3_3)
        Me.imText3.Add(_imText3_4)
        Me.imText3.Add(_imText3_5)
        Me.imText3.Add(_imText3_6)
        Me.imText3.Add(_imText3_7)
        Me.imText3.Add(_imText3_8)

        Me.imText4.Add(_imText4_0)
        Me.imText4.Add(Nothing)
        Me.imText4.Add(_imText4_2)
        Me.imText4.Add(_imText4_3)
        Me.imText4.Add(_imText4_4)
        Me.imText4.Add(_imText4_5)
        Me.imText4.Add(_imText4_6)
        Me.imText4.Add(_imText4_7)

        Me.ctlMeisai1.Add(_ctlMeisai1_0)
        Me.ctlMeisai1.Add(_ctlMeisai1_1)
        Me.ctlMeisai1.Add(_ctlMeisai1_2)

        Me.ctlMeisai2.Add(_ctlMeisai2_0)
        Me.ctlMeisai2.Add(_ctlMeisai2_1)
        Me.ctlMeisai2.Add(_ctlMeisai2_2)
        Me.ctlMeisai2.Add(_ctlMeisai2_3)
    End Sub
    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
        If Disposing Then
            If Not components Is Nothing Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(Disposing)
    End Sub
    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer
    Public ToolTip1 As System.Windows.Forms.ToolTip
    Public WithEvents _imText3_4 As GcTextBox
    Public WithEvents _imText3_5 As GcTextBox
    Public WithEvents _imText3_6 As GcTextBox
    Public WithEvents _imNumber2_6 As GcNumber
    Public WithEvents Picture2 As System.Windows.Forms.Panel
    Public WithEvents _ctlMeisai2_0 As ctlIppan
    Public WithEvents VScroll2 As System.Windows.Forms.VScrollBar
    Public WithEvents _ctlMeisai2_1 As ctlIppan
    Public WithEvents _ctlMeisai2_2 As ctlIppan
    Public WithEvents _ctlMeisai2_3 As ctlIppan
    Public WithEvents _imText3_7 As GcTextBox
    Public WithEvents _imText3_8 As GcTextBox
    Public WithEvents _Label1_44 As System.Windows.Forms.Label
    Public WithEvents _Label1_43 As System.Windows.Forms.Label
    Public WithEvents _Label1_39 As System.Windows.Forms.Label
    Public WithEvents _Label1_38 As System.Windows.Forms.Label
    Public WithEvents _Label1_37 As System.Windows.Forms.Label
    Public WithEvents _Label1_36 As System.Windows.Forms.Label
    Public WithEvents _Label1_35 As System.Windows.Forms.Label
    Public WithEvents _Label1_30 As System.Windows.Forms.Label
    Public WithEvents _Label1_33 As System.Windows.Forms.Label
    Public WithEvents _Label1_34 As System.Windows.Forms.Label
    Public WithEvents _Label1_27 As System.Windows.Forms.Label
    Public WithEvents _Label1_28 As System.Windows.Forms.Label
    Public WithEvents _Label1_29 As System.Windows.Forms.Label
    Public WithEvents _Label1_32 As System.Windows.Forms.Label
    Public WithEvents _Label1_31 As System.Windows.Forms.Label
    Public WithEvents _Frame1_4 As System.Windows.Forms.GroupBox
    Public WithEvents _imText4_0 As GcTextBox
    Public WithEvents _imNumber2_0 As GcNumber
    Public WithEvents _imText4_2 As GcTextBox
    Public WithEvents _imText4_3 As GcTextBox
    Public WithEvents _imNumber2_1 As GcNumber
    Public WithEvents _imText4_4 As GcTextBox
    Public WithEvents _imText4_5 As GcTextBox
    Public WithEvents _imText4_6 As GcTextBox
    Public WithEvents _imNumber2_3 As GcNumber
    Public WithEvents _imText4_7 As GcTextBox
    Public WithEvents _imNumber2_4 As GcNumber
    Public WithEvents _imNumber2_2 As GcNumber
    Public WithEvents _imNumber2_7 As GcNumber
    Public WithEvents _imNumber2_8 As GcNumber
    Public WithEvents _Label1_46 As System.Windows.Forms.Label
    Public WithEvents _Label1_45 As System.Windows.Forms.Label
    Public WithEvents _Label1_3 As System.Windows.Forms.Label
    Public WithEvents _Label1_25 As System.Windows.Forms.Label
    Public WithEvents _Label1_26 As System.Windows.Forms.Label
    Public WithEvents _Label1_24 As System.Windows.Forms.Label
    Public WithEvents _Label1_23 As System.Windows.Forms.Label
    Public WithEvents _Label1_21 As System.Windows.Forms.Label
    Public WithEvents _Label1_22 As System.Windows.Forms.Label
    Public WithEvents Label2 As System.Windows.Forms.Label
    Public WithEvents _Label1_20 As System.Windows.Forms.Label
    Public WithEvents _Label1_19 As System.Windows.Forms.Label
    Public WithEvents _Label1_18 As System.Windows.Forms.Label
    Public WithEvents _Label1_17 As System.Windows.Forms.Label
    Public WithEvents _Label1_16 As System.Windows.Forms.Label
    Public WithEvents _Label1_15 As System.Windows.Forms.Label
    Public WithEvents _Frame1_3 As System.Windows.Forms.GroupBox
    Public WithEvents VScroll1 As System.Windows.Forms.VScrollBar
    Public WithEvents _ctlMeisai1_0 As ctlKeiyaku
    Public WithEvents _imText3_0 As GcTextBox
    Public WithEvents _ctlMeisai1_1 As ctlKeiyaku
    Public WithEvents _ctlMeisai1_2 As ctlKeiyaku
    Public WithEvents _imText3_1 As GcTextBox
    Public WithEvents _imText3_2 As GcTextBox
    Public WithEvents _imText3_3 As GcTextBox
    Public WithEvents _Label1_10 As System.Windows.Forms.Label
    Public WithEvents _Label1_11 As System.Windows.Forms.Label
    Public WithEvents _Label1_14 As System.Windows.Forms.Label
    Public WithEvents _Label1_9 As System.Windows.Forms.Label
    Public WithEvents _Label1_8 As System.Windows.Forms.Label
    Public WithEvents _Label1_7 As System.Windows.Forms.Label
    Public WithEvents _Label1_13 As System.Windows.Forms.Label
    Public WithEvents _Label1_12 As System.Windows.Forms.Label
    Public WithEvents _Frame1_2 As System.Windows.Forms.GroupBox
    Public WithEvents _imNumber1_0 As GcNumber
    Public WithEvents _imNumber1_1 As GcNumber
    Public WithEvents _imNumber1_2 As GcNumber
    Public WithEvents _Label1_42 As System.Windows.Forms.Label
    Public WithEvents _Label1_41 As System.Windows.Forms.Label
    Public WithEvents _Label1_40 As System.Windows.Forms.Label
    Public WithEvents _Label1_6 As System.Windows.Forms.Label
    Public WithEvents _Label1_5 As System.Windows.Forms.Label
    Public WithEvents _Label1_4 As System.Windows.Forms.Label
    Public WithEvents _Frame1_1 As System.Windows.Forms.GroupBox
    Public WithEvents Check1 As System.Windows.Forms.CheckBox
    Public WithEvents _imText1_0 As GcTextBox
    Public WithEvents _imText1_3 As GcTextBox
    Public WithEvents _imText1_2 As GcTextBox
    Public WithEvents _imText1_1 As GcTextBox
    Public WithEvents _Label1_1 As System.Windows.Forms.Label
    Public WithEvents _Label1_0 As System.Windows.Forms.Label
    Public WithEvents _Label1_2 As System.Windows.Forms.Label
    Public WithEvents _Frame1_0 As System.Windows.Forms.GroupBox
    Public WithEvents _cmdKey_3 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_12 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_4 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_10 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_6 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_7 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_8 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_9 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_1 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_11 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_2 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_5 As System.Windows.Forms.Button
    Public WithEvents Picture1 As System.Windows.Forms.Panel
    Public WithEvents Message As System.Windows.Forms.ToolStripStatusLabel
    Public WithEvents _StatusBar1_Panel2 As System.Windows.Forms.ToolStripStatusLabel
    Public WithEvents StatusBar1 As System.Windows.Forms.StatusStrip
    Public WithEvents _imText2_2 As GcTextBox
    Public WithEvents _imText2_0 As GcTextBox
    Public WithEvents _imText2_1 As GcTextBox
    Public WithEvents lblTitle As System.Windows.Forms.Label
    Public WithEvents Frame1 As ArrayList
    Public WithEvents Label1 As ArrayList
    Public WithEvents cmdKey As ArrayList
    Public WithEvents ctlMeisai1 As ArrayList
    Public WithEvents ctlMeisai2 As ArrayList
    Public WithEvents imNumber1 As ArrayList
    Public WithEvents imNumber2 As ArrayList
    Public WithEvents imText1 As ArrayList
    Public WithEvents imText2 As ArrayList
    Public WithEvents imText3 As ArrayList
    Public WithEvents imText4 As ArrayList
    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim NumberSignDisplayField1 As GrapeCity.Win.Editors.Fields.NumberSignDisplayField = New GrapeCity.Win.Editors.Fields.NumberSignDisplayField()
        Dim NumberIntegerPartDisplayField1 As GrapeCity.Win.Editors.Fields.NumberIntegerPartDisplayField = New GrapeCity.Win.Editors.Fields.NumberIntegerPartDisplayField()
        Dim NumberSignDisplayField2 As GrapeCity.Win.Editors.Fields.NumberSignDisplayField = New GrapeCity.Win.Editors.Fields.NumberSignDisplayField()
        Dim NumberIntegerPartDisplayField2 As GrapeCity.Win.Editors.Fields.NumberIntegerPartDisplayField = New GrapeCity.Win.Editors.Fields.NumberIntegerPartDisplayField()
        Dim NumberIntegerPartDisplayField3 As GrapeCity.Win.Editors.Fields.NumberIntegerPartDisplayField = New GrapeCity.Win.Editors.Fields.NumberIntegerPartDisplayField()
        Dim NumberIntegerPartDisplayField4 As GrapeCity.Win.Editors.Fields.NumberIntegerPartDisplayField = New GrapeCity.Win.Editors.Fields.NumberIntegerPartDisplayField()
        Dim NumberIntegerPartDisplayField5 As GrapeCity.Win.Editors.Fields.NumberIntegerPartDisplayField = New GrapeCity.Win.Editors.Fields.NumberIntegerPartDisplayField()
        Dim NumberIntegerPartDisplayField6 As GrapeCity.Win.Editors.Fields.NumberIntegerPartDisplayField = New GrapeCity.Win.Editors.Fields.NumberIntegerPartDisplayField()
        Dim NumberIntegerPartDisplayField7 As GrapeCity.Win.Editors.Fields.NumberIntegerPartDisplayField = New GrapeCity.Win.Editors.Fields.NumberIntegerPartDisplayField()
        Dim NumberIntegerPartDisplayField8 As GrapeCity.Win.Editors.Fields.NumberIntegerPartDisplayField = New GrapeCity.Win.Editors.Fields.NumberIntegerPartDisplayField()
        Dim NumberIntegerPartDisplayField9 As GrapeCity.Win.Editors.Fields.NumberIntegerPartDisplayField = New GrapeCity.Win.Editors.Fields.NumberIntegerPartDisplayField()
        Dim NumberIntegerPartDisplayField10 As GrapeCity.Win.Editors.Fields.NumberIntegerPartDisplayField = New GrapeCity.Win.Editors.Fields.NumberIntegerPartDisplayField()
        Dim NumberIntegerPartDisplayField11 As GrapeCity.Win.Editors.Fields.NumberIntegerPartDisplayField = New GrapeCity.Win.Editors.Fields.NumberIntegerPartDisplayField()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmSYKD150))
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me._Frame1_4 = New System.Windows.Forms.GroupBox()
        Me.Picture2 = New System.Windows.Forms.Panel()
        Me._imText3_4 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._imText3_5 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._imText3_6 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._imNumber2_5 = New GrapeCity.Win.Editors.GcNumber(Me.components)
        Me._imNumber2_6 = New GrapeCity.Win.Editors.GcNumber(Me.components)
        Me.VScroll2 = New System.Windows.Forms.VScrollBar()
        Me._imText3_7 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._imText3_8 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._Label1_44 = New System.Windows.Forms.Label()
        Me._Label1_43 = New System.Windows.Forms.Label()
        Me._Label1_39 = New System.Windows.Forms.Label()
        Me._Label1_38 = New System.Windows.Forms.Label()
        Me._Label1_37 = New System.Windows.Forms.Label()
        Me._Label1_36 = New System.Windows.Forms.Label()
        Me._Label1_35 = New System.Windows.Forms.Label()
        Me._Label1_30 = New System.Windows.Forms.Label()
        Me._Label1_33 = New System.Windows.Forms.Label()
        Me._Label1_34 = New System.Windows.Forms.Label()
        Me._Label1_27 = New System.Windows.Forms.Label()
        Me._Label1_28 = New System.Windows.Forms.Label()
        Me._Label1_29 = New System.Windows.Forms.Label()
        Me._Label1_32 = New System.Windows.Forms.Label()
        Me._Label1_31 = New System.Windows.Forms.Label()
        Me._Frame1_3 = New System.Windows.Forms.GroupBox()
        Me._imText4_0 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._imNumber2_0 = New GrapeCity.Win.Editors.GcNumber(Me.components)
        Me._imText4_2 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._imText4_3 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._imNumber2_1 = New GrapeCity.Win.Editors.GcNumber(Me.components)
        Me._imText4_4 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._imText4_5 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._imText4_6 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._imNumber2_3 = New GrapeCity.Win.Editors.GcNumber(Me.components)
        Me._imText4_7 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._imNumber2_4 = New GrapeCity.Win.Editors.GcNumber(Me.components)
        Me._imNumber2_2 = New GrapeCity.Win.Editors.GcNumber(Me.components)
        Me._imNumber2_7 = New GrapeCity.Win.Editors.GcNumber(Me.components)
        Me._imNumber2_8 = New GrapeCity.Win.Editors.GcNumber(Me.components)
        Me._Label1_46 = New System.Windows.Forms.Label()
        Me._Label1_45 = New System.Windows.Forms.Label()
        Me._Label1_3 = New System.Windows.Forms.Label()
        Me._Label1_25 = New System.Windows.Forms.Label()
        Me._Label1_26 = New System.Windows.Forms.Label()
        Me._Label1_24 = New System.Windows.Forms.Label()
        Me._Label1_23 = New System.Windows.Forms.Label()
        Me._Label1_21 = New System.Windows.Forms.Label()
        Me._Label1_22 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me._Label1_20 = New System.Windows.Forms.Label()
        Me._Label1_19 = New System.Windows.Forms.Label()
        Me._Label1_18 = New System.Windows.Forms.Label()
        Me._Label1_17 = New System.Windows.Forms.Label()
        Me._Label1_16 = New System.Windows.Forms.Label()
        Me._Label1_15 = New System.Windows.Forms.Label()
        Me._Frame1_2 = New System.Windows.Forms.GroupBox()
        Me.VScroll1 = New System.Windows.Forms.VScrollBar()
        Me._imText3_0 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._imText3_1 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._imText3_2 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._imText3_3 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._Label1_10 = New System.Windows.Forms.Label()
        Me._Label1_11 = New System.Windows.Forms.Label()
        Me._Label1_14 = New System.Windows.Forms.Label()
        Me._Label1_9 = New System.Windows.Forms.Label()
        Me._Label1_8 = New System.Windows.Forms.Label()
        Me._Label1_7 = New System.Windows.Forms.Label()
        Me._Label1_13 = New System.Windows.Forms.Label()
        Me._Label1_12 = New System.Windows.Forms.Label()
        Me._Frame1_1 = New System.Windows.Forms.GroupBox()
        Me._imNumber1_0 = New GrapeCity.Win.Editors.GcNumber(Me.components)
        Me._imNumber1_1 = New GrapeCity.Win.Editors.GcNumber(Me.components)
        Me._imNumber1_2 = New GrapeCity.Win.Editors.GcNumber(Me.components)
        Me._Label1_42 = New System.Windows.Forms.Label()
        Me._Label1_41 = New System.Windows.Forms.Label()
        Me._Label1_40 = New System.Windows.Forms.Label()
        Me._Label1_6 = New System.Windows.Forms.Label()
        Me._Label1_5 = New System.Windows.Forms.Label()
        Me._Label1_4 = New System.Windows.Forms.Label()
        Me._Frame1_0 = New System.Windows.Forms.GroupBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Check1 = New System.Windows.Forms.CheckBox()
        Me._imText1_0 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._imText1_3 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._imText1_2 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._imText1_1 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._Label1_1 = New System.Windows.Forms.Label()
        Me._Label1_0 = New System.Windows.Forms.Label()
        Me._Label1_2 = New System.Windows.Forms.Label()
        Me.Picture1 = New System.Windows.Forms.Panel()
        Me._cmdKey_3 = New System.Windows.Forms.Button()
        Me._cmdKey_12 = New System.Windows.Forms.Button()
        Me._cmdKey_4 = New System.Windows.Forms.Button()
        Me._cmdKey_10 = New System.Windows.Forms.Button()
        Me._cmdKey_6 = New System.Windows.Forms.Button()
        Me._cmdKey_7 = New System.Windows.Forms.Button()
        Me._cmdKey_8 = New System.Windows.Forms.Button()
        Me._cmdKey_9 = New System.Windows.Forms.Button()
        Me._cmdKey_1 = New System.Windows.Forms.Button()
        Me._cmdKey_11 = New System.Windows.Forms.Button()
        Me._cmdKey_2 = New System.Windows.Forms.Button()
        Me._cmdKey_5 = New System.Windows.Forms.Button()
        Me.StatusBar1 = New System.Windows.Forms.StatusStrip()
        Me._StatusBar1_Panel2 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.Message = New System.Windows.Forms.ToolStripStatusLabel()
        Me._imText2_2 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._imText2_0 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._imText2_1 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.GcShortcut1 = New GrapeCity.Win.Editors.GcShortcut(Me.components)
        Me._ctlMeisai2_0 = New Syk_d000.ctlIppan()
        Me._ctlMeisai2_1 = New Syk_d000.ctlIppan()
        Me._ctlMeisai2_2 = New Syk_d000.ctlIppan()
        Me._ctlMeisai2_3 = New Syk_d000.ctlIppan()
        Me._ctlMeisai1_0 = New Syk_d000.ctlKeiyaku()
        Me._ctlMeisai1_1 = New Syk_d000.ctlKeiyaku()
        Me._ctlMeisai1_2 = New Syk_d000.ctlKeiyaku()
        Me._Frame1_4.SuspendLayout()
        Me.Picture2.SuspendLayout()
        CType(Me._imText3_4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imText3_5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imText3_6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imNumber2_5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imNumber2_6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imText3_7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imText3_8, System.ComponentModel.ISupportInitialize).BeginInit()
        Me._Frame1_3.SuspendLayout()
        CType(Me._imText4_0, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imNumber2_0, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imText4_2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imText4_3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imNumber2_1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imText4_4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imText4_5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imText4_6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imNumber2_3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imText4_7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imNumber2_4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imNumber2_2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imNumber2_7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imNumber2_8, System.ComponentModel.ISupportInitialize).BeginInit()
        Me._Frame1_2.SuspendLayout()
        CType(Me._imText3_0, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imText3_1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imText3_2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imText3_3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me._Frame1_1.SuspendLayout()
        CType(Me._imNumber1_0, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imNumber1_1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imNumber1_2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me._Frame1_0.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me._imText1_0, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imText1_3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imText1_2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imText1_1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Picture1.SuspendLayout()
        Me.StatusBar1.SuspendLayout()
        CType(Me._imText2_2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imText2_0, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imText2_1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        '_Frame1_4
        '
        Me._Frame1_4.BackColor = System.Drawing.SystemColors.Control
        Me._Frame1_4.Controls.Add(Me.Picture2)
        Me._Frame1_4.Controls.Add(Me._ctlMeisai2_0)
        Me._Frame1_4.Controls.Add(Me.VScroll2)
        Me._Frame1_4.Controls.Add(Me._ctlMeisai2_1)
        Me._Frame1_4.Controls.Add(Me._ctlMeisai2_2)
        Me._Frame1_4.Controls.Add(Me._ctlMeisai2_3)
        Me._Frame1_4.Controls.Add(Me._imText3_7)
        Me._Frame1_4.Controls.Add(Me._imText3_8)
        Me._Frame1_4.Controls.Add(Me._Label1_44)
        Me._Frame1_4.Controls.Add(Me._Label1_43)
        Me._Frame1_4.Controls.Add(Me._Label1_39)
        Me._Frame1_4.Controls.Add(Me._Label1_38)
        Me._Frame1_4.Controls.Add(Me._Label1_37)
        Me._Frame1_4.Controls.Add(Me._Label1_36)
        Me._Frame1_4.Controls.Add(Me._Label1_35)
        Me._Frame1_4.Controls.Add(Me._Label1_30)
        Me._Frame1_4.Controls.Add(Me._Label1_33)
        Me._Frame1_4.Controls.Add(Me._Label1_34)
        Me._Frame1_4.Controls.Add(Me._Label1_27)
        Me._Frame1_4.Controls.Add(Me._Label1_28)
        Me._Frame1_4.Controls.Add(Me._Label1_29)
        Me._Frame1_4.Controls.Add(Me._Label1_32)
        Me._Frame1_4.Controls.Add(Me._Label1_31)
        Me._Frame1_4.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Frame1_4.Location = New System.Drawing.Point(4, 424)
        Me._Frame1_4.Name = "_Frame1_4"
        Me._Frame1_4.Padding = New System.Windows.Forms.Padding(0)
        Me._Frame1_4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Frame1_4.Size = New System.Drawing.Size(1005, 237)
        Me._Frame1_4.TabIndex = 89
        Me._Frame1_4.TabStop = False
        '
        'Picture2
        '
        Me.Picture2.BackColor = System.Drawing.SystemColors.Control
        Me.Picture2.Controls.Add(Me._imText3_4)
        Me.Picture2.Controls.Add(Me._imText3_5)
        Me.Picture2.Controls.Add(Me._imText3_6)
        Me.Picture2.Controls.Add(Me._imNumber2_5)
        Me.Picture2.Controls.Add(Me._imNumber2_6)
        Me.Picture2.Cursor = System.Windows.Forms.Cursors.Default
        Me.Picture2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Picture2.Location = New System.Drawing.Point(319, 204)
        Me.Picture2.Name = "Picture2"
        Me.Picture2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Picture2.Size = New System.Drawing.Size(661, 27)
        Me.Picture2.TabIndex = 107
        '
        '_imText3_4
        '
        Me._imText3_4.BackColor = System.Drawing.SystemColors.Control
        Me._imText3_4.ContentAlignment = System.Drawing.ContentAlignment.MiddleRight
        Me._imText3_4.DisabledForeColor = System.Drawing.SystemColors.MenuText
        Me._imText3_4.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Bold)
        Me._imText3_4.ImeMode = System.Windows.Forms.ImeMode.Off
        Me._imText3_4.Location = New System.Drawing.Point(0, 0)
        Me._imText3_4.Name = "_imText3_4"
        Me._imText3_4.ReadOnly = True
        Me._imText3_4.Size = New System.Drawing.Size(128, 23)
        Me._imText3_4.TabIndex = 27
        Me._imText3_4.TabStop = False
        '
        '_imText3_5
        '
        Me._imText3_5.BackColor = System.Drawing.SystemColors.Control
        Me._imText3_5.ContentAlignment = System.Drawing.ContentAlignment.MiddleRight
        Me._imText3_5.DisabledForeColor = System.Drawing.SystemColors.MenuText
        Me._imText3_5.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Bold)
        Me._imText3_5.Location = New System.Drawing.Point(264, 0)
        Me._imText3_5.Name = "_imText3_5"
        Me._imText3_5.ReadOnly = True
        Me._imText3_5.Size = New System.Drawing.Size(128, 23)
        Me._imText3_5.TabIndex = 29
        Me._imText3_5.TabStop = False
        '
        '_imText3_6
        '
        Me._imText3_6.BackColor = System.Drawing.SystemColors.Control
        Me._imText3_6.ContentAlignment = System.Drawing.ContentAlignment.MiddleRight
        Me._imText3_6.DisabledForeColor = System.Drawing.SystemColors.MenuText
        Me._imText3_6.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Bold)
        Me._imText3_6.Location = New System.Drawing.Point(526, 0)
        Me._imText3_6.Name = "_imText3_6"
        Me._imText3_6.ReadOnly = True
        Me._imText3_6.Size = New System.Drawing.Size(128, 23)
        Me._imText3_6.TabIndex = 31
        Me._imText3_6.TabStop = False
        Me._imText3_6.Text = "9,999,999,999"
        '
        '_imNumber2_5
        '
        Me._imNumber2_5.AlternateText.DisplayNull.ForeColor = System.Drawing.SystemColors.WindowText
        Me._imNumber2_5.AlternateText.DisplayZero.ForeColor = System.Drawing.SystemColors.WindowText
        Me._imNumber2_5.AlternateText.Zero.ForeColor = System.Drawing.SystemColors.WindowText
        Me._imNumber2_5.DisabledBackColor = System.Drawing.SystemColors.Window
        Me._imNumber2_5.DisabledForeColor = System.Drawing.SystemColors.MenuText
        NumberIntegerPartDisplayField1.GroupSizes = New Integer() {3, 3, 0}
        Me._imNumber2_5.DisplayFields.AddRange(New GrapeCity.Win.Editors.Fields.NumberDisplayField() {NumberSignDisplayField1, NumberIntegerPartDisplayField1})
        Me._imNumber2_5.Fields.DecimalPart.MaxDigits = 0
        Me._imNumber2_5.Fields.IntegerPart.GroupSizes = New Integer() {3, 3, 0}
        Me._imNumber2_5.Fields.IntegerPart.MaxDigits = 9
        Me._imNumber2_5.Fields.IntegerPart.MinDigits = 1
        Me._imNumber2_5.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Bold)
        Me._imNumber2_5.HighlightText = True
        Me._imNumber2_5.ImeMode = System.Windows.Forms.ImeMode.Disable
        Me._imNumber2_5.Location = New System.Drawing.Point(132, 0)
        Me._imNumber2_5.MaxValue = New Decimal(New Integer() {999999999, 0, 0, 0})
        Me._imNumber2_5.MinValue = New Decimal(New Integer() {999999999, 0, 0, -2147483648})
        Me._imNumber2_5.Name = "_imNumber2_5"
        Me.GcShortcut1.SetShortcuts(Me._imNumber2_5, New GrapeCity.Win.Editors.ShortcutCollection(New System.Windows.Forms.Keys() {System.Windows.Forms.Keys.F2, System.Windows.Forms.Keys.Subtract, System.Windows.Forms.Keys.OemMinus, CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.[Return]), System.Windows.Forms.Keys)}, New Object() {CType(Me._imNumber2_5, Object), CType(Me._imNumber2_5, Object), CType(Me._imNumber2_5, Object), CType(Me._imNumber2_5, Object)}, New String() {"SetZero", "SwitchSign", "SwitchSign", "ApplyRecommendedValue"}))
        Me._imNumber2_5.Size = New System.Drawing.Size(128, 23)
        Me._imNumber2_5.TabIndex = 28
        Me._imNumber2_5.Tag = "��s����������͂��ĉ������B"
        Me._imNumber2_5.Value = Nothing
        '
        '_imNumber2_6
        '
        Me._imNumber2_6.AlternateText.DisplayNull.ForeColor = System.Drawing.SystemColors.WindowText
        Me._imNumber2_6.AlternateText.DisplayZero.ForeColor = System.Drawing.SystemColors.WindowText
        Me._imNumber2_6.AlternateText.Zero.ForeColor = System.Drawing.SystemColors.WindowText
        Me._imNumber2_6.DisabledBackColor = System.Drawing.SystemColors.Window
        Me._imNumber2_6.DisabledForeColor = System.Drawing.SystemColors.MenuText
        NumberIntegerPartDisplayField2.GroupSizes = New Integer() {3, 3, 3, 0}
        Me._imNumber2_6.DisplayFields.AddRange(New GrapeCity.Win.Editors.Fields.NumberDisplayField() {NumberSignDisplayField2, NumberIntegerPartDisplayField2})
        Me._imNumber2_6.Fields.DecimalPart.MaxDigits = 0
        Me._imNumber2_6.Fields.IntegerPart.GroupSizes = New Integer() {3, 3, 3, 0}
        Me._imNumber2_6.Fields.IntegerPart.MaxDigits = 10
        Me._imNumber2_6.Fields.IntegerPart.MinDigits = 1
        Me._imNumber2_6.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Bold)
        Me._imNumber2_6.HighlightText = True
        Me._imNumber2_6.ImeMode = System.Windows.Forms.ImeMode.Disable
        Me._imNumber2_6.Location = New System.Drawing.Point(395, 0)
        Me._imNumber2_6.MaxValue = New Decimal(New Integer() {1410065407, 2, 0, 0})
        Me._imNumber2_6.MinValue = New Decimal(New Integer() {1410065407, 2, 0, -2147483648})
        Me._imNumber2_6.Name = "_imNumber2_6"
        Me._imNumber2_6.Size = New System.Drawing.Size(128, 23)
        Me._imNumber2_6.TabIndex = 30
        Me._imNumber2_6.Tag = "���S���������͂��ĉ������B"
        Me._imNumber2_6.Value = Nothing
        '
        'VScroll2
        '
        Me.VScroll2.Cursor = System.Windows.Forms.Cursors.Default
        Me.VScroll2.LargeChange = 4
        Me.VScroll2.Location = New System.Drawing.Point(981, 40)
        Me.VScroll2.Maximum = 32770
        Me.VScroll2.Name = "VScroll2"
        Me.VScroll2.Size = New System.Drawing.Size(17, 135)
        Me.VScroll2.TabIndex = 26
        Me.VScroll2.TabStop = True
        '
        '_imText3_7
        '
        Me._imText3_7.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._imText3_7.Location = New System.Drawing.Point(182, 204)
        Me._imText3_7.Name = "_imText3_7"
        Me._imText3_7.Size = New System.Drawing.Size(128, 23)
        Me._imText3_7.TabIndex = 109
        Me._imText3_7.Text = "9,999,999,999"
        Me._imText3_7.Visible = False
        '
        '_imText3_8
        '
        Me._imText3_8.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._imText3_8.ImeMode = System.Windows.Forms.ImeMode.Off
        Me._imText3_8.Location = New System.Drawing.Point(50, 204)
        Me._imText3_8.Name = "_imText3_8"
        Me._imText3_8.Size = New System.Drawing.Size(128, 23)
        Me._imText3_8.TabIndex = 110
        Me._imText3_8.Text = "9,999,999,999"
        Me._imText3_8.Visible = False
        '
        '_Label1_44
        '
        Me._Label1_44.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_44.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_44.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_44.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_44.ForeColor = System.Drawing.Color.White
        Me._Label1_44.Location = New System.Drawing.Point(50, 180)
        Me._Label1_44.Name = "_Label1_44"
        Me._Label1_44.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_44.Size = New System.Drawing.Size(128, 23)
        Me._Label1_44.TabIndex = 111
        Me._Label1_44.Text = "�݌ɍ��v"
        Me._Label1_44.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me._Label1_44.Visible = False
        '
        '_Label1_43
        '
        Me._Label1_43.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_43.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_43.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_43.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_43.ForeColor = System.Drawing.Color.White
        Me._Label1_43.Location = New System.Drawing.Point(182, 180)
        Me._Label1_43.Name = "_Label1_43"
        Me._Label1_43.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_43.Size = New System.Drawing.Size(128, 23)
        Me._Label1_43.TabIndex = 108
        Me._Label1_43.Text = "���v���z"
        Me._Label1_43.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me._Label1_43.Visible = False
        '
        '_Label1_39
        '
        Me._Label1_39.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_39.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_39.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_39.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_39.ForeColor = System.Drawing.Color.White
        Me._Label1_39.Location = New System.Drawing.Point(845, 180)
        Me._Label1_39.Name = "_Label1_39"
        Me._Label1_39.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_39.Size = New System.Drawing.Size(128, 23)
        Me._Label1_39.TabIndex = 102
        Me._Label1_39.Text = "���������"
        Me._Label1_39.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_38
        '
        Me._Label1_38.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_38.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_38.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_38.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_38.ForeColor = System.Drawing.Color.White
        Me._Label1_38.Location = New System.Drawing.Point(714, 180)
        Me._Label1_38.Name = "_Label1_38"
        Me._Label1_38.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_38.Size = New System.Drawing.Size(128, 23)
        Me._Label1_38.TabIndex = 101
        Me._Label1_38.Text = "���S������"
        Me._Label1_38.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_37
        '
        Me._Label1_37.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_37.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_37.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_37.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_37.ForeColor = System.Drawing.Color.White
        Me._Label1_37.Location = New System.Drawing.Point(583, 180)
        Me._Label1_37.Name = "_Label1_37"
        Me._Label1_37.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_37.Size = New System.Drawing.Size(128, 23)
        Me._Label1_37.TabIndex = 100
        Me._Label1_37.Text = "���S������݌v"
        Me._Label1_37.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_36
        '
        Me._Label1_36.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_36.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_36.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_36.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_36.ForeColor = System.Drawing.Color.White
        Me._Label1_36.Location = New System.Drawing.Point(451, 180)
        Me._Label1_36.Name = "_Label1_36"
        Me._Label1_36.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_36.Size = New System.Drawing.Size(128, 23)
        Me._Label1_36.TabIndex = 99
        Me._Label1_36.Text = "��s������"
        Me._Label1_36.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_35
        '
        Me._Label1_35.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_35.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_35.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_35.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_35.ForeColor = System.Drawing.Color.White
        Me._Label1_35.Location = New System.Drawing.Point(319, 180)
        Me._Label1_35.Name = "_Label1_35"
        Me._Label1_35.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_35.Size = New System.Drawing.Size(128, 23)
        Me._Label1_35.TabIndex = 98
        Me._Label1_35.Text = "��s�����c�z"
        Me._Label1_35.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_30
        '
        Me._Label1_30.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_30.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_30.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_30.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_30.ForeColor = System.Drawing.Color.White
        Me._Label1_30.Location = New System.Drawing.Point(294, 14)
        Me._Label1_30.Name = "_Label1_30"
        Me._Label1_30.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_30.Size = New System.Drawing.Size(211, 23)
        Me._Label1_30.TabIndex = 97
        Me._Label1_30.Text = " �i���E�K�i"
        Me._Label1_30.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        '_Label1_33
        '
        Me._Label1_33.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_33.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_33.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_33.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_33.ForeColor = System.Drawing.Color.White
        Me._Label1_33.Location = New System.Drawing.Point(715, 14)
        Me._Label1_33.Name = "_Label1_33"
        Me._Label1_33.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_33.Size = New System.Drawing.Size(128, 23)
        Me._Label1_33.TabIndex = 96
        Me._Label1_33.Text = "�P�@��"
        Me._Label1_33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_34
        '
        Me._Label1_34.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_34.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_34.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_34.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_34.ForeColor = System.Drawing.Color.White
        Me._Label1_34.Location = New System.Drawing.Point(846, 14)
        Me._Label1_34.Name = "_Label1_34"
        Me._Label1_34.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_34.Size = New System.Drawing.Size(128, 23)
        Me._Label1_34.TabIndex = 95
        Me._Label1_34.Text = "���@�z"
        Me._Label1_34.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_27
        '
        Me._Label1_27.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_27.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_27.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_27.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_27.ForeColor = System.Drawing.Color.White
        Me._Label1_27.Location = New System.Drawing.Point(11, 14)
        Me._Label1_27.Name = "_Label1_27"
        Me._Label1_27.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_27.Size = New System.Drawing.Size(27, 23)
        Me._Label1_27.TabIndex = 94
        Me._Label1_27.Text = "��"
        Me._Label1_27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_28
        '
        Me._Label1_28.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_28.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_28.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_28.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_28.ForeColor = System.Drawing.Color.White
        Me._Label1_28.Location = New System.Drawing.Point(42, 14)
        Me._Label1_28.Name = "_Label1_28"
        Me._Label1_28.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_28.Size = New System.Drawing.Size(86, 23)
        Me._Label1_28.TabIndex = 93
        Me._Label1_28.Text = "�Ǝк���"
        Me._Label1_28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_29
        '
        Me._Label1_29.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_29.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_29.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_29.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_29.ForeColor = System.Drawing.Color.White
        Me._Label1_29.Location = New System.Drawing.Point(130, 14)
        Me._Label1_29.Name = "_Label1_29"
        Me._Label1_29.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_29.Size = New System.Drawing.Size(160, 23)
        Me._Label1_29.TabIndex = 92
        Me._Label1_29.Text = " �ƎЖ�"
        Me._Label1_29.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        '_Label1_32
        '
        Me._Label1_32.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_32.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_32.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_32.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_32.ForeColor = System.Drawing.Color.White
        Me._Label1_32.Location = New System.Drawing.Point(612, 14)
        Me._Label1_32.Name = "_Label1_32"
        Me._Label1_32.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_32.Size = New System.Drawing.Size(100, 23)
        Me._Label1_32.TabIndex = 91
        Me._Label1_32.Text = "�� ��"
        Me._Label1_32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_31
        '
        Me._Label1_31.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_31.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_31.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_31.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_31.ForeColor = System.Drawing.Color.White
        Me._Label1_31.Location = New System.Drawing.Point(509, 14)
        Me._Label1_31.Name = "_Label1_31"
        Me._Label1_31.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_31.Size = New System.Drawing.Size(100, 23)
        Me._Label1_31.TabIndex = 90
        Me._Label1_31.Text = "�� ��"
        Me._Label1_31.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Frame1_3
        '
        Me._Frame1_3.BackColor = System.Drawing.SystemColors.Control
        Me._Frame1_3.Controls.Add(Me._imText4_0)
        Me._Frame1_3.Controls.Add(Me._imNumber2_0)
        Me._Frame1_3.Controls.Add(Me._imText4_2)
        Me._Frame1_3.Controls.Add(Me._imText4_3)
        Me._Frame1_3.Controls.Add(Me._imNumber2_1)
        Me._Frame1_3.Controls.Add(Me._imText4_4)
        Me._Frame1_3.Controls.Add(Me._imText4_5)
        Me._Frame1_3.Controls.Add(Me._imText4_6)
        Me._Frame1_3.Controls.Add(Me._imNumber2_3)
        Me._Frame1_3.Controls.Add(Me._imText4_7)
        Me._Frame1_3.Controls.Add(Me._imNumber2_4)
        Me._Frame1_3.Controls.Add(Me._imNumber2_2)
        Me._Frame1_3.Controls.Add(Me._imNumber2_7)
        Me._Frame1_3.Controls.Add(Me._imNumber2_8)
        Me._Frame1_3.Controls.Add(Me._Label1_46)
        Me._Frame1_3.Controls.Add(Me._Label1_45)
        Me._Frame1_3.Controls.Add(Me._Label1_3)
        Me._Frame1_3.Controls.Add(Me._Label1_25)
        Me._Frame1_3.Controls.Add(Me._Label1_26)
        Me._Frame1_3.Controls.Add(Me._Label1_24)
        Me._Frame1_3.Controls.Add(Me._Label1_23)
        Me._Frame1_3.Controls.Add(Me._Label1_21)
        Me._Frame1_3.Controls.Add(Me._Label1_22)
        Me._Frame1_3.Controls.Add(Me.Label2)
        Me._Frame1_3.Controls.Add(Me._Label1_20)
        Me._Frame1_3.Controls.Add(Me._Label1_19)
        Me._Frame1_3.Controls.Add(Me._Label1_18)
        Me._Frame1_3.Controls.Add(Me._Label1_17)
        Me._Frame1_3.Controls.Add(Me._Label1_16)
        Me._Frame1_3.Controls.Add(Me._Label1_15)
        Me._Frame1_3.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Frame1_3.Location = New System.Drawing.Point(4, 276)
        Me._Frame1_3.Name = "_Frame1_3"
        Me._Frame1_3.Padding = New System.Windows.Forms.Padding(0)
        Me._Frame1_3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Frame1_3.Size = New System.Drawing.Size(1005, 147)
        Me._Frame1_3.TabIndex = 75
        Me._Frame1_3.TabStop = False
        '
        '_imText4_0
        '
        Me._imText4_0.BackColor = System.Drawing.SystemColors.Control
        Me._imText4_0.ContentAlignment = System.Drawing.ContentAlignment.MiddleRight
        Me._imText4_0.DisabledForeColor = System.Drawing.SystemColors.MenuText
        Me._imText4_0.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Bold)
        Me._imText4_0.Location = New System.Drawing.Point(16, 106)
        Me._imText4_0.Name = "_imText4_0"
        Me._imText4_0.ReadOnly = True
        Me._imText4_0.Size = New System.Drawing.Size(128, 23)
        Me._imText4_0.TabIndex = 9
        Me._imText4_0.TabStop = False
        '
        '_imNumber2_0
        '
        Me._imNumber2_0.DisabledBackColor = System.Drawing.SystemColors.Window
        Me._imNumber2_0.DisabledForeColor = System.Drawing.SystemColors.MenuText
        NumberIntegerPartDisplayField3.GroupSizes = New Integer() {3, 3, 3, 0}
        Me._imNumber2_0.DisplayFields.AddRange(New GrapeCity.Win.Editors.Fields.NumberDisplayField() {NumberIntegerPartDisplayField3})
        Me._imNumber2_0.Fields.DecimalPart.MaxDigits = 0
        Me._imNumber2_0.Fields.IntegerPart.GroupSizes = New Integer() {3, 3, 3, 0}
        Me._imNumber2_0.Fields.IntegerPart.MaxDigits = 10
        Me._imNumber2_0.Fields.IntegerPart.MinDigits = 1
        Me._imNumber2_0.Fields.SignPrefix.NegativePattern = ""
        Me._imNumber2_0.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Bold)
        Me._imNumber2_0.HighlightText = True
        Me._imNumber2_0.ImeMode = System.Windows.Forms.ImeMode.Disable
        Me._imNumber2_0.Location = New System.Drawing.Point(16, 48)
        Me._imNumber2_0.MaxValue = New Decimal(New Integer() {1410065407, 2, 0, 0})
        Me._imNumber2_0.MinValue = New Decimal(New Integer() {0, 0, 0, 0})
        Me._imNumber2_0.Name = "_imNumber2_0"
        Me._imNumber2_0.Size = New System.Drawing.Size(128, 23)
        Me._imNumber2_0.TabIndex = 8
        Me._imNumber2_0.Tag = "�_����z����͂��ĉ������B"
        Me._imNumber2_0.Value = New Decimal(New Integer() {1410065407, 2, 0, 0})
        '
        '_imText4_2
        '
        Me._imText4_2.BackColor = System.Drawing.SystemColors.Control
        Me._imText4_2.ContentAlignment = System.Drawing.ContentAlignment.MiddleRight
        Me._imText4_2.DisabledForeColor = System.Drawing.SystemColors.MenuText
        Me._imText4_2.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Bold)
        Me._imText4_2.ImeMode = System.Windows.Forms.ImeMode.Off
        Me._imText4_2.Location = New System.Drawing.Point(160, 106)
        Me._imText4_2.Name = "_imText4_2"
        Me._imText4_2.ReadOnly = True
        Me._imText4_2.Size = New System.Drawing.Size(128, 23)
        Me._imText4_2.TabIndex = 11
        Me._imText4_2.TabStop = False
        Me._imText4_2.Text = "9,999,999,999"
        '
        '_imText4_3
        '
        Me._imText4_3.BackColor = System.Drawing.SystemColors.Control
        Me._imText4_3.ContentAlignment = System.Drawing.ContentAlignment.MiddleRight
        Me._imText4_3.DisabledForeColor = System.Drawing.SystemColors.MenuText
        Me._imText4_3.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Bold)
        Me._imText4_3.ImeMode = System.Windows.Forms.ImeMode.Off
        Me._imText4_3.Location = New System.Drawing.Point(306, 48)
        Me._imText4_3.Name = "_imText4_3"
        Me._imText4_3.ReadOnly = True
        Me._imText4_3.Size = New System.Drawing.Size(128, 23)
        Me._imText4_3.TabIndex = 12
        Me._imText4_3.TabStop = False
        Me._imText4_3.Text = "9,999,999,999"
        '
        '_imNumber2_1
        '
        Me._imNumber2_1.DisabledBackColor = System.Drawing.SystemColors.Window
        Me._imNumber2_1.DisabledForeColor = System.Drawing.SystemColors.MenuText
        NumberIntegerPartDisplayField4.GroupSizes = New Integer() {0}
        Me._imNumber2_1.DisplayFields.AddRange(New GrapeCity.Win.Editors.Fields.NumberDisplayField() {NumberIntegerPartDisplayField4})
        Me._imNumber2_1.Fields.DecimalPart.MaxDigits = 0
        Me._imNumber2_1.Fields.IntegerPart.GroupSizes = New Integer() {0}
        Me._imNumber2_1.Fields.IntegerPart.MaxDigits = 3
        Me._imNumber2_1.Fields.IntegerPart.MinDigits = 1
        Me._imNumber2_1.Fields.SignPrefix.NegativePattern = ""
        Me._imNumber2_1.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Bold)
        Me._imNumber2_1.HighlightText = True
        Me._imNumber2_1.ImeMode = System.Windows.Forms.ImeMode.Disable
        Me._imNumber2_1.Location = New System.Drawing.Point(306, 106)
        Me._imNumber2_1.MaxValue = New Decimal(New Integer() {100, 0, 0, 0})
        Me._imNumber2_1.MinValue = New Decimal(New Integer() {0, 0, 0, 0})
        Me._imNumber2_1.Name = "_imNumber2_1"
        Me._imNumber2_1.Size = New System.Drawing.Size(40, 23)
        Me._imNumber2_1.TabIndex = 13
        Me._imNumber2_1.Tag = "����������͂��ĉ������B"
        Me._imNumber2_1.Value = Nothing
        '
        '_imText4_4
        '
        Me._imText4_4.BackColor = System.Drawing.SystemColors.Control
        Me._imText4_4.ContentAlignment = System.Drawing.ContentAlignment.MiddleRight
        Me._imText4_4.DisabledForeColor = System.Drawing.SystemColors.MenuText
        Me._imText4_4.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Bold)
        Me._imText4_4.ImeMode = System.Windows.Forms.ImeMode.Off
        Me._imText4_4.Location = New System.Drawing.Point(374, 106)
        Me._imText4_4.Name = "_imText4_4"
        Me._imText4_4.ReadOnly = True
        Me._imText4_4.Size = New System.Drawing.Size(128, 23)
        Me._imText4_4.TabIndex = 14
        Me._imText4_4.TabStop = False
        Me._imText4_4.Text = "9,999,999,999"
        '
        '_imText4_5
        '
        Me._imText4_5.BackColor = System.Drawing.SystemColors.Control
        Me._imText4_5.ContentAlignment = System.Drawing.ContentAlignment.MiddleRight
        Me._imText4_5.DisabledForeColor = System.Drawing.SystemColors.MenuText
        Me._imText4_5.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Bold)
        Me._imText4_5.Location = New System.Drawing.Point(518, 48)
        Me._imText4_5.Name = "_imText4_5"
        Me._imText4_5.ReadOnly = True
        Me._imText4_5.Size = New System.Drawing.Size(128, 23)
        Me._imText4_5.TabIndex = 15
        Me._imText4_5.TabStop = False
        '
        '_imText4_6
        '
        Me._imText4_6.BackColor = System.Drawing.SystemColors.Control
        Me._imText4_6.ContentAlignment = System.Drawing.ContentAlignment.MiddleRight
        Me._imText4_6.DisabledForeColor = System.Drawing.SystemColors.MenuText
        Me._imText4_6.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Bold)
        Me._imText4_6.ImeMode = System.Windows.Forms.ImeMode.Off
        Me._imText4_6.Location = New System.Drawing.Point(660, 48)
        Me._imText4_6.Name = "_imText4_6"
        Me._imText4_6.ReadOnly = True
        Me._imText4_6.Size = New System.Drawing.Size(128, 23)
        Me._imText4_6.TabIndex = 17
        Me._imText4_6.TabStop = False
        Me._imText4_6.Text = "9,999,999,999"
        '
        '_imNumber2_3
        '
        Me._imNumber2_3.AlternateText.DisplayNull.ForeColor = System.Drawing.SystemColors.WindowText
        Me._imNumber2_3.AlternateText.DisplayZero.ForeColor = System.Drawing.SystemColors.WindowText
        Me._imNumber2_3.AlternateText.Zero.ForeColor = System.Drawing.SystemColors.WindowText
        Me._imNumber2_3.AlternateText.Zero.Text = "0"
        Me._imNumber2_3.DisabledBackColor = System.Drawing.SystemColors.Window
        Me._imNumber2_3.DisabledForeColor = System.Drawing.SystemColors.MenuText
        NumberIntegerPartDisplayField5.GroupSizes = New Integer() {3, 3, 3, 0}
        Me._imNumber2_3.DisplayFields.AddRange(New GrapeCity.Win.Editors.Fields.NumberDisplayField() {NumberIntegerPartDisplayField5})
        Me._imNumber2_3.Fields.DecimalPart.MaxDigits = 0
        Me._imNumber2_3.Fields.IntegerPart.GroupSizes = New Integer() {3, 3, 3, 0}
        Me._imNumber2_3.Fields.IntegerPart.MaxDigits = 10
        Me._imNumber2_3.Fields.IntegerPart.MinDigits = 1
        Me._imNumber2_3.Fields.SignPrefix.NegativePattern = ""
        Me._imNumber2_3.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Bold)
        Me._imNumber2_3.HighlightText = True
        Me._imNumber2_3.ImeMode = System.Windows.Forms.ImeMode.Disable
        Me._imNumber2_3.Location = New System.Drawing.Point(660, 106)
        Me._imNumber2_3.MaxValue = New Decimal(New Integer() {1410065407, 2, 0, 0})
        Me._imNumber2_3.MinValue = New Decimal(New Integer() {0, 0, 0, -2147483648})
        Me._imNumber2_3.Name = "_imNumber2_3"
        Me._imNumber2_3.Size = New System.Drawing.Size(128, 23)
        Me._imNumber2_3.TabIndex = 18
        Me._imNumber2_3.Tag = "����x���z����͂��ĉ������B"
        '
        '_imText4_7
        '
        Me._imText4_7.BackColor = System.Drawing.SystemColors.Control
        Me._imText4_7.ContentAlignment = System.Drawing.ContentAlignment.MiddleRight
        Me._imText4_7.DisabledForeColor = System.Drawing.SystemColors.MenuText
        Me._imText4_7.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Bold)
        Me._imText4_7.ImeMode = System.Windows.Forms.ImeMode.Off
        Me._imText4_7.Location = New System.Drawing.Point(860, 106)
        Me._imText4_7.Name = "_imText4_7"
        Me._imText4_7.ReadOnly = True
        Me._imText4_7.Size = New System.Drawing.Size(128, 23)
        Me._imText4_7.TabIndex = 21
        Me._imText4_7.TabStop = False
        Me._imText4_7.Text = "9,999,999,999"
        '
        '_imNumber2_4
        '
        Me._imNumber2_4.AlternateText.DisplayNull.ForeColor = System.Drawing.SystemColors.WindowText
        Me._imNumber2_4.AlternateText.DisplayZero.ForeColor = System.Drawing.SystemColors.WindowText
        Me._imNumber2_4.AlternateText.Zero.ForeColor = System.Drawing.SystemColors.WindowText
        Me._imNumber2_4.BackColor = System.Drawing.SystemColors.Control
        Me._imNumber2_4.DisabledForeColor = System.Drawing.SystemColors.MenuText
        Me._imNumber2_4.Fields.DecimalPart.MaxDigits = 0
        Me._imNumber2_4.Fields.IntegerPart.GroupSizes = New Integer() {3, 3, 3, 0}
        Me._imNumber2_4.Fields.IntegerPart.MaxDigits = 11
        Me._imNumber2_4.Fields.IntegerPart.MinDigits = 1
        Me._imNumber2_4.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Bold)
        Me._imNumber2_4.Location = New System.Drawing.Point(860, 48)
        Me._imNumber2_4.MaxValue = New Decimal(New Integer() {1410065407, 2, 0, 0})
        Me._imNumber2_4.MinValue = New Decimal(New Integer() {0, 0, 0, 0})
        Me._imNumber2_4.Name = "_imNumber2_4"
        Me._imNumber2_4.ReadOnly = True
        Me._imNumber2_4.Size = New System.Drawing.Size(128, 23)
        Me._imNumber2_4.TabIndex = 20
        Me._imNumber2_4.TabStop = False
        '
        '_imNumber2_2
        '
        Me._imNumber2_2.AlternateText.DisplayNull.ForeColor = System.Drawing.SystemColors.WindowText
        Me._imNumber2_2.AlternateText.DisplayNull.Text = "0"
        Me._imNumber2_2.AlternateText.DisplayZero.ForeColor = System.Drawing.SystemColors.WindowText
        Me._imNumber2_2.AlternateText.DisplayZero.Text = "0"
        Me._imNumber2_2.AlternateText.Zero.ForeColor = System.Drawing.SystemColors.WindowText
        Me._imNumber2_2.BackColor = System.Drawing.SystemColors.Control
        Me._imNumber2_2.DisabledForeColor = System.Drawing.SystemColors.MenuText
        NumberIntegerPartDisplayField6.GroupSizes = New Integer() {3, 3, 3, 0}
        Me._imNumber2_2.DisplayFields.AddRange(New GrapeCity.Win.Editors.Fields.NumberDisplayField() {NumberIntegerPartDisplayField6})
        Me._imNumber2_2.Fields.DecimalPart.MaxDigits = 0
        Me._imNumber2_2.Fields.IntegerPart.GroupSizes = New Integer() {3, 3, 3, 0}
        Me._imNumber2_2.Fields.IntegerPart.MaxDigits = 10
        Me._imNumber2_2.Fields.IntegerPart.MinDigits = 1
        Me._imNumber2_2.Fields.SignPrefix.NegativePattern = ""
        Me._imNumber2_2.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Bold)
        Me._imNumber2_2.Location = New System.Drawing.Point(518, 106)
        Me._imNumber2_2.MaxValue = New Decimal(New Integer() {1410065407, 2, 0, 0})
        Me._imNumber2_2.MinValue = New Decimal(New Integer() {0, 0, 0, 0})
        Me._imNumber2_2.Name = "_imNumber2_2"
        Me._imNumber2_2.ReadOnly = True
        Me._imNumber2_2.Size = New System.Drawing.Size(128, 23)
        Me._imNumber2_2.TabIndex = 16
        Me._imNumber2_2.TabStop = False
        Me._imNumber2_2.Value = Nothing
        '
        '_imNumber2_7
        '
        Me._imNumber2_7.BackColor = System.Drawing.SystemColors.Control
        Me._imNumber2_7.DisabledForeColor = System.Drawing.SystemColors.MenuText
        NumberIntegerPartDisplayField7.GroupSizes = New Integer() {3, 3, 3, 0}
        Me._imNumber2_7.DisplayFields.AddRange(New GrapeCity.Win.Editors.Fields.NumberDisplayField() {NumberIntegerPartDisplayField7})
        Me._imNumber2_7.Fields.DecimalPart.MaxDigits = 0
        Me._imNumber2_7.Fields.IntegerPart.GroupSizes = New Integer() {3, 3, 3, 0}
        Me._imNumber2_7.Fields.IntegerPart.MaxDigits = 10
        Me._imNumber2_7.Fields.IntegerPart.MinDigits = 1
        Me._imNumber2_7.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Bold)
        Me._imNumber2_7.Location = New System.Drawing.Point(160, 48)
        Me._imNumber2_7.MaxValue = New Decimal(New Integer() {1410065407, 2, 0, 0})
        Me._imNumber2_7.MinValue = New Decimal(New Integer() {1410065407, 2, 0, -2147483648})
        Me._imNumber2_7.Name = "_imNumber2_7"
        Me._imNumber2_7.ReadOnly = True
        Me._imNumber2_7.Size = New System.Drawing.Size(128, 23)
        Me._imNumber2_7.TabIndex = 10
        Me._imNumber2_7.TabStop = False
        Me._imNumber2_7.Value = New Decimal(New Integer() {1410065407, 2, 0, 0})
        '
        '_imNumber2_8
        '
        Me._imNumber2_8.DisabledBackColor = System.Drawing.SystemColors.Window
        Me._imNumber2_8.DisabledForeColor = System.Drawing.SystemColors.MenuText
        NumberIntegerPartDisplayField8.GroupSizes = New Integer() {0}
        Me._imNumber2_8.DisplayFields.AddRange(New GrapeCity.Win.Editors.Fields.NumberDisplayField() {NumberIntegerPartDisplayField8})
        Me._imNumber2_8.Fields.DecimalPart.MaxDigits = 0
        Me._imNumber2_8.Fields.IntegerPart.GroupSizes = New Integer() {0}
        Me._imNumber2_8.Fields.IntegerPart.MaxDigits = 2
        Me._imNumber2_8.Fields.IntegerPart.MinDigits = 1
        Me._imNumber2_8.Fields.SignPrefix.NegativePattern = ""
        Me._imNumber2_8.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Bold)
        Me._imNumber2_8.HighlightText = True
        Me._imNumber2_8.ImeMode = System.Windows.Forms.ImeMode.Disable
        Me._imNumber2_8.Location = New System.Drawing.Point(798, 106)
        Me._imNumber2_8.MaxValue = New Decimal(New Integer() {100, 0, 0, 0})
        Me._imNumber2_8.MinValue = New Decimal(New Integer() {0, 0, 0, 0})
        Me._imNumber2_8.Name = "_imNumber2_8"
        Me._imNumber2_8.Size = New System.Drawing.Size(30, 23)
        Me._imNumber2_8.TabIndex = 19
        Me._imNumber2_8.Tag = "����������͂��ĉ������B"
        '
        '_Label1_46
        '
        Me._Label1_46.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_46.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_46.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_46.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_46.ForeColor = System.Drawing.Color.White
        Me._Label1_46.Location = New System.Drawing.Point(798, 82)
        Me._Label1_46.Name = "_Label1_46"
        Me._Label1_46.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_46.Size = New System.Drawing.Size(52, 23)
        Me._Label1_46.TabIndex = 113
        Me._Label1_46.Text = "�ŗ�"
        Me._Label1_46.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_45
        '
        Me._Label1_45.AutoSize = True
        Me._Label1_45.BackColor = System.Drawing.Color.Transparent
        Me._Label1_45.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_45.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_45.ForeColor = System.Drawing.Color.Black
        Me._Label1_45.Location = New System.Drawing.Point(829, 109)
        Me._Label1_45.Name = "_Label1_45"
        Me._Label1_45.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_45.Size = New System.Drawing.Size(25, 16)
        Me._Label1_45.TabIndex = 112
        Me._Label1_45.Text = "��"
        Me._Label1_45.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        '_Label1_3
        '
        Me._Label1_3.AutoSize = True
        Me._Label1_3.BackColor = System.Drawing.Color.Transparent
        Me._Label1_3.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_3.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_3.ForeColor = System.Drawing.Color.Black
        Me._Label1_3.Location = New System.Drawing.Point(350, 110)
        Me._Label1_3.Name = "_Label1_3"
        Me._Label1_3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_3.Size = New System.Drawing.Size(25, 16)
        Me._Label1_3.TabIndex = 103
        Me._Label1_3.Text = "��"
        Me._Label1_3.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        '_Label1_25
        '
        Me._Label1_25.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_25.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_25.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_25.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_25.ForeColor = System.Drawing.Color.White
        Me._Label1_25.Location = New System.Drawing.Point(860, 24)
        Me._Label1_25.Name = "_Label1_25"
        Me._Label1_25.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_25.Size = New System.Drawing.Size(128, 23)
        Me._Label1_25.TabIndex = 88
        Me._Label1_25.Text = "���񐿋��z"
        Me._Label1_25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_26
        '
        Me._Label1_26.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_26.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_26.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_26.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_26.ForeColor = System.Drawing.Color.White
        Me._Label1_26.Location = New System.Drawing.Point(860, 82)
        Me._Label1_26.Name = "_Label1_26"
        Me._Label1_26.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_26.Size = New System.Drawing.Size(128, 23)
        Me._Label1_26.TabIndex = 87
        Me._Label1_26.Text = "�x���c�z"
        Me._Label1_26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_24
        '
        Me._Label1_24.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_24.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_24.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_24.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_24.ForeColor = System.Drawing.Color.White
        Me._Label1_24.Location = New System.Drawing.Point(660, 82)
        Me._Label1_24.Name = "_Label1_24"
        Me._Label1_24.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_24.Size = New System.Drawing.Size(128, 23)
        Me._Label1_24.TabIndex = 86
        Me._Label1_24.Text = "����x���z"
        Me._Label1_24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_23
        '
        Me._Label1_23.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_23.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_23.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_23.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_23.ForeColor = System.Drawing.Color.White
        Me._Label1_23.Location = New System.Drawing.Point(660, 24)
        Me._Label1_23.Name = "_Label1_23"
        Me._Label1_23.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_23.Size = New System.Drawing.Size(128, 23)
        Me._Label1_23.TabIndex = 85
        Me._Label1_23.Text = "�x���\�z"
        Me._Label1_23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_21
        '
        Me._Label1_21.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_21.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_21.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_21.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_21.ForeColor = System.Drawing.Color.White
        Me._Label1_21.Location = New System.Drawing.Point(518, 24)
        Me._Label1_21.Name = "_Label1_21"
        Me._Label1_21.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_21.Size = New System.Drawing.Size(128, 23)
        Me._Label1_21.TabIndex = 84
        Me._Label1_21.Text = "�O�񖘎x���z"
        Me._Label1_21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_22
        '
        Me._Label1_22.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_22.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_22.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_22.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_22.ForeColor = System.Drawing.Color.White
        Me._Label1_22.Location = New System.Drawing.Point(518, 82)
        Me._Label1_22.Name = "_Label1_22"
        Me._Label1_22.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_22.Size = New System.Drawing.Size(128, 23)
        Me._Label1_22.TabIndex = 83
        Me._Label1_22.Text = "�x�������z"
        Me._Label1_22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label2.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label2.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(374, 82)
        Me.Label2.Name = "Label2"
        Me.Label2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label2.Size = New System.Drawing.Size(128, 23)
        Me.Label2.TabIndex = 82
        Me.Label2.Text = "�����v100��"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_20
        '
        Me._Label1_20.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_20.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_20.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_20.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_20.ForeColor = System.Drawing.Color.White
        Me._Label1_20.Location = New System.Drawing.Point(306, 82)
        Me._Label1_20.Name = "_Label1_20"
        Me._Label1_20.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_20.Size = New System.Drawing.Size(66, 23)
        Me._Label1_20.TabIndex = 81
        Me._Label1_20.Text = "��"
        Me._Label1_20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_19
        '
        Me._Label1_19.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_19.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_19.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_19.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_19.ForeColor = System.Drawing.Color.White
        Me._Label1_19.Location = New System.Drawing.Point(306, 24)
        Me._Label1_19.Name = "_Label1_19"
        Me._Label1_19.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_19.Size = New System.Drawing.Size(128, 23)
        Me._Label1_19.TabIndex = 80
        Me._Label1_19.Text = "�� �� �v"
        Me._Label1_19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_18
        '
        Me._Label1_18.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_18.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_18.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_18.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_18.ForeColor = System.Drawing.Color.White
        Me._Label1_18.Location = New System.Drawing.Point(160, 82)
        Me._Label1_18.Name = "_Label1_18"
        Me._Label1_18.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_18.Size = New System.Drawing.Size(128, 23)
        Me._Label1_18.TabIndex = 79
        Me._Label1_18.Text = "���������"
        Me._Label1_18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_17
        '
        Me._Label1_17.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_17.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_17.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_17.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_17.ForeColor = System.Drawing.Color.White
        Me._Label1_17.Location = New System.Drawing.Point(160, 24)
        Me._Label1_17.Name = "_Label1_17"
        Me._Label1_17.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_17.Size = New System.Drawing.Size(128, 23)
        Me._Label1_17.TabIndex = 78
        Me._Label1_17.Text = "�O�񖘈�����"
        Me._Label1_17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_16
        '
        Me._Label1_16.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_16.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_16.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_16.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_16.ForeColor = System.Drawing.Color.White
        Me._Label1_16.Location = New System.Drawing.Point(16, 82)
        Me._Label1_16.Name = "_Label1_16"
        Me._Label1_16.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_16.Size = New System.Drawing.Size(128, 23)
        Me._Label1_16.TabIndex = 77
        Me._Label1_16.Text = "���o����"
        Me._Label1_16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_15
        '
        Me._Label1_15.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_15.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_15.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_15.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_15.ForeColor = System.Drawing.Color.White
        Me._Label1_15.Location = New System.Drawing.Point(16, 24)
        Me._Label1_15.Name = "_Label1_15"
        Me._Label1_15.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_15.Size = New System.Drawing.Size(128, 23)
        Me._Label1_15.TabIndex = 76
        Me._Label1_15.Text = "�_����z"
        Me._Label1_15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Frame1_2
        '
        Me._Frame1_2.BackColor = System.Drawing.SystemColors.Control
        Me._Frame1_2.Controls.Add(Me.VScroll1)
        Me._Frame1_2.Controls.Add(Me._ctlMeisai1_0)
        Me._Frame1_2.Controls.Add(Me._imText3_0)
        Me._Frame1_2.Controls.Add(Me._ctlMeisai1_1)
        Me._Frame1_2.Controls.Add(Me._ctlMeisai1_2)
        Me._Frame1_2.Controls.Add(Me._imText3_1)
        Me._Frame1_2.Controls.Add(Me._imText3_2)
        Me._Frame1_2.Controls.Add(Me._imText3_3)
        Me._Frame1_2.Controls.Add(Me._Label1_10)
        Me._Frame1_2.Controls.Add(Me._Label1_11)
        Me._Frame1_2.Controls.Add(Me._Label1_14)
        Me._Frame1_2.Controls.Add(Me._Label1_9)
        Me._Frame1_2.Controls.Add(Me._Label1_8)
        Me._Frame1_2.Controls.Add(Me._Label1_7)
        Me._Frame1_2.Controls.Add(Me._Label1_13)
        Me._Frame1_2.Controls.Add(Me._Label1_12)
        Me._Frame1_2.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Frame1_2.Location = New System.Drawing.Point(4, 106)
        Me._Frame1_2.Name = "_Frame1_2"
        Me._Frame1_2.Padding = New System.Windows.Forms.Padding(0)
        Me._Frame1_2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Frame1_2.Size = New System.Drawing.Size(1005, 169)
        Me._Frame1_2.TabIndex = 65
        Me._Frame1_2.TabStop = False
        '
        'VScroll1
        '
        Me.VScroll1.Cursor = System.Windows.Forms.Cursors.Default
        Me.VScroll1.LargeChange = 3
        Me.VScroll1.Location = New System.Drawing.Point(875, 40)
        Me.VScroll1.Maximum = 32769
        Me.VScroll1.Name = "VScroll1"
        Me.VScroll1.Size = New System.Drawing.Size(17, 97)
        Me.VScroll1.TabIndex = 100
        Me.VScroll1.TabStop = True
        '
        '_imText3_0
        '
        Me._imText3_0.AlternateText.DisplayNull.ForeColor = System.Drawing.SystemColors.WindowText
        Me._imText3_0.AlternateText.DisplayNull.Text = "0"
        Me._imText3_0.BackColor = System.Drawing.SystemColors.Control
        Me._imText3_0.ContentAlignment = System.Drawing.ContentAlignment.MiddleRight
        Me._imText3_0.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._imText3_0.Location = New System.Drawing.Point(347, 138)
        Me._imText3_0.Name = "_imText3_0"
        Me._imText3_0.ReadOnly = True
        Me._imText3_0.Size = New System.Drawing.Size(128, 23)
        Me._imText3_0.TabIndex = 4
        Me._imText3_0.TabStop = False
        '
        '_imText3_1
        '
        Me._imText3_1.BackColor = System.Drawing.SystemColors.Control
        Me._imText3_1.ContentAlignment = System.Drawing.ContentAlignment.MiddleRight
        Me._imText3_1.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._imText3_1.Location = New System.Drawing.Point(478, 138)
        Me._imText3_1.Name = "_imText3_1"
        Me._imText3_1.ReadOnly = True
        Me._imText3_1.Size = New System.Drawing.Size(128, 23)
        Me._imText3_1.TabIndex = 5
        Me._imText3_1.TabStop = False
        '
        '_imText3_2
        '
        Me._imText3_2.BackColor = System.Drawing.SystemColors.Control
        Me._imText3_2.ContentAlignment = System.Drawing.ContentAlignment.MiddleRight
        Me._imText3_2.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._imText3_2.Location = New System.Drawing.Point(609, 138)
        Me._imText3_2.Name = "_imText3_2"
        Me._imText3_2.ReadOnly = True
        Me._imText3_2.Size = New System.Drawing.Size(128, 23)
        Me._imText3_2.TabIndex = 6
        Me._imText3_2.TabStop = False
        '
        '_imText3_3
        '
        Me._imText3_3.AlternateText.DisplayNull.ForeColor = System.Drawing.SystemColors.WindowText
        Me._imText3_3.AlternateText.DisplayNull.Text = "0"
        Me._imText3_3.BackColor = System.Drawing.SystemColors.Control
        Me._imText3_3.ContentAlignment = System.Drawing.ContentAlignment.MiddleRight
        Me._imText3_3.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._imText3_3.Location = New System.Drawing.Point(740, 138)
        Me._imText3_3.Name = "_imText3_3"
        Me._imText3_3.ReadOnly = True
        Me._imText3_3.Size = New System.Drawing.Size(128, 23)
        Me._imText3_3.TabIndex = 7
        Me._imText3_3.TabStop = False
        '
        '_Label1_10
        '
        Me._Label1_10.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_10.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_10.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_10.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_10.ForeColor = System.Drawing.Color.White
        Me._Label1_10.Location = New System.Drawing.Point(347, 14)
        Me._Label1_10.Name = "_Label1_10"
        Me._Label1_10.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_10.Size = New System.Drawing.Size(128, 23)
        Me._Label1_10.TabIndex = 74
        Me._Label1_10.Text = "�_�񌈒�z"
        Me._Label1_10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_11
        '
        Me._Label1_11.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_11.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_11.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_11.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_11.ForeColor = System.Drawing.Color.White
        Me._Label1_11.Location = New System.Drawing.Point(478, 14)
        Me._Label1_11.Name = "_Label1_11"
        Me._Label1_11.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_11.Size = New System.Drawing.Size(128, 23)
        Me._Label1_11.TabIndex = 73
        Me._Label1_11.Text = "����o����"
        Me._Label1_11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_14
        '
        Me._Label1_14.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_14.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_14.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_14.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_14.ForeColor = System.Drawing.Color.White
        Me._Label1_14.Location = New System.Drawing.Point(215, 138)
        Me._Label1_14.Name = "_Label1_14"
        Me._Label1_14.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_14.Size = New System.Drawing.Size(128, 23)
        Me._Label1_14.TabIndex = 72
        Me._Label1_14.Text = "���@�v"
        Me._Label1_14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_9
        '
        Me._Label1_9.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_9.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_9.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_9.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_9.ForeColor = System.Drawing.Color.White
        Me._Label1_9.Location = New System.Drawing.Point(94, 14)
        Me._Label1_9.Name = "_Label1_9"
        Me._Label1_9.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_9.Size = New System.Drawing.Size(250, 23)
        Me._Label1_9.TabIndex = 71
        Me._Label1_9.Text = " �H�햼"
        '
        '_Label1_8
        '
        Me._Label1_8.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_8.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_8.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_8.ForeColor = System.Drawing.Color.White
        Me._Label1_8.Location = New System.Drawing.Point(42, 14)
        Me._Label1_8.Name = "_Label1_8"
        Me._Label1_8.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_8.Size = New System.Drawing.Size(50, 23)
        Me._Label1_8.TabIndex = 70
        Me._Label1_8.Text = "�H��"
        Me._Label1_8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_7
        '
        Me._Label1_7.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_7.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_7.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_7.ForeColor = System.Drawing.Color.White
        Me._Label1_7.Location = New System.Drawing.Point(11, 14)
        Me._Label1_7.Name = "_Label1_7"
        Me._Label1_7.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_7.Size = New System.Drawing.Size(27, 23)
        Me._Label1_7.TabIndex = 69
        Me._Label1_7.Text = "��"
        Me._Label1_7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_13
        '
        Me._Label1_13.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_13.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_13.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_13.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_13.ForeColor = System.Drawing.Color.White
        Me._Label1_13.Location = New System.Drawing.Point(740, 14)
        Me._Label1_13.Name = "_Label1_13"
        Me._Label1_13.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_13.Size = New System.Drawing.Size(128, 23)
        Me._Label1_13.TabIndex = 68
        Me._Label1_13.Text = "����x���z"
        Me._Label1_13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_12
        '
        Me._Label1_12.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_12.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_12.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_12.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_12.ForeColor = System.Drawing.Color.White
        Me._Label1_12.Location = New System.Drawing.Point(609, 14)
        Me._Label1_12.Name = "_Label1_12"
        Me._Label1_12.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_12.Size = New System.Drawing.Size(128, 23)
        Me._Label1_12.TabIndex = 67
        Me._Label1_12.Text = "�o�����݌v"
        Me._Label1_12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Frame1_1
        '
        Me._Frame1_1.BackColor = System.Drawing.SystemColors.Control
        Me._Frame1_1.Controls.Add(Me._imNumber1_0)
        Me._Frame1_1.Controls.Add(Me._imNumber1_1)
        Me._Frame1_1.Controls.Add(Me._imNumber1_2)
        Me._Frame1_1.Controls.Add(Me._Label1_42)
        Me._Frame1_1.Controls.Add(Me._Label1_41)
        Me._Frame1_1.Controls.Add(Me._Label1_40)
        Me._Frame1_1.Controls.Add(Me._Label1_6)
        Me._Frame1_1.Controls.Add(Me._Label1_5)
        Me._Frame1_1.Controls.Add(Me._Label1_4)
        Me._Frame1_1.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Frame1_1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me._Frame1_1.Location = New System.Drawing.Point(572, 46)
        Me._Frame1_1.Name = "_Frame1_1"
        Me._Frame1_1.Padding = New System.Windows.Forms.Padding(0)
        Me._Frame1_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Frame1_1.Size = New System.Drawing.Size(437, 59)
        Me._Frame1_1.TabIndex = 102
        Me._Frame1_1.TabStop = False
        Me._Frame1_1.Text = "�x���䗦"
        '
        '_imNumber1_0
        '
        Me._imNumber1_0.AlternateText.Zero.ForeColor = System.Drawing.SystemColors.WindowText
        Me._imNumber1_0.DisabledBackColor = System.Drawing.SystemColors.Window
        Me._imNumber1_0.DisabledForeColor = System.Drawing.SystemColors.MenuText
        NumberIntegerPartDisplayField9.GroupSizes = New Integer() {0}
        Me._imNumber1_0.DisplayFields.AddRange(New GrapeCity.Win.Editors.Fields.NumberDisplayField() {NumberIntegerPartDisplayField9})
        Me._imNumber1_0.Fields.DecimalPart.MaxDigits = 0
        Me._imNumber1_0.Fields.IntegerPart.GroupSizes = New Integer() {0}
        Me._imNumber1_0.Fields.IntegerPart.MaxDigits = 3
        Me._imNumber1_0.Fields.IntegerPart.MinDigits = 1
        Me._imNumber1_0.Fields.SignPrefix.NegativePattern = ""
        Me._imNumber1_0.HighlightText = True
        Me._imNumber1_0.ImeMode = System.Windows.Forms.ImeMode.Disable
        Me._imNumber1_0.Location = New System.Drawing.Point(86, 22)
        Me._imNumber1_0.MaxValue = New Decimal(New Integer() {100, 0, 0, 0})
        Me._imNumber1_0.MinValue = New Decimal(New Integer() {0, 0, 0, 0})
        Me._imNumber1_0.Name = "_imNumber1_0"
        Me._imNumber1_0.Size = New System.Drawing.Size(39, 23)
        Me._imNumber1_0.TabIndex = 49
        Me._imNumber1_0.Tag = "�U���x���䗦����͂��ĉ������B"
        Me._imNumber1_0.Value = Nothing
        '
        '_imNumber1_1
        '
        Me._imNumber1_1.AlternateText.Zero.ForeColor = System.Drawing.SystemColors.WindowText
        Me._imNumber1_1.DisabledBackColor = System.Drawing.SystemColors.Window
        Me._imNumber1_1.DisabledForeColor = System.Drawing.SystemColors.MenuText
        NumberIntegerPartDisplayField10.GroupSizes = New Integer() {0}
        Me._imNumber1_1.DisplayFields.AddRange(New GrapeCity.Win.Editors.Fields.NumberDisplayField() {NumberIntegerPartDisplayField10})
        Me._imNumber1_1.Fields.DecimalPart.MaxDigits = 0
        Me._imNumber1_1.Fields.IntegerPart.GroupSizes = New Integer() {0}
        Me._imNumber1_1.Fields.IntegerPart.MaxDigits = 3
        Me._imNumber1_1.Fields.IntegerPart.MinDigits = 1
        Me._imNumber1_1.Fields.SignPrefix.NegativePattern = ""
        Me._imNumber1_1.HighlightText = True
        Me._imNumber1_1.ImeMode = System.Windows.Forms.ImeMode.Disable
        Me._imNumber1_1.Location = New System.Drawing.Point(224, 22)
        Me._imNumber1_1.MaxValue = New Decimal(New Integer() {100, 0, 0, 0})
        Me._imNumber1_1.MinValue = New Decimal(New Integer() {0, 0, 0, 0})
        Me._imNumber1_1.Name = "_imNumber1_1"
        Me._imNumber1_1.Size = New System.Drawing.Size(39, 23)
        Me._imNumber1_1.TabIndex = 50
        Me._imNumber1_1.Tag = "�����x���䗦����͂��ĉ������B"
        Me._imNumber1_1.Value = Nothing
        '
        '_imNumber1_2
        '
        Me._imNumber1_2.AlternateText.Zero.ForeColor = System.Drawing.SystemColors.WindowText
        Me._imNumber1_2.DisabledBackColor = System.Drawing.SystemColors.Window
        Me._imNumber1_2.DisabledForeColor = System.Drawing.SystemColors.MenuText
        NumberIntegerPartDisplayField11.GroupSizes = New Integer() {0}
        Me._imNumber1_2.DisplayFields.AddRange(New GrapeCity.Win.Editors.Fields.NumberDisplayField() {NumberIntegerPartDisplayField11})
        Me._imNumber1_2.Fields.DecimalPart.MaxDigits = 0
        Me._imNumber1_2.Fields.IntegerPart.GroupSizes = New Integer() {0}
        Me._imNumber1_2.Fields.IntegerPart.MaxDigits = 3
        Me._imNumber1_2.Fields.IntegerPart.MinDigits = 1
        Me._imNumber1_2.Fields.SignPrefix.NegativePattern = ""
        Me._imNumber1_2.HighlightText = True
        Me._imNumber1_2.ImeMode = System.Windows.Forms.ImeMode.Disable
        Me._imNumber1_2.Location = New System.Drawing.Point(362, 22)
        Me._imNumber1_2.MaxValue = New Decimal(New Integer() {100, 0, 0, 0})
        Me._imNumber1_2.MinValue = New Decimal(New Integer() {0, 0, 0, 0})
        Me._imNumber1_2.Name = "_imNumber1_2"
        Me._imNumber1_2.Size = New System.Drawing.Size(39, 23)
        Me._imNumber1_2.TabIndex = 51
        Me._imNumber1_2.Tag = "��`�x���䗦����͂��ĉ������B"
        Me._imNumber1_2.Value = Nothing
        '
        '_Label1_42
        '
        Me._Label1_42.AutoSize = True
        Me._Label1_42.BackColor = System.Drawing.Color.Transparent
        Me._Label1_42.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_42.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_42.ForeColor = System.Drawing.Color.Black
        Me._Label1_42.Location = New System.Drawing.Point(404, 26)
        Me._Label1_42.Name = "_Label1_42"
        Me._Label1_42.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_42.Size = New System.Drawing.Size(25, 16)
        Me._Label1_42.TabIndex = 106
        Me._Label1_42.Text = "��"
        Me._Label1_42.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        '_Label1_41
        '
        Me._Label1_41.AutoSize = True
        Me._Label1_41.BackColor = System.Drawing.Color.Transparent
        Me._Label1_41.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_41.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_41.ForeColor = System.Drawing.Color.Black
        Me._Label1_41.Location = New System.Drawing.Point(266, 26)
        Me._Label1_41.Name = "_Label1_41"
        Me._Label1_41.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_41.Size = New System.Drawing.Size(25, 16)
        Me._Label1_41.TabIndex = 105
        Me._Label1_41.Text = "��"
        Me._Label1_41.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        '_Label1_40
        '
        Me._Label1_40.AutoSize = True
        Me._Label1_40.BackColor = System.Drawing.Color.Transparent
        Me._Label1_40.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_40.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_40.ForeColor = System.Drawing.Color.Black
        Me._Label1_40.Location = New System.Drawing.Point(128, 26)
        Me._Label1_40.Name = "_Label1_40"
        Me._Label1_40.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_40.Size = New System.Drawing.Size(25, 16)
        Me._Label1_40.TabIndex = 104
        Me._Label1_40.Text = "��"
        Me._Label1_40.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        '_Label1_6
        '
        Me._Label1_6.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_6.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_6.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_6.ForeColor = System.Drawing.Color.White
        Me._Label1_6.Location = New System.Drawing.Point(292, 22)
        Me._Label1_6.Name = "_Label1_6"
        Me._Label1_6.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_6.Size = New System.Drawing.Size(67, 23)
        Me._Label1_6.TabIndex = 64
        Me._Label1_6.Text = "��`"
        Me._Label1_6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_5
        '
        Me._Label1_5.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_5.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_5.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_5.ForeColor = System.Drawing.Color.White
        Me._Label1_5.Location = New System.Drawing.Point(154, 22)
        Me._Label1_5.Name = "_Label1_5"
        Me._Label1_5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_5.Size = New System.Drawing.Size(67, 23)
        Me._Label1_5.TabIndex = 63
        Me._Label1_5.Text = "����"
        Me._Label1_5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_4
        '
        Me._Label1_4.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_4.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_4.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_4.ForeColor = System.Drawing.Color.White
        Me._Label1_4.Location = New System.Drawing.Point(16, 22)
        Me._Label1_4.Name = "_Label1_4"
        Me._Label1_4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_4.Size = New System.Drawing.Size(67, 23)
        Me._Label1_4.TabIndex = 62
        Me._Label1_4.Text = "�U��"
        Me._Label1_4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Frame1_0
        '
        Me._Frame1_0.BackColor = System.Drawing.SystemColors.Control
        Me._Frame1_0.Controls.Add(Me.Panel1)
        Me._Frame1_0.Controls.Add(Me._imText1_0)
        Me._Frame1_0.Controls.Add(Me._imText1_3)
        Me._Frame1_0.Controls.Add(Me._imText1_2)
        Me._Frame1_0.Controls.Add(Me._imText1_1)
        Me._Frame1_0.Controls.Add(Me._Label1_1)
        Me._Frame1_0.Controls.Add(Me._Label1_0)
        Me._Frame1_0.Controls.Add(Me._Label1_2)
        Me._Frame1_0.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Frame1_0.Location = New System.Drawing.Point(4, 34)
        Me._Frame1_0.Name = "_Frame1_0"
        Me._Frame1_0.Padding = New System.Windows.Forms.Padding(0)
        Me._Frame1_0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Frame1_0.Size = New System.Drawing.Size(559, 71)
        Me._Frame1_0.TabIndex = 101
        Me._Frame1_0.TabStop = False
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.Check1)
        Me.Panel1.Location = New System.Drawing.Point(464, 12)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(87, 25)
        Me.Panel1.TabIndex = 67
        '
        'Check1
        '
        Me.Check1.BackColor = System.Drawing.SystemColors.Control
        Me.Check1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Check1.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Check1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Check1.Location = New System.Drawing.Point(26, 2)
        Me.Check1.Name = "Check1"
        Me.Check1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Check1.Size = New System.Drawing.Size(72, 23)
        Me.Check1.TabIndex = 48
        Me.Check1.Tag = "���Z�ς̏ꍇ�̓`�F�b�N���ĉ������B"
        Me.Check1.Text = "���Z"
        Me.Check1.UseVisualStyleBackColor = False
        '
        '_imText1_0
        '
        Me._imText1_0.BackColor = System.Drawing.SystemColors.Control
        Me._imText1_0.CausesValidation = False
        Me._imText1_0.ContentAlignment = System.Drawing.ContentAlignment.MiddleCenter
        Me._imText1_0.DisabledForeColor = System.Drawing.SystemColors.MenuText
        Me._imText1_0.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Bold)
        Me._imText1_0.Location = New System.Drawing.Point(112, 14)
        Me._imText1_0.Name = "_imText1_0"
        Me._imText1_0.ReadOnly = True
        Me._imText1_0.Size = New System.Drawing.Size(73, 23)
        Me._imText1_0.TabIndex = 44
        Me._imText1_0.TabStop = False
        '
        '_imText1_3
        '
        Me._imText1_3.BackColor = System.Drawing.SystemColors.Control
        Me._imText1_3.CausesValidation = False
        Me._imText1_3.DisabledForeColor = System.Drawing.SystemColors.MenuText
        Me._imText1_3.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Bold)
        Me._imText1_3.Location = New System.Drawing.Point(198, 40)
        Me._imText1_3.Name = "_imText1_3"
        Me._imText1_3.ReadOnly = True
        Me._imText1_3.Size = New System.Drawing.Size(353, 23)
        Me._imText1_3.TabIndex = 47
        Me._imText1_3.TabStop = False
        '
        '_imText1_2
        '
        Me._imText1_2.BackColor = System.Drawing.SystemColors.Control
        Me._imText1_2.ContentAlignment = System.Drawing.ContentAlignment.MiddleCenter
        Me._imText1_2.DisabledForeColor = System.Drawing.SystemColors.MenuText
        Me._imText1_2.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Bold)
        Me._imText1_2.Location = New System.Drawing.Point(112, 40)
        Me._imText1_2.Name = "_imText1_2"
        Me._imText1_2.ReadOnly = True
        Me._imText1_2.Size = New System.Drawing.Size(83, 23)
        Me._imText1_2.TabIndex = 46
        Me._imText1_2.TabStop = False
        '
        '_imText1_1
        '
        Me._imText1_1.BackColor = System.Drawing.SystemColors.Control
        Me._imText1_1.CausesValidation = False
        Me._imText1_1.ContentAlignment = System.Drawing.ContentAlignment.MiddleCenter
        Me._imText1_1.DisabledForeColor = System.Drawing.SystemColors.MenuText
        Me._imText1_1.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Bold)
        Me._imText1_1.Location = New System.Drawing.Point(302, 14)
        Me._imText1_1.Name = "_imText1_1"
        Me._imText1_1.ReadOnly = True
        Me._imText1_1.Size = New System.Drawing.Size(33, 23)
        Me._imText1_1.TabIndex = 45
        Me._imText1_1.TabStop = False
        '
        '_Label1_1
        '
        Me._Label1_1.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_1.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_1.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_1.ForeColor = System.Drawing.Color.White
        Me._Label1_1.Location = New System.Drawing.Point(198, 14)
        Me._Label1_1.Name = "_Label1_1"
        Me._Label1_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_1.Size = New System.Drawing.Size(100, 23)
        Me._Label1_1.TabIndex = 66
        Me._Label1_1.Text = "������"
        Me._Label1_1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_0
        '
        Me._Label1_0.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_0.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_0.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_0.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_0.ForeColor = System.Drawing.Color.White
        Me._Label1_0.Location = New System.Drawing.Point(8, 14)
        Me._Label1_0.Name = "_Label1_0"
        Me._Label1_0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_0.Size = New System.Drawing.Size(100, 23)
        Me._Label1_0.TabIndex = 60
        Me._Label1_0.Text = "���N��"
        Me._Label1_0.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_2
        '
        Me._Label1_2.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_2.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_2.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_2.ForeColor = System.Drawing.Color.White
        Me._Label1_2.Location = New System.Drawing.Point(8, 40)
        Me._Label1_2.Name = "_Label1_2"
        Me._Label1_2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_2.Size = New System.Drawing.Size(100, 23)
        Me._Label1_2.TabIndex = 59
        Me._Label1_2.Text = "�Ɓ@��"
        Me._Label1_2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Picture1
        '
        Me.Picture1.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Picture1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Picture1.Controls.Add(Me._cmdKey_3)
        Me.Picture1.Controls.Add(Me._cmdKey_12)
        Me.Picture1.Controls.Add(Me._cmdKey_4)
        Me.Picture1.Controls.Add(Me._cmdKey_10)
        Me.Picture1.Controls.Add(Me._cmdKey_6)
        Me.Picture1.Controls.Add(Me._cmdKey_7)
        Me.Picture1.Controls.Add(Me._cmdKey_8)
        Me.Picture1.Controls.Add(Me._cmdKey_9)
        Me.Picture1.Controls.Add(Me._cmdKey_1)
        Me.Picture1.Controls.Add(Me._cmdKey_11)
        Me.Picture1.Controls.Add(Me._cmdKey_2)
        Me.Picture1.Controls.Add(Me._cmdKey_5)
        Me.Picture1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Picture1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Picture1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Picture1.Location = New System.Drawing.Point(0, 668)
        Me.Picture1.Name = "Picture1"
        Me.Picture1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Picture1.Size = New System.Drawing.Size(1016, 51)
        Me.Picture1.TabIndex = 100
        '
        '_cmdKey_3
        '
        Me._cmdKey_3.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_3.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_3.Enabled = False
        Me._cmdKey_3.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_3.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_3.Location = New System.Drawing.Point(166, 4)
        Me._cmdKey_3.Name = "_cmdKey_3"
        Me._cmdKey_3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_3.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_3.TabIndex = 34
        Me._cmdKey_3.Text = "F3"
        Me._cmdKey_3.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_3.UseVisualStyleBackColor = False
        '
        '_cmdKey_12
        '
        Me._cmdKey_12.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_12.CausesValidation = False
        Me._cmdKey_12.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_12.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_12.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_12.Location = New System.Drawing.Point(929, 4)
        Me._cmdKey_12.Name = "_cmdKey_12"
        Me._cmdKey_12.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_12.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_12.TabIndex = 33
        Me._cmdKey_12.Tag = "�������I�����܂��B"
        Me._cmdKey_12.Text = "F12" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "�I ��"
        Me._cmdKey_12.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_12.UseVisualStyleBackColor = False
        '
        '_cmdKey_4
        '
        Me._cmdKey_4.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_4.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_4.Enabled = False
        Me._cmdKey_4.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_4.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_4.Location = New System.Drawing.Point(246, 4)
        Me._cmdKey_4.Name = "_cmdKey_4"
        Me._cmdKey_4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_4.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_4.TabIndex = 35
        Me._cmdKey_4.Text = "F4"
        Me._cmdKey_4.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_4.UseVisualStyleBackColor = False
        '
        '_cmdKey_10
        '
        Me._cmdKey_10.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_10.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_10.Enabled = False
        Me._cmdKey_10.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_10.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_10.Location = New System.Drawing.Point(769, 4)
        Me._cmdKey_10.Name = "_cmdKey_10"
        Me._cmdKey_10.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_10.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_10.TabIndex = 41
        Me._cmdKey_10.Text = "F10"
        Me._cmdKey_10.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_10.UseVisualStyleBackColor = False
        '
        '_cmdKey_6
        '
        Me._cmdKey_6.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_6.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_6.Enabled = False
        Me._cmdKey_6.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_6.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_6.Location = New System.Drawing.Point(428, 4)
        Me._cmdKey_6.Name = "_cmdKey_6"
        Me._cmdKey_6.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_6.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_6.TabIndex = 37
        Me._cmdKey_6.Text = "F6"
        Me._cmdKey_6.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_6.UseVisualStyleBackColor = False
        '
        '_cmdKey_7
        '
        Me._cmdKey_7.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_7.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_7.Enabled = False
        Me._cmdKey_7.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_7.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_7.Location = New System.Drawing.Point(508, 4)
        Me._cmdKey_7.Name = "_cmdKey_7"
        Me._cmdKey_7.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_7.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_7.TabIndex = 38
        Me._cmdKey_7.Text = "F7"
        Me._cmdKey_7.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_7.UseVisualStyleBackColor = False
        '
        '_cmdKey_8
        '
        Me._cmdKey_8.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_8.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_8.Enabled = False
        Me._cmdKey_8.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_8.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_8.Location = New System.Drawing.Point(588, 4)
        Me._cmdKey_8.Name = "_cmdKey_8"
        Me._cmdKey_8.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_8.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_8.TabIndex = 39
        Me._cmdKey_8.Text = "F8"
        Me._cmdKey_8.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_8.UseVisualStyleBackColor = False
        '
        '_cmdKey_9
        '
        Me._cmdKey_9.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_9.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_9.Enabled = False
        Me._cmdKey_9.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_9.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_9.Location = New System.Drawing.Point(689, 4)
        Me._cmdKey_9.Name = "_cmdKey_9"
        Me._cmdKey_9.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_9.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_9.TabIndex = 40
        Me._cmdKey_9.Text = "F9"
        Me._cmdKey_9.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_9.UseVisualStyleBackColor = False
        '
        '_cmdKey_1
        '
        Me._cmdKey_1.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_1.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_1.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_1.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_1.Location = New System.Drawing.Point(6, 4)
        Me._cmdKey_1.Name = "_cmdKey_1"
        Me._cmdKey_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_1.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_1.TabIndex = 32
        Me._cmdKey_1.Tag = "���̓f�[�^��o�^���܂��B"
        Me._cmdKey_1.Text = "F1" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "�o �^"
        Me._cmdKey_1.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_1.UseVisualStyleBackColor = False
        '
        '_cmdKey_11
        '
        Me._cmdKey_11.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_11.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_11.Enabled = False
        Me._cmdKey_11.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_11.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_11.Location = New System.Drawing.Point(849, 4)
        Me._cmdKey_11.Name = "_cmdKey_11"
        Me._cmdKey_11.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_11.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_11.TabIndex = 42
        Me._cmdKey_11.Text = "F11"
        Me._cmdKey_11.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_11.UseVisualStyleBackColor = False
        '
        '_cmdKey_2
        '
        Me._cmdKey_2.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_2.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_2.Enabled = False
        Me._cmdKey_2.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_2.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_2.Location = New System.Drawing.Point(86, 4)
        Me._cmdKey_2.Name = "_cmdKey_2"
        Me._cmdKey_2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_2.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_2.TabIndex = 33
        Me._cmdKey_2.Text = "F2"
        Me._cmdKey_2.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_2.UseVisualStyleBackColor = False
        '
        '_cmdKey_5
        '
        Me._cmdKey_5.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_5.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_5.Enabled = False
        Me._cmdKey_5.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_5.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_5.Location = New System.Drawing.Point(348, 4)
        Me._cmdKey_5.Name = "_cmdKey_5"
        Me._cmdKey_5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_5.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_5.TabIndex = 36
        Me._cmdKey_5.Text = "F5"
        Me._cmdKey_5.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_5.UseVisualStyleBackColor = False
        '
        'StatusBar1
        '
        Me.StatusBar1.Font = New System.Drawing.Font("MS Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.StatusBar1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me._StatusBar1_Panel2, Me.Message})
        Me.StatusBar1.Location = New System.Drawing.Point(0, 719)
        Me.StatusBar1.Name = "StatusBar1"
        Me.StatusBar1.Size = New System.Drawing.Size(1016, 23)
        Me.StatusBar1.SizingGrip = False
        Me.StatusBar1.TabIndex = 52
        '
        '_StatusBar1_Panel2
        '
        Me._StatusBar1_Panel2.AutoSize = False
        Me._StatusBar1_Panel2.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me._StatusBar1_Panel2.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter
        Me._StatusBar1_Panel2.Margin = New System.Windows.Forms.Padding(0)
        Me._StatusBar1_Panel2.Name = "_StatusBar1_Panel2"
        Me._StatusBar1_Panel2.Size = New System.Drawing.Size(117, 23)
        '
        'Message
        '
        Me.Message.AutoSize = False
        Me.Message.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me.Message.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter
        Me.Message.Margin = New System.Windows.Forms.Padding(0)
        Me.Message.Name = "Message"
        Me.Message.Size = New System.Drawing.Size(892, 23)
        Me.Message.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        '_imText2_2
        '
        Me._imText2_2.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me._imText2_2.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Bold)
        Me._imText2_2.Location = New System.Drawing.Point(576, 6)
        Me._imText2_2.Name = "_imText2_2"
        Me._imText2_2.ReadOnly = True
        Me._imText2_2.Size = New System.Drawing.Size(433, 23)
        Me._imText2_2.TabIndex = 54
        Me._imText2_2.TabStop = False
        '
        '_imText2_0
        '
        Me._imText2_0.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me._imText2_0.ContentAlignment = System.Drawing.ContentAlignment.MiddleCenter
        Me._imText2_0.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._imText2_0.Location = New System.Drawing.Point(440, 6)
        Me._imText2_0.Name = "_imText2_0"
        Me._imText2_0.ReadOnly = True
        Me._imText2_0.Size = New System.Drawing.Size(83, 23)
        Me._imText2_0.TabIndex = 55
        Me._imText2_0.TabStop = False
        '
        '_imText2_1
        '
        Me._imText2_1.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me._imText2_1.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Bold)
        Me._imText2_1.Location = New System.Drawing.Point(527, 6)
        Me._imText2_1.Name = "_imText2_1"
        Me._imText2_1.ReadOnly = True
        Me._imText2_1.Size = New System.Drawing.Size(45, 23)
        Me._imText2_1.TabIndex = 56
        Me._imText2_1.TabStop = False
        '
        'lblTitle
        '
        Me.lblTitle.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblTitle.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTitle.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblTitle.Font = New System.Drawing.Font("MS Mincho", 20.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblTitle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.lblTitle.Location = New System.Drawing.Point(0, 0)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblTitle.Size = New System.Drawing.Size(1015, 34)
        Me.lblTitle.TabIndex = 53
        Me.lblTitle.Text = " �O�����́i�y�؁j"
        '
        '_ctlMeisai2_0
        '
        Me._ctlMeisai2_0.Location = New System.Drawing.Point(8, 40)
        Me._ctlMeisai2_0.Name = "_ctlMeisai2_0"
        Me._ctlMeisai2_0.Size = New System.Drawing.Size(973, 34)
        Me._ctlMeisai2_0.TabIndex = 22
        '
        '_ctlMeisai2_1
        '
        Me._ctlMeisai2_1.Location = New System.Drawing.Point(8, 74)
        Me._ctlMeisai2_1.Name = "_ctlMeisai2_1"
        Me._ctlMeisai2_1.Size = New System.Drawing.Size(973, 34)
        Me._ctlMeisai2_1.TabIndex = 23
        '
        '_ctlMeisai2_2
        '
        Me._ctlMeisai2_2.Location = New System.Drawing.Point(8, 108)
        Me._ctlMeisai2_2.Name = "_ctlMeisai2_2"
        Me._ctlMeisai2_2.Size = New System.Drawing.Size(973, 34)
        Me._ctlMeisai2_2.TabIndex = 24
        '
        '_ctlMeisai2_3
        '
        Me._ctlMeisai2_3.Location = New System.Drawing.Point(8, 142)
        Me._ctlMeisai2_3.Name = "_ctlMeisai2_3"
        Me._ctlMeisai2_3.Size = New System.Drawing.Size(973, 36)
        Me._ctlMeisai2_3.TabIndex = 25
        '
        '_ctlMeisai1_0
        '
        Me._ctlMeisai1_0.Location = New System.Drawing.Point(8, 40)
        Me._ctlMeisai1_0.Name = "_ctlMeisai1_0"
        Me._ctlMeisai1_0.Size = New System.Drawing.Size(875, 33)
        Me._ctlMeisai1_0.TabIndex = 0
        '
        '_ctlMeisai1_1
        '
        Me._ctlMeisai1_1.Location = New System.Drawing.Point(8, 72)
        Me._ctlMeisai1_1.Name = "_ctlMeisai1_1"
        Me._ctlMeisai1_1.Size = New System.Drawing.Size(875, 33)
        Me._ctlMeisai1_1.TabIndex = 1
        '
        '_ctlMeisai1_2
        '
        Me._ctlMeisai1_2.Location = New System.Drawing.Point(8, 104)
        Me._ctlMeisai1_2.Name = "_ctlMeisai1_2"
        Me._ctlMeisai1_2.Size = New System.Drawing.Size(875, 33)
        Me._ctlMeisai1_2.TabIndex = 2
        '
        'frmSYKD150
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(1016, 742)
        Me.Controls.Add(Me._Frame1_4)
        Me.Controls.Add(Me._Frame1_3)
        Me.Controls.Add(Me._Frame1_2)
        Me.Controls.Add(Me._Frame1_1)
        Me.Controls.Add(Me._Frame1_0)
        Me.Controls.Add(Me.Picture1)
        Me.Controls.Add(Me.StatusBar1)
        Me.Controls.Add(Me._imText2_2)
        Me.Controls.Add(Me._imText2_0)
        Me.Controls.Add(Me._imText2_1)
        Me.Controls.Add(Me.lblTitle)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.KeyPreview = True
        Me.Location = New System.Drawing.Point(4, 23)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmSYKD150"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "�H���Ǘ��V�X�e��"
        Me._Frame1_4.ResumeLayout(False)
        Me.Picture2.ResumeLayout(False)
        CType(Me._imText3_4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._imText3_5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._imText3_6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._imNumber2_5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._imNumber2_6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._imText3_7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._imText3_8, System.ComponentModel.ISupportInitialize).EndInit()
        Me._Frame1_3.ResumeLayout(False)
        Me._Frame1_3.PerformLayout()
        CType(Me._imText4_0, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._imNumber2_0, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._imText4_2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._imText4_3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._imNumber2_1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._imText4_4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._imText4_5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._imText4_6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._imNumber2_3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._imText4_7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._imNumber2_4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._imNumber2_2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._imNumber2_7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._imNumber2_8, System.ComponentModel.ISupportInitialize).EndInit()
        Me._Frame1_2.ResumeLayout(False)
        CType(Me._imText3_0, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._imText3_1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._imText3_2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._imText3_3, System.ComponentModel.ISupportInitialize).EndInit()
        Me._Frame1_1.ResumeLayout(False)
        Me._Frame1_1.PerformLayout()
        CType(Me._imNumber1_0, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._imNumber1_1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._imNumber1_2, System.ComponentModel.ISupportInitialize).EndInit()
        Me._Frame1_0.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        CType(Me._imText1_0, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._imText1_3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._imText1_2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._imText1_1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Picture1.ResumeLayout(False)
        Me.StatusBar1.ResumeLayout(False)
        Me.StatusBar1.PerformLayout()
        CType(Me._imText2_2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._imText2_0, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._imText2_1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Panel1 As Panel
    Public WithEvents _imNumber2_5 As GcNumber
    Friend WithEvents GcShortcut1 As GcShortcut
#End Region
End Class