Option Strict Off
Option Explicit On
Imports C1.Win.C1Document
Imports C1.Win.FlexReport
Imports System.Drawing.Printing

Module prnSYKD115
    '=============================================================
    ' ���[�U�[���@  �F  �R�z�H�Ɗ������
    ' �V�X�e�����@  �F  �H���Ǘ��V�X�e��
    ' ���W���[����  �F  �O���o�����񍐏����
    ' ���W���[��ID�@�F  prnSYKD115.bas
    ' �쐬���@ �@�@ �F  ���� 13 �N 07 �� 25 ��
    ' �X�V���@�@  �@�F  ���� 13 �N 08 �� 29 ��
    '=============================================================
    '

    Private P_Cnt As Short ' ����y�[�W�J�E���g
    Private XX() As Single ' ����w�ʒu
    Private YY() As Single ' ����x�ʒu
    '

    '-------------------------------------------------------------------------------
    '   ����    :   �O���o�����񍐏����
    '   �֐�    :   Function PrnMainD115()
    '   ����    :   CDT()   �����ԍ�
    '   �ߒl    :   True    ����I��
    '   �@�@        False   ���f
    '-------------------------------------------------------------------------------
    Public Function PrnMainD115(ByRef CDT() As String) As Object

        Dim QRY1 As String
        Dim QRY2 As String
        Dim SQL As String
        '2021.08.03 UPGRADE S  AIT)dannnl
        'Dim Rs As ADODB.Recordset
        Dim Rs As New DataTable
        '2021.08.03 UPGRADE E
        Dim OpenFlg As Short
        Dim DT() As WARIDASI_DATA_DBT ' ���o�f�[�^�p
        Dim DT2() As DEKIDAKA_DATA_DBT ' �O���o����(������)�f�[�^�p
        'Dim DT3() As DEKIDAKA_DATA_DBT ' �O���o����(�O����)�f�[�^�p�@�@�@�@�@'2021.08.03 UPGRADE DEL  AIT)dannnl
        Dim Cnt As Integer : Cnt = 0
        Dim BCnt As Integer : BCnt = 0
        Dim M_Cnt As Integer : M_Cnt = 0
        Dim lp As Integer
        Dim pryy As Single
        '2021.08.03  UPGRADE DEL S  AIT)dannnl
        'Dim LCnt As Integer
        'Dim L_Length As Single
        '2021.08.03 UPGRADE DEL E	
        Dim W_WARIDASI_NO As String
        Dim W_KOUSYU_CDNO As String
        Dim W_SIMEYM(3) As String
        Dim G_SIMEID As Integer : G_SIMEID = 0
        Dim i As Short
        Dim DT_KEI(3) As Decimal
        Dim DT_SEN(3) As Decimal
        Dim GD_KEI As Decimal : GD_KEI = 0
        Dim SD_KEI As Decimal : SD_KEI = 0
        Dim NewPage_Flag As String : NewPage_Flag = CStr(False)

        ' �o�����f�[�^�i�����j�̒��o
        For lp = 1 To UBound(CDT)
            If CDT(lp) <> "" Then
                ' QRY/SELECT���g��
                QRY1 = "(SELECT * FROM WARIDASI_DATA"
                QRY1 = QRY1 & " WHERE EDA_NO = '" & KeyKouji.EDA_NO & "'"
                QRY1 = QRY1 & " AND KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"
                QRY1 = QRY1 & " AND WARIDASI_NO = '" & CDT(lp) & "'"
                QRY1 = QRY1 & ") AS WARIDASI"

                ' QRY/SELECT���g��
                QRY2 = "(SELECT * FROM DEKIDAKA_DATA"
                QRY2 = QRY2 & " WHERE EDA_NO = '" & KeyKouji.EDA_NO & "'"
                QRY2 = QRY2 & " AND KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"
                QRY2 = QRY2 & " AND SIME_YM = '" & CtlKouji.SYORI_YM & "'"
                QRY2 = QRY2 & ") AS DEKIDAKA"

                ' SQL/SELECT���g��
                SQL = "SELECT"
                SQL = SQL & " WARIDASI.KOUSYU_CD    AS F01," ' �H������
                SQL = SQL & " WARIDASI.KOUSYU_NO    AS F02," ' �H��ԍ�
                SQL = SQL & " WARIDASI.MEISAI_NO    AS F03," ' ���הԍ�
                SQL = SQL & " WARIDASI.MEISYOU      AS F04," ' ����
                SQL = SQL & " WARIDASI.TANI         AS F05," ' �P��
                SQL = SQL & " WARIDASI.G_SUURYOU    AS F06," ' ���ʁi�O���j
                SQL = SQL & " WARIDASI.G_TANKA      AS F07," ' �P���i�O���j
                SQL = SQL & " WARIDASI.G_KINGAKU    AS F08," ' ���z�i�O���j
                SQL = SQL & " DEKIDAKA.*"
                SQL = SQL & " FROM " & QRY1 & " LEFT JOIN " & QRY2
                SQL = SQL & " ON  (WARIDASI.MEISAI_NO = DEKIDAKA.MEISAI_NO)"
                SQL = SQL & " AND (WARIDASI.KOUSYU_NO = DEKIDAKA.KOUSYU_NO)"
                SQL = SQL & " AND (WARIDASI.KOUSYU_CD = DEKIDAKA.KOUSYU_CD)"
                SQL = SQL & " AND (WARIDASI.EDA_NO    = DEKIDAKA.EDA_NO)"
                SQL = SQL & " AND (WARIDASI.KOUJI_NO  = DEKIDAKA.KOUJI_NO)"
                SQL = SQL & " ORDER BY WARIDASI.KOUSYU_CD, WARIDASI.KOUSYU_NO, WARIDASI.MEISAI_NO"

                ' SQL�����s
                '2021.08.03 UPGRADE S  AIT)dannnl
                'Rs = SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText)
                Rs = RsOpen(SQL)
                '2021.08.03 UPGRADE E
                OpenFlg = 1

                Cnt = 0
                '2021.08.03 UPGRADE S  AIT)dannnl
                'Do Until Rs.EOF
                For Each Row As DataRow In Rs.Rows
                    '2021.08.03 UPGRADE E
                    ' ���o�f�[�^
                    ReDim Preserve DT(Cnt + BCnt)
                    Call CLEAR_WARIDASI_DATA(DT(Cnt + BCnt))
                    With DT(Cnt + BCnt)
                        .KOUJI_NO = KeyKouji.KOUJI_NO ' �H���ԍ�
                        .EDA_NO = KeyKouji.EDA_NO ' �H���}��
                        '2021.08.03 UPGRADE S  AIT)dannnl
                        '.KOUSYU_CD = RsNull(Rs, "F01") ' �H������
                        '.KOUSYU_NO = RsNull(Rs, "F02") ' �H��ԍ�
                        '.MEISAI_NO = CDbl2(RsNull(Rs, "F03")) ' ���הԍ�
                        '.MEISYOU = RsNull(Rs, "F04") ' ����
                        '.TANI = RsNull(Rs, "F05") ' �P��
                        .KOUSYU_CD = RsNull(Row, "F01") ' �H������
                        .KOUSYU_NO = RsNull(Row, "F02") ' �H��ԍ�
                        .MEISAI_NO = CDbl2(RsNull(Row, "F03")) ' ���הԍ�
                        .MEISYOU = RsNull(Row, "F04") ' ����
                        .TANI = RsNull(Row, "F05") ' �P��
                        '2021.08.03 UPGRADE E	
                        .WARIDASI_NO = CDT(lp) ' ���o�ԍ�
                        '2021.08.03 UPGRADE S  AIT)dannnl
                        '.G_SUURYOU = CCur2(RsNull(Rs, "F06")) ' ���ʁi�O���j
                        '.G_TANKA = CCur2(RsNull(Rs, "F07")) ' �P���i�O���j
                        '.G_KINGAKU = CCur2(RsNull(Rs, "F08")) ' ���z�i�O���j
                        .G_SUURYOU = CCur2(RsNull(Row, "F06")) ' ���ʁi�O���j
                        .G_TANKA = CCur2(RsNull(Row, "F07")) ' �P���i�O���j
                        .G_KINGAKU = CCur2(RsNull(Row, "F08")) ' ���z�i�O���j
                        '2021.08.03 UPGRADE E
                    End With
                    ' �o����(������)�f�[�^
                    ReDim Preserve DT2(Cnt + BCnt)
                    Call CLEAR_DEKIDAKA_DATA(DT2(Cnt + BCnt))
                    '2021.08.03 UPGRADE S  AIT)dannnl
                    'Call DATSET_DEKIDAKA_DATA(Rs, DT2(Cnt + BCnt))
                    Call DATSET_DEKIDAKA_DATA(Row, DT2(Cnt + BCnt))
                    '2021.08.03 UPGRADE E
                    Cnt = Cnt + 1
                    '2021.08.03 UPGRADE S  AIT)dannnl
                    '	Rs.MoveNext()
                    'Loop
                Next
                '2021.08.03 UPGRADE E
                BCnt = BCnt + Cnt
            End If
        Next lp

        '2021.08.03 UPGRADE S  AIT)dannnl
        'Rs.Close()
        Rs.Dispose()
        '2021.08.03 UPGRADE E
        Rs = Nothing

        If BCnt = 0 Then
            '2021.09.14 UPGRADE S  AIT)dannnl
            'MsgBox("�Y���f�[�^������܂���B", MsgBoxStyle.Information)
            MsgBox("�Y���f�[�^������܂���B", MsgBoxStyle.Information, SYSTEMNM)
            '2021.09.14 UPGRADE E
            Exit Function
        End If

        ' �v�����^�[�f�o�C�X�̓ǂݍ���
        Call INI_PRN_Read(1)

        ' �����ݒ�
        If PrnFirstD115() = False Then
            Exit Function
        End If

        ' ����ʒu�̎擾
        Call PrXYGetD115()

        ' ������
        P_Cnt = 1 : pryy = P_YY * 5
        W_WARIDASI_NO = DT(0).WARIDASI_NO
        W_KOUSYU_CDNO = ""
        For i = 0 To 3
            DT_KEI(i) = 0
            DT_SEN(i) = 0
        Next i

        ' ���o����
        Call PrItemPD115(pryy, DT(0).WARIDASI_NO, DT)
        ' �����̎擾
        M_Cnt = MonthCountGet(DT(0), W_SIMEYM)
        '----- ���s
        pryy = pryy + ((P_YY * 1.5) * 5.5)
        ' ���o����
        Call PrItemD115(pryy)
        '----- ���s
        pryy = pryy + ((P_YY * 1.5) * 3)

        If PrnCancel = 1 Then
            '----- ���f
            Call PRN_ErrEnd()
            Exit Function
        End If

        For lp = 0 To UBound(DT)
            'If DT(lp).WARIDASI_NO <> W_WARIDASI_NO Or NewPage_CHK(pryy, P_YY * 4.25) = False Then
            If DT(lp).WARIDASI_NO <> W_WARIDASI_NO Or NewPage_CHK(pryy, (P_YY * 4.25) + (P_YY * 1.5)) = False Then
                If DT(lp).WARIDASI_NO <> W_WARIDASI_NO Then
                    ' ���v��
                    If pryy > P_HEIGHT - (P_YY * 4.25) - ((P_YY * 1.5) * 3) Then
                        NewPage_Flag = CStr(True)
                        ' �e�f�[�^���v��
                        Call PrDataGD115(pryy, W_SIMEYM, DT_KEI, DT_SEN, GD_KEI, SD_KEI, M_Cnt, NewPage_Flag)
                        NewPage_Flag = CStr(False)
                        '----- ���y�[�W
                        Call PRN_NewPage()
                        '----- �y�[�W���̍X�V
                        P_Cnt = P_Cnt + 1
                        '----- �󎚈ʒu�̃��Z�b�g
                        pryy = P_YY * 5
                        ' ���o����(�y�[�W���o��)
                        Call PrItemPD115(pryy, DT(lp - 1).WARIDASI_NO, DT)
                        ' �����̎擾
                        M_Cnt = MonthCountGet(DT(lp - 1), W_SIMEYM)
                        '----- ���s
                        pryy = pryy + ((P_YY * 1.5) * 5.5)
                        ' ���o����(���ڌ��o��)
                        Call PrItemD115(pryy)
                        pryy = pryy + ((P_YY * 1.5) * 3)
                        NewPage_Flag = CStr(True)
                        ' �f�[�^��(���o�E�挎��)
                        Call PrData2D115(pryy, DT(lp - 1), DT2(lp - 1), M_Cnt, W_KOUSYU_CDNO, W_SIMEYM, G_SIMEID, DT_KEI, DT_SEN, NewPage_Flag)
                        NewPage_Flag = CStr(False)
                    End If
                    ' �e�f�[�^���v��
                    pryy = P_HEIGHT - (P_YY * 4.25) - ((P_YY * 1.5) * 3)
                    Call PrDataGD115(pryy, W_SIMEYM, DT_KEI, DT_SEN, GD_KEI, SD_KEI, M_Cnt, NewPage_Flag)
                    ' �������E�Đݒ�
                    For i = 0 To 3
                        W_SIMEYM(i) = ""
                        DT_KEI(i) = 0
                        DT_SEN(i) = 0
                    Next i
                    GD_KEI = 0
                    SD_KEI = 0
                    W_WARIDASI_NO = DT(lp).WARIDASI_NO
                    W_KOUSYU_CDNO = ""
                    M_Cnt = 0
                    '----- �y�[�W���̍X�V
                    P_Cnt = 1
                Else
                    ' �e�f�[�^���v��
                    NewPage_Flag = CStr(True)
                    Call PrDataGD115(pryy, W_SIMEYM, DT_KEI, DT_SEN, GD_KEI, SD_KEI, M_Cnt, NewPage_Flag)
                    NewPage_Flag = CStr(False)
                    '----- �y�[�W���̍X�V
                    P_Cnt = P_Cnt + 1
                End If
                '----- ���y�[�W
                Call PRN_NewPage()
                '----- �󎚈ʒu�̃��Z�b�g
                pryy = P_YY * 5
                ' ���o����(�y�[�W���o��)
                Call PrItemPD115(pryy, DT(lp).WARIDASI_NO, DT)
                ' �����̎擾
                M_Cnt = MonthCountGet(DT(lp), W_SIMEYM)
                '----- ���s
                pryy = pryy + ((P_YY * 1.5) * 5.5)
                ' ���o����(���ڌ��o��)
                Call PrItemD115(pryy)
                '----- ���s
                pryy = pryy + ((P_YY * 1.5) * 3)
                NewPage_Flag = CStr(True)
                ' �f�[�^��(���o�E�挎���o����)
                Call PrData2D115(pryy, DT(lp), DT2(lp), M_Cnt, W_KOUSYU_CDNO, W_SIMEYM, G_SIMEID, DT_KEI, DT_SEN, NewPage_Flag)
                NewPage_Flag = CStr(False)
                ' �������E�Đݒ�
                W_WARIDASI_NO = DT(lp).WARIDASI_NO
                W_KOUSYU_CDNO = ""
                'M_Cnt = 0
            End If
            ' �f�[�^��(���o�E�挎���o����)
            Call PrData2D115(pryy, DT(lp), DT2(lp), M_Cnt, W_KOUSYU_CDNO, W_SIMEYM, G_SIMEID, DT_KEI, DT_SEN, NewPage_Flag)
            ' �f�[�^��(�_��E����o����)
            Call PrDataD115(pryy, DT(lp), W_KOUSYU_CDNO, DT2(lp), M_Cnt, GD_KEI, SD_KEI)
            '----- ���s
            pryy = pryy + (P_YY * 1.5)
            '----- ����
            '2021.08.12 UPGRADE S AIT)phongdv
            'Call PRN_LINE(XX(0), pryy, XX(18), pryy, 1, "", VSDraw7Lib.PenStyleSettings.psDot)
            Call PRN_LINE(XX(0), pryy, XX(18), pryy, 1, "", DashStyle.Dot)
            '2021.08.12 UPGRADE E
        Next lp

        ' ���v�󎚏���
        If pryy > P_HEIGHT - (P_YY * 4.25) - (P_YY * 1.5 * 3) Then
            NewPage_Flag = CStr(True)
            Call PrDataGD115(pryy, W_SIMEYM, DT_KEI, DT_SEN, GD_KEI, SD_KEI, M_Cnt, NewPage_Flag)
            NewPage_Flag = CStr(False)
            '----- ���y�[�W
            Call PRN_NewPage()
            '----- �y�[�W���̍X�V
            P_Cnt = P_Cnt + 1
            '----- �󎚈ʒu�̃��Z�b�g
            pryy = P_YY * 5
            ' ���o����(�y�[�W���o��)
            Call PrItemPD115(pryy, DT(UBound(DT)).WARIDASI_NO, DT)
            ' �����̎擾
            M_Cnt = MonthCountGet(DT(UBound(DT)), W_SIMEYM)
            '----- ���s
            pryy = pryy + ((P_YY * 1.5) * 5.5)
            ' ���o����(���ڌ��o��)
            Call PrItemD115(pryy)
            '----- ���s
            pryy = pryy + ((P_YY * 1.5) * 3)
            NewPage_Flag = CStr(True)
            ' �f�[�^��(���o�E�o����)
            Call PrData2D115(pryy, DT(UBound(DT)), DT2(UBound(DT2)), M_Cnt, W_KOUSYU_CDNO, W_SIMEYM, G_SIMEID, DT_KEI, DT_SEN, NewPage_Flag)
            NewPage_Flag = CStr(False)
        End If

        ' ���v��
        pryy = P_HEIGHT - (P_YY * 4.25) - (P_YY * 1.5 * 3)
        Call PrDataGD115(pryy, W_SIMEYM, DT_KEI, DT_SEN, GD_KEI, SD_KEI, M_Cnt, NewPage_Flag)

        ' ����I��
        Call PRN_END()

        ' �v���r���[�\��
        If ViewFlg = True Then
            frmSYKD115.StatusBar1.Items.Item("Message").Text = ""
            ViewForm.ShowDialog()
        End If

        ' ����I��
        PrnMainD115 = True
        ViewForm.Dispose()�@�@�@�@�@'2021.08.12 UPGRADE ADD  AIT)phongdv
    End Function

    '-------------------------------------------------------------------------------
    '   ����    :   �����ݒ�
    '   �֐�    :   Sub     PrnFirstD115()
    '   ����    :   ����
    '   �ߒl    :   True    ����I��
    '   �@�@        False   �Y���Ȃ�
    '-------------------------------------------------------------------------------
    Private Function PrnFirstD115() As Boolean

        ' �߂�l�̏�����
        PrnFirstD115 = False

        ' �^�C�g���ݒ�
        DocName = "�O���o�����񍐏�"

        ' �v�����^�[�f�o�C�X�̐ݒ�
        If Printer_Set(PRN1) = False Then
            '2021.09.14 UPGRADE S  AIT)dannnl
            'MsgBox("�ݒ�ɖ����v�����^�[�f�o�C�X���w�肳��܂����B")
            MsgBox("�ݒ�ɖ����v�����^�[�f�o�C�X���w�肳��܂����B", MsgBoxStyle.ApplicationModal, SYSTEMNM)
            '2021.09.14 UPGRADE E
            Exit Function
        End If

        ' �p���ݒ�
        '2021.08.12 UPGRADE S AIT)phongdv
        'P_SIZE = PrinterObjectConstants.vbPRPSA4 ' �`�S
        'P_ORIENT = VSPrinter7Lib.OrientationSettings.orLandscape ' ��:orLandscape,�c:orPortrait
        P_SIZE = PaperKind.A4  ' �`�S
        P_ORIENT = OrientationEnum.Landscape  ' ��:orLandscape,�c:orPortrait
        '2021.08.12 UPGRADE E 
        F_SIZE = 12

        ' ����ďo��ʂ̃Z�b�g
        CallForm = frmSYKD115

        ' ��������ݒ�
        If PRN_First(ViewForm) = False Then
            '2021.09.14 UPGRADE S  AIT)dannnl
            'MsgBox("�v�����^�̐ݒ�Ɏ��s���܂����B", MsgBoxStyle.Exclamation)
            MsgBox("�v�����^�̐ݒ�Ɏ��s���܂����B", MsgBoxStyle.Exclamation, SYSTEMNM)
            '2021.09.14 UPGRADE E
            Exit Function
        End If

        ' ����I��
        PrnFirstD115 = True

    End Function

    '-------------------------------------------------------------------------------
    '   ����    :   ����ʒu�ݒ菈��
    '   �֐�    :   Sub PrXYGetD115()
    '   ����    :   ����
    '   �ߒl    :   ����
    '-------------------------------------------------------------------------------
    Private Sub PrXYGetD115()

        Dim PrLen As Short
        Dim xMargn As Short

        ' ���ڐ��̐ݒ�
        ReDim XX(19)
        ReDim YY(1)

        ' �����񒷂̎Z�o(PrLen=148)
        PrLen = 0
        PrLen = PrLen + Len(Space(30)) ' �H�����ށ{�H��ԍ��{�H�햼��
        PrLen = PrLen + Len(Space(6)) ' <�_����z>����
        PrLen = PrLen + Len(Space(4)) ' <�_����z>�P��
        PrLen = PrLen + Len(Space(10)) ' <�_����z>�P��
        PrLen = PrLen + Len(Space(10)) ' <�_����z>���z
        PrLen = PrLen + Len(Space(6)) ' <�O������>�ύX�㐔��
        PrLen = PrLen + Len(Space(6)) ' <�O������>�݌v(����)����
        PrLen = PrLen + Len(Space(10)) ' <�O������>(����)���z
        PrLen = PrLen + Len(Space(6)) ' <�O���O��>�ύX�㐔��
        PrLen = PrLen + Len(Space(6)) ' <�O���O��>�݌v(����)����
        PrLen = PrLen + Len(Space(10)) ' <�O���O��>(����)���z
        PrLen = PrLen + Len(Space(6)) ' <�O���R�O>�ύX�㐔��
        PrLen = PrLen + Len(Space(6)) ' <�O���R�O>�݌v(����)����
        PrLen = PrLen + Len(Space(10)) ' <�O���R�O>(����)���z
        PrLen = PrLen + Len(Space(6)) ' <�O���S�O>�ύX�㐔��
        PrLen = PrLen + Len(Space(6)) ' <�O���S�O>�݌v(����)����
        PrLen = PrLen + Len(Space(10)) ' <�O���S�O>(����)���z

        ' �t�H���g�T�C�Y�̎Z�o
        xMargn = 9
        '2021.08.12 UPGRADE S AIT)phongdv
        'F_SIZE = PRN_FontGet(P_XX * xMargn * 2, P_WIDTH, Basic_F, Space(PrLen))
        F_SIZE = PRN_FontGet(P_XX * xMargn * 2, P_WIDTH, Basic_F, New String(")", PrLen))
        '2021.08.12 UPGRADE E


        ' �P�������E�����̍Đݒ�
        '2021.08.12 UPGRADE S AIT)phongdv
        'P_XX = PRN.TextWidth("M")
        'P_YY = PRN.TextHeight("M")
        P_XX = TextWidthToTwips("M")
        P_YY = TextHeightToTwips("M")
        '2021.08.12 UPGRADE E 

        ' ���ڈ󎚈ʒu�̐ݒ� Y��
        YY(0) = P_YY * 7 ' ���ڏ��
        YY(1) = YY(0) + P_YY * 1.5 ' ���ډ���

        ' ���ڈ󎚈ʒu�̐ݒ� X��
        XX(0) = P_XX * (xMargn - 2) ' �r�����[
        XX(1) = XX(0) + P_XX * 1 ' �H�����ށ{�H��ԍ��{�H�햼��
        XX(2) = XX(1) + P_XX * (24 + 2) ' <�_����z>����
        XX(3) = XX(2) + P_XX * (6 + 2) ' <�_����z>�P��
        XX(4) = XX(3) + P_XX * (4 + 2) ' <�_����z>�P��
        XX(5) = XX(4) + P_XX * (10 + 4) ' <�O������>�ύX�㐔��
        XX(6) = XX(5) + P_XX * (10 + 4) ' <�O������>(����)���z
        XX(7) = XX(6) + P_XX * (6 + 2) ' <�O������>(����)���z
        XX(8) = XX(7) + P_XX * (6 + 2) ' <�O������>�ύX�㐔��
        XX(9) = XX(8) + P_XX * (10 + 4) ' <�O������>(����)���z
        XX(10) = XX(9) + P_XX * (6 + 2) ' <�O������>(����)���z
        XX(11) = XX(10) + P_XX * (6 + 2) ' <�O������>�ύX�㐔��
        XX(12) = XX(11) + P_XX * (10 + 4) ' <�O������>(����)���z
        XX(13) = XX(12) + P_XX * (6 + 2) ' <�O������>(����)���z
        XX(14) = XX(13) + P_XX * (6 + 2) ' <�O������>�ύX�㐔��
        XX(15) = XX(14) + P_XX * (10 + 4) ' <�O������>(����)���z
        XX(16) = XX(15) + P_XX * (6 + 2) ' <�O������>(����)���z
        XX(17) = XX(16) + P_XX * (6 + 2) ' <�O������>(����)���z
        XX(18) = XX(17) + P_XX * (10 + 4) ' <�O������>(����)���z
        XX(19) = P_WIDTH - P_XX * 5 ' �r���E�[

    End Sub

    '-------------------------------------------------------------------------------
    '   ����    :   ���ڈ������(�y�[�W���o��)
    '   �֐�    :   Sub PrItemPD115()
    '   ����    :   �Ȃ�
    '   �ߒl    :   �Ȃ�
    '-------------------------------------------------------------------------------
    Private Sub PrItemPD115(ByRef pryy As Single, ByRef WNo As String, ByRef DT() As WARIDASI_DATA_DBT)

        Dim SQL As String
        '2021.08.03 UPGRADE S  AIT)dannnl
        'Dim Rs As ADODB.Recordset
        'Dim Cnt As Integer
        Dim Rs As New DataTable
        '2021.08.03 UPGRADE E
        Dim OpenFlg As Short
        Dim PR_WK_Renamed As PR_WK
        Dim PR_Text As String : PR_Text = ""
        'Dim yMargn As Single�@�@�@�@�@'2021.08.03 UPGRADE DEL  AIT)dannnl
        Dim i As Object
        Dim j As Short
        Dim lp As Short
        Dim Pos As Short
        Dim Keiyaku As Decimal
        Dim WariName As String

        ' dummy
        PR_WK_Renamed.DT = ""
        PR_WK_Renamed.FS = F_SIZE
        PR_WK_Renamed.X = XX(0)
        PR_WK_Renamed.Y = YY(0)
        Call PRN_DATA(PR_WK_Renamed)

        '���o���f�[�^�ʒu�̎擾�ƌ_����z���v�̎Z�o
        Pos = 0 : Keiyaku = 0
        For lp = 0 To UBound(DT)
            If DT(lp).WARIDASI_NO = WNo Then
                If Pos = 0 Then Pos = lp
                Keiyaku = Keiyaku + DT(lp).G_KINGAKU
            End If
        Next lp

        '----- �w�b�_
        ' �^�C�g��
        '2021.08.12 UPGRADE S AIT)phongdv
        'PR_WK_Renamed.DT = "�@�o�����񍐏��@"
        PR_WK_Renamed.DT = "�o�����񍐏�"
        '2021.08.12 UPGRADE E

        PR_WK_Renamed.FS = 14
        '2021.08.12 UPGRADE S AIT)phongdv
        'PR_WK_Renamed.X = PRN_XGet(1, XX(2), XX(6), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(1, XX(2), XX(6), PR_WK_Renamed)
        '2021.08.12 UPGRADE E 

        PR_WK_Renamed.Y = pryy + (P_YY * 0.75)
        Call PRN_DATA(PR_WK_Renamed, Nothing, Nothing, True)
        Call PRN_LINE(XX(2) + P_XX * 8, pryy + ((P_YY * 1.5) * 1.75), XX(6) - P_XX * 8, pryy + ((P_YY * 1.5) * 1.75), 20, "")
        ' ����
        Call PRN_LINE(XX(6), pryy + ((P_YY * 1.5) * 2), XX(18), pryy + ((P_YY * 1.5) * 2), 20, "")
        Call PRN_LINE(XX(6), pryy + ((P_YY * 1.5) * 2.75), XX(18), pryy + ((P_YY * 1.5) * 2.75), 20, "")
        Call PRN_LINE(XX(0), pryy + ((P_YY * 1.5) * 5.5), XX(18), pryy + ((P_YY * 1.5) * 5.5), 20, "")

        For i = 0 To 3
            For j = 0 To 3
                Call PRN_LINE(XX(6 + (i * 3)) + (((XX(9 + (i * 3)) - XX(6 + (i * 3))) / 3) * j), pryy + ((P_YY * 1.5) * 2), XX(6 + (i * 3)) + (((XX(9 + (i * 3)) - XX(6 + (i * 3))) / 3) * j), pryy + ((P_YY * 1.5) * 5.5), 20, "")
            Next j
        Next i
        ' ����
        For i = 0 To 11
            Select Case i
                Case 0, 3, 6, 9
                    PR_Text = Trim(D_HOUKOKU01)
                Case 1, 4, 7, 10
                    PR_Text = Trim(D_HOUKOKU02)
                Case 2, 5, 8, 11
                    PR_Text = Trim(D_HOUKOKU03)
            End Select
            PR_WK_Renamed.DT = PR_Text
            PR_WK_Renamed.FS = 9
            '2021.08.12 UPGRADE S AIT)phongdv
            'PR_WK_Renamed.X = PRN_XGet(1, XX(6) + (((XX(18) - XX(6)) / 12) * i), XX(6) + (((XX(18) - XX(6)) / 12) * (i + 1)), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
            PRN_XGet(1, XX(6) + (((XX(18) - XX(6)) / 12) * i), XX(6) + (((XX(18) - XX(6)) / 12) * (i + 1)), PR_WK_Renamed)
            '2021.08.12 UPGRADE E 

            PR_WK_Renamed.Y = pryy + ((P_YY * 1.5) * 2)
            Call PRN_DATA(PR_WK_Renamed)
        Next i
        ' ����y�[�W
        '2021.08.03 UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.DT = VB6.Format(P_Cnt) & " ��"
        PR_WK_Renamed.DT = P_Cnt & " ��"
        '2021.08.03 UPGRADE E
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.03 UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(2, XX(0), XX(UBound(XX) - 1), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(0), XX(UBound(XX) - 1), PR_WK_Renamed)
        '2021.08.03 UPGRADE E
        PR_WK_Renamed.Y = pryy
        Call PRN_DATA(PR_WK_Renamed)
        ' �����
        '2021.07.26 UPGRADE S  AIT)Tool Convert
        'PR_WK_Renamed.DT = "������t�F" & VB6.Format(Today, "yyyy/mm/dd")
        PR_WK_Renamed.DT = "������t�F" & Today.ToString("yyyy/MM/dd")
        '2021.07.26 UPGRADE E
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.03 UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(2, XX(0), XX(UBound(XX) - 1), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(0), XX(UBound(XX) - 1), PR_WK_Renamed)
        '2021.08.03 UPGRADE E
        PR_WK_Renamed.Y = pryy + (P_YY * 1.5)
        Call PRN_DATA(PR_WK_Renamed)
        ' �H���ԍ��{�}��
        PR_Text = ""
        If CtlKouji.EDA_NO <> "0000" Then PR_Text = "- " & CtlKouji.EDA_NO & Space(1)
        PR_WK_Renamed.DT = "�H���ԍ��F" & CtlKouji.KOUJI_NO & Space(1) & PR_Text
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.12 UPGRADE S AIT)phongdv
        'PR_WK_Renamed.X = PRN_XGet(0, XX(0), XX(2), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(0, XX(0), XX(2), PR_WK_Renamed)
        '2021.08.12 UPGRADE E 

        PR_WK_Renamed.Y = pryy
        Call PRN_DATA(PR_WK_Renamed)
        ' �H������
        PR_WK_Renamed.DT = "�H�����́F" & GetNameKouji(CtlKouji.KOUJI_NO, CtlKouji.EDA_NO)
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.12 UPGRADE S AIT)phongdv
        'PR_WK_Renamed.X = PRN_XGet(0, XX(0), XX(2), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(0, XX(0), XX(2), PR_WK_Renamed)
        '2021.08.12 UPGRADE E 
        PR_WK_Renamed.Y = pryy + (P_YY * 1.5)
        Call PRN_DATA(PR_WK_Renamed)
        ' �Ǝк���
        PR_Text = ""
        ' (���o���}�X�^���Ǝк��ނ��擾����)
        SQL = "SELECT"
        SQL = SQL & " GYOUSYA_CD, MEISYOU"
        SQL = SQL & " FROM WARIDASI_MAST"
        SQL = SQL & " WHERE"
        SQL = SQL & " KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"
        SQL = SQL & " AND EDA_NO = '" & KeyKouji.EDA_NO & "'"
        SQL = SQL & " AND WARIDASI_NO = '" & DT(Pos).WARIDASI_NO & "'"
        ' SQL�����s
        '2021.08.03 UPGRADE S  AIT)dannnl
        'Rs = SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText)
        Rs = RsOpen(SQL)
        '2021.08.03 UPGRADE E
        OpenFlg = 1
        '2021.08.03 UPGRADE S  AIT)dannnl
        'PR_Text = Rs.Fields("GYOUSYA_CD").Value
        'WariName = Rs.Fields("MEISYOU").Value
        'Rs.Close()
        PR_Text = Rs.Rows(0)("GYOUSYA_CD")
        WariName = Rs.Rows(0)("MEISYOU")
        Rs.Dispose()
        '2021.08.03 UPGRADE E
        Rs = Nothing
        ' �Ǝк���
        PR_WK_Renamed.DT = "�Ǝк��ށF" & Space(1) & PR_Text
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.12 UPGRADE S AIT)phongdv
        'PR_WK_Renamed.X = PRN_XGet(0, XX(6), XX(10), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(0, XX(6), XX(10), PR_WK_Renamed)
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.Y = pryy
        Call PRN_DATA(PR_WK_Renamed)
        ' �ƎЖ���
        PR_WK_Renamed.DT = "�ƎЖ��́F" & Space(1) & GetNameGyousya(PR_Text)
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.12 UPGRADE S AIT)phongdv
        'PR_WK_Renamed.X = PRN_XGet(0, XX(6), XX(10), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(0, XX(6), XX(10), PR_WK_Renamed)
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.Y = pryy + (P_YY * 1.5)
        Call PRN_DATA(PR_WK_Renamed)
        ' �����(���o��)
        PR_WK_Renamed.DT = "����ҁF" & Space(1) & GetNameSyain(CtlSyain.SYAIN_CD)
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.12 UPGRADE S AIT)phongdv
        'PR_WK_Renamed.X = PRN_XGet(0, XX(11) + P_XX * 5, XX(15) + P_XX * 5, PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(0, XX(11) + P_XX * 5, XX(15) + P_XX * 5, PR_WK_Renamed)
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.Y = pryy + (P_YY * 1.5)
        Call PRN_DATA(PR_WK_Renamed)
        Call PRN_LINE(XX(11) + P_XX * 5, pryy + ((P_YY * 1.5) * 1.75), XX(15) + P_XX * 5, pryy + (P_YY * 1.5) * 1.75, 20, "")
        ' �����(��ӗ�)
        PR_WK_Renamed.DT = "��"
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.12 UPGRADE S AIT)phongdv
        'PR_WK_Renamed.X = PRN_XGet(2, XX(11) + P_XX * 5, XX(15) + P_XX * 5, PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(11) + P_XX * 5, XX(15) + P_XX * 5, PR_WK_Renamed)
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.Y = pryy + (P_YY * 1.5)
        Call PRN_DATA(PR_WK_Renamed)
        ' �O����
        '    PR_WK.DT = "�O����F" & Space(1) & DT(Pos).WARIDASI_NO & Space(1) & WariName
        '    PR_WK.FS = F_SIZE - 1
        '    PR_WK.X = PRN_XGet(0, XX(0), XX(2), PR_WK.FS, PR_WK.DT)
        '    PR_WK.Y = pryy + ((P_YY * 1.5) * 2.75)
        '    Call PRN_DATA(PR_WK)
        ' �_����z
        '2021.08.03 UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.DT = "�_����z�F" & Space(1) & VB6.Format(Keiyaku, "#,###,###,##0")
        PR_WK_Renamed.DT = "�_����z�F" & Space(1) & Keiyaku.ToString("#,###,###,##0")
        '2021.08.03 UPGRADE E
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.12 UPGRADE S AIT)phongdv
        'PR_WK_Renamed.X = PRN_XGet(0, XX(0), XX(2), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(0, XX(0), XX(2), PR_WK_Renamed)
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.Y = pryy + ((P_YY * 1.5) * 4.5)
        Call PRN_DATA(PR_WK_Renamed)

    End Sub

    '-------------------------------------------------------------------------------
    '   ����    :   ���ڈ������(���ڌ��o��)
    '   �֐�    :   Sub PrItemD115()
    '   ����    :   DT  DEKIDAKA_DATA_DBT
    '   �ߒl    :   �Ȃ�
    '-------------------------------------------------------------------------------
    Private Sub PrItemD115(ByRef pryy As Single)

        '2021.08.03 UPGRADE DEL S  AIT)dannnl
        'Dim SQL As String
        'Dim Rs As ADODB.Recordset
        'Dim Cnt As Integer
        'Dim OpenFlg As Short
        '2021.08.03 UPGRADE DEL E
        Dim PR_WK_Renamed As PR_WK
        'Dim PR_Text As String�@�@�@�@�@'2021.08.03 UPGRADE DEL  AIT)dannnl
        Dim yMargn As Single
        Dim i As Short

        '----- ����
        Call PRN_LINE(XX(0), pryy, XX(0), P_HEIGHT - (P_YY * 4.25), 20, "")

        For i = 2 To 18
            Select Case i
                Case 2, 6, 9, 12, 15, 18
                    Call PRN_LINE(XX(i), pryy, XX(i), P_HEIGHT - (P_YY * 4.25), 20, "")
                Case 3, 4
                    Call PRN_LINE(XX(i), pryy + (P_YY * 1.5), XX(i), P_HEIGHT - (P_YY * 4.25) - ((P_YY * 1.5) * 3), 20, "")
                Case Else
                    Call PRN_LINE(XX(i), pryy + (P_YY * 1.5), XX(i), P_HEIGHT - (P_YY * 4.25), 20, "")
            End Select
        Next i

        '----- �]��
        yMargn = P_YY * 0.25

        Call PRN_LINE(XX(2), pryy + (P_YY * 1.5), XX(18), pryy + (P_YY * 1.5), 20, "")
        Call PRN_LINE(XX(0), pryy + ((P_YY * 1.5) * 3), XX(18), pryy + ((P_YY * 1.5) * 3), 20, "")
        Call PRN_LINE(XX(0), P_HEIGHT - (P_YY * 4.25), XX(18), P_HEIGHT - (P_YY * 4.25), 20, "")

        ' �_����z��
        PR_WK_Renamed.DT = "�_����z"
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.12 UPGRADE S AIT)phongdv
        'PR_WK_Renamed.X = PRN_XGet(1, XX(2), XX(6), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(1, XX(2), XX(6), PR_WK_Renamed)
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        '----- �񍀖�
        ' �H�����ށ{�H��ԍ��{�H�햼��
        PR_WK_Renamed.DT = "�H�햼��"
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.12 UPGRADE S AIT)phongdv
        'PR_WK_Renamed.X = PRN_XGet(1, XX(1), XX(2), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(1, XX(1), XX(2), PR_WK_Renamed)
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + (P_YY * 2.25)
        Call PRN_DATA(PR_WK_Renamed)
        ' ����
        PR_WK_Renamed.DT = "����"
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.12 UPGRADE S AIT)phongdv
        'PR_WK_Renamed.X = PRN_XGet(1, XX(2), XX(3), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(1, XX(2), XX(3), PR_WK_Renamed)
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + (P_YY * 2.25)
        Call PRN_DATA(PR_WK_Renamed)
        ' �P��
        PR_WK_Renamed.DT = "�P��"
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.12 UPGRADE S AIT)phongdv
        'PR_WK_Renamed.X = PRN_XGet(1, XX(3), XX(4), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(1, XX(3), XX(4), PR_WK_Renamed)
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + (P_YY * 2.25)
        Call PRN_DATA(PR_WK_Renamed)
        ' �P��
        PR_WK_Renamed.DT = "�P��"
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.12 UPGRADE S AIT)phongdv
        'PR_WK_Renamed.X = PRN_XGet(1, XX(4), XX(5), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(1, XX(4), XX(5), PR_WK_Renamed)
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + (P_YY * 2.25)
        Call PRN_DATA(PR_WK_Renamed)
        ' ���z
        PR_WK_Renamed.DT = "���z"
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.12 UPGRADE S AIT)phongdv
        'PR_WK_Renamed.X = PRN_XGet(1, XX(5), XX(6), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(1, XX(5), XX(6), PR_WK_Renamed)
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + (P_YY * 2.25)
        Call PRN_DATA(PR_WK_Renamed)
        ' (������)�ύX�㐔��
        PR_WK_Renamed.DT = "�ύX��"
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.12 UPGRADE S AIT)phongdv
        'PR_WK_Renamed.X = PRN_XGet(1, XX(6), XX(7), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(1, XX(6), XX(7), PR_WK_Renamed)
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + (P_YY * 1.5)
        Call PRN_DATA(PR_WK_Renamed)
        PR_WK_Renamed.DT = "����"
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.12 UPGRADE S AIT)phongdv
        'PR_WK_Renamed.X = PRN_XGet(1, XX(6), XX(7), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(1, XX(6), XX(7), PR_WK_Renamed)
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + ((P_YY * 1.5) * 2)
        Call PRN_DATA(PR_WK_Renamed)
        ' (������)�݌v����
        PR_WK_Renamed.DT = "�݌v"
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.12 UPGRADE S AIT)phongdv
        'PR_WK_Renamed.X = PRN_XGet(1, XX(7), XX(8), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(1, XX(7), XX(8), PR_WK_Renamed)
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + (P_YY * 1.5)
        Call PRN_DATA(PR_WK_Renamed)
        PR_WK_Renamed.DT = "����"
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.12 UPGRADE S AIT)phongdv
        'PR_WK_Renamed.X = PRN_XGet(1, XX(7), XX(8), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(1, XX(7), XX(8), PR_WK_Renamed)
        PR_WK_Renamed.Y = pryy + yMargn + ((P_YY * 1.5) * 2)
        Call PRN_DATA(PR_WK_Renamed)
        ' (������)���z
        PR_WK_Renamed.DT = "���z"
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.12 UPGRADE S AIT)phongdv
        'PR_WK_Renamed.X = PRN_XGet(1, XX(8), XX(9), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(1, XX(8), XX(9), PR_WK_Renamed)
        PR_WK_Renamed.Y = pryy + yMargn + (P_YY * 2.25)
        Call PRN_DATA(PR_WK_Renamed)
        ' (�O����)�ύX�㐔��
        PR_WK_Renamed.DT = "�ύX��"
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.12 UPGRADE S AIT)phongdv
        'PR_WK_Renamed.X = PRN_XGet(1, XX(9), XX(10), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(1, XX(9), XX(10), PR_WK_Renamed)
        PR_WK_Renamed.Y = pryy + yMargn + (P_YY * 1.5)
        Call PRN_DATA(PR_WK_Renamed)
        PR_WK_Renamed.DT = "����"
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.12 UPGRADE S AIT)phongdv
        'PR_WK_Renamed.X = PRN_XGet(1, XX(9), XX(10), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(1, XX(9), XX(10), PR_WK_Renamed)
        PR_WK_Renamed.Y = pryy + yMargn + ((P_YY * 1.5) * 2)
        Call PRN_DATA(PR_WK_Renamed)
        ' (�O����)�݌v����
        PR_WK_Renamed.DT = "�݌v"
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.12 UPGRADE S AIT)phongdv
        'PR_WK_Renamed.X = PRN_XGet(1, XX(10), XX(11), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(1, XX(10), XX(11), PR_WK_Renamed)
        PR_WK_Renamed.Y = pryy + yMargn + (P_YY * 1.5)
        Call PRN_DATA(PR_WK_Renamed)
        PR_WK_Renamed.DT = "����"
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.12 UPGRADE S AIT)phongdv
        'PR_WK_Renamed.X = PRN_XGet(1, XX(10), XX(11), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(1, XX(10), XX(11), PR_WK_Renamed)
        PR_WK_Renamed.Y = pryy + yMargn + ((P_YY * 1.5) * 2)
        Call PRN_DATA(PR_WK_Renamed)
        ' (�O����)���z
        PR_WK_Renamed.DT = "���z"
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.12 UPGRADE S AIT)phongdv
        ' PR_WK_Renamed.X = PRN_XGet(1, XX(11), XX(12), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(1, XX(11), XX(12), PR_WK_Renamed)
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + (P_YY * 2.25)
        Call PRN_DATA(PR_WK_Renamed)
        ' (�Q���O)�ύX�㐔��
        PR_WK_Renamed.DT = "�ύX��"
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.12 UPGRADE S AIT)phongdv
        ' PR_WK_Renamed.X = PRN_XGet(1, XX(12), XX(13), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(1, XX(12), XX(13), PR_WK_Renamed)
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + (P_YY * 1.5)
        Call PRN_DATA(PR_WK_Renamed)
        PR_WK_Renamed.DT = "����"
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.12 UPGRADE S AIT)phongdv
        ' PR_WK_Renamed.X = PRN_XGet(1, XX(12), XX(13), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(1, XX(12), XX(13), PR_WK_Renamed)
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + ((P_YY * 1.5) * 2)
        Call PRN_DATA(PR_WK_Renamed)
        ' (�Q���O)�݌v����
        PR_WK_Renamed.DT = "�݌v"
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.12 UPGRADE S AIT)phongdv
        ' PR_WK_Renamed.X = PRN_XGet(1, XX(13), XX(14), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(1, XX(13), XX(14), PR_WK_Renamed)
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + (P_YY * 1.5)
        Call PRN_DATA(PR_WK_Renamed)
        PR_WK_Renamed.DT = "����"
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.12 UPGRADE S AIT)phongdv
        ' PR_WK_Renamed.X = PRN_XGet(1, XX(13), XX(14), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(1, XX(13), XX(14), PR_WK_Renamed)
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + ((P_YY * 1.5) * 2)
        Call PRN_DATA(PR_WK_Renamed)
        ' (�Q���O)���z
        PR_WK_Renamed.DT = "���z"
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.12 UPGRADE S AIT)phongdv
        ' PR_WK_Renamed.X = PRN_XGet(1, XX(14), XX(15), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(1, XX(14), XX(15), PR_WK_Renamed)
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + (P_YY * 2.25)
        Call PRN_DATA(PR_WK_Renamed)
        ' (�R���O)�ύX�㐔��
        PR_WK_Renamed.DT = "�ύX��"
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.12 UPGRADE S AIT)phongdv
        ' PR_WK_Renamed.X = PRN_XGet(1, XX(15), XX(16), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(1, XX(15), XX(16), PR_WK_Renamed)
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + (P_YY * 1.5)
        Call PRN_DATA(PR_WK_Renamed)
        PR_WK_Renamed.DT = "����"
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.12 UPGRADE S AIT)phongdv
        ' PR_WK_Renamed.X = PRN_XGet(1, XX(15), XX(16), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(1, XX(15), XX(16), PR_WK_Renamed)
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + ((P_YY * 1.5) * 2)
        Call PRN_DATA(PR_WK_Renamed)
        ' (�R���O)�݌v����
        PR_WK_Renamed.DT = "�݌v"
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.12 UPGRADE S AIT)phongdv
        ' PR_WK_Renamed.X = PRN_XGet(1, XX(16), XX(17), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(1, XX(16), XX(17), PR_WK_Renamed)
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + (P_YY * 1.5)
        Call PRN_DATA(PR_WK_Renamed)
        PR_WK_Renamed.DT = "����"
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.12 UPGRADE S AIT)phongdv
        ' PR_WK_Renamed.X = PRN_XGet(1, XX(16), XX(17), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(1, XX(16), XX(17), PR_WK_Renamed)
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + ((P_YY * 1.5) * 2)
        Call PRN_DATA(PR_WK_Renamed)
        ' (�R���O)���z
        PR_WK_Renamed.DT = "���z"
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.12 UPGRADE S AIT)phongdv
        ' PR_WK_Renamed.X = PRN_XGet(1, XX(17), XX(18), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(1, XX(17), XX(18), PR_WK_Renamed)
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + (P_YY * 2.25)
        Call PRN_DATA(PR_WK_Renamed)

    End Sub

    '-------------------------------------------------------------------------------
    '   ����    :   �f�[�^�������(�_��f�[�^�E����o�����f�[�^)
    '   �֐�    :   Sub PrDataD115()
    '   ����    :   Pryy    ����x�ʒu
    '   �@�@        DT      WARIDASI_DATA_DBT
    '   �ߒl    :   �Ȃ�
    '-------------------------------------------------------------------------------
    Private Sub PrDataD115(ByRef pryy As Single, ByRef DT As WARIDASI_DATA_DBT, ByRef W_KOUSYU_CDNO As String, ByRef DT2 As DEKIDAKA_DATA_DBT, ByRef M_Cnt As Integer, ByRef GD_KEI As Decimal, ByRef SD_KEI As Decimal)

        '2021.08.03 UPGRADE DEL S  AIT)dannnl
        'Dim SQL As String
        'Dim Rs As ADODB.Recordset
        'Dim OpenFlg As Short
        '2021.08.03 UPGRADE DEL E
        Dim Cnt2 As Integer : Cnt2 = 0
        'Dim lp2 As Integer�@�@�@�@�@'2021.08.03 UPGRADE DEL  AIT)dannnl
        Dim PR_WK_Renamed As PR_WK
        Dim PR_Text As String
        Dim yMargn As Single

        '----- �]��
        yMargn = P_YY * 0.25

        '----- ���o�f�[�^
        ' �H�햼��
        PR_WK_Renamed.DT = Space(1) & GetvbUnicode(DT.MEISYOU, 24)
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.12 UPGRADE S AIT)phongdv
        'PR_WK_Renamed.X = PRN_XGet(0, XX(1), XX(2), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(0, XX(1), XX(2), PR_WK_Renamed)
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' ����
        '2021.08.03 UPGRADE S  AIT)dannnl
        'PR_Text = VB6.Format(DT.G_SUURYOU, "#####.##")
        PR_Text = DT.G_SUURYOU.ToString("#####.##")
        '2021.08.03 UPGRADE E
        If Right(PR_Text, 1) = "." Then PR_Text = Left(PR_Text, Len(PR_Text) - 1)
        If Left(PR_Text, 1) = "." Then PR_Text = "0" & PR_Text
        PR_WK_Renamed.DT = PR_Text
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.12 UPGRADE S AIT)phongdv
        ' PR_WK_Renamed.X = PRN_XGet(2, XX(2), XX(3), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(2), XX(3), PR_WK_Renamed)
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' �P��
        PR_WK_Renamed.DT = Trim(DT.TANI)
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.12 UPGRADE S AIT)phongdv
        ' PR_WK_Renamed.X = PRN_XGet(1, XX(3), XX(4), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(1, XX(3), XX(4), PR_WK_Renamed)
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' �P��
        '2021.08.03 UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.DT = VB6.Format(DT.G_TANKA, "#,###,###,##0")
        PR_WK_Renamed.DT = DT.G_TANKA.ToString("#,###,###,##0")
        '2021.08.03 UPGRADE E
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.12 UPGRADE S AIT)phongdv
        ' PR_WK_Renamed.X = PRN_XGet(2, XX(4), XX(5), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(4), XX(5), PR_WK_Renamed)
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' ���z
        '2021.08.03 UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.DT = VB6.Format(DT.G_KINGAKU, "#,###,###,##0")
        PR_WK_Renamed.DT = DT.G_KINGAKU.ToString("#,###,###,##0")
        '2021.08.03 UPGRADE E
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.12 UPGRADE S AIT)phongdv
        ' PR_WK_Renamed.X = PRN_XGet(2, XX(5), XX(6), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(5), XX(6), PR_WK_Renamed)
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)

        '----- �o�����f�[�^
        ' (������)�ύX�㐔��
        '2021.08.03 UPGRADE S  AIT)dannnl
        'PR_Text = VB6.Format(DT2.HENKOU_SUU, "#####.##")
        PR_Text = DT2.HENKOU_SUU.ToString("#####.##")
        '2021.08.03 UPGRADE E
        If Right(PR_Text, 1) = "." Then PR_Text = Left(PR_Text, Len(PR_Text) - 1)
        If Left(PR_Text, 1) = "." Then PR_Text = "0" & PR_Text
        PR_WK_Renamed.DT = PR_Text
        '2021.08.12 UPGRADE S AIT)phongdv
        PR_WK_Renamed.FS = F_SIZE - 1
        ' PR_WK_Renamed.X = PRN_XGet(2, XX(6 + (M_Cnt * 3)), XX(7 + (M_Cnt * 3)), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(6 + (M_Cnt * 3)), XX(7 + (M_Cnt * 3)), PR_WK_Renamed)
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' (������)�݌v����
        '2021.08.03 UPGRADE S  AIT)dannnl
        'PR_Text = VB6.Format(DT2.JITU_SUU + DT2.RUI_SUU, "#####.##")
        PR_Text = (DT2.JITU_SUU + DT2.RUI_SUU).ToString("#####.##")
        '2021.08.03 UPGRADE E
        If Right(PR_Text, 1) = "." Then PR_Text = Left(PR_Text, Len(PR_Text) - 1)
        If Left(PR_Text, 1) = "." Then PR_Text = "0" & PR_Text
        PR_WK_Renamed.DT = PR_Text
        '2021.08.12 UPGRADE S AIT)phongdv
        PR_WK_Renamed.FS = F_SIZE - 1
        ' PR_WK_Renamed.X = PRN_XGet(2, XX(7 + (M_Cnt * 3)), XX(8 + (M_Cnt * 3)), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(7 + (M_Cnt * 3)), XX(8 + (M_Cnt * 3)), PR_WK_Renamed)
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' (������)���z
        '2021.08.03 UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.DT = VB6.Format(DT2.JITU_GAKU + DT2.RUI_GAKU, "#,###,###,##0")
        PR_WK_Renamed.DT = (DT2.JITU_GAKU + DT2.RUI_GAKU).ToString("#,###,###,##0")
        '2021.08.03 UPGRADE E
        '2021.08.12 UPGRADE S AIT)phongdv
        PR_WK_Renamed.FS = F_SIZE - 1
        ' PR_WK_Renamed.X = PRN_XGet(2, XX(8 + (M_Cnt * 3)), XX(9 + (M_Cnt * 3)), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(8 + (M_Cnt * 3)), XX(9 + (M_Cnt * 3)), PR_WK_Renamed)
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' �e���z���v����
        GD_KEI = GD_KEI + DT2.JITU_GAKU + DT2.RUI_GAKU
        SD_KEI = SD_KEI + DT2.RUI_GAKU

    End Sub

    '-------------------------------------------------------------------------------
    '   ����    :   �f�[�^�������(���o�f�[�^�E�挎���o�����f�[�^)
    '   �֐�    :   Sub PrData2D115()
    '   ����    :   pryy    ����x�ʒu
    '   �@�@        DT()    WARIDASI_DATA_DBT
    '   �@�@        DT2()   DEKIDAKA_DATA_DBT
    '   �ߒl    :   �Ȃ�
    '-------------------------------------------------------------------------------
    Private Sub PrData2D115(ByRef pryy As Single, ByRef DT As WARIDASI_DATA_DBT, ByRef DT2 As DEKIDAKA_DATA_DBT, ByRef M_Cnt As Integer, ByRef W_KOUSYU_CDNO As String, ByRef W_SIMEYM() As String, ByRef G_SIMEID As Integer, ByRef DT_KEI() As Decimal, ByRef DT_SEN() As Decimal, ByRef NewPage_Flag As String)

        Dim SQL As String
        '2021.08.03 UPGRADE S  AIT)dannnl
        'Dim Rs As ADODB.Recordset
        Dim Rs As New DataTable
        '2021.08.03 UPGRADE E
        Dim OpenFlg As Short
        Dim DT3() As DEKIDAKA_DATA_DBT
        Dim Cnt As Integer
        Dim lp As Integer
        'Dim lpMax As Integer�@�@�@�@�@'2021.08.03 UPGRADE DEL  AIT)dannnl
        Dim lp2 As Integer
        Dim Pos As Integer
        Dim PR_WK_Renamed As PR_WK
        Dim PR_Text As String
        Dim yMargn As Single
        Dim i As Object
        Dim j As Short
        Dim SUMIIN(9) As Single

        'If M_Cnt = 0 Then Exit Sub

        '---��
        yMargn = P_YY * 0.25

        If CBool(NewPage_Flag) = False Then
            If DT.KOUSYU_CD & DT.KOUSYU_NO <> W_KOUSYU_CDNO Then
                ' �H�����ށ{�H��ԍ�
                'PR_Text = DT.KOUSYU_CD & "-" & DT.KOUSYU_NO & Space(1) & _
                ''           GetNameKousyu("01", DT.KOUSYU_CD, "00") & "-" & _
                ''           GetNameKousyu("01", DT.KOUSYU_CD, DT.KOUSYU_NO)
                PR_Text = GetNameKousyu("01", DT.KOUSYU_CD, "00") & "-" & GetNameKousyu("01", DT.KOUSYU_CD, DT.KOUSYU_NO)
                PR_WK_Renamed.DT = GetvbUnicode(PR_Text, 24)
                PR_WK_Renamed.FS = F_SIZE - 1
                '2021.08.12 UPGRADE S AIT)phongdv
                'PR_WK_Renamed.X = PRN_XGet(0, XX(1), XX(2), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
                PRN_XGet(0, XX(1), XX(2), PR_WK_Renamed)
                '2021.08.12 UPGRADE E
                PR_WK_Renamed.Y = pryy + yMargn
                Call PRN_DATA(PR_WK_Renamed)
                W_KOUSYU_CDNO = DT.KOUSYU_CD & DT.KOUSYU_NO
                pryy = pryy + (P_YY * 1.5)

                '2021.08.12 UPGRADE S AIT)phongdv
                'Call PRN_LINE(XX(0), pryy, XX(18), pryy, 1, "", VSDraw7Lib.PenStyleSettings.psDot)
                Call PRN_LINE(XX(0), pryy, XX(18), pryy, 1, "", DashStyle.Dot)
                '2021.08.12 UPGRADE E
            End If

            ' �o����(�O����)�f�[�^
            SQL = "SELECT"
            SQL = SQL & " KOUJI_NO,"
            SQL = SQL & " EDA_NO,"
            SQL = SQL & " KOUSYU_CD,"
            SQL = SQL & " KOUSYU_NO,"
            SQL = SQL & " MEISAI_NO,"
            SQL = SQL & " SIME_YM," ' ���N��
            SQL = SQL & " HENKOU_SUU," ' �ύX�㐔��
            SQL = SQL & " RUI_SUU," ' �O�񖘗ݐϐ���
            SQL = SQL & " RUI_GAKU," ' �O�񖘗ݐϋ��z
            SQL = SQL & " JITU_SUU," ' ���ѐ���
            SQL = SQL & " JITU_GAKU" ' ���ы��z
            SQL = SQL & " FROM DEKIDAKA_DATA"
            SQL = SQL & " WHERE KOUJI_NO = '" & DT2.KOUJI_NO & "'"
            SQL = SQL & " AND EDA_NO = '" & DT2.EDA_NO & "'"
            SQL = SQL & " AND KOUSYU_CD = '" & DT2.KOUSYU_CD & "'"
            SQL = SQL & " AND KOUSYU_NO = '" & DT2.KOUSYU_NO & "'"
            SQL = SQL & " AND MEISAI_NO = " & DT2.MEISAI_NO ' ���הԍ�
            SQL = SQL & " AND SIME_YM < '" & DT2.SIME_YM & "'"
            SQL = SQL & " ORDER BY SIME_YM,KOUSYU_CD,KOUSYU_NO,MEISAI_NO"

            'SQL�����s
            '2021.08.03 UPGRADE S  AIT)dannnl
            'Rs = SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText)
            Rs = RsOpen(SQL)
            '2021.08.03 UPGRADE E
            OpenFlg = 1

            Cnt = 0
            '2021.08.03 UPGRADE S  AIT)dannnl
            'Do Until Rs.EOF
            For Each Row As DataRow In Rs.Rows
                '2021.08.03 UPGRADE E
                ReDim Preserve DT3(Cnt)
                Call CLEAR_DEKIDAKA_DATA(DT3(Cnt))
                With DT3(Cnt)
                    '2021.08.03 UPGRADE S  AIT)dannnl
                    '.KOUJI_NO = Rs.Fields("KOUJI_NO").Value
                    '.EDA_NO = Rs.Fields("EDA_NO").Value
                    '.KOUSYU_CD = Rs.Fields("KOUSYU_CD").Value
                    '.KOUSYU_NO = Rs.Fields("KOUSYU_NO").Value
                    '.MEISAI_NO = Rs.Fields("MEISAI_NO").Value
                    '.SIME_YM = Rs.Fields("SIME_YM").Value
                    '.HENKOU_SUU = Rs.Fields("HENKOU_SUU").Value
                    '.RUI_SUU = Rs.Fields("RUI_SUU").Value
                    '.RUI_GAKU = Rs.Fields("RUI_GAKU").Value
                    '.JITU_SUU = Rs.Fields("JITU_SUU").Value
                    '.JITU_GAKU = Rs.Fields("JITU_GAKU").Value
                    .KOUJI_NO = Row("KOUJI_NO")
                    .EDA_NO = Row("EDA_NO")
                    .KOUSYU_CD = Row("KOUSYU_CD")
                    .KOUSYU_NO = Row("KOUSYU_NO")
                    .MEISAI_NO = Row("MEISAI_NO")
                    .SIME_YM = Row("SIME_YM")
                    .HENKOU_SUU = Row("HENKOU_SUU")
                    .RUI_SUU = Row("RUI_SUU")
                    .RUI_GAKU = Row("RUI_GAKU")
                    .JITU_SUU = Row("JITU_SUU")
                    .JITU_GAKU = Row("JITU_GAKU")
                    '2021.08.03 UPGRADE E
                End With
                Cnt = Cnt + 1
                '2021.08.03 UPGRADE S  AIT)dannnl
                '	Rs.MoveNext()
                'Loop
            Next
            '2021.08.03 UPGRADE E
        Else
            Cnt = M_Cnt
        End If

        '�ψ�󎚈ʒu�̎擾
        lp = 0
        For i = 0 To 2
            If lp > 9 Then Exit For
            For j = 0 To 2
                SUMIIN(lp) = XX(6 + (i * 3)) + (((XX(9 + (i * 3)) - XX(6 + (i * 3))) / 3) * j)
                lp = lp + 1
                If lp > 9 Then Exit For
            Next j
        Next i
        SUMIIN(lp) = XX(12) + (((XX(15) - XX(12)) / 3) * 3)
        For lp = 0 To M_Cnt - 1
            For i = 1 To 3
                ' �ψ�
                PR_WK_Renamed.DT = "��"
                PR_WK_Renamed.FS = 14
                '2021.08.12 UPGRADE S AIT)phongdv
                'PR_WK_Renamed.X = PRN_XGet(1, SUMIIN(0 + (i - 1) + (lp * 3)), SUMIIN(0 + i + (lp * 3)), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
                PRN_XGet(1, SUMIIN(0 + (i - 1) + (lp * 3)), SUMIIN(0 + i + (lp * 3)), PR_WK_Renamed)
                '2021.08.12 UPGRADE E
                PR_WK_Renamed.Y = P_YY * 5 + ((P_YY * 1.5) * 3.5) + yMargn
                Call PRN_DATA(PR_WK_Renamed)
            Next i
        Next lp

        If CBool(NewPage_Flag) = True Then Exit Sub

        '---�f�[�^��
        For lp = 0 To Cnt - 1
            Pos = -1
            For lp2 = 0 To M_Cnt - 1
                If DT3(lp).SIME_YM = W_SIMEYM(lp2) Then
                    Pos = lp2
                    Exit For
                End If
            Next lp2
            If Pos > -1 Then
                ' (�O����)�ύX�㐔��
                PR_Text = ""
                '2021.08.03 UPGRADE S  AIT)dannnl
                'PR_Text = VB6.Format(DT3(lp).HENKOU_SUU, "#####.##")
                PR_Text = DT3(lp).HENKOU_SUU.ToString("#####.##")
                '2021.08.03 UPGRADE E
                If Right(PR_Text, 1) = "." Then PR_Text = Left(PR_Text, Len(PR_Text) - 1)
                If Left(PR_Text, 1) = "." Then PR_Text = "0" & PR_Text
                PR_WK_Renamed.DT = PR_Text
                PR_WK_Renamed.FS = F_SIZE - 1
                '2021.08.12 UPGRADE S AIT)phongdv
                ' PR_WK_Renamed.X = PRN_XGet(2, XX(6 + (Pos * 3)), XX(7 + (Pos * 3)), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
                PRN_XGet(2, XX(6 + (Pos * 3)), XX(7 + (Pos * 3)), PR_WK_Renamed)
                '2021.08.12 UPGRADE E
                PR_WK_Renamed.Y = pryy + yMargn
                Call PRN_DATA(PR_WK_Renamed)
                ' (�O����)�݌v����
                PR_Text = ""
                '2021.08.03 UPGRADE S  AIT)dannnl
                'PR_Text = VB6.Format(DT3(lp).JITU_SUU + DT3(lp).RUI_SUU, "#####.##")
                PR_Text = (DT3(lp).JITU_SUU + DT3(lp).RUI_SUU).ToString("#####.##")
                '2021.08.03 UPGRADE E
                If Right(PR_Text, 1) = "." Then PR_Text = Left(PR_Text, Len(PR_Text) - 1)
                If Left(PR_Text, 1) = "." Then PR_Text = "0" & PR_Text
                PR_WK_Renamed.DT = PR_Text
                PR_WK_Renamed.FS = F_SIZE - 1
                '2021.08.12 UPGRADE S AIT)phongdv
                ' PR_WK_Renamed.X = PRN_XGet(2, XX(7 + (Pos * 3)), XX(8 + (Pos * 3)), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
                PRN_XGet(2, XX(7 + (Pos * 3)), XX(8 + (Pos * 3)), PR_WK_Renamed)
                '2021.08.12 UPGRADE E
                PR_WK_Renamed.Y = pryy + yMargn
                Call PRN_DATA(PR_WK_Renamed)
                ' (�O����)���z
                '2021.08.03 UPGRADE S  AIT)dannnl
                'PR_WK_Renamed.DT = VB6.Format(DT3(lp).JITU_GAKU + DT3(lp).RUI_GAKU, "#,###,###,##0")
                PR_WK_Renamed.DT = (DT3(lp).JITU_GAKU + DT3(lp).RUI_GAKU).ToString("#,###,###,##0")
                '2021.08.03 UPGRADE E
                PR_WK_Renamed.FS = F_SIZE - 1
                '2021.08.12 UPGRADE S AIT)phongdv
                ' PR_WK_Renamed.X = PRN_XGet(2, XX(8 + (Pos * 3)), XX(9 + (Pos * 3)), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
                PRN_XGet(2, XX(8 + (Pos * 3)), XX(9 + (Pos * 3)), PR_WK_Renamed)
                '2021.08.12 UPGRADE E
                PR_WK_Renamed.Y = pryy + yMargn
                Call PRN_DATA(PR_WK_Renamed)
                ' �e���v���z����
                DT_KEI(Pos) = DT_KEI(Pos) + DT3(lp).JITU_GAKU + DT3(lp).RUI_GAKU
                DT_SEN(Pos) = DT_SEN(Pos) + DT3(lp).RUI_GAKU
            End If
        Next lp

    End Sub

    '-------------------------------------------------------------------------------
    '   ����    :   �e�f�[�^���v�������
    '   �֐�    :   Sub PrData2D115()
    '   ����    :   pryy    ����x�ʒu
    '   �@�@        W_SIMEYM()  ���N��
    '   �@�@        DT_KEI()    �������o�����݌v(4������)
    '   �@�@        DT_SEN()    �挎���o�����݌v(4������)
    '   �@�@        GD_KEI      �����o�����v
    '   �@�@        SD_KEI      �挎���o�����v
    '   �ߒl    :   �Ȃ�
    '-------------------------------------------------------------------------------
    Private Sub PrDataGD115(ByRef pryy As Single, ByRef W_SIMEYM() As String, ByRef DT_KEI() As Decimal, ByRef DT_SEN() As Decimal, ByRef GD_KEI As Decimal, ByRef SD_KEI As Decimal, ByRef M_Cnt As Integer, ByRef NewPage_Flag As String)

        Dim PR_WK_Renamed As PR_WK
        Dim PR_Text As String : PR_Text = ""
        Dim yMargn As Single
        Dim i As Short
        Dim prnGKEI_Flag As String : prnGKEI_Flag = CStr(False)
        Dim prnSKEI_Flag As String : prnSKEI_Flag = CStr(False)
        Dim prnKKEI_Flag As String : prnKKEI_Flag = CStr(False)

        '----- �]��
        yMargn = P_YY * 0.25

        ' ���N��
        For i = 0 To 3
            If W_SIMEYM(i) <> "" Then
                '2021.07.26 UPGRADE S  AIT)Tool Convert
                'PR_Text = VB6.Format(W_SIMEYM(i), "0000/00")
                PR_Text = CDec(W_SIMEYM(i)).ToString("0000/00")
                '2021.07.26 UPGRADE E
                PR_WK_Renamed.DT = PR_Text
                PR_WK_Renamed.FS = F_SIZE
                '2021.08.12 UPGRADE S AIT)phongdv
                'PR_WK_Renamed.X = PRN_XGet(1, XX(6 + (i * 3)), XX(9 + (i * 3)), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
                PRN_XGet(1, XX(6 + (i * 3)), XX(9 + (i * 3)), PR_WK_Renamed)
                '2021.08.12 UPGRADE E
                PR_WK_Renamed.Y = P_YY * 5 + ((P_YY * 1.5) * 5.5) + yMargn
                Call PRN_DATA(PR_WK_Renamed)
            End If
        Next i

        If CBool(NewPage_Flag) = True Then
            Call PRN_LINE(XX(3), P_HEIGHT - (P_YY * 4.25) - ((P_YY * 1.5) * 3), XX(3), P_HEIGHT - (P_YY * 4.25), 20, "")
            Call PRN_LINE(XX(4), P_HEIGHT - (P_YY * 4.25) - ((P_YY * 1.5) * 3), XX(4), P_HEIGHT - (P_YY * 4.25), 20, "")
            Exit Sub
        End If

        Call PRN_LINE(XX(0), pryy, XX(18), pryy, 10, "")
        Call PRN_LINE(XX(2), pryy + (P_YY * 1.5), XX(18), pryy + (P_YY * 1.5), 10, "")
        Call PRN_LINE(XX(2), pryy + ((P_YY * 1.5) * 2), XX(18), pryy + ((P_YY * 1.5) * 2), 10, "")

        ' ���o��(���v)
        PR_WK_Renamed.DT = "���v"
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.12 UPGRADE S AIT)phongdv
        ' PR_WK_Renamed.X = PRN_XGet(0, XX(1), XX(2), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(0, XX(1), XX(2), PR_WK_Renamed)
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' �������o�����݌v
        PR_WK_Renamed.DT = "�������o�����݌v"
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.12 UPGRADE S AIT)phongdv
        ' PR_WK_Renamed.X = PRN_XGet(1, XX(2), XX(5), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(1, XX(2), XX(5), PR_WK_Renamed)
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' �挎���o�����݌v
        PR_WK_Renamed.DT = "�挎���o�����݌v"
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.12 UPGRADE S AIT)phongdv
        ' PR_WK_Renamed.X = PRN_XGet(1, XX(2), XX(5), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(1, XX(2), XX(5), PR_WK_Renamed)
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + (P_YY * 1.5)
        Call PRN_DATA(PR_WK_Renamed)
        ' �����o�����v
        PR_WK_Renamed.DT = "�����o�����v"
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.12 UPGRADE S AIT)phongdv
        ' PR_WK_Renamed.X = PRN_XGet(1, XX(2), XX(5), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(1, XX(2), XX(5), PR_WK_Renamed)
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + ((P_YY * 1.5) * 2)
        Call PRN_DATA(PR_WK_Renamed)
        ' ���o��(�P)
        PR_WK_Renamed.DT = "�`"
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.12 UPGRADE S AIT)phongdv
        ' PR_WK_Renamed.X = PRN_XGet(1, XX(5), XX(6), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(1, XX(5), XX(6), PR_WK_Renamed)
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' ���o��(�Q)
        PR_WK_Renamed.DT = "�a"
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.12 UPGRADE S AIT)phongdv
        ' PR_WK_Renamed.X = PRN_XGet(1, XX(5), XX(6), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(1, XX(5), XX(6), PR_WK_Renamed)
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + (P_YY * 1.5)
        Call PRN_DATA(PR_WK_Renamed)
        ' ���o��(�R)
        PR_WK_Renamed.DT = "�`�|�a"
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.12 UPGRADE S AIT)phongdv
        'PR_WK_Renamed.X = PRN_XGet(1, XX(5), XX(6), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(1, XX(5), XX(6), PR_WK_Renamed)
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + ((P_YY * 1.5) * 2)
        Call PRN_DATA(PR_WK_Renamed)

        '----- �������o�����݌v
        ' �������o�����݌v(�P)
        If M_Cnt = 0 Then
            '2021.08.03 UPGRADE S  AIT)dannnl
            'PR_Text = VB6.Format(GD_KEI, "#,###,###,##0")
            PR_Text = GD_KEI.ToString("#,###,###,##0")
            '2021.08.03 UPGRADE E
            prnGKEI_Flag = CStr(True)
        ElseIf CBool(prnGKEI_Flag) = False Then
            '2021.08.03 UPGRADE S  AIT)dannnl
            'PR_Text = VB6.Format(DT_KEI(0), "#,###,###,##0")
            PR_Text = DT_KEI(0).ToString("#,###,###,##0")
            '2021.08.03 UPGRADE E
        Else
            PR_Text = ""
        End If
        PR_WK_Renamed.DT = PR_Text
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.12 UPGRADE S AIT)phongdv
        'PR_WK_Renamed.X = PRN_XGet(2, XX(8), XX(9), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(8), XX(9), PR_WK_Renamed)
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' �������o�����݌v(�Q)
        If M_Cnt = 1 Then
            '2021.08.03 UPGRADE S  AIT)dannnl
            'PR_Text = VB6.Format(GD_KEI, "#,###,###,##0")
            PR_Text = GD_KEI.ToString("#,###,###,##0")
            '2021.08.03 UPGRADE E
            prnGKEI_Flag = CStr(True)
        ElseIf CBool(prnGKEI_Flag) = False Then
            '2021.08.03 UPGRADE S  AIT)dannnl
            'PR_Text = VB6.Format(DT_KEI(1), "#,###,###,##0")
            PR_Text = DT_KEI(1).ToString("#,###,###,##0")
            '2021.08.03 UPGRADE E
        Else
            PR_Text = ""
        End If
        PR_WK_Renamed.DT = PR_Text
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.12 UPGRADE S AIT)phongdv
        'PR_WK_Renamed.X = PRN_XGet(2, XX(11), XX(12), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(11), XX(12), PR_WK_Renamed)
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' �������o�����݌v(�R)
        If M_Cnt = 2 Then
            '2021.08.03 UPGRADE S  AIT)dannnl
            'PR_Text = VB6.Format(GD_KEI, "#,###,###,##0")
            PR_Text = GD_KEI.ToString("#,###,###,##0")
            '2021.08.03 UPGRADE E
            prnGKEI_Flag = CStr(True)
        ElseIf CBool(prnGKEI_Flag) = False Then
            '2021.08.03 UPGRADE S  AIT)dannnl
            'PR_Text = VB6.Format(DT_KEI(2), "#,###,###,##0")
            PR_Text = DT_KEI(2).ToString("#,###,###,##0")
            '2021.08.03 UPGRADE E
        Else
            PR_Text = ""
        End If
        PR_WK_Renamed.DT = PR_Text
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.12 UPGRADE S AIT)phongdv
        'PR_WK_Renamed.X = PRN_XGet(2, XX(14), XX(15), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(14), XX(15), PR_WK_Renamed)
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' �������o�����݌v(�S)
        If M_Cnt = 3 Then
            '2021.08.03 UPGRADE S  AIT)dannnl
            'PR_Text = VB6.Format(GD_KEI, "#,###,###,##0")
            PR_Text = GD_KEI.ToString("#,###,###,##0")
            '2021.08.03 UPGRADE E
            prnGKEI_Flag = CStr(True)
        ElseIf CBool(prnGKEI_Flag) = False Then
            '2021.08.03 UPGRADE S  AIT)dannnl
            'PR_Text = VB6.Format(DT_KEI(3), "#,###,###,##0")
            PR_Text = DT_KEI(3).ToString("#,###,###,##0")
            '2021.08.03 UPGRADE E
        Else
            PR_Text = ""
        End If
        PR_WK_Renamed.DT = PR_Text
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.12 UPGRADE S AIT)phongdv
        'PR_WK_Renamed.X = PRN_XGet(2, XX(17), XX(18), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(17), XX(18), PR_WK_Renamed)
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)

        '----- ���s
        pryy = pryy + (P_YY * 1.5)

        '----- �挎���o�����݌v
        ' �挎���o�����݌v(�P)
        If M_Cnt = 0 Then
            '2021.08.03 UPGRADE S  AIT)dannnl
            'PR_Text = VB6.Format(SD_KEI, "#,###,###,##0")
            PR_Text = SD_KEI.ToString("#,###,###,##0")
            '2021.08.03 UPGRADE E
            prnSKEI_Flag = CStr(True)
        ElseIf CBool(prnSKEI_Flag) = False Then
            '2021.08.03 UPGRADE S  AIT)dannnl
            'PR_Text = VB6.Format(DT_SEN(0), "#,###,###,##0")
            PR_Text = DT_SEN(0).ToString("#,###,###,##0")
            '2021.08.03 UPGRADE E
        Else
            PR_Text = ""
        End If
        PR_WK_Renamed.DT = PR_Text
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.12 UPGRADE S AIT)phongdv
        'PR_WK_Renamed.X = PRN_XGet(2, XX(8), XX(9), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(8), XX(9), PR_WK_Renamed)
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' �挎���o�����݌v(�Q)
        If M_Cnt = 1 Then
            '2021.08.03 UPGRADE S  AIT)dannnl
            'PR_Text = VB6.Format(SD_KEI, "#,###,###,##0")
            PR_Text = SD_KEI.ToString("#,###,###,##0")
            '2021.08.03 UPGRADE E
            prnSKEI_Flag = CStr(True)
        ElseIf CBool(prnSKEI_Flag) = False Then
            '2021.08.03 UPGRADE S  AIT)dannnl
            'PR_Text = VB6.Format(DT_SEN(1), "#,###,###,##0")
            PR_Text = DT_SEN(1).ToString("#,###,###,##0")
            '2021.08.03 UPGRADE E
        Else
            PR_Text = ""
        End If
        PR_WK_Renamed.DT = PR_Text
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.12 UPGRADE S AIT)phongdv
        'PR_WK_Renamed.X = PRN_XGet(2, XX(11), XX(12), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(11), XX(12), PR_WK_Renamed)
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' �挎���o�����݌v(�R)
        If M_Cnt = 2 Then
            '2021.08.03 UPGRADE S  AIT)dannnl
            'PR_Text = VB6.Format(SD_KEI, "#,###,###,##0")
            PR_Text = SD_KEI.ToString("#,###,###,##0")
            '2021.08.03 UPGRADE E
            prnSKEI_Flag = CStr(True)
        ElseIf CBool(prnSKEI_Flag) = False Then
            '2021.08.03 UPGRADE S  AIT)dannnl
            'PR_Text = VB6.Format(DT_SEN(2), "#,###,###,##0")
            PR_Text = DT_SEN(2).ToString("#,###,###,##0")
            '2021.08.03 UPGRADE E
        Else
            PR_Text = ""
        End If
        PR_WK_Renamed.DT = PR_Text
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.12 UPGRADE S AIT)phongdv
        'PR_WK_Renamed.X = PRN_XGet(2, XX(14), XX(15), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(14), XX(15), PR_WK_Renamed)
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' �挎���o�����݌v(�S)
        If M_Cnt = 3 Then
            '2021.08.03 UPGRADE S  AIT)dannnl
            'PR_Text = VB6.Format(SD_KEI, "#,###,###,##0")
            PR_Text = SD_KEI.ToString("#,###,###,##0")
            '2021.08.03 UPGRADE E
            prnSKEI_Flag = CStr(True)
        ElseIf CBool(prnSKEI_Flag) = False Then
            '2021.08.03 UPGRADE S  AIT)dannnl
            'PR_Text = VB6.Format(DT_SEN(3), "#,###,###,##0")
            PR_Text = DT_SEN(3).ToString("#,###,###,##0")
            '2021.08.03 UPGRADE E
        Else
            PR_Text = ""
        End If
        PR_WK_Renamed.DT = PR_Text
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.12 UPGRADE S AIT)phongdv
        'PR_WK_Renamed.X = PRN_XGet(2, XX(17), XX(18), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(17), XX(18), PR_WK_Renamed)
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)

        '----- ���s
        pryy = pryy + (P_YY * 1.5)

        '----- �����o�����v
        ' �����o�����v(�P)
        If M_Cnt = 0 Then
            '2021.08.03 UPGRADE S  AIT)dannnl
            'PR_Text = VB6.Format(GD_KEI - SD_KEI, "#,###,###,##0")
            PR_Text = (GD_KEI - SD_KEI).ToString("#,###,###,##0")
            '2021.08.03 UPGRADE E
            prnKKEI_Flag = CStr(True)
        ElseIf CBool(prnKKEI_Flag) = False Then
            '2021.08.03 UPGRADE S  AIT)dannnl
            'PR_Text = VB6.Format(DT_KEI(0) - DT_SEN(0), "#,###,###,##0")
            PR_Text = (DT_KEI(0) - DT_SEN(0)).ToString("#,###,###,##0")
            '2021.08.03 UPGRADE E
        Else
            PR_Text = ""
        End If
        PR_WK_Renamed.DT = PR_Text
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.12 UPGRADE S AIT)phongdv
        'PR_WK_Renamed.X = PRN_XGet(2, XX(8), XX(9), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(8), XX(9), PR_WK_Renamed)
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' �����o�����v(�Q)
        If M_Cnt = 1 Then
            '2021.08.03 UPGRADE S  AIT)dannnl
            'PR_Text = VB6.Format(GD_KEI - SD_KEI, "#,###,###,##0")
            PR_Text = (GD_KEI - SD_KEI).ToString("#,###,###,##0")
            '2021.08.03 UPGRADE E
            prnKKEI_Flag = CStr(True)
        ElseIf CBool(prnKKEI_Flag) = False Then
            '2021.08.03 UPGRADE S  AIT)dannnl
            'PR_Text = VB6.Format(DT_KEI(1) - DT_SEN(1), "#,###,###,##0")
            PR_Text = (DT_KEI(1) - DT_SEN(1)).ToString("#,###,###,##0")
            '2021.08.03 UPGRADE E
        Else
            PR_Text = ""
        End If
        PR_WK_Renamed.DT = PR_Text
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.12 UPGRADE S AIT)phongdv
        'PR_WK_Renamed.X = PRN_XGet(2, XX(11), XX(12), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(11), XX(12), PR_WK_Renamed)
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' �����o�����v(�R)
        If M_Cnt = 2 Then
            '2021.08.03 UPGRADE S  AIT)dannnl
            'PR_Text = VB6.Format(GD_KEI - SD_KEI, "#,###,###,##0")
            PR_Text = (GD_KEI - SD_KEI).ToString("#,###,###,##0")
            '2021.08.03 UPGRADE E
            prnKKEI_Flag = CStr(True)
        ElseIf CBool(prnKKEI_Flag) = False Then
            '2021.08.03 UPGRADE S  AIT)dannnl
            'PR_Text = VB6.Format(DT_KEI(2) - DT_SEN(2), "#,###,###,##0")
            PR_Text = (DT_KEI(2) - DT_SEN(2)).ToString("#,###,###,##0")
            '2021.08.03 UPGRADE E
        Else
            PR_Text = ""
        End If
        PR_WK_Renamed.DT = PR_Text
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.12 UPGRADE S AIT)phongdv
        'PR_WK_Renamed.X = PRN_XGet(2, XX(14), XX(15), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(14), XX(15), PR_WK_Renamed)
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' �����o�����v(�S)
        If M_Cnt = 3 Then
            '2021.08.03 UPGRADE S  AIT)dannnl
            'PR_Text = VB6.Format(GD_KEI - SD_KEI, "#,###,###,##0")
            PR_Text = (GD_KEI - SD_KEI).ToString("#,###,###,##0")
            '2021.08.03 UPGRADE E
            prnKKEI_Flag = CStr(True)
        ElseIf CBool(prnKKEI_Flag) = False Then
            '2021.08.03 UPGRADE S  AIT)dannnl
            'PR_Text = VB6.Format(DT_KEI(3) - DT_SEN(3), "#,###,###,##0")
            PR_Text = (DT_KEI(3) - DT_SEN(3)).ToString("#,###,###,##0")
            '2021.08.03 UPGRADE E
        Else
            PR_Text = ""
        End If
        PR_WK_Renamed.DT = PR_Text
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.12 UPGRADE S AIT)phongdv
        'PR_WK_Renamed.X = PRN_XGet(2, XX(17), XX(18), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(17), XX(18), PR_WK_Renamed)
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)

    End Sub

    '-------------------------------------------------------------------------------
    '   ����    :   �f�[�^�������(���o�f�[�^�E�挎���o�����f�[�^)
    '   �֐�    :   Sub PrData2D115()
    '   ����    :   DT          WARIDASI_DATA_DBT
    '               W_SIMEYM    �N���z��
    '   �ߒl    :   �����i0�`3�j
    '-------------------------------------------------------------------------------
    Private Function MonthCountGet(ByRef DT As WARIDASI_DATA_DBT, ByRef W_SIMEYM() As String) As Integer

        Dim SQL As String
        '2021.08.03 UPGRADE S  AIT)dannnl
        'Dim Rs As ADODB.Recordset
        Dim Rs As New DataTable
        '2021.08.03 UPGRADE E
        Dim OpenFlg As Short
        Dim Cnt As Integer
        Dim lp As Integer
        Dim YMBuf() As String

        MonthCountGet = 0

        SQL = SQL & "SELECT"
        SQL = SQL & " WARIDASI_DATA.WARIDASI_NO AS F01, "
        SQL = SQL & " DEKIDAKA_DATA.SIME_YM     AS F02"
        SQL = SQL & " FROM WARIDASI_DATA"
        SQL = SQL & " INNER JOIN DEKIDAKA_DATA"
        SQL = SQL & " ON (WARIDASI_DATA.MEISAI_NO = DEKIDAKA_DATA.MEISAI_NO)"
        SQL = SQL & " AND (WARIDASI_DATA.KOUSYU_NO = DEKIDAKA_DATA.KOUSYU_NO)"
        SQL = SQL & " AND (WARIDASI_DATA.KOUSYU_CD = DEKIDAKA_DATA.KOUSYU_CD)"
        SQL = SQL & " AND (WARIDASI_DATA.EDA_NO = DEKIDAKA_DATA.EDA_NO)"
        SQL = SQL & " AND (WARIDASI_DATA.KOUJI_NO = DEKIDAKA_DATA.KOUJI_NO)"
        SQL = SQL & " WHERE DEKIDAKA_DATA.SIME_YM < '" & CtlKouji.SYORI_YM & "'"
        SQL = SQL & " AND WARIDASI_DATA.WARIDASI_NO = '" & DT.WARIDASI_NO & "'"
        SQL = SQL & " AND WARIDASI_DATA.KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"
        SQL = SQL & " AND WARIDASI_DATA.EDA_NO = '" & KeyKouji.EDA_NO & "'"
        SQL = SQL & " GROUP BY WARIDASI_DATA.WARIDASI_NO, DEKIDAKA_DATA.SIME_YM"
        SQL = SQL & " ORDER BY WARIDASI_DATA.WARIDASI_NO, DEKIDAKA_DATA.SIME_YM"

        'SQL�����s
        '2021.08.03 UPGRADE S  AIT)dannnl
        'Rs = SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText)
        Rs = RsOpen(SQL)
        '2021.08.03 UPGRADE E
        OpenFlg = 1

        Cnt = 0
        '2021.08.03 UPGRADE S  AIT)dannnl
        'Do Until Rs.EOF
        For Each Row As DataRow In Rs.Rows
            '2021.08.03 UPGRADE E
            ReDim Preserve YMBuf(Cnt)
            '2021.08.03 UPGRADE S  AIT)dannnl
            'YMBuf(Cnt) = Rs.Fields("F02").Value
            YMBuf(Cnt) = Row("F02")
            '2021.08.03 UPGRADE E
            Cnt = Cnt + 1
            '2021.08.03 UPGRADE S  AIT)dannnl
            '	Rs.MoveNext()
            'Loop
        Next
        '2021.08.03 UPGRADE E

        '�擾�N���̃Z�b�g
        For lp = 0 To 3
            W_SIMEYM(lp) = ""
        Next lp
        If Cnt > 3 Then
            For lp = 0 To 3 - 1
                W_SIMEYM(lp) = YMBuf(Cnt - 3 + lp)
            Next lp
            Cnt = 3
        Else
            For lp = 0 To Cnt - 1
                W_SIMEYM(lp) = YMBuf(lp)
            Next lp
        End If
        W_SIMEYM(Cnt) = CtlKouji.SYORI_YM

        '�����̃Z�b�g
        MonthCountGet = Cnt

    End Function
End Module

