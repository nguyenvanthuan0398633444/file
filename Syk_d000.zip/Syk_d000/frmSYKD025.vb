Option Strict Off
Option Explicit On
Imports VB = Microsoft.VisualBasic
Friend Class frmSYKD025
	Inherits System.Windows.Forms.Form
	'=============================================================
	' ���[�U�[���@  �F  �R�z�H�Ɗ������
	' �V�X�e�����@  �F  �H���Ǘ��V�X�e��
	' ���W���[����  �F  ���c��O�����o�e�L�X�g�Ǎ��ݏ��m�F
	' ���W���[��ID�@�F  frmSYKD025.frm
	' �쐬���@ �@�@ �F  ���� 13 �N 06 �� 19 ��
	' �X�V���@�@  �@�F  ����    �N    ��    ��
	'=============================================================
	'
	'2021.08.10 UPGRADE S  AIT)hieunv
	'Private Const RowHeight As Short = 15
	Private Const RowHeight As Short = 20
	'2021.08.10 UPGRADE E
	Public Shared SelMode As String '�I������
	'

	'-------------------------------------------------------------------------------
	'   ����    :   �f�[�^�̃N���A
	'   �֐�    :   Sub DispClear()
	'   ����    :   �Ȃ�
	'   �@�\    :   �f�[�^���N���A���܂��B
	'-------------------------------------------------------------------------------
	Private Sub DispClear()
		
		'----- �H�����
		With KeyKouji
			imText2(0).Text = .KOUJI_NO
			If .EDA_NO = "0000" Then
				imText2(1).Text = ""
			Else
				imText2(1).Text = .EDA_NO
			End If
			imText2(2).Text = .MEISYOU
		End With
		'2021.08.02 UPGRADE S  AIT)hieunv
		'vaSpread1.MaxRows = 0
		vaSpread1.ActiveSheet.RowCount = 0
		'2021.08.02 UPGRADE E
	End Sub
	
	'-------------------------------------------------------------------------------
	'   ����    :   �f�[�^�̎擾
	'   �֐�    :   Sub ListDataDisp()
	'   ����    :   Mode    0 = MsgBox�\��
	'   �@�\    :   �f�[�^�̎擾���s���܂��B
	'-------------------------------------------------------------------------------
	Private Sub ListDataDisp()
		
		' �J�[�\���������v��
		System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
		StatusBar1.Items.Item("Message").Text = "�Y���f�[�^�\�����E�E�E"

		' �X�v���b�h�ɕ\��
		Call SprdDataSet(txtCnt, txtWari)
		System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
	End Sub

	'-------------------------------------------------------------------------------
	'   ����    :   �X�v���b�h�\��
	'   �֐�    :   Sub SprdDataSet(DT())
	'   ����    :   Cnt     �f�[�^����
	'   �@�@    :   DT()    WARIDASI_DATA_DBT
	'   �@�\    :   �f�[�^���X�v���b�h�ɕ\�����܂��B
	'-------------------------------------------------------------------------------
	Private Sub SprdDataSet(ByRef Cnt As Integer, ByRef DT() As WARIDASI_DATA_DBT)

		Dim lp As Integer
		Dim Row As Integer
		Dim ssText As Object

		With vaSpread1
			If Me.Visible = True Then
				'2021.08.02 UPGRADE S  AIT) hieunv
				'.ReDraw = False
				.SuspendLayout()
				'2021.08.02 UPGRADE E
			End If
			'2021.08.02 UPGRADE S  AIT) hieunv
			'.MaxRows = Cnt
			'.Col = 1 : .Col2 = .MaxCols
			'.Row = 1 : .Row2 = .MaxRows
			'.BlockMode = True
			''2021.07.26 UPGRADE S  AIT)Tool Convert
			'.Action = FPSpread.ActionConstants.ActionClearText
			'.BlockMode = False
			.ActiveSheet.RowCount = Cnt
			.ActiveSheet.ClearRange(0, 0, .ActiveSheet.RowCount, .ActiveSheet.ColumnCount, True)
			.ActiveSheet.OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
			.ActiveSheet.AddSelection(0, 0, 1, 1)
			'2021.08.02 UPGRADE E
			'2021.07.26 UPGRADE S  AIT)Tool Convert
			'.Font = VB6.FontChangeBold(.Font, False)
			.Font = New Font(.Font, FontStyle.Regular)
			'2021.07.26 UPGRADE E
			For lp = 0 To Cnt - 1
				'2021.08.02 UPGRADE S  AIT) hieunv
				'.set_RowHeight = lp+1
				'Row = lp + 1
				.ActiveSheet.SetRowHeight(lp, RowHeight)
				Row = lp
				'2021.08.02 UPGRADE E
				'----- �H��
				ssText = DT(lp).KOUSYU_CD & "-" & DT(lp).KOUSYU_NO
				'2021.08.02 UPGRADE S  AIT) hieunv
				'.SetText(1, Row, ssText)
				.ActiveSheet.SetText(Row, 0, ssText)
				'----- ����
				ssText = Trim(DT(lp).MEISYOU)
				'2021.08.02 UPGRADE S  AIT) hieunv
				'.SetText(2, Row, ssText)
				.ActiveSheet.SetText(Row, 1, ssText)
				'2021.08.02 UPGRADE E
				'>>>>> ���s�\�Z
				'----- ����
				'2021.07.26 UPGRADE S  AIT)Tool Convert
				'ssText = VB6.Format(DT(lp).S_SUURYOU, "#,###.##")
				ssText = DT(lp).S_SUURYOU.ToString("#,###.##")
				'2021.07.26 UPGRADE E
				If VB.Right(ssText, 1) = "." Then ssText = VB.Left(ssText, Len(ssText) - 1)
				If VB.Left(ssText, 1) = "." Then ssText = "0" & ssText
				'2021.08.02 UPGRADE S  AIT) hieunv
				'.SetText(3, Row, ssText)
				.ActiveSheet.SetText(Row, 2, ssText)
				'2021.08.02 UPGRADE E
				'----- �P��
				ssText = Trim(DT(lp).TANI)
				'2021.08.02 UPGRADE S  AIT) hieunv
				'.SetText(4, Row, ssText)
				.ActiveSheet.SetText(Row, 3, ssText)
				'2021.08.02 UPGRADE E
				'----- �P��
				'2021.07.26 UPGRADE S  AIT) hieunv
				'ssText = VB6.Format(DT(lp).S_TANKA, "#,###")
				ssText = CDec(DT(lp).S_TANKA).ToString("#,###")
				'2021.08.02 UPGRADE S  AIT) hieunv
				'.SetText(5, Row, ssText)
				.ActiveSheet.SetText(Row, 4, ssText)
				'2021.08.02 UPGRADE E
				'----- ���z
				'2021.07.26 UPGRADE S  AIT)Tool Convert
				'ssText = VB6.Format(DT(lp).S_KINGAKU, "#,##0")
				ssText = CDec(DT(lp).S_KINGAKU).ToString("#,##0")
				'2021.07.26 UPGRADE E
				'.SetText(6, Row, ssText)
				.ActiveSheet.SetText(Row, 5, ssText)
				'>>>>> ��Ɋz���͎�ɗ\��z     2004/03/14 �ǉ�
				'----- ����
				'2021.07.26 UPGRADE S  AIT)Tool Convert
				'ssText = VB6.Format(DT(lp).J_SUURYOU, "#,###.##")
				ssText = DT(lp).J_SUURYOU.ToString("#,###.##")
				'2021.07.26 UPGRADE E
				If VB.Right(ssText, 1) = "." Then ssText = VB.Left(ssText, Len(ssText) - 1)
				If VB.Left(ssText, 1) = "." Then ssText = "0" & ssText
				'2021.08.02 UPGRADE S  AIT) hieunv
				'.SetText(7, Row, ssText)
				.ActiveSheet.SetText(Row, 6, ssText)
				'----- �P��
				ssText = Trim(DT(lp).TANI)
				'2021.08.02 UPGRADE S  AIT) hieunv
				'.SetText(8, Row, ssText)
				.ActiveSheet.SetText(Row, 7, ssText)
				'----- �P��
				'2021.08.02 UPGRADE S  AIT) hieunv
				'ssText = VB6.Format(DT(lp).J_TANKA, "#,###")
				'.SetText(9, Row, ssText)
				ssText = CDec(DT(lp).J_TANKA).ToString("#,###")
				.ActiveSheet.SetText(Row, 8, ssText)
				'2021.08.02 UPGRADE E
				'----- ���z
				'2021.07.26 UPGRADE S  AIT)Tool Convert
				'ssText = VB6.Format(DT(lp).J_KINGAKU, "#,##0")
				ssText = CDec(DT(lp).J_KINGAKU).ToString("#,##0")
				'2021.07.26 UPGRADE E
				'2021.08.02 UPGRADE S  AIT) hieunv
				'.SetText(10, Row, ssText)
				.ActiveSheet.SetText(Row, 9, ssText)
				'2021.08.02 UPGRADE E
			Next lp
			If Me.Visible = True Then
				'2021.08.02 UPGRADE S  AIT) hieunv
				'.CtlRefresh()
				'.ReDraw = True
				.Refresh()
				.ResumeLayout()
				'2021.08.02 UPGRADE E
			End If
		End With
	End Sub
	'2021.08.02 UPGRADE S  AIT)hieunv
	'Private Sub cmdKey_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Click

	'Dim Index As Short = cmdKey.GetIndex(eventSender)
	Private Sub cmdKey_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _cmdKey_1.Click, _cmdKey_10.Click,
																												_cmdKey_11.Click, _cmdKey_12.Click,
																												_cmdKey_2.Click, _cmdKey_3.Click,
																												_cmdKey_4.Click, _cmdKey_5.Click,
																												_cmdKey_6.Click, _cmdKey_7.Click,
																												_cmdKey_8.Click, _cmdKey_9.Click
		Dim Index As Short = cmdKey.IndexOf(eventSender)
		'2021.08.02 UPGRADE E
		Select Case Index
			Case 1 '----- �m��
				SelMode = "1"
			Case 12 '----- ���~
				SelMode = ""
		End Select
		'2021.09.15 UPGRADE S  AIT)hieunv
		'Me.Close()
		Me.Dispose()
		'2021.09.15 UPGRADE E
	End Sub
	'2021.08.02 UPGRADE S  AIT) hieunv
	'Private Sub cmdKey_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Enter
	'Dim Index As Short = cmdKey.GetIndex(eventSender)
	'Call GotFocus(cmdKey(Index), StatusBar1)
	'End Sub
	Private Sub cmdKey_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _cmdKey_1.Enter, _cmdKey_10.Enter,
																												_cmdKey_11.Enter, _cmdKey_12.Enter,
																												_cmdKey_2.Enter, _cmdKey_3.Enter,
																												_cmdKey_4.Enter, _cmdKey_5.Enter,
																												_cmdKey_6.Enter, _cmdKey_7.Enter,
																												_cmdKey_8.Enter, _cmdKey_9.Enter
		Dim Index As Short = cmdKey.IndexOf(eventSender)
		Call MtyTool.GotFocus(cmdKey(Index), StatusBar1)
	End Sub
	'2021.08.02 UPGRADE E
	'Private Sub cmdKey_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Leave
	'	Dim Index As Short = cmdKey.GetIndex(eventSender)
	'	Call LostFocus(cmdKey(Index), StatusBar1)
	'End Sub
	Private Sub cmdKey_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _cmdKey_1.Leave, _cmdKey_10.Leave,
																												_cmdKey_11.Leave, _cmdKey_12.Leave,
																												_cmdKey_2.Leave, _cmdKey_3.Leave,
																												_cmdKey_4.Leave, _cmdKey_5.Leave,
																												_cmdKey_6.Leave, _cmdKey_7.Leave,
																												_cmdKey_8.Leave, _cmdKey_9.Leave
		Dim Index As Short = cmdKey.IndexOf(eventSender)
		Call MtyTool.LostFocus(cmdKey(Index), StatusBar1)
	End Sub
	'2021.08.02 UPGRADE E
	Private Sub frmSYKD025_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown
		Dim KeyCode As Short = eventArgs.KeyCode
		Dim Shift As Short = eventArgs.KeyData \ &H10000
		Select Case KeyCode
			Case System.Windows.Forms.Keys.F1
				If cmdKey(1).Enabled = True Then cmdKey(1).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(1), New System.EventArgs())
			Case System.Windows.Forms.Keys.F2
				If cmdKey(2).Enabled = True Then cmdKey(2).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(2), New System.EventArgs())
			Case System.Windows.Forms.Keys.F3
				If cmdKey(3).Enabled = True Then cmdKey(3).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(3), New System.EventArgs())
			Case System.Windows.Forms.Keys.F4
				If cmdKey(4).Enabled = True Then cmdKey(4).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(4), New System.EventArgs())
			Case System.Windows.Forms.Keys.F5
				If cmdKey(5).Enabled = True Then cmdKey(5).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(5), New System.EventArgs())
			Case System.Windows.Forms.Keys.F6
				If cmdKey(6).Enabled = True Then cmdKey(6).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(6), New System.EventArgs())
			Case System.Windows.Forms.Keys.F7
				If cmdKey(7).Enabled = True Then cmdKey(7).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(7), New System.EventArgs())
			Case System.Windows.Forms.Keys.F8
				If cmdKey(8).Enabled = True Then cmdKey(8).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(8), New System.EventArgs())
			Case System.Windows.Forms.Keys.F9
				If cmdKey(9).Enabled = True Then cmdKey(9).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(9), New System.EventArgs())
			Case System.Windows.Forms.Keys.F10
				If cmdKey(10).Enabled = True Then cmdKey(10).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(10), New System.EventArgs())
			Case System.Windows.Forms.Keys.F11
				If cmdKey(11).Enabled = True Then cmdKey(11).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(11), New System.EventArgs())
			Case System.Windows.Forms.Keys.F12
				If cmdKey(12).Enabled = True Then cmdKey(12).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(12), New System.EventArgs())
		End Select
	End Sub
	
	Private Sub frmSYKD025_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load

		Call FormDisp(Me)
		SelMode = ""
		' �����\��
		Call DispClear()
		Call ListDataDisp()

	End Sub

	Private Sub frmSYKD025_FormClosing(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
		Dim Cancel As Boolean = eventArgs.Cancel
		Dim UnloadMode As System.Windows.Forms.CloseReason = eventArgs.CloseReason
		If UnloadMode = System.Windows.Forms.CloseReason.UserClosing Then
			SelMode = ""
		End If
		eventArgs.Cancel = Cancel
	End Sub

End Class
