Imports GrapeCity.Win.Editors

<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frmSYKD090
#Region "Windows Form Designer generated code "
    <System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
        MyBase.New()
        InitializeComponent()

        '2021.08.05 UPGRADE ADD S AIT)hieutv
        Command1 = New ArrayList()
        Command1.Add(_Command1_0)
        Command1.Add(_Command1_1)
        Command1.Add(_Command1_2)
        Command1.Add(_Command1_3)
        Command1.Add(_Command1_4)

        Label1 = New ArrayList()
        Label1.Add(_Label1_0)
        Label1.Add(_Label1_1)

        cmdKey = New ArrayList()
        cmdKey.Add(Nothing)
        cmdKey.Add(_cmdKey_1)
        cmdKey.Add(_cmdKey_2)
        cmdKey.Add(_cmdKey_3)
        cmdKey.Add(_cmdKey_4)
        cmdKey.Add(_cmdKey_5)
        cmdKey.Add(_cmdKey_6)
        cmdKey.Add(_cmdKey_7)
        cmdKey.Add(_cmdKey_8)
        cmdKey.Add(_cmdKey_9)
        cmdKey.Add(_cmdKey_10)
        cmdKey.Add(_cmdKey_11)
        cmdKey.Add(_cmdKey_12)

        imText1 = New ArrayList()
        imText1.Add(_imText1_0)
        imText1.Add(_imText1_1)
        imText1.Add(_imText1_2)

        imText2 = New ArrayList()
        imText2.Add(_imText2_0)
        imText2.Add(_imText2_1)
        imText2.Add(_imText2_2)

        '2021.08.05 UPGRADE ADD E

    End Sub

    <System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
        If Disposing Then
            If Not components Is Nothing Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(Disposing)
    End Sub

    Private components As System.ComponentModel.IContainer
    Public ToolTip1 As System.Windows.Forms.ToolTip
    '2021.08.05 UPGRADE S  AIT)hieutv
    'Public WithEvents _imText1_0 As imText6.imText
    'Public WithEvents _imText1_1 As imText6.imText
    'Public WithEvents _imText1_2 As imText6.imText
    Public WithEvents _imText1_0 As GcTextBox
    Public WithEvents _imText1_1 As GcTextBox
    Public WithEvents _imText1_2 As GcTextBox
    '2021.08.05 UPGRADE E
    Public WithEvents _Label1_0 As System.Windows.Forms.Label
    Public WithEvents _Label1_1 As System.Windows.Forms.Label
    Public WithEvents Frame1 As System.Windows.Forms.GroupBox
    Public WithEvents _Command1_1 As System.Windows.Forms.Button
    Public WithEvents _Command1_0 As System.Windows.Forms.Button
    Public WithEvents _Command1_2 As System.Windows.Forms.Button
    Public WithEvents _Command1_3 As System.Windows.Forms.Button
    Public WithEvents _Command1_4 As System.Windows.Forms.Button
    Public WithEvents Picture2 As System.Windows.Forms.Panel
    Public WithEvents _cmdKey_3 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_12 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_4 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_10 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_6 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_7 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_8 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_9 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_1 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_11 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_2 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_5 As System.Windows.Forms.Button
    Public WithEvents Picture1 As System.Windows.Forms.Panel
    Public WithEvents _StatusBar1_Panel1 As System.Windows.Forms.ToolStripStatusLabel
    Public WithEvents Message As System.Windows.Forms.ToolStripStatusLabel
    Public WithEvents StatusBar1 As System.Windows.Forms.StatusStrip
    '2021.08.05 UPGRADE S  AIT)hieutv
    'Public WithEvents _imText2_2 As imText6.imText
    'Public WithEvents _imText2_0 As imText6.imText
    'Public WithEvents _imText2_1 As imText6.imText
    Public WithEvents _imText2_2 As GcTextBox
    Public WithEvents _imText2_0 As GcTextBox
    Public WithEvents _imText2_1 As GcTextBox
    'Public WithEvents vaSpread1 As AxFPSpread.AxvaSpread
    'Public WithEvents vaSpread2 As AxFPSpread.AxvaSpread
    '2021.08.05 UPGRADE E
    Public WithEvents lblTitle As System.Windows.Forms.Label
    '2021.08.05 UPGRADE S  AIT)hieutv
    'Public WithEvents Command1 As Microsoft.VisualBasic.Compatibility.VB6.ButtonArray
    'Public WithEvents Label1 As Microsoft.VisualBasic.Compatibility.VB6.LabelArray
    'Public WithEvents cmdKey As Microsoft.VisualBasic.Compatibility.VB6.ButtonArray
    'Public WithEvents imText1 As imTextArray
    'Public WithEvents imText2 As imTextArray
    Public WithEvents Command1 As ArrayList
    Public WithEvents Label1 As ArrayList
    Public WithEvents cmdKey As ArrayList
    Public WithEvents imText1 As ArrayList
    Public WithEvents imText2 As ArrayList
    '2021.08.05 UPGRADE E

    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim CustomSpdHeader As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim CustomSpdHeader1 As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim CustomSpdHeader2 As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim CustomSpdHeader3 As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim CustomSpdHeader4 As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim CustomSpdHeader5 As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim CustomSpdHeader6 As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim CustomSpdHeader7 As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim CustomSpdHeader8 As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim CustomSpdHeader9 As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim CustomSpdHeader10 As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim CustomSpdHeader11 As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim CustomSpdHeader12 As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim DefaultFocusIndicatorRenderer1 As FarPoint.Win.Spread.DefaultFocusIndicatorRenderer = New FarPoint.Win.Spread.DefaultFocusIndicatorRenderer()
        Dim DefaultScrollBarRenderer1 As FarPoint.Win.Spread.DefaultScrollBarRenderer = New FarPoint.Win.Spread.DefaultScrollBarRenderer()
        Dim NamedStyle1 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("Color65637638421707046342")
        Dim NamedStyle2 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("Font231637638421707056338")
        Dim NamedStyle3 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("BorderEx730637638421707146350")
        Dim ComplexBorder1 As FarPoint.Win.ComplexBorder = New FarPoint.Win.ComplexBorder(New FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.None), New FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.None), New FarPoint.Win.ComplexBorderSide(System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))), New FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.None), New FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.None), False, False)
        Dim NamedStyle4 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("BorderEx1004637638421707166347")
        Dim TipAppearance1 As FarPoint.Win.Spread.TipAppearance = New FarPoint.Win.Spread.TipAppearance()
        Dim DefaultScrollBarRenderer2 As FarPoint.Win.Spread.DefaultScrollBarRenderer = New FarPoint.Win.Spread.DefaultScrollBarRenderer()
        Dim TextCellType1 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType()
        Dim ComplexBorder2 As FarPoint.Win.ComplexBorder = New FarPoint.Win.ComplexBorder(New FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThinLine))
        Dim TextCellType2 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType()
        Dim TextCellType3 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType()
        Dim TextCellType4 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType()
        Dim TextCellType5 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType()
        Dim TextCellType6 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType()
        Dim DefaultScrollBarRenderer3 As FarPoint.Win.Spread.DefaultScrollBarRenderer = New FarPoint.Win.Spread.DefaultScrollBarRenderer()
        Dim NamedStyle5 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("Color65637638422468147708")
        Dim NamedStyle6 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("Font193637638422468147708")
        Dim NamedStyle7 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("BorderEx684637638422468157707")
        Dim ComplexBorder3 As FarPoint.Win.ComplexBorder = New FarPoint.Win.ComplexBorder(New FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.None), New FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.None), New FarPoint.Win.ComplexBorderSide(System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))), New FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.None), New FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.None), False, False)
        Dim NamedStyle8 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("BorderEx958637638422468157707")
        Dim TipAppearance2 As FarPoint.Win.Spread.TipAppearance = New FarPoint.Win.Spread.TipAppearance()
        Dim DefaultScrollBarRenderer4 As FarPoint.Win.Spread.DefaultScrollBarRenderer = New FarPoint.Win.Spread.DefaultScrollBarRenderer()
        Dim ComplexBorder4 As FarPoint.Win.ComplexBorder = New FarPoint.Win.ComplexBorder(New FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.None), New FarPoint.Win.ComplexBorderSide(System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))), New FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.None), New FarPoint.Win.ComplexBorderSide(System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))), New FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.None), False, False)
        Dim TextCellType7 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType()
        Dim ComplexBorder5 As FarPoint.Win.ComplexBorder = New FarPoint.Win.ComplexBorder(New FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.None), New FarPoint.Win.ComplexBorderSide(System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))), New FarPoint.Win.ComplexBorderSide(System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))), New FarPoint.Win.ComplexBorderSide(System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))), New FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.None), False, False)
        Dim TextCellType8 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType()
        Dim TextCellType9 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType()
        Dim TextCellType10 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType()
        Dim TextCellType11 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType()
        Dim TextCellType12 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType()
        Dim ComplexBorder6 As FarPoint.Win.ComplexBorder = New FarPoint.Win.ComplexBorder(New FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThinLine))
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmSYKD090))
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.Frame1 = New System.Windows.Forms.GroupBox()
        Me._imText1_0 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._imText1_1 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._imText1_2 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._Label1_0 = New System.Windows.Forms.Label()
        Me._Label1_1 = New System.Windows.Forms.Label()
        Me.Picture2 = New System.Windows.Forms.Panel()
        Me._Command1_1 = New System.Windows.Forms.Button()
        Me._Command1_0 = New System.Windows.Forms.Button()
        Me._Command1_2 = New System.Windows.Forms.Button()
        Me._Command1_3 = New System.Windows.Forms.Button()
        Me._Command1_4 = New System.Windows.Forms.Button()
        Me.Picture1 = New System.Windows.Forms.Panel()
        Me._cmdKey_3 = New System.Windows.Forms.Button()
        Me._cmdKey_12 = New System.Windows.Forms.Button()
        Me._cmdKey_4 = New System.Windows.Forms.Button()
        Me._cmdKey_10 = New System.Windows.Forms.Button()
        Me._cmdKey_6 = New System.Windows.Forms.Button()
        Me._cmdKey_7 = New System.Windows.Forms.Button()
        Me._cmdKey_8 = New System.Windows.Forms.Button()
        Me._cmdKey_9 = New System.Windows.Forms.Button()
        Me._cmdKey_1 = New System.Windows.Forms.Button()
        Me._cmdKey_11 = New System.Windows.Forms.Button()
        Me._cmdKey_2 = New System.Windows.Forms.Button()
        Me._cmdKey_5 = New System.Windows.Forms.Button()
        Me.StatusBar1 = New System.Windows.Forms.StatusStrip()
        Me._StatusBar1_Panel1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.Message = New System.Windows.Forms.ToolStripStatusLabel()
        Me._imText2_2 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._imText2_0 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._imText2_1 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.FpSpread1 = New FarPoint.Win.Spread.FpSpread()
        Me.FpSpread1_Sheet1 = New FarPoint.Win.Spread.SheetView()
        Me.FpSpread2 = New FarPoint.Win.Spread.FpSpread()
        Me.FpSpread2_Sheet1 = New FarPoint.Win.Spread.SheetView()
        Me.Frame1.SuspendLayout()
        CType(Me._imText1_0, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imText1_1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imText1_2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Picture2.SuspendLayout()
        Me.Picture1.SuspendLayout()
        Me.StatusBar1.SuspendLayout()
        CType(Me._imText2_2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imText2_0, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imText2_1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.FpSpread1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.FpSpread1_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.FpSpread2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.FpSpread2_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        CustomSpdHeader.Name = "CustomSpdHeader"
        CustomSpdHeader.PictureZoomEffect = False
        CustomSpdHeader.TextRotationAngle = 0R
        CustomSpdHeader.ZoomFactor = 1.0!
        CustomSpdHeader1.Name = "CustomSpdHeader1"
        CustomSpdHeader1.PictureZoomEffect = False
        CustomSpdHeader1.TextRotationAngle = 0R
        CustomSpdHeader1.ZoomFactor = 1.0!
        CustomSpdHeader2.Name = "CustomSpdHeader2"
        CustomSpdHeader2.PictureZoomEffect = False
        CustomSpdHeader2.TextRotationAngle = 0R
        CustomSpdHeader2.ZoomFactor = 1.0!
        CustomSpdHeader3.Name = "CustomSpdHeader3"
        CustomSpdHeader3.PictureZoomEffect = False
        CustomSpdHeader3.TextRotationAngle = 0R
        CustomSpdHeader3.ZoomFactor = 1.0!
        CustomSpdHeader4.Name = "CustomSpdHeader4"
        CustomSpdHeader4.PictureZoomEffect = False
        CustomSpdHeader4.TextRotationAngle = 0R
        CustomSpdHeader4.ZoomFactor = 1.0!
        CustomSpdHeader5.Name = "CustomSpdHeader5"
        CustomSpdHeader5.PictureZoomEffect = False
        CustomSpdHeader5.TextRotationAngle = 0R
        CustomSpdHeader5.ZoomFactor = 1.0!
        CustomSpdHeader6.Name = "CustomSpdHeader6"
        CustomSpdHeader6.PictureZoomEffect = False
        CustomSpdHeader6.TextRotationAngle = 0R
        CustomSpdHeader6.ZoomFactor = 1.0!
        CustomSpdHeader7.Name = "CustomSpdHeader7"
        CustomSpdHeader7.PictureZoomEffect = False
        CustomSpdHeader7.TextRotationAngle = 0R
        CustomSpdHeader7.ZoomFactor = 1.0!
        CustomSpdHeader8.Name = "CustomSpdHeader8"
        CustomSpdHeader8.PictureZoomEffect = False
        CustomSpdHeader8.TextRotationAngle = 0R
        CustomSpdHeader8.ZoomFactor = 1.0!
        CustomSpdHeader9.Name = "CustomSpdHeader9"
        CustomSpdHeader9.PictureZoomEffect = False
        CustomSpdHeader9.TextRotationAngle = 0R
        CustomSpdHeader9.ZoomFactor = 1.0!
        CustomSpdHeader10.Name = "CustomSpdHeader10"
        CustomSpdHeader10.PictureZoomEffect = False
        CustomSpdHeader10.TextRotationAngle = 0R
        CustomSpdHeader10.ZoomFactor = 1.0!
        CustomSpdHeader11.Name = "CustomSpdHeader11"
        CustomSpdHeader11.PictureZoomEffect = False
        CustomSpdHeader11.TextRotationAngle = 0R
        CustomSpdHeader11.ZoomFactor = 1.0!
        CustomSpdHeader12.Name = "CustomSpdHeader12"
        CustomSpdHeader12.PictureZoomEffect = False
        CustomSpdHeader12.TextRotationAngle = 0R
        CustomSpdHeader12.ZoomFactor = 1.0!
        '
        'Frame1
        '
        Me.Frame1.BackColor = System.Drawing.SystemColors.Control
        Me.Frame1.Controls.Add(Me._imText1_0)
        Me.Frame1.Controls.Add(Me._imText1_1)
        Me.Frame1.Controls.Add(Me._imText1_2)
        Me.Frame1.Controls.Add(Me._Label1_0)
        Me.Frame1.Controls.Add(Me._Label1_1)
        Me.Frame1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Frame1.Location = New System.Drawing.Point(4, 40)
        Me.Frame1.Name = "Frame1"
        Me.Frame1.Padding = New System.Windows.Forms.Padding(0)
        Me.Frame1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame1.Size = New System.Drawing.Size(1006, 71)
        Me.Frame1.TabIndex = 29
        Me.Frame1.TabStop = False
        '
        '_imText1_0
        '
        Me._imText1_0.CausesValidation = False
        Me._imText1_0.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._imText1_0.ImeMode = System.Windows.Forms.ImeMode.Off
        Me._imText1_0.Location = New System.Drawing.Point(112, 14)
        Me._imText1_0.Name = "_imText1_0"
        Me._imText1_0.ReadOnly = True
        Me._imText1_0.ReadOnlyBackColor = System.Drawing.SystemColors.Control
        Me._imText1_0.Size = New System.Drawing.Size(73, 23)
        Me._imText1_0.TabIndex = 14
        Me._imText1_0.TabStop = False
        '
        '_imText1_1
        '
        Me._imText1_1.CausesValidation = False
        Me._imText1_1.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._imText1_1.ImeMode = System.Windows.Forms.ImeMode.Off
        Me._imText1_1.Location = New System.Drawing.Point(112, 40)
        Me._imText1_1.Name = "_imText1_1"
        Me._imText1_1.ReadOnly = True
        Me._imText1_1.ReadOnlyBackColor = System.Drawing.SystemColors.Control
        Me._imText1_1.Size = New System.Drawing.Size(33, 23)
        Me._imText1_1.TabIndex = 15
        Me._imText1_1.TabStop = False
        '
        '_imText1_2
        '
        Me._imText1_2.CausesValidation = False
        Me._imText1_2.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._imText1_2.ImeMode = System.Windows.Forms.ImeMode.Off
        Me._imText1_2.Location = New System.Drawing.Point(148, 40)
        Me._imText1_2.Name = "_imText1_2"
        Me._imText1_2.ReadOnly = True
        Me._imText1_2.ReadOnlyBackColor = System.Drawing.SystemColors.Control
        Me._imText1_2.Size = New System.Drawing.Size(385, 23)
        Me._imText1_2.TabIndex = 16
        Me._imText1_2.TabStop = False
        '
        '_Label1_0
        '
        Me._Label1_0.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_0.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_0.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_0.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_0.ForeColor = System.Drawing.Color.White
        Me._Label1_0.Location = New System.Drawing.Point(8, 14)
        Me._Label1_0.Name = "_Label1_0"
        Me._Label1_0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_0.Size = New System.Drawing.Size(100, 23)
        Me._Label1_0.TabIndex = 31
        Me._Label1_0.Text = "���N��"
        Me._Label1_0.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        '_Label1_1
        '
        Me._Label1_1.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_1.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_1.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_1.ForeColor = System.Drawing.Color.White
        Me._Label1_1.Location = New System.Drawing.Point(8, 40)
        Me._Label1_1.Name = "_Label1_1"
        Me._Label1_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_1.Size = New System.Drawing.Size(100, 23)
        Me._Label1_1.TabIndex = 30
        Me._Label1_1.Text = "������"
        Me._Label1_1.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Picture2
        '
        Me.Picture2.BackColor = System.Drawing.SystemColors.Window
        Me.Picture2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Picture2.Controls.Add(Me._Command1_1)
        Me.Picture2.Controls.Add(Me._Command1_0)
        Me.Picture2.Controls.Add(Me._Command1_2)
        Me.Picture2.Controls.Add(Me._Command1_3)
        Me.Picture2.Controls.Add(Me._Command1_4)
        Me.Picture2.Cursor = System.Windows.Forms.Cursors.Default
        Me.Picture2.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Picture2.Location = New System.Drawing.Point(215, 120)
        Me.Picture2.Name = "Picture2"
        Me.Picture2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Picture2.Size = New System.Drawing.Size(256, 45)
        Me.Picture2.TabIndex = 23
        '
        '_Command1_1
        '
        Me._Command1_1.BackColor = System.Drawing.SystemColors.Control
        Me._Command1_1.Cursor = System.Windows.Forms.Cursors.Default
        Me._Command1_1.Font = New System.Drawing.Font("MS Mincho", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Command1_1.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Command1_1.Location = New System.Drawing.Point(0, 22)
        Me._Command1_1.Name = "_Command1_1"
        Me._Command1_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Command1_1.Size = New System.Drawing.Size(54, 22)
        Me._Command1_1.TabIndex = 28
        Me._Command1_1.TabStop = False
        Me._Command1_1.Text = "����"
        Me._Command1_1.UseVisualStyleBackColor = False
        '
        '_Command1_0
        '
        Me._Command1_0.BackColor = System.Drawing.SystemColors.Control
        Me._Command1_0.Cursor = System.Windows.Forms.Cursors.Default
        Me._Command1_0.Font = New System.Drawing.Font("MS Mincho", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Command1_0.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Command1_0.Location = New System.Drawing.Point(0, 0)
        Me._Command1_0.Name = "_Command1_0"
        Me._Command1_0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Command1_0.Size = New System.Drawing.Size(257, 22)
        Me._Command1_0.TabIndex = 27
        Me._Command1_0.TabStop = False
        Me._Command1_0.Text = "�_�@�@�@��"
        Me._Command1_0.UseVisualStyleBackColor = False
        '
        '_Command1_2
        '
        Me._Command1_2.BackColor = System.Drawing.SystemColors.Control
        Me._Command1_2.Cursor = System.Windows.Forms.Cursors.Default
        Me._Command1_2.Font = New System.Drawing.Font("MS Mincho", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Command1_2.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Command1_2.Location = New System.Drawing.Point(52, 22)
        Me._Command1_2.Name = "_Command1_2"
        Me._Command1_2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Command1_2.Size = New System.Drawing.Size(38, 22)
        Me._Command1_2.TabIndex = 26
        Me._Command1_2.TabStop = False
        Me._Command1_2.Text = "�P��"
        Me._Command1_2.UseVisualStyleBackColor = False
        '
        '_Command1_3
        '
        Me._Command1_3.BackColor = System.Drawing.SystemColors.Control
        Me._Command1_3.Cursor = System.Windows.Forms.Cursors.Default
        Me._Command1_3.Font = New System.Drawing.Font("MS Mincho", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Command1_3.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Command1_3.Location = New System.Drawing.Point(88, 22)
        Me._Command1_3.Name = "_Command1_3"
        Me._Command1_3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Command1_3.Size = New System.Drawing.Size(85, 22)
        Me._Command1_3.TabIndex = 25
        Me._Command1_3.TabStop = False
        Me._Command1_3.Text = "�P ��"
        Me._Command1_3.UseVisualStyleBackColor = False
        '
        '_Command1_4
        '
        Me._Command1_4.BackColor = System.Drawing.SystemColors.Control
        Me._Command1_4.Cursor = System.Windows.Forms.Cursors.Default
        Me._Command1_4.Font = New System.Drawing.Font("MS Mincho", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Command1_4.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Command1_4.Location = New System.Drawing.Point(172, 22)
        Me._Command1_4.Name = "_Command1_4"
        Me._Command1_4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Command1_4.Size = New System.Drawing.Size(85, 22)
        Me._Command1_4.TabIndex = 24
        Me._Command1_4.TabStop = False
        Me._Command1_4.Text = "�� �z"
        Me._Command1_4.UseVisualStyleBackColor = False
        '
        'Picture1
        '
        Me.Picture1.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Picture1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Picture1.Controls.Add(Me._cmdKey_3)
        Me.Picture1.Controls.Add(Me._cmdKey_12)
        Me.Picture1.Controls.Add(Me._cmdKey_4)
        Me.Picture1.Controls.Add(Me._cmdKey_10)
        Me.Picture1.Controls.Add(Me._cmdKey_6)
        Me.Picture1.Controls.Add(Me._cmdKey_7)
        Me.Picture1.Controls.Add(Me._cmdKey_8)
        Me.Picture1.Controls.Add(Me._cmdKey_9)
        Me.Picture1.Controls.Add(Me._cmdKey_1)
        Me.Picture1.Controls.Add(Me._cmdKey_11)
        Me.Picture1.Controls.Add(Me._cmdKey_2)
        Me.Picture1.Controls.Add(Me._cmdKey_5)
        Me.Picture1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Picture1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Picture1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Picture1.Location = New System.Drawing.Point(0, 668)
        Me.Picture1.Name = "Picture1"
        Me.Picture1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Picture1.Size = New System.Drawing.Size(1016, 51)
        Me.Picture1.TabIndex = 22
        '
        '_cmdKey_3
        '
        Me._cmdKey_3.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_3.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_3.Enabled = False
        Me._cmdKey_3.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_3.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_3.Location = New System.Drawing.Point(166, 4)
        Me._cmdKey_3.Name = "_cmdKey_3"
        Me._cmdKey_3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_3.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_3.TabIndex = 4
        Me._cmdKey_3.Text = "F3"
        Me._cmdKey_3.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_3.UseVisualStyleBackColor = False
        '
        '_cmdKey_12
        '
        Me._cmdKey_12.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_12.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_12.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_12.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_12.Location = New System.Drawing.Point(929, 4)
        Me._cmdKey_12.Name = "_cmdKey_12"
        Me._cmdKey_12.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_12.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_12.TabIndex = 13
        Me._cmdKey_12.Tag = "�������I�����܂��B"
        Me._cmdKey_12.Text = "F12" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "�I ��"
        Me._cmdKey_12.UseVisualStyleBackColor = False
        '
        '_cmdKey_4
        '
        Me._cmdKey_4.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_4.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_4.Enabled = False
        Me._cmdKey_4.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_4.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_4.Location = New System.Drawing.Point(246, 4)
        Me._cmdKey_4.Name = "_cmdKey_4"
        Me._cmdKey_4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_4.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_4.TabIndex = 5
        Me._cmdKey_4.Text = "F4"
        Me._cmdKey_4.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_4.UseVisualStyleBackColor = False
        '
        '_cmdKey_10
        '
        Me._cmdKey_10.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_10.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_10.Enabled = False
        Me._cmdKey_10.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_10.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_10.Location = New System.Drawing.Point(769, 4)
        Me._cmdKey_10.Name = "_cmdKey_10"
        Me._cmdKey_10.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_10.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_10.TabIndex = 11
        Me._cmdKey_10.Text = "F10"
        Me._cmdKey_10.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_10.UseVisualStyleBackColor = False
        '
        '_cmdKey_6
        '
        Me._cmdKey_6.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_6.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_6.Enabled = False
        Me._cmdKey_6.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_6.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_6.Location = New System.Drawing.Point(428, 4)
        Me._cmdKey_6.Name = "_cmdKey_6"
        Me._cmdKey_6.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_6.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_6.TabIndex = 7
        Me._cmdKey_6.Text = "F6"
        Me._cmdKey_6.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_6.UseVisualStyleBackColor = False
        '
        '_cmdKey_7
        '
        Me._cmdKey_7.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_7.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_7.Enabled = False
        Me._cmdKey_7.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_7.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_7.Location = New System.Drawing.Point(508, 4)
        Me._cmdKey_7.Name = "_cmdKey_7"
        Me._cmdKey_7.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_7.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_7.TabIndex = 8
        Me._cmdKey_7.Text = "F7"
        Me._cmdKey_7.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_7.UseVisualStyleBackColor = False
        '
        '_cmdKey_8
        '
        Me._cmdKey_8.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_8.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_8.Enabled = False
        Me._cmdKey_8.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_8.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_8.Location = New System.Drawing.Point(588, 4)
        Me._cmdKey_8.Name = "_cmdKey_8"
        Me._cmdKey_8.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_8.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_8.TabIndex = 9
        Me._cmdKey_8.Text = "F8"
        Me._cmdKey_8.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_8.UseVisualStyleBackColor = False
        '
        '_cmdKey_9
        '
        Me._cmdKey_9.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_9.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_9.Enabled = False
        Me._cmdKey_9.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_9.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_9.Location = New System.Drawing.Point(689, 4)
        Me._cmdKey_9.Name = "_cmdKey_9"
        Me._cmdKey_9.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_9.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_9.TabIndex = 10
        Me._cmdKey_9.Text = "F9"
        Me._cmdKey_9.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_9.UseVisualStyleBackColor = False
        '
        '_cmdKey_1
        '
        Me._cmdKey_1.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_1.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_1.Enabled = False
        Me._cmdKey_1.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_1.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_1.Location = New System.Drawing.Point(6, 4)
        Me._cmdKey_1.Name = "_cmdKey_1"
        Me._cmdKey_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_1.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_1.TabIndex = 2
        Me._cmdKey_1.Text = "F1"
        Me._cmdKey_1.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_1.UseVisualStyleBackColor = False
        '
        '_cmdKey_11
        '
        Me._cmdKey_11.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_11.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_11.Enabled = False
        Me._cmdKey_11.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_11.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_11.Location = New System.Drawing.Point(849, 4)
        Me._cmdKey_11.Name = "_cmdKey_11"
        Me._cmdKey_11.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_11.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_11.TabIndex = 12
        Me._cmdKey_11.Text = "F11"
        Me._cmdKey_11.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_11.UseVisualStyleBackColor = False
        '
        '_cmdKey_2
        '
        Me._cmdKey_2.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_2.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_2.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_2.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_2.Location = New System.Drawing.Point(86, 4)
        Me._cmdKey_2.Name = "_cmdKey_2"
        Me._cmdKey_2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_2.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_2.TabIndex = 3
        Me._cmdKey_2.Tag = "�f�[�^���C�����܂��B"
        Me._cmdKey_2.Text = "F2" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "�C ��"
        Me._cmdKey_2.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_2.UseVisualStyleBackColor = False
        '
        '_cmdKey_5
        '
        Me._cmdKey_5.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_5.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_5.Enabled = False
        Me._cmdKey_5.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_5.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_5.Location = New System.Drawing.Point(348, 4)
        Me._cmdKey_5.Name = "_cmdKey_5"
        Me._cmdKey_5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_5.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_5.TabIndex = 6
        Me._cmdKey_5.Tag = "��ʕ����̏ڍׂ�\�����܂��B"
        Me._cmdKey_5.Text = "F5" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "��ʕ�"
        Me._cmdKey_5.UseVisualStyleBackColor = False
        '
        'StatusBar1
        '
        Me.StatusBar1.Font = New System.Drawing.Font("MS Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.StatusBar1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me._StatusBar1_Panel1, Me.Message})
        Me.StatusBar1.Location = New System.Drawing.Point(0, 719)
        Me.StatusBar1.Name = "StatusBar1"
        Me.StatusBar1.Size = New System.Drawing.Size(1016, 23)
        Me.StatusBar1.TabIndex = 17
        '
        '_StatusBar1_Panel1
        '
        Me._StatusBar1_Panel1.AutoSize = False
        Me._StatusBar1_Panel1.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me._StatusBar1_Panel1.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter
        Me._StatusBar1_Panel1.Margin = New System.Windows.Forms.Padding(0)
        Me._StatusBar1_Panel1.Name = "_StatusBar1_Panel1"
        Me._StatusBar1_Panel1.Size = New System.Drawing.Size(117, 23)
        '
        'Message
        '
        Me.Message.AutoSize = False
        Me.Message.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me.Message.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter
        Me.Message.Margin = New System.Windows.Forms.Padding(0)
        Me.Message.Name = "Message"
        Me.Message.Size = New System.Drawing.Size(886, 23)
        Me.Message.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        '_imText2_2
        '
        Me._imText2_2.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me._imText2_2.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._imText2_2.ImeMode = System.Windows.Forms.ImeMode.Off
        Me._imText2_2.Location = New System.Drawing.Point(576, 6)
        Me._imText2_2.Name = "_imText2_2"
        Me._imText2_2.ReadOnly = True
        Me._imText2_2.ReadOnlyBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me._imText2_2.Size = New System.Drawing.Size(433, 23)
        Me._imText2_2.TabIndex = 19
        Me._imText2_2.TabStop = False
        '
        '_imText2_0
        '
        Me._imText2_0.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me._imText2_0.ContentAlignment = System.Drawing.ContentAlignment.TopCenter
        Me._imText2_0.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._imText2_0.ImeMode = System.Windows.Forms.ImeMode.Off
        Me._imText2_0.Location = New System.Drawing.Point(440, 6)
        Me._imText2_0.Name = "_imText2_0"
        Me._imText2_0.ReadOnly = True
        Me._imText2_0.ReadOnlyBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me._imText2_0.Size = New System.Drawing.Size(83, 23)
        Me._imText2_0.TabIndex = 20
        Me._imText2_0.TabStop = False
        '
        '_imText2_1
        '
        Me._imText2_1.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me._imText2_1.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._imText2_1.ImeMode = System.Windows.Forms.ImeMode.Off
        Me._imText2_1.Location = New System.Drawing.Point(527, 6)
        Me._imText2_1.Name = "_imText2_1"
        Me._imText2_1.ReadOnly = True
        Me._imText2_1.ReadOnlyBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me._imText2_1.Size = New System.Drawing.Size(45, 23)
        Me._imText2_1.TabIndex = 21
        Me._imText2_1.TabStop = False
        '
        'lblTitle
        '
        Me.lblTitle.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblTitle.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTitle.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblTitle.Font = New System.Drawing.Font("MS Mincho", 20.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblTitle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.lblTitle.Location = New System.Drawing.Point(0, 0)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblTitle.Size = New System.Drawing.Size(1015, 34)
        Me.lblTitle.TabIndex = 18
        Me.lblTitle.Text = " ���c��������"
        '
        'FpSpread1
        '
        Me.FpSpread1.AccessibleDescription = "FpSpread1, Sheet1, Row 0, Column 0"
        Me.FpSpread1.AllowUserToTouchZoom = False
        Me.FpSpread1.AllowUserZoom = False
        Me.FpSpread1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.FpSpread1.FocusRenderer = DefaultFocusIndicatorRenderer1
        Me.FpSpread1.Font = New System.Drawing.Font("MS PMincho", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.FpSpread1.HorizontalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.FpSpread1.HorizontalScrollBar.Name = ""
        Me.FpSpread1.HorizontalScrollBar.Renderer = DefaultScrollBarRenderer1
        Me.FpSpread1.HorizontalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.Never
        Me.FpSpread1.Location = New System.Drawing.Point(6, 119)
        Me.FpSpread1.Name = "FpSpread1"
        NamedStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        NamedStyle1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        NamedStyle1.Locked = False
        NamedStyle2.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        NamedStyle2.Font = New System.Drawing.Font("MS Mincho", 9.0!, System.Drawing.FontStyle.Bold)
        NamedStyle2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        NamedStyle2.Locked = False
        NamedStyle3.BackColor = System.Drawing.Color.Empty
        NamedStyle3.Border = ComplexBorder1
        NamedStyle3.ForeColor = System.Drawing.Color.Empty
        NamedStyle4.BackColor = System.Drawing.Color.Empty
        NamedStyle4.Border = ComplexBorder1
        NamedStyle4.ForeColor = System.Drawing.Color.Empty
        Me.FpSpread1.RowSplitBoxAlignment = FarPoint.Win.Spread.SplitBoxAlignment.Trailing
        Me.FpSpread1.RowSplitBoxPolicy = FarPoint.Win.Spread.SplitBoxPolicy.Never
        Me.FpSpread1.ScrollBarTrackPolicy = FarPoint.Win.Spread.ScrollBarTrackPolicy.Vertical
        Me.FpSpread1.SelectionBlockOptions = FarPoint.Win.Spread.SelectionBlockOptions.None
        Me.FpSpread1.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.FpSpread1_Sheet1})
        Me.FpSpread1.Size = New System.Drawing.Size(1005, 523)
        Me.FpSpread1.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Classic
        Me.FpSpread1.NamedStyles.AddRange(New FarPoint.Win.Spread.NamedStyle() {NamedStyle1, NamedStyle2, NamedStyle3, NamedStyle4})
        Me.FpSpread1.TabIndex = 0
        Me.FpSpread1.Tag = "�f�[�^��I�����ĉ������B"
        TipAppearance1.BackColor = System.Drawing.SystemColors.Info
        TipAppearance1.Font = New System.Drawing.Font("MS PGothic", 9.0!)
        TipAppearance1.ForeColor = System.Drawing.SystemColors.InfoText
        Me.FpSpread1.TextTipAppearance = TipAppearance1
        Me.FpSpread1.VerticalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.FpSpread1.VerticalScrollBar.Name = ""
        Me.FpSpread1.VerticalScrollBar.Renderer = DefaultScrollBarRenderer2
        Me.FpSpread1.VisualStyles = FarPoint.Win.VisualStyles.Off
        Me.FpSpread1.SetViewportLeftColumn(0, 0, 6)
        Me.FpSpread1.SetActiveViewport(0, 0, -1)
        '
        'FpSpread1_Sheet1
        '
        Me.FpSpread1_Sheet1.Reset()
        Me.FpSpread1_Sheet1.SheetName = "Sheet1"
        'Formulas and custom names must be loaded with R1C1 reference style
        Me.FpSpread1_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1
        Me.FpSpread1_Sheet1.ColumnCount = 13
        Me.FpSpread1_Sheet1.RowCount = 100
        Me.FpSpread1_Sheet1.ActiveSkin = FarPoint.Win.Spread.DefaultSkins.Default
        Me.FpSpread1_Sheet1.Cells.Get(0, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(0, 0).Value = "Z-99"
        Me.FpSpread1_Sheet1.Cells.Get(0, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(0, 1).Value = "�P�Q�R�S�T�U�V�W�X�O�P�Q�R�S�T�U�V�W�X�O"
        Me.FpSpread1_Sheet1.Cells.Get(0, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(0, 2).Value = "9,999.9"
        Me.FpSpread1_Sheet1.Cells.Get(0, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(0, 3).Value = "1234"
        Me.FpSpread1_Sheet1.Cells.Get(0, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(0, 4).Value = "9,999,999,999"
        Me.FpSpread1_Sheet1.Cells.Get(0, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(0, 5).Value = "9,999,999,999"
        TextCellType1.Static = True
        Me.FpSpread1_Sheet1.Cells.Get(0, 6).CellType = TextCellType1
        Me.FpSpread1_Sheet1.Cells.Get(0, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(0, 6).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Right
        Me.FpSpread1_Sheet1.Cells.Get(0, 6).Value = "9,999,999,999"
        Me.FpSpread1_Sheet1.Cells.Get(0, 6).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread1_Sheet1.Cells.Get(0, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(0, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(0, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(0, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(0, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(1, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(1, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(1, 1).Value = "1234567890123456789012345678901234567890"
        Me.FpSpread1_Sheet1.Cells.Get(1, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(1, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(1, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(1, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(1, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(1, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(1, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(1, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(1, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(1, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(2, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(2, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(2, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(2, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(2, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(2, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(2, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(2, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(2, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(2, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(2, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(2, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(3, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(3, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(3, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(3, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(3, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(3, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(3, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(3, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(3, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(3, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(3, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(3, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(4, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(4, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(4, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(4, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(4, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(4, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(4, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(4, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(4, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(4, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(4, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(4, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(5, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(5, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(5, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(5, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(5, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(5, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(5, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(5, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(5, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(5, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(5, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(5, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(6, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(6, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(6, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(6, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(6, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(6, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(6, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(6, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(6, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(6, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(6, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(6, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(7, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(7, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(7, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(7, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(7, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(7, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(7, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(7, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(7, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(7, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(7, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(7, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(8, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(8, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(8, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(8, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(8, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(8, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(8, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(8, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(8, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(8, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(8, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(8, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(9, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(9, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(9, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(9, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(9, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(9, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(9, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(9, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(9, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(9, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(9, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(9, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(10, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(10, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(10, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(10, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(10, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(10, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(10, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(10, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(10, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(10, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(10, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(10, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(11, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(11, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(11, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(11, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(11, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(11, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(11, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(11, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(11, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(11, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(11, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(11, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(12, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(12, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(12, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(12, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(12, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(12, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(12, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(12, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(12, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(12, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(12, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(12, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(13, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(13, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(13, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(13, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(13, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(13, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(13, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(13, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(13, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(13, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(13, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(13, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(14, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(14, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(14, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(14, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(14, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(14, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(14, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(14, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(14, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(14, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(14, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(14, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(15, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(15, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(15, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(15, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(15, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(15, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(15, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(15, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(15, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(15, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(15, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(15, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(16, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(16, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(16, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(16, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(16, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(16, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(16, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(16, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(16, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(16, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(16, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(16, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(17, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(17, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(17, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(17, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(17, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(17, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(17, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(17, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(17, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(17, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(17, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(17, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(18, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(18, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(18, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(18, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(18, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(18, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(18, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(18, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(18, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(18, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(18, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(18, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(19, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(19, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(19, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(19, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(19, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(19, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(19, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(19, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(19, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(19, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(19, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(19, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(20, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(20, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(20, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(20, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(20, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(20, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(20, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(20, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(20, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(20, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(20, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(20, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(21, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(21, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(21, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(21, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(21, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(21, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(21, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(21, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(21, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(21, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(21, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(21, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(22, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(22, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(22, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(22, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(22, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(22, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(22, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(22, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(22, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(22, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(22, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(22, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(23, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(23, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(23, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(23, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(23, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(23, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(23, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(23, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(23, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(23, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(23, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(23, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(24, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(24, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(24, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(24, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(24, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(24, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(24, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(24, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(24, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(24, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(24, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(24, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(25, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(25, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(25, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(25, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(25, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(25, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(25, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(25, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(25, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(25, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(25, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(25, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(26, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(26, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(26, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(26, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(26, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(26, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(26, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(26, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(26, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(26, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(26, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(26, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(27, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(27, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(27, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(27, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(27, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(27, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(27, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(27, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(27, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(27, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(27, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(27, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(28, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(28, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(28, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(28, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(28, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(28, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(28, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(28, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(28, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(28, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(28, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(28, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(29, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(29, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(29, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(29, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(29, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(29, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(29, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(29, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(29, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(29, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(29, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(29, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(30, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(30, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(30, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(30, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(30, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(30, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(30, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(30, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(30, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(30, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(30, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(30, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(31, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(31, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(31, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(31, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(31, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(31, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(31, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(31, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(31, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(31, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(31, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(31, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(32, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(32, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(32, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(32, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(32, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(32, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(32, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(32, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(32, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(32, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(32, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(32, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(33, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(33, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(33, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(33, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(33, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(33, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(33, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(33, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(33, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(33, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(33, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(33, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(34, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(34, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(34, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(34, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(34, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(34, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(34, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(34, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(34, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(34, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(34, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(34, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(35, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(35, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(35, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(35, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(35, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(35, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(35, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(35, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(35, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(35, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(35, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(35, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(36, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(36, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(36, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(36, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(36, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(36, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(36, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(36, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(36, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(36, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(36, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(36, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(37, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(37, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(37, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(37, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(37, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(37, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(37, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(37, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(37, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(37, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(37, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(37, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(38, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(38, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(38, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(38, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(38, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(38, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(38, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(38, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(38, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(38, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(38, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(38, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(39, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(39, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(39, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(39, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(39, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(39, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(39, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(39, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(39, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(39, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(39, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(39, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(40, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(40, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(40, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(40, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(40, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(40, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(40, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(40, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(40, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(40, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(40, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(40, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(41, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(41, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(41, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(41, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(41, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(41, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(41, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(41, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(41, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(41, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(41, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(41, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(42, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(42, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(42, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(42, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(42, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(42, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(42, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(42, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(42, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(42, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(42, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(42, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(43, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(43, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(43, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(43, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(43, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(43, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(43, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(43, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(43, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(43, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(43, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(43, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(44, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(44, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(44, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(44, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(44, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(44, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(44, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(44, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(44, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(44, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(44, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(44, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(45, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(45, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(45, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(45, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(45, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(45, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(45, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(45, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(45, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(45, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(45, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(45, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(46, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(46, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(46, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(46, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(46, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(46, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(46, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(46, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(46, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(46, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(46, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(46, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(47, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(47, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(47, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(47, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(47, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(47, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(47, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(47, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(47, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(47, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(47, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(47, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(48, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(48, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(48, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(48, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(48, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(48, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(48, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(48, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(48, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(48, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(48, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(48, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(49, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(49, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(49, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(49, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(49, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(49, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(49, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(49, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(49, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(49, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(49, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(49, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(50, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(50, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(50, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(50, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(50, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(50, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(50, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(50, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(50, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(50, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(50, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(50, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(51, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(51, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(51, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(51, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(51, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(51, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(51, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(51, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(51, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(51, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(51, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(51, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(52, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(52, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(52, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(52, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(52, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(52, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(52, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(52, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(52, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(52, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(52, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(52, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(53, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(53, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(53, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(53, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(53, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(53, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(53, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(53, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(53, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(53, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(53, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(53, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(54, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(54, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(54, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(54, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(54, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(54, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(54, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(54, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(54, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(54, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(54, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(54, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(55, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(55, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(55, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(55, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(55, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(55, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(55, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(55, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(55, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(55, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(55, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(55, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(56, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(56, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(56, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(56, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(56, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(56, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(56, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(56, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(56, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(56, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(56, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(56, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(57, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(57, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(57, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(57, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(57, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(57, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(57, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(57, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(57, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(57, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(57, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(57, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(58, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(58, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(58, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(58, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(58, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(58, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(58, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(58, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(58, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(58, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(58, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(58, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(59, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(59, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(59, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(59, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(59, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(59, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(59, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(59, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(59, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(59, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(59, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(59, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(60, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(60, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(60, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(60, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(60, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(60, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(60, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(60, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(60, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(60, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(60, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(60, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(61, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(61, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(61, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(61, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(61, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(61, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(61, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(61, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(61, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(61, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(61, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(61, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(62, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(62, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(62, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(62, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(62, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(62, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(62, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(62, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(62, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(62, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(62, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(62, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(63, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(63, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(63, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(63, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(63, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(63, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(63, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(63, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(63, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(63, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(63, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(63, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(64, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(64, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(64, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(64, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(64, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(64, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(64, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(64, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(64, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(64, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(64, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(64, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(65, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(65, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(65, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(65, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(65, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(65, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(65, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(65, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(65, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(65, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(65, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(65, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(66, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(66, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(66, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(66, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(66, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(66, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(66, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(66, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(66, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(66, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(66, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(66, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(67, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(67, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(67, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(67, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(67, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(67, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(67, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(67, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(67, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(67, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(67, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(67, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(68, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(68, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(68, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(68, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(68, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(68, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(68, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(68, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(68, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(68, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(68, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(68, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(69, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(69, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(69, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(69, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(69, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(69, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(69, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(69, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(69, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(69, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(69, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(69, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(70, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(70, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(70, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(70, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(70, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(70, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(70, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(70, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(70, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(70, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(70, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(70, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(71, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(71, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(71, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(71, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(71, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(71, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(71, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(71, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(71, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(71, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(71, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(71, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(72, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(72, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(72, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(72, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(72, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(72, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(72, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(72, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(72, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(72, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(72, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(72, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(73, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(73, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(73, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(73, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(73, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(73, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(73, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(73, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(73, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(73, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(73, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(73, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(74, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(74, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(74, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(74, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(74, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(74, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(74, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(74, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(74, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(74, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(74, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(74, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(75, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(75, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(75, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(75, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(75, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(75, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(75, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(75, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(75, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(75, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(75, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(75, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(76, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(76, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(76, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(76, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(76, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(76, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(76, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(76, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(76, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(76, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(76, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(76, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(77, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(77, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(77, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(77, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(77, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(77, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(77, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(77, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(77, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(77, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(77, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(77, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(78, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(78, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(78, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(78, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(78, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(78, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(78, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(78, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(78, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(78, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(78, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(78, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(79, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(79, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(79, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(79, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(79, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(79, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(79, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(79, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(79, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(79, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(79, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(79, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(80, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(80, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(80, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(80, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(80, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(80, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(80, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(80, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(80, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(80, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(80, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(80, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(81, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(81, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(81, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(81, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(81, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(81, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(81, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(81, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(81, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(81, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(81, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(81, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(82, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(82, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(82, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(82, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(82, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(82, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(82, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(82, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(82, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(82, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(82, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(82, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(83, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(83, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(83, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(83, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(83, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(83, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(83, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(83, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(83, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(83, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(83, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(83, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(84, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(84, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(84, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(84, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(84, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(84, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(84, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(84, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(84, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(84, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(84, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(84, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(85, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(85, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(85, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(85, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(85, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(85, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(85, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(85, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(85, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(85, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(85, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(85, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(86, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(86, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(86, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(86, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(86, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(86, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(86, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(86, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(86, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(86, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(86, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(86, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(87, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(87, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(87, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(87, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(87, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(87, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(87, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(87, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(87, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(87, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(87, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(87, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(88, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(88, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(88, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(88, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(88, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(88, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(88, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(88, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(88, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(88, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(88, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(88, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(89, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(89, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(89, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(89, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(89, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(89, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(89, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(89, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(89, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(89, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(89, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(89, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(90, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(90, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(90, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(90, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(90, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(90, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(90, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(90, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(90, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(90, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(90, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(90, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(91, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(91, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(91, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(91, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(91, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(91, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(91, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(91, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(91, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(91, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(91, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(91, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(92, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(92, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(92, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(92, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(92, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(92, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(92, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(92, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(92, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(92, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(92, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(92, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(93, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(93, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(93, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(93, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(93, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(93, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(93, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(93, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(93, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(93, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(93, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(93, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(94, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(94, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(94, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(94, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(94, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(94, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(94, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(94, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(94, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(94, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(94, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(94, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(95, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(95, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(95, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(95, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(95, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(95, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(95, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(95, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(95, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(95, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(95, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(95, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(96, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(96, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(96, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(96, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(96, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(96, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(96, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(96, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(96, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(96, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(96, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(96, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(97, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(97, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(97, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(97, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(97, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(97, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(97, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(97, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(97, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(97, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(97, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(97, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(98, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(98, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(98, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(98, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(98, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(98, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(98, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(98, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(98, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(98, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(98, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(98, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(99, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(99, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(99, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(99, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(99, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(99, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(99, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(99, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(99, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(99, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(99, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.Cells.Get(99, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread1_Sheet1.ColumnFooter.Columns.Default.Resizable = False
        Me.FpSpread1_Sheet1.ColumnFooter.Columns.Default.SortIndicator = FarPoint.Win.Spread.Model.SortIndicator.None
        Me.FpSpread1_Sheet1.ColumnFooter.Columns.Default.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread1_Sheet1.ColumnFooter.DefaultStyle.BackColor = System.Drawing.Color.Empty
        Me.FpSpread1_Sheet1.ColumnFooter.DefaultStyle.ForeColor = System.Drawing.Color.Empty
        Me.FpSpread1_Sheet1.ColumnFooter.DefaultStyle.Locked = False
        Me.FpSpread1_Sheet1.ColumnFooter.DefaultStyle.Parent = "HeaderDefault"
        Me.FpSpread1_Sheet1.ColumnFooter.DefaultStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread1_Sheet1.ColumnFooter.Rows.Default.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread1_Sheet1.ColumnFooterSheetCornerStyle.BackColor = System.Drawing.Color.Empty
        Me.FpSpread1_Sheet1.ColumnFooterSheetCornerStyle.ForeColor = System.Drawing.Color.Empty
        Me.FpSpread1_Sheet1.ColumnFooterSheetCornerStyle.Locked = False
        Me.FpSpread1_Sheet1.ColumnFooterSheetCornerStyle.Parent = "RowHeaderDefault"
        Me.FpSpread1_Sheet1.ColumnFooterSheetCornerStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 0).Value = "�H��"
        Me.FpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = "���@�@��"
        Me.FpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 2).Value = "����"
        Me.FpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 3).Value = "�P��"
        Me.FpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 4).Value = "�P ��"
        Me.FpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 5).Value = "�� �z"
        Me.FpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 6).Value = "�x�����z"
        Me.FpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 7).Value = "�ݐϋ��z"
        Me.FpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 8).Value = "���㏊�v����"
        Me.FpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 9).Value = "���{�������z"
        Me.FpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 10).Value = "�\�Z�Δ�"
        Me.FpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 11).Value = "�ύX����"
        Me.FpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 12).Value = "���הԍ�"
        Me.FpSpread1_Sheet1.ColumnHeader.Columns.Default.Resizable = False
        Me.FpSpread1_Sheet1.ColumnHeader.Columns.Default.SortIndicator = FarPoint.Win.Spread.Model.SortIndicator.None
        Me.FpSpread1_Sheet1.ColumnHeader.Columns.Default.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread1_Sheet1.ColumnHeader.DefaultStyle.BackColor = System.Drawing.Color.Empty
        Me.FpSpread1_Sheet1.ColumnHeader.DefaultStyle.Border = ComplexBorder2
        Me.FpSpread1_Sheet1.ColumnHeader.DefaultStyle.Font = New System.Drawing.Font("MS Mincho", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.FpSpread1_Sheet1.ColumnHeader.DefaultStyle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.FpSpread1_Sheet1.ColumnHeader.DefaultStyle.Locked = False
        Me.FpSpread1_Sheet1.ColumnHeader.DefaultStyle.Parent = "HeaderDefault"
        Me.FpSpread1_Sheet1.ColumnHeader.DefaultStyle.Renderer = CustomSpdHeader9
        Me.FpSpread1_Sheet1.ColumnHeader.DefaultStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread1_Sheet1.ColumnHeader.Rows.Default.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread1_Sheet1.ColumnHeader.Rows.Get(0).Height = 45.0!
        Me.FpSpread1_Sheet1.Columns.Default.Resizable = False
        Me.FpSpread1_Sheet1.Columns.Default.SortIndicator = FarPoint.Win.Spread.Model.SortIndicator.None
        TextCellType2.Static = True
        Me.FpSpread1_Sheet1.Columns.Get(0).CellType = TextCellType2
        Me.FpSpread1_Sheet1.Columns.Get(0).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.FpSpread1_Sheet1.Columns.Get(0).Label = "�H��"
        Me.FpSpread1_Sheet1.Columns.Get(0).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread1_Sheet1.Columns.Get(0).Width = 37.0!
        Me.FpSpread1_Sheet1.Columns.Get(1).Border = ComplexBorder1
        TextCellType3.Static = True
        Me.FpSpread1_Sheet1.Columns.Get(1).CellType = TextCellType3
        Me.FpSpread1_Sheet1.Columns.Get(1).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Left
        Me.FpSpread1_Sheet1.Columns.Get(1).Label = "���@�@��"
        Me.FpSpread1_Sheet1.Columns.Get(1).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread1_Sheet1.Columns.Get(1).Width = 137.0!
        TextCellType4.Static = True
        Me.FpSpread1_Sheet1.Columns.Get(2).CellType = TextCellType4
        Me.FpSpread1_Sheet1.Columns.Get(2).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Right
        Me.FpSpread1_Sheet1.Columns.Get(2).Label = "����"
        Me.FpSpread1_Sheet1.Columns.Get(2).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread1_Sheet1.Columns.Get(2).Width = 52.0!
        Me.FpSpread1_Sheet1.Columns.Get(3).CellType = TextCellType2
        Me.FpSpread1_Sheet1.Columns.Get(3).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.FpSpread1_Sheet1.Columns.Get(3).Label = "�P��"
        Me.FpSpread1_Sheet1.Columns.Get(3).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread1_Sheet1.Columns.Get(3).Width = 36.0!
        Me.FpSpread1_Sheet1.Columns.Get(4).CellType = TextCellType4
        Me.FpSpread1_Sheet1.Columns.Get(4).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Right
        Me.FpSpread1_Sheet1.Columns.Get(4).Label = "�P ��"
        Me.FpSpread1_Sheet1.Columns.Get(4).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread1_Sheet1.Columns.Get(4).Width = 84.0!
        Me.FpSpread1_Sheet1.Columns.Get(5).Border = ComplexBorder1
        TextCellType5.Static = True
        Me.FpSpread1_Sheet1.Columns.Get(5).CellType = TextCellType5
        Me.FpSpread1_Sheet1.Columns.Get(5).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Right
        Me.FpSpread1_Sheet1.Columns.Get(5).Label = "�� �z"
        Me.FpSpread1_Sheet1.Columns.Get(5).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread1_Sheet1.Columns.Get(5).Width = 84.0!
        Me.FpSpread1_Sheet1.Columns.Get(6).CellType = TextCellType4
        Me.FpSpread1_Sheet1.Columns.Get(6).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Right
        Me.FpSpread1_Sheet1.Columns.Get(6).Label = "�x�����z"
        Me.FpSpread1_Sheet1.Columns.Get(6).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread1_Sheet1.Columns.Get(6).Width = 84.0!
        Me.FpSpread1_Sheet1.Columns.Get(7).CellType = TextCellType4
        Me.FpSpread1_Sheet1.Columns.Get(7).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Right
        Me.FpSpread1_Sheet1.Columns.Get(7).Label = "�ݐϋ��z"
        Me.FpSpread1_Sheet1.Columns.Get(7).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread1_Sheet1.Columns.Get(7).Width = 88.0!
        Me.FpSpread1_Sheet1.Columns.Get(8).CellType = TextCellType4
        Me.FpSpread1_Sheet1.Columns.Get(8).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Right
        Me.FpSpread1_Sheet1.Columns.Get(8).Label = "���㏊�v����"
        Me.FpSpread1_Sheet1.Columns.Get(8).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread1_Sheet1.Columns.Get(8).Width = 88.0!
        Me.FpSpread1_Sheet1.Columns.Get(9).CellType = TextCellType4
        Me.FpSpread1_Sheet1.Columns.Get(9).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Right
        Me.FpSpread1_Sheet1.Columns.Get(9).Label = "���{�������z"
        Me.FpSpread1_Sheet1.Columns.Get(9).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread1_Sheet1.Columns.Get(9).Width = 88.0!
        Me.FpSpread1_Sheet1.Columns.Get(10).CellType = TextCellType4
        Me.FpSpread1_Sheet1.Columns.Get(10).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Right
        Me.FpSpread1_Sheet1.Columns.Get(10).Label = "�\�Z�Δ�"
        Me.FpSpread1_Sheet1.Columns.Get(10).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread1_Sheet1.Columns.Get(10).Width = 84.0!
        Me.FpSpread1_Sheet1.Columns.Get(11).CellType = TextCellType4
        Me.FpSpread1_Sheet1.Columns.Get(11).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Right
        Me.FpSpread1_Sheet1.Columns.Get(11).Label = "�ύX����"
        Me.FpSpread1_Sheet1.Columns.Get(11).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread1_Sheet1.Columns.Get(11).Width = 88.0!
        Me.FpSpread1_Sheet1.Columns.Get(12).CellType = TextCellType4
        Me.FpSpread1_Sheet1.Columns.Get(12).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Right
        Me.FpSpread1_Sheet1.Columns.Get(12).Label = "���הԍ�"
        Me.FpSpread1_Sheet1.Columns.Get(12).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread1_Sheet1.Columns.Get(12).Visible = False
        Me.FpSpread1_Sheet1.Columns.Get(12).Width = 0!
        Me.FpSpread1_Sheet1.DefaultStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        TextCellType6.MaxLength = 60
        Me.FpSpread1_Sheet1.DefaultStyle.CellType = TextCellType6
        Me.FpSpread1_Sheet1.DefaultStyle.Font = New System.Drawing.Font("MS Mincho", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.FpSpread1_Sheet1.DefaultStyle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.FpSpread1_Sheet1.DefaultStyle.Locked = True
        Me.FpSpread1_Sheet1.DefaultStyle.Parent = "DataAreaDefault"
        Me.FpSpread1_Sheet1.DefaultStyle.Renderer = TextCellType6
        Me.FpSpread1_Sheet1.FilterBar.DefaultStyle.BackColor = System.Drawing.Color.Empty
        Me.FpSpread1_Sheet1.FilterBar.DefaultStyle.ForeColor = System.Drawing.Color.Empty
        Me.FpSpread1_Sheet1.FilterBar.DefaultStyle.Locked = False
        Me.FpSpread1_Sheet1.FilterBar.DefaultStyle.Parent = "FilterBarDefault"
        Me.FpSpread1_Sheet1.FilterBar.DefaultStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread1_Sheet1.FilterBarHeaderStyle.BackColor = System.Drawing.Color.Empty
        Me.FpSpread1_Sheet1.FilterBarHeaderStyle.ForeColor = System.Drawing.Color.Empty
        Me.FpSpread1_Sheet1.FilterBarHeaderStyle.Locked = False
        Me.FpSpread1_Sheet1.FilterBarHeaderStyle.Parent = "RowHeaderDefault"
        Me.FpSpread1_Sheet1.FilterBarHeaderStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread1_Sheet1.FrozenColumnCount = 6
        Me.FpSpread1_Sheet1.OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        Me.FpSpread1_Sheet1.Protect = True
        Me.FpSpread1_Sheet1.RowHeader.Columns.Default.Resizable = False
        Me.FpSpread1_Sheet1.RowHeader.Columns.Default.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread1_Sheet1.RowHeader.Columns.Get(0).Width = 34.0!
        Me.FpSpread1_Sheet1.RowHeader.DefaultStyle.BackColor = System.Drawing.Color.Empty
        Me.FpSpread1_Sheet1.RowHeader.DefaultStyle.Border = ComplexBorder2
        Me.FpSpread1_Sheet1.RowHeader.DefaultStyle.Font = New System.Drawing.Font("MS Mincho", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.FpSpread1_Sheet1.RowHeader.DefaultStyle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.FpSpread1_Sheet1.RowHeader.DefaultStyle.Locked = False
        Me.FpSpread1_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderDefault"
        Me.FpSpread1_Sheet1.RowHeader.DefaultStyle.Renderer = CustomSpdHeader10
        Me.FpSpread1_Sheet1.RowHeader.DefaultStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread1_Sheet1.RowHeader.Rows.Default.Resizable = False
        Me.FpSpread1_Sheet1.RowHeader.Rows.Default.Visible = True
        Me.FpSpread1_Sheet1.RowHeader.Rows.Default.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread1_Sheet1.Rows.Default.Height = 17.0!
        Me.FpSpread1_Sheet1.Rows.Default.Resizable = False
        Me.FpSpread1_Sheet1.Rows.Default.Visible = True
        Me.FpSpread1_Sheet1.SelectionUnit = FarPoint.Win.Spread.Model.SelectionUnit.Row
        Me.FpSpread1_Sheet1.SheetCornerStyle.BackColor = System.Drawing.Color.Empty
        Me.FpSpread1_Sheet1.SheetCornerStyle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.FpSpread1_Sheet1.SheetCornerStyle.Locked = False
        Me.FpSpread1_Sheet1.SheetCornerStyle.Parent = "RowHeaderDefault"
        Me.FpSpread1_Sheet1.SheetCornerStyle.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread1_Sheet1.SheetCornerStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread1_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1
        '
        'FpSpread2
        '
        Me.FpSpread2.AccessibleDescription = "FpSpread2, Sheet1, Row 0, Column 0"
        Me.FpSpread2.AllowUserToTouchZoom = False
        Me.FpSpread2.AllowUserZoom = False
        Me.FpSpread2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.FpSpread2.FocusRenderer = DefaultFocusIndicatorRenderer1
        Me.FpSpread2.Font = New System.Drawing.Font("MS Mincho", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FpSpread2.HorizontalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.FpSpread2.HorizontalScrollBar.Name = ""
        Me.FpSpread2.HorizontalScrollBar.Renderer = DefaultScrollBarRenderer3
        Me.FpSpread2.HorizontalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.Never
        Me.FpSpread2.Location = New System.Drawing.Point(6, 620)
        Me.FpSpread2.Name = "FpSpread2"
        NamedStyle5.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        NamedStyle5.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        NamedStyle5.Locked = False
        NamedStyle6.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        NamedStyle6.Font = New System.Drawing.Font("MS Mincho", 9.0!, System.Drawing.FontStyle.Bold)
        NamedStyle6.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        NamedStyle6.Locked = False
        NamedStyle7.BackColor = System.Drawing.Color.Empty
        NamedStyle7.Border = ComplexBorder3
        NamedStyle7.ForeColor = System.Drawing.Color.Empty
        NamedStyle8.BackColor = System.Drawing.Color.Empty
        NamedStyle8.Border = ComplexBorder3
        NamedStyle8.ForeColor = System.Drawing.Color.Empty
        Me.FpSpread2.ScrollBarTrackPolicy = FarPoint.Win.Spread.ScrollBarTrackPolicy.Horizontal
        Me.FpSpread2.SelectionBlockOptions = FarPoint.Win.Spread.SelectionBlockOptions.None
        Me.FpSpread2.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.FpSpread2_Sheet1})
        Me.FpSpread2.Size = New System.Drawing.Size(1005, 38)
        Me.FpSpread2.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Classic
        Me.FpSpread2.NamedStyles.AddRange(New FarPoint.Win.Spread.NamedStyle() {NamedStyle5, NamedStyle6, NamedStyle7, NamedStyle8})
        Me.FpSpread2.TabIndex = 34
        Me.FpSpread2.TabStop = False
        TipAppearance2.BackColor = System.Drawing.SystemColors.Info
        TipAppearance2.Font = New System.Drawing.Font("MS PGothic", 9.0!)
        TipAppearance2.ForeColor = System.Drawing.SystemColors.InfoText
        Me.FpSpread2.TextTipAppearance = TipAppearance2
        Me.FpSpread2.VerticalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.FpSpread2.VerticalScrollBar.Name = ""
        Me.FpSpread2.VerticalScrollBar.Renderer = DefaultScrollBarRenderer4
        Me.FpSpread2.VerticalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.Never
        Me.FpSpread2.VisualStyles = FarPoint.Win.VisualStyles.Off
        Me.FpSpread2.SetViewportLeftColumn(0, 0, 6)
        Me.FpSpread2.SetActiveViewport(0, 0, -1)
        '
        'FpSpread2_Sheet1
        '
        Me.FpSpread2_Sheet1.Reset()
        Me.FpSpread2_Sheet1.SheetName = "Sheet1"
        'Formulas and custom names must be loaded with R1C1 reference style
        Me.FpSpread2_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1
        Me.FpSpread2_Sheet1.ColumnCount = 12
        Me.FpSpread2_Sheet1.RowCount = 1
        Me.FpSpread2_Sheet1.ActiveSkin = FarPoint.Win.Spread.DefaultSkins.Default
        Me.FpSpread2_Sheet1.Cells.Get(0, 0).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread2_Sheet1.Cells.Get(0, 1).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread2_Sheet1.Cells.Get(0, 2).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread2_Sheet1.Cells.Get(0, 3).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread2_Sheet1.Cells.Get(0, 4).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread2_Sheet1.Cells.Get(0, 5).BackColor = System.Drawing.Color.FromArgb(CType(CType(221, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.FpSpread2_Sheet1.Cells.Get(0, 5).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread2_Sheet1.Cells.Get(0, 5).ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.FpSpread2_Sheet1.Cells.Get(0, 6).BackColor = System.Drawing.Color.FromArgb(CType(CType(221, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.FpSpread2_Sheet1.Cells.Get(0, 6).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread2_Sheet1.Cells.Get(0, 6).ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.FpSpread2_Sheet1.Cells.Get(0, 7).BackColor = System.Drawing.Color.FromArgb(CType(CType(221, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.FpSpread2_Sheet1.Cells.Get(0, 7).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread2_Sheet1.Cells.Get(0, 7).ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.FpSpread2_Sheet1.Cells.Get(0, 8).BackColor = System.Drawing.Color.FromArgb(CType(CType(223, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.FpSpread2_Sheet1.Cells.Get(0, 8).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread2_Sheet1.Cells.Get(0, 8).ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.FpSpread2_Sheet1.Cells.Get(0, 9).BackColor = System.Drawing.Color.FromArgb(CType(CType(223, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.FpSpread2_Sheet1.Cells.Get(0, 9).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread2_Sheet1.Cells.Get(0, 9).ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.FpSpread2_Sheet1.Cells.Get(0, 10).BackColor = System.Drawing.Color.FromArgb(CType(CType(223, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.FpSpread2_Sheet1.Cells.Get(0, 10).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread2_Sheet1.Cells.Get(0, 10).ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.FpSpread2_Sheet1.Cells.Get(0, 11).BackColor = System.Drawing.Color.FromArgb(CType(CType(223, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.FpSpread2_Sheet1.Cells.Get(0, 11).Font = New System.Drawing.Font("MS Mincho", 9.0!)
        Me.FpSpread2_Sheet1.Cells.Get(0, 11).ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.FpSpread2_Sheet1.ColumnFooter.Columns.Default.Resizable = False
        Me.FpSpread2_Sheet1.ColumnFooter.Columns.Default.SortIndicator = FarPoint.Win.Spread.Model.SortIndicator.None
        Me.FpSpread2_Sheet1.ColumnFooter.Columns.Default.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread2_Sheet1.ColumnFooter.DefaultStyle.BackColor = System.Drawing.Color.Empty
        Me.FpSpread2_Sheet1.ColumnFooter.DefaultStyle.ForeColor = System.Drawing.Color.Empty
        Me.FpSpread2_Sheet1.ColumnFooter.DefaultStyle.Locked = False
        Me.FpSpread2_Sheet1.ColumnFooter.DefaultStyle.Parent = "HeaderDefault"
        Me.FpSpread2_Sheet1.ColumnFooter.DefaultStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread2_Sheet1.ColumnFooter.Rows.Default.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread2_Sheet1.ColumnFooterSheetCornerStyle.BackColor = System.Drawing.Color.Empty
        Me.FpSpread2_Sheet1.ColumnFooterSheetCornerStyle.ForeColor = System.Drawing.Color.Empty
        Me.FpSpread2_Sheet1.ColumnFooterSheetCornerStyle.Locked = False
        Me.FpSpread2_Sheet1.ColumnFooterSheetCornerStyle.Parent = "RowHeaderDefault"
        Me.FpSpread2_Sheet1.ColumnFooterSheetCornerStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread2_Sheet1.ColumnHeader.Cells.Get(0, 0).Value = "�H��"
        Me.FpSpread2_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = "���@�@��"
        Me.FpSpread2_Sheet1.ColumnHeader.Cells.Get(0, 2).Value = "����"
        Me.FpSpread2_Sheet1.ColumnHeader.Cells.Get(0, 3).Value = "�P��"
        Me.FpSpread2_Sheet1.ColumnHeader.Cells.Get(0, 4).Value = "�P ��"
        Me.FpSpread2_Sheet1.ColumnHeader.Cells.Get(0, 5).Value = "�� �z"
        Me.FpSpread2_Sheet1.ColumnHeader.Cells.Get(0, 6).Value = "�� �z"
        Me.FpSpread2_Sheet1.ColumnHeader.Cells.Get(0, 7).Value = "�ݐϋ��z"
        Me.FpSpread2_Sheet1.ColumnHeader.Cells.Get(0, 8).Value = "���㏊�v����"
        Me.FpSpread2_Sheet1.ColumnHeader.Cells.Get(0, 9).Value = "���{�������z"
        Me.FpSpread2_Sheet1.ColumnHeader.Cells.Get(0, 10).Value = "�\�Z�Δ�"
        Me.FpSpread2_Sheet1.ColumnHeader.Cells.Get(0, 11).Value = "�ύX����"
        Me.FpSpread2_Sheet1.ColumnHeader.Columns.Default.Resizable = False
        Me.FpSpread2_Sheet1.ColumnHeader.Columns.Default.SortIndicator = FarPoint.Win.Spread.Model.SortIndicator.None
        Me.FpSpread2_Sheet1.ColumnHeader.Columns.Default.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread2_Sheet1.ColumnHeader.DefaultStyle.BackColor = System.Drawing.Color.Empty
        Me.FpSpread2_Sheet1.ColumnHeader.DefaultStyle.Font = New System.Drawing.Font("MS Mincho", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.FpSpread2_Sheet1.ColumnHeader.DefaultStyle.ForeColor = System.Drawing.Color.Empty
        Me.FpSpread2_Sheet1.ColumnHeader.DefaultStyle.Locked = False
        Me.FpSpread2_Sheet1.ColumnHeader.DefaultStyle.Parent = "HeaderDefault"
        Me.FpSpread2_Sheet1.ColumnHeader.DefaultStyle.Renderer = CustomSpdHeader11
        Me.FpSpread2_Sheet1.ColumnHeader.DefaultStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread2_Sheet1.ColumnHeader.Rows.Default.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread2_Sheet1.Columns.Default.Resizable = False
        Me.FpSpread2_Sheet1.Columns.Default.SortIndicator = FarPoint.Win.Spread.Model.SortIndicator.None
        Me.FpSpread2_Sheet1.Columns.Get(0).Border = ComplexBorder4
        TextCellType7.Static = True
        Me.FpSpread2_Sheet1.Columns.Get(0).CellType = TextCellType7
        Me.FpSpread2_Sheet1.Columns.Get(0).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.FpSpread2_Sheet1.Columns.Get(0).Label = "�H��"
        Me.FpSpread2_Sheet1.Columns.Get(0).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread2_Sheet1.Columns.Get(0).Width = 37.0!
        Me.FpSpread2_Sheet1.Columns.Get(1).Border = ComplexBorder5
        TextCellType8.Static = True
        Me.FpSpread2_Sheet1.Columns.Get(1).CellType = TextCellType8
        Me.FpSpread2_Sheet1.Columns.Get(1).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Left
        Me.FpSpread2_Sheet1.Columns.Get(1).Label = "���@�@��"
        Me.FpSpread2_Sheet1.Columns.Get(1).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread2_Sheet1.Columns.Get(1).Width = 137.0!
        Me.FpSpread2_Sheet1.Columns.Get(2).Border = ComplexBorder4
        TextCellType9.Static = True
        Me.FpSpread2_Sheet1.Columns.Get(2).CellType = TextCellType9
        Me.FpSpread2_Sheet1.Columns.Get(2).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Right
        Me.FpSpread2_Sheet1.Columns.Get(2).Label = "����"
        Me.FpSpread2_Sheet1.Columns.Get(2).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread2_Sheet1.Columns.Get(2).Width = 52.0!
        Me.FpSpread2_Sheet1.Columns.Get(3).Border = ComplexBorder4
        Me.FpSpread2_Sheet1.Columns.Get(3).CellType = TextCellType7
        Me.FpSpread2_Sheet1.Columns.Get(3).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.FpSpread2_Sheet1.Columns.Get(3).Label = "�P��"
        Me.FpSpread2_Sheet1.Columns.Get(3).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread2_Sheet1.Columns.Get(3).Width = 36.0!
        Me.FpSpread2_Sheet1.Columns.Get(4).Border = ComplexBorder4
        Me.FpSpread2_Sheet1.Columns.Get(4).CellType = TextCellType9
        Me.FpSpread2_Sheet1.Columns.Get(4).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Right
        Me.FpSpread2_Sheet1.Columns.Get(4).Label = "�P ��"
        Me.FpSpread2_Sheet1.Columns.Get(4).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread2_Sheet1.Columns.Get(4).Width = 84.0!
        Me.FpSpread2_Sheet1.Columns.Get(5).Border = ComplexBorder5
        TextCellType10.Static = True
        Me.FpSpread2_Sheet1.Columns.Get(5).CellType = TextCellType10
        Me.FpSpread2_Sheet1.Columns.Get(5).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Right
        Me.FpSpread2_Sheet1.Columns.Get(5).Label = "�� �z"
        Me.FpSpread2_Sheet1.Columns.Get(5).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread2_Sheet1.Columns.Get(5).Width = 84.0!
        Me.FpSpread2_Sheet1.Columns.Get(6).Border = ComplexBorder4
        Me.FpSpread2_Sheet1.Columns.Get(6).CellType = TextCellType9
        Me.FpSpread2_Sheet1.Columns.Get(6).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Right
        Me.FpSpread2_Sheet1.Columns.Get(6).Label = "�� �z"
        Me.FpSpread2_Sheet1.Columns.Get(6).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread2_Sheet1.Columns.Get(6).Width = 84.0!
        Me.FpSpread2_Sheet1.Columns.Get(7).Border = ComplexBorder4
        Me.FpSpread2_Sheet1.Columns.Get(7).CellType = TextCellType9
        Me.FpSpread2_Sheet1.Columns.Get(7).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Right
        Me.FpSpread2_Sheet1.Columns.Get(7).Label = "�ݐϋ��z"
        Me.FpSpread2_Sheet1.Columns.Get(7).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread2_Sheet1.Columns.Get(7).Width = 88.0!
        Me.FpSpread2_Sheet1.Columns.Get(8).Border = ComplexBorder4
        Me.FpSpread2_Sheet1.Columns.Get(8).CellType = TextCellType9
        Me.FpSpread2_Sheet1.Columns.Get(8).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Right
        Me.FpSpread2_Sheet1.Columns.Get(8).Label = "���㏊�v����"
        Me.FpSpread2_Sheet1.Columns.Get(8).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread2_Sheet1.Columns.Get(8).Width = 88.0!
        Me.FpSpread2_Sheet1.Columns.Get(9).Border = ComplexBorder4
        Me.FpSpread2_Sheet1.Columns.Get(9).CellType = TextCellType9
        Me.FpSpread2_Sheet1.Columns.Get(9).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Right
        Me.FpSpread2_Sheet1.Columns.Get(9).Label = "���{�������z"
        Me.FpSpread2_Sheet1.Columns.Get(9).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread2_Sheet1.Columns.Get(9).Width = 88.0!
        Me.FpSpread2_Sheet1.Columns.Get(10).Border = ComplexBorder4
        Me.FpSpread2_Sheet1.Columns.Get(10).CellType = TextCellType9
        Me.FpSpread2_Sheet1.Columns.Get(10).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Right
        Me.FpSpread2_Sheet1.Columns.Get(10).Label = "�\�Z�Δ�"
        Me.FpSpread2_Sheet1.Columns.Get(10).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread2_Sheet1.Columns.Get(10).Width = 84.0!
        Me.FpSpread2_Sheet1.Columns.Get(11).Border = ComplexBorder5
        TextCellType11.Static = True
        Me.FpSpread2_Sheet1.Columns.Get(11).CellType = TextCellType11
        Me.FpSpread2_Sheet1.Columns.Get(11).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Right
        Me.FpSpread2_Sheet1.Columns.Get(11).Label = "�ύX����"
        Me.FpSpread2_Sheet1.Columns.Get(11).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread2_Sheet1.Columns.Get(11).Width = 88.0!
        Me.FpSpread2_Sheet1.DefaultStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        TextCellType12.MaxLength = 60
        Me.FpSpread2_Sheet1.DefaultStyle.CellType = TextCellType12
        Me.FpSpread2_Sheet1.DefaultStyle.Font = New System.Drawing.Font("MS Mincho", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.FpSpread2_Sheet1.DefaultStyle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.FpSpread2_Sheet1.DefaultStyle.Locked = True
        Me.FpSpread2_Sheet1.DefaultStyle.Parent = "DataAreaDefault"
        Me.FpSpread2_Sheet1.DefaultStyle.Renderer = TextCellType12
        Me.FpSpread2_Sheet1.FilterBar.DefaultStyle.BackColor = System.Drawing.Color.Empty
        Me.FpSpread2_Sheet1.FilterBar.DefaultStyle.ForeColor = System.Drawing.Color.Empty
        Me.FpSpread2_Sheet1.FilterBar.DefaultStyle.Locked = False
        Me.FpSpread2_Sheet1.FilterBar.DefaultStyle.Parent = "FilterBarDefault"
        Me.FpSpread2_Sheet1.FilterBar.DefaultStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread2_Sheet1.FilterBarHeaderStyle.BackColor = System.Drawing.Color.Empty
        Me.FpSpread2_Sheet1.FilterBarHeaderStyle.ForeColor = System.Drawing.Color.Empty
        Me.FpSpread2_Sheet1.FilterBarHeaderStyle.Locked = False
        Me.FpSpread2_Sheet1.FilterBarHeaderStyle.Parent = "RowHeaderDefault"
        Me.FpSpread2_Sheet1.FilterBarHeaderStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread2_Sheet1.FrozenColumnCount = 6
        Me.FpSpread2_Sheet1.OperationMode = FarPoint.Win.Spread.OperationMode.[ReadOnly]
        Me.FpSpread2_Sheet1.Protect = True
        Me.FpSpread2_Sheet1.RowHeader.Cells.Get(0, 0).Value = "���v"
        Me.FpSpread2_Sheet1.RowHeader.Columns.Default.Resizable = False
        Me.FpSpread2_Sheet1.RowHeader.Columns.Default.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread2_Sheet1.RowHeader.Columns.Get(0).Width = 34.0!
        Me.FpSpread2_Sheet1.RowHeader.DefaultStyle.BackColor = System.Drawing.Color.Empty
        Me.FpSpread2_Sheet1.RowHeader.DefaultStyle.Border = ComplexBorder6
        Me.FpSpread2_Sheet1.RowHeader.DefaultStyle.Font = New System.Drawing.Font("MS Mincho", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.FpSpread2_Sheet1.RowHeader.DefaultStyle.ForeColor = System.Drawing.Color.Empty
        Me.FpSpread2_Sheet1.RowHeader.DefaultStyle.Locked = False
        Me.FpSpread2_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderDefault"
        Me.FpSpread2_Sheet1.RowHeader.DefaultStyle.Renderer = CustomSpdHeader12
        Me.FpSpread2_Sheet1.RowHeader.DefaultStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread2_Sheet1.RowHeader.Rows.Default.Resizable = false
        Me.FpSpread2_Sheet1.RowHeader.Rows.Default.Visible = true
        Me.FpSpread2_Sheet1.RowHeader.Rows.Default.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread2_Sheet1.RowHeader.Rows.Get(0).Label = "���v"
        Me.FpSpread2_Sheet1.Rows.Default.Height = 17!
        Me.FpSpread2_Sheet1.Rows.Default.Resizable = false
        Me.FpSpread2_Sheet1.Rows.Default.Visible = true
        Me.FpSpread2_Sheet1.SheetCornerStyle.BackColor = System.Drawing.Color.Empty
        Me.FpSpread2_Sheet1.SheetCornerStyle.ForeColor = System.Drawing.Color.Empty
        Me.FpSpread2_Sheet1.SheetCornerStyle.Locked = false
        Me.FpSpread2_Sheet1.SheetCornerStyle.Parent = "RowHeaderDefault"
        Me.FpSpread2_Sheet1.SheetCornerStyle.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread2_Sheet1.SheetCornerStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread2_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1
        '
        'frmSYKD090
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(1016, 742)
        Me.Controls.Add(Me.Frame1)
        Me.Controls.Add(Me.Picture2)
        Me.Controls.Add(Me.Picture1)
        Me.Controls.Add(Me.StatusBar1)
        Me.Controls.Add(Me._imText2_2)
        Me.Controls.Add(Me._imText2_0)
        Me.Controls.Add(Me._imText2_1)
        Me.Controls.Add(Me.lblTitle)
        Me.Controls.Add(Me.FpSpread1)
        Me.Controls.Add(Me.FpSpread2)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"),System.Drawing.Icon)
        Me.KeyPreview = true
        Me.Location = New System.Drawing.Point(4, 23)
        Me.MaximizeBox = false
        Me.MinimizeBox = false
        Me.Name = "frmSYKD090"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "�H���Ǘ��V�X�e��"
        Me.Frame1.ResumeLayout(false)
        CType(Me._imText1_0,System.ComponentModel.ISupportInitialize).EndInit
        CType(Me._imText1_1,System.ComponentModel.ISupportInitialize).EndInit
        CType(Me._imText1_2,System.ComponentModel.ISupportInitialize).EndInit
        Me.Picture2.ResumeLayout(false)
        Me.Picture1.ResumeLayout(false)
        Me.StatusBar1.ResumeLayout(false)
        Me.StatusBar1.PerformLayout
        CType(Me._imText2_2,System.ComponentModel.ISupportInitialize).EndInit
        CType(Me._imText2_0,System.ComponentModel.ISupportInitialize).EndInit
        CType(Me._imText2_1,System.ComponentModel.ISupportInitialize).EndInit
        CType(Me.FpSpread1,System.ComponentModel.ISupportInitialize).EndInit
        CType(Me.FpSpread1_Sheet1,System.ComponentModel.ISupportInitialize).EndInit
        CType(Me.FpSpread2,System.ComponentModel.ISupportInitialize).EndInit
        CType(Me.FpSpread2_Sheet1,System.ComponentModel.ISupportInitialize).EndInit
        Me.ResumeLayout(false)
        Me.PerformLayout

End Sub

    Friend WithEvents FpSpread1 As FarPoint.Win.Spread.FpSpread
    Friend WithEvents FpSpread1_Sheet1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents FpSpread2 As FarPoint.Win.Spread.FpSpread
    Friend WithEvents FpSpread2_Sheet1 As FarPoint.Win.Spread.SheetView
#End Region
End Class