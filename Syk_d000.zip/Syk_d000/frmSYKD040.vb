Option Strict Off
Option Explicit On
Friend Class frmSYKD040
	Inherits System.Windows.Forms.Form
	'=============================================================
	' ���[�U�[���@  �F  �R�z�H�Ɗ������
	' �V�X�e�����@  �F  �H���Ǘ��V�X�e��
	' ���W���[����  �F  ���o������
	' ���W���[��ID�@�F  frmSYKD040.frm
	' �쐬���@ �@�@ �F  ���� 13 �N 06 �� 19 ��
	' �X�V���@�@  �@�F  ����    �N    ��    ��
	'=============================================================
	'

	'2021.08.02 UPGRADE S  AIT)Hoangtx
	'Public SetCode As String ' �ǉ����o�ԍ�
	'Public SetKubun As String ' �I�����o�敪
	Public Shared SetCode As String ' �ǉ����o�ԍ�
	Public Shared SetKubun As String ' �I�����o�敪
	'2021.08.02 UPGRADE E
	'

	'-------------------------------------------------------------------------------
	'   ����    :   �f�[�^�̃N���A
	'   �֐�    :   Sub DispClear()
	'   ����    :   �Ȃ�
	'   �@�\    :   �f�[�^���N���A���܂��B
	'-------------------------------------------------------------------------------
	Private Sub DispClear()
		
		imText1(0).Text = SetCode '���o�ԍ�
		imText1(1).Text = "" '����
		Option1(1).Checked = True '���c�敪
		Option2(1).Checked = True '��p�敪
		imText1(2).Text = "" '�Ǝк���
		imText2(2).Text = ""
		imNumber1.Value = "0" '�_����z
		
	End Sub
	
	'-------------------------------------------------------------------------------
	'   ����    :   �f�[�^�̎擾
	'   �֐�    :   Sub DispDataGet()
	'   ����    :   DT   WARIDASI_MAST_DBT
	'   �@�\    :   �f�[�^���擾���܂��B
	'-------------------------------------------------------------------------------
	Private Sub DispDataGet(ByRef DT As WARIDASI_MAST_DBT)
		
		Call CLEAR_WARIDASI_MAST(DT)
		
		With KeyKouji
			DT.KOUJI_NO = .KOUJI_NO '�H���ԍ�
			DT.EDA_NO = .EDA_NO '�H���}��
		End With
		With DT
			.WARIDASI_NO = Trim(imText1(0).Text) '���o�ԍ�
			.MEISYOU = Trim(imText1(1).Text) '����
			If Option1(1).Checked = True Then .CHOKUEI_KB = "1" '���c�敪
			If Option1(2).Checked = True Then .CHOKUEI_KB = "2"
			If Option2(1).Checked = True Then .HIYOU_KB = "1" '��p�敪
			If Option2(2).Checked = True Then .HIYOU_KB = "2"
			If Option2(3).Checked = True Then .HIYOU_KB = "3"
			If .CHOKUEI_KB = "2" Then .HIYOU_KB = "0"
			.GYOUSYA_CD = Trim(imText1(2).Text) '�Ǝк���
			.KEIYAKU_GAKU = CCur2((imNumber1.Value)) '�_����z
			.ZEIRITU = SEIGYO.ZEIRITU '����ŗ�
			.SEISAN_FLG = "0" '���Z�t���O
			.HENKOU_FLG = "1" '�ύX�t���O
		End With
		
	End Sub
	
	'-------------------------------------------------------------------------------
	'   ����    :   ���̓f�[�^�̃`�F�b�N
	'   �֐�    :   Function DispDataCheck()
	'   ����    :   �Ȃ�
	'   �ߒl    :   True  ���͐���
	'   �@�@    :   False ���̓G���[
	'   �@�\    :   ���̓f�[�^���`�F�b�N���܂��B
	'-------------------------------------------------------------------------------
	Private Function DispDataCheck() As Boolean
		
		Dim Jouken As String
		
		DispDataCheck = False
		
		'----- ����
		If Trim(imText1(1).Text) = "" Then
			'2021.09.14 UPGRADE S  AIT)dannnl
			'MsgBox("���̂����͂���Ă��܂���B", MsgBoxStyle.Information)
			MsgBox("���̂����͂���Ă��܂���B", MsgBoxStyle.Information, SYSTEMNM)
			'2021.09.14 UPGRADE E
			imText1(1).Focus()
			Exit Function
		End If
		If TextCharCheck(Trim(imText1(1).Text)) > 0 Then
			'2021.09.14 UPGRADE S  AIT)dannnl
			'MsgBox("���̂ɂ́u ' �v�u " & Chr(34) & " �v���g�p�ł��܂���B", MsgBoxStyle.Information)
			MsgBox("���̂ɂ́u ' �v�u " & Chr(34) & " �v���g�p�ł��܂���B", MsgBoxStyle.Information, SYSTEMNM)
			'2021.09.14 UPGRADE E
			imText1(1).Focus()
			Exit Function
		End If
		
		'----- �Ǝк��ށF�O���̏ꍇ
		If Option1(2).Checked = True Then
			If Trim(imText1(2).Text) = "" Then
				'2021.09.14 UPGRADE S  AIT)dannnl
				'MsgBox("�Ǝк��ނ����͂���Ă��܂���B", MsgBoxStyle.Information)
				MsgBox("�Ǝк��ނ����͂���Ă��܂���B", MsgBoxStyle.Information, SYSTEMNM)
				'2021.09.14 UPGRADE E
				imText1(2).Focus()
				Exit Function
			End If
			Jouken = "GYOUSYA_CD = '" & Trim(imText1(2).Text) & "'"
			If CNTGET_GYOUSYA_MAST(Jouken) <= 0 Then
				'2021.09.14 UPGRADE S  AIT)dannnl
				'MsgBox("���͂��ꂽ�Ǝк��ނ͓o�^����Ă��܂���B", MsgBoxStyle.Information)
				MsgBox("���͂��ꂽ�Ǝк��ނ͓o�^����Ă��܂���B", MsgBoxStyle.Information, SYSTEMNM)
				'2021.09.14 UPGRADE E
				imText1(2).Focus()
				Exit Function
			End If
		End If
		
		DispDataCheck = True
		
	End Function
	
	'-------------------------------------------------------------------------------
	'   ����    :   �f�[�^�̎��X�V
	'   �֐�    :   Function DataUpdate()
	'   ����    :   �Ȃ�
	'   �ߒl    :   True    ����I��
	'   �@�@        False   �ُ�I��
	'   �@�\    :   �f�[�^�̍X�V���s���܂��B
	'-------------------------------------------------------------------------------
	Private Function DataUpdate() As Boolean
		
		Dim Jouken As String
		Dim Order As String
		Dim Cnt As Integer
		Dim DT As WARIDASI_MAST_DBT
		Dim GA As GAI_KIHON_DATA_DBT
		Dim GY() As GYOUSYA_MAST_DBT
		Dim Msgbuf As String
		
		' �߂�l�̏�����
		DataUpdate = False
		
		' ���̓`�F�b�N
		If DispDataCheck() = False Then
			Exit Function
		End If
		
		'�o�^�m�F
		Msgbuf = "�o�^���Ă���낵���ł����H"
		Msgbuf = Msgbuf & vbCr & vbCr & "���c�敪�F"
		If Option1(1).Checked = True Then
			Msgbuf = Msgbuf & "�y���c�z"
		Else
			Msgbuf = Msgbuf & "�y�O���z"
		End If
		Msgbuf = Msgbuf & vbCr & vbCr & "��p�敪�F"
		If Option2(1).Checked = True Then
			Msgbuf = Msgbuf & "�y�ޗ���z"
		ElseIf Option2(2).Checked = True Then
			Msgbuf = Msgbuf & "�y�J����z"
		Else
			Msgbuf = Msgbuf & "�y�O����z"
		End If
		'2021.09.14 UPGRADE S  AIT)dannnl
		'If MsgBox(Msgbuf, MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2 + MsgBoxStyle.Information) = MsgBoxResult.No Then
		If MsgBox(Msgbuf, MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2 + MsgBoxStyle.Information, SYSTEMNM) = MsgBoxResult.No Then
		'2021.09.14 UPGRADE E
			Exit Function
		End If
		
		' ���͓��e�̎擾
		Call DispDataGet(DT)
		
		'----- �O���̏ꍇ�̂�
		If DT.CHOKUEI_KB = "2" Then
			'----- �ƎЏ��̎擾
			Jouken = "GYOUSYA_CD = '" & Trim(DT.GYOUSYA_CD) & "'"
			Order = ""
			Cnt = SELECT_GYOUSYA_MAST(Jouken, Order, GY)
			If Cnt <= 0 Then
				Exit Function
			End If
			'----- �O����{�̍쐬
			Call CLEAR_GAI_KIHON_DATA(GA)
			With GA
				.KOUJI_NO = DT.KOUJI_NO '�H���ԍ�
				.EDA_NO = DT.EDA_NO '�H���}��
				.CHUUMON_NO = DT.WARIDASI_NO '���o�ԍ�
				.SIME_YM = CtlKouji.SYORI_YM '���N��
				.GYOUSYA_CD = DT.GYOUSYA_CD '�Ǝк���
				If Cnt > 0 Then
					.HIRITU_FURI = GY(0).HIRITU_FURI '�x���䗦�i�U���j
					.HIRITU_GEN = GY(0).HIRITU_GEN '�x���䗦�i�����j
					.HIRITU_TE = GY(0).HIRITU_TE '�x���䗦�i��`�j
				End If
				.KEIYAKU_GAKU = DT.KEIYAKU_GAKU '�_����z
				.RITU = 90 '��
				.DENPYOU_NO = "000000" '�`�[�ԍ�
				.HENKOU_FLG = "1" '�ύX�t���O
				.NYUURYOKU_FLG = GyosyuID '���̓t���O
				.SEISAN_FLG = "0" '���Z�t���O
				.J_FLG_TENSOU = "0" '���FLG �f�[�^�]��
				.J_FLG_SIWAKE = "0" '���FLG �d��f�[�^
				.S_FLG_SIHARAI = "1" '����FLG �x���f�[�^
				.J_FLG_SIHARAI = "0" '���FLG �x���f�[�^
				.P_FLG_CHECK = "0" '���FLG ����ؽ�
				.ZEIRITU = GetTax(.SIME_YM) '����ŗ� 2013/12/06 �ǉ�
			End With
		End If
		
		Do
			' ���o�}�X�^
			If INSERT_WARIDASI_MAST(DT) = False Then
				Exit Do
			End If
			' �O����{�F�O���̏ꍇ
			If DT.CHOKUEI_KB = "2" Then
				If INSERT_GAI_KIHON_DATA(GA) = False Then
					Exit Do
				End If
			End If
			' �ݒ�敪
			SetKubun = DT.CHOKUEI_KB
			' ����I��
			DataUpdate = True
			Exit Do
		Loop
		
	End Function
	
	'-------------------------------------------------------------------------------
	'   ����    :   �ύX�`�F�b�N
	'   �֐�    :   Function ChangeCheck()
	'   ����    :   �Ȃ�
	'   �ߒl    :   True    �ύX����
	'   �@�@        False   �ύX�Ȃ�
	'   �@�\    :   �f�[�^���ύX���ꂽ���ǂ����`�F�b�N���s���܂��B
	'-------------------------------------------------------------------------------
	Private Function ChangeCheck() As Boolean
		
		Dim DT As WARIDASI_MAST_DBT
		
		' �߂�l�̏�����
		ChangeCheck = True
		
		' ���͓��e�̎擾
		Call DispDataGet(DT)
		
		With DT
			If Trim(.MEISYOU) <> "" Then Exit Function '����
			If Trim(.CHOKUEI_KB) <> "1" Then Exit Function '���c�敪
			If Trim(.HIYOU_KB) <> "1" Then Exit Function '��p�敪
			If Trim(.GYOUSYA_CD) <> "" Then Exit Function '�Ǝк���
			If .KEIYAKU_GAKU <> 0 Then Exit Function '�_����z
		End With
		
		' �ύX�Ȃ�
		ChangeCheck = False
		
	End Function
	'2021.08.02 UPGRADE S  AIT)Hoangtx
	'Private Sub cmdKey_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Click
	Private Sub cmdKey_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _cmdKey_12.Click, _cmdKey_1.Click
		'Dim Index As Short = cmdKey.GetIndex(eventSender)
		Dim Index As Short = cmdKey.IndexOf(eventSender)
		'2021.08.02 UPGRADE E

		Dim wkBango As Double

		Select Case Index
			Case 1 '----- �o�^
				' �f�[�^���X�V
				If DataUpdate() = False Then
					Exit Sub
				End If

			Case 12 '----- �I��
				' �ύX�`�F�b�N
				If ChangeCheck() = True Then
					'2021.09.14 UPGRADE S  AIT)dannnl
					'If MsgBox("�f�[�^���ύX����Ă��܂��B�{���ɏI�����܂����H", MsgBoxStyle.YesNo + MsgBoxStyle.Information) = MsgBoxResult.No Then
					If MsgBox("�f�[�^���ύX����Ă��܂��B�{���ɏI�����܂����H", MsgBoxStyle.YesNo + MsgBoxStyle.Information, SYSTEMNM) = MsgBoxResult.No Then
					'2021.09.14 UPGRADE E
						Exit Sub
					End If
				End If
		End Select

		'2021.08.02 UPGRADE S  AIT)Hoangtx
		'Me.Close()
		Me.Dispose()
		'2021.08.02 UPGRADE E
	End Sub
	'2021.08.02 UPGRADE S  AIT)Hoangtx
	'Private Sub cmdKey_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Enter
	Private Sub cmdKey_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _cmdKey_12.Enter, _cmdKey_1.Enter
		'Dim Index As Short = cmdKey.GetIndex(eventSender)
		Dim Index As Short = cmdKey.IndexOf(eventSender)
		'Call GotFocus(cmdKey(Index), StatusBar1)
		Call MtyTool.GotFocus(cmdKey(Index), StatusBar1)
		'2021.08.02 UPGRADE E
	End Sub
	'2021.08.02 UPGRADE S  AIT)Hoangtx
	'Private Sub cmdKey_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Leave
	Private Sub cmdKey_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _cmdKey_12.Leave, _cmdKey_1.Leave
		'Dim Index As Short = cmdKey.GetIndex(eventSender)
		Dim Index As Short = cmdKey.IndexOf(eventSender)
		'Call LostFocus(cmdKey(Index), StatusBar1)
		Call MtyTool.LostFocus(cmdKey(Index), StatusBar1)
	End Sub
	'2021.08.02 UPGRADE E

	'2021.08.02 UPGRADE S  AIT)Hoangtx
	'Private Sub cmdLook_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdLook.Click
	Private Sub cmdLook_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _cmdLook_2.Click
		'Dim Index As Short = cmdLook.GetIndex(eventSender)
		Dim Index As Short = cmdLook.IndexOf(eventSender)
		'2021.08.02 UPGRADE E

		Select Case Index
			Case 2 ' �ƎЃ}�X�^����
				frmSearch.MastNo = 3
				frmSearch.ShowDialog()
				If frmSearch.GetCD <> "" Then
					imText1(Index).Text = Trim(frmSearch.GetCD)
					imText2(Index).Text = Trim(frmSearch.GetNM)
					imNumber1.Focus()
					Exit Sub
				End If
				imText1(Index).Focus()
		End Select

	End Sub


	Private Sub frmSYKD040_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown
		Dim KeyCode As Short = eventArgs.KeyCode
		Dim Shift As Short = eventArgs.KeyData \ &H10000
		Select Case KeyCode
			Case System.Windows.Forms.Keys.Return
				'2021.08.17 UPGRADE S  AIT)dannnl
				'Call NextCntlGet(Me, Me.ActiveControl.TabIndex)
				Call NextCntlGet()
				'2021.08.17 UPGRADE E
			Case System.Windows.Forms.Keys.F1
				If cmdKey(1).Enabled = True Then cmdKey(1).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(1), New System.EventArgs())
			Case System.Windows.Forms.Keys.F12
				If cmdKey(12).Enabled = True Then cmdKey(12).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(12), New System.EventArgs())
		End Select
	End Sub

	Private Sub frmSYKD040_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
		' �����\��
		Call FormDisp(Me)
		Call DispClear()
		' ������
		SetKubun = ""
	End Sub

	Private Sub frmSYKD040_FormClosing(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
		Dim Cancel As Boolean = eventArgs.Cancel
		Dim UnloadMode As System.Windows.Forms.CloseReason = eventArgs.CloseReason
		If UnloadMode = System.Windows.Forms.CloseReason.UserClosing Then
			' �ύX�`�F�b�N
			If ChangeCheck() = True Then
				'2021.09.14 UPGRADE S  AIT)dannnl
				'If MsgBox("�f�[�^���ύX����Ă��܂��B�{���ɏI�����܂����H", MsgBoxStyle.YesNo + MsgBoxStyle.Information) = MsgBoxResult.No Then
				If MsgBox("�f�[�^���ύX����Ă��܂��B�{���ɏI�����܂����H", MsgBoxStyle.YesNo + MsgBoxStyle.Information, SYSTEMNM) = MsgBoxResult.No Then
				'2021.09.14 UPGRADE E
					Cancel = True
					Exit Sub
				End If
			End If
		End If
		eventArgs.Cancel = Cancel
	End Sub
	'2021.08.02 UPGRADE S  AIT)Hoangtx
	Private Sub imNumber1_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles imNumber1.Enter
		'Call GotFocus(imNumber1, StatusBar1)
		Call MtyTool.GotFocus(imNumber1, StatusBar1)
		'2021.08.02 UPGRADE E
	End Sub
	'2021.08.02 UPGRADE S  AIT)Hoangtx
	Private Sub imNumber1_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles imNumber1.Leave
		'Call LostFocus(imNumber1, StatusBar1)
		Call MtyTool.LostFocus(imNumber1, StatusBar1)
		'2021.08.02 UPGRADE E
	End Sub

	'2021.08.02 UPGRADE S  AIT)Hoangtx
	'Private Sub imText1_Change(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles imText1.Change
	Private Sub imText1_Change(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _imText1_2.TextChanged, _imText1_1.TextChanged, _imText1_0.TextChanged
		'Dim Index As Short = imText1.GetIndex(eventSender)
		Dim Index As Short = imText1.IndexOf(eventSender)
		'2021.08.02 UPGRADE E
		If Index = 2 Then
			imText2(Index).Text = ""
		End If
	End Sub
	'2021.08.02 UPGRADE S  AIT)Hoangtx
	'Private Sub imText1_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles imText1.Enter
	Private Sub imText1_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _imText1_2.Enter, _imText1_1.Enter, _imText1_0.Enter
		'Dim Index As Short = imText1.GetIndex(eventSender)
		Dim Index As Short = imText1.IndexOf(eventSender)
		'Call GotFocus(imText1(Index), StatusBar1, 1)
		Call MtyTool.GotFocus(imText1(Index), StatusBar1, 1)
		'2021.08.02 UPGRADE E
	End Sub
	'2021.08.02 UPGRADE S  AIT)Hoangtx
	'Private Sub imText1_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles imText1.KeyDown
	Private Sub imText1_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles _imText1_2.KeyDown, _imText1_1.KeyDown, _imText1_0.KeyDown
		Dim KeyCode As Short = eventArgs.KeyCode
		Dim Shift As Short = eventArgs.KeyData \ &H10000
		'Dim Index As Short = imText1.GetIndex(eventSender)
		Dim Index As Short = imText1.IndexOf(eventSender)
		'2021.08.02 UPGRADE E
		'2021.09.15 ADD S  AIT)Hoangtx
		Dim text As String = imText1(Index).text
		'2021.09.15 ADD E
		Select Case KeyCode
			Case System.Windows.Forms.Keys.Space
				Call cmdLook_Click(cmdLook.Item(Index), New System.EventArgs())
				'2021.09.15 ADD S  AIT)Hoangtx
				If Trim(imText1(Index).text) = text.ToString Or imText1(Index).text.Contains(" ") Then
					imText1(Index).text = text
					imText1_Leave(imText1(Index), eventArgs)
					imText1(Index).selectall()
				End If
				'2021.09.15 ADD E
		End Select
	End Sub
	'2021.08.02 UPGRADE S  AIT)Hoangtx
	'Private Sub imText1_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles imText1.KeyDown

	Private Sub imText1_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _imText1_2.Leave, _imText1_1.Leave, _imText1_0.Leave
		'Dim Index As Short = imText1.GetIndex(eventSender)
		Dim Index As Short = imText1.IndexOf(eventSender)
		'Call LostFocus(imText1(Index), StatusBar1, 1)
		Call MtyTool.LostFocus(imText1(Index), StatusBar1, 1)
		'If imText1(Index).Format = "9" Then
		'imText1(Index).Text = VB6.Format(imText1(Index).Text, New String("0", imText1(Index).MaxLength))
		If imText1(Index) IsNot Nothing AndAlso imText1(Index).Format = "9" Then
			If imText1(Index).Text <> "" Then
				imText1(Index).Text = Strings.Right(New String("0", imText1(Index).MaxLength) & Trim(imText1(Index).Text), imText1(Index).MaxLength)
			End If
			'2021.08.02 UPGRADE E
		End If
		Select Case Index
			Case 2 '----- �Ǝк���
				imText2(Index).Text = GetNameGyousya(imText1(Index).Text)
		End Select
	End Sub
	'2021.08.02 UPGRADE S  AIT)Hoangtx
	'Private Sub Option1_CheckedChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles Option1.CheckedChanged
	Private Sub Option1_CheckedChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _Option1_2.CheckedChanged, _Option1_1.CheckedChanged
		If eventSender.Checked Then
			'Dim Index As Short = Option1.GetIndex(eventSender)
			Dim Index As Short = Option1.IndexOf(eventSender)
			'2021.08.02 UPGRADE E
			Select Case Index
				Case 1 '----- ���c
					'2021.08.02 UPGRADE S  AIT)Hoangtx
					'Frame1(1).Enabled = True
					_Picture2_1.Enabled = True
					'Frame1(2).Enabled = False
					_imText1_2.Enabled = False
					_imText2_2.Enabled = False
					imNumber1.Enabled = False
					_Frame1_2.ForeColor = Color.Gray
					_Frame1_1.ForeColor = Color.FromArgb(0, 0, 192)
					'2021.08.02 UPGRADE E
					imText1(2).Text = ""
					imText1(2).BackColor = System.Drawing.SystemColors.Control
					cmdLook(2).Enabled = False
					imNumber1.Text = "0"
					imNumber1.BackColor = System.Drawing.SystemColors.Control
				Case 2 '----- �O��
					'2021.08.02 UPGRADE S  AIT)Hoangtx
					'Frame1(1).Enabled = False
					_Picture2_1.Enabled = False
					_Frame1_1.ForeColor = Color.Gray
					_Frame1_2.ForeColor = Color.FromArgb(0, 0, 192)
					'Frame1(2).Enabled = True
					_imText1_2.Enabled = True
					imNumber1.Enabled = True
					'2021.08.02 UPGRADE E
					imText1(2).BackColor = System.Drawing.Color.White
					cmdLook(2).Enabled = True
					imNumber1.BackColor = System.Drawing.Color.White
			End Select
		End If
	End Sub
	'2021.08.02 UPGRADE S  AIT)Hoangtx
	'Private Sub Option1_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles Option1.Enter

	Private Sub Option1_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _Option1_2.Enter, _Option1_1.Enter
		'Dim Index As Short = Option1.GetIndex(eventSender)
		Dim Index As Short = Option1.IndexOf(eventSender)
		'Call GotFocus(Option1(Index), StatusBar1)
		Call MtyTool.GotFocus(Option1(Index), StatusBar1)
		'2021.08.02 UPGRADE E
	End Sub
	'2021.08.02 UPGRADE S  AIT)Hoangtx
	'Private Sub Option1_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles Option1.Leave
	Private Sub Option1_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _Option1_2.Leave, _Option1_1.Leave
		'Dim Index As Short = Option1.GetIndex(eventSender)
		Dim Index As Short = Option1.IndexOf(eventSender)
		'Call LostFocus(Option1(Index), StatusBar1)
		Call MtyTool.LostFocus(Option1(Index), StatusBar1)
		'2021.08.02 UPGRADE E
	End Sub
	'2021.08.02 UPGRADE S  AIT)Hoangtx
	'Private Sub Option2_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles Option2.Enter
	Private Sub Option2_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _Option2_2.Enter, _Option2_1.Enter, _Option2_3.Enter
		'Dim Index As Short = Option2.GetIndex(eventSender)
		Dim Index As Short = Option2.IndexOf(eventSender)
		'Call GotFocus(Option2(Index), StatusBar1)
		Call MtyTool.GotFocus(Option2(Index), StatusBar1)
		'2021.08.02 UPGRADE E
	End Sub
	'2021.08.02 UPGRADE S  AIT)Hoangtx
	'Private Sub Option2_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles Option2.Leave
	Private Sub Option2_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _Option2_2.Leave, _Option2_1.Leave, _Option2_3.Leave
		'Dim Index As Short = Option2.GetIndex(eventSender)
		Dim Index As Short = Option2.IndexOf(eventSender)
		'Call LostFocus(Option2(Index), StatusBar1)
		Call MtyTool.LostFocus(Option2(Index), StatusBar1)
		'2021.08.02 UPGRADE E
	End Sub
	'2021.08.02 ADD S  AIT)Hoangtx
	Private Sub option2_EnabledChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _Option2_1.EnabledChanged, _Option2_3.EnabledChanged, _Option2_2.EnabledChanged
		Dim Index As Short = Option2.IndexOf(eventSender)
		If Option2(Index).enabled = False Then
			Option2(Index).BackColor = Color.WhiteSmoke
		End If
	End Sub
	'2021.08.02 ADD E
End Class
