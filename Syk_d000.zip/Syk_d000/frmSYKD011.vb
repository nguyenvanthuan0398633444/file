Option Strict Off
Option Explicit On
Imports VB = Microsoft.VisualBasic
Friend Class frmSYKD011
    Inherits System.Windows.Forms.Form
    '=============================================================
    ' ���[�U�[���@  �F  �R�z�H�Ɗ������
    ' �V�X�e�����@  �F  �H���Ǘ��V�X�e��
    ' ���W���[����  �F  �H���I��
    ' ���W���[��ID�@�F  frmSYKD011.frm
    ' �쐬���@ �@�@ �F  ���� 13 �N 05 �� 29 ��
    ' �X�V���@�@  �@�F  ����    �N    ��    ��
    '=============================================================
    '
    '2021.08.10 UPGRADE S  AIT)hieunv
    'Private Const RowHeight As Double = 15.0#
    Private Const RowHeight As Double = 20.0#
    '2021.08.10 UPGRADE E

    '2021.08.25 ADD S  AIT)hieunv
    Private Shared rowSelect As Integer = 0
    '2021.08.25 ADD E

    '�\���p�\����
    Private Structure DSP_KOUJI_QRY
        '----- KOUJI_NO_MAST -----
        '2021.07.26 UPGRADE S  AIT)Tool Convert
        '<VBFixedString(8),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=8)> Public KOUJI_NO() As Char '�H���ԍ�
        '<VBFixedString(4),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=4)> Public EDA_NO() As Char '�H���}��
        '<VBFixedString(40),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=40)> Public MEISYOU() As Char '�H������
        '<VBFixedString(2),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=2)> Public GYOUSYU_KB() As Char '�Ǝ�敪
        '<VBFixedString(1),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=1)> Public SIIRE_KB() As Char '�d���敪
        ''----- KOUJI_CTRL_S -----
        '<VBFixedString(1),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=1)> Public K_STATUS() As Char '�H�����
        '<VBFixedString(1),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=1)> Public G_STATUS() As Char '�Ɩ���� 2013/12/11 �ǉ�
        '<VBFixedString(6),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=6)> Public CTRL_S_SYORI_YM() As Char '�����N�� 2013/12/11 �ǉ�
        ''----- KOUJI_CTRL_D -----
        '<VBFixedString(6),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=6)> Public SYORI_YM() As Char '�����N��
        ''----- GEPPOU_DATA_D -----
        '<VBFixedString(6),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=6)> Public MIN_YM() As Char '�ŏ�����N��
        '<VBFixedString(6),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=6)> Public MAX_YM() As Char '�ő匎��N��
        ''----- KOUJI_MAST -----
        '<VBFixedString(20),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=20)> Public RYAKUSYOU() As Char '����
        <VBFixedStringAttribute(8)> Public KOUJI_NO As String    '�H���ԍ�
        <VBFixedStringAttribute(4)> Public EDA_NO As String  '�H���}��
        <VBFixedStringAttribute(40)> Public MEISYOU As String    '�H������
        <VBFixedStringAttribute(2)> Public GYOUSYU_KB As String  '�Ǝ�敪
        <VBFixedStringAttribute(1)> Public SIIRE_KB As String    '�d���敪
        '----- KOUJI_CTRL_S -----
        <VBFixedStringAttribute(1)> Public K_STATUS As String    '�H�����
        <VBFixedStringAttribute(1)> Public G_STATUS As String    '�Ɩ���� 2013/12/11 �ǉ�
        <VBFixedStringAttribute(6)> Public CTRL_S_SYORI_YM As String     '�����N�� 2013/12/11 �ǉ�
        '----- KOUJI_CTRL_D -----
        <VBFixedStringAttribute(6)> Public SYORI_YM As String    '�����N��
        '----- GEPPOU_DATA_D -----
        <VBFixedStringAttribute(6)> Public MIN_YM As String  '�ŏ�����N��
        <VBFixedStringAttribute(6)> Public MAX_YM As String  '�ő匎��N��
        '----- KOUJI_MAST -----
        <VBFixedStringAttribute(20)> Public RYAKUSYOU As String  '����
        '2021.07.26 UPGRADE E
    End Structure

    'Private Dsp()   As KOUJI_NO_MAST_DBT
    Private Dsp() As DSP_KOUJI_QRY
    Private DCnt As Integer
    '2021.08.18 UPGRADE S  AIT)hieunv
    'Public SetKouji As String
    Public Shared SetKouji As String
    '2021.08.18 UPGRADE E
    '

    '-------------------------------------------------------------------------------
    '   ����    :   �f�[�^�̎擾
    '   �֐�    :   Sub MainDataDisp()
    '   ����    :   �Ȃ�
    '   �@�\    :   �f�[�^�̎擾���s���܂��B
    '-------------------------------------------------------------------------------
    Private Sub MainDataDisp()

        Dim Jouken As String
        Dim Order As String
        Dim Cnt As Integer

        '�J�[�\���������v��
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor

        '�e�[�u���̓Ǎ���
        'Cnt = SelectKoujiNoMast(Dsp())
        Jouken = "KOUJI_NO_MAST.GYOUSYU_KB = '" & GyosyuID & "'"
        If SYSTEMID = "S" Then
            Jouken = Jouken & " AND KOUJI_CTRL_S.K_STATUS <>'3'"
        End If
        Order = "KOUJI_NO_MAST.KOUJI_NO, KOUJI_NO_MAST.EDA_NO"
        Cnt = SELECT_DSP_KOUJI_QRY(Jouken, Order, Dsp)
        If Cnt <= 0 Then
            '2021.08.03 UPGRADE S  AIT)hieunv
            'vaSpread1.MaxRows = 0
            vaSpread1.ActiveSheet.RowCount = 0
            '2021.08.03 UPGRADE E
            cmdKey(1).Enabled = False '����{�^��
            cmdKey(3).Enabled = False '�폜�{�^��
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
            Exit Sub
        End If

        '�X�v���b�h�ɕ\��
        DCnt = Cnt
        Call SprdDataSet(Cnt)

        cmdKey(1).Enabled = True '����{�^��
        If SYSTEMID = "S" Then
            cmdKey(3).Enabled = False '�폜�{�^��
        Else
            cmdKey(3).Enabled = True '�폜�{�^��
        End If
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
        Util.SetColorCalendar(imDate1)�@�@�@�@�@'2021.10.05 UPGRADE ADD  AIT)dannnl
    End Sub

    '-------------------------------------------------------------------------------
    '   ����    :   �X�v���b�h�\��
    '   �֐�    :   Sub SprdDataSet(DT())
    '   ����    :   Cnt     �f�[�^����
    '   �@�\    :   �f�[�^���X�v���b�h�ɕ\�����܂��B
    '-------------------------------------------------------------------------------
    Private Sub SprdDataSet(ByRef Cnt As Integer)

        Dim lp As Integer
        Dim Row As Integer
        Dim ssText As Object
        Dim CPos As Integer

        With vaSpread1
            If Me.Visible = True Then
                '2021.08.03 UPGRADE S  AIT) hieunv
                '.ReDraw = False
                .SuspendLayout()
                '2021.08.03 UPGRADE E
            End If
            '2021.08.02 UPGRADE S  AIT) hieunv
            '.MaxRows = Cnt
            '.Col = 1 : .Col2 = .MaxCols
            '.Row = 1 : .Row2 = .MaxRows
            '.BlockMode = True
            '.SetActionMap = FPSpread.ActionConstants.ActionClearText
            '.BlockMode = False
            .ActiveSheet.RowCount = Cnt
            .ActiveSheet.ClearRange(0, 0, .ActiveSheet.RowCount, .ActiveSheet.ColumnCount, True)
            .ActiveSheet.OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
            '2021.08.02 UPGRADE E
            CPos = 0
            For lp = 0 To Cnt - 1
                '2021.08.02 UPGRADE S  AIT)hieunv
                '.set_RowHeight(lp + 1, RowHeight)
                'Row = lp + 1
                .ActiveSheet.SetRowHeight(lp, RowHeight)
                Row = lp
                '2021.08.02 UPGRADE E
                '----- �H���ԍ�
                ssText = Trim(Dsp(lp).KOUJI_NO)
                '2021.08.02 UPGRADE S  AIT)hieunv
                '.SetText(1, Row, ssText)
                .ActiveSheet.SetText(Row, 0, ssText)
                '2021.08.02 UPGRADE E
                '----- �}��
                ssText = Trim(Dsp(lp).EDA_NO)
                If ssText <> "0000" Then
                    '2021.08.02 UPGRADE S  AIT)hieunv
                    '.SetText(2, Row, ssText)
                    .ActiveSheet.SetText(Row, 1, ssText)
                    '2021.08.02 UPGRADE E
                End If
                '----- �H����
                ssText = Trim(Dsp(lp).RYAKUSYOU)
                '2021.08.02 UPGRADE S  AIT)hieunv
                '.SetText(3, Row, ssText)
                .ActiveSheet.SetText(Row, 2, ssText)
                '2021.08.02 UPGRADE E
                '----- �����N��
                If Trim(Dsp(lp).SYORI_YM) = "" Then
                    ssText = ""
                Else
                    '2021.07.26 UPGRADE S  AIT)Tool Convert
                    'ssText = VB6.Format(Dsp(lp).SYORI_YM, "0000/00")
                    ssText = CDec(Dsp(lp).SYORI_YM).ToString("0000/00")
                    '2021.07.26 UPGRADE E
                End If
                '2021.08.02 UPGRADE S  AIT) hieunv
                '.SetText(4, Row, ssText)
                .ActiveSheet.SetText(Row, 3, ssText)
                '2021.08.02 UPGRADE E
                '----- �ŏ��H������
                If Trim(Dsp(lp).MIN_YM) = "" Then
                    ssText = ""
                Else
                    '2021.07.26 UPGRADE S  AIT)Tool Convert
                    'ssText = VB6.Format(Dsp(lp).MIN_YM, "0000/00")
                    ssText = CDec(Dsp(lp).MIN_YM).ToString("0000/00")
                    '2021.07.26 UPGRADE E
                End If
                '2021.08.02 UPGRADE S  AIT)hieunv
                '.SetText(5, Row, ssText)
                .ActiveSheet.SetText(Row, 4, ssText)
                '2021.08.02 UPGRADE E
                '----- �ő�H������
                If Trim(Dsp(lp).MAX_YM) = "" Then
                    ssText = ""
                Else
                    '2021.07.26 UPGRADE S  AIT)Tool Convert
                    'ssText = VB6.Format(Dsp(lp).MAX_YM, "0000/00")
                    ssText = CDec(Dsp(lp).MAX_YM).ToString("0000/00")
                    '2021.07.26 UPGRADE E
                End If
                '2021.08.02 UPGRADE S  AIT)hieunv
                '.SetText(6, Row, ssText)
                .ActiveSheet.SetText(Row, 5, ssText)
                '2013/12/11 �ǉ� -----------------------------------------------------����������
                ' �Ɩ����
                ssText = Dsp(lp).G_STATUS
                '2021.08.02 UPGRADE S  AIT)hieunv
                '.SetText(7, Row, ssText)
                .ActiveSheet.SetText(Row, 6, ssText)
                ' �����N��(CTRL_S)
                If Trim(Dsp(lp).CTRL_S_SYORI_YM) = "" Then
                    ssText = ""
                Else
                    '2021.07.26 UPGRADE S  AIT)Tool Convert
                    'ssText = VB6.Format(Dsp(lp).CTRL_S_SYORI_YM, "0000/00")
                    ssText = CDec(Dsp(lp).CTRL_S_SYORI_YM).ToString("0000/00")
                    '2021.07.26 UPGRADE E
                End If
                '2021.08.02 UPGRADE S  AIT)hieunv
                '.SetText(8, Row, ssText)
                .ActiveSheet.SetText(Row, 7, ssText)
                '---------------------------------------------------------------------����������
                '----- �I���H���ʒu
                If KeyKouji.KOUJI_NO = Dsp(lp).KOUJI_NO And KeyKouji.EDA_NO = Dsp(lp).EDA_NO Then
                    CPos = lp
                End If
            Next lp
            '2021.08.02 UPGRADE S  AIT)hieunv
            '.Row = CPos + 1
            '.Action = SS_ACTION_ACTIVE_CELL
            '2013/12/12 �ǉ� -----------------------------------------------------����������
            'Call vaSpread1_LeaveCell(vaSpread1, New AxFPSpread._DSpreadEvents_LeaveCellEvent(.Col, .Row, .Col, .Row, False))
            '---------------------------------------------------------------------��������
            .ActiveSheet.SetActiveCell(CPos, 0)
            If rowSelect <> 0 Then
                .ActiveSheet.ClearSelection()
                .ActiveSheet.AddSelection(rowSelect, 0, 1, .ActiveSheet.ColumnCount)
                .ShowRow(0, rowSelect, FarPoint.Win.Spread.VerticalPosition.Bottom)
            Else
                .ActiveSheet.AddSelection(0, 0, 1, .ActiveSheet.ColumnCount)
            End If
            '2021.08.02 �ǉ� -----------------------------------------------------����������
            Call vaSpread1_LeaveCell(vaSpread1, New FarPoint.Win.Spread.LeaveCellEventArgs(vaSpread1.GetRootWorkbook, CPos, 0, CPos, 0))
            '---------------------------------------------------------------------����������
            '2021.08.02 UPGRADE E
            If Me.Visible = True Then
                '2021.08.02 UPGRADE S  AIT)hieunv
                '.CtlRefresh()
                '.ReDraw = True
                .Refresh()
                .ResumeLayout()
                '2021.08.02 UPGRADE E
            End If
			'2021.08.31 ADD S  AIT)hieunv
			Dim YearPicker As Integer
            Dim MonthPicker As Integer
            Dim DatePicker As Integer = CInt(Date.Today.Day)
            If Not String.IsNullOrEmpty(vaSpread1.ActiveSheet.Cells(.ActiveSheet.ActiveRowIndex, 3).Value) Then
                imDate1.Enabled = True
                YearPicker = CInt((vaSpread1.ActiveSheet.Cells(.ActiveSheet.ActiveRowIndex, 3).Value.ToString()).Substring(0, 4).Trim)
                MonthPicker = CInt((vaSpread1.ActiveSheet.Cells(.ActiveSheet.ActiveRowIndex, 3).Value.ToString()).Substring(5, 2).Trim)
            ElseIf Not String.IsNullOrEmpty(vaSpread1.ActiveSheet.Cells(.ActiveSheet.ActiveRowIndex, 7).Value) Then
                imDate1.Enabled = False
                YearPicker = CInt((vaSpread1.ActiveSheet.Cells(.ActiveSheet.ActiveRowIndex, 7).Value.ToString()).Substring(0, 4).Trim)
                MonthPicker = CInt((vaSpread1.ActiveSheet.Cells(.ActiveSheet.ActiveRowIndex, 7).Value.ToString()).Substring(5, 2).Trim)
            End If
            If YearPicker <> 0 AndAlso MonthPicker <> 0 Then
                Dim numDays As Integer = DateTime.DaysInMonth(YearPicker, MonthPicker)
                Dim currentDay = Date.Now.Day
                If currentDay > numDays Then
                    DatePicker = numDays
                End If
                If imDate1.Enabled = False Then
                    imDate1.Value = New Date(YearPicker, MonthPicker, DatePicker, 0, 0, 0, 0)
                Else
                    imDate1.Value = New Date(YearPicker, MonthPicker, DatePicker, 0, 0, 0, 0)
                End If
            Else
                imDate1.Number = 0
            End If
            '2021.08.31 ADD S  AIT)hieunv
        End With

    End Sub

    Private Sub cmdKey_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _cmdKey_1.Click, _cmdKey_12.Click,
                                                                                                              _cmdKey_3.Click, _cmdKey_8.Click
        Dim Index As Short = cmdKey.IndexOf(eventSender)

        Dim Jouken As String
        Dim Order As String
        Dim DT01() As KOUJI_CTRL_D_DBT
        Dim Cnt01 As Integer
        Dim DT02() As KOUJI_CTRL_S_DBT
        Dim Cnt02 As Integer
        Dim GenYM As String
        Dim Msg As String
        Dim MikomiFlg As Short
        Dim DT03() As IPPAN_DATA_DBT
        Dim Cnt03 As Integer
        Dim ChkMsg As String
        Dim lp As Integer
        Dim CmpBuf As String

        '2021.08.02 ADD S  AIT) hieunv
        rowSelect = vaSpread1.ActiveSheet.ActiveRowIndex

        Select Case Index
            Case 1 '----- ����
                '2021.08.02 UPGRADE S  AIT) hieunv
                'KeyKouji.KOUJI_NO = Dsp(vaSpread1.ActiveRow - 1).KOUJI_NO
                'KeyKouji.EDA_NO = Dsp(vaSpread1.ActiveRow - 1).EDA_NO
                'KeyKouji.MEISYOU = Dsp(vaSpread1.ActiveRow - 1).MEISYOU
                'KeyKouji.GYOUSYU_KB = Dsp(vaSpread1.ActiveRow - 1).GYOUSYU_KB
                'KeyKouji.SIIRE_KB = Dsp(vaSpread1.ActiveRow - 1).SIIRE_KB
                KeyKouji.KOUJI_NO = Dsp(vaSpread1.ActiveSheet.ActiveRowIndex).KOUJI_NO
                KeyKouji.EDA_NO = Dsp(vaSpread1.ActiveSheet.ActiveRowIndex).EDA_NO
                KeyKouji.MEISYOU = Dsp(vaSpread1.ActiveSheet.ActiveRowIndex).MEISYOU
                KeyKouji.GYOUSYU_KB = Dsp(vaSpread1.ActiveSheet.ActiveRowIndex).GYOUSYU_KB
                KeyKouji.SIIRE_KB = Dsp(vaSpread1.ActiveSheet.ActiveRowIndex).SIIRE_KB
                SetKouji = KeyKouji.KOUJI_NO & KeyKouji.EDA_NO
                '2021.08.02 UPGRADE E
                '----- �����N���̃`�F�b�N�P
                '2021.07.26 UPGRADE S  AIT)Tool Convert
                'SELECTYM = VB6.Format(imDate1.Text, "YYYYMM")
                'GenYM = VB6.Format(Now, "YYYYMM")
                SELECTYM = imDate1.Text.Replace("/", "")
                GenYM = Now.ToString("yyyyMM")
                '2021.07.26 UPGRADE E
                If GenYM < SELECTYM Then
                    Msg = "���͂��ꂽ�����N�����Ԉ���Ă��܂��B"
                    '2021.09.14 UPGRADE S  AIT)dannnl
                    'MsgBox(Msg, MsgBoxStyle.OkOnly + MsgBoxStyle.Information)
                    MsgBox(Msg, MsgBoxStyle.OkOnly + MsgBoxStyle.Information, SYSTEMNM)
                    '2021.09.14 UPGRADE E
                    If imDate1.Enabled = True Then imDate1.Focus() Else vaSpread1.Focus()
                    Exit Sub
                End If

                ' �H�����i����j�o���e�[�u���̓Ǎ���
                Jouken = "KOUJI_NO = '" & KeyKouji.KOUJI_NO & "' AND EDA_NO = '" & KeyKouji.EDA_NO & "'"
                Order = ""
                Cnt02 = SELECT_KOUJI_CTRL_S(Jouken, Order, DT02)
                If Cnt02 > 0 Then
                    SysKouji = DT02(0)
                End If

                ' �H�����i����j�y�؃e�[�u���̓Ǎ���
                Jouken = "KOUJI_NO = '" & KeyKouji.KOUJI_NO & "' AND EDA_NO = '" & KeyKouji.EDA_NO & "'"
                Order = ""
                Cnt01 = SELECT_KOUJI_CTRL_D(Jouken, Order, DT01)
                If Cnt01 > 0 Then
                    '----- �����N���̃`�F�b�N�Q
                    If SELECTYM < DT01(0).SYORI_YM Then
                        '----- �����I�ɎQ�ƃ��[�h�ɂ���
                        B11INPMODE = INPMODE
                        INPMODE = "1"
                        B10INPMODE = INPMODE
                    ElseIf SELECTYM = DT01(0).SYORI_YM Then
                        '----- ���ݏ������̏����N���̏ꍇ
                        ' ����ɂ��Ă̓��j���[��ʂōs�����̂Ƃ���B
                    Else
                        '----- �����ȍ~�̏ꍇ
                        If DT01(0).R_FLG_TUKISIME <> "2" And Trim(DT01(0).SYORI_YM) <> "" Then
                            Msg = "���ݏ������y" & VB.Left(DT01(0).SYORI_YM, 4) & "/" & VB.Right(DT01(0).SYORI_YM, 2) & "�z�̌�������������Ă��܂���B"
                            '2021.09.14 UPGRADE S  AIT)dannnl
                            'MsgBox(Msg, MsgBoxStyle.OkOnly + MsgBoxStyle.Information)
                            MsgBox(Msg, MsgBoxStyle.OkOnly + MsgBoxStyle.Information, SYSTEMNM)
                            '2021.09.14 UPGRADE E
                            If imDate1.Enabled = True Then imDate1.Focus() Else vaSpread1.Focus()
                            Exit Sub
                        End If

                        '----- 2005/06/15 SELECTYM ���O�̈�ʕ����i���ݒ�j�����邩���`�F�b�N����
                        ChkMsg = ""
                        Jouken = "KOUJI_NO = '" & KeyKouji.KOUJI_NO & "' AND EDA_NO = '" & KeyKouji.EDA_NO & "'"
                        Jouken = Jouken & " AND SIME_YM < '" & SELECTYM & "'"
                        Jouken = Jouken & " AND MEISAI_KB <> '1' AND MEISAI_KB <> '2'"
                        Jouken = Jouken & " AND S_FLG_GENKA = '1'"
                        Jouken = Jouken & " AND J_FLG_SIWAKE = '0'"
                        Order = "SIME_YM"
                        Cnt03 = SELECT_IPPAN_DATA(Jouken, Order, DT03)
                        If Cnt03 > 0 Then
                            ChkMsg = "�������� �x�� ��������" & vbCrLf & vbCrLf
                            ChkMsg = ChkMsg & "��ʕ��̖��ݒ肪���݂��܂��B" & vbCrLf & vbCrLf
                            CmpBuf = ""
                            For lp = 0 To Cnt03 - 1
                                If CmpBuf <> DT03(lp).SIME_YM Then
                                    CmpBuf = DT03(lp).SIME_YM
                                    '2021.07.26 UPGRADE S  AIT)Tool Convert
                                    'ChkMsg = ChkMsg & "�@�y" & VB6.Format(DT03(lp).SIME_YM, "0000/00") & "�z" & vbCrLf
                                    ChkMsg = ChkMsg & "�@�y" & CDec(DT03(lp).SIME_YM).ToString("0000/00") & "�z" & vbCrLf
                                    '2021.07.26 UPGRADE E
                                End If
                            Next lp
                            ChkMsg = ChkMsg & vbCrLf & "�����I��"
                        End If

                        Msg = ChkMsg & "�y" & VB.Left(SELECTYM, 4) & "/" & VB.Right(SELECTYM, 2) & "�z�̏������J�n���܂��B"
                        Msg = Msg & vbCrLf & vbCrLf
                        Msg = Msg & "��낵���ł����H"
                        '2021.09.14 UPGRADE S  AIT)dannnl
                        'If MsgBox(Msg, MsgBoxStyle.YesNo + MsgBoxStyle.Information + MsgBoxStyle.DefaultButton2) = MsgBoxResult.No Then
                        If MsgBox(Msg, MsgBoxStyle.YesNo + MsgBoxStyle.Information + MsgBoxStyle.DefaultButton2, SYSTEMNM) = MsgBoxResult.No Then
                            '2021.09.14 UPGRADE E
                            If imDate1.Enabled = True Then imDate1.Focus() Else vaSpread1.Focus()
                            Exit Sub
                        End If

                        If Trim(DT01(0).SYORI_YM) = "" Then
                            MikomiFlg = 0
                        Else
                            Msg = "�O��̌����f�[�^�������p���܂����H"
                            '2021.09.14 UPGRADE S  AIT)dannnl
                            'If MsgBox(Msg, MsgBoxStyle.YesNo + MsgBoxStyle.Information + MsgBoxStyle.DefaultButton2) = MsgBoxResult.No Then
                            If MsgBox(Msg, MsgBoxStyle.YesNo + MsgBoxStyle.Information + MsgBoxStyle.DefaultButton2, SYSTEMNM) = MsgBoxResult.No Then
                                '2021.09.14 UPGRADE E
                                MikomiFlg = 0
                            Else
                                MikomiFlg = 1
                            End If
                        End If

                        '----- ��ݻ޸��݂̊J�n
                        '2021.07.26 UPGRADE S  AIT)Tool Convert
                        'SYKDB.BeginTrans()
                        BeginTrans()
                        '2021.07.26 UPGRADE E

                        '----- �����N���̊�{�f�[�^���쐬����
                        If KihonDataMakeD(KeyKouji.KOUJI_NO, KeyKouji.EDA_NO, SELECTYM, MikomiFlg) = False Then
                            RollBack()
                            Exit Sub
                        End If

                        ' �H�����i����j�y�؃e�[�u���̍X�V
                        With DT01(0)
                            .ZENKAI_YM = .SYORI_YM '�O�񏈗��N��
                            .SYORI_YM = SELECTYM '�����N��
                            .H_FLG_IPPAN = "0" '�ύXFLG ��ʕ��ꗗ
                            .H_FLG_MIKOMI = "0" '�ύXFLG ���c��O�������ꗗ
                            .H_FLG_GAICHUU = "0" '�ύXFLG �O���ꗗ
                            .H_FLG_IPPAN_M = "0" '�ύXFLG ��ʌ����ꗗ
                            .H_FLG_GEPPOU = "0" '�ύXFLG �H������ꗗ
                            .P_FLG_CHECK = "0" '���FLG ��ʕ���������ؽ�
                            .P_FLG_WARIDASI = "0" '���FLG ���c��O�����o���ꗗ
                            .P_FLG_DEKIDAKA = "0" '���FLG �O���o�����񍐏�
                            .P_FLG_IPPAN = "0" '���FLG ��ʕ��ꗗ
                            .P_FLG_GEPPOU = "0" '���FLG �H������
                            .R_FLG_KEIRI = "1" '�A�gFLG �o���f�[�^
                            .R_FLG_GEPPOU = "0" '�A�gFLG ����f�[�^
                            .R_FLG_TUKISIME = "0" '�A�gFLG ����
                        End With
                        Jouken = "KOUJI_NO = '" & KeyKouji.KOUJI_NO & "' AND EDA_NO = '" & KeyKouji.EDA_NO & "'"
                        If UPDATE_KOUJI_CTRL_D(Jouken, DT01(0)) = False Then
                            Msg = "�H�����i����j�y�؂̍쐬�Ɏ��s���܂����B"
                            Msg = Msg & vbCrLf & vbCrLf
                            If KeyKouji.EDA_NO = "0000" Then Msg = Msg & "�y�H���ԍ��F" & KeyKouji.KOUJI_NO & "�z" Else Msg = Msg & "�y�H���ԍ��F" & KeyKouji.KOUJI_NO & "-" & KeyKouji.EDA_NO & "�z"
                            '2021.09.14 UPGRADE S  AIT)dannnl
                            'MsgBox(Msg, MsgBoxStyle.OkOnly + MsgBoxStyle.Information)
                            MsgBox(Msg, MsgBoxStyle.OkOnly + MsgBoxStyle.Information, SYSTEMNM)
                            '2021.09.14 UPGRADE E
                            RollBack()
                            Exit Sub
                        End If

                        '----- ��ݻ޸��݂̊m��
                        '2021.07.26 UPGRADE S  AIT)Tool Convert
                        'SYKDB.CommitTrans()
                        CommitTransaction()
                        '2021.07.26 UPGRADE E

                    End If
                End If
                '2021.08.09 UPGRADE S  AIT)hieunv
                'Me.Close()
                Me.Dispose()
                '2021.08.09 UPGRADE E
            Case 3 '----- �폜
                KeyKouji.KOUJI_NO = Dsp(vaSpread1.ActiveSheet.ActiveRowIndex).KOUJI_NO
                KeyKouji.EDA_NO = Dsp(vaSpread1.ActiveSheet.ActiveRowIndex).EDA_NO
                KeyKouji.MEISYOU = Dsp(vaSpread1.ActiveSheet.ActiveRowIndex).MEISYOU
                KeyKouji.GYOUSYU_KB = Dsp(vaSpread1.ActiveSheet.ActiveRowIndex).GYOUSYU_KB
                KeyKouji.SIIRE_KB = Dsp(vaSpread1.ActiveSheet.ActiveRowIndex).SIIRE_KB
                ' �H�����i����j�y�؃e�[�u���̓Ǎ���
                Jouken = "KOUJI_NO = '" & KeyKouji.KOUJI_NO & "' AND EDA_NO = '" & KeyKouji.EDA_NO & "'"
                Order = ""
                Cnt01 = SELECT_KOUJI_CTRL_D(Jouken, Order, DT01)
                If Cnt01 > 0 Then
                    If DT01(0).R_FLG_TUKISIME <> "2" Then
                        Msg = "���̍H���͌������I�����Ă��܂���B"
                        Msg = Msg & vbCrLf & vbCrLf
                        If KeyKouji.EDA_NO = "0000" Then Msg = Msg & "�y�H���ԍ��F" & KeyKouji.KOUJI_NO & "�z" Else Msg = Msg & "�y�H���ԍ��F" & KeyKouji.KOUJI_NO & "-" & KeyKouji.EDA_NO & "�z"
                        Msg = Msg & vbCrLf & vbCrLf
                        Msg = Msg & "�����I�ɍ폜���Ă���낵���ł����H"
                        '2021.09.14 UPGRADE S  AIT)dannnl
                        'If MsgBox(Msg, MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2 + MsgBoxStyle.Information) = MsgBoxResult.No Then
                        If MsgBox(Msg, MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2 + MsgBoxStyle.Information, SYSTEMNM) = MsgBoxResult.No Then
                            '2021.09.14 UPGRADE E
                            Exit Sub
                        End If
                    Else
                        Msg = "�H�������폜���܂��B"
                        Msg = Msg & vbCrLf & vbCrLf
                        If KeyKouji.EDA_NO = "0000" Then Msg = Msg & "�y�H���ԍ��F" & KeyKouji.KOUJI_NO & "�z" Else Msg = Msg & "�y�H���ԍ��F" & KeyKouji.KOUJI_NO & "-" & KeyKouji.EDA_NO & "�z"
                        Msg = Msg & vbCrLf & vbCrLf
                        Msg = Msg & "�폜���Ă���낵���ł����H"
                        '2021.09.14 UPGRADE S  AIT)dannnl
                        'If MsgBox(Msg, MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2 + MsgBoxStyle.Information) = MsgBoxResult.No Then
                        If MsgBox(Msg, MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2 + MsgBoxStyle.Information, SYSTEMNM) = MsgBoxResult.No Then
                            '2021.09.14 UPGRADE E
                            Exit Sub
                        End If
                    End If
                Else
                    Msg = "�H�������폜���܂��B"
                    Msg = Msg & vbCrLf & vbCrLf
                    If KeyKouji.EDA_NO = "0000" Then Msg = Msg & "�y�H���ԍ��F" & KeyKouji.KOUJI_NO & "�z" Else Msg = Msg & "�y�H���ԍ��F" & KeyKouji.KOUJI_NO & "-" & KeyKouji.EDA_NO & "�z"
                    Msg = Msg & vbCrLf & vbCrLf
                    Msg = Msg & "�폜���Ă���낵���ł����H"
                    '2021.09.14 UPGRADE S  AIT)dannnl
                    'If MsgBox(Msg, MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2 + MsgBoxStyle.Information) = MsgBoxResult.No Then
                    If MsgBox(Msg, MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2 + MsgBoxStyle.Information, SYSTEMNM) = MsgBoxResult.No Then
                        '2021.09.14 UPGRADE E
                        Exit Sub
                    End If
                End If
                Msg = "�������@�ŏI�폜�m�F�@������"
                Msg = Msg & vbCrLf & vbCrLf
                If KeyKouji.EDA_NO = "0000" Then Msg = Msg & "�y�H���ԍ��F" & KeyKouji.KOUJI_NO & "�z" Else Msg = Msg & "�y�H���ԍ��F" & KeyKouji.KOUJI_NO & "-" & KeyKouji.EDA_NO & "�z"
                Msg = Msg & vbCrLf & vbCrLf
                Msg = Msg & "�폜���Ă���낵���ł����H"
                '2021.09.14 UPGRADE S  AIT)dannnl
                'If MsgBox(Msg, MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2 + MsgBoxStyle.Information) = MsgBoxResult.No Then
                If MsgBox(Msg, MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2 + MsgBoxStyle.Information, SYSTEMNM) = MsgBoxResult.No Then
                    '2021.09.14 UPGRADE E
                    Exit Sub
                End If
                ' �H�����폜�i�y�؁j
                '----- ��ݻ޸��݂̊J�n
                '2021.07.26 UPGRADE S  AIT)Tool Convert
                'SYKDB.BeginTrans()
                BeginTrans()
                '2021.07.26 UPGRADE E
                If KoujiDeleteD(KeyKouji.KOUJI_NO, KeyKouji.EDA_NO) = False Then
                    '----- ��ݻ޸��݂̒��f
                    'RollbackTrans()
                    RollBack()
                Else
                    '----- ��ݻ޸��݂̊m��
                    '2021.07.26 UPGRADE S  AIT)Tool Convert
                    'SYKDB.CommitTrans()
                    CommitTransaction()
                    '2021.07.26 UPGRADE E
                End If
                ' �ĕ\��
                Call MainDataDisp()
            Case 8 '----- ��M�ꗗ
                Call CLEAR_KOUJI_CTRL_D(CtlKouji)
                frmSYKD300.D300ShowMode = 1
                frmSYKD300.ShowDialog()
                ' �ĕ\��
                Call MainDataDisp()
            Case 12 '----- �I��
                Call JobEnd()
        End Select

    End Sub
    '2021.08.02 UPGRADE S  AIT)hieunv
    'Private Sub cmdKey_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Enter
    '    Dim Index As Short = cmdKey.GetIndex(eventSender)
    '    Call GotFocus(cmdKey(Index), StatusBar1)
    'End Sub
    Private Sub cmdKey_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _cmdKey_1.Enter, _cmdKey_3.Enter, _cmdKey_8.Enter, _cmdKey_12.Enter
        'Dim Index As Short = cmdKey.GetIndex(eventSender)
        Dim Index As Short = cmdKey.IndexOf(eventSender)
        'Call GotFocus(cmdKey(Index), StatusBar1)
        Call MtyTool.GotFocus(cmdKey(Index), StatusBar1)
        '2021.08.03 UPGRADE E
    End Sub
    '2021.08.02 UPGRADE E
    '2021.08.02 UPGRADE S  AIT)hieunv
    'Private Sub cmdKey_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Leave
    '    Dim Index As Short = cmdKey.GetIndex(eventSender)
    '    Call LostFocus(cmdKey(Index), StatusBar1)
    'End Sub
    Private Sub cmdKey_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _cmdKey_1.Leave, _cmdKey_3.Leave,
                                                                                                              _cmdKey_12.Leave, _cmdKey_8.Leave
        Dim Index As Short = cmdKey.IndexOf(eventSender)
        Call MtyTool.LostFocus(cmdKey(Index), StatusBar1)
    End Sub
    '2021.08.02 UPGRADE E
    Private Sub frmSYKD011_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown
        Dim KeyCode As Short = eventArgs.KeyCode
        Dim Shift As Short = eventArgs.KeyData \ &H10000
        Select Case KeyCode
            Case System.Windows.Forms.Keys.F1
                If cmdKey(1).Enabled = True Then cmdKey(1).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(1), New System.EventArgs())
            Case System.Windows.Forms.Keys.F3
                If cmdKey(3).Enabled = True Then cmdKey(3).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(3), New System.EventArgs())
            Case System.Windows.Forms.Keys.F8
                If cmdKey(8).Enabled = True Then cmdKey(8).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(8), New System.EventArgs())
            Case System.Windows.Forms.Keys.F12
                If cmdKey(12).Enabled = True Then cmdKey(12).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(12), New System.EventArgs())
        End Select

    End Sub

    Private Sub frmSYKD011_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load

        ' ��������
        Call JobFirst()

        ' ������
        SetKouji = ""

        ' �����\��
        Call FormDisp(Me)
        Call MainDataDisp()

        ' ���̓��[�h�̏�����
        INPMODE = B11INPMODE
        B10INPMODE = B11INPMODE

    End Sub

    Private Sub frmSYKD011_FormClosing(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Dim Cancel As Boolean = eventArgs.Cancel
        Dim UnloadMode As System.Windows.Forms.CloseReason = eventArgs.CloseReason
        If UnloadMode = System.Windows.Forms.CloseReason.UserClosing Then
            Call JobEnd()
        End If
        eventArgs.Cancel = Cancel
    End Sub

    Private Sub imDate1_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles imDate1.Enter
        '2021.08.02 UPGRADE S  AIT) hieunv
        'Call GotFocus(imDate1, StatusBar1)
        Call MtyTool.GotFocus(imDate1, StatusBar1)
        '2021.08.02 UPGRADE E
    End Sub

    Private Sub imDate1_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles imDate1.KeyDown
        Dim KeyCode As Short = eventArgs.KeyCode
        Dim Shift As Short = eventArgs.KeyData \ &H10000
        Select Case KeyCode
            Case System.Windows.Forms.Keys.Return
                If cmdKey(1).Enabled = True Then cmdKey(1).Focus()
        End Select

    End Sub

    Private Sub imDate1_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles imDate1.Leave
        '2021.08.02 UPGRADE S  AIT) hieunv
        'Call LostFocus(imDate1, StatusBar1)
        Call MtyTool.LostFocus(imDate1, StatusBar1)
        '2021.08.02 UPGRADE E
    End Sub

    Private Sub vaSpread1_DblClick(ByVal eventSender As System.Object, ByVal eventArgs As FarPoint.Win.Spread.CellClickEventArgs) Handles vaSpread1.CellDoubleClick
        '2021.08.14 UPDATE S  AIT)hieunv
        'Dim lp As Integer
        'Dim ssText As Object

        'If eventArgs.Col = 3 And eventArgs.Row = 0 Then

        '    Select Case Trim(Command1(2).Text)
        '        Case "�H�@�@���@�@��"
        '            Command1(2).Text = "�H�@���@���i���́j"
        '            With vaSpread1
        '                If Me.Visible = True Then
        '                    .ReDraw = False
        '                End If
        '                For lp = 0 To DCnt - 1
        '                    '----- �H����
        '                    'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
        '                    ssText = Trim(Dsp(lp).RYAKUSYOU)
        '                    .SetText(3, lp + 1, ssText)
        '                Next lp
        '                If Me.Visible = True Then
        '                    'UPGRADE_NOTE: Refresh was upgraded to CtlRefresh. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="A9E4979A-37FA-4718-9994-97DD76ED70A7"'
        '                    .CtlRefresh()
        '                    .ReDraw = True
        '                End If
        '            End With

        '        Case "�H�@���@���i���́j"
        '            Command1(2).Text = "�H�@�@���@�@��"
        '            With vaSpread1
        '                If Me.Visible = True Then
        '                    .ReDraw = False
        '                End If
        '                For lp = 0 To DCnt - 1
        '                    '----- �H����
        '                    ssText = Trim(Dsp(lp).MEISYOU)
        '                    .SetText(3, lp + 1, ssText)
        '                Next lp
        '                If Me.Visible = True Then
        '                    .CtlRefresh()
        '                    .ReDraw = True
        '                End If
        '            End With

        '    End Select

        'ElseIf eventArgs.Col > 0 And eventArgs.Row > 0 Then
        '    Call cmdKey_Click(cmdKey.Item(1), New System.EventArgs())
        'End If

        If eventArgs.Column >= 0 AndAlso
           eventArgs.Row >= 0 AndAlso
           eventArgs.ColumnHeader = False AndAlso
           eventArgs.RowHeader = False Then
            Call cmdKey_Click(cmdKey.Item(1), New System.EventArgs())
        End If
        '2021.08.14 UPDATE E  AIT)hieunv
    End Sub
    '2021.08.14 ADD S  AIT)hieunv
    Private Sub _Command1_2_Click(sender As Object, e As EventArgs) Handles _Command1_2.Click
        Dim lp As Integer
        Dim ssText As Object

        Select Case Trim(Command1(2).Text)
            Case "�H�@�@���@�@��"
                Command1(2).Text = "�H�@���@���i���́j"
                With vaSpread1
                    If Me.Visible = True Then
                        .SuspendLayout()
                    End If
                    For lp = 0 To DCnt - 1
                        '----- �H����
                        ssText = Trim(Dsp(lp).RYAKUSYOU)
                        .ActiveSheet.SetText(lp, 2, ssText)
                    Next lp
                    If Me.Visible = True Then
                        .Refresh()
                        .ResumeLayout()
                    End If
                End With

            Case "�H�@���@���i���́j"
                Command1(2).Text = "�H�@�@���@�@��"
                With vaSpread1
                    If Me.Visible = True Then
                        .SuspendLayout()
                    End If
                    For lp = 0 To DCnt - 1
                        '----- �H����
                        ssText = Trim(Dsp(lp).MEISYOU)
                        .ActiveSheet.SetText(lp, 2, ssText)
                    Next lp
                    If Me.Visible = True Then
                        .Refresh()
                        .ResumeLayout()
                    End If
                End With

        End Select
    End Sub
    '2021.08.16 ADD E 
    Private Sub vaSpread1_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles vaSpread1.Enter
        '2021.08.03 UPGRADE S  AIT)hieunv
        'Call GotFocus(vaSpread1, StatusBar1)
        Call MtyTool.GotFocus(vaSpread1, StatusBar1)
        '2021.08.03 UPGRADE E
    End Sub

    '2021.08.03 UPGRADE S  AIT)hieunv
    Private Sub vaSpread1_KeyDownEvent(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles vaSpread1.KeyDown
        'If eventArgs.KeyCode = System.Windows.Forms.Keys.Return Then
        '	If vaSpread1.ActiveRow > 0 Then
        If eventArgs.KeyCode = System.Windows.Forms.Keys.Return Then
            If vaSpread1_Sheet1.ActiveRowIndex >= 0 Then
                '2021.08.03 UPGRADE E  
                Call cmdKey_Click(cmdKey.Item(1), New System.EventArgs())
            End If
        End If
    End Sub

    Private Sub vaSpread1_LeaveCell(ByVal eventSender As System.Object, ByVal eventArgs As FarPoint.Win.Spread.LeaveCellEventArgs) Handles vaSpread1.LeaveCell

        Dim ssTextCTRLD As Object
        Dim ssTextCTRLS As Object

        ' �������t�̃Z�b�g
        'If eventArgs.NewRow > 0 Then
        If eventArgs.NewRow >= 0 Then
            '2013/12/12 �ǉ� -----------------------------------------------------------------����������
            '��Ԃɂ���ĉ�ʂ𐧌䂷��
            '------------------------------------------------
            '�����N��      ���
            'CTRL-D CTRL-S �������� �����N���@�@ �p�^�[��
            ' ����   �Ȃ�    ��     ��  /CTRL-D  �P
            ' ����   ����    ��     ��  /CTRL-D  �P
            ' �Ȃ�   �Ȃ�    �s��   �s��/��߰�   �Q
            ' �Ȃ�   ����    ��     �s��/CTRL-S  �R
            '------------------------------------------------
            '2021.08.03 UPGRADE S  AIT)hieunv
            'Call vaSpread1.GetText(4, eventArgs.NewRow,ssTextCTRLD )
            'Call vaSpread1.GetText(8, eventArgs.NewRow,ssTextCTRLS )
            ssTextCTRLD = vaSpread1.ActiveSheet.GetText(eventArgs.NewRow, 3)
            ssTextCTRLS = vaSpread1.ActiveSheet.GetText(eventArgs.NewRow, 7)
            '2021.08.03 UPGRADE E

            If Trim(ssTextCTRLD) <> "" Then
                '�p�^�[���P
                cmdKey(1).Enabled = True '����{�^����L��
                imDate1.Enabled = True '�����N����L��
                imDate1.Text = Trim(ssTextCTRLD) '�����N����CTRL-D
            ElseIf Trim(ssTextCTRLS) = "" Then
                '�p�^�[���Q
                cmdKey(1).Enabled = False '����{�^���𖳌�
                imDate1.Enabled = False '�����N���𖳌�
                imDate1.Text = "" '�����N�����X�y�[�X
            Else
                '�p�^�[���R
                cmdKey(1).Enabled = True '����{�^����L��
                imDate1.Enabled = False '�����N����L��
                imDate1.Text = Trim(ssTextCTRLS) '�����N����CTRL-S
            End If
            '---------------------------------------------------------------------------------����������
        End If

    End Sub

    Private Sub vaSpread1_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles vaSpread1.Leave
        '2021.08.03 UPGRADE S  AIT)hieunv
        'Call LostFocus(vaSpread1, StatusBar1)
        Call MtyTool.LostFocus(vaSpread1, StatusBar1)
        '2021.08.03 UPGRADE S  AIT)hieunv
    End Sub

    '-------------------------------------------------------------------------------
    '   ����   :   KOUJI_NO_MAST �ǂݍ��ݏ���
    '   �֐�   :   Function SelectKoujiNoMast()
    '   ����   :   DT()�@   KOUJI_NO_MAST_QRY
    '   �ߒl   :   �ް���   ����I��
    '   �@�@       -1�@     �ُ�I��
    '   �@�\   :   KOUJI_NO_MAST SELECT����
    '-------------------------------------------------------------------------------
    Private Function SelectKoujiNoMast(ByRef DT() As KOUJI_NO_MAST_DBT) As Integer

        Dim SQL As String
        '2021.08.02 UPGRADE S  AIT)hieunv
        'Dim Rs As ADODB.Recordset
        'Dim Fld As ADODB.Field
        Dim Rs As New DataTable
        '2021.08.02 UPGRADE E
        Dim Cnt As Integer
        Dim OpenFlg As Short

        '2021.07.26 UPGRADE S  AIT)Tool Convert
        'On Error GoTo SelectKoujiNoMast_Err
        Try
            '2021.07.26 UPGRADE E

            '�߂�l�̏�����
            SelectKoujiNoMast = -1

            If SYSTEMID <> "S" Then
                'SQL/SELECT���g��
                SQL = "SELECT"
                SQL = SQL & " KOUJI_NO_MAST.KOUJI_NO   AS KOUJI_NO," '�H���ԍ�
                SQL = SQL & " KOUJI_NO_MAST.EDA_NO     AS EDA_NO," '�H���}��
                SQL = SQL & " KOUJI_NO_MAST.MEISYOU    AS MEISYOU," '�H������
                SQL = SQL & " KOUJI_NO_MAST.GYOUSYU_KB AS GYOUSYU_KB" '�Ǝ�敪
                SQL = SQL & " FROM KOUJI_NO_MAST"
                SQL = SQL & " WHERE GYOUSYU_KB = '" & GyosyuID & "'"
                SQL = SQL & " ORDER BY KOUJI_NO, EDA_NO"
            Else
                'SQL/SELECT���g��
                SQL = "SELECT"
                SQL = SQL & " KOUJI_NO_MAST.KOUJI_NO   AS KOUJI_NO," '�H���ԍ�
                SQL = SQL & " KOUJI_NO_MAST.EDA_NO     AS EDA_NO," '�H���}��
                SQL = SQL & " KOUJI_NO_MAST.MEISYOU    AS MEISYOU," '�H������
                SQL = SQL & " KOUJI_NO_MAST.GYOUSYU_KB AS GYOUSYU_KB" '�Ǝ�敪
                SQL = SQL & " FROM KOUJI_NO_MAST INNER JOIN KOUJI_CTRL_S ON"
                SQL = SQL & " (KOUJI_NO_MAST.KOUJI_NO = KOUJI_CTRL_S.KOUJI_NO"
                SQL = SQL & " AND KOUJI_NO_MAST.EDA_NO = KOUJI_CTRL_S.EDA_NO)"
                SQL = SQL & " WHERE KOUJI_NO_MAST.GYOUSYU_KB = '" & GyosyuID & "'"
                SQL = SQL & " AND KOUJI_CTRL_S.K_STATUS <>'3'"
                SQL = SQL & " ORDER BY KOUJI_NO, EDA_NO"
            End If

            'SQL�����s
            '2021.08.02 UPGRADE S  AIT)hieunv
            'Rs = SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText)
            Rs = RsOpen(SQL)
            '2021.08.02 UPGRADE E
            OpenFlg = 1
            Cnt = 0
            '2021.08.02 UPGRADE S  AIT)dannnl
            'Do Until Rs.EOF
            For Each Row As DataRow In Rs.Rows
                '2021.08.02 UPGRADE E
                ReDim Preserve DT(Cnt)
                With DT(Cnt)
                    '----- ������
                    .KOUJI_NO = "" '�H���ԍ�
                    .EDA_NO = "" '�H���}��
                    .MEISYOU = "" '�H������
                    .GYOUSYU_KB = "" '�Ǝ�敪
                    '----- �\���̂�
                    '2021.08.03 UPGRADE S  AIT)hieunv
                    'For Each Fld In Rs.Columns
                    '    If IsDBNull(Fld.Name) = False And IsDBNull(Fld.Value) = False Then
                    '        Select Case UCase(Fld.Name)
                    '            Case "KOUJI_NO" : .KOUJI_NO = Fld.Value '�H���ԍ�
                    '            Case "EDA_NO" : .EDA_NO = Fld.Value '�H���}��
                    '            Case "MEISYOU" : .MEISYOU = Fld.Value '�H������
                    '            Case "GYOUSYU_KB" : .GYOUSYU_KB = Fld.Value '�Ǝ�敪
                    '        End Select
                    '    End If
                    'Next Fld
                    For Each Fld As DataColumn In Row.Table.Columns
                        Dim FldValue = Row(Fld.ColumnName)
                        If IsDBNull(Fld.ColumnName) = False And IsDBNull(FldValue) = False Then
                            Select Case UCase(Fld.ColumnName)
                                Case "KOUJI_NO" : .KOUJI_NO = FldValue '�H���ԍ�
                                Case "EDA_NO" : .EDA_NO = FldValue '�H���}��
                                Case "MEISYOU" : .MEISYOU = FldValue '�H������
                                Case "GYOUSYU_KB" : .GYOUSYU_KB = FldValue '�Ǝ�敪
                            End Select
                        End If
                    Next
                    '2021.08.03 UPGRADE E
                End With
                Cnt = Cnt + 1
                '2021.08.03 UPGRADE S  AIT)hieunv
                '	Rs.MoveNext()
                'Loop

                'Rs.Close()
            Next

            Rs.Dispose()
            '2021.08.03 UPGRADE E
            Rs = Nothing

            '�߂�l�̃Z�b�g
            SelectKoujiNoMast = Cnt
            Exit Function

            '2021.07.26 UPGRADE S  AIT)Tool Convert
            'SelectKoujiNoMast_Err:
        Catch ex As Exception
            '2021.07.26 UPGRADE E

            If OpenFlg = 1 Then
                '2021.08.03 UPGRADE S  AIT)hieunv
                'Rs.Close()
                Rs.Dispose()
                '2021.08.03 UPGRADE E
            End If
            Rs = Nothing

            '2021.08.03 UPGRADE S  AIT)hieunv
            'Call Sql_Error_Msg("KOUJI_NO_MAST SELECT")
            Call Sql_Error_Msg(ex, "KOUJI_NO_MAST SELECT")
            '2021.08.03 UPGRADE E

        End Try     '2021.07.26 UPGRADE ADD AIT)Tool Convert
    End Function

    '-------------------------------------------------------------------------------
    '   ����   :   KOUJI_NO_MAST_DBT �\���̃N���A����
    '   �֐�   :   Sub CLEAR_DSP_KOUJI_QRY()
    '   ����   :   DT  KOUJI_NO_MAST_DBT
    '   �@�\   :   �\���̂�����������
    '-------------------------------------------------------------------------------
    Private Sub CLEAR_DSP_KOUJI_QRY(ByRef DT As DSP_KOUJI_QRY)

        With DT
            .KOUJI_NO = "" '�H���ԍ�
            .EDA_NO = "" '�H���}��
            .MEISYOU = "" '�H������
            .GYOUSYU_KB = "" '�Ǝ�敪
            .SIIRE_KB = "" '�d���敪
            .K_STATUS = "" '�H�����
            .G_STATUS = "" '�Ɩ����
            .CTRL_S_SYORI_YM = "" '�����N��(CTRL_S)
            .SYORI_YM = "" '�����N��
            .MIN_YM = "" '�ŏ�����N��
            .MAX_YM = "" '�ő匎��N��
            .RYAKUSYOU = "" '����
        End With

    End Sub

    '-------------------------------------------------------------------------------
    '   ����   :   DSP_KOUJI_QRY �f�[�^�Z�b�g����
    '   �֐�   :   Sub DATSET_DSP_KOUJI_QRY()
    '   ����   :   Rs  ADODB.Recordset
    '   �@�@       DT  DSP_KOUJI_QRY
    '   �@�\   :   �\���̂Ƀf�[�^���Z�b�g����
    '-------------------------------------------------------------------------------
    '2021.08.03 UPGRADE S  AIT)hieunv
    'Private Sub DATSET_DSP_KOUJI_QRY(ByRef Rs As ADODB.Recordset, ByRef DT As DSP_KOUJI_QRY)

    'Dim Fld As ADODB.Field
    Private Sub DATSET_DSP_KOUJI_QRY(ByRef Rs As DataRow, ByRef DT As DSP_KOUJI_QRY)

        Dim Fld As DataColumn
        '2021.08.03 UPGRADE E

        '�\���̂̏�����
        Call CLEAR_DSP_KOUJI_QRY(DT)

        '�t�B�[���h�����������s
        '2021.08.03 UPGRADE S  AIT)hieunv
        'For Each Fld In Rs.Fields
        '    If IsDBNull(Fld.Name) = False And IsDBNull(Fld.Value) = False Then
        '        Select Case UCase(Fld.Name)
        '            Case "KOUJI_NO" : DT.KOUJI_NO = Fld.Value '�H���ԍ�
        '            Case "EDA_NO" : DT.EDA_NO = Fld.Value '�H���}��
        '            Case "MEISYOU" : DT.MEISYOU = Fld.Value '�H������
        '            Case "GYOUSYU_KB" : DT.GYOUSYU_KB = Fld.Value '�Ǝ�敪
        '            Case "SIIRE_KB" : DT.SIIRE_KB = Fld.Value '�d���敪
        '            Case "K_STATUS" : DT.K_STATUS = Fld.Value '�H�����
        '            Case "G_STATUS" : DT.G_STATUS = Fld.Value '�Ɩ����
        '            Case "CTRL_S_SYORI_YM" : DT.CTRL_S_SYORI_YM = Fld.Value '�����N��(CTRL_S)
        '            Case "SYORI_YM" : DT.SYORI_YM = Fld.Value '�����N��
        '            Case "MIN_YM" : DT.MIN_YM = Fld.Value '�ŏ�����N��
        '            Case "MAX_YM" : DT.MAX_YM = Fld.Value '�ő匎��N��
        '            Case "RYAKUSYOU" : DT.RYAKUSYOU = Fld.Value '����
        '        End Select
        '    End If
        'Next Fld
        For Each Fld In Rs.Table.Columns
            Dim FldValue = Rs(Fld.ColumnName)
            If IsDBNull(Fld.ColumnName) = False And IsDBNull(FldValue) = False Then
                Select Case UCase(Fld.ColumnName)
                    Case "KOUJI_NO" : DT.KOUJI_NO = FldValue '�H���ԍ�
                    Case "EDA_NO" : DT.EDA_NO = FldValue '�H���}��
                    Case "MEISYOU" : DT.MEISYOU = FldValue '�H������
                    Case "GYOUSYU_KB" : DT.GYOUSYU_KB = FldValue '�Ǝ�敪
                    Case "SIIRE_KB" : DT.SIIRE_KB = FldValue '�d���敪
                    Case "K_STATUS" : DT.K_STATUS = FldValue '�H�����
                    Case "G_STATUS" : DT.G_STATUS = FldValue '�Ɩ����
                    Case "CTRL_S_SYORI_YM" : DT.CTRL_S_SYORI_YM = FldValue '�����N��(CTRL_S)
                    Case "SYORI_YM" : DT.SYORI_YM = FldValue '�����N��
                    Case "MIN_YM" : DT.MIN_YM = FldValue '�ŏ�����N��
                    Case "MAX_YM" : DT.MAX_YM = FldValue '�ő匎��N��
                    Case "RYAKUSYOU" : DT.RYAKUSYOU = FldValue '����
                End Select
            End If
        Next Fld
        '2021.08.03 UPGRADE E
    End Sub

    '-------------------------------------------------------------------------------
    '   ����   :   DSP_KOUJI_QRY �ǂݍ��ݏ���
    '   �֐�   :   Function SELECT_DSP_KOUJI_QRY()
    '   ����   :   Jouken�@ ������
    '   �@�@       strSort�@�\�[�g����
    '   �@�@       DT()�@   DSP_KOUJI_QRY
    '   �ߒl   :   �ް���   ����I��
    '   �@�@       -1�@     �ُ�I��
    '   �@�\   :   DSP_KOUJI_QRY SELECT����
    '-------------------------------------------------------------------------------
    Private Function SELECT_DSP_KOUJI_QRY(ByRef Jouken As String, ByRef strSort As String, ByRef DT() As DSP_KOUJI_QRY) As Integer

        Dim SQL As String
        '2021.08.03 UPGRADE S  AIT)hieunv
        'Dim Rs As ADODB.Recordset
        Dim Rs As New DataTable
        '2021.08.03 UPGRADE E
        Dim Cnt As Integer
        Dim OpenFlg As Short

        '2021.07.26 UPGRADE S  AIT)Tool Convert
        'On Error GoTo SELECT_DSP_KOUJI_QRY_Err
        Try
            '2021.07.26 UPGRADE E

            '�߂�l�̏�����
            SELECT_DSP_KOUJI_QRY = -1

            'SQL/SELECT���g��
            SQL = "SELECT "
            SQL = SQL & "KOUJI_NO_MAST.KOUJI_NO        AS KOUJI_NO, "
            SQL = SQL & "KOUJI_NO_MAST.EDA_NO          AS EDA_NO, "
            SQL = SQL & "MIN(KOUJI_NO_MAST.MEISYOU)    AS MEISYOU, "
            SQL = SQL & "MIN(KOUJI_NO_MAST.GYOUSYU_KB) AS GYOUSYU_KB, "
            SQL = SQL & "MIN(KOUJI_NO_MAST.SIIRE_KB)   AS SIIRE_KB, "
            SQL = SQL & "MAX(KOUJI_CTRL_S.K_STATUS)    AS K_STATUS, "
            SQL = SQL & "MAX(KOUJI_CTRL_S.G_STATUS)    AS G_STATUS, "
            SQL = SQL & "MAX(KOUJI_CTRL_S.SYORI_YM)    AS CTRL_S_SYORI_YM, "
            SQL = SQL & "MAX(KOUJI_CTRL_D.SYORI_YM)    AS SYORI_YM, "
            SQL = SQL & "MIN(GEPPOU_DATA_D.SIME_YM)    AS MIN_YM, "
            SQL = SQL & "MAX(GEPPOU_DATA_D.SIME_YM)    AS MAX_YM, "
            SQL = SQL & "MIN(KOUJI_MAST.RYAKUSYOU)     AS RYAKUSYOU "
            SQL = SQL & "FROM "
            SQL = SQL & "(((KOUJI_NO_MAST LEFT JOIN KOUJI_CTRL_S ON "
            SQL = SQL & "(KOUJI_NO_MAST.EDA_NO = KOUJI_CTRL_S.EDA_NO) AND (KOUJI_NO_MAST.KOUJI_NO = KOUJI_CTRL_S.KOUJI_NO)) "
            SQL = SQL & "LEFT JOIN KOUJI_CTRL_D ON "
            SQL = SQL & "(KOUJI_NO_MAST.EDA_NO = KOUJI_CTRL_D.EDA_NO) AND (KOUJI_NO_MAST.KOUJI_NO = KOUJI_CTRL_D.KOUJI_NO)) "
            SQL = SQL & "LEFT JOIN GEPPOU_DATA_D ON "
            SQL = SQL & "(KOUJI_NO_MAST.EDA_NO = GEPPOU_DATA_D.EDA_NO) AND (KOUJI_NO_MAST.KOUJI_NO = GEPPOU_DATA_D.KOUJI_NO)) "
            SQL = SQL & "LEFT JOIN KOUJI_MAST ON "
            SQL = SQL & "(KOUJI_NO_MAST.EDA_NO = KOUJI_MAST.EDA_NO) AND (KOUJI_NO_MAST.KOUJI_NO = KOUJI_MAST.KOUJI_NO)"
            If Trim(Jouken) <> "" Then
                SQL = SQL & " WHERE " & Jouken
            End If
            If Trim(strSort) <> "" Then
                SQL = SQL & " GROUP BY " & strSort
                SQL = SQL & " ORDER BY " & strSort
            End If

            'SQL�����s
            'SQL�����s
            '2021.08.03 UPGRADE S  AIT)hieunv
            'Rs = SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText)
            Rs = RsOpen(SQL)
            '2021.08.03 UPGRADE E
            OpenFlg = 1

            Cnt = 0
            '2021.08.02 UPGRADE S  AIT)hieunv
            'Do Until Rs.EOF
            For Each Row As DataRow In Rs.Rows
                '2021.08.02 UPGRADE E
                ReDim Preserve DT(Cnt)
                'Call DATSET_DSP_KOUJI_QRY(Rs, DT(Cnt))
                Call DATSET_DSP_KOUJI_QRY(Row, DT(Cnt))
                Cnt = Cnt + 1
                '2021.08.03 UPGRADE S  AIT)hieunv
                '	Rs.MoveNext()
                'Loop

                'Rs.Close()
            Next
            Rs.Dispose()
            '2021.08.03 UPGRADE E
            Rs = Nothing

            '�߂�l�̃Z�b�g
            SELECT_DSP_KOUJI_QRY = Cnt
            Exit Function

            '2021.07.26 UPGRADE S  AIT)Tool Convert
            'SELECT_DSP_KOUJI_QRY_Err:
        Catch ex As Exception
            '2021.07.26 UPGRADE E

            If OpenFlg = 1 Then
                '2021.08.03 UPGRADE S  AIT)hieunv
                'Rs.Close()
                Rs.Dispose()
                '2021.08.03 UPGRADE E
            End If
            Rs = Nothing

            '2021.08.03 UPGRADE S  AIT)hieunv
            'Call Sql_Error_Msg("KOUJI_NO_MAST SELECT")
            Call Sql_Error_Msg(ex, "KOUJI_NO_MAST SELECT")
            '2021.08.03 UPGRADE E

        End Try     '2021.07.26 UPGRADE ADD AIT)Tool Convert
    End Function

End Class
