﻿'汎用関数クラス
'機能：汎用関数を静的メソッドとして提供する
Imports System.Linq
Imports System.Runtime.InteropServices

Public Class Util
    '**********************************************************************
    ' サブルーチン名          LeftB
    '----------------------------------------------------------------------
    ' 用途     文字列の左側より指定したバイト数文字を取得します。
    '
    ' 引数     ①stTarget
    '          ②iByteSize
    '
    ' 戻値     文字列の左側より指定したバイト数文字の結果を取得します。
    Public Shared Function LeftB(ByVal stTarget As String, ByVal iByteSize As Integer) As String
        Return MidB(stTarget, 1, iByteSize)
    End Function

    '**********************************************************************
    ' サブルーチン名          MidB
    '----------------------------------------------------------------------
    ' 用途     Mid関数のバイト版。文字数と位置をバイト数で指定して文字列を切り抜く
    '
    ' 引数     ①stTarget
    '          ②iStart
    '          ③iByteSize
    '
    ' 戻値    切り抜かれた文字列
    Public Shared Function MidB(ByVal stTarget As String, ByVal iStart As Integer, ByVal iByteSize As Integer) As String
        stTarget = stTarget.Replace(" ", "  ")
        Dim hEncoding As System.Text.Encoding = System.Text.Encoding.GetEncoding("Shift_JIS")
        Dim btBytes As Byte() = hEncoding.GetBytes(stTarget)
        Dim countSpace As Integer = stTarget.Count(Function(s) s = " "c)
        Dim count As Integer = 0

        If iByteSize <= 0 OrElse (iStart <= 0) Then
            Return ""
        End If
        If btBytes.Length > iByteSize AndAlso (iStart <= btBytes.Length) Then
            If (iStart + iByteSize > btBytes.Length) Then
                count = btBytes.Length - iStart + 1
            Else
                count = iByteSize
            End If
        ElseIf iStart <= btBytes.Length Then
            If (iStart + iByteSize >= btBytes.Length) Then
                count = btBytes.Length - iStart + 1
            Else
                count = btBytes.Length
            End If
        End If
        stTarget = hEncoding.GetString(btBytes, iStart - 1, count)
        stTarget = stTarget.Replace("  ", " ")
        Return stTarget
    End Function

    '**********************************************************************
    ' サブルーチン名          LenB
    '----------------------------------------------------------------------
    ' 用途     文字列の長さを計算します。
    '
    ' 引数     ①stTarget
    '
    ' 戻値     文字列の長さの結果を返却します。
    Public Shared Function LenB(ByVal stTarget As String) As Integer
        Dim hEncoding As System.Text.Encoding = System.Text.Encoding.GetEncoding("Shift_JIS")
        Dim btBytes As Byte() = hEncoding.GetBytes(stTarget)
        Dim countSpace As Integer = stTarget.Count(Function(s) s = " "c)
        Return btBytes.Length + countSpace
    End Function

    '**********************************************************************
    ' サブルーチン名          InStrB
    '----------------------------------------------------------------------
    ' 用途     InStr関数のバイト版。Returning the byte position of the first occurrence of one string within another
    '
    ' 引数     ①stTarget
    '          ②searchChar
    '
    ' 戻値     文字列の長さの結果を返却します。
    Public Shared Function InStrB(ByVal stTarget As String, searchChar As Char) As Integer
        Dim hEncoding As Text.Encoding = System.Text.Encoding.GetEncoding("Shift_JIS")
        stTarget = BitConverter.ToString(hEncoding.GetBytes(stTarget))
        Return InStr(stTarget, searchChar)
    End Function

    '**********************************************************************
    ' サブルーチン名          TwipsToPixelsX
    '----------------------------------------------------------------------
    ' 用途     TwipsをPixelsXに変換します。
    '
    ' 引数     ①tX
    '          ②frm
    '
    ' 戻値     変換後の結果を返却します。
    Public Shared Function TwipsToPixelsX(ByVal tX As Integer, ByRef frm As Object) As Integer
        Dim g As Graphics = frm.CreateGraphics

        Return CInt(tX * g.DpiX / 1440)

    End Function

    '**********************************************************************
    ' サブルーチン名          TwipsToPixelsY
    '----------------------------------------------------------------------
    ' 用途     TwipsをPixelsYに変換します。
    '
    ' 引数     ①tX
    '          ②frm
    '
    ' 戻値     変換後の結果を返却します。
    Public Shared Function TwipsToPixelsY(ByVal tY As Integer, ByRef frm As Object) As Integer
        Dim g As Graphics = frm.CreateGraphics

        Return CInt(tY * g.DpiY / 1440)

    End Function

    '**********************************************************************
    ' サブルーチン名          PixelsToTwipsX
    '----------------------------------------------------------------------
    ' 用途     PixelsをTwipsXに変換します。
    '
    ' 引数     ①pX
    '          ②frm
    '
    ' 戻値     変換後の結果を返却します。
    Public Shared Function PixelsToTwipsX(ByVal pX As Integer, ByRef frm As Object) As Integer
        Dim g As Graphics = frm.CreateGraphics

        Return CInt(pX * 1440 / g.DpiX)

    End Function

    '**********************************************************************
    ' サブルーチン名          PixelsToTwipsY
    '----------------------------------------------------------------------
    ' 用途     PixelsをTwipsYに変換します。
    '
    ' 引数     ①pX
    '          ②frm
    '
    ' 戻値     変換後の結果を返却します。
    Public Shared Function PixelsToTwipsY(ByVal pY As Integer, ByRef frm As Object) As Integer
        Dim g As Graphics = frm.CreateGraphics

        Return CInt(pY * 1440 / g.DpiY)

    End Function

    '**********************************************************************
    ' サブルーチン名          PrevInstance
    '----------------------------------------------------------------------
    ' 用途     Creates an array of new Process components and associates them with the existing process resources that all share the specified process name.
    '
    ' 戻値     Boolean
    Public Shared Function PrevInstance() As Boolean
        If UBound(Diagnostics.Process.GetProcessesByName(Diagnostics.Process.GetCurrentProcess.ProcessName)) > 0 Then
            Return True
        Else
            Return False
        End If
    End Function

    '**********************************************************************
    ' サブルーチン名          TwipsPerPixelX
    '----------------------------------------------------------------------
    Public Shared Function TwipsPerPixelX(ByRef frm As Form) As Single
        Dim g As Graphics = frm.CreateGraphics()
        Return 1440.0F / g.DpiX
    End Function

    '**********************************************************************
    ' サブルーチン名          TwipsPerPixelY
    '----------------------------------------------------------------------
    Public Shared Function TwipsPerPixelY(ByRef frm As Form) As Single
        Dim g As Graphics = frm.CreateGraphics()
        Return 1440.0F / g.DpiY
    End Function

    '**********************************************************************
    ' サブルーチン名          SetColorCalendar
    '----------------------------------------------------------------------
    Public Shared Function SetColorCalendar(ByRef ctrlDate As GrapeCity.Win.Editors.GcDate) As Single
        ctrlDate.DropDownCalendar.ShowTodayMark = False
        ctrlDate.DropDownCalendar.ActiveHolidayStyles = New String() {"HolidayStyles1"}
        ctrlDate.DropDownCalendar.HolidayStyles = New GrapeCity.Win.Editors.HolidayStyleCollection(New String() {"HolidayStyles1"}, New GrapeCity.Win.Editors.HolidayStyle() {New GrapeCity.Win.Editors.HolidayStyle("HolidayStyles1", New GrapeCity.Win.Editors.HolidayCollection(New GrapeCity.Win.Editors.IHoliday() {CType(New GrapeCity.Win.Editors.Holiday("", 1, 1), GrapeCity.Win.Editors.IHoliday), CType(New GrapeCity.Win.Editors.Holiday("", 1, 15), GrapeCity.Win.Editors.IHoliday), CType(New GrapeCity.Win.Editors.Holiday("", 2, 11), GrapeCity.Win.Editors.IHoliday), CType(New GrapeCity.Win.Editors.Holiday("", 4, 29), GrapeCity.Win.Editors.IHoliday), CType(New GrapeCity.Win.Editors.Holiday("", 5, 3), GrapeCity.Win.Editors.IHoliday), CType(New GrapeCity.Win.Editors.Holiday("", 5, 5), GrapeCity.Win.Editors.IHoliday), CType(New GrapeCity.Win.Editors.Holiday("", 7, 20), GrapeCity.Win.Editors.IHoliday), CType(New GrapeCity.Win.Editors.Holiday("", 9, 15), GrapeCity.Win.Editors.IHoliday), CType(New GrapeCity.Win.Editors.Holiday("", 10, 10), GrapeCity.Win.Editors.IHoliday), CType(New GrapeCity.Win.Editors.Holiday("", 11, 3), GrapeCity.Win.Editors.IHoliday), CType(New GrapeCity.Win.Editors.Holiday("", 11, 23), GrapeCity.Win.Editors.IHoliday), CType(New GrapeCity.Win.Editors.Holiday("", 12, 23), GrapeCity.Win.Editors.IHoliday)}, New GrapeCity.Win.Editors.Weekdays(New GrapeCity.Win.Editors.DayOfWeekHolidayPolicy() {New GrapeCity.Win.Editors.DayOfWeekHolidayPolicy(CType((((((GrapeCity.Win.Editors.WeekFlags.FirstWeek Or GrapeCity.Win.Editors.WeekFlags.SecondWeek) _
                                                Or GrapeCity.Win.Editors.WeekFlags.ThirdWeek) _
                                                Or GrapeCity.Win.Editors.WeekFlags.FourthWeek) _
                                                Or GrapeCity.Win.Editors.WeekFlags.FifthWeek) _
                                                Or GrapeCity.Win.Editors.WeekFlags.LastWeek), GrapeCity.Win.Editors.WeekFlags), GrapeCity.Win.Editors.HolidayOverride.NextWorkDay), New GrapeCity.Win.Editors.DayOfWeekHolidayPolicy(GrapeCity.Win.Editors.WeekFlags.None, GrapeCity.Win.Editors.HolidayOverride.None), New GrapeCity.Win.Editors.DayOfWeekHolidayPolicy(GrapeCity.Win.Editors.WeekFlags.None, GrapeCity.Win.Editors.HolidayOverride.None), New GrapeCity.Win.Editors.DayOfWeekHolidayPolicy(GrapeCity.Win.Editors.WeekFlags.None, GrapeCity.Win.Editors.HolidayOverride.None), New GrapeCity.Win.Editors.DayOfWeekHolidayPolicy(GrapeCity.Win.Editors.WeekFlags.None, GrapeCity.Win.Editors.HolidayOverride.None), New GrapeCity.Win.Editors.DayOfWeekHolidayPolicy(GrapeCity.Win.Editors.WeekFlags.None, GrapeCity.Win.Editors.HolidayOverride.None), New GrapeCity.Win.Editors.DayOfWeekHolidayPolicy(GrapeCity.Win.Editors.WeekFlags.None, GrapeCity.Win.Editors.HolidayOverride.None)})), New GrapeCity.Win.Editors.SubStyle(System.Drawing.SystemColors.Window, System.Drawing.Color.Red, True, False))})
        ctrlDate.DropDownCalendar.Weekdays = New GrapeCity.Win.Editors.WeekdaysStyle(New GrapeCity.Win.Editors.DayOfWeekStyle("日", GrapeCity.Win.Editors.ReflectTitle.None, New GrapeCity.Win.Editors.SubStyle(System.Drawing.SystemColors.Window, System.Drawing.Color.Red, True, False), CType((((((GrapeCity.Win.Editors.WeekFlags.FirstWeek Or GrapeCity.Win.Editors.WeekFlags.SecondWeek) _
                    Or GrapeCity.Win.Editors.WeekFlags.ThirdWeek) _
                    Or GrapeCity.Win.Editors.WeekFlags.FourthWeek) _
                    Or GrapeCity.Win.Editors.WeekFlags.FifthWeek) _
                    Or GrapeCity.Win.Editors.WeekFlags.LastWeek), GrapeCity.Win.Editors.WeekFlags)), New GrapeCity.Win.Editors.DayOfWeekStyle("月", GrapeCity.Win.Editors.ReflectTitle.None, New GrapeCity.Win.Editors.SubStyle(System.Drawing.SystemColors.Window, System.Drawing.SystemColors.WindowText, False, False), GrapeCity.Win.Editors.WeekFlags.None), New GrapeCity.Win.Editors.DayOfWeekStyle("火", GrapeCity.Win.Editors.ReflectTitle.None, New GrapeCity.Win.Editors.SubStyle(System.Drawing.SystemColors.Window, System.Drawing.SystemColors.WindowText, False, False), GrapeCity.Win.Editors.WeekFlags.None), New GrapeCity.Win.Editors.DayOfWeekStyle("水", GrapeCity.Win.Editors.ReflectTitle.None, New GrapeCity.Win.Editors.SubStyle(System.Drawing.SystemColors.Window, System.Drawing.SystemColors.WindowText, False, False), GrapeCity.Win.Editors.WeekFlags.None), New GrapeCity.Win.Editors.DayOfWeekStyle("木", GrapeCity.Win.Editors.ReflectTitle.None, New GrapeCity.Win.Editors.SubStyle(System.Drawing.SystemColors.Window, System.Drawing.SystemColors.WindowText, False, False), GrapeCity.Win.Editors.WeekFlags.None), New GrapeCity.Win.Editors.DayOfWeekStyle("金", GrapeCity.Win.Editors.ReflectTitle.None, New GrapeCity.Win.Editors.SubStyle(System.Drawing.SystemColors.Window, System.Drawing.SystemColors.WindowText, False, False), GrapeCity.Win.Editors.WeekFlags.None), New GrapeCity.Win.Editors.DayOfWeekStyle("土", GrapeCity.Win.Editors.ReflectTitle.None, New GrapeCity.Win.Editors.SubStyle(System.Drawing.SystemColors.Window, System.Drawing.Color.Blue, True, False), CType((((((GrapeCity.Win.Editors.WeekFlags.FirstWeek Or GrapeCity.Win.Editors.WeekFlags.SecondWeek) _
                    Or GrapeCity.Win.Editors.WeekFlags.ThirdWeek) _
                    Or GrapeCity.Win.Editors.WeekFlags.FourthWeek) _
                    Or GrapeCity.Win.Editors.WeekFlags.FifthWeek) _
                    Or GrapeCity.Win.Editors.WeekFlags.LastWeek), GrapeCity.Win.Editors.WeekFlags)))
    End Function
End Class
