Option Strict Off
Option Explicit On
Imports VB = Microsoft.VisualBasic
Friend Class frmSYKD300
	Inherits System.Windows.Forms.Form
	'=============================================================
	' ���[�U�[���@  �F  �R�z�H�Ɗ������
	' �V�X�e�����@  �F  �H���Ǘ��V�X�e��
	' ���W���[����  �F  ��M�f�[�^�ꗗ
	' ���W���[��ID�@�F  frmSYKD300.frm
	' �쐬���@ �@�@ �F  ���� 13 �N 07 �� 09 ��
	' �X�V���@�@  �@�F  ����    �N    ��    ��
	'=============================================================
	'
	'2021.08.10 UPGRADE S  AIT)vyhnt
	'Private Const RowHeight As Short = 15
	Private Const RowHeight As Short = 21
	'2021.08.10 UPGRADE E 
	Private himc As Integer
	'2021.11.05  UPGRADE S  AIT)hieutv
	'Public D300ShowMode As Short
	Public Shared D300ShowMode As Short
	'2021.11.05  UPGRADE E
	'

	'-------------------------------------------------------------------------------
	'   ����    :   �f�[�^�̃N���A
	'   �֐�    :   Sub DispClear()
	'   ����    :   �Ȃ�
	'   �@�\    :   �f�[�^���N���A���܂��B
	'-------------------------------------------------------------------------------
	Private Sub DispClear()

		'2021.08.02 UPGRADE S  AIT)vyhnt
		'vaSpread1.MaxRows = 0
		vaSpread1.ActiveSheet.RowCount = 0
		'2021.08.02 UPGRADE E  


		'----- �Q�ƃ��[�h
		If INPMODE <> "2" Then
			cmdKey(5).Enabled = False
			'2021.08.10 UPGRADE S  AIT)vyhnt
			cmdKey(5).Text = "  F5  �@"
			cmdKey(5).Text = "F5"
			cmdKey(8).Enabled = False
			'cmdKey(8).Text = "  F8  �@"
			cmdKey(8).Text = "F8"
			'2021.08.10 UPGRADE E   
		End If
		
	End Sub
	
	'-------------------------------------------------------------------------------
	'   ����    :   �e�L�X�g���̎擾
	'   �֐�    :   Function GetTextFile()
	'   ����    :   �Ȃ�
	'   �ߒl    :   True    ����I��
	'   �@�@    :   False   �ُ�I��
	'   �@�\    :   �e�L�X�g�t�@�C���̏����擾���܂��B
	'-------------------------------------------------------------------------------
	Private Function GetTextFile() As Boolean
		
		Dim wkPath As String
		Dim wkFile As String
		'2021.08.10 UPGRADE DEL  AIT)vyhnt
		'Dim lp As Integer
		'2021.08.10 DEL  E 
		Dim Cnt As Integer
		Dim DT() As KOUJI_NO_MAST_DBT
		
		'2021.07.26 UPGRADE S  AIT)Tool Convert
		'On Error GoTo FileErrD300
		Try
		'2021.07.26 UPGRADE E
		
		' �߂�l�̏�����
		GetTextFile = False
		
		' �����e�L�X�g�t�@�C�����̎擾
		wkPath = RECVPATH & "SYK_*.LZH"
		
		' �t�@�C�������擾
		Cnt = 0
			wkFile = Dir(wkPath, FileAttribute.Normal)
			'2021.08.03 UPGRADE S  AIT)vyhnt
			Do While Len(wkFile)
				'2021.08.03 UPGRADE E  
				ReDim Preserve DT(Cnt)
				Call CLEAR_KOUJI_NO_MAST(DT(Cnt))
				With DT(Cnt)
					.KOUJI_NO = Mid(wkFile, 6, 8) '�H���ԍ�
					.EDA_NO = Mid(wkFile, 14, 4) '�H���}��
					.MEISYOU = GetNameKouji(.KOUJI_NO, .EDA_NO) '�H������
					.GYOUSYU_KB = UCase(Mid(wkFile, 5, 1)) '���
				End With
				Cnt = Cnt + 1
				wkFile = Dir()
			Loop

			' �f�[�^�\��
			If Cnt <> 0 Then
				Call SprdDataSet(Cnt, DT)
			End If

			' ����I��
			GetTextFile = True
		Exit Function
		
		'2021.07.26 UPGRADE S  AIT)Tool Convert
		'FileErrD300:
		Catch ex As Exception
			'2021.07.26 UPGRADE E

			'----- �G���[����
			Call FileErrors(ex)

		End Try 	'2021.07.26 UPGRADE ADD AIT)Tool Convert
	End Function
	
	'-------------------------------------------------------------------------------
	'   ����    :   �X�v���b�h�\��
	'   �֐�    :   Sub SprdDataSet(DT())
	'   ����    :   Cnt     �f�[�^����
	'   �@�@    :   DT()    KOUJI_NO_MAST_DBT
	'   �@�\    :   �f�[�^���X�v���b�h�ɕ\�����܂��B
	'-------------------------------------------------------------------------------
	Private Sub SprdDataSet(ByRef Cnt As Integer, ByRef DT() As KOUJI_NO_MAST_DBT)
		
		Dim lp As Integer
		Dim Row As Integer
		Dim ssText As Object
		
		With vaSpread1
			If Me.Visible = True Then
				'2021.08.02 UPGRADE S  AIT)vyhnt
				'.ReDraw = False
				.ResumeLayout(False)
				'2021.08.02 UPGRADE E   

			End If
			'2021.08.02 UPGRADE S  AIT)vyhnt
			'2021.08.02 UPGRADE E   
			'.MaxRows = Cnt
			.ActiveSheet.RowCount = Cnt
			'.Row = 1 : .Row2 = .MaxRows
			'.Col = 1 : .Col2 = .MaxCols
			'.BlockMode = True
			'.Action = FPSpread.ActionConstants.ActionClearText
			.ActiveSheet.ClearRange(0, 0, .ActiveSheet.RowCount, .ActiveSheet.ColumnCount, True)
			'.BlockMode = False
			For lp = 0 To Cnt - 1
				'2021.08.02 UPGRADE S  AIT)vyhnt
				'.set_RowHeight(lp + 1, RowHeight)
				.ActiveSheet.SetRowHeight(lp, RowHeight)
				'2021.08.02 UPGRADE E   
				'Row = lp + 1
				Row = lp
				'----- CheckBox
				If KeyKouji.KOUJI_NO = DT(lp).KOUJI_NO And KeyKouji.EDA_NO = DT(lp).EDA_NO Then
					'2021.08.02 UPGRADE S  AIT)vyhnt
					'.SetText(1, Row, "1")
					.ActiveSheet.SetText(Row, 0, "1")
					'2021.08.02 UPGRADE E   
				Else
					'2021.08.02 UPGRADE S  AIT)vyhnt
					'.SetText(1, Row, "0")
					.ActiveSheet.SetText(Row, 0, "0")
					'2021.08.02 UPGRADE E   
				End If
				'----- �H���ԍ�
				ssText = Trim(DT(lp).KOUJI_NO)
				'2021.08.02 UPGRADE S  AIT)vyhnt
				'.SetText(2, Row, ssText)
				.ActiveSheet.SetText(Row, 1, ssText)
				'2021.08.02 UPGRADE E   
				'----- �}��
				ssText = Trim(DT(lp).EDA_NO)
				If ssText <> "0000" Then
					'2021.08.02 UPGRADE S  AIT)vyhnt
					'.SetText(3, Row, ssText)
					.ActiveSheet.SetText(Row, 2, ssText)
					'2021.08.02 UPGRADE E   
				End If
				'----- ����
				If Trim(DT(lp).MEISYOU) <> "" Then
					ssText = Trim(DT(lp).MEISYOU)
				Else
					ssText = "�V�K �H�����"
				End If
				'2021.08.02 UPGRADE S  AIT)vyhnt
				'.SetText(4, Row, ssText)
				.ActiveSheet.SetText(Row, 3, ssText)
				'2021.08.02 UPGRADE E   
				'----- �H���敪
				ssText = GetNameGyosyu(DT(lp).KOUJI_NO, DT(lp).EDA_NO)
				'2021.08.02 UPGRADE S  AIT)vyhnt
				'.SetText(5, Row, ssText)
				.ActiveSheet.SetText(Row, 4, ssText)
				'2021.08.02 UPGRADE E   
				'----- �m��
				Select Case Trim(DT(lp).GYOUSYU_KB)
					Case "K"
						ssText = "�m��"
					Case Else
						ssText = ""
				End Select
				'2021.08.02 UPGRADE S  AIT)vyhnt
				'.SetText(6, Row, ssText)
				.ActiveSheet.SetText(Row, 5, ssText)
				'2021.08.02 UPGRADE E   
			Next lp
			'2021.08.03 UPGRADE S  AIT)vyhnt
			'.Row = 1 : .Row2 = .MaxRows
			'.Col = 1 : .Col2 = .MaxCols
			'.BlockMode = True
			Dim sort(1) As FarPoint.Win.Spread.SortInfo
			'.SortBy = FPSpread.SortByConstants.SortByRow
			'.set_SortKey(1, 2)
			'.set_SortKeyOrder(1, FPSpread.SortKeyOrderConstants.SortKeyOrderAscending)		
			'.set_SortKey(2, 3)
			'.set_SortKeyOrder(2, FPSpread.SortKeyOrderConstants.SortKeyOrderAscending)
			'.Action = FPSpread.ActionConstants.ActionSort
			sort(0) = New FarPoint.Win.Spread.SortInfo(1, True, System.Collections.Comparer.Default)
			.ActiveSheet.SortRange(0, 0, .ActiveSheet.RowCount, .ActiveSheet.ColumnCount, True, sort)
			'.BlockMode = False
			'2021.08.03 UPGRADE E     
			If Me.Visible = True Then
				'2021.08.02 UPGRADE S  AIT)vyhnt
				'.CtlRefresh()
				'.ReDraw = True
				.Refresh()
				.ResumeLayout(True)
				'2021.08.02 UPGRADE E   
			End If
			'2021.08.11 UPGRADE ADD  AIT)vyhnt
			vaSpread1.ActiveSheet.AddSelection(0, 0, vaSpread1.ActiveSheet.RowCount, vaSpread1.ActiveSheet.ColumnCount)
			'2021.08.11 UPGRADE S  AIT)*** 
		End With
		
	End Sub
	
	'-------------------------------------------------------------------------------
	'   ����    :   �I���f�[�^�i�j�d�x�j�̎擾
	'   �֐�    :   Sub SprdDataGet(DT)
	'   ����    :   DT  KOUJI_NO_MAST_DBT
	'   �@�\    :   �I���f�[�^���X�v���b�h����擾���܂��B
	'-------------------------------------------------------------------------------
	Private Sub SprdDataGet(ByRef DT As KOUJI_NO_MAST_DBT)
		
		Dim ssText As Object

		With vaSpread1
			'2021.08.02 UPGRADE S  AIT)vyhnt
			'.GetText(2, .ActiveRow, ssText) '�H���ԍ�
			ssText = .ActiveSheet.GetText(.ActiveSheet.ActiveRowIndex, 1) '�H���ԍ�
			'2021.08.02 UPGRADE E  

			DT.KOUJI_NO = Trim(ssText)
			'2021.08.02 UPGRADE S  AIT)vyhnt
			'.GetText(3, .ActiveRow, ssText) '�}��
			ssText = .ActiveSheet.GetText(.ActiveSheet.ActiveRowIndex, 2) '�}��
			'2021.08.02 UPGRADE E  
			If Trim(ssText) = "" Then ssText = "0000"
			DT.EDA_NO = Trim(ssText)
		End With

	End Sub

	'2021.08.02 UPGRADE S  AIT)vyhnt
	'Private Sub cmdKey_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Click
	'	Dim Index As Short = cmdKey.GetIndex(eventSender)
	Private Sub cmdKey_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _cmdKey_1.Click, _cmdKey_2.Click, _cmdKey_3.Click, _cmdKey_4.Click, _cmdKey_5.Click, _cmdKey_6.Click,
																													_cmdKey_7.Click, _cmdKey_8.Click, _cmdKey_9.Click, _cmdKey_10.Click, _cmdKey_11.Click, _cmdKey_12.Click
		Dim Index As Short = cmdKey.IndexOf(eventSender)
		'2021.08.02 UPGRADE E   


		Dim ChkCnt As Short
		Dim lp As Integer
		Dim Pos As Integer
		Dim ssText As Object
		Dim KNo As String
		Dim ENo As String
		Dim KName As String
		Dim Syu As String
		Dim fName As String
		Dim Msg As String

		Select Case Index
			Case 5 '----- ���
				' �I���f�[�^�̃`�F�b�N
				ChkCnt = 0
				Pos = 0
				With vaSpread1
					'2021.08.02 UPGRADE S  AIT)vyhnt
					'For lp = 1 To .MaxRows
					'	.GetText(1, lp, ssText) ' CheckBox
					For lp = 1 To .ActiveSheet.RowCount
						ssText = .ActiveSheet.GetText(lp - 1, 0) ' CheckBox
						'2021.08.02 UPGRADE E   
						If ssText = "1" Then
							ChkCnt = ChkCnt + 1
							'2021.08.10 UPGRADE S  AIT)vyhnt
							'Pos = lp
							Pos = lp - 1
							'2021.08.10 UPGRADE E  
						End If
					Next lp
				End With
				If ChkCnt = 0 Then
					Msg = "�H����񂪑I������Ă�����B"
					'2021.09.14 UPGRADE S  AIT)dannnl
					'MsgBox(Msg, MsgBoxStyle.OkOnly + MsgBoxStyle.Information)
					MsgBox(Msg, MsgBoxStyle.OkOnly + MsgBoxStyle.Information, SYSTEMNM)
					'2021.09.14 UPGRADE E
					Exit Sub
				End If
				If ChkCnt > 1 Then
					Msg = "�����̍H�����͑I���ł��܂���B"
					'2021.09.14 UPGRADE S  AIT)dannnl
					'MsgBox(Msg, MsgBoxStyle.OkOnly + MsgBoxStyle.Information)
					MsgBox(Msg, MsgBoxStyle.OkOnly + MsgBoxStyle.Information, SYSTEMNM)
					'2021.09.14 UPGRADE E
					Exit Sub
				End If
				' �V�K �H�����̃`�F�b�N
				With vaSpread1
					'----- �H���ԍ�
					'2021.08.02 UPGRADE S  AIT)vyhnt
					'.GetText(2, Pos, ssText)
					ssText = .ActiveSheet.GetText(Pos, 1)
					'2021.08.02 UPGRADE E   

					KNo = Trim(ssText)
					'----- �}��
					'2021.08.02 UPGRADE S  AIT)vyhnt
					'2021.08.02 UPGRADE E   
					'.GetText(3, Pos, ssText)
					ssText = .ActiveSheet.GetText(Pos, 2)
					ENo = Trim(ssText)
					If ENo = "" Then ENo = "0000"
					'----- �H������
					'2021.08.02 UPGRADE S  AIT)vyhnt
					'2021.08.02 UPGRADE E   
					'.GetText(4, Pos, ssText)
					ssText = .ActiveSheet.GetText(Pos, 3)
					KName = Trim(ssText)
					'----- ���
					'2021.08.02 UPGRADE S  AIT)vyhnt
					'2021.08.02 UPGRADE E   
					'.GetText(6, Pos, ssText)
					ssText = .ActiveSheet.GetText(Pos, 5)
					Syu = Trim(ssText)
				End With
				If Syu = "�m��" Then
					fName = "SYK_K" & KNo & ENo & ".LZH"
				Else
					fName = "SYK_N" & KNo & ENo & ".LZH"
				End If
				If D300ShowMode = 1 Then ' �V�K �H�����̓o�^
					If Syu = "�m��" Then
						Msg = "�m��f�[�^�͐V�K�̍H�����Ƃ��đI���ł��܂���B"
						'2021.09.14 UPGRADE S  AIT)dannnl
						'MsgBox(Msg, MsgBoxStyle.OkOnly + MsgBoxStyle.Information)
						MsgBox(Msg, MsgBoxStyle.OkOnly + MsgBoxStyle.Information, SYSTEMNM)
						'2021.09.14 UPGRADE E
						Exit Sub
					End If
					If Trim(KName) = "�V�K �H�����" Then
						Msg = "�V�K�ɍH�������󂯎��܂��B��낵���ł����H"
						'2021.09.14 UPGRADE S  AIT)dannnl
						'If MsgBox(Msg, MsgBoxStyle.YesNo + MsgBoxStyle.Information) = MsgBoxResult.No Then
						If MsgBox(Msg, MsgBoxStyle.YesNo + MsgBoxStyle.Information, SYSTEMNM) = MsgBoxResult.No Then
						'2021.09.14 UPGRADE E
							Exit Sub
						End If
						'----- �V�K�H�����ǂݍ���
						Call DDataUpdate(KNo, ENo, fName, 0)
					Else
						Msg = "�V�K�̍H�����͑I���ł��܂���B"
						'2021.09.14 UPGRADE S  AIT)dannnl
						'MsgBox(Msg, MsgBoxStyle.OkOnly + MsgBoxStyle.Information)
						MsgBox(Msg, MsgBoxStyle.OkOnly + MsgBoxStyle.Information, SYSTEMNM)
						'2021.09.14 UPGRADE E
						Exit Sub
					End If
				Else ' �o���f�[�^���m�茎��f�[�^�̎��
					If Trim(KName) = "�V�K �H�����" Then
						Msg = "�V�K�̍H�����͑I���ł��܂���B"
						'2021.09.14 UPGRADE S  AIT)dannnl
						'MsgBox(Msg, MsgBoxStyle.OkOnly + MsgBoxStyle.Information)
						MsgBox(Msg, MsgBoxStyle.OkOnly + MsgBoxStyle.Information, SYSTEMNM)
						'2021.09.14 UPGRADE E
						Exit Sub
					End If
					' ���݂̑I���H�������`�F�b�N
					If KNo = KeyKouji.KOUJI_NO And ENo = KeyKouji.EDA_NO Then
						If Syu = "�m��" Then
							'----- ���݂̏�����Ԃ��m�F
							Select Case CtlKouji.R_FLG_TUKISIME
								Case "0" '0:�����O
								Case "1" '1:������
									Msg = "���ɓǂݍ��܂�Ă��܂��B�y" & VB.Left(CtlKouji.SYORI_YM, 4) & "/" & VB.Right(CtlKouji.SYORI_YM, 2) & "�z"
									Msg = Msg & vbCrLf & vbCrLf
									Msg = Msg & "�����I�Ɋm�茎��f�[�^��ǂ݂��݂܂����H"
									'2021.09.14 UPGRADE S  AIT)dannnl
									'If MsgBox(Msg, MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2 + MsgBoxStyle.Information) = MsgBoxResult.No Then
									If MsgBox(Msg, MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2 + MsgBoxStyle.Information, SYSTEMNM) = MsgBoxResult.No Then
									'2021.09.14 UPGRADE E
										Exit Sub
									End If
								Case "2" '1:������
									Msg = "������������Ă��܂��B�y" & VB.Left(CtlKouji.SYORI_YM, 4) & "/" & VB.Right(CtlKouji.SYORI_YM, 2) & "�z"
									Msg = Msg & vbCrLf & vbCrLf
									Msg = Msg & "�����I�Ɋm�茎��f�[�^��ǂ݂��݂܂����H"
									'2021.09.14 UPGRADE S  AIT)dannnl
									'If MsgBox(Msg, MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2 + MsgBoxStyle.Information) = MsgBoxResult.No Then
									If MsgBox(Msg, MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2 + MsgBoxStyle.Information, SYSTEMNM) = MsgBoxResult.No Then
									'2021.09.14 UPGRADE E
										Exit Sub
									End If
							End Select
							'----- �m��H�����ǂݍ���
							Call DDataUpdate(KNo, ENo, fName, 2)
						Else
							'----- ���݂̏�����Ԃ��m�F
							Select Case CtlKouji.R_FLG_KEIRI
								Case "0" '0:���O
								Case "1" '1:������
									Msg = "���ɓǂݍ��܂�Ă��܂��B�y" & VB.Left(CtlKouji.SYORI_YM, 4) & "/" & VB.Right(CtlKouji.SYORI_YM, 2) & "�z"
									Msg = Msg & vbCrLf & vbCrLf
									Msg = Msg & "�����I�Ɍo���f�[�^��ǂ݂��݂܂����H"
									'2021.09.14 UPGRADE S  AIT)dannnl
									'If MsgBox(Msg, MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2 + MsgBoxStyle.Information) = MsgBoxResult.No Then
									If MsgBox(Msg, MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2 + MsgBoxStyle.Information, SYSTEMNM) = MsgBoxResult.No Then
									'2021.09.14 UPGRADE E
										Exit Sub
									End If
								Case "2" '1:����
									Msg = "�o���f�[�^��揈������Ă��܂��B�y" & VB.Left(CtlKouji.SYORI_YM, 4) & "/" & VB.Right(CtlKouji.SYORI_YM, 2) & "�z"
									Msg = Msg & vbCrLf & vbCrLf
									Msg = Msg & "�����I�Ɍo���f�[�^��ǂ݂��݂܂����H"
									'2021.09.14 UPGRADE S  AIT)dannnl
									'If MsgBox(Msg, MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2 + MsgBoxStyle.Information) = MsgBoxResult.No Then
									If MsgBox(Msg, MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2 + MsgBoxStyle.Information, SYSTEMNM) = MsgBoxResult.No Then
									'2021.09.14 UPGRADE E
										Exit Sub
									End If
							End Select
							'----- �o�����H�����ǂݍ���
							Call DDataUpdate(KNo, ENo, fName, 1)
						End If
					Else
						Msg = "���݁A�������Ă���H���ԍ��ł͂���܂���B"
						'2021.09.14 UPGRADE S  AIT)dannnl
						'MsgBox(Msg, MsgBoxStyle.OkOnly + MsgBoxStyle.Information)
						MsgBox(Msg, MsgBoxStyle.OkOnly + MsgBoxStyle.Information, SYSTEMNM)
						'2021.09.14 UPGRADE E
						Exit Sub
					End If
				End If
				' �����\��
				Call DispClear()
				Call GetTextFile()

			Case 8 '----- �e�c����

				Call MtyTool.LostFocus(cmdKey(Index), StatusBar1)
				frmSYKD301.ShowDialog()
				' �����\��
				'2021.08.19 UPGRADE ADD  AIT)vyhnt
				Call MtyTool.GotFocus(cmdKey(Index), StatusBar1)
				Call DispClear()
				Call GetTextFile()
				'2021.08.19  ADD E
			Case 12 '----- �I��
				If D300ShowMode = 0 Then frmSYKD010.Show()
				'2021.08.19 UPGRADE S  AIT)
				'Me.Close()
				Me.Dispose()
				'2021.08.19 UPGRADE S  AIT)
		End Select

	End Sub

	'2021.08.02 UPGRADE S  AIT)vyhnt
	'Private Sub cmdKey_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Enter
	'	Dim Index As Short = cmdKey.GetIndex(eventSender)
	'	Call GotFocus(cmdKey(Index), StatusBar1)
	Private Sub cmdKey_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _cmdKey_1.Enter, _cmdKey_2.Enter, _cmdKey_3.Enter, _cmdKey_4.Enter, _cmdKey_5.Enter, _cmdKey_6.Enter,
																												_cmdKey_7.Enter, _cmdKey_8.Enter, _cmdKey_9.Enter, _cmdKey_10.Enter, _cmdKey_11.Enter, _cmdKey_12.Enter
		Dim Index As Short = cmdKey.IndexOf(eventSender)
		Call MtyTool.GotFocus(cmdKey(Index), StatusBar1)
		'2021.08.02 UPGRADE E  

	End Sub

	'2021.08.02 UPGRADE S  AIT)vyhnt
	'Private Sub cmdKey_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Leave
	'	Dim Index As Short = cmdKey.GetIndex(eventSender)
	'	Call LostFocus(cmdKey(Index), StatusBar1)
	'End Sub
	Private Sub cmdKey_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _cmdKey_1.Leave, _cmdKey_2.Leave, _cmdKey_3.Leave, _cmdKey_4.Leave, _cmdKey_5.Leave, _cmdKey_6.Leave,
																												_cmdKey_7.Leave, _cmdKey_8.Leave, _cmdKey_9.Leave, _cmdKey_10.Leave, _cmdKey_11.Leave, _cmdKey_12.Leave
		Dim Index As Short = cmdKey.IndexOf(eventSender)
		Call MtyTool.LostFocus(cmdKey(Index), StatusBar1)
	End Sub
	'2021.08.02 UPGRADE E  


	Private Sub frmSYKD300_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown
		Dim KeyCode As Short = eventArgs.KeyCode
		Dim Shift As Short = eventArgs.KeyData \ &H10000
		Select Case KeyCode
			Case System.Windows.Forms.Keys.F1
				If cmdKey(1).Enabled = True Then cmdKey(1).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(1), New System.EventArgs())
			Case System.Windows.Forms.Keys.F2
				If cmdKey(2).Enabled = True Then cmdKey(2).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(2), New System.EventArgs())
			Case System.Windows.Forms.Keys.F3
				If cmdKey(3).Enabled = True Then cmdKey(3).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(3), New System.EventArgs())
			Case System.Windows.Forms.Keys.F4
				If cmdKey(4).Enabled = True Then cmdKey(4).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(4), New System.EventArgs())
			Case System.Windows.Forms.Keys.F5
				If cmdKey(5).Enabled = True Then cmdKey(5).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(5), New System.EventArgs())
			Case System.Windows.Forms.Keys.F6
				If cmdKey(6).Enabled = True Then cmdKey(6).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(6), New System.EventArgs())
			Case System.Windows.Forms.Keys.F7
				If cmdKey(7).Enabled = True Then cmdKey(7).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(7), New System.EventArgs())
			Case System.Windows.Forms.Keys.F8
				If cmdKey(8).Enabled = True Then cmdKey(8).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(8), New System.EventArgs())
			Case System.Windows.Forms.Keys.F9
				If cmdKey(9).Enabled = True Then cmdKey(9).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(9), New System.EventArgs())
			Case System.Windows.Forms.Keys.F10
				If cmdKey(10).Enabled = True Then cmdKey(10).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(10), New System.EventArgs())
			Case System.Windows.Forms.Keys.F11
				If cmdKey(11).Enabled = True Then cmdKey(11).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(11), New System.EventArgs())
			Case System.Windows.Forms.Keys.F12
				If cmdKey(12).Enabled = True Then cmdKey(12).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(12), New System.EventArgs())
		End Select
	End Sub
	
	Private Sub frmSYKD300_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
		
		Call FormDisp(Me)

		'�X�v���b�h��IME�N���n�e�e
		'2021.08.02 UPGRADE S  AIT)vyhnt
		'himc = ImmGetContext(vaSpread1.hWnd)
		himc = ImmGetContext(vaSpread1.Handle)
		'2021.08.02 UPGRADE E  

		' �����\��
		Call DispClear()
		Call GetTextFile()
		
	End Sub
	
	Private Sub frmSYKD300_FormClosing(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
		Dim Cancel As Boolean = eventArgs.Cancel
		Dim UnloadMode As System.Windows.Forms.CloseReason = eventArgs.CloseReason
		If UnloadMode = System.Windows.Forms.CloseReason.UserClosing Then
			frmSYKD010.Show()
		End If
		eventArgs.Cancel = Cancel
	End Sub
	'2021.08.03 UPGRADE S  AIT)vyhnt
	'Private Sub vaSpread1_ClickEvent(ByVal eventSender As System.Object, ByVal eventArgs As AxFPSpread._DSpreadEvents_ClickEvent) Handles vaSpread1.ClickEvent
	Private Sub vaSpread1_ClickEvent(ByVal eventSender As System.Object, ByVal eventArgs As FarPoint.Win.Spread.CellClickEventArgs) Handles vaSpread1.CellClick

		'2021.08.03 UPGRADE E      
		Dim lp As Integer
		Dim ssText As Object
		'2021.08.03 UPGRADE S  AIT)vyhnt

		'If EventArgs.col = 1 Then
		'	With vaSpread1
		'		If EventArgs.row = 0 Then
		'2021.08.05  UPGRADE S  AIT)***   
		If eventArgs.Column = 0 Then
			With vaSpread1
				If eventArgs.ColumnHeader = True AndAlso eventArgs.RowHeader = False Then
					'2021.08.03 UPGRADE E      
					' �S�I��
					'2021.08.02 UPGRADE S  AIT)vyhnt
					'For lp = 1 To .MaxRows
					'	.GetText(1, lp, ssText)
					For lp = 1 To .ActiveSheet.RowCount
						ssText = .ActiveSheet.GetText(lp - 1, 0)
						'2021.08.02 UPGRADE E   
						If ssText = "1" Then Exit For
					Next lp
					If ssText = "1" Then
						ssText = "0"
					Else
						ssText = "1"
					End If
					'2021.08.03 UPGRADE S  AIT)vyhnt
					'2021.08.03 UPGRADE E      
					'	For lp = 1 To .MaxRows
					'		.eventArgs.Col = EventArgs.col : .eventArgs.Row = lp
					'		.Text = ssText
					'	Next lp
					'Else
					'	.eventArgs.Col = EventArgs.col : .eventArgs.Row = EventArgs.row
					For lp = 1 To .ActiveSheet.RowCount
						'.eventArgs.Col = EventArgs.col : .eventArgs.Row = lp
						.ActiveSheet.Cells(lp - 1, 0).Text = ssText
					Next lp
				ElseIf eventArgs.ColumnHeader = False AndAlso eventArgs.RowHeader = False Then
					'2021.08.10 UPGRADE S  AIT)vyhnt
					'.eventArgs.Col = EventArgs.col : .eventArgs.Row = EventArgs.row
					'If .Text = "0" Then .Text = "1" Else .Text = "0"
					If .ActiveSheet.Cells(eventArgs.Row, 0).Text = "0" Then
						.ActiveSheet.Cells(eventArgs.Row, 0).Text = "1"
					Else
						.ActiveSheet.Cells(eventArgs.Row, 0).Text = "0"
					End If
					'2021.08.10 UPGRADE E 
				End If
			End With
		End If
	End Sub

	Private Sub vaSpread1_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles vaSpread1.Enter
		'2021.08.02 UPGRADE S  AIT)vyhnt
		'Call GotFocus(vaSpread1, StatusBar1)
		Call MtyTool.GotFocus(vaSpread1, StatusBar1)
		'2021.08.02 UPGRADE E  

		ImmSetOpenStatus(himc, False)
	End Sub

	'2021.08.03 UPGRADE S  AIT)vyhnt
	'Private Sub vaSpread1_KeyDownEvent(ByVal eventSender As System.Object, ByVal eventArgs As AxFPSpread._DSpreadEvents_KeyDownEvent) Handles vaSpread1.KeyDownEvent
	'	If eventArgs.keyCode = System.Windows.Forms.Keys.Space Then
	'		Call vaSpread1_ClickEvent(vaSpread1, New AxFPSpread._DSpreadEvents_ClickEvent(1, vaSpread1.ActiveRow))
	Private Sub vaSpread1_KeyDownEvent(ByVal eventSender As System.Object, ByVal eventArgs As KeyEventArgs) Handles vaSpread1.KeyDown
		If eventArgs.KeyCode = System.Windows.Forms.Keys.Space Then
			Call vaSpread1_ClickEvent(vaSpread1, New FarPoint.Win.Spread.CellClickEventArgs(
										vaSpread1.GetRootWorkbook, vaSpread1.ActiveSheet.ActiveRow.Index, 0, 1, 1, New MouseButtons, False, False))
			'2021.08.03 UPGRADE E      
		End If
	End Sub

	Private Sub vaSpread1_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles vaSpread1.Leave
		'2021.08.02 UPGRADE S  AIT)vyhnt
		'Call LostFocus(vaSpread1, StatusBar1)
		Call MtyTool.LostFocus(vaSpread1, StatusBar1)
		'2021.08.02 UPGRADE E  

	End Sub
End Class
