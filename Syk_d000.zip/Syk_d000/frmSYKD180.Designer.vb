Imports GrapeCity.Win.Editors

<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frmSYKD180
#Region "Windows Form Designer generated code "
    <System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
        MyBase.New()
        'This call is required by the Windows Form Designer.
        InitializeComponent()
        '2021.08.11 UPGRADE ADD S AIT)hieutv
        Frame1 = New ArrayList()
        Frame1.Add(_Frame1_0)
        Frame1.Add(_Frame1_1)
        Frame1.Add(_Frame1_2)

        Label1 = New ArrayList
        Label1.Add(_Label1_0)
        Label1.Add(_Label1_1)
        Label1.Add(_Label1_2)
        Label1.Add(_Label1_3)
        Label1.Add(_Label1_4)
        Label1.Add(_Label1_5)
        Label1.Add(_Label1_6)
        Label1.Add(_Label1_7)
        Label1.Add(_Label1_8)
        Label1.Add(_Label1_9)
        Label1.Add(_Label1_10)
        Label1.Add(_Label1_11)
        Label1.Add(_Label1_12)
        Label1.Add(_Label1_13)
        Label1.Add(_Label1_14)
        Label1.Add(_Label1_15)
        Label1.Add(_Label1_16)
        Label1.Add(_Label1_17)
        Label1.Add(_Label1_18)
        Label1.Add(_Label1_19)
        Label1.Add(_Label1_20)

        Picture2 = New ArrayList
        Picture2.Add(_Picture2_0)
        Picture2.Add(_Picture2_1)

        cmdKey = New ArrayList
        cmdKey.Add(Nothing)
        cmdKey.Add(_cmdKey_1)
        cmdKey.Add(_cmdKey_2)
        cmdKey.Add(_cmdKey_3)
        cmdKey.Add(_cmdKey_4)
        cmdKey.Add(_cmdKey_5)
        cmdKey.Add(_cmdKey_6)
        cmdKey.Add(_cmdKey_7)
        cmdKey.Add(_cmdKey_8)
        cmdKey.Add(_cmdKey_9)
        cmdKey.Add(_cmdKey_10)
        cmdKey.Add(_cmdKey_11)
        cmdKey.Add(_cmdKey_12)

        ctlGeppo1 = New ArrayList
        ctlGeppo1.Add(_ctlGeppo1_0)
        ctlGeppo1.Add(_ctlGeppo1_1)
        ctlGeppo1.Add(_ctlGeppo1_2)

        imDate1 = New ArrayList
        imDate1.Add(_imDate1_0)
        imDate1.Add(_imDate1_1)
        imDate1.Add(_imDate1_2)

        imNumber1 = New ArrayList
        imNumber1.Add(_imNumber1_0)
        imNumber1.Add(_imNumber1_1)

        imNumber2 = New ArrayList
        imNumber2.Add(_imNumber2_0)
        imNumber2.Add(_imNumber2_1)
        imNumber2.Add(_imNumber2_2)
        imNumber2.Add(_imNumber2_3)

        imText1 = New ArrayList
        imText1.Add(_imText1_0)
        imText1.Add(_imText1_1)

        imText2 = New ArrayList
        imText2.Add(_imText2_0)
        imText2.Add(_imText2_1)
        imText2.Add(_imText2_2)

        imText3 = New ArrayList
        imText3.Add(_imText3_0)
        imText3.Add(_imText3_1)
        imText3.Add(_imText3_2)

        imText4 = New ArrayList
        imText4.Add(Nothing)
        imText4.Add(Nothing)
        imText4.Add(_imText4_2)
        imText4.Add(_imText4_3)

        imText5 = New ArrayList
        imText5.Add(_imText5_0)
        imText5.Add(_imText5_1)
        imText5.Add(_imText5_2)
        imText5.Add(_imText5_3)

        imText6 = New ArrayList
        imText6.Add(_imText6_0)
        imText6.Add(_imText6_1)
        imText6.Add(_imText6_2)
        imText6.Add(Nothing)
        imText6.Add(_imText6_4)
        imText6.Add(_imText6_5)

        imText7 = New ArrayList
        imText7.Add(_imText7_0)
        imText7.Add(_imText7_1)
        '2021.08.11 UPGRADE ADD E
    End Sub
    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
        If Disposing Then
            If Not components Is Nothing Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(Disposing)
    End Sub
    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer
    Public ToolTip1 As System.Windows.Forms.ToolTip
    Public WithEvents Check1 As System.Windows.Forms.CheckBox
    Public WithEvents _Label1_20 As System.Windows.Forms.Label
    Public WithEvents Picture3 As System.Windows.Forms.Panel
    '2021.08.11 UPGRADE S  AIT)hieutv
    'Public WithEvents _imText6_0 As imText6.imText
    'Public WithEvents _imText7_0 As imText6.imText
    'Public WithEvents _imText6_1 As imText6.imText
    'Public WithEvents _imText6_2 As imText6.imText
    'Public WithEvents _imText6_4 As imText6.imText
    'Public WithEvents _imText6_5 As imText6.imText
    'Public WithEvents _imText7_1 As imText6.imText
    'Public WithEvents _imNumber2_0 As imNumber6.imNumber
    'Public WithEvents _imNumber2_1 As imNumber6.imNumber
    'Public WithEvents _imNumber2_2 As imNumber6.imNumber
    'Public WithEvents _imNumber2_3 As imNumber6.imNumber
    Public WithEvents _imText6_0 As GcTextBox
    Public WithEvents _imText7_0 As GcTextBox
    Public WithEvents _imText6_1 As GcTextBox
    Public WithEvents _imText6_2 As GcTextBox
    Public WithEvents _imText6_4 As GcTextBox
    Public WithEvents _imText6_5 As GcTextBox
    Public WithEvents _imText7_1 As GcTextBox
    Public WithEvents _imNumber2_0 As GcNumber
    Public WithEvents _imNumber2_1 As GcNumber
    Public WithEvents _imNumber2_2 As GcNumber
    Public WithEvents _imNumber2_3 As GcNumber
    '2021.08.11 UPGRADE E
    Public WithEvents _Label1_15 As System.Windows.Forms.Label
    Public WithEvents _Label1_13 As System.Windows.Forms.Label
    Public WithEvents _Label1_14 As System.Windows.Forms.Label
    Public WithEvents _Label1_12 As System.Windows.Forms.Label
    Public WithEvents _Label1_10 As System.Windows.Forms.Label
    Public WithEvents _Label1_11 As System.Windows.Forms.Label
    Public WithEvents _Label1_9 As System.Windows.Forms.Label
    Public WithEvents _Label1_8 As System.Windows.Forms.Label
    Public WithEvents _Label1_7 As System.Windows.Forms.Label
    Public WithEvents _Frame1_2 As System.Windows.Forms.GroupBox
    Public WithEvents VScroll1 As System.Windows.Forms.VScrollBar
    '2021.08.11 UPGRADE S  AIT)hieutv
    'Public WithEvents _imText3_2 As imText6.imText
    'Public WithEvents _imText5_2 As imText6.imText
    'Public WithEvents _imText5_3 As imText6.imText
    'Public WithEvents _imText5_0 As imText6.imText
    'Public WithEvents _imText5_1 As imText6.imText
    Public WithEvents _imText3_2 As GcTextBox
    Public WithEvents _imText5_2 As GcTextBox
    Public WithEvents _imText5_3 As GcTextBox
    Public WithEvents _imText5_0 As GcTextBox
    Public WithEvents _imText5_1 As GcTextBox
    Public WithEvents _Picture2_1 As System.Windows.Forms.Panel
    'Public WithEvents _imText3_1 As imText6.imText
    'Public WithEvents _imText4_2 As imText6.imText
    'Public WithEvents _imNumber1_0 As imNumber6.imNumber
    'Public WithEvents _imNumber1_1 As imNumber6.imNumber
    'Public WithEvents _imText4_3 As imText6.imText
    Public WithEvents _imText3_1 As GcTextBox
    Public WithEvents _imText4_2 As GcTextBox
    Public WithEvents _imNumber1_0 As GcNumber
    Public WithEvents _imNumber1_1 As GcNumber
    Public WithEvents _imText4_3 As GcTextBox
    '2021.08.11 UPGRADE E
    Public WithEvents _Picture2_0 As System.Windows.Forms.Panel
    Public WithEvents _ctlGeppo1_0 As ctlGeppo
    Public WithEvents _ctlGeppo1_1 As ctlGeppo
    Public WithEvents _ctlGeppo1_2 As ctlGeppo
    Public WithEvents _Label1_6 As System.Windows.Forms.Label
    Public WithEvents _Label1_5 As System.Windows.Forms.Label
    Public WithEvents _Label1_4 As System.Windows.Forms.Label
    Public WithEvents _Label1_1 As System.Windows.Forms.Label
    Public WithEvents _Label1_3 As System.Windows.Forms.Label
    Public WithEvents _Label1_2 As System.Windows.Forms.Label
    Public WithEvents _Frame1_0 As System.Windows.Forms.GroupBox
    Public WithEvents _cmdKey_3 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_12 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_4 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_10 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_6 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_7 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_8 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_9 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_1 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_11 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_2 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_5 As System.Windows.Forms.Button
    Public WithEvents Picture1 As System.Windows.Forms.Panel
    Public WithEvents _StatusBar1_Panel1 As System.Windows.Forms.ToolStripStatusLabel
    Public WithEvents Message As System.Windows.Forms.ToolStripStatusLabel
    Public WithEvents StatusBar1 As System.Windows.Forms.StatusStrip
    '2021.08.11 UPGRADE S  AIT)hieutv
    'Public WithEvents _imText2_2 As imText6.imText
    'Public WithEvents _imText2_0 As imText6.imText
    'Public WithEvents _imText2_1 As imText6.imText
    'Public WithEvents vaSpread1 As AxFPSpread.AxvaSpread
    'Public WithEvents vaSpread2 As AxFPSpread.AxvaSpread
    'Public WithEvents _imText3_0 As imText6.imText
    'Public WithEvents _imText1_0 As imText6.imText
    'Public WithEvents _imDate1_0 As imDate6.imDate
    'Public WithEvents _imDate1_1 As imDate6.imDate
    'Public WithEvents _imDate1_2 As imDate6.imDate
    'Public WithEvents _imText1_1 As imText6.imText
    Public WithEvents _imText2_2 As GcTextBox
    Public WithEvents _imText2_0 As GcTextBox
    Public WithEvents _imText2_1 As GcTextBox
    Public WithEvents _imText3_0 As GcTextBox
    Public WithEvents _imText1_0 As GcTextBox
    Public WithEvents _imDate1_0 As GcDate
    Public WithEvents _imDate1_1 As GcDate
    Public WithEvents _imDate1_2 As GcDate
    Public WithEvents _imText1_1 As GcTextBox
    '2021.08.11 UPGRADE E
    Public WithEvents _Label1_19 As System.Windows.Forms.Label
    Public WithEvents _Label1_17 As System.Windows.Forms.Label
    Public WithEvents _Label1_16 As System.Windows.Forms.Label
    Public WithEvents _Label1_18 As System.Windows.Forms.Label
    Public WithEvents _Frame1_1 As System.Windows.Forms.GroupBox
    Public WithEvents _Label1_0 As System.Windows.Forms.Label
    Public WithEvents lblTitle As System.Windows.Forms.Label
    '2021.08.11 UPGRADE S  AIT)hieutv
    'Public WithEvents Frame1 As Microsoft.VisualBasic.Compatibility.VB6.GroupBoxArray
    'Public WithEvents Label1 As Microsoft.VisualBasic.Compatibility.VB6.LabelArray
    'Public WithEvents Picture2 As Microsoft.VisualBasic.Compatibility.VB6.PanelArray
    'Public WithEvents cmdKey As Microsoft.VisualBasic.Compatibility.VB6.ButtonArray
    'Public WithEvents ctlGeppo1 As ctlGeppoArray
    'Public WithEvents imDate1 As imDateArray
    'Public WithEvents imNumber1 As imNumberArray
    'Public WithEvents imNumber2 As imNumberArray
    'Public WithEvents imText1 As imTextArray
    'Public WithEvents imText2 As imTextArray
    'Public WithEvents imText3 As imTextArray
    'Public WithEvents imText4 As imTextArray
    'Public WithEvents imText5 As imTextArray
    'Public WithEvents imText6 As imTextArray
    'Public WithEvents imText7 As imTextArray
    Public WithEvents Frame1 As ArrayList
    Public WithEvents Label1 As ArrayList
    Public WithEvents Picture2 As ArrayList
    Public WithEvents cmdKey As ArrayList
    Public WithEvents ctlGeppo1 As ArrayList
    Public WithEvents imDate1 As ArrayList
    Public WithEvents imNumber1 As ArrayList
    Public WithEvents imNumber2 As ArrayList
    Public WithEvents imText1 As ArrayList
    Public WithEvents imText2 As ArrayList
    Public WithEvents imText3 As ArrayList
    Public WithEvents imText4 As ArrayList
    Public WithEvents imText5 As ArrayList
    Public WithEvents imText6 As ArrayList
    Public WithEvents imText7 As ArrayList
    '2021.08.11 UPGRADE E

    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim CustomSpdHeader As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim CustomSpdHeader1 As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim CustomSpdHeader2 As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim CustomSpdHeader3 As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim CustomSpdHeader4 As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim CustomSpdHeader5 As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim CustomSpdHeader6 As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim CustomSpdHeader7 As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim CustomSpdHeader8 As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim CustomSpdHeader9 As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim CustomSpdHeader10 As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim CustomSpdHeader11 As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim CustomSpdHeader12 As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim CustomSpdHeader13 As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim CustomSpdHeader14 As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim NumberSignDisplayField1 As GrapeCity.Win.Editors.Fields.NumberSignDisplayField = New GrapeCity.Win.Editors.Fields.NumberSignDisplayField()
        Dim NumberIntegerPartDisplayField1 As GrapeCity.Win.Editors.Fields.NumberIntegerPartDisplayField = New GrapeCity.Win.Editors.Fields.NumberIntegerPartDisplayField()
        Dim NumberDecimalSeparatorDisplayField1 As GrapeCity.Win.Editors.Fields.NumberDecimalSeparatorDisplayField = New GrapeCity.Win.Editors.Fields.NumberDecimalSeparatorDisplayField()
        Dim NumberDecimalPartDisplayField1 As GrapeCity.Win.Editors.Fields.NumberDecimalPartDisplayField = New GrapeCity.Win.Editors.Fields.NumberDecimalPartDisplayField()
        Dim DateYearField1 As GrapeCity.Win.Editors.Fields.DateYearField = New GrapeCity.Win.Editors.Fields.DateYearField()
        Dim DateLiteralField1 As GrapeCity.Win.Editors.Fields.DateLiteralField = New GrapeCity.Win.Editors.Fields.DateLiteralField()
        Dim DateMonthField1 As GrapeCity.Win.Editors.Fields.DateMonthField = New GrapeCity.Win.Editors.Fields.DateMonthField()
        Dim DateLiteralField2 As GrapeCity.Win.Editors.Fields.DateLiteralField = New GrapeCity.Win.Editors.Fields.DateLiteralField()
        Dim DateDayField1 As GrapeCity.Win.Editors.Fields.DateDayField = New GrapeCity.Win.Editors.Fields.DateDayField()
        Dim DateYearField2 As GrapeCity.Win.Editors.Fields.DateYearField = New GrapeCity.Win.Editors.Fields.DateYearField()
        Dim DateLiteralField3 As GrapeCity.Win.Editors.Fields.DateLiteralField = New GrapeCity.Win.Editors.Fields.DateLiteralField()
        Dim DateMonthField2 As GrapeCity.Win.Editors.Fields.DateMonthField = New GrapeCity.Win.Editors.Fields.DateMonthField()
        Dim DateLiteralField4 As GrapeCity.Win.Editors.Fields.DateLiteralField = New GrapeCity.Win.Editors.Fields.DateLiteralField()
        Dim DateDayField2 As GrapeCity.Win.Editors.Fields.DateDayField = New GrapeCity.Win.Editors.Fields.DateDayField()
        Dim DateYearField3 As GrapeCity.Win.Editors.Fields.DateYearField = New GrapeCity.Win.Editors.Fields.DateYearField()
        Dim DateLiteralField5 As GrapeCity.Win.Editors.Fields.DateLiteralField = New GrapeCity.Win.Editors.Fields.DateLiteralField()
        Dim DateMonthField3 As GrapeCity.Win.Editors.Fields.DateMonthField = New GrapeCity.Win.Editors.Fields.DateMonthField()
        Dim DateLiteralField6 As GrapeCity.Win.Editors.Fields.DateLiteralField = New GrapeCity.Win.Editors.Fields.DateLiteralField()
        Dim DateDayField3 As GrapeCity.Win.Editors.Fields.DateDayField = New GrapeCity.Win.Editors.Fields.DateDayField()
        Dim DefaultFocusIndicatorRenderer1 As FarPoint.Win.Spread.DefaultFocusIndicatorRenderer = New FarPoint.Win.Spread.DefaultFocusIndicatorRenderer()
        Dim DefaultScrollBarRenderer1 As FarPoint.Win.Spread.DefaultScrollBarRenderer = New FarPoint.Win.Spread.DefaultScrollBarRenderer()
        Dim NamedStyle1 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("Color65637643599430503617")
        Dim NamedStyle2 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("Font193637643599430513598")
        Dim NamedStyle3 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("BorderEx688637643599430533607")
        Dim ComplexBorder1 As FarPoint.Win.ComplexBorder = New FarPoint.Win.ComplexBorder(New FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.None), New FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.None), New FarPoint.Win.ComplexBorderSide(System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))), New FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.None), New FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.None), False, False)
        Dim NamedStyle4 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("BorderEx785637643599430543601")
        Dim TipAppearance1 As FarPoint.Win.Spread.TipAppearance = New FarPoint.Win.Spread.TipAppearance()
        Dim DefaultScrollBarRenderer2 As FarPoint.Win.Spread.DefaultScrollBarRenderer = New FarPoint.Win.Spread.DefaultScrollBarRenderer()
        Dim TextCellType1 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType()
        Dim ComplexBorder2 As FarPoint.Win.ComplexBorder = New FarPoint.Win.ComplexBorder(New FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThinLine))
        Dim TextCellType2 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType()
        Dim TextCellType3 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType()
        Dim TextCellType4 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType()
        Dim TextCellType5 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType()
        Dim DefaultScrollBarRenderer3 As FarPoint.Win.Spread.DefaultScrollBarRenderer = New FarPoint.Win.Spread.DefaultScrollBarRenderer()
        Dim NamedStyle5 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("Color65637643603259328833")
        Dim NamedStyle6 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("Font193637643603259328833")
        Dim NamedStyle7 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("BorderEx696637643603259388827")
        Dim ComplexBorder3 As FarPoint.Win.ComplexBorder = New FarPoint.Win.ComplexBorder(New FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.None), New FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.None), New FarPoint.Win.ComplexBorderSide(System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))), New FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.None), New FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.None), False, False)
        Dim NamedStyle8 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("BorderEx801637643603259388827")
        Dim TipAppearance2 As FarPoint.Win.Spread.TipAppearance = New FarPoint.Win.Spread.TipAppearance()
        Dim DefaultScrollBarRenderer4 As FarPoint.Win.Spread.DefaultScrollBarRenderer = New FarPoint.Win.Spread.DefaultScrollBarRenderer()
        Dim ComplexBorder4 As FarPoint.Win.ComplexBorder = New FarPoint.Win.ComplexBorder(New FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.None), New FarPoint.Win.ComplexBorderSide(System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))), New FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.None), New FarPoint.Win.ComplexBorderSide(System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))), New FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.None), False, False)
        Dim TextCellType6 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType()
        Dim ComplexBorder5 As FarPoint.Win.ComplexBorder = New FarPoint.Win.ComplexBorder(New FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.None), New FarPoint.Win.ComplexBorderSide(System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))), New FarPoint.Win.ComplexBorderSide(System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))), New FarPoint.Win.ComplexBorderSide(System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))), New FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.None), False, False)
        Dim TextCellType7 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType()
        Dim CurrencyCellType1 As FarPoint.Win.Spread.CellType.CurrencyCellType = New FarPoint.Win.Spread.CellType.CurrencyCellType()
        Dim CurrencyCellType2 As FarPoint.Win.Spread.CellType.CurrencyCellType = New FarPoint.Win.Spread.CellType.CurrencyCellType()
        Dim CurrencyCellType3 As FarPoint.Win.Spread.CellType.CurrencyCellType = New FarPoint.Win.Spread.CellType.CurrencyCellType()
        Dim TextCellType8 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType()
        Dim TextCellType9 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType()
        Dim ComplexBorder6 As FarPoint.Win.ComplexBorder = New FarPoint.Win.ComplexBorder(New FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThinLine))
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmSYKD180))
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.Check1 = New System.Windows.Forms.CheckBox()
        Me.Picture3 = New System.Windows.Forms.Panel()
        Me._Label1_20 = New System.Windows.Forms.Label()
        Me._Frame1_2 = New System.Windows.Forms.GroupBox()
        Me._imText6_0 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._imText7_0 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._imText6_1 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._imText6_2 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._imText6_4 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._imText6_5 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._imText7_1 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._imNumber2_0 = New GrapeCity.Win.Editors.GcNumber(Me.components)
        Me._imNumber2_1 = New GrapeCity.Win.Editors.GcNumber(Me.components)
        Me._imNumber2_2 = New GrapeCity.Win.Editors.GcNumber(Me.components)
        Me._Label1_15 = New System.Windows.Forms.Label()
        Me._Label1_13 = New System.Windows.Forms.Label()
        Me._Label1_14 = New System.Windows.Forms.Label()
        Me._Label1_12 = New System.Windows.Forms.Label()
        Me._Label1_10 = New System.Windows.Forms.Label()
        Me._Label1_11 = New System.Windows.Forms.Label()
        Me._Label1_9 = New System.Windows.Forms.Label()
        Me._Label1_8 = New System.Windows.Forms.Label()
        Me._Label1_7 = New System.Windows.Forms.Label()
        Me._imNumber2_3 = New GrapeCity.Win.Editors.GcNumber(Me.components)
        Me._Frame1_0 = New System.Windows.Forms.GroupBox()
        Me.VScroll1 = New System.Windows.Forms.VScrollBar()
        Me._Picture2_1 = New System.Windows.Forms.Panel()
        Me._imText3_2 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._imText5_2 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._imText5_3 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._imText5_0 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._imText5_1 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._Picture2_0 = New System.Windows.Forms.Panel()
        Me._imText3_1 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._imText4_2 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._imNumber1_0 = New GrapeCity.Win.Editors.GcNumber(Me.components)
        Me._imNumber1_1 = New GrapeCity.Win.Editors.GcNumber(Me.components)
        Me._imText4_3 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._ctlGeppo1_0 = New Syk_d000.ctlGeppo()
        Me._ctlGeppo1_1 = New Syk_d000.ctlGeppo()
        Me._ctlGeppo1_2 = New Syk_d000.ctlGeppo()
        Me._Label1_6 = New System.Windows.Forms.Label()
        Me._Label1_5 = New System.Windows.Forms.Label()
        Me._Label1_4 = New System.Windows.Forms.Label()
        Me._Label1_1 = New System.Windows.Forms.Label()
        Me._Label1_3 = New System.Windows.Forms.Label()
        Me._Label1_2 = New System.Windows.Forms.Label()
        Me.Picture1 = New System.Windows.Forms.Panel()
        Me._cmdKey_3 = New System.Windows.Forms.Button()
        Me._cmdKey_12 = New System.Windows.Forms.Button()
        Me._cmdKey_4 = New System.Windows.Forms.Button()
        Me._cmdKey_10 = New System.Windows.Forms.Button()
        Me._cmdKey_6 = New System.Windows.Forms.Button()
        Me._cmdKey_7 = New System.Windows.Forms.Button()
        Me._cmdKey_8 = New System.Windows.Forms.Button()
        Me._cmdKey_9 = New System.Windows.Forms.Button()
        Me._cmdKey_1 = New System.Windows.Forms.Button()
        Me._cmdKey_11 = New System.Windows.Forms.Button()
        Me._cmdKey_2 = New System.Windows.Forms.Button()
        Me._cmdKey_5 = New System.Windows.Forms.Button()
        Me.StatusBar1 = New System.Windows.Forms.StatusStrip()
        Me._StatusBar1_Panel1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.Message = New System.Windows.Forms.ToolStripStatusLabel()
        Me._imText2_2 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._imText2_0 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._imText2_1 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._imText3_0 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._Frame1_1 = New System.Windows.Forms.GroupBox()
        Me._imText1_0 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._imDate1_0 = New GrapeCity.Win.Editors.GcDate(Me.components)
        Me.DropDownButton1 = New GrapeCity.Win.Editors.DropDownButton()
        Me._imDate1_1 = New GrapeCity.Win.Editors.GcDate(Me.components)
        Me.DropDownButton2 = New GrapeCity.Win.Editors.DropDownButton()
        Me._imDate1_2 = New GrapeCity.Win.Editors.GcDate(Me.components)
        Me.DropDownButton3 = New GrapeCity.Win.Editors.DropDownButton()
        Me._imText1_1 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._Label1_19 = New System.Windows.Forms.Label()
        Me._Label1_17 = New System.Windows.Forms.Label()
        Me._Label1_16 = New System.Windows.Forms.Label()
        Me._Label1_18 = New System.Windows.Forms.Label()
        Me._Label1_0 = New System.Windows.Forms.Label()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.FpSpread1 = New FarPoint.Win.Spread.FpSpread()
        Me.FpSpread1_Sheet1 = New FarPoint.Win.Spread.SheetView()
        Me.FpSpread2 = New FarPoint.Win.Spread.FpSpread()
        Me.FpSpread2_Sheet1 = New FarPoint.Win.Spread.SheetView()
        Me.Picture3.SuspendLayout()
        Me._Frame1_2.SuspendLayout()
        CType(Me._imText6_0, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imText7_0, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imText6_1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imText6_2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imText6_4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imText6_5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imText7_1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imNumber2_0, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imNumber2_1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imNumber2_2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imNumber2_3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me._Frame1_0.SuspendLayout()
        Me._Picture2_1.SuspendLayout()
        CType(Me._imText3_2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imText5_2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imText5_3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imText5_0, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imText5_1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me._Picture2_0.SuspendLayout()
        CType(Me._imText3_1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imText4_2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imNumber1_0, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imNumber1_1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imText4_3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Picture1.SuspendLayout()
        Me.StatusBar1.SuspendLayout()
        CType(Me._imText2_2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imText2_0, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imText2_1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imText3_0, System.ComponentModel.ISupportInitialize).BeginInit()
        Me._Frame1_1.SuspendLayout()
        CType(Me._imText1_0, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imDate1_0, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imDate1_1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imDate1_2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imText1_1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.FpSpread1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.FpSpread1_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.FpSpread2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.FpSpread2_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        CustomSpdHeader.Name = "CustomSpdHeader"
        CustomSpdHeader.PictureZoomEffect = False
        CustomSpdHeader.TextRotationAngle = 0R
        CustomSpdHeader.ZoomFactor = 1.0!
        CustomSpdHeader1.Name = "CustomSpdHeader1"
        CustomSpdHeader1.PictureZoomEffect = False
        CustomSpdHeader1.TextRotationAngle = 0R
        CustomSpdHeader1.ZoomFactor = 1.0!
        CustomSpdHeader2.Name = "CustomSpdHeader2"
        CustomSpdHeader2.PictureZoomEffect = False
        CustomSpdHeader2.TextRotationAngle = 0R
        CustomSpdHeader2.ZoomFactor = 1.0!
        CustomSpdHeader3.Name = "CustomSpdHeader3"
        CustomSpdHeader3.PictureZoomEffect = False
        CustomSpdHeader3.TextRotationAngle = 0R
        CustomSpdHeader3.ZoomFactor = 1.0!
        CustomSpdHeader4.Name = "CustomSpdHeader4"
        CustomSpdHeader4.PictureZoomEffect = False
        CustomSpdHeader4.TextRotationAngle = 0R
        CustomSpdHeader4.ZoomFactor = 1.0!
        CustomSpdHeader5.Name = "CustomSpdHeader5"
        CustomSpdHeader5.PictureZoomEffect = False
        CustomSpdHeader5.TextRotationAngle = 0R
        CustomSpdHeader5.ZoomFactor = 1.0!
        CustomSpdHeader6.Name = "CustomSpdHeader6"
        CustomSpdHeader6.PictureZoomEffect = False
        CustomSpdHeader6.TextRotationAngle = 0R
        CustomSpdHeader6.ZoomFactor = 1.0!
        CustomSpdHeader7.Name = "CustomSpdHeader7"
        CustomSpdHeader7.PictureZoomEffect = False
        CustomSpdHeader7.TextRotationAngle = 0R
        CustomSpdHeader7.ZoomFactor = 1.0!
        CustomSpdHeader8.Name = "CustomSpdHeader8"
        CustomSpdHeader8.PictureZoomEffect = False
        CustomSpdHeader8.TextRotationAngle = 0R
        CustomSpdHeader8.ZoomFactor = 1.0!
        CustomSpdHeader9.Name = "CustomSpdHeader9"
        CustomSpdHeader9.PictureZoomEffect = False
        CustomSpdHeader9.TextRotationAngle = 0R
        CustomSpdHeader9.ZoomFactor = 1.0!
        CustomSpdHeader10.Name = "CustomSpdHeader10"
        CustomSpdHeader10.PictureZoomEffect = False
        CustomSpdHeader10.TextRotationAngle = 0R
        CustomSpdHeader10.ZoomFactor = 1.0!
        CustomSpdHeader11.Name = "CustomSpdHeader11"
        CustomSpdHeader11.PictureZoomEffect = False
        CustomSpdHeader11.TextRotationAngle = 0R
        CustomSpdHeader11.ZoomFactor = 1.0!
        CustomSpdHeader12.Name = "CustomSpdHeader12"
        CustomSpdHeader12.PictureZoomEffect = False
        CustomSpdHeader12.TextRotationAngle = 0R
        CustomSpdHeader12.ZoomFactor = 1.0!
        CustomSpdHeader13.Name = "CustomSpdHeader13"
        CustomSpdHeader13.PictureZoomEffect = False
        CustomSpdHeader13.TextRotationAngle = 0R
        CustomSpdHeader13.ZoomFactor = 1.0!
        CustomSpdHeader14.Name = "CustomSpdHeader14"
        CustomSpdHeader14.PictureZoomEffect = False
        CustomSpdHeader14.TextRotationAngle = 0R
        CustomSpdHeader14.ZoomFactor = 1.0!
        '
        'Check1
        '
        Me.Check1.BackColor = System.Drawing.SystemColors.Control
        Me.Check1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Check1.Font = New System.Drawing.Font("MS Mincho", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Check1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Check1.Location = New System.Drawing.Point(248, 392)
        Me.Check1.Name = "Check1"
        Me.Check1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Check1.Size = New System.Drawing.Size(55, 17)
        Me.Check1.TabIndex = 37
        Me.Check1.Tag = "���F����ꍇ���������ĉ������B"
        Me.Check1.Text = "���F"
        Me.Check1.UseVisualStyleBackColor = False
        '
        'Picture3
        '
        Me.Picture3.BackColor = System.Drawing.SystemColors.Control
        Me.Picture3.Controls.Add(Me._Label1_20)
        Me.Picture3.Cursor = System.Windows.Forms.Cursors.Default
        Me.Picture3.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Picture3.Location = New System.Drawing.Point(250, 378)
        Me.Picture3.Name = "Picture3"
        Me.Picture3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Picture3.Size = New System.Drawing.Size(109, 26)
        Me.Picture3.TabIndex = 76
        '
        '_Label1_20
        '
        Me._Label1_20.BackColor = System.Drawing.Color.Transparent
        Me._Label1_20.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_20.Font = New System.Drawing.Font("MS Mincho", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_20.ForeColor = System.Drawing.Color.Black
        Me._Label1_20.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me._Label1_20.Location = New System.Drawing.Point(0, 0)
        Me._Label1_20.Name = "_Label1_20"
        Me._Label1_20.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_20.Size = New System.Drawing.Size(109, 26)
        Me._Label1_20.TabIndex = 36
        Me._Label1_20.Text = "��Ɋz���͎��" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "         �\��z"
        Me._Label1_20.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        '_Frame1_2
        '
        Me._Frame1_2.BackColor = System.Drawing.SystemColors.Control
        Me._Frame1_2.Controls.Add(Me._imText6_0)
        Me._Frame1_2.Controls.Add(Me._imText7_0)
        Me._Frame1_2.Controls.Add(Me._imText6_1)
        Me._Frame1_2.Controls.Add(Me._imText6_2)
        Me._Frame1_2.Controls.Add(Me._imText6_4)
        Me._Frame1_2.Controls.Add(Me._imText6_5)
        Me._Frame1_2.Controls.Add(Me._imText7_1)
        Me._Frame1_2.Controls.Add(Me._imNumber2_0)
        Me._Frame1_2.Controls.Add(Me._imNumber2_1)
        Me._Frame1_2.Controls.Add(Me._imNumber2_2)
        Me._Frame1_2.Controls.Add(Me._Label1_15)
        Me._Frame1_2.Controls.Add(Me._Label1_13)
        Me._Frame1_2.Controls.Add(Me._Label1_14)
        Me._Frame1_2.Controls.Add(Me._Label1_12)
        Me._Frame1_2.Controls.Add(Me._Label1_10)
        Me._Frame1_2.Controls.Add(Me._Label1_11)
        Me._Frame1_2.Controls.Add(Me._Label1_9)
        Me._Frame1_2.Controls.Add(Me._Label1_8)
        Me._Frame1_2.Controls.Add(Me._Label1_7)
        Me._Frame1_2.ForeColor = System.Drawing.Color.White
        Me._Frame1_2.Location = New System.Drawing.Point(658, 60)
        Me._Frame1_2.Name = "_Frame1_2"
        Me._Frame1_2.Padding = New System.Windows.Forms.Padding(0)
        Me._Frame1_2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Frame1_2.Size = New System.Drawing.Size(349, 307)
        Me._Frame1_2.TabIndex = 24
        Me._Frame1_2.TabStop = False
        '
        '_imText6_0
        '
        Me._imText6_0.ContentAlignment = System.Drawing.ContentAlignment.MiddleRight
        Me._imText6_0.DisabledForeColor = System.Drawing.SystemColors.WindowText
        Me._imText6_0.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._imText6_0.ImeMode = System.Windows.Forms.ImeMode.Off
        Me._imText6_0.Location = New System.Drawing.Point(148, 14)
        Me._imText6_0.Name = "_imText6_0"
        Me._imText6_0.ReadOnly = True
        Me._imText6_0.ReadOnlyBackColor = System.Drawing.SystemColors.Control
        Me._imText6_0.Size = New System.Drawing.Size(127, 23)
        Me._imText6_0.TabIndex = 25
        Me._imText6_0.TabStop = False
        '
        '_imText7_0
        '
        Me._imText7_0.ContentAlignment = System.Drawing.ContentAlignment.MiddleRight
        Me._imText7_0.DisabledForeColor = System.Drawing.SystemColors.WindowText
        Me._imText7_0.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._imText7_0.ImeMode = System.Windows.Forms.ImeMode.Off
        Me._imText7_0.Location = New System.Drawing.Point(278, 14)
        Me._imText7_0.Name = "_imText7_0"
        Me._imText7_0.ReadOnly = True
        Me._imText7_0.ReadOnlyBackColor = System.Drawing.SystemColors.Control
        Me._imText7_0.Size = New System.Drawing.Size(63, 23)
        Me._imText7_0.TabIndex = 26
        Me._imText7_0.TabStop = False
        '
        '_imText6_1
        '
        Me._imText6_1.ContentAlignment = System.Drawing.ContentAlignment.MiddleRight
        Me._imText6_1.DisabledForeColor = System.Drawing.SystemColors.WindowText
        Me._imText6_1.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._imText6_1.ImeMode = System.Windows.Forms.ImeMode.Off
        Me._imText6_1.Location = New System.Drawing.Point(148, 40)
        Me._imText6_1.Name = "_imText6_1"
        Me._imText6_1.ReadOnly = True
        Me._imText6_1.ReadOnlyBackColor = System.Drawing.SystemColors.Control
        Me._imText6_1.Size = New System.Drawing.Size(127, 23)
        Me._imText6_1.TabIndex = 27
        Me._imText6_1.TabStop = False
        '
        '_imText6_2
        '
        Me._imText6_2.ContentAlignment = System.Drawing.ContentAlignment.MiddleRight
        Me._imText6_2.DisabledForeColor = System.Drawing.SystemColors.WindowText
        Me._imText6_2.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._imText6_2.ImeMode = System.Windows.Forms.ImeMode.Off
        Me._imText6_2.Location = New System.Drawing.Point(148, 66)
        Me._imText6_2.Name = "_imText6_2"
        Me._imText6_2.ReadOnly = True
        Me._imText6_2.ReadOnlyBackColor = System.Drawing.SystemColors.Control
        Me._imText6_2.Size = New System.Drawing.Size(127, 23)
        Me._imText6_2.TabIndex = 28
        Me._imText6_2.TabStop = False
        '
        '_imText6_4
        '
        Me._imText6_4.ContentAlignment = System.Drawing.ContentAlignment.MiddleRight
        Me._imText6_4.DisabledForeColor = System.Drawing.SystemColors.WindowText
        Me._imText6_4.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._imText6_4.ImeMode = System.Windows.Forms.ImeMode.Off
        Me._imText6_4.Location = New System.Drawing.Point(148, 144)
        Me._imText6_4.Name = "_imText6_4"
        Me._imText6_4.ReadOnly = True
        Me._imText6_4.ReadOnlyBackColor = System.Drawing.SystemColors.Control
        Me._imText6_4.Size = New System.Drawing.Size(127, 23)
        Me._imText6_4.TabIndex = 32
        Me._imText6_4.TabStop = False
        '
        '_imText6_5
        '
        Me._imText6_5.ContentAlignment = System.Drawing.ContentAlignment.MiddleRight
        Me._imText6_5.DisabledForeColor = System.Drawing.SystemColors.WindowText
        Me._imText6_5.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._imText6_5.ImeMode = System.Windows.Forms.ImeMode.Off
        Me._imText6_5.Location = New System.Drawing.Point(148, 222)
        Me._imText6_5.Name = "_imText6_5"
        Me._imText6_5.ReadOnly = True
        Me._imText6_5.ReadOnlyBackColor = System.Drawing.SystemColors.Control
        Me._imText6_5.Size = New System.Drawing.Size(127, 23)
        Me._imText6_5.TabIndex = 35
        Me._imText6_5.TabStop = False
        '
        '_imText7_1
        '
        Me._imText7_1.ContentAlignment = System.Drawing.ContentAlignment.MiddleRight
        Me._imText7_1.DisabledForeColor = System.Drawing.SystemColors.WindowText
        Me._imText7_1.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._imText7_1.ImeMode = System.Windows.Forms.ImeMode.Off
        Me._imText7_1.Location = New System.Drawing.Point(278, 92)
        Me._imText7_1.Name = "_imText7_1"
        Me._imText7_1.ReadOnly = True
        Me._imText7_1.ReadOnlyBackColor = System.Drawing.SystemColors.Control
        Me._imText7_1.Size = New System.Drawing.Size(63, 23)
        Me._imText7_1.TabIndex = 30
        Me._imText7_1.TabStop = False
        '
        '_imNumber2_0
        '
        Me._imNumber2_0.ContentAlignment = System.Drawing.ContentAlignment.MiddleRight
        Me._imNumber2_0.DisabledBackColor = System.Drawing.SystemColors.Window
        Me._imNumber2_0.DisabledForeColor = System.Drawing.SystemColors.WindowText
        Me._imNumber2_0.Fields.DecimalPart.MaxDigits = 0
        Me._imNumber2_0.Fields.IntegerPart.GroupSizes = New Integer() {3, 3, 3, 0}
        Me._imNumber2_0.Fields.IntegerPart.MaxDigits = 11
        Me._imNumber2_0.Fields.IntegerPart.MinDigits = 1
        Me._imNumber2_0.Fields.SignPrefix.NegativePattern = ""
        Me._imNumber2_0.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._imNumber2_0.HighlightText = True
        Me._imNumber2_0.Location = New System.Drawing.Point(148, 92)
        Me._imNumber2_0.MaxMinBehavior = GrapeCity.Win.Editors.MaxMinBehavior.CancelInput
        Me._imNumber2_0.MaxValue = New Decimal(New Integer() {1215752191, 23, 0, 0})
        Me._imNumber2_0.MinValue = New Decimal(New Integer() {1410065407, 2, 0, -2147483648})
        Me._imNumber2_0.Name = "_imNumber2_0"
        Me._imNumber2_0.ReadOnlyForeColor = System.Drawing.SystemColors.WindowText
        Me._imNumber2_0.Size = New System.Drawing.Size(127, 23)
        Me._imNumber2_0.Spin.AllowSpin = False
        Me._imNumber2_0.TabIndex = 29
        Me._imNumber2_0.Tag = "�������o��������͂��ĉ������B"
        '
        '_imNumber2_1
        '
        Me._imNumber2_1.AlternateText.DisplayZero.ForeColor = System.Drawing.SystemColors.WindowText
        Me._imNumber2_1.AlternateText.Null.ForeColor = System.Drawing.SystemColors.WindowText
        Me._imNumber2_1.AlternateText.Zero.ForeColor = System.Drawing.SystemColors.WindowText
        Me._imNumber2_1.AlternateText.Zero.Text = "0"
        Me._imNumber2_1.ContentAlignment = System.Drawing.ContentAlignment.MiddleRight
        Me._imNumber2_1.DisabledBackColor = System.Drawing.SystemColors.Window
        Me._imNumber2_1.DisabledForeColor = System.Drawing.SystemColors.WindowText
        Me._imNumber2_1.Fields.DecimalPart.MaxDigits = 0
        Me._imNumber2_1.Fields.IntegerPart.GroupSizes = New Integer() {3, 3, 3, 0}
        Me._imNumber2_1.Fields.IntegerPart.MaxDigits = 10
        Me._imNumber2_1.Fields.IntegerPart.MinDigits = 1
        Me._imNumber2_1.Fields.SignPrefix.NegativePattern = ""
        Me._imNumber2_1.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._imNumber2_1.HighlightText = True
        Me._imNumber2_1.Location = New System.Drawing.Point(148, 170)
        Me._imNumber2_1.MaxMinBehavior = GrapeCity.Win.Editors.MaxMinBehavior.CancelInput
        Me._imNumber2_1.MaxValue = New Decimal(New Integer() {1410065407, 2, 0, 0})
        Me._imNumber2_1.MinValue = New Decimal(New Integer() {999999999, 0, 0, -2147483648})
        Me._imNumber2_1.Name = "_imNumber2_1"
        Me._imNumber2_1.ReadOnlyForeColor = System.Drawing.SystemColors.WindowText
        Me._imNumber2_1.Size = New System.Drawing.Size(127, 23)
        Me._imNumber2_1.Spin.AllowSpin = False
        Me._imNumber2_1.TabIndex = 33
        Me._imNumber2_1.Tag = "�����w�͖ڕW����͂��ĉ������B"
        '
        '_imNumber2_2
        '
        Me._imNumber2_2.ContentAlignment = System.Drawing.ContentAlignment.MiddleRight
        Me._imNumber2_2.DisabledBackColor = System.Drawing.SystemColors.Window
        Me._imNumber2_2.DisabledForeColor = System.Drawing.SystemColors.WindowText
        NumberIntegerPartDisplayField1.GroupSizes = New Integer() {3, 3, 0}
        NumberDecimalPartDisplayField1.MaxDigits = 3
        Me._imNumber2_2.DisplayFields.AddRange(New GrapeCity.Win.Editors.Fields.NumberDisplayField() {NumberSignDisplayField1, NumberIntegerPartDisplayField1, NumberDecimalSeparatorDisplayField1, NumberDecimalPartDisplayField1})
        Me._imNumber2_2.Fields.DecimalPart.MaxDigits = 0
        Me._imNumber2_2.Fields.IntegerPart.GroupSizes = New Integer() {3, 3, 3, 0}
        Me._imNumber2_2.Fields.IntegerPart.MaxDigits = 10
        Me._imNumber2_2.Fields.IntegerPart.MinDigits = 1
        Me._imNumber2_2.Fields.SignPrefix.NegativePattern = ""
        Me._imNumber2_2.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._imNumber2_2.HighlightText = True
        Me._imNumber2_2.Location = New System.Drawing.Point(148, 196)
        Me._imNumber2_2.MaxMinBehavior = GrapeCity.Win.Editors.MaxMinBehavior.CancelInput
        Me._imNumber2_2.MaxValue = New Decimal(New Integer() {1410065407, 2, 0, 0})
        Me._imNumber2_2.MinValue = New Decimal(New Integer() {999999999, 0, 0, -2147483648})
        Me._imNumber2_2.Name = "_imNumber2_2"
        Me._imNumber2_2.ReadOnlyForeColor = System.Drawing.SystemColors.WindowText
        Me._imNumber2_2.Size = New System.Drawing.Size(127, 23)
        Me._imNumber2_2.Spin.AllowSpin = False
        Me._imNumber2_2.TabIndex = 34
        Me._imNumber2_2.Tag = "�扺�z����͂��ĉ������B"
        '
        '_Label1_15
        '
        Me._Label1_15.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_15.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_15.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_15.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_15.ForeColor = System.Drawing.Color.White
        Me._Label1_15.Location = New System.Drawing.Point(8, 222)
        Me._Label1_15.Name = "_Label1_15"
        Me._Label1_15.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_15.Size = New System.Drawing.Size(137, 23)
        Me._Label1_15.TabIndex = 75
        Me._Label1_15.Text = "�扺�c��"
        Me._Label1_15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_13
        '
        Me._Label1_13.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_13.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_13.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_13.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_13.ForeColor = System.Drawing.Color.White
        Me._Label1_13.Location = New System.Drawing.Point(8, 170)
        Me._Label1_13.Name = "_Label1_13"
        Me._Label1_13.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_13.Size = New System.Drawing.Size(137, 23)
        Me._Label1_13.TabIndex = 74
        Me._Label1_13.Text = "�����w�͖ڕW"
        Me._Label1_13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_14
        '
        Me._Label1_14.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_14.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_14.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_14.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_14.ForeColor = System.Drawing.Color.White
        Me._Label1_14.Location = New System.Drawing.Point(8, 196)
        Me._Label1_14.Name = "_Label1_14"
        Me._Label1_14.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_14.Size = New System.Drawing.Size(137, 23)
        Me._Label1_14.TabIndex = 73
        Me._Label1_14.Text = "�� �� �z"
        Me._Label1_14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_12
        '
        Me._Label1_12.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_12.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_12.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_12.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_12.ForeColor = System.Drawing.Color.White
        Me._Label1_12.Location = New System.Drawing.Point(8, 144)
        Me._Label1_12.Name = "_Label1_12"
        Me._Label1_12.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_12.Size = New System.Drawing.Size(137, 23)
        Me._Label1_12.TabIndex = 72
        Me._Label1_12.Text = "���񐿕��o����"
        Me._Label1_12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_10
        '
        Me._Label1_10.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_10.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_10.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_10.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_10.ForeColor = System.Drawing.Color.White
        Me._Label1_10.Location = New System.Drawing.Point(8, 92)
        Me._Label1_10.Name = "_Label1_10"
        Me._Label1_10.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_10.Size = New System.Drawing.Size(137, 23)
        Me._Label1_10.TabIndex = 71
        Me._Label1_10.Text = "�������o����"
        Me._Label1_10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_11
        '
        Me._Label1_11.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_11.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_11.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_11.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_11.ForeColor = System.Drawing.Color.White
        Me._Label1_11.Location = New System.Drawing.Point(8, 118)
        Me._Label1_11.Name = "_Label1_11"
        Me._Label1_11.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_11.Size = New System.Drawing.Size(137, 23)
        Me._Label1_11.TabIndex = 70
        Me._Label1_11.Text = "�O�񐿕��o����"
        Me._Label1_11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_9
        '
        Me._Label1_9.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_9.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_9.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_9.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_9.ForeColor = System.Drawing.Color.White
        Me._Label1_9.Location = New System.Drawing.Point(8, 66)
        Me._Label1_9.Name = "_Label1_9"
        Me._Label1_9.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_9.Size = New System.Drawing.Size(137, 23)
        Me._Label1_9.TabIndex = 69
        Me._Label1_9.Text = "������{���z"
        Me._Label1_9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_8
        '
        Me._Label1_8.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_8.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_8.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_8.ForeColor = System.Drawing.Color.White
        Me._Label1_8.Location = New System.Drawing.Point(8, 40)
        Me._Label1_8.Name = "_Label1_8"
        Me._Label1_8.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_8.Size = New System.Drawing.Size(137, 23)
        Me._Label1_8.TabIndex = 68
        Me._Label1_8.Text = "�O�񖘎��{���z"
        Me._Label1_8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_7
        '
        Me._Label1_7.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_7.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_7.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_7.ForeColor = System.Drawing.Color.White
        Me._Label1_7.Location = New System.Drawing.Point(8, 14)
        Me._Label1_7.Name = "_Label1_7"
        Me._Label1_7.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_7.Size = New System.Drawing.Size(137, 23)
        Me._Label1_7.TabIndex = 67
        Me._Label1_7.Text = "�݌v���{���z"
        Me._Label1_7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_imNumber2_3
        '
        Me._imNumber2_3.ContentAlignment = System.Drawing.ContentAlignment.MiddleRight
        Me._imNumber2_3.DisabledBackColor = System.Drawing.SystemColors.Window
        Me._imNumber2_3.DisabledForeColor = System.Drawing.SystemColors.WindowText
        Me._imNumber2_3.Fields.DecimalPart.MaxDigits = 0
        Me._imNumber2_3.Fields.IntegerPart.GroupSizes = New Integer() {3, 3, 3, 0}
        Me._imNumber2_3.Fields.IntegerPart.MaxDigits = 10
        Me._imNumber2_3.Fields.IntegerPart.MinDigits = 1
        Me._imNumber2_3.Fields.SignPrefix.NegativePattern = ""
        Me._imNumber2_3.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._imNumber2_3.HighlightText = True
        Me._imNumber2_3.Location = New System.Drawing.Point(806, 178)
        Me._imNumber2_3.MaxMinBehavior = GrapeCity.Win.Editors.MaxMinBehavior.CancelInput
        Me._imNumber2_3.MaxValue = New Decimal(New Integer() {1410065407, 2, 0, 0})
        Me._imNumber2_3.MinValue = New Decimal(New Integer() {999999999, 0, 0, -2147483648})
        Me._imNumber2_3.Name = "_imNumber2_3"
        Me._imNumber2_3.ReadOnlyForeColor = System.Drawing.SystemColors.WindowText
        Me._imNumber2_3.Size = New System.Drawing.Size(127, 23)
        Me._imNumber2_3.Spin.AllowSpin = False
        Me._imNumber2_3.TabIndex = 47
        Me._imNumber2_3.Tag = "�������o��������͂��ĉ������B"
        '
        '_Frame1_0
        '
        Me._Frame1_0.BackColor = System.Drawing.SystemColors.Control
        Me._Frame1_0.Controls.Add(Me.VScroll1)
        Me._Frame1_0.Controls.Add(Me._Picture2_1)
        Me._Frame1_0.Controls.Add(Me._Picture2_0)
        Me._Frame1_0.Controls.Add(Me._ctlGeppo1_0)
        Me._Frame1_0.Controls.Add(Me._ctlGeppo1_1)
        Me._Frame1_0.Controls.Add(Me._ctlGeppo1_2)
        Me._Frame1_0.Controls.Add(Me._Label1_6)
        Me._Frame1_0.Controls.Add(Me._Label1_5)
        Me._Frame1_0.Controls.Add(Me._Label1_4)
        Me._Frame1_0.Controls.Add(Me._Label1_1)
        Me._Frame1_0.Controls.Add(Me._Label1_3)
        Me._Frame1_0.Controls.Add(Me._Label1_2)
        Me._Frame1_0.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Frame1_0.Location = New System.Drawing.Point(6, 60)
        Me._Frame1_0.Name = "_Frame1_0"
        Me._Frame1_0.Padding = New System.Windows.Forms.Padding(0)
        Me._Frame1_0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Frame1_0.Size = New System.Drawing.Size(648, 209)
        Me._Frame1_0.TabIndex = 1
        Me._Frame1_0.TabStop = False
        '
        'VScroll1
        '
        Me.VScroll1.Cursor = System.Windows.Forms.Cursors.Default
        Me.VScroll1.LargeChange = 3
        Me.VScroll1.Location = New System.Drawing.Point(622, 72)
        Me.VScroll1.Maximum = 4
        Me.VScroll1.Name = "VScroll1"
        Me.VScroll1.Size = New System.Drawing.Size(17, 96)
        Me.VScroll1.TabIndex = 17
        Me.VScroll1.TabStop = True
        '
        '_Picture2_1
        '
        Me._Picture2_1.BackColor = System.Drawing.SystemColors.Control
        Me._Picture2_1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Picture2_1.Controls.Add(Me._imText3_2)
        Me._Picture2_1.Controls.Add(Me._imText5_2)
        Me._Picture2_1.Controls.Add(Me._imText5_3)
        Me._Picture2_1.Controls.Add(Me._imText5_0)
        Me._Picture2_1.Controls.Add(Me._imText5_1)
        Me._Picture2_1.Cursor = System.Windows.Forms.Cursors.Default
        Me._Picture2_1.Enabled = False
        Me._Picture2_1.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Picture2_1.Location = New System.Drawing.Point(8, 170)
        Me._Picture2_1.Name = "_Picture2_1"
        Me._Picture2_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Picture2_1.Size = New System.Drawing.Size(613, 31)
        Me._Picture2_1.TabIndex = 11
        '
        '_imText3_2
        '
        Me._imText3_2.ActiveBackColor = System.Drawing.Color.PeachPuff
        Me._imText3_2.BackColor = System.Drawing.Color.PeachPuff
        Me._imText3_2.ContentAlignment = System.Drawing.ContentAlignment.MiddleCenter
        Me._imText3_2.DisabledBackColor = System.Drawing.Color.PeachPuff
        Me._imText3_2.DisabledForeColor = System.Drawing.SystemColors.WindowText
        Me._imText3_2.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._imText3_2.Location = New System.Drawing.Point(3, 2)
        Me._imText3_2.Name = "_imText3_2"
        Me._imText3_2.ReadOnly = True
        Me._imText3_2.ReadOnlyBackColor = System.Drawing.Color.PeachPuff
        Me._imText3_2.Size = New System.Drawing.Size(148, 23)
        Me._imText3_2.TabIndex = 12
        Me._imText3_2.TabStop = False
        Me._imText3_2.Text = "���Z����"
        '
        '_imText5_2
        '
        Me._imText5_2.ContentAlignment = System.Drawing.ContentAlignment.MiddleRight
        Me._imText5_2.DisabledForeColor = System.Drawing.SystemColors.WindowText
        Me._imText5_2.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._imText5_2.ImeMode = System.Windows.Forms.ImeMode.Off
        Me._imText5_2.Location = New System.Drawing.Point(414, 2)
        Me._imText5_2.Name = "_imText5_2"
        Me._imText5_2.ReadOnly = True
        Me._imText5_2.ReadOnlyBackColor = System.Drawing.SystemColors.Control
        Me._imText5_2.Size = New System.Drawing.Size(127, 23)
        Me._imText5_2.TabIndex = 15
        '
        '_imText5_3
        '
        Me._imText5_3.ContentAlignment = System.Drawing.ContentAlignment.MiddleRight
        Me._imText5_3.DisabledForeColor = System.Drawing.SystemColors.WindowText
        Me._imText5_3.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._imText5_3.ImeMode = System.Windows.Forms.ImeMode.Off
        Me._imText5_3.Location = New System.Drawing.Point(544, 2)
        Me._imText5_3.Name = "_imText5_3"
        Me._imText5_3.ReadOnly = True
        Me._imText5_3.ReadOnlyBackColor = System.Drawing.SystemColors.Control
        Me._imText5_3.Size = New System.Drawing.Size(63, 23)
        Me._imText5_3.TabIndex = 16
        '
        '_imText5_0
        '
        Me._imText5_0.ContentAlignment = System.Drawing.ContentAlignment.MiddleRight
        Me._imText5_0.DisabledForeColor = System.Drawing.SystemColors.WindowText
        Me._imText5_0.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._imText5_0.HighlightText = True
        Me._imText5_0.ImeMode = System.Windows.Forms.ImeMode.Off
        Me._imText5_0.Location = New System.Drawing.Point(154, 2)
        Me._imText5_0.Name = "_imText5_0"
        Me._imText5_0.ReadOnly = True
        Me._imText5_0.ReadOnlyBackColor = System.Drawing.SystemColors.Control
        Me._imText5_0.ReadOnlyForeColor = System.Drawing.SystemColors.WindowText
        Me._imText5_0.Size = New System.Drawing.Size(127, 23)
        Me._imText5_0.TabIndex = 13
        '
        '_imText5_1
        '
        Me._imText5_1.ContentAlignment = System.Drawing.ContentAlignment.MiddleRight
        Me._imText5_1.DisabledForeColor = System.Drawing.SystemColors.WindowText
        Me._imText5_1.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._imText5_1.HighlightText = True
        Me._imText5_1.ImeMode = System.Windows.Forms.ImeMode.Off
        Me._imText5_1.Location = New System.Drawing.Point(284, 2)
        Me._imText5_1.Name = "_imText5_1"
        Me._imText5_1.ReadOnly = True
        Me._imText5_1.ReadOnlyBackColor = System.Drawing.SystemColors.Control
        Me._imText5_1.ReadOnlyForeColor = System.Drawing.SystemColors.WindowText
        Me._imText5_1.Size = New System.Drawing.Size(127, 23)
        Me._imText5_1.TabIndex = 14
        '
        '_Picture2_0
        '
        Me._Picture2_0.BackColor = System.Drawing.SystemColors.Control
        Me._Picture2_0.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Picture2_0.Controls.Add(Me._imText3_1)
        Me._Picture2_0.Controls.Add(Me._imText4_2)
        Me._Picture2_0.Controls.Add(Me._imNumber1_0)
        Me._Picture2_0.Controls.Add(Me._imNumber1_1)
        Me._Picture2_0.Controls.Add(Me._imText4_3)
        Me._Picture2_0.Cursor = System.Windows.Forms.Cursors.Default
        Me._Picture2_0.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Picture2_0.Location = New System.Drawing.Point(8, 40)
        Me._Picture2_0.Name = "_Picture2_0"
        Me._Picture2_0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Picture2_0.Size = New System.Drawing.Size(613, 31)
        Me._Picture2_0.TabIndex = 2
        '
        '_imText3_1
        '
        Me._imText3_1.ActiveBackColor = System.Drawing.Color.PeachPuff
        Me._imText3_1.BackColor = System.Drawing.Color.PeachPuff
        Me._imText3_1.ContentAlignment = System.Drawing.ContentAlignment.MiddleCenter
        Me._imText3_1.DisabledBackColor = System.Drawing.Color.PeachPuff
        Me._imText3_1.DisabledForeColor = System.Drawing.SystemColors.WindowText
        Me._imText3_1.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._imText3_1.Location = New System.Drawing.Point(3, 2)
        Me._imText3_1.Name = "_imText3_1"
        Me._imText3_1.ReadOnly = True
        Me._imText3_1.ReadOnlyBackColor = System.Drawing.Color.PeachPuff
        Me._imText3_1.Size = New System.Drawing.Size(148, 23)
        Me._imText3_1.TabIndex = 3
        Me._imText3_1.TabStop = False
        Me._imText3_1.Text = "���@��"
        '
        '_imText4_2
        '
        Me._imText4_2.ContentAlignment = System.Drawing.ContentAlignment.MiddleRight
        Me._imText4_2.DisabledForeColor = System.Drawing.SystemColors.WindowText
        Me._imText4_2.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._imText4_2.ImeMode = System.Windows.Forms.ImeMode.Off
        Me._imText4_2.Location = New System.Drawing.Point(414, 2)
        Me._imText4_2.Name = "_imText4_2"
        Me._imText4_2.ReadOnly = True
        Me._imText4_2.ReadOnlyBackColor = System.Drawing.SystemColors.Control
        Me._imText4_2.Size = New System.Drawing.Size(127, 23)
        Me._imText4_2.TabIndex = 6
        Me._imText4_2.TabStop = False
        '
        '_imNumber1_0
        '
        Me._imNumber1_0.ContentAlignment = System.Drawing.ContentAlignment.MiddleRight
        Me._imNumber1_0.DisabledBackColor = System.Drawing.SystemColors.Window
        Me._imNumber1_0.DisabledForeColor = System.Drawing.SystemColors.WindowText
        Me._imNumber1_0.Fields.DecimalPart.MaxDigits = 0
        Me._imNumber1_0.Fields.IntegerPart.GroupSizes = New Integer() {3, 3, 3, 0}
        Me._imNumber1_0.Fields.IntegerPart.MaxDigits = 10
        Me._imNumber1_0.Fields.IntegerPart.MinDigits = 1
        Me._imNumber1_0.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._imNumber1_0.HighlightText = True
        Me._imNumber1_0.Location = New System.Drawing.Point(154, 2)
        Me._imNumber1_0.MaxMinBehavior = GrapeCity.Win.Editors.MaxMinBehavior.CancelInput
        Me._imNumber1_0.MaxValue = New Decimal(New Integer() {1410065407, 2, 0, 0})
        Me._imNumber1_0.MinValue = New Decimal(New Integer() {999999999, 0, 0, -2147483648})
        Me._imNumber1_0.Name = "_imNumber1_0"
        Me._imNumber1_0.ReadOnlyForeColor = System.Drawing.SystemColors.WindowText
        Me._imNumber1_0.Size = New System.Drawing.Size(127, 23)
        Me._imNumber1_0.Spin.AllowSpin = False
        Me._imNumber1_0.TabIndex = 4
        Me._imNumber1_0.Tag = "�����������z����͂��ĉ������B"
        '
        '_imNumber1_1
        '
        Me._imNumber1_1.ContentAlignment = System.Drawing.ContentAlignment.MiddleRight
        Me._imNumber1_1.DisabledBackColor = System.Drawing.SystemColors.Window
        Me._imNumber1_1.DisabledForeColor = System.Drawing.SystemColors.WindowText
        Me._imNumber1_1.Fields.DecimalPart.MaxDigits = 0
        Me._imNumber1_1.Fields.IntegerPart.GroupSizes = New Integer() {3, 3, 3, 0}
        Me._imNumber1_1.Fields.IntegerPart.MaxDigits = 10
        Me._imNumber1_1.Fields.IntegerPart.MinDigits = 1
        Me._imNumber1_1.Fields.SignPrefix.NegativePattern = ""
        Me._imNumber1_1.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._imNumber1_1.HighlightText = True
        Me._imNumber1_1.Location = New System.Drawing.Point(284, 2)
        Me._imNumber1_1.MaxMinBehavior = GrapeCity.Win.Editors.MaxMinBehavior.CancelInput
        Me._imNumber1_1.MaxValue = New Decimal(New Integer() {1410065407, 2, 0, 0})
        Me._imNumber1_1.MinValue = New Decimal(New Integer() {999999999, 0, 0, -2147483648})
        Me._imNumber1_1.Name = "_imNumber1_1"
        Me._imNumber1_1.ReadOnlyForeColor = System.Drawing.SystemColors.WindowText
        Me._imNumber1_1.Size = New System.Drawing.Size(127, 23)
        Me._imNumber1_1.Spin.AllowSpin = False
        Me._imNumber1_1.TabIndex = 5
        Me._imNumber1_1.Tag = "�������s�\�Z�z����͂��ĉ������B"
        '
        '_imText4_3
        '
        Me._imText4_3.ContentAlignment = System.Drawing.ContentAlignment.MiddleRight
        Me._imText4_3.DisabledForeColor = System.Drawing.SystemColors.WindowText
        Me._imText4_3.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._imText4_3.ImeMode = System.Windows.Forms.ImeMode.Off
        Me._imText4_3.Location = New System.Drawing.Point(544, 2)
        Me._imText4_3.Name = "_imText4_3"
        Me._imText4_3.ReadOnly = True
        Me._imText4_3.ReadOnlyBackColor = System.Drawing.SystemColors.Control
        Me._imText4_3.Size = New System.Drawing.Size(63, 23)
        Me._imText4_3.TabIndex = 7
        Me._imText4_3.TabStop = False
        '
        '_ctlGeppo1_0
        '
        Me._ctlGeppo1_0.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._ctlGeppo1_0.Location = New System.Drawing.Point(8, 74)
        Me._ctlGeppo1_0.Name = "_ctlGeppo1_0"
        Me._ctlGeppo1_0.Size = New System.Drawing.Size(615, 33)
        Me._ctlGeppo1_0.TabIndex = 8
        '
        '_ctlGeppo1_1
        '
        Me._ctlGeppo1_1.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._ctlGeppo1_1.Location = New System.Drawing.Point(8, 106)
        Me._ctlGeppo1_1.Name = "_ctlGeppo1_1"
        Me._ctlGeppo1_1.Size = New System.Drawing.Size(615, 33)
        Me._ctlGeppo1_1.TabIndex = 9
        '
        '_ctlGeppo1_2
        '
        Me._ctlGeppo1_2.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._ctlGeppo1_2.Location = New System.Drawing.Point(8, 138)
        Me._ctlGeppo1_2.Name = "_ctlGeppo1_2"
        Me._ctlGeppo1_2.Size = New System.Drawing.Size(615, 33)
        Me._ctlGeppo1_2.TabIndex = 10
        '
        '_Label1_6
        '
        Me._Label1_6.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_6.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_6.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_6.ForeColor = System.Drawing.Color.White
        Me._Label1_6.Location = New System.Drawing.Point(554, 14)
        Me._Label1_6.Name = "_Label1_6"
        Me._Label1_6.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_6.Size = New System.Drawing.Size(65, 23)
        Me._Label1_6.TabIndex = 60
        Me._Label1_6.Text = "���v��"
        Me._Label1_6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_5
        '
        Me._Label1_5.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_5.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_5.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_5.ForeColor = System.Drawing.Color.White
        Me._Label1_5.Location = New System.Drawing.Point(424, 14)
        Me._Label1_5.Name = "_Label1_5"
        Me._Label1_5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_5.Size = New System.Drawing.Size(127, 23)
        Me._Label1_5.TabIndex = 59
        Me._Label1_5.Text = "�H�����v"
        Me._Label1_5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_4
        '
        Me._Label1_4.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_4.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_4.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_4.ForeColor = System.Drawing.Color.White
        Me._Label1_4.Location = New System.Drawing.Point(294, 14)
        Me._Label1_4.Name = "_Label1_4"
        Me._Label1_4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_4.Size = New System.Drawing.Size(127, 23)
        Me._Label1_4.TabIndex = 58
        Me._Label1_4.Text = "���s�\�Z�z"
        Me._Label1_4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_1
        '
        Me._Label1_1.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_1.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_1.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_1.ForeColor = System.Drawing.Color.White
        Me._Label1_1.Location = New System.Drawing.Point(12, 14)
        Me._Label1_1.Name = "_Label1_1"
        Me._Label1_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_1.Size = New System.Drawing.Size(27, 23)
        Me._Label1_1.TabIndex = 55
        Me._Label1_1.Text = "��"
        Me._Label1_1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_3
        '
        Me._Label1_3.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_3.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_3.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_3.ForeColor = System.Drawing.Color.White
        Me._Label1_3.Location = New System.Drawing.Point(164, 14)
        Me._Label1_3.Name = "_Label1_3"
        Me._Label1_3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_3.Size = New System.Drawing.Size(127, 23)
        Me._Label1_3.TabIndex = 54
        Me._Label1_3.Text = "�������z"
        Me._Label1_3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_2
        '
        Me._Label1_2.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_2.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_2.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_2.ForeColor = System.Drawing.Color.White
        Me._Label1_2.Location = New System.Drawing.Point(42, 14)
        Me._Label1_2.Name = "_Label1_2"
        Me._Label1_2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_2.Size = New System.Drawing.Size(119, 23)
        Me._Label1_2.TabIndex = 53
        Me._Label1_2.Text = " ���l"
        Me._Label1_2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Picture1
        '
        Me.Picture1.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Picture1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Picture1.Controls.Add(Me._cmdKey_3)
        Me.Picture1.Controls.Add(Me._cmdKey_12)
        Me.Picture1.Controls.Add(Me._cmdKey_4)
        Me.Picture1.Controls.Add(Me._cmdKey_10)
        Me.Picture1.Controls.Add(Me._cmdKey_6)
        Me.Picture1.Controls.Add(Me._cmdKey_7)
        Me.Picture1.Controls.Add(Me._cmdKey_8)
        Me.Picture1.Controls.Add(Me._cmdKey_9)
        Me.Picture1.Controls.Add(Me._cmdKey_1)
        Me.Picture1.Controls.Add(Me._cmdKey_11)
        Me.Picture1.Controls.Add(Me._cmdKey_2)
        Me.Picture1.Controls.Add(Me._cmdKey_5)
        Me.Picture1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Picture1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Picture1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Picture1.Location = New System.Drawing.Point(0, 668)
        Me.Picture1.Name = "Picture1"
        Me.Picture1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Picture1.Size = New System.Drawing.Size(1016, 51)
        Me.Picture1.TabIndex = 46
        '
        '_cmdKey_3
        '
        Me._cmdKey_3.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_3.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_3.Enabled = False
        Me._cmdKey_3.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_3.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_3.Location = New System.Drawing.Point(166, 4)
        Me._cmdKey_3.Name = "_cmdKey_3"
        Me._cmdKey_3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_3.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_3.TabIndex = 41
        Me._cmdKey_3.Text = "F3"
        Me._cmdKey_3.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_3.UseVisualStyleBackColor = False
        '
        '_cmdKey_12
        '
        Me._cmdKey_12.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_12.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_12.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_12.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_12.Location = New System.Drawing.Point(929, 4)
        Me._cmdKey_12.Name = "_cmdKey_12"
        Me._cmdKey_12.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_12.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_12.TabIndex = 50
        Me._cmdKey_12.Tag = "�I�����܂��B"
        Me._cmdKey_12.Text = "F12" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "�I ��"
        Me._cmdKey_12.UseVisualStyleBackColor = False
        '
        '_cmdKey_4
        '
        Me._cmdKey_4.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_4.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_4.Enabled = False
        Me._cmdKey_4.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_4.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_4.Location = New System.Drawing.Point(246, 4)
        Me._cmdKey_4.Name = "_cmdKey_4"
        Me._cmdKey_4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_4.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_4.TabIndex = 42
        Me._cmdKey_4.Text = "F4"
        Me._cmdKey_4.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_4.UseVisualStyleBackColor = False
        '
        '_cmdKey_10
        '
        Me._cmdKey_10.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_10.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_10.Enabled = False
        Me._cmdKey_10.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_10.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_10.Location = New System.Drawing.Point(769, 4)
        Me._cmdKey_10.Name = "_cmdKey_10"
        Me._cmdKey_10.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_10.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_10.TabIndex = 48
        Me._cmdKey_10.Text = "F10"
        Me._cmdKey_10.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_10.UseVisualStyleBackColor = False
        '
        '_cmdKey_6
        '
        Me._cmdKey_6.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_6.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_6.Enabled = False
        Me._cmdKey_6.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_6.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_6.Location = New System.Drawing.Point(428, 4)
        Me._cmdKey_6.Name = "_cmdKey_6"
        Me._cmdKey_6.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_6.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_6.TabIndex = 44
        Me._cmdKey_6.Text = "F6"
        Me._cmdKey_6.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_6.UseVisualStyleBackColor = False
        '
        '_cmdKey_7
        '
        Me._cmdKey_7.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_7.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_7.Enabled = False
        Me._cmdKey_7.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_7.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_7.Location = New System.Drawing.Point(508, 4)
        Me._cmdKey_7.Name = "_cmdKey_7"
        Me._cmdKey_7.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_7.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_7.TabIndex = 45
        Me._cmdKey_7.Text = "F7"
        Me._cmdKey_7.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_7.UseVisualStyleBackColor = False
        '
        '_cmdKey_8
        '
        Me._cmdKey_8.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_8.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_8.Enabled = False
        Me._cmdKey_8.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_8.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_8.Location = New System.Drawing.Point(588, 4)
        Me._cmdKey_8.Name = "_cmdKey_8"
        Me._cmdKey_8.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_8.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_8.TabIndex = 46
        Me._cmdKey_8.Text = "F8"
        Me._cmdKey_8.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_8.UseVisualStyleBackColor = False
        '
        '_cmdKey_9
        '
        Me._cmdKey_9.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_9.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_9.Enabled = False
        Me._cmdKey_9.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_9.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_9.Location = New System.Drawing.Point(689, 4)
        Me._cmdKey_9.Name = "_cmdKey_9"
        Me._cmdKey_9.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_9.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_9.TabIndex = 47
        Me._cmdKey_9.Text = "F9"
        Me._cmdKey_9.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_9.UseVisualStyleBackColor = False
        '
        '_cmdKey_1
        '
        Me._cmdKey_1.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_1.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_1.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_1.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_1.Location = New System.Drawing.Point(6, 4)
        Me._cmdKey_1.Name = "_cmdKey_1"
        Me._cmdKey_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_1.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_1.TabIndex = 39
        Me._cmdKey_1.Tag = "���̓f�[�^��o�^���܂��B"
        Me._cmdKey_1.Text = "F1" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "�o �^"
        Me._cmdKey_1.UseVisualStyleBackColor = False
        '
        '_cmdKey_11
        '
        Me._cmdKey_11.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_11.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_11.Enabled = False
        Me._cmdKey_11.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_11.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_11.Location = New System.Drawing.Point(849, 4)
        Me._cmdKey_11.Name = "_cmdKey_11"
        Me._cmdKey_11.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_11.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_11.TabIndex = 49
        Me._cmdKey_11.Text = "F11"
        Me._cmdKey_11.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_11.UseVisualStyleBackColor = False
        '
        '_cmdKey_2
        '
        Me._cmdKey_2.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_2.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_2.Enabled = False
        Me._cmdKey_2.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_2.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_2.Location = New System.Drawing.Point(86, 4)
        Me._cmdKey_2.Name = "_cmdKey_2"
        Me._cmdKey_2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_2.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_2.TabIndex = 40
        Me._cmdKey_2.Text = "F2"
        Me._cmdKey_2.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_2.UseVisualStyleBackColor = False
        '
        '_cmdKey_5
        '
        Me._cmdKey_5.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_5.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_5.Enabled = False
        Me._cmdKey_5.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_5.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_5.Location = New System.Drawing.Point(348, 4)
        Me._cmdKey_5.Name = "_cmdKey_5"
        Me._cmdKey_5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_5.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_5.TabIndex = 43
        Me._cmdKey_5.Text = "F5"
        Me._cmdKey_5.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_5.UseVisualStyleBackColor = False
        '
        'StatusBar1
        '
        Me.StatusBar1.Font = New System.Drawing.Font("MS Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.StatusBar1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me._StatusBar1_Panel1, Me.Message})
        Me.StatusBar1.Location = New System.Drawing.Point(0, 719)
        Me.StatusBar1.Name = "StatusBar1"
        Me.StatusBar1.Size = New System.Drawing.Size(1016, 23)
        Me.StatusBar1.TabIndex = 45
        '
        '_StatusBar1_Panel1
        '
        Me._StatusBar1_Panel1.AutoSize = False
        Me._StatusBar1_Panel1.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me._StatusBar1_Panel1.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter
        Me._StatusBar1_Panel1.Margin = New System.Windows.Forms.Padding(0)
        Me._StatusBar1_Panel1.Name = "_StatusBar1_Panel1"
        Me._StatusBar1_Panel1.Size = New System.Drawing.Size(117, 23)
        '
        'Message
        '
        Me.Message.AutoSize = False
        Me.Message.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me.Message.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter
        Me.Message.Margin = New System.Windows.Forms.Padding(0)
        Me.Message.Name = "Message"
        Me.Message.Size = New System.Drawing.Size(886, 23)
        Me.Message.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        '_imText2_2
        '
        Me._imText2_2.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me._imText2_2.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._imText2_2.Location = New System.Drawing.Point(578, 4)
        Me._imText2_2.Name = "_imText2_2"
        Me._imText2_2.ReadOnly = True
        Me._imText2_2.ReadOnlyBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me._imText2_2.Size = New System.Drawing.Size(433, 23)
        Me._imText2_2.TabIndex = 48
        Me._imText2_2.TabStop = False
        '
        '_imText2_0
        '
        Me._imText2_0.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me._imText2_0.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._imText2_0.Location = New System.Drawing.Point(442, 4)
        Me._imText2_0.Name = "_imText2_0"
        Me._imText2_0.ReadOnly = True
        Me._imText2_0.ReadOnlyBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me._imText2_0.Size = New System.Drawing.Size(83, 23)
        Me._imText2_0.TabIndex = 49
        Me._imText2_0.TabStop = False
        '
        '_imText2_1
        '
        Me._imText2_1.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me._imText2_1.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._imText2_1.Location = New System.Drawing.Point(529, 4)
        Me._imText2_1.Name = "_imText2_1"
        Me._imText2_1.ReadOnly = True
        Me._imText2_1.ReadOnlyBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me._imText2_1.Size = New System.Drawing.Size(45, 23)
        Me._imText2_1.TabIndex = 50
        Me._imText2_1.TabStop = False
        '
        '_imText3_0
        '
        Me._imText3_0.CausesValidation = False
        Me._imText3_0.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._imText3_0.Location = New System.Drawing.Point(118, 36)
        Me._imText3_0.Name = "_imText3_0"
        Me._imText3_0.ReadOnly = True
        Me._imText3_0.ReadOnlyBackColor = System.Drawing.SystemColors.Control
        Me._imText3_0.Size = New System.Drawing.Size(73, 23)
        Me._imText3_0.TabIndex = 0
        Me._imText3_0.TabStop = False
        '
        '_Frame1_1
        '
        Me._Frame1_1.BackColor = System.Drawing.SystemColors.Control
        Me._Frame1_1.Controls.Add(Me._imText1_0)
        Me._Frame1_1.Controls.Add(Me._imDate1_0)
        Me._Frame1_1.Controls.Add(Me._imDate1_1)
        Me._Frame1_1.Controls.Add(Me._imDate1_2)
        Me._Frame1_1.Controls.Add(Me._imText1_1)
        Me._Frame1_1.Controls.Add(Me._Label1_19)
        Me._Frame1_1.Controls.Add(Me._Label1_17)
        Me._Frame1_1.Controls.Add(Me._Label1_16)
        Me._Frame1_1.Controls.Add(Me._Label1_18)
        Me._Frame1_1.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Frame1_1.Location = New System.Drawing.Point(6, 270)
        Me._Frame1_1.Name = "_Frame1_1"
        Me._Frame1_1.Padding = New System.Windows.Forms.Padding(0)
        Me._Frame1_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Frame1_1.Size = New System.Drawing.Size(648, 97)
        Me._Frame1_1.TabIndex = 18
        Me._Frame1_1.TabStop = False
        '
        '_imText1_0
        '
        Me._imText1_0.DisabledBackColor = System.Drawing.SystemColors.Window
        Me._imText1_0.DisabledForeColor = System.Drawing.SystemColors.WindowText
        Me._imText1_0.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._imText1_0.ImeMode = System.Windows.Forms.ImeMode.[On]
        Me._imText1_0.Location = New System.Drawing.Point(256, 40)
        Me._imText1_0.Name = "_imText1_0"
        Me._imText1_0.ReadOnlyForeColor = System.Drawing.SystemColors.WindowText
        Me._imText1_0.Size = New System.Drawing.Size(281, 23)
        Me._imText1_0.TabIndex = 22
        Me._imText1_0.Tag = "���l����͂��ĉ������B"
        '
        '_imDate1_0
        '
        Me._imDate1_0.DisabledBackColor = System.Drawing.SystemColors.Window
        Me._imDate1_0.DisabledForeColor = System.Drawing.SystemColors.WindowText
        Me._imDate1_0.DropDown.AutoHideTouchKeyboard = GrapeCity.Win.Editors.AutoHideTouchKeyboard.None
        DateLiteralField1.Text = "/"
        DateLiteralField2.Text = "/"
        Me._imDate1_0.Fields.AddRange(New GrapeCity.Win.Editors.Fields.DateField() {DateYearField1, DateLiteralField1, DateMonthField1, DateLiteralField2, DateDayField1})
        Me._imDate1_0.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._imDate1_0.Location = New System.Drawing.Point(112, 14)
        Me._imDate1_0.Name = "_imDate1_0"
        Me._imDate1_0.ReadOnlyForeColor = System.Drawing.SystemColors.WindowText
        Me._imDate1_0.SideButtons.AddRange(New GrapeCity.Win.Editors.SideButtonBase() {Me.DropDownButton1})
        Me._imDate1_0.Size = New System.Drawing.Size(117, 23)
        Me._imDate1_0.TabIndex = 19
        Me._imDate1_0.Tag = "���H�N��������͂��ĉ������B"
        Me._imDate1_0.Value = New Date(2021, 8, 12, 0, 0, 0, 0)
        '
        'DropDownButton1
        '
        Me.DropDownButton1.Name = "DropDownButton1"
        '
        '_imDate1_1
        '
        Me._imDate1_1.DisabledBackColor = System.Drawing.SystemColors.Window
        Me._imDate1_1.DisabledForeColor = System.Drawing.SystemColors.WindowText
        DateLiteralField3.Text = "/"
        DateLiteralField4.Text = "/"
        Me._imDate1_1.Fields.AddRange(New GrapeCity.Win.Editors.Fields.DateField() {DateYearField2, DateLiteralField3, DateMonthField2, DateLiteralField4, DateDayField2})
        Me._imDate1_1.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._imDate1_1.Location = New System.Drawing.Point(112, 40)
        Me._imDate1_1.Name = "_imDate1_1"
        Me._imDate1_1.ReadOnlyForeColor = System.Drawing.SystemColors.WindowText
        Me._imDate1_1.SideButtons.AddRange(New GrapeCity.Win.Editors.SideButtonBase() {Me.DropDownButton2})
        Me._imDate1_1.Size = New System.Drawing.Size(117, 23)
        Me._imDate1_1.TabIndex = 20
        Me._imDate1_1.Tag = "�v�H�N��������͂��ĉ������B"
        Me._imDate1_1.Value = New Date(2021, 8, 12, 0, 0, 0, 0)
        '
        'DropDownButton2
        '
        Me.DropDownButton2.Name = "DropDownButton2"
        '
        '_imDate1_2
        '
        Me._imDate1_2.DisabledBackColor = System.Drawing.SystemColors.Window
        Me._imDate1_2.DisabledForeColor = System.Drawing.SystemColors.WindowText
        DateLiteralField5.Text = "/"
        DateLiteralField6.Text = "/"
        Me._imDate1_2.Fields.AddRange(New GrapeCity.Win.Editors.Fields.DateField() {DateYearField3, DateLiteralField5, DateMonthField3, DateLiteralField6, DateDayField3})
        Me._imDate1_2.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._imDate1_2.Location = New System.Drawing.Point(112, 66)
        Me._imDate1_2.Name = "_imDate1_2"
        Me._imDate1_2.ReadOnlyForeColor = System.Drawing.SystemColors.WindowText
        Me._imDate1_2.SideButtons.AddRange(New GrapeCity.Win.Editors.SideButtonBase() {Me.DropDownButton3})
        Me._imDate1_2.Size = New System.Drawing.Size(117, 23)
        Me._imDate1_2.TabIndex = 21
        Me._imDate1_2.Tag = "�����N��������͂��ĉ������B"
        Me._imDate1_2.Value = New Date(2021, 8, 12, 0, 0, 0, 0)
        '
        'DropDownButton3
        '
        Me.DropDownButton3.Name = "DropDownButton3"
        '
        '_imText1_1
        '
        Me._imText1_1.DisabledBackColor = System.Drawing.SystemColors.Window
        Me._imText1_1.DisabledForeColor = System.Drawing.SystemColors.WindowText
        Me._imText1_1.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._imText1_1.ImeMode = System.Windows.Forms.ImeMode.[On]
        Me._imText1_1.Location = New System.Drawing.Point(256, 66)
        Me._imText1_1.Name = "_imText1_1"
        Me._imText1_1.ReadOnlyForeColor = System.Drawing.SystemColors.WindowText
        Me._imText1_1.Size = New System.Drawing.Size(281, 23)
        Me._imText1_1.TabIndex = 23
        Me._imText1_1.Tag = "���l����͂��ĉ������B"
        '
        '_Label1_19
        '
        Me._Label1_19.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_19.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_19.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_19.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_19.ForeColor = System.Drawing.Color.White
        Me._Label1_19.Location = New System.Drawing.Point(256, 14)
        Me._Label1_19.Name = "_Label1_19"
        Me._Label1_19.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_19.Size = New System.Drawing.Size(282, 23)
        Me._Label1_19.TabIndex = 65
        Me._Label1_19.Text = " ���̑�"
        Me._Label1_19.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        '_Label1_17
        '
        Me._Label1_17.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_17.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_17.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_17.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_17.ForeColor = System.Drawing.Color.White
        Me._Label1_17.Location = New System.Drawing.Point(8, 40)
        Me._Label1_17.Name = "_Label1_17"
        Me._Label1_17.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_17.Size = New System.Drawing.Size(100, 23)
        Me._Label1_17.TabIndex = 64
        Me._Label1_17.Text = "�v �H"
        Me._Label1_17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_16
        '
        Me._Label1_16.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_16.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_16.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_16.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_16.ForeColor = System.Drawing.Color.White
        Me._Label1_16.Location = New System.Drawing.Point(8, 14)
        Me._Label1_16.Name = "_Label1_16"
        Me._Label1_16.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_16.Size = New System.Drawing.Size(100, 23)
        Me._Label1_16.TabIndex = 63
        Me._Label1_16.Text = "�� �H"
        Me._Label1_16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_18
        '
        Me._Label1_18.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_18.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_18.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_18.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_18.ForeColor = System.Drawing.Color.White
        Me._Label1_18.Location = New System.Drawing.Point(8, 66)
        Me._Label1_18.Name = "_Label1_18"
        Me._Label1_18.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_18.Size = New System.Drawing.Size(100, 23)
        Me._Label1_18.TabIndex = 62
        Me._Label1_18.Text = "�� ��"
        Me._Label1_18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_Label1_0
        '
        Me._Label1_0.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_0.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_0.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_0.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_0.ForeColor = System.Drawing.Color.White
        Me._Label1_0.Location = New System.Drawing.Point(14, 36)
        Me._Label1_0.Name = "_Label1_0"
        Me._Label1_0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_0.Size = New System.Drawing.Size(100, 23)
        Me._Label1_0.TabIndex = 51
        Me._Label1_0.Text = "���N��"
        Me._Label1_0.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblTitle
        '
        Me.lblTitle.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblTitle.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTitle.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblTitle.Font = New System.Drawing.Font("MS Mincho", 20.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblTitle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.lblTitle.Location = New System.Drawing.Point(0, 0)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblTitle.Size = New System.Drawing.Size(1015, 31)
        Me.lblTitle.TabIndex = 47
        Me.lblTitle.Text = " �H������ꗗ�i�y�؁j"
        '
        'FpSpread1
        '
        Me.FpSpread1.AccessibleDescription = ""
        Me.FpSpread1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.FpSpread1.FocusRenderer = DefaultFocusIndicatorRenderer1
        Me.FpSpread1.HorizontalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.FpSpread1.HorizontalScrollBar.Name = ""
        Me.FpSpread1.HorizontalScrollBar.Renderer = DefaultScrollBarRenderer1
        Me.FpSpread1.HorizontalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.Never
        Me.FpSpread1.Location = New System.Drawing.Point(6, 372)
        Me.FpSpread1.Name = "FpSpread1"
        NamedStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        NamedStyle1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        NamedStyle1.Locked = False
        NamedStyle2.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        NamedStyle2.Font = New System.Drawing.Font("MS Mincho", 11.0!, System.Drawing.FontStyle.Bold)
        NamedStyle2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        NamedStyle2.Locked = False
        NamedStyle3.BackColor = System.Drawing.Color.Empty
        NamedStyle3.Border = ComplexBorder1
        NamedStyle3.ForeColor = System.Drawing.Color.Empty
        NamedStyle4.BackColor = System.Drawing.Color.Empty
        NamedStyle4.Border = ComplexBorder1
        NamedStyle4.ForeColor = System.Drawing.Color.Empty
        Me.FpSpread1.RowSplitBoxPolicy = FarPoint.Win.Spread.SplitBoxPolicy.Never
        Me.FpSpread1.ScrollBarTrackPolicy = FarPoint.Win.Spread.ScrollBarTrackPolicy.Vertical
        Me.FpSpread1.SelectionBlockOptions = FarPoint.Win.Spread.SelectionBlockOptions.None
        Me.FpSpread1.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.FpSpread1_Sheet1})
        Me.FpSpread1.Size = New System.Drawing.Size(1000, 273)
        Me.FpSpread1.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Classic
        Me.FpSpread1.NamedStyles.AddRange(New FarPoint.Win.Spread.NamedStyle() {NamedStyle1, NamedStyle2, NamedStyle3, NamedStyle4})
        Me.FpSpread1.TabIndex = 79
        Me.FpSpread1.TabStop = false
        TipAppearance1.BackColor = System.Drawing.SystemColors.Info
        TipAppearance1.Font = New System.Drawing.Font("MS PGothic", 9!)
        TipAppearance1.ForeColor = System.Drawing.SystemColors.InfoText
        Me.FpSpread1.TextTipAppearance = TipAppearance1
        Me.FpSpread1.VerticalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.FpSpread1.VerticalScrollBar.Name = ""
        Me.FpSpread1.VerticalScrollBar.Renderer = DefaultScrollBarRenderer2
        Me.FpSpread1.VerticalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded
        Me.FpSpread1.VisualStyles = FarPoint.Win.VisualStyles.Off
        '
        'FpSpread1_Sheet1
        '
        Me.FpSpread1_Sheet1.Reset
        Me.FpSpread1_Sheet1.SheetName = "Sheet1"
        'Formulas and custom names must be loaded with R1C1 reference style
        Me.FpSpread1_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1
        Me.FpSpread1_Sheet1.ColumnCount = 10
        Me.FpSpread1_Sheet1.RowCount = 100
        Me.FpSpread1_Sheet1.ActiveSkin = FarPoint.Win.Spread.DefaultSkins.Default
        Me.FpSpread1_Sheet1.Cells.Get(0, 0).Value = "A-00"
        TextCellType1.Static = true
        Me.FpSpread1_Sheet1.Cells.Get(0, 1).CellType = TextCellType1
        Me.FpSpread1_Sheet1.Cells.Get(0, 1).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Left
        Me.FpSpread1_Sheet1.Cells.Get(0, 1).Value = "�P�Q�R�S�T�U�V�W�X�O"
        Me.FpSpread1_Sheet1.Cells.Get(0, 1).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread1_Sheet1.Cells.Get(0, 2).Value = "9,999,999,999"
        Me.FpSpread1_Sheet1.Cells.Get(1, 0).Value = "B-01"
        Me.FpSpread1_Sheet1.Cells.Get(1, 1).Value = "�������`����"
        Me.FpSpread1_Sheet1.Cells.Get(2, 0).Value = "B-02"
        Me.FpSpread1_Sheet1.Cells.Get(2, 1).Value = "���݉^��"
        Me.FpSpread1_Sheet1.Cells.Get(3, 0).Value = "B-03"
        Me.FpSpread1_Sheet1.Cells.Get(3, 1).Value = "���ݘJ����"
        Me.FpSpread1_Sheet1.Cells.Get(4, 0).Value = "B-04"
        Me.FpSpread1_Sheet1.Cells.Get(4, 1).Value = "�n��A�ƒ�"
        Me.FpSpread1_Sheet1.Cells.Get(5, 0).Value = "B-05"
        Me.FpSpread1_Sheet1.Cells.Get(5, 1).Value = "�c�U��"
        Me.FpSpread1_Sheet1.Cells.Get(6, 0).Value = "B-06"
        Me.FpSpread1_Sheet1.Cells.Get(6, 1).Value = "���ݓ���"
        Me.FpSpread1_Sheet1.Cells.Get(7, 0).Value = "B-07"
        Me.FpSpread1_Sheet1.Cells.Get(7, 1).Value = "�⏞��"
        Me.FpSpread1_Sheet1.Cells.Get(8, 0).Value = "B-08"
        Me.FpSpread1_Sheet1.Cells.Get(8, 1).Value = "�{�H�i���Ǘ���"
        Me.FpSpread1_Sheet1.Cells.Get(9, 0).Value = "B-09"
        Me.FpSpread1_Sheet1.Cells.Get(9, 1).Value = "�G�H���"
        Me.FpSpread1_Sheet1.Cells.Get(10, 0).Value = "B-10"
        Me.FpSpread1_Sheet1.Cells.Get(10, 1).Value = "�@�B�Ǘ���"
        Me.FpSpread1_Sheet1.Cells.Get(11, 0).Value = "B-11"
        Me.FpSpread1_Sheet1.Cells.Get(11, 1).Value = "���S�Ǘ���"
        Me.FpSpread1_Sheet1.Cells.Get(12, 0).Value = "B-12"
        Me.FpSpread1_Sheet1.Cells.Get(12, 1).Value = "�����o��"
        Me.FpSpread1_Sheet1.Cells.Get(13, 0).Value = "C-01"
        Me.FpSpread1_Sheet1.Cells.Get(13, 1).Value = "���͗p�����M��"
        Me.FpSpread1_Sheet1.Cells.Get(14, 0).Value = "C-02"
        Me.FpSpread1_Sheet1.Cells.Get(14, 1).Value = "�d�Ō���"
        Me.FpSpread1_Sheet1.Cells.Get(15, 0).Value = "C-03"
        Me.FpSpread1_Sheet1.Cells.Get(15, 1).Value = "�@�蕟����"
        Me.FpSpread1_Sheet1.Cells.Get(16, 0).Value = "C-04"
        Me.FpSpread1_Sheet1.Cells.Get(16, 1).Value = "����������"
        Me.FpSpread1_Sheet1.Cells.Get(17, 0).Value = "C-05"
        Me.FpSpread1_Sheet1.Cells.Get(17, 1).Value = "�����p�i��"
        Me.FpSpread1_Sheet1.Cells.Get(18, 0).Value = "C-06"
        Me.FpSpread1_Sheet1.Cells.Get(18, 1).Value = "�����ʔ�"
        Me.FpSpread1_Sheet1.Cells.Get(19, 0).Value = "C-07"
        Me.FpSpread1_Sheet1.Cells.Get(19, 1).Value = "�l����"
        Me.FpSpread1_Sheet1.Cells.Get(20, 0).Value = "C-08"
        Me.FpSpread1_Sheet1.Cells.Get(20, 1).Value = "�J���Ǘ���"
        Me.FpSpread1_Sheet1.Cells.Get(21, 0).Value = "C-09"
        Me.FpSpread1_Sheet1.Cells.Get(21, 1).Value = "�ʐM��"
        Me.FpSpread1_Sheet1.Cells.Get(22, 0).Value = "C-10"
        Me.FpSpread1_Sheet1.Cells.Get(22, 1).Value = "�ł����킹���"
        Me.FpSpread1_Sheet1.Cells.Get(23, 0).Value = "C-11"
        Me.FpSpread1_Sheet1.Cells.Get(23, 1).Value = "�G��"
        Me.FpSpread1_Sheet1.ColumnFooter.Columns.Default.Resizable = false
        Me.FpSpread1_Sheet1.ColumnFooter.Columns.Default.SortIndicator = FarPoint.Win.Spread.Model.SortIndicator.None
        Me.FpSpread1_Sheet1.ColumnFooter.Columns.Default.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread1_Sheet1.ColumnFooter.DefaultStyle.BackColor = System.Drawing.Color.Empty
        Me.FpSpread1_Sheet1.ColumnFooter.DefaultStyle.ForeColor = System.Drawing.Color.Empty
        Me.FpSpread1_Sheet1.ColumnFooter.DefaultStyle.Locked = false
        Me.FpSpread1_Sheet1.ColumnFooter.DefaultStyle.Parent = "HeaderDefault"
        Me.FpSpread1_Sheet1.ColumnFooter.DefaultStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread1_Sheet1.ColumnFooter.Rows.Default.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread1_Sheet1.ColumnFooterSheetCornerStyle.BackColor = System.Drawing.Color.Empty
        Me.FpSpread1_Sheet1.ColumnFooterSheetCornerStyle.ForeColor = System.Drawing.Color.Empty
        Me.FpSpread1_Sheet1.ColumnFooterSheetCornerStyle.Locked = false
        Me.FpSpread1_Sheet1.ColumnFooterSheetCornerStyle.Parent = "RowHeaderDefault"
        Me.FpSpread1_Sheet1.ColumnFooterSheetCornerStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread1_Sheet1.ColumnHeader.AutoText = FarPoint.Win.Spread.HeaderAutoText.Blank
        Me.FpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 0).Value = "�H��"
        Me.FpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = "���@��"
        Me.FpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 3).Value = "�݌v���{���z"
        Me.FpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 4).Value = "���㏊�v����"
        Me.FpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 5).Value = "���{�������z"
        Me.FpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 6).Value = "�\�Z�Δ�"
        Me.FpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 7).Value = "�ύX����"
        Me.FpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 8).Value = "������z"
        Me.FpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 9).Value = "�݌v���z"
        Me.FpSpread1_Sheet1.ColumnHeader.Columns.Default.CanFocus = false
        Me.FpSpread1_Sheet1.ColumnHeader.Columns.Default.Resizable = false
        Me.FpSpread1_Sheet1.ColumnHeader.Columns.Default.SortIndicator = FarPoint.Win.Spread.Model.SortIndicator.None
        Me.FpSpread1_Sheet1.ColumnHeader.Columns.Default.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread1_Sheet1.ColumnHeader.DefaultStyle.BackColor = System.Drawing.Color.Empty
        Me.FpSpread1_Sheet1.ColumnHeader.DefaultStyle.Border = ComplexBorder2
        Me.FpSpread1_Sheet1.ColumnHeader.DefaultStyle.CanFocus = false
        Me.FpSpread1_Sheet1.ColumnHeader.DefaultStyle.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.FpSpread1_Sheet1.ColumnHeader.DefaultStyle.ForeColor = System.Drawing.Color.Empty
        Me.FpSpread1_Sheet1.ColumnHeader.DefaultStyle.Locked = false
        Me.FpSpread1_Sheet1.ColumnHeader.DefaultStyle.Parent = "HeaderDefault"
        Me.FpSpread1_Sheet1.ColumnHeader.DefaultStyle.Renderer = CustomSpdHeader9
        Me.FpSpread1_Sheet1.ColumnHeader.DefaultStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread1_Sheet1.ColumnHeader.Rows.Default.CanFocus = false
        Me.FpSpread1_Sheet1.ColumnHeader.Rows.Default.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread1_Sheet1.ColumnHeader.Rows.Get(0).Height = 37!
        Me.FpSpread1_Sheet1.Columns.Default.CanFocus = false
        Me.FpSpread1_Sheet1.Columns.Default.Resizable = false
        Me.FpSpread1_Sheet1.Columns.Default.SortIndicator = FarPoint.Win.Spread.Model.SortIndicator.None
        TextCellType2.Static = true
        Me.FpSpread1_Sheet1.Columns.Get(0).CellType = TextCellType2
        Me.FpSpread1_Sheet1.Columns.Get(0).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.FpSpread1_Sheet1.Columns.Get(0).Label = "�H��"
        Me.FpSpread1_Sheet1.Columns.Get(0).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread1_Sheet1.Columns.Get(0).Width = 48!
        Me.FpSpread1_Sheet1.Columns.Get(1).Border = ComplexBorder1
        TextCellType3.Static = true
        Me.FpSpread1_Sheet1.Columns.Get(1).CellType = TextCellType3
        Me.FpSpread1_Sheet1.Columns.Get(1).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Left
        Me.FpSpread1_Sheet1.Columns.Get(1).Label = "���@��"
        Me.FpSpread1_Sheet1.Columns.Get(1).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread1_Sheet1.Columns.Get(1).Width = 148!
        Me.FpSpread1_Sheet1.Columns.Get(2).Border = ComplexBorder1
        TextCellType4.Static = true
        Me.FpSpread1_Sheet1.Columns.Get(2).CellType = TextCellType4
        Me.FpSpread1_Sheet1.Columns.Get(2).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Right
        Me.FpSpread1_Sheet1.Columns.Get(2).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread1_Sheet1.Columns.Get(2).Width = 124!
        TextCellType5.Static = true
        Me.FpSpread1_Sheet1.Columns.Get(3).CellType = TextCellType5
        Me.FpSpread1_Sheet1.Columns.Get(3).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Right
        Me.FpSpread1_Sheet1.Columns.Get(3).Label = "�݌v���{���z"
        Me.FpSpread1_Sheet1.Columns.Get(3).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread1_Sheet1.Columns.Get(3).Width = 124!
        Me.FpSpread1_Sheet1.Columns.Get(4).CellType = TextCellType5
        Me.FpSpread1_Sheet1.Columns.Get(4).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Right
        Me.FpSpread1_Sheet1.Columns.Get(4).Label = "���㏊�v����"
        Me.FpSpread1_Sheet1.Columns.Get(4).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread1_Sheet1.Columns.Get(4).Width = 124!
        Me.FpSpread1_Sheet1.Columns.Get(5).CellType = TextCellType5
        Me.FpSpread1_Sheet1.Columns.Get(5).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Right
        Me.FpSpread1_Sheet1.Columns.Get(5).Label = "���{�������z"
        Me.FpSpread1_Sheet1.Columns.Get(5).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread1_Sheet1.Columns.Get(5).Width = 124!
        Me.FpSpread1_Sheet1.Columns.Get(6).CellType = TextCellType5
        Me.FpSpread1_Sheet1.Columns.Get(6).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Right
        Me.FpSpread1_Sheet1.Columns.Get(6).Label = "�\�Z�Δ�"
        Me.FpSpread1_Sheet1.Columns.Get(6).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread1_Sheet1.Columns.Get(6).Width = 124!
        Me.FpSpread1_Sheet1.Columns.Get(7).CellType = TextCellType5
        Me.FpSpread1_Sheet1.Columns.Get(7).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Right
        Me.FpSpread1_Sheet1.Columns.Get(7).Label = "�ύX����"
        Me.FpSpread1_Sheet1.Columns.Get(7).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread1_Sheet1.Columns.Get(7).Width = 124!
        Me.FpSpread1_Sheet1.Columns.Get(8).CellType = TextCellType5
        Me.FpSpread1_Sheet1.Columns.Get(8).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Right
        Me.FpSpread1_Sheet1.Columns.Get(8).Label = "������z"
        Me.FpSpread1_Sheet1.Columns.Get(8).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread1_Sheet1.Columns.Get(8).Visible = false
        Me.FpSpread1_Sheet1.Columns.Get(8).Width = 0!
        Me.FpSpread1_Sheet1.Columns.Get(9).CellType = TextCellType5
        Me.FpSpread1_Sheet1.Columns.Get(9).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Right
        Me.FpSpread1_Sheet1.Columns.Get(9).Label = "�݌v���z"
        Me.FpSpread1_Sheet1.Columns.Get(9).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread1_Sheet1.Columns.Get(9).Visible = false
        Me.FpSpread1_Sheet1.Columns.Get(9).Width = 0!
        Me.FpSpread1_Sheet1.DefaultStyle.BackColor = System.Drawing.Color.Empty
        Me.FpSpread1_Sheet1.DefaultStyle.CanFocus = false
        Me.FpSpread1_Sheet1.DefaultStyle.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128,Byte))
        Me.FpSpread1_Sheet1.DefaultStyle.ForeColor = System.Drawing.Color.Empty
        Me.FpSpread1_Sheet1.DefaultStyle.Locked = true
        Me.FpSpread1_Sheet1.DefaultStyle.Parent = "DataAreaDefault"
        Me.FpSpread1_Sheet1.FilterBar.DefaultStyle.BackColor = System.Drawing.Color.Empty
        Me.FpSpread1_Sheet1.FilterBar.DefaultStyle.ForeColor = System.Drawing.Color.Empty
        Me.FpSpread1_Sheet1.FilterBar.DefaultStyle.Locked = false
        Me.FpSpread1_Sheet1.FilterBar.DefaultStyle.Parent = "FilterBarDefault"
        Me.FpSpread1_Sheet1.FilterBar.DefaultStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread1_Sheet1.FilterBarHeaderStyle.BackColor = System.Drawing.Color.Empty
        Me.FpSpread1_Sheet1.FilterBarHeaderStyle.ForeColor = System.Drawing.Color.Empty
        Me.FpSpread1_Sheet1.FilterBarHeaderStyle.Locked = false
        Me.FpSpread1_Sheet1.FilterBarHeaderStyle.Parent = "RowHeaderDefault"
        Me.FpSpread1_Sheet1.FilterBarHeaderStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread1_Sheet1.OperationMode = FarPoint.Win.Spread.OperationMode.[ReadOnly]
        Me.FpSpread1_Sheet1.Protect = true
        Me.FpSpread1_Sheet1.RowHeader.Columns.Default.CanFocus = false
        Me.FpSpread1_Sheet1.RowHeader.Columns.Default.Resizable = false
        Me.FpSpread1_Sheet1.RowHeader.Columns.Default.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread1_Sheet1.RowHeader.Columns.Get(0).Width = 37!
        Me.FpSpread1_Sheet1.RowHeader.DefaultStyle.BackColor = System.Drawing.Color.Empty
        Me.FpSpread1_Sheet1.RowHeader.DefaultStyle.Border = ComplexBorder2
        Me.FpSpread1_Sheet1.RowHeader.DefaultStyle.CanFocus = false
        Me.FpSpread1_Sheet1.RowHeader.DefaultStyle.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128,Byte))
        Me.FpSpread1_Sheet1.RowHeader.DefaultStyle.ForeColor = System.Drawing.Color.Empty
        Me.FpSpread1_Sheet1.RowHeader.DefaultStyle.Locked = false
        Me.FpSpread1_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderDefault"
        Me.FpSpread1_Sheet1.RowHeader.DefaultStyle.Renderer = CustomSpdHeader10
        Me.FpSpread1_Sheet1.RowHeader.DefaultStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread1_Sheet1.RowHeader.Rows.Default.CanFocus = false
        Me.FpSpread1_Sheet1.RowHeader.Rows.Default.Resizable = false
        Me.FpSpread1_Sheet1.RowHeader.Rows.Default.Visible = true
        Me.FpSpread1_Sheet1.RowHeader.Rows.Default.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread1_Sheet1.Rows.Default.CanFocus = false
        Me.FpSpread1_Sheet1.Rows.Default.Height = 18!
        Me.FpSpread1_Sheet1.Rows.Default.Resizable = false
        Me.FpSpread1_Sheet1.Rows.Default.Visible = true
        Me.FpSpread1_Sheet1.SheetCornerStyle.BackColor = System.Drawing.Color.Empty
        Me.FpSpread1_Sheet1.SheetCornerStyle.ForeColor = System.Drawing.Color.Empty
        Me.FpSpread1_Sheet1.SheetCornerStyle.Locked = false
        Me.FpSpread1_Sheet1.SheetCornerStyle.Parent = "RowHeaderDefault"
        Me.FpSpread1_Sheet1.SheetCornerStyle.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread1_Sheet1.SheetCornerStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread1_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1
        '
        'FpSpread2
        '
        Me.FpSpread2.AccessibleDescription = "FpSpread2, Sheet1, Row 0, Column 0"
        Me.FpSpread2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.FpSpread2.FocusRenderer = DefaultFocusIndicatorRenderer1
        Me.FpSpread2.HorizontalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.FpSpread2.HorizontalScrollBar.Name = ""
        Me.FpSpread2.HorizontalScrollBar.Renderer = DefaultScrollBarRenderer3
        Me.FpSpread2.HorizontalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.Never
        Me.FpSpread2.Location = New System.Drawing.Point(6, 623)
        Me.FpSpread2.Name = "FpSpread2"
        NamedStyle5.BackColor = System.Drawing.Color.FromArgb(CType(CType(255,Byte),Integer), CType(CType(255,Byte),Integer), CType(CType(255,Byte),Integer))
        NamedStyle5.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64,Byte),Integer), CType(CType(0,Byte),Integer), CType(CType(64,Byte),Integer))
        NamedStyle5.Locked = false
        NamedStyle6.BackColor = System.Drawing.Color.FromArgb(CType(CType(255,Byte),Integer), CType(CType(255,Byte),Integer), CType(CType(255,Byte),Integer))
        NamedStyle6.Font = New System.Drawing.Font("MS Mincho", 11!, System.Drawing.FontStyle.Bold)
        NamedStyle6.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64,Byte),Integer), CType(CType(0,Byte),Integer), CType(CType(64,Byte),Integer))
        NamedStyle6.Locked = false
        NamedStyle7.BackColor = System.Drawing.Color.Empty
        NamedStyle7.Border = ComplexBorder3
        NamedStyle7.ForeColor = System.Drawing.Color.Empty
        NamedStyle8.BackColor = System.Drawing.Color.Empty
        NamedStyle8.Border = ComplexBorder3
        NamedStyle8.ForeColor = System.Drawing.Color.Empty
        Me.FpSpread2.ScrollBarTrackPolicy = FarPoint.Win.Spread.ScrollBarTrackPolicy.Vertical
        Me.FpSpread2.SelectionBlockOptions = FarPoint.Win.Spread.SelectionBlockOptions.None
        Me.FpSpread2.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.FpSpread2_Sheet1})
        Me.FpSpread2.Size = New System.Drawing.Size(1000, 40)
        Me.FpSpread2.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Classic
        Me.FpSpread2.NamedStyles.AddRange(New FarPoint.Win.Spread.NamedStyle() {NamedStyle5, NamedStyle6, NamedStyle7, NamedStyle8})
        Me.FpSpread2.TabIndex = 80
        Me.FpSpread2.TabStop = false
        TipAppearance2.BackColor = System.Drawing.SystemColors.Info
        TipAppearance2.Font = New System.Drawing.Font("MS PGothic", 9!)
        TipAppearance2.ForeColor = System.Drawing.SystemColors.InfoText
        Me.FpSpread2.TextTipAppearance = TipAppearance2
        Me.FpSpread2.VerticalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.FpSpread2.VerticalScrollBar.Name = ""
        Me.FpSpread2.VerticalScrollBar.Renderer = DefaultScrollBarRenderer4
        Me.FpSpread2.VerticalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.Never
        Me.FpSpread2.VisualStyles = FarPoint.Win.VisualStyles.Off
        '
        'FpSpread2_Sheet1
        '
        Me.FpSpread2_Sheet1.Reset
        Me.FpSpread2_Sheet1.SheetName = "Sheet1"
        'Formulas and custom names must be loaded with R1C1 reference style
        Me.FpSpread2_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1
        Me.FpSpread2_Sheet1.ColumnCount = 10
        Me.FpSpread2_Sheet1.RowCount = 1
        Me.FpSpread2_Sheet1.ActiveSkin = FarPoint.Win.Spread.DefaultSkins.Default
        Me.FpSpread2_Sheet1.Cells.Get(0, 0).BackColor = System.Drawing.Color.FromArgb(CType(CType(255,Byte),Integer), CType(CType(223,Byte),Integer), CType(CType(255,Byte),Integer))
        Me.FpSpread2_Sheet1.Cells.Get(0, 0).Font = Nothing
        Me.FpSpread2_Sheet1.Cells.Get(0, 0).ForeColor = System.Drawing.Color.FromArgb(CType(CType(0,Byte),Integer), CType(CType(0,Byte),Integer), CType(CType(0,Byte),Integer))
        Me.FpSpread2_Sheet1.Cells.Get(0, 0).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Left
        Me.FpSpread2_Sheet1.Cells.Get(0, 0).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread2_Sheet1.Cells.Get(0, 1).BackColor = System.Drawing.Color.FromArgb(CType(CType(255,Byte),Integer), CType(CType(223,Byte),Integer), CType(CType(255,Byte),Integer))
        Me.FpSpread2_Sheet1.Cells.Get(0, 1).Font = Nothing
        Me.FpSpread2_Sheet1.Cells.Get(0, 1).ForeColor = System.Drawing.Color.FromArgb(CType(CType(0,Byte),Integer), CType(CType(0,Byte),Integer), CType(CType(0,Byte),Integer))
        Me.FpSpread2_Sheet1.Cells.Get(0, 1).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Left
        Me.FpSpread2_Sheet1.Cells.Get(0, 1).Value = "���v"
        Me.FpSpread2_Sheet1.Cells.Get(0, 1).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread2_Sheet1.Cells.Get(0, 2).BackColor = System.Drawing.Color.FromArgb(CType(CType(221,Byte),Integer), CType(CType(255,Byte),Integer), CType(CType(255,Byte),Integer))
        Me.FpSpread2_Sheet1.Cells.Get(0, 2).Font = Nothing
        Me.FpSpread2_Sheet1.Cells.Get(0, 2).ForeColor = System.Drawing.Color.FromArgb(CType(CType(0,Byte),Integer), CType(CType(0,Byte),Integer), CType(CType(0,Byte),Integer))
        Me.FpSpread2_Sheet1.Cells.Get(0, 2).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Right
        Me.FpSpread2_Sheet1.Cells.Get(0, 2).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread2_Sheet1.Cells.Get(0, 3).BackColor = System.Drawing.Color.FromArgb(CType(CType(221,Byte),Integer), CType(CType(255,Byte),Integer), CType(CType(255,Byte),Integer))
        Me.FpSpread2_Sheet1.Cells.Get(0, 3).Font = Nothing
        Me.FpSpread2_Sheet1.Cells.Get(0, 3).ForeColor = System.Drawing.Color.FromArgb(CType(CType(0,Byte),Integer), CType(CType(0,Byte),Integer), CType(CType(0,Byte),Integer))
        Me.FpSpread2_Sheet1.Cells.Get(0, 3).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Right
        Me.FpSpread2_Sheet1.Cells.Get(0, 3).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread2_Sheet1.Cells.Get(0, 4).BackColor = System.Drawing.Color.FromArgb(CType(CType(221,Byte),Integer), CType(CType(255,Byte),Integer), CType(CType(255,Byte),Integer))
        Me.FpSpread2_Sheet1.Cells.Get(0, 4).Font = Nothing
        Me.FpSpread2_Sheet1.Cells.Get(0, 4).ForeColor = System.Drawing.Color.FromArgb(CType(CType(0,Byte),Integer), CType(CType(0,Byte),Integer), CType(CType(0,Byte),Integer))
        Me.FpSpread2_Sheet1.Cells.Get(0, 4).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Right
        Me.FpSpread2_Sheet1.Cells.Get(0, 4).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread2_Sheet1.Cells.Get(0, 5).BackColor = System.Drawing.Color.FromArgb(CType(CType(221,Byte),Integer), CType(CType(255,Byte),Integer), CType(CType(255,Byte),Integer))
        Me.FpSpread2_Sheet1.Cells.Get(0, 5).Font = Nothing
        Me.FpSpread2_Sheet1.Cells.Get(0, 5).ForeColor = System.Drawing.Color.FromArgb(CType(CType(0,Byte),Integer), CType(CType(0,Byte),Integer), CType(CType(0,Byte),Integer))
        Me.FpSpread2_Sheet1.Cells.Get(0, 5).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Right
        Me.FpSpread2_Sheet1.Cells.Get(0, 5).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread2_Sheet1.Cells.Get(0, 6).BackColor = System.Drawing.Color.FromArgb(CType(CType(221,Byte),Integer), CType(CType(255,Byte),Integer), CType(CType(255,Byte),Integer))
        Me.FpSpread2_Sheet1.Cells.Get(0, 6).Font = Nothing
        Me.FpSpread2_Sheet1.Cells.Get(0, 6).ForeColor = System.Drawing.Color.FromArgb(CType(CType(0,Byte),Integer), CType(CType(0,Byte),Integer), CType(CType(0,Byte),Integer))
        Me.FpSpread2_Sheet1.Cells.Get(0, 6).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Right
        Me.FpSpread2_Sheet1.Cells.Get(0, 6).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread2_Sheet1.Cells.Get(0, 7).BackColor = System.Drawing.Color.FromArgb(CType(CType(221,Byte),Integer), CType(CType(255,Byte),Integer), CType(CType(255,Byte),Integer))
        Me.FpSpread2_Sheet1.Cells.Get(0, 7).Font = Nothing
        Me.FpSpread2_Sheet1.Cells.Get(0, 7).ForeColor = System.Drawing.Color.FromArgb(CType(CType(0,Byte),Integer), CType(CType(0,Byte),Integer), CType(CType(0,Byte),Integer))
        Me.FpSpread2_Sheet1.Cells.Get(0, 7).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Right
        Me.FpSpread2_Sheet1.Cells.Get(0, 7).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread2_Sheet1.ColumnFooter.Columns.Default.Resizable = false
        Me.FpSpread2_Sheet1.ColumnFooter.Columns.Default.SortIndicator = FarPoint.Win.Spread.Model.SortIndicator.None
        Me.FpSpread2_Sheet1.ColumnFooter.Columns.Default.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread2_Sheet1.ColumnFooter.DefaultStyle.BackColor = System.Drawing.Color.Empty
        Me.FpSpread2_Sheet1.ColumnFooter.DefaultStyle.ForeColor = System.Drawing.Color.Empty
        Me.FpSpread2_Sheet1.ColumnFooter.DefaultStyle.Locked = false
        Me.FpSpread2_Sheet1.ColumnFooter.DefaultStyle.Parent = "HeaderDefault"
        Me.FpSpread2_Sheet1.ColumnFooter.DefaultStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread2_Sheet1.ColumnFooter.Rows.Default.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread2_Sheet1.ColumnFooterSheetCornerStyle.BackColor = System.Drawing.Color.Empty
        Me.FpSpread2_Sheet1.ColumnFooterSheetCornerStyle.ForeColor = System.Drawing.Color.Empty
        Me.FpSpread2_Sheet1.ColumnFooterSheetCornerStyle.Locked = false
        Me.FpSpread2_Sheet1.ColumnFooterSheetCornerStyle.Parent = "RowHeaderDefault"
        Me.FpSpread2_Sheet1.ColumnFooterSheetCornerStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread2_Sheet1.ColumnHeader.Cells.Get(0, 0).Value = "�H��"
        Me.FpSpread2_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = "���@��"
        Me.FpSpread2_Sheet1.ColumnHeader.Cells.Get(0, 2).Value = "���s�\�Z"
        Me.FpSpread2_Sheet1.ColumnHeader.Cells.Get(0, 3).Value = "�݌v���{���z"
        Me.FpSpread2_Sheet1.ColumnHeader.Cells.Get(0, 4).Value = "���㏊�v����"
        Me.FpSpread2_Sheet1.ColumnHeader.Cells.Get(0, 5).Value = "���{�������z"
        Me.FpSpread2_Sheet1.ColumnHeader.Cells.Get(0, 6).Value = "�\�Z�Δ�"
        Me.FpSpread2_Sheet1.ColumnHeader.Cells.Get(0, 7).Value = "�ύX����"
        Me.FpSpread2_Sheet1.ColumnHeader.Cells.Get(0, 8).Value = "������z"
        Me.FpSpread2_Sheet1.ColumnHeader.Cells.Get(0, 9).Value = "�݌v���z"
        Me.FpSpread2_Sheet1.ColumnHeader.Columns.Default.CanFocus = false
        Me.FpSpread2_Sheet1.ColumnHeader.Columns.Default.Resizable = false
        Me.FpSpread2_Sheet1.ColumnHeader.Columns.Default.SortIndicator = FarPoint.Win.Spread.Model.SortIndicator.None
        Me.FpSpread2_Sheet1.ColumnHeader.Columns.Default.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread2_Sheet1.ColumnHeader.DefaultStyle.BackColor = System.Drawing.Color.Empty
        Me.FpSpread2_Sheet1.ColumnHeader.DefaultStyle.CanFocus = false
        Me.FpSpread2_Sheet1.ColumnHeader.DefaultStyle.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.FpSpread2_Sheet1.ColumnHeader.DefaultStyle.ForeColor = System.Drawing.Color.Empty
        Me.FpSpread2_Sheet1.ColumnHeader.DefaultStyle.Locked = false
        Me.FpSpread2_Sheet1.ColumnHeader.DefaultStyle.Parent = "HeaderDefault"
        Me.FpSpread2_Sheet1.ColumnHeader.DefaultStyle.Renderer = CustomSpdHeader13
        Me.FpSpread2_Sheet1.ColumnHeader.DefaultStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread2_Sheet1.ColumnHeader.Rows.Default.CanFocus = false
        Me.FpSpread2_Sheet1.ColumnHeader.Rows.Default.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread2_Sheet1.Columns.Default.CanFocus = false
        Me.FpSpread2_Sheet1.Columns.Default.Resizable = false
        Me.FpSpread2_Sheet1.Columns.Default.SortIndicator = FarPoint.Win.Spread.Model.SortIndicator.None
        Me.FpSpread2_Sheet1.Columns.Get(0).Border = ComplexBorder4
        TextCellType6.CharacterSet = FarPoint.Win.Spread.CellType.CharacterSet.AlphaNumeric
        TextCellType6.MaxLength = 8
        Me.FpSpread2_Sheet1.Columns.Get(0).CellType = TextCellType6
        Me.FpSpread2_Sheet1.Columns.Get(0).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.FpSpread2_Sheet1.Columns.Get(0).Label = "�H��"
        Me.FpSpread2_Sheet1.Columns.Get(0).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread2_Sheet1.Columns.Get(0).Width = 48!
        Me.FpSpread2_Sheet1.Columns.Get(1).Border = ComplexBorder5
        TextCellType7.MaxLength = 60
        Me.FpSpread2_Sheet1.Columns.Get(1).CellType = TextCellType7
        Me.FpSpread2_Sheet1.Columns.Get(1).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Left
        Me.FpSpread2_Sheet1.Columns.Get(1).Label = "���@��"
        Me.FpSpread2_Sheet1.Columns.Get(1).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread2_Sheet1.Columns.Get(1).Width = 148!
        Me.FpSpread2_Sheet1.Columns.Get(2).Border = ComplexBorder5
        CurrencyCellType1.DecimalPlaces = 0
        CurrencyCellType1.MaximumValue = New Decimal(New Integer() {1410065407, 2, 0, 0})
        CurrencyCellType1.MinimumValue = New Decimal(New Integer() {1410065407, 2, 0, -2147483648})
        CurrencyCellType1.ShowCurrencySymbol = false
        CurrencyCellType1.ShowSeparator = true
        Me.FpSpread2_Sheet1.Columns.Get(2).CellType = CurrencyCellType1
        Me.FpSpread2_Sheet1.Columns.Get(2).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Right
        Me.FpSpread2_Sheet1.Columns.Get(2).Label = "���s�\�Z"
        Me.FpSpread2_Sheet1.Columns.Get(2).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread2_Sheet1.Columns.Get(2).Width = 124!
        Me.FpSpread2_Sheet1.Columns.Get(3).Border = ComplexBorder4
        CurrencyCellType2.DecimalPlaces = 0
        CurrencyCellType2.MaximumValue = New Decimal(New Integer() {1410065407, 2, 0, 0})
        CurrencyCellType2.MinimumValue = New Decimal(New Integer() {1410065407, 2, 0, -2147483648})
        CurrencyCellType2.ShowCurrencySymbol = false
        CurrencyCellType2.ShowSeparator = true
        Me.FpSpread2_Sheet1.Columns.Get(3).CellType = CurrencyCellType2
        Me.FpSpread2_Sheet1.Columns.Get(3).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Right
        Me.FpSpread2_Sheet1.Columns.Get(3).Label = "�݌v���{���z"
        Me.FpSpread2_Sheet1.Columns.Get(3).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread2_Sheet1.Columns.Get(3).Width = 124!
        Me.FpSpread2_Sheet1.Columns.Get(4).Border = ComplexBorder4
        Me.FpSpread2_Sheet1.Columns.Get(4).CellType = CurrencyCellType2
        Me.FpSpread2_Sheet1.Columns.Get(4).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Right
        Me.FpSpread2_Sheet1.Columns.Get(4).Label = "���㏊�v����"
        Me.FpSpread2_Sheet1.Columns.Get(4).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread2_Sheet1.Columns.Get(4).Width = 124!
        Me.FpSpread2_Sheet1.Columns.Get(5).Border = ComplexBorder4
        Me.FpSpread2_Sheet1.Columns.Get(5).CellType = CurrencyCellType2
        Me.FpSpread2_Sheet1.Columns.Get(5).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Right
        Me.FpSpread2_Sheet1.Columns.Get(5).Label = "���{�������z"
        Me.FpSpread2_Sheet1.Columns.Get(5).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread2_Sheet1.Columns.Get(5).Width = 124!
        Me.FpSpread2_Sheet1.Columns.Get(6).Border = ComplexBorder4
        Me.FpSpread2_Sheet1.Columns.Get(6).CellType = CurrencyCellType2
        Me.FpSpread2_Sheet1.Columns.Get(6).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Right
        Me.FpSpread2_Sheet1.Columns.Get(6).Label = "�\�Z�Δ�"
        Me.FpSpread2_Sheet1.Columns.Get(6).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread2_Sheet1.Columns.Get(6).Width = 124!
        Me.FpSpread2_Sheet1.Columns.Get(7).Border = ComplexBorder5
        CurrencyCellType3.DecimalPlaces = 0
        CurrencyCellType3.MaximumValue = New Decimal(New Integer() {1410065407, 2, 0, 0})
        CurrencyCellType3.MinimumValue = New Decimal(New Integer() {1410065407, 2, 0, -2147483648})
        CurrencyCellType3.ShowCurrencySymbol = false
        CurrencyCellType3.ShowSeparator = true
        Me.FpSpread2_Sheet1.Columns.Get(7).CellType = CurrencyCellType3
        Me.FpSpread2_Sheet1.Columns.Get(7).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Right
        Me.FpSpread2_Sheet1.Columns.Get(7).Label = "�ύX����"
        Me.FpSpread2_Sheet1.Columns.Get(7).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread2_Sheet1.Columns.Get(7).Width = 124!
        Me.FpSpread2_Sheet1.Columns.Get(8).Border = ComplexBorder4
        TextCellType8.Static = true
        Me.FpSpread2_Sheet1.Columns.Get(8).CellType = TextCellType8
        Me.FpSpread2_Sheet1.Columns.Get(8).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Right
        Me.FpSpread2_Sheet1.Columns.Get(8).Label = "������z"
        Me.FpSpread2_Sheet1.Columns.Get(8).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread2_Sheet1.Columns.Get(8).Visible = false
        Me.FpSpread2_Sheet1.Columns.Get(8).Width = 0!
        Me.FpSpread2_Sheet1.Columns.Get(9).Border = ComplexBorder5
        TextCellType9.Static = true
        Me.FpSpread2_Sheet1.Columns.Get(9).CellType = TextCellType9
        Me.FpSpread2_Sheet1.Columns.Get(9).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Right
        Me.FpSpread2_Sheet1.Columns.Get(9).Label = "�݌v���z"
        Me.FpSpread2_Sheet1.Columns.Get(9).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread2_Sheet1.Columns.Get(9).Visible = false
        Me.FpSpread2_Sheet1.Columns.Get(9).Width = 0!
        Me.FpSpread2_Sheet1.DefaultStyle.BackColor = System.Drawing.Color.Empty
        Me.FpSpread2_Sheet1.DefaultStyle.CanFocus = false
        Me.FpSpread2_Sheet1.DefaultStyle.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128,Byte))
        Me.FpSpread2_Sheet1.DefaultStyle.ForeColor = System.Drawing.Color.Empty
        Me.FpSpread2_Sheet1.DefaultStyle.Locked = true
        Me.FpSpread2_Sheet1.DefaultStyle.Parent = "DataAreaDefault"
        Me.FpSpread2_Sheet1.FilterBar.DefaultStyle.BackColor = System.Drawing.Color.Empty
        Me.FpSpread2_Sheet1.FilterBar.DefaultStyle.ForeColor = System.Drawing.Color.Empty
        Me.FpSpread2_Sheet1.FilterBar.DefaultStyle.Locked = false
        Me.FpSpread2_Sheet1.FilterBar.DefaultStyle.Parent = "FilterBarDefault"
        Me.FpSpread2_Sheet1.FilterBar.DefaultStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread2_Sheet1.FilterBarHeaderStyle.BackColor = System.Drawing.Color.Empty
        Me.FpSpread2_Sheet1.FilterBarHeaderStyle.ForeColor = System.Drawing.Color.Empty
        Me.FpSpread2_Sheet1.FilterBarHeaderStyle.Locked = false
        Me.FpSpread2_Sheet1.FilterBarHeaderStyle.Parent = "RowHeaderDefault"
        Me.FpSpread2_Sheet1.FilterBarHeaderStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread2_Sheet1.OperationMode = FarPoint.Win.Spread.OperationMode.[ReadOnly]
        Me.FpSpread2_Sheet1.Protect = true
        Me.FpSpread2_Sheet1.RowHeader.AutoText = FarPoint.Win.Spread.HeaderAutoText.Blank
        Me.FpSpread2_Sheet1.RowHeader.Columns.Default.CanFocus = false
        Me.FpSpread2_Sheet1.RowHeader.Columns.Default.Resizable = false
        Me.FpSpread2_Sheet1.RowHeader.Columns.Default.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread2_Sheet1.RowHeader.Columns.Get(0).Width = 37!
        Me.FpSpread2_Sheet1.RowHeader.DefaultStyle.BackColor = System.Drawing.Color.Empty
        Me.FpSpread2_Sheet1.RowHeader.DefaultStyle.Border = ComplexBorder6
        Me.FpSpread2_Sheet1.RowHeader.DefaultStyle.CanFocus = false
        Me.FpSpread2_Sheet1.RowHeader.DefaultStyle.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128,Byte))
        Me.FpSpread2_Sheet1.RowHeader.DefaultStyle.ForeColor = System.Drawing.Color.Empty
        Me.FpSpread2_Sheet1.RowHeader.DefaultStyle.Locked = false
        Me.FpSpread2_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderDefault"
        Me.FpSpread2_Sheet1.RowHeader.DefaultStyle.Renderer = CustomSpdHeader14
        Me.FpSpread2_Sheet1.RowHeader.DefaultStyle.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.General
        Me.FpSpread2_Sheet1.RowHeader.DefaultStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread2_Sheet1.RowHeader.Rows.Default.CanFocus = false
        Me.FpSpread2_Sheet1.RowHeader.Rows.Default.Resizable = false
        Me.FpSpread2_Sheet1.RowHeader.Rows.Default.Visible = true
        Me.FpSpread2_Sheet1.RowHeader.Rows.Default.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread2_Sheet1.Rows.Default.CanFocus = false
        Me.FpSpread2_Sheet1.Rows.Default.Height = 19!
        Me.FpSpread2_Sheet1.Rows.Default.Resizable = false
        Me.FpSpread2_Sheet1.Rows.Default.Visible = true
        Me.FpSpread2_Sheet1.Rows.Get(0).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Left
        Me.FpSpread2_Sheet1.Rows.Get(0).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Top
        Me.FpSpread2_Sheet1.SheetCornerStyle.BackColor = System.Drawing.Color.Empty
        Me.FpSpread2_Sheet1.SheetCornerStyle.ForeColor = System.Drawing.Color.Empty
        Me.FpSpread2_Sheet1.SheetCornerStyle.Locked = false
        Me.FpSpread2_Sheet1.SheetCornerStyle.Parent = "RowHeaderDefault"
        Me.FpSpread2_Sheet1.SheetCornerStyle.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.FpSpread2_Sheet1.SheetCornerStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.FpSpread2_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1
        '
        'frmSYKD180
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(1016, 742)
        Me.Controls.Add(Me._imNumber2_3)
        Me.Controls.Add(Me.Check1)
        Me.Controls.Add(Me.Picture3)
        Me.Controls.Add(Me._Frame1_2)
        Me.Controls.Add(Me._Frame1_0)
        Me.Controls.Add(Me.Picture1)
        Me.Controls.Add(Me.StatusBar1)
        Me.Controls.Add(Me._imText2_2)
        Me.Controls.Add(Me._imText2_0)
        Me.Controls.Add(Me._imText2_1)
        Me.Controls.Add(Me._imText3_0)
        Me.Controls.Add(Me._Frame1_1)
        Me.Controls.Add(Me._Label1_0)
        Me.Controls.Add(Me.lblTitle)
        Me.Controls.Add(Me.FpSpread1)
        Me.Controls.Add(Me.FpSpread2)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"),System.Drawing.Icon)
        Me.KeyPreview = true
        Me.Location = New System.Drawing.Point(5, 23)
        Me.MaximizeBox = false
        Me.MinimizeBox = false
        Me.Name = "frmSYKD180"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "�H���Ǘ��V�X�e��"
        Me.Picture3.ResumeLayout(false)
        Me._Frame1_2.ResumeLayout(false)
        CType(Me._imText6_0,System.ComponentModel.ISupportInitialize).EndInit
        CType(Me._imText7_0,System.ComponentModel.ISupportInitialize).EndInit
        CType(Me._imText6_1,System.ComponentModel.ISupportInitialize).EndInit
        CType(Me._imText6_2,System.ComponentModel.ISupportInitialize).EndInit
        CType(Me._imText6_4,System.ComponentModel.ISupportInitialize).EndInit
        CType(Me._imText6_5,System.ComponentModel.ISupportInitialize).EndInit
        CType(Me._imText7_1,System.ComponentModel.ISupportInitialize).EndInit
        CType(Me._imNumber2_0,System.ComponentModel.ISupportInitialize).EndInit
        CType(Me._imNumber2_1,System.ComponentModel.ISupportInitialize).EndInit
        CType(Me._imNumber2_2,System.ComponentModel.ISupportInitialize).EndInit
        CType(Me._imNumber2_3,System.ComponentModel.ISupportInitialize).EndInit
        Me._Frame1_0.ResumeLayout(false)
        Me._Picture2_1.ResumeLayout(false)
        CType(Me._imText3_2,System.ComponentModel.ISupportInitialize).EndInit
        CType(Me._imText5_2,System.ComponentModel.ISupportInitialize).EndInit
        CType(Me._imText5_3,System.ComponentModel.ISupportInitialize).EndInit
        CType(Me._imText5_0,System.ComponentModel.ISupportInitialize).EndInit
        CType(Me._imText5_1,System.ComponentModel.ISupportInitialize).EndInit
        Me._Picture2_0.ResumeLayout(false)
        CType(Me._imText3_1,System.ComponentModel.ISupportInitialize).EndInit
        CType(Me._imText4_2,System.ComponentModel.ISupportInitialize).EndInit
        CType(Me._imNumber1_0,System.ComponentModel.ISupportInitialize).EndInit
        CType(Me._imNumber1_1,System.ComponentModel.ISupportInitialize).EndInit
        CType(Me._imText4_3,System.ComponentModel.ISupportInitialize).EndInit
        Me.Picture1.ResumeLayout(false)
        Me.StatusBar1.ResumeLayout(false)
        Me.StatusBar1.PerformLayout
        CType(Me._imText2_2,System.ComponentModel.ISupportInitialize).EndInit
        CType(Me._imText2_0,System.ComponentModel.ISupportInitialize).EndInit
        CType(Me._imText2_1,System.ComponentModel.ISupportInitialize).EndInit
        CType(Me._imText3_0,System.ComponentModel.ISupportInitialize).EndInit
        Me._Frame1_1.ResumeLayout(false)
        CType(Me._imText1_0,System.ComponentModel.ISupportInitialize).EndInit
        CType(Me._imDate1_0,System.ComponentModel.ISupportInitialize).EndInit
        CType(Me._imDate1_1,System.ComponentModel.ISupportInitialize).EndInit
        CType(Me._imDate1_2,System.ComponentModel.ISupportInitialize).EndInit
        CType(Me._imText1_1,System.ComponentModel.ISupportInitialize).EndInit
        CType(Me.FpSpread1,System.ComponentModel.ISupportInitialize).EndInit
        CType(Me.FpSpread1_Sheet1,System.ComponentModel.ISupportInitialize).EndInit
        CType(Me.FpSpread2,System.ComponentModel.ISupportInitialize).EndInit
        CType(Me.FpSpread2_Sheet1,System.ComponentModel.ISupportInitialize).EndInit
        Me.ResumeLayout(false)
        Me.PerformLayout

End Sub

    Friend WithEvents FpSpread1 As FarPoint.Win.Spread.FpSpread
    Friend WithEvents FpSpread1_Sheet1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents FpSpread2 As FarPoint.Win.Spread.FpSpread
    Friend WithEvents FpSpread2_Sheet1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents DropDownButton1 As DropDownButton
    Friend WithEvents DropDownButton2 As DropDownButton
    Friend WithEvents DropDownButton3 As DropDownButton
#End Region
End Class