Option Strict Off
Option Explicit On
Imports VB = Microsoft.VisualBasic
Friend Class frmSYKD110
    Inherits System.Windows.Forms.Form
    '=============================================================
    ' ���[�U�[���@  �F  �R�z�H�Ɗ������
    ' �V�X�e�����@  �F  �H���Ǘ��V�X�e��
    ' ���W���[����  �F  �O���o��������
    ' ���W���[��ID�@�F  frmSYKD110.frm
    ' �쐬���@ �@�@ �F  ���� 13 �N 07 �� 19 ��
    ' �X�V���@�@  �@�F  ����    �N    ��    ��
    '=============================================================
    '
    '2021.08.09 UPGRADE S  AIT)dannnl
    'Private Const RowHeight As Short = 11
    Private Const RowHeight As Short = 17
    '2021.08.09 UPGRADE E

    '2021.11.05  UPGRADE S  AIT)hieutv
    'Public ChumonID As String '�����ԍ�
    'Public GyosyaID As String '�Ǝк���
    'Public HenkouFG As String '�ύX�׸�
    '
    'Public UpdateFG As String '�X�V�׸�
    Public Shared ChumonID As String '�����ԍ�
    Public Shared GyosyaID As String '�Ǝк���
    Public Shared HenkouFG As String '�ύX�׸�

    Public Shared UpdateFG As String '�X�V�׸�
    '2021.11.05  UPGRADE E
    '

    '-------------------------------------------------------------------------------
    '   ����    :   �f�[�^�̃N���A
    '   �֐�    :   Sub DispClear()
    '   ����    :   �Ȃ�
    '   �@�\    :   �f�[�^���N���A���܂��B
    '-------------------------------------------------------------------------------
    Private Sub DispClear(Optional ByRef Mode As Short = 0)

        If Mode = 1 Then
            With KeyKouji
                '----- �H�����
                imText2(0).Text = .KOUJI_NO
                If .EDA_NO = "0000" Then
                    imText2(1).Text = ""
                Else
                    imText2(1).Text = .EDA_NO
                End If
                imText2(2).Text = .MEISYOU
                '----- ���N��
                '2021.07.26 UPGRADE S  AIT)Tool Convert
                'imText1(0).Text = VB6.Format(CtlKouji.SYORI_YM, "0000/00")
                imText1(0).Text = CDec(CtlKouji.SYORI_YM).ToString("0000/00")
                '2021.07.26 UPGRADE E
                '----- �����ԍ�
                imText1(1).Text = Trim(ChumonID)
                imText1(2).Text = GetNameWaridasi(.KOUJI_NO, .EDA_NO, ChumonID)
                '----- �Ǝ�
                imText1(3).Text = GyosyaID
                imText1(4).Text = GetNameGyousya(GyosyaID)
            End With
        End If

        '2021.08.02 UPGRADE S  AIT)dannnl
        'vaSpread1.MaxRows = 0 '�\
        'Call SpAllClear(vaSpread2)
        FpSpread1.ActiveSheet.RowCount = 0 '�\
        Call SpAllClear(FpSpread2)
        '2021.08.02 UPGRADE E	

        '----- �Q�ƃ��[�h
        If INPMODE <> "2" Then
            '2021.08.10 UPGRADE S  AIT)dannnl
            'cmdKey(2).Text = "  F2  �� ��"
            cmdKey(2).Text = " F2" & vbCrLf & "�� ��"
            '2021.08.10 UPGRADE E
            cmdKey(2).Tag = "�I���f�[�^�̏ڍׂ�\�����܂��B"
        End If

    End Sub

    '-------------------------------------------------------------------------------
    '   ����   :   DEKIDAKA_DATA �ǂݍ��ݏ���
    '   �֐�   :   Function SelectDekidaka()
    '   ����   :   WA()�@   WARIDASI_DATA_DBT
    '   �@�@       DE()�@   DEKIDAKA_DATA_DBT
    '   �ߒl   :   �ް���   ����I��
    '   �@�@       -1�@     �ُ�I��
    '   �@�\   :   DEKIDAKA_DATA SELECT����
    '-------------------------------------------------------------------------------
    Private Function SelectDekidaka(ByRef WA() As WARIDASI_DATA_DBT, ByRef DE() As DEKIDAKA_DATA_DBT) As Integer

        Dim QRY1 As String
        Dim QRY2 As String
        Dim SQL As String
        '2021.08.02 UPGRADE S  AIT)dannnl
        'Dim Rs As ADODB.Recordset
        'Dim Fld As ADODB.Field
        Dim Rs As New DataTable
        '2021.08.02 UPGRADE E
        Dim Cnt As Integer
        Dim OpenFlg As Short

        '2021.07.26 UPGRADE S  AIT)Tool Convert
        'On Error GoTo SelectDekidaka_Err
        Try
            '2021.07.26 UPGRADE E

            '�߂�l�̏�����
            SelectDekidaka = -1

            'QRY/SELECT���g��
            QRY1 = "(SELECT * FROM WARIDASI_DATA"
            QRY1 = QRY1 & " WHERE EDA_NO = '" & KeyKouji.EDA_NO & "'"
            QRY1 = QRY1 & " AND KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"
            QRY1 = QRY1 & " AND WARIDASI_NO = '" & Trim(ChumonID) & "'"
            QRY1 = QRY1 & ") AS WARIDASI"

            'QRY/SELECT���g��
            QRY2 = "(SELECT * FROM DEKIDAKA_DATA"
            QRY2 = QRY2 & " WHERE EDA_NO = '" & KeyKouji.EDA_NO & "'"
            QRY2 = QRY2 & " AND KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"
            QRY2 = QRY2 & " AND SIME_YM = '" & CtlKouji.SYORI_YM & "'"
            QRY2 = QRY2 & ") AS DEKIDAKA"

            'SQL/SELECT���g��
            SQL = "SELECT"
            SQL = SQL & " WARIDASI.KOUSYU_CD    AS F01," '�H������
            SQL = SQL & " WARIDASI.KOUSYU_NO    AS F02," '�H��ԍ�
            SQL = SQL & " WARIDASI.MEISAI_NO    AS F03," '���הԍ�
            SQL = SQL & " WARIDASI.MEISYOU      AS F04," '����
            SQL = SQL & " WARIDASI.TANI         AS F05," '�P��
            SQL = SQL & " WARIDASI.G_SUURYOU    AS F06," '���ʁi�O���j
            SQL = SQL & " WARIDASI.G_TANKA      AS F07," '�P���i�O���j
            SQL = SQL & " WARIDASI.G_KINGAKU    AS F08," '���z�i�O���j
            SQL = SQL & " DEKIDAKA.*"
            SQL = SQL & " FROM " & QRY1 & " LEFT JOIN " & QRY2
            SQL = SQL & " ON  (WARIDASI.MEISAI_NO = DEKIDAKA.MEISAI_NO)"
            SQL = SQL & " AND (WARIDASI.KOUSYU_NO = DEKIDAKA.KOUSYU_NO)"
            SQL = SQL & " AND (WARIDASI.KOUSYU_CD = DEKIDAKA.KOUSYU_CD)"
            SQL = SQL & " AND (WARIDASI.EDA_NO    = DEKIDAKA.EDA_NO)"
            SQL = SQL & " AND (WARIDASI.KOUJI_NO  = DEKIDAKA.KOUJI_NO)"
            SQL = SQL & " ORDER BY WARIDASI.KOUSYU_CD, WARIDASI.KOUSYU_NO, WARIDASI.MEISAI_NO"

            'SQL�����s
            '2021.08.02 UPGRADE S  AIT)dannnl
            'Rs = SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText)
            Rs = RsOpen(SQL)
            '2021.08.02 UPGRADE E
            OpenFlg = 1

            Cnt = 0
            '2021.08.02 UPGRADE S  AIT)dannnl
            'Do Until Rs.EOF
            For Each Row As DataRow In Rs.Rows
                '2021.08.02 UPGRADE E
                ReDim Preserve WA(Cnt)
                Call CLEAR_WARIDASI_DATA(WA(Cnt))
                With WA(Cnt)
                    .KOUJI_NO = KeyKouji.KOUJI_NO '�H���ԍ�
                    .EDA_NO = KeyKouji.EDA_NO '�H���}��
                    '2021.08.02 UPGRADE S  AIT)dannnl
                    '.KOUSYU_CD = RsNull(Rs, "F01") '�H������
                    '.KOUSYU_NO = RsNull(Rs, "F02") '�H��ԍ�
                    '.MEISAI_NO = CDbl2(RsNull(Rs, "F03")) '���הԍ�
                    '.MEISYOU = RsNull(Rs, "F04") '����
                    '.TANI = RsNull(Rs, "F05") '�P��
                    .KOUSYU_CD = RsNull(Row, "F01") '�H������
                    .KOUSYU_NO = RsNull(Row, "F02") '�H��ԍ�
                    .MEISAI_NO = CDbl2(RsNull(Row, "F03")) '���הԍ�
                    .MEISYOU = RsNull(Row, "F04") '����
                    .TANI = RsNull(Row, "F05") '�P��
                    '2021.08.02 UPGRADE E
                    .WARIDASI_NO = Trim(ChumonID) '���o�ԍ�
                    '2021.08.02 UPGRADE S  AIT)dannnl
                    '.G_SUURYOU = CCur2(RsNull(Rs, "F06")) '���ʁi�O���j
                    '.G_TANKA = CCur2(RsNull(Rs, "F07")) '�P���i�O���j
                    '.G_KINGAKU = CCur2(RsNull(Rs, "F08")) '���z�i�O���j
                    .G_SUURYOU = CCur2(RsNull(Row, "F06")) '���ʁi�O���j
                    .G_TANKA = CCur2(RsNull(Row, "F07")) '�P���i�O���j
                    .G_KINGAKU = CCur2(RsNull(Row, "F08")) '���z�i�O���j
                    '2021.08.02 UPGRADE E
                End With
                ReDim Preserve DE(Cnt)
                '2021.08.03 UPGRADE S  AIT)dannnl
                'Call DATSET_DEKIDAKA_DATA(Rs, DE(Cnt))
                Call DATSET_DEKIDAKA_DATA(Row, DE(Cnt))
                '2021.08.03 UPGRADE E
                '----- �o�����f�[�^���Ȃ��ꍇ
                If Trim(DE(Cnt).KOUJI_NO) = "" Then
                    With DE(Cnt)
                        .KOUJI_NO = WA(Cnt).KOUJI_NO '�H���ԍ�
                        .EDA_NO = WA(Cnt).EDA_NO '�H���}��
                        .KOUSYU_CD = WA(Cnt).KOUSYU_CD '�H������
                        .KOUSYU_NO = WA(Cnt).KOUSYU_NO '�H��ԍ�
                        .SIME_YM = CtlKouji.SYORI_YM '���N��
                        .MEISAI_NO = WA(Cnt).MEISAI_NO '���הԍ�
                        .HENKOU_SUU = WA(Cnt).G_SUURYOU '�ύX�㐔��
                        .ZOUGEN_GAKU = WA(Cnt).G_KINGAKU '�ύX���� 2003/04/21 �ǉ�
                    End With
                    '----- �ύX����̏ꍇ
                    If HenkouFG = "1" Then
                        ' �o�����f�[�^�̒ǉ�
                        If INSERT_DEKIDAKA_DATA(DE(Cnt)) = False Then
                            '2021.08.02 UPGRADE S  AIT)dannnl
                            'Rs.Close()
                            Rs.Dispose()
                            '2021.08.02 UPGRADE E	
                            Rs = Nothing
                            Exit Function
                        End If
                    End If
                End If
                Cnt = Cnt + 1
                '2021.08.02 UPGRADE S  AIT)dannnl
                '	Rs.MoveNext()
                'Loop

                'Rs.Close()
            Next

            Rs.Dispose()
            '2021.08.02 UPGRADE E
            Rs = Nothing

            '�߂�l�̃Z�b�g
            SelectDekidaka = Cnt
            Exit Function

            '2021.07.26 UPGRADE S  AIT)Tool Convert
            'SelectDekidaka_Err:
        Catch ex As Exception
            '2021.07.26 UPGRADE E

            If OpenFlg = 1 Then
                '2021.08.02 UPGRADE S  AIT)dannnl
                'Rs.Close()
                Rs.Dispose()
                '2021.08.02 UPGRADE E	
            End If
            Rs = Nothing

            Call Sql_Error_Msg(ex, "DEKIDAKA_DATA SELECT")

        End Try     '2021.07.26 UPGRADE ADD AIT)Tool Convert
    End Function

    '-------------------------------------------------------------------------------
    '   ����   :   �������̍폜
    '   �֐�   :   Function DeleteMikomi()
    '   ����   :   Cnt      �f�[�^����
    '   �@�@       DT()     DEKIDAKA_DATA_DBT
    '   �ߒl   :   True     ����I��
    '   �@�@       False    �ُ�I��
    '   �@�\   :   �������̍폜���s���܂��B
    '-------------------------------------------------------------------------------
    Private Function DeleteMikomi(ByRef Cnt As Integer, ByRef DT() As DEKIDAKA_DATA_DBT) As Boolean

        Dim lp As Integer
        Dim Jouken As String

        ' �߂�l�̏�����
        DeleteMikomi = False

        For lp = 0 To Cnt - 1
            '----- WHERE���̑g��
            With DT(lp)
                '2021.08.02 UPGRADE S  AIT)dannnl
                'Jouken = "MEISAI_NO = " & VB6.Format(.MEISAI_NO)
                Jouken = "MEISAI_NO = " & .MEISAI_NO
                '2021.08.02 UPGRADE E	
                Jouken = Jouken & " AND KOUSYU_NO = '" & .KOUSYU_NO & "'"
                Jouken = Jouken & " AND KOUSYU_CD = '" & .KOUSYU_CD & "'"
                Jouken = Jouken & " AND SIME_YM = '" & .SIME_YM & "'"
                Jouken = Jouken & " AND EDA_NO = '" & .EDA_NO & "'"
                Jouken = Jouken & " AND KOUJI_NO = '" & .KOUJI_NO & "'"
            End With
            '----- �폜����
            If DELETE_MIKOMI_DATA(Jouken) = False Then
                Exit Function
            End If
        Next lp

        ' ����I��
        DeleteMikomi = True

    End Function

    '-------------------------------------------------------------------------------
    '   ����    :   �f�[�^�̎擾
    '   �֐�    :   Sub ListDataDisp()
    '   ����    :   Mode    0 = MsgBox�\��
    '   �@�\    :   �f�[�^�̎擾���s���܂��B
    '-------------------------------------------------------------------------------
    Public Sub ListDataDisp(Optional ByRef Mode As Short = 0)

        Dim Cnt As Integer
        Dim WA() As WARIDASI_DATA_DBT
        Dim DE() As DEKIDAKA_DATA_DBT
        Dim wkBuf As String

        ' �J�[�\���������v��
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
        wkBuf = StatusBar1.Items.Item("Message").Text
        StatusBar1.Items.Item("Message").Text = "�Y���f�[�^�������E�E�E"

        ' �e�[�u���̓Ǎ���
        Cnt = SelectDekidaka(WA, DE)
        If Cnt <= 0 Then
            '2021.08.02 UPGRADE S  AIT)dannnl
            'vaSpread1.MaxRows = 0
            FpSpread1.ActiveSheet.RowCount = 0
            '2021.08.02 UPGRADE E
            If Cnt = 0 Then UpdateFG = "1" '�X�V�t���O
            cmdKey(2).Enabled = False '�C���{�^��
            StatusBar1.Items.Item("Message").Text = wkBuf
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
            Exit Sub
        End If
        '----- �ύX����̏ꍇ
        If HenkouFG = "1" Then
            ' �����f�[�^�̍폜
            If DeleteMikomi(Cnt, DE) = False Then
                '2021.08.02 UPGRADE S  AIT)dannnl
                'vaSpread1.MaxRows = 0
                FpSpread1.ActiveSheet.RowCount = 0
                '2021.08.02 UPGRADE E
                cmdKey(2).Enabled = False '�C���{�^��
                StatusBar1.Items.Item("Message").Text = wkBuf
                System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
                Exit Sub
            End If
        End If

        ' �X�v���b�h�ɕ\��
        Call SprdDataSet(Cnt, WA, DE)

        StatusBar1.Items.Item("Message").Text = wkBuf
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default

    End Sub

    '-------------------------------------------------------------------------------
    '   ����    :   �X�v���b�h�\��
    '   �֐�    :   Sub SprdDataSet(DT())
    '   ����    :   Cnt     �f�[�^����
    '   �@�@        WA()    WARIDASI_DATA_DBT
    '   �@�@        DE()    DEKIDAKA_DATA_DBT
    '   �@�\    :   �f�[�^���X�v���b�h�ɕ\�����܂��B
    '-------------------------------------------------------------------------------
    Private Sub SprdDataSet(ByRef Cnt As Integer, ByRef WA() As WARIDASI_DATA_DBT, ByRef DE() As DEKIDAKA_DATA_DBT)

        Dim lp As Integer
        Dim Row As Integer
        Dim ssText As Object
        Dim wkVal() As Decimal

        '2021.08.02 UPGRADE S  AIT)dannnl
        'With vaSpread1
        With FpSpread1
            '2021.08.02 UPGRADE E
            If Me.Visible = True Then
                '2021.08.02 UPGRADE S  AIT)dannnl
                '.ReDraw = False
                .SuspendLayout()
                '2021.08.02 UPGRADE E	
            End If
            '2021.08.02 UPGRADE S  AIT)dannnl
            '.MaxRows = Cnt
            '.Col = 1 : .Col2 = .MaxCols
            '.Row = 1 : .Row2 = .MaxRows
            '.BlockMode = True
            '.Font = VB6.FontChangeBold(.Font, False)
            '.Action = FPSpread.ActionConstants.ActionClearText
            '.BlockMode = False
            .ActiveSheet.RowCount = Cnt
            .Font = New Font(.Font, FontStyle.Regular)
            .ActiveSheet.ColumnHeader.DefaultStyle.Font = New Font(.Font, FontStyle.Bold)
            .ActiveSheet.RowHeader.DefaultStyle.Font = New Font(.Font, FontStyle.Bold)
            .ActiveSheet.ClearRange(0, 0, .ActiveSheet.RowCount, .ActiveSheet.ColumnCount, True)
            .ActiveSheet.AddSelection(.ActiveSheet.ActiveRowIndex, .ActiveSheet.ActiveColumnIndex, 1, FpSpread1.ActiveSheet.ColumnCount)
            '2021.08.02 UPGRADE E
            ReDim wkVal(6)
            For lp = 0 To Cnt - 1
                '2021.08.02 UPGRADE S  AIT)dannnl
                '.set_RowHeight(lp + 1, RowHeight)
                'Row = lp + 1
                .ActiveSheet.SetRowHeight(lp, RowHeight)
                Row = lp
                '2021.08.02 UPGRADE E
                '----- �H��
                ssText = Trim(WA(lp).KOUSYU_CD) & "-" & Trim(WA(lp).KOUSYU_NO)
                '2021.08.02 UPGRADE S  AIT)dannnl
                '.SetText(1, Row, ssText)
                .ActiveSheet.SetText(Row, 0, ssText)
                '2021.08.02 UPGRADE E
                '----- ����
                ssText = Trim(WA(lp).MEISYOU)
                '2021.08.02 UPGRADE S  AIT)dannnl
                '.SetText(2, Row, ssText)
                .ActiveSheet.SetText(Row, 1, ssText)
                '2021.08.02 UPGRADE E
                '----- ����
                '2021.07.26 UPGRADE S  AIT)Tool Convert
                'ssText = VB6.Format(WA(lp).G_SUURYOU, "#,###.##")
                ssText = WA(lp).G_SUURYOU.ToString("#,###.##")
                '2021.07.26 UPGRADE E
                If VB.Right(ssText, 1) = "." Then ssText = VB.Left(ssText, Len(ssText) - 1)
                If VB.Left(ssText, 1) = "." Then ssText = "0" & ssText
                '2021.08.02 UPGRADE S  AIT)dannnl
                '.SetText(3, Row, ssText)
                .ActiveSheet.SetText(Row, 2, ssText)
                '2021.08.02 UPGRADE E
                '----- �P��
                ssText = Trim(WA(lp).TANI)
                '2021.08.02 UPGRADE S  AIT)dannnl
                '.SetText(4, Row, ssText)
                .ActiveSheet.SetText(Row, 3, ssText)
                '2021.08.02 UPGRADE E
                '----- �P��
                '2021.08.02 UPGRADE S  AIT)dannnl
                'ssText = VB6.Format(WA(lp).G_TANKA, "#,###")
                '.SetText(5, Row, ssText)
                ssText = CDec(WA(lp).G_TANKA).ToString("#,###")
                .ActiveSheet.SetText(Row, 4, ssText)
                '2021.08.02 UPGRADE E
                '----- ���z
                '2021.07.26 UPGRADE S  AIT)Tool Convert
                'ssText = VB6.Format(WA(lp).G_KINGAKU, "#,##0")
                '.SetText(6, Row, ssText)
                ssText = CDec(WA(lp).G_KINGAKU).ToString("#,##0")
                .ActiveSheet.SetText(Row, 5, ssText)
                '2021.07.26 UPGRADE E
                '----- �ύX�㐔��
                '2021.07.26 UPGRADE S  AIT)Tool Convert
                'ssText = VB6.Format(DE(lp).HENKOU_SUU, "#,###.##")
                ssText = DE(lp).HENKOU_SUU.ToString("#,###.##")
                '2021.07.26 UPGRADE E
                If VB.Right(ssText, 1) = "." Then ssText = VB.Left(ssText, Len(ssText) - 1)
                If VB.Left(ssText, 1) = "." Then ssText = "0" & ssText
                '2021.08.02 UPGRADE S  AIT)dannnl
                '.SetText(7, Row, ssText)
                .ActiveSheet.SetText(Row, 6, ssText)
                '2021.08.02 UPGRADE E
                '----- ���ѐ���
                '2021.07.26 UPGRADE S  AIT)Tool Convert
                'ssText = VB6.Format(DE(lp).JITU_SUU, "#,###.##")
                ssText = DE(lp).JITU_SUU.ToString("#,###.##")
                '2021.07.26 UPGRADE E
                If VB.Right(ssText, 1) = "." Then ssText = VB.Left(ssText, Len(ssText) - 1)
                If VB.Left(ssText, 1) = "." Then ssText = "0" & ssText
                '2021.08.02 UPGRADE S  AIT)dannnl
                '.SetText(8, Row, ssText)
                .ActiveSheet.SetText(Row, 7, ssText)
                '2021.08.02 UPGRADE E
                '----- ���ы��z
                '2021.07.26 UPGRADE S  AIT)Tool Convert
                'ssText = VB6.Format(DE(lp).JITU_GAKU, "#,##0")
                '.SetText(9, Row, ssText)
                ssText = CDec(DE(lp).JITU_GAKU).ToString("#,##0")
                .ActiveSheet.SetText(Row, 8, ssText)
                '2021.07.26 UPGRADE E
                '----- �ݐϐ���
                '2021.07.26 UPGRADE S  AIT)Tool Convert
                'ssText = VB6.Format(DE(lp).JITU_SUU + DE(lp).RUI_SUU, "#,###.##")
                ssText = (DE(lp).JITU_SUU + DE(lp).RUI_SUU).ToString("#,###.##")
                '2021.07.26 UPGRADE E
                If VB.Right(ssText, 1) = "." Then ssText = VB.Left(ssText, Len(ssText) - 1)
                If VB.Left(ssText, 1) = "." Then ssText = "0" & ssText
                '2021.08.02 UPGRADE S  AIT)dannnl
                '.SetText(10, Row, ssText)
                .ActiveSheet.SetText(Row, 9, ssText)
                '2021.08.02 UPGRADE E
                '----- �ݐϋ��z
                '2021.07.26 UPGRADE S  AIT)Tool Convert
                'ssText = VB6.Format(DE(lp).JITU_GAKU + DE(lp).RUI_GAKU, "#,##0")
                '.SetText(11, Row, ssText)
                ssText = CDec(DE(lp).JITU_GAKU + DE(lp).RUI_GAKU).ToString("#,##0")
                .ActiveSheet.SetText(Row, 10, ssText)
                '2021.07.26 UPGRADE E
                '----- ���㏊�v��������
                '2021.07.26 UPGRADE S  AIT)Tool Convert
                'ssText = VB6.Format(DE(lp).KONGO_SUU, "#,###.##")
                ssText = DE(lp).KONGO_SUU.ToString("#,###.##")
                '2021.07.26 UPGRADE E
                If VB.Right(ssText, 1) = "." Then ssText = VB.Left(ssText, Len(ssText) - 1)
                If VB.Left(ssText, 1) = "." Then ssText = "0" & ssText
                '2021.08.02 UPGRADE S  AIT)dannnl
                '.SetText(12, Row, ssText)
                .ActiveSheet.SetText(Row, 11, ssText)
                '2021.08.02 UPGRADE E
                '----- ���㏊�v�������z
                '2021.07.26 UPGRADE S  AIT)Tool Convert
                'ssText = VB6.Format(DE(lp).KONGO_GAKU, "#,##0")
                '.SetText(13, Row, ssText)
                ssText = CDec(DE(lp).KONGO_GAKU).ToString("#,##0")
                .ActiveSheet.SetText(Row, 12, ssText)
                '2021.07.26 UPGRADE E
                '----- ���{��������
                '2021.07.26 UPGRADE S  AIT)Tool Convert
                'ssText = VB6.Format(DE(lp).JISSI_SUU, "#,###.##")
                ssText = DE(lp).JISSI_SUU.ToString("#,###.##")
                '2021.07.26 UPGRADE E
                If VB.Right(ssText, 1) = "." Then ssText = VB.Left(ssText, Len(ssText) - 1)
                If VB.Left(ssText, 1) = "." Then ssText = "0" & ssText
                '2021.08.02 UPGRADE S  AIT)dannnl
                '.SetText(14, Row, ssText)
                .ActiveSheet.SetText(Row, 13, ssText)
                '2021.08.02 UPGRADE E
                '----- ���{�������z
                '2021.07.26 UPGRADE S  AIT)Tool Convert
                'ssText = VB6.Format(DE(lp).JISSI_GAKU, "#,##0")
                '.SetText(15, Row, ssText)
                ssText = CDec(DE(lp).JISSI_GAKU).ToString("#,##0")
                .ActiveSheet.SetText(Row, 14, ssText)
                '2021.07.26 UPGRADE E
                '----- �\�Z�Δ�
                '2021.07.26 UPGRADE S  AIT)Tool Convert
                'ssText = VB6.Format(DE(lp).TAIHI_GAKU, "#,##0")
                '.SetText(16, Row, ssText)
                ssText = CDec(DE(lp).TAIHI_GAKU).ToString("#,##0")
                .ActiveSheet.SetText(Row, 15, ssText)
                '2021.07.26 UPGRADE E
                '----- �ύX����
                '2021.07.26 UPGRADE S  AIT)Tool Convert
                'ssText = VB6.Format(DE(lp).ZOUGEN_GAKU, "#,##0")
                '.SetText(17, Row, ssText)
                ssText = CDec(DE(lp).ZOUGEN_GAKU).ToString("#,##0")
                .ActiveSheet.SetText(Row, 16, ssText)
                '2021.07.26 UPGRADE E
                '----- ���הԍ�
                '2021.08.02 UPGRADE S  AIT)dannnl
                'ssText = VB6.Format(WA(lp).MEISAI_NO)
                '.SetText(18, Row, ssText)
                ssText = WA(lp).MEISAI_NO
                .ActiveSheet.SetText(Row, 17, ssText)
                '2021.08.02 UPGRADE E
                '----- �W�v
                wkVal(0) = wkVal(0) + WA(lp).G_KINGAKU
                wkVal(1) = wkVal(1) + DE(lp).JITU_GAKU
                wkVal(2) = wkVal(2) + DE(lp).JITU_GAKU + DE(lp).RUI_GAKU
                wkVal(3) = wkVal(3) + DE(lp).KONGO_GAKU
                wkVal(4) = wkVal(4) + DE(lp).JISSI_GAKU
                wkVal(5) = wkVal(5) + DE(lp).TAIHI_GAKU
                wkVal(6) = wkVal(6) + DE(lp).ZOUGEN_GAKU
            Next lp
            If Me.Visible = True Then
                '2021.08.02 UPGRADE S  AIT)dannnl
                '.CtlRefresh()
                '.ReDraw = True
                .Refresh()
                .ResumeLayout()
                '2021.08.02 UPGRADE E
            End If
        End With

        '----- ���v���z
        '2021.08.02 UPGRADE S  AIT)dannnl
        'With vaSpread2
        With FpSpread2
            '2021.08.02 UPGRADE E
            If Me.Visible = True Then
                '2021.08.02 UPGRADE S  AIT)dannnl
                '.ReDraw = False
                .SuspendLayout()
                '2021.08.02 UPGRADE E
            End If
            '2021.08.02 UPGRADE S  AIT)dannnl
            '.Col = 1 : .Col2 = .MaxCols
            '.Row = 1 : .Row2 = .MaxRows
            '.BlockMode = True
            '.Font = VB6.FontChangeBold(.Font, False)
            '.Action = FPSpread.ActionConstants.ActionClearText
            '.BlockMode = False
            .Font = New Font(.Font, FontStyle.Regular)
            .ActiveSheet.RowHeader.DefaultStyle.Font = New Font(.Font, FontStyle.Bold)
            .ActiveSheet.ClearRange(0, 0, .ActiveSheet.RowCount, .ActiveSheet.ColumnCount, True)
            '2021.08.02 UPGRADE E
            '----- �\�Z���z
            '2021.07.26 UPGRADE S  AIT)Tool Convert
            'ssText = VB6.Format(wkVal(0), "#,##0")
            '.SetText(6, 1, ssText)
            ssText = CDec(wkVal(0)).ToString("#,##0")
            .ActiveSheet.SetText(0, 5, ssText)
            '2021.07.26 UPGRADE E
            '----- ���ы��z
            '2021.07.26 UPGRADE S  AIT)Tool Convert
            'ssText = VB6.Format(wkVal(1), "#,##0")
            '.SetText(9, 1, ssText)
            ssText = CDec(wkVal(1)).ToString("#,##0")
            .ActiveSheet.SetText(0, 8, ssText)
            '2021.07.26 UPGRADE E
            '----- �ݐϋ��z
            '2021.07.26 UPGRADE S  AIT)Tool Convert
            'ssText = VB6.Format(wkVal(2), "#,##0")
            '.SetText(11, 1, ssText)
            ssText = CDec(wkVal(2)).ToString("#,##0")
            .ActiveSheet.SetText(0, 10, ssText)
            '2021.07.26 UPGRADE E
            '----- ���㏊�v�������z
            '2021.07.26 UPGRADE S  AIT)Tool Convert
            'ssText = VB6.Format(wkVal(3), "#,##0")
            '.SetText(13, 1, ssText)
            ssText = CDec(wkVal(3)).ToString("#,##0")
            .ActiveSheet.SetText(0, 12, ssText)
            '2021.07.26 UPGRADE E
            '----- ���{�������z
            '2021.07.26 UPGRADE S  AIT)Tool Convert
            'ssText = VB6.Format(wkVal(4), "#,##0")
            '.SetText(15, 1, ssText)
            ssText = CDec(wkVal(4)).ToString("#,##0")
            .ActiveSheet.SetText(0, 14, ssText)
            '2021.07.26 UPGRADE E
            '----- �\�Z�Δ�
            '2021.07.26 UPGRADE S  AIT)Tool Convert
            'ssText = VB6.Format(wkVal(5), "#,##0")
            '.SetText(16, 1, ssText)
            ssText = CDec(wkVal(5)).ToString("#,##0")
            .ActiveSheet.SetText(0, 15, ssText)
            '2021.07.26 UPGRADE E
            '----- �ύX����
            '2021.07.26 UPGRADE S  AIT)Tool Convert
            'ssText = VB6.Format(wkVal(6), "#,##0")
            '.SetText(17, 1, ssText)
            ssText = CDec(wkVal(6)).ToString("#,##0")
            .ActiveSheet.SetText(0, 16, ssText)
            '2021.07.26 UPGRADE E
            If Me.Visible = True Then
                '2021.08.02 UPGRADE S  AIT)dannnl
                '.CtlRefresh()
                '.ReDraw = True
                .Refresh()
                .ResumeLayout()
                '2021.08.02 UPGRADE E
            End If
        End With

    End Sub

    '-------------------------------------------------------------------------------
    '   ����    :   ����t���O�̍X�V
    '   �֐�    :   Function FlagUpdate()
    '   ����    :   �Ȃ�
    '   �ߒl    :   True    ����I��
    '   �@�@        False   �ُ�I��
    '   �@�\    :   ����t���O�̍X�V���s���܂��B
    '-------------------------------------------------------------------------------
    Private Function FlagUpdate() As Boolean

        Dim Jouken As String

        ' �߂�l�̏�����
        FlagUpdate = False

        ' �X�V����
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
        '----- ��ݻ޸��݂̊J�n
        '2021.07.26 UPGRADE S  AIT)Tool Convert
        'SYKDB.BeginTrans()
        BeginTrans()
        '2021.07.26 UPGRADE E
        Do
            ' ����t���O�i�y�؁j
            If UpdateCtrlFlg(8) = False Then
                '2021.08.02 UPGRADE S  AIT)dannnl
                'SYKDB.RollbackTrans()
                RollBack()
                '2021.08.02 UPGRADE E
                Exit Do
            End If
            ' ���o�ύX�t���O
            Jouken = "WARIDASI_NO = '" & Trim(ChumonID) & "'"
            Jouken = Jouken & " AND EDA_NO = '" & KeyKouji.EDA_NO & "'"
            Jouken = Jouken & " AND KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"
            If UpdateHenkoFlg("WARIDASI_MAST", Jouken, "0") = False Then
                '2021.08.02 UPGRADE S  AIT)dannnl
                'SYKDB.RollbackTrans()
                RollBack()
                '2021.08.02 UPGRADE E
                Exit Do
            End If
            ' �O���ύX�t���O
            Jouken = "SIME_YM = '" & CtlKouji.SYORI_YM & "'"
            Jouken = Jouken & " AND CHUUMON_NO = '" & Trim(ChumonID) & "'"
            Jouken = Jouken & " AND EDA_NO = '" & KeyKouji.EDA_NO & "'"
            Jouken = Jouken & " AND KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"
            If UpdateHenkoFlg("GAI_KIHON_DATA", Jouken, "1") = False Then
                '2021.08.02 UPGRADE S  AIT)dannnl
                'SYKDB.RollbackTrans()
                RollBack()
                '2021.08.02 UPGRADE E
                Exit Do
            End If
            '----- ��ݻ޸��݂̊m��
            '2021.07.26 UPGRADE S  AIT)Tool Convert
            'SYKDB.CommitTrans()
            '' ����I��
            CommitTransaction()
            ' ����I��
            '2021.07.26 UPGRADE E
            FlagUpdate = True
            Exit Do
        Loop
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default

    End Function

    '2021.08.02 UPGRADE S  AIT)dannnl
    'Private Sub cmdKey_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Click
    '	Dim Index As Short = cmdKey.GetIndex(eventSender)
    Private Sub cmdKey_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _cmdKey_1.Click, _cmdKey_2.Click, _cmdKey_3.Click, _cmdKey_4.Click, _cmdKey_5.Click, _cmdKey_6.Click,
                                                                                                            _cmdKey_7.Click, _cmdKey_8.Click, _cmdKey_9.Click, _cmdKey_10.Click, _cmdKey_11.Click, _cmdKey_12.Click
        Dim Index As Short = cmdKey.IndexOf(eventSender)
        '2021.08.02 UPGRADE E

        'Dim ssText As Object�@�@�@�@�@'2021.08.11 UPGRADE DEL  AIT)dannnl

        Call MtyTool.LostFocus(cmdKey(Index), StatusBar1)�@�@�@�@�@'2021.08.09 UPGRADE ADD  AIT)dannnl

        Select Case Index
            Case 2 '----- �C��
                frmSYKD120.ShowDialog()
                '2021.08.02 UPGRADE S  AIT)dannnl
                'vaSpread1.Focus()
                FpSpread1.Focus()
                '2021.08.02 UPGRADE E

            Case 12 '----- �I��
                If UpdateFG = "1" Then
                    ' ����t���O�̍X�V
                    If FlagUpdate() = False Then
                        '
                    End If
                    UpdateFG = "0"
                    ' �ĕ\��
                    Call frmSYKD080.ListDataDisp(1)
                End If
                '2021.08.31  UPGRADE S  AIT)dannnl
                'Me.Close()
                Me.Dispose()
                '2021.08.31  UPGRADE E
        End Select

    End Sub

    '2021.08.02 UPGRADE S  AIT)dannnl
    'Private Sub cmdKey_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Enter
    '	Dim Index As Short = cmdKey.GetIndex(eventSender)
    '	Call GotFocus(cmdKey(Index), StatusBar1)
    Private Sub cmdKey_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _cmdKey_1.Enter, _cmdKey_2.Enter, _cmdKey_3.Enter, _cmdKey_4.Enter, _cmdKey_5.Enter, _cmdKey_6.Enter,
                                                                                                            _cmdKey_7.Enter, _cmdKey_8.Enter, _cmdKey_9.Enter, _cmdKey_10.Enter, _cmdKey_11.Enter, _cmdKey_12.Enter
        Dim Index As Short = cmdKey.IndexOf(eventSender)
        Call MtyTool.GotFocus(cmdKey(Index), StatusBar1)
        '2021.08.02 UPGRADE E
    End Sub

    '2021.08.02 UPGRADE S  AIT)dannnl
    'Private Sub cmdKey_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Leave
    '	Dim Index As Short = cmdKey.GetIndex(eventSender)
    '	Call LostFocus(cmdKey(Index), StatusBar1)
    Private Sub cmdKey_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _cmdKey_1.Leave, _cmdKey_2.Leave, _cmdKey_3.Leave, _cmdKey_4.Leave, _cmdKey_5.Leave, _cmdKey_6.Leave,
                                                                                                            _cmdKey_7.Leave, _cmdKey_8.Leave, _cmdKey_9.Leave, _cmdKey_10.Leave, _cmdKey_11.Leave, _cmdKey_12.Leave
        Dim Index As Short = cmdKey.IndexOf(eventSender)
        Call MtyTool.LostFocus(cmdKey(Index), StatusBar1)
        '2021.08.02 UPGRADE E
    End Sub

    Private Sub frmSYKD110_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown
        Dim KeyCode As Short = eventArgs.KeyCode
        Dim Shift As Short = eventArgs.KeyData \ &H10000
        Select Case KeyCode
            Case System.Windows.Forms.Keys.F1
                If cmdKey(1).Enabled = True Then cmdKey(1).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(1), New System.EventArgs())
            Case System.Windows.Forms.Keys.F2
                If cmdKey(2).Enabled = True Then cmdKey(2).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(2), New System.EventArgs())
            Case System.Windows.Forms.Keys.F3
                If cmdKey(3).Enabled = True Then cmdKey(3).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(3), New System.EventArgs())
            Case System.Windows.Forms.Keys.F4
                If cmdKey(4).Enabled = True Then cmdKey(4).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(4), New System.EventArgs())
            Case System.Windows.Forms.Keys.F5
                If cmdKey(5).Enabled = True Then cmdKey(5).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(5), New System.EventArgs())
            Case System.Windows.Forms.Keys.F6
                If cmdKey(6).Enabled = True Then cmdKey(6).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(6), New System.EventArgs())
            Case System.Windows.Forms.Keys.F7
                If cmdKey(7).Enabled = True Then cmdKey(7).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(7), New System.EventArgs())
            Case System.Windows.Forms.Keys.F8
                If cmdKey(8).Enabled = True Then cmdKey(8).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(8), New System.EventArgs())
            Case System.Windows.Forms.Keys.F9
                If cmdKey(9).Enabled = True Then cmdKey(9).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(9), New System.EventArgs())
            Case System.Windows.Forms.Keys.F10
                If cmdKey(10).Enabled = True Then cmdKey(10).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(10), New System.EventArgs())
            Case System.Windows.Forms.Keys.F11
                If cmdKey(11).Enabled = True Then cmdKey(11).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(11), New System.EventArgs())
            Case System.Windows.Forms.Keys.F12
                If cmdKey(12).Enabled = True Then cmdKey(12).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(12), New System.EventArgs())
        End Select
    End Sub

    Private Sub frmSYKD110_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load

        Call FormDisp(Me)

        ' ������
        UpdateFG = "0"

        ' �����\��
        Call DispClear(1)
        Call ListDataDisp(1)
        Me.ActiveControl = FpSpread1�@�@�@�@�@'2021.08.31 UPGRADE ADD  AIT)dannnl

    End Sub

    Private Sub frmSYKD110_FormClosing(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Dim Cancel As Boolean = eventArgs.Cancel
        Dim UnloadMode As System.Windows.Forms.CloseReason = eventArgs.CloseReason
        If UnloadMode = System.Windows.Forms.CloseReason.UserClosing Then
            If UpdateFG = "1" Then
                ' ����t���O�̍X�V
                If FlagUpdate() = False Then
                    '
                End If
                UpdateFG = "0"
                ' �ĕ\��
                Call frmSYKD080.ListDataDisp(1)
            End If
        End If
        eventArgs.Cancel = Cancel
    End Sub

    '2021.08.02 UPGRADE S  AIT)dannnl
    'Private Sub vaSpread1_DblClick(ByVal eventSender As System.Object, ByVal eventArgs As AxFPSpread._DSpreadEvents_DblClickEvent) Handles vaSpread1.DblClick
    '' �^�C�g���ȊO
    'If eventArgs.Col > 0 And eventArgs.Row > 0 Then
    Private Sub FpSpread1_DblClick(ByVal eventSender As System.Object, ByVal eventArgs As FarPoint.Win.Spread.CellClickEventArgs) Handles FpSpread1.CellDoubleClick
        ' �^�C�g���ȊO
        If eventArgs.Column >= 0 AndAlso eventArgs.Row >= 0 AndAlso eventArgs.ColumnHeader = False AndAlso eventArgs.RowHeader = False Then
            '2021.08.02 UPGRADE E
            ' �C������
            Call cmdKey_Click(cmdKey.Item(2), New System.EventArgs())
        End If
    End Sub

    '2021.08.02 UPGRADE S  AIT)dannnl
    'Private Sub vaSpread1_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles vaSpread1.Enter
    '	Call GotFocus(vaSpread1, StatusBar1)
    Private Sub FpSpread1_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles FpSpread1.Enter
        Call MtyTool.GotFocus(FpSpread1, StatusBar1)
        '2021.08.02 UPGRADE E
    End Sub

    '2021.08.02 UPGRADE S  AIT)dannnl
    'Private Sub vaSpread1_KeyDownEvent(ByVal eventSender As System.Object, ByVal eventArgs As AxFPSpread._DSpreadEvents_KeyDownEvent) Handles vaSpread1.KeyDownEvent
    Private Sub FpSpread1_KeyDownEvent(ByVal eventSender As System.Object, ByVal eventArgs As KeyEventArgs) Handles FpSpread1.KeyDown
        '2021.08.02 UPGRADE E
        If eventArgs.KeyCode = System.Windows.Forms.Keys.Return Then
            '2021.08.02 UPGRADE S  AIT)dannnl
            'If vaSpread1.ActiveRow > 0 Then
            If FpSpread1.ActiveSheet.ActiveRowIndex >= 0 Then
                '2021.08.02 UPGRADE E
                ' �C������
                Call cmdKey_Click(cmdKey.Item(2), New System.EventArgs())
            End If
        End If
    End Sub

    '2021.08.02 UPGRADE S  AIT)dannnl
    'Private Sub vaSpread1_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles vaSpread1.Leave
    '	Call LostFocus(vaSpread1, StatusBar1)
    Private Sub FpSpread1_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles FpSpread1.Leave
        Call MtyTool.LostFocus(FpSpread1, StatusBar1)
        '2021.08.02 UPGRADE E
    End Sub

    '2021.08.02 UPGRADE S  AIT)dannnl
    'Private Sub vaSpread1_TopLeftChange(ByVal eventSender As System.Object, ByVal eventArgs As AxFPSpread._DSpreadEvents_TopLeftChangeEvent) Handles vaSpread1.TopLeftChange
    '	vaSpread2.LeftCol = eventArgs.NewLeft
    Private Sub FpSpread1_LeftChange(ByVal eventSender As System.Object, ByVal eventArgs As FarPoint.Win.Spread.LeftChangeEventArgs) Handles FpSpread1.LeftChange
        FpSpread2.SetViewportLeftColumn(0, eventArgs.NewLeft)
    End Sub

    Private Sub FpSpread1_TopChange(ByVal eventSender As System.Object, ByVal eventArgs As FarPoint.Win.Spread.TopChangeEventArgs) Handles FpSpread1.TopChange
        FpSpread2.SetViewportTopRow(0, eventArgs.NewTop)
    End Sub
    '2021.08.02 UPGRADE E

    '2021.08.02 UPGRADE S  AIT)dannnl
    'Private Sub vaSpread2_TopLeftChange(ByVal eventSender As System.Object, ByVal eventArgs As AxFPSpread._DSpreadEvents_TopLeftChangeEvent) Handles vaSpread2.TopLeftChange
    '	vaSpread1.LeftCol = eventArgs.NewLeft
    Private Sub FpSpread2_LeftChange(ByVal eventSender As System.Object, ByVal eventArgs As FarPoint.Win.Spread.LeftChangeEventArgs) Handles FpSpread2.LeftChange
        FpSpread1.SetViewportLeftColumn(0, eventArgs.NewLeft)
    End Sub

    Private Sub FpSpread2_TopChange(ByVal eventSender As System.Object, ByVal eventArgs As FarPoint.Win.Spread.TopChangeEventArgs) Handles FpSpread2.TopChange
        FpSpread1.SetViewportTopRow(0, eventArgs.NewTop)
    End Sub
    '2021.08.02 UPGRADE E
End Class
