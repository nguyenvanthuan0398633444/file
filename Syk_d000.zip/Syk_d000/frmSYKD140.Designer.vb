Imports System.Collections.Generic
Imports GrapeCity.Win.Editors

<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frmSYKD140
#Region "Windows Form Designer generated code "
    <System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
        MyBase.New()
        'This call is required by the Windows Form Designer.
        InitializeComponent()
        '2021.08.05 UPGRADE ADD  AIT)vyhnt
        Label1 = New ArrayList()
        Label1.Add(Nothing)
        Label1.Add(_Label1_0)
        Label1.Add(_Label1_1)

        cmdKey = New ArrayList()
        cmdKey.Add(Nothing)
        cmdKey.Add(_cmdKey_1)
        cmdKey.Add(_cmdKey_2)
        cmdKey.Add(_cmdKey_3)
        cmdKey.Add(_cmdKey_4)
        cmdKey.Add(_cmdKey_5)
        cmdKey.Add(_cmdKey_6)
        cmdKey.Add(_cmdKey_7)
        cmdKey.Add(_cmdKey_8)
        cmdKey.Add(_cmdKey_9)
        cmdKey.Add(_cmdKey_10)
        cmdKey.Add(_cmdKey_11)
        cmdKey.Add(_cmdKey_12)

        imText1 = New ArrayList()
        imText1.Add(_imText1_0)
        imText1.Add(_imText1_1)

        imText2 = New ArrayList()
        imText2.Add(_imText2_0)
        imText2.Add(_imText2_1)
        imText2.Add(_imText2_2)
        '2021.08.05  UPGRADE S  AIT)*** 

    End Sub
    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
        If Disposing Then
            If Not components Is Nothing Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(Disposing)
    End Sub
    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer
    Public ToolTip1 As System.Windows.Forms.ToolTip
    Public WithEvents _cmdKey_5 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_2 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_11 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_1 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_9 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_8 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_7 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_6 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_10 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_4 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_12 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_3 As System.Windows.Forms.Button
    Public WithEvents Picture1 As System.Windows.Forms.Panel
    Public WithEvents Message As System.Windows.Forms.ToolStripStatusLabel
    Public WithEvents _StatusBar1_Panel2 As System.Windows.Forms.ToolStripStatusLabel
    Public WithEvents StatusBar1 As System.Windows.Forms.StatusStrip
    '2021.08.02 UPGRADE S  AIT)vyhnt
    'Public WithEvents _imText1_1 As imText6.imText
    'Public WithEvents _imText2_2 As imText6.imText
    'Public WithEvents _imText2_0 As imText6.imText
    'Public WithEvents _imText2_1 As imText6.imText
    'Public WithEvents _imText1_0 As imText6.imText
    Public WithEvents _imText1_1 As GcTextBox
    Public WithEvents _imText2_2 As GcTextBox
    Public WithEvents _imText2_0 As GcTextBox
    Public WithEvents _imText2_1 As GcTextBox
    Public WithEvents _imText1_0 As GcTextBox
    '2021.08.02 UPGRADE E  
    'Public WithEvents vaSpread1 As AxFPSpread.AxvaSpread
    Public WithEvents vaSpread1 As FarPoint.Win.Spread.FpSpread
    '2021.08.02 UPGRADE E  
    Public WithEvents _Label1_1 As System.Windows.Forms.Label
    Public WithEvents _Label1_0 As System.Windows.Forms.Label
    Public WithEvents lblTitle As System.Windows.Forms.Label
    '2021.08.02 UPGRADE S  AIT)vyhnt
    'Public WithEvents Label1 As Microsoft.VisualBasic.Compatibility.VB6.LabelArray
    'Public WithEvents cmdKey As Microsoft.VisualBasic.Compatibility.VB6.ButtonArray
    'Public WithEvents imText1 As imTextArray
    'Public WithEvents imText2 As imTextArray

    Public WithEvents Label1 As ArrayList
    Public WithEvents cmdKey As ArrayList
    Public WithEvents imText1 As ArrayList
    Public WithEvents imText2 As ArrayList
    '2021.08.02 UPGRADE E     

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim CustomSpdHeader As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim DefaultFocusIndicatorRenderer1 As FarPoint.Win.Spread.DefaultFocusIndicatorRenderer = New FarPoint.Win.Spread.DefaultFocusIndicatorRenderer()
        Dim DefaultScrollBarRenderer1 As FarPoint.Win.Spread.DefaultScrollBarRenderer = New FarPoint.Win.Spread.DefaultScrollBarRenderer()
        Dim NamedStyle1 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("Color65637635076670122903")
        Dim NamedStyle2 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("Font193637635076670152900")
        Dim TipAppearance1 As FarPoint.Win.Spread.TipAppearance = New FarPoint.Win.Spread.TipAppearance()
        Dim DefaultScrollBarRenderer2 As FarPoint.Win.Spread.DefaultScrollBarRenderer = New FarPoint.Win.Spread.DefaultScrollBarRenderer()
        Dim TextCellType1 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType()
        Dim TextCellType2 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType()
        Dim TextCellType3 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmSYKD140))
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.Picture1 = New System.Windows.Forms.Panel()
        Me._cmdKey_5 = New System.Windows.Forms.Button()
        Me._cmdKey_2 = New System.Windows.Forms.Button()
        Me._cmdKey_11 = New System.Windows.Forms.Button()
        Me._cmdKey_1 = New System.Windows.Forms.Button()
        Me._cmdKey_9 = New System.Windows.Forms.Button()
        Me._cmdKey_8 = New System.Windows.Forms.Button()
        Me._cmdKey_7 = New System.Windows.Forms.Button()
        Me._cmdKey_6 = New System.Windows.Forms.Button()
        Me._cmdKey_10 = New System.Windows.Forms.Button()
        Me._cmdKey_4 = New System.Windows.Forms.Button()
        Me._cmdKey_12 = New System.Windows.Forms.Button()
        Me._cmdKey_3 = New System.Windows.Forms.Button()
        Me.StatusBar1 = New System.Windows.Forms.StatusStrip()
        Me._StatusBar1_Panel2 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.Message = New System.Windows.Forms.ToolStripStatusLabel()
        Me._imText1_1 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._imText2_2 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._imText2_0 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._imText2_1 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._imText1_0 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me.vaSpread1 = New FarPoint.Win.Spread.FpSpread()
        Me.vaSpread1_Sheet1 = New FarPoint.Win.Spread.SheetView()
        Me._Label1_1 = New System.Windows.Forms.Label()
        Me._Label1_0 = New System.Windows.Forms.Label()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.Picture1.SuspendLayout()
        Me.StatusBar1.SuspendLayout()
        CType(Me._imText1_1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imText2_2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imText2_0, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imText2_1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imText1_0, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.vaSpread1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.vaSpread1_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        CustomSpdHeader.Name = "CustomSpdHeader"
        CustomSpdHeader.PictureZoomEffect = False
        CustomSpdHeader.TextRotationAngle = 0R
        CustomSpdHeader.ZoomFactor = 1.0!
        '
        'Picture1
        '
        Me.Picture1.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Picture1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Picture1.Controls.Add(Me._cmdKey_5)
        Me.Picture1.Controls.Add(Me._cmdKey_2)
        Me.Picture1.Controls.Add(Me._cmdKey_11)
        Me.Picture1.Controls.Add(Me._cmdKey_1)
        Me.Picture1.Controls.Add(Me._cmdKey_9)
        Me.Picture1.Controls.Add(Me._cmdKey_8)
        Me.Picture1.Controls.Add(Me._cmdKey_7)
        Me.Picture1.Controls.Add(Me._cmdKey_6)
        Me.Picture1.Controls.Add(Me._cmdKey_10)
        Me.Picture1.Controls.Add(Me._cmdKey_4)
        Me.Picture1.Controls.Add(Me._cmdKey_12)
        Me.Picture1.Controls.Add(Me._cmdKey_3)
        Me.Picture1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Picture1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Picture1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Picture1.Location = New System.Drawing.Point(0, 668)
        Me.Picture1.Name = "Picture1"
        Me.Picture1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Picture1.Size = New System.Drawing.Size(1016, 51)
        Me.Picture1.TabIndex = 14
        '
        '_cmdKey_5
        '
        Me._cmdKey_5.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_5.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_5.Enabled = False
        Me._cmdKey_5.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_5.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_5.Location = New System.Drawing.Point(348, 4)
        Me._cmdKey_5.Name = "_cmdKey_5"
        Me._cmdKey_5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_5.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_5.TabIndex = 5
        Me._cmdKey_5.Text = "F5"
        Me._cmdKey_5.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_5.UseVisualStyleBackColor = False
        '
        '_cmdKey_2
        '
        Me._cmdKey_2.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_2.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_2.Enabled = False
        Me._cmdKey_2.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_2.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_2.Location = New System.Drawing.Point(86, 4)
        Me._cmdKey_2.Name = "_cmdKey_2"
        Me._cmdKey_2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_2.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_2.TabIndex = 2
        Me._cmdKey_2.Text = "F2"
        Me._cmdKey_2.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_2.UseVisualStyleBackColor = False
        '
        '_cmdKey_11
        '
        Me._cmdKey_11.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_11.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_11.Enabled = False
        Me._cmdKey_11.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_11.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_11.Location = New System.Drawing.Point(849, 4)
        Me._cmdKey_11.Name = "_cmdKey_11"
        Me._cmdKey_11.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_11.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_11.TabIndex = 11
        Me._cmdKey_11.Text = "F11"
        Me._cmdKey_11.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_11.UseVisualStyleBackColor = False
        '
        '_cmdKey_1
        '
        Me._cmdKey_1.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_1.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_1.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_1.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_1.Location = New System.Drawing.Point(6, 4)
        Me._cmdKey_1.Name = "_cmdKey_1"
        Me._cmdKey_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_1.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_1.TabIndex = 1
        Me._cmdKey_1.Tag = "�O�����̖��ד��͂��s���܂��B"
        Me._cmdKey_1.Text = "F1" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "�� ��"
        Me._cmdKey_1.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_1.UseVisualStyleBackColor = False
        '
        '_cmdKey_9
        '
        Me._cmdKey_9.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_9.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_9.Enabled = False
        Me._cmdKey_9.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_9.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_9.Location = New System.Drawing.Point(689, 4)
        Me._cmdKey_9.Name = "_cmdKey_9"
        Me._cmdKey_9.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_9.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_9.TabIndex = 9
        Me._cmdKey_9.Text = "F9"
        Me._cmdKey_9.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_9.UseVisualStyleBackColor = False
        '
        '_cmdKey_8
        '
        Me._cmdKey_8.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_8.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_8.Enabled = False
        Me._cmdKey_8.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_8.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_8.Location = New System.Drawing.Point(588, 4)
        Me._cmdKey_8.Name = "_cmdKey_8"
        Me._cmdKey_8.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_8.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_8.TabIndex = 8
        Me._cmdKey_8.Text = "F8"
        Me._cmdKey_8.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_8.UseVisualStyleBackColor = False
        '
        '_cmdKey_7
        '
        Me._cmdKey_7.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_7.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_7.Enabled = False
        Me._cmdKey_7.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_7.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_7.Location = New System.Drawing.Point(508, 4)
        Me._cmdKey_7.Name = "_cmdKey_7"
        Me._cmdKey_7.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_7.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_7.TabIndex = 7
        Me._cmdKey_7.Text = "F7"
        Me._cmdKey_7.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_7.UseVisualStyleBackColor = False
        '
        '_cmdKey_6
        '
        Me._cmdKey_6.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_6.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_6.Enabled = False
        Me._cmdKey_6.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_6.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_6.Location = New System.Drawing.Point(428, 4)
        Me._cmdKey_6.Name = "_cmdKey_6"
        Me._cmdKey_6.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_6.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_6.TabIndex = 6
        Me._cmdKey_6.Text = "F6"
        Me._cmdKey_6.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_6.UseVisualStyleBackColor = False
        '
        '_cmdKey_10
        '
        Me._cmdKey_10.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_10.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_10.Enabled = False
        Me._cmdKey_10.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_10.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_10.Location = New System.Drawing.Point(769, 4)
        Me._cmdKey_10.Name = "_cmdKey_10"
        Me._cmdKey_10.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_10.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_10.TabIndex = 10
        Me._cmdKey_10.Text = "F10"
        Me._cmdKey_10.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_10.UseVisualStyleBackColor = False
        '
        '_cmdKey_4
        '
        Me._cmdKey_4.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_4.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_4.Enabled = False
        Me._cmdKey_4.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_4.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_4.Location = New System.Drawing.Point(246, 4)
        Me._cmdKey_4.Name = "_cmdKey_4"
        Me._cmdKey_4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_4.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_4.TabIndex = 4
        Me._cmdKey_4.Text = "F4"
        Me._cmdKey_4.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_4.UseVisualStyleBackColor = False
        '
        '_cmdKey_12
        '
        Me._cmdKey_12.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_12.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_12.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_12.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_12.Location = New System.Drawing.Point(929, 4)
        Me._cmdKey_12.Name = "_cmdKey_12"
        Me._cmdKey_12.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_12.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_12.TabIndex = 12
        Me._cmdKey_12.Tag = "�������I�����܂��B"
        Me._cmdKey_12.Text = "F12" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "�I ��"
        Me._cmdKey_12.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_12.UseVisualStyleBackColor = False
        '
        '_cmdKey_3
        '
        Me._cmdKey_3.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_3.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_3.Enabled = False
        Me._cmdKey_3.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_3.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_3.Location = New System.Drawing.Point(166, 4)
        Me._cmdKey_3.Name = "_cmdKey_3"
        Me._cmdKey_3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_3.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_3.TabIndex = 3
        Me._cmdKey_3.Text = "F3"
        Me._cmdKey_3.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_3.UseVisualStyleBackColor = False
        '
        'StatusBar1
        '
        Me.StatusBar1.Font = New System.Drawing.Font("MS Mincho", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.StatusBar1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me._StatusBar1_Panel2, Me.Message})
        Me.StatusBar1.Location = New System.Drawing.Point(0, 719)
        Me.StatusBar1.Name = "StatusBar1"
        Me.StatusBar1.Size = New System.Drawing.Size(1016, 23)
        Me.StatusBar1.SizingGrip = False
        Me.StatusBar1.TabIndex = 13
        '
        '_StatusBar1_Panel2
        '
        Me._StatusBar1_Panel2.AutoSize = False
        Me._StatusBar1_Panel2.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me._StatusBar1_Panel2.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter
        Me._StatusBar1_Panel2.Margin = New System.Windows.Forms.Padding(0)
        Me._StatusBar1_Panel2.Name = "_StatusBar1_Panel2"
        Me._StatusBar1_Panel2.Size = New System.Drawing.Size(117, 23)
        Me._StatusBar1_Panel2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Message
        '
        Me.Message.AutoSize = False
        Me.Message.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me.Message.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter
        Me.Message.Margin = New System.Windows.Forms.Padding(0)
        Me.Message.Name = "Message"
        Me.Message.Size = New System.Drawing.Size(902, 23)
        Me.Message.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        '_imText1_1
        '
        Me._imText1_1.BackColor = System.Drawing.SystemColors.Control
        Me._imText1_1.ContentAlignment = System.Drawing.ContentAlignment.TopRight
        Me._imText1_1.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._imText1_1.ImeMode = System.Windows.Forms.ImeMode.Off
        Me._imText1_1.Location = New System.Drawing.Point(708, 634)
        Me._imText1_1.Name = "_imText1_1"
        Me._imText1_1.ReadOnly = True
        Me._imText1_1.Size = New System.Drawing.Size(138, 23)
        Me._imText1_1.TabIndex = 16
        Me._imText1_1.TabStop = False
        '
        '_imText2_2
        '
        Me._imText2_2.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._imText2_2.ImeMode = System.Windows.Forms.ImeMode.Off
        Me._imText2_2.Location = New System.Drawing.Point(576, 6)
        Me._imText2_2.Name = "_imText2_2"
        Me._imText2_2.ReadOnly = True
        Me._imText2_2.ReadOnlyBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me._imText2_2.ReadOnlyForeColor = System.Drawing.Color.Black
        Me._imText2_2.Size = New System.Drawing.Size(433, 23)
        Me._imText2_2.TabIndex = 18
        Me._imText2_2.TabStop = False
        '
        '_imText2_0
        '
        Me._imText2_0.ContentAlignment = System.Drawing.ContentAlignment.TopCenter
        Me._imText2_0.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._imText2_0.ImeMode = System.Windows.Forms.ImeMode.Off
        Me._imText2_0.Location = New System.Drawing.Point(440, 6)
        Me._imText2_0.Name = "_imText2_0"
        Me._imText2_0.ReadOnly = True
        Me._imText2_0.ReadOnlyBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me._imText2_0.ReadOnlyForeColor = System.Drawing.Color.Black
        Me._imText2_0.Size = New System.Drawing.Size(83, 23)
        Me._imText2_0.TabIndex = 19
        Me._imText2_0.TabStop = False
        '
        '_imText2_1
        '
        Me._imText2_1.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._imText2_1.ImeMode = System.Windows.Forms.ImeMode.Off
        Me._imText2_1.Location = New System.Drawing.Point(527, 6)
        Me._imText2_1.Name = "_imText2_1"
        Me._imText2_1.ReadOnly = True
        Me._imText2_1.ReadOnlyBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me._imText2_1.ReadOnlyForeColor = System.Drawing.Color.Black
        Me._imText2_1.Size = New System.Drawing.Size(45, 23)
        Me._imText2_1.TabIndex = 20
        Me._imText2_1.TabStop = False
        '
        '_imText1_0
        '
        Me._imText1_0.BackColor = System.Drawing.SystemColors.Control
        Me._imText1_0.ContentAlignment = System.Drawing.ContentAlignment.TopCenter
        Me._imText1_0.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._imText1_0.ImeMode = System.Windows.Forms.ImeMode.Off
        Me._imText1_0.Location = New System.Drawing.Point(120, 46)
        Me._imText1_0.Name = "_imText1_0"
        Me._imText1_0.ReadOnly = True
        Me._imText1_0.Size = New System.Drawing.Size(81, 23)
        Me._imText1_0.TabIndex = 21
        Me._imText1_0.TabStop = False
        '
        'vaSpread1
        '
        Me.vaSpread1.AccessibleDescription = "vaSpread1, Sheet1, Row 0, Column 0"
        Me.vaSpread1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.vaSpread1.FocusRenderer = DefaultFocusIndicatorRenderer1
        Me.vaSpread1.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.vaSpread1.HorizontalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.vaSpread1.HorizontalScrollBar.Name = ""
        Me.vaSpread1.HorizontalScrollBar.Renderer = DefaultScrollBarRenderer1
        Me.vaSpread1.HorizontalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.Never
        Me.vaSpread1.Location = New System.Drawing.Point(18, 76)
        Me.vaSpread1.Name = "vaSpread1"
        NamedStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        NamedStyle1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        NamedStyle1.Locked = False
        NamedStyle2.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        NamedStyle2.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold)
        NamedStyle2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        NamedStyle2.Locked = False
        Me.vaSpread1.RowSplitBoxAlignment = FarPoint.Win.Spread.SplitBoxAlignment.Trailing
        Me.vaSpread1.RowSplitBoxPolicy = FarPoint.Win.Spread.SplitBoxPolicy.Never
        Me.vaSpread1.ScrollBarTrackPolicy = FarPoint.Win.Spread.ScrollBarTrackPolicy.Vertical
        Me.vaSpread1.SelectionBlockOptions = FarPoint.Win.Spread.SelectionBlockOptions.Rows
        Me.vaSpread1.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.vaSpread1_Sheet1})
        Me.vaSpread1.Size = New System.Drawing.Size(979, 549)
        Me.vaSpread1.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Classic
        Me.vaSpread1.NamedStyles.AddRange(New FarPoint.Win.Spread.NamedStyle() {NamedStyle1, NamedStyle2})
        Me.vaSpread1.TabIndex = 0
        Me.vaSpread1.Tag = "�f�[�^��I�����ĉ������B"
        TipAppearance1.BackColor = System.Drawing.SystemColors.Info
        TipAppearance1.Font = New System.Drawing.Font("MS Mincho", 9.0!)
        TipAppearance1.ForeColor = System.Drawing.SystemColors.InfoText
        Me.vaSpread1.TextTipAppearance = TipAppearance1
        Me.vaSpread1.TitleInfo.ForeColor = System.Drawing.Color.Black
        Me.vaSpread1.VerticalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.vaSpread1.VerticalScrollBar.Name = ""
        Me.vaSpread1.VerticalScrollBar.Renderer = DefaultScrollBarRenderer2
        Me.vaSpread1.VerticalScrollBarWidth = 20
        Me.vaSpread1.VisualStyles = FarPoint.Win.VisualStyles.Off
        Me.vaSpread1.SetViewportTopRow(0, 0, 4)
        '
        'vaSpread1_Sheet1
        '
        Me.vaSpread1_Sheet1.Reset()
        Me.vaSpread1_Sheet1.SheetName = "Sheet1"
        'Formulas and custom names must be loaded with R1C1 reference style
        Me.vaSpread1_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1
        Me.vaSpread1_Sheet1.ColumnCount = 7
        Me.vaSpread1_Sheet1.RowCount = 100
        Me.vaSpread1_Sheet1.ActiveSkin = FarPoint.Win.Spread.DefaultSkins.Classic
        TextCellType1.Static = True
        Me.vaSpread1_Sheet1.Cells.Get(0, 0).CellType = TextCellType1
        Me.vaSpread1_Sheet1.Cells.Get(0, 0).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.vaSpread1_Sheet1.Cells.Get(0, 0).Value = "Z9"
        Me.vaSpread1_Sheet1.Cells.Get(0, 0).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        TextCellType2.Static = True
        Me.vaSpread1_Sheet1.Cells.Get(0, 1).CellType = TextCellType2
        Me.vaSpread1_Sheet1.Cells.Get(0, 1).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Left
        Me.vaSpread1_Sheet1.Cells.Get(0, 1).Value = "�P�Q�R�S�T�U�V�W�X�O�P�Q�R�S�T�U�V�W�X�O"
        Me.vaSpread1_Sheet1.Cells.Get(0, 1).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.vaSpread1_Sheet1.Cells.Get(0, 2).Value = "00000010"
        Me.vaSpread1_Sheet1.Cells.Get(0, 3).CellType = TextCellType2
        Me.vaSpread1_Sheet1.Cells.Get(0, 3).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Left
        Me.vaSpread1_Sheet1.Cells.Get(0, 3).Value = "�P�Q�R�S�T�U�V�W�X�O�P�Q�R�S�T�U�V�W�X�O"
        Me.vaSpread1_Sheet1.Cells.Get(0, 3).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.vaSpread1_Sheet1.Cells.Get(0, 4).Value = "100,000"
        Me.vaSpread1_Sheet1.Cells.Get(0, 5).CellType = TextCellType1
        Me.vaSpread1_Sheet1.Cells.Get(0, 5).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.vaSpread1_Sheet1.Cells.Get(0, 5).Value = "�ύX����"
        Me.vaSpread1_Sheet1.Cells.Get(0, 5).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.vaSpread1_Sheet1.Cells.Get(1, 1).CellType = TextCellType2
        Me.vaSpread1_Sheet1.Cells.Get(1, 1).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Left
        Me.vaSpread1_Sheet1.Cells.Get(1, 1).Value = "1234567890123456789012345678901234567890"
        Me.vaSpread1_Sheet1.Cells.Get(1, 1).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.vaSpread1_Sheet1.Cells.Get(1, 2).Value = "00000010"
        Me.vaSpread1_Sheet1.Cells.Get(1, 3).CellType = TextCellType2
        Me.vaSpread1_Sheet1.Cells.Get(1, 3).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Left
        Me.vaSpread1_Sheet1.Cells.Get(1, 3).Value = "1234567890123456789012345678901234567890"
        Me.vaSpread1_Sheet1.Cells.Get(1, 3).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.vaSpread1_Sheet1.Cells.Get(1, 4).Value = "150,000"
        Me.vaSpread1_Sheet1.Cells.Get(1, 6).CellType = TextCellType1
        Me.vaSpread1_Sheet1.Cells.Get(1, 6).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.vaSpread1_Sheet1.Cells.Get(1, 6).Value = "��"
        Me.vaSpread1_Sheet1.Cells.Get(1, 6).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.vaSpread1_Sheet1.Cells.Get(2, 2).Value = "00000020"
        Me.vaSpread1_Sheet1.Cells.Get(2, 3).Value = "�ƎЂQ�O"
        Me.vaSpread1_Sheet1.Cells.Get(2, 4).Value = "80,000"
        Me.vaSpread1_Sheet1.Cells.Get(3, 2).Value = "00000020"
        Me.vaSpread1_Sheet1.Cells.Get(3, 3).Value = "�ƎЂQ�O"
        Me.vaSpread1_Sheet1.Cells.Get(3, 4).Value = "200,000"
        Me.vaSpread1_Sheet1.Cells.Get(4, 2).Value = "00000030"
        Me.vaSpread1_Sheet1.Cells.Get(4, 3).Value = "�ƎЂR�O"
        Me.vaSpread1_Sheet1.Cells.Get(4, 4).Value = "5,000"
        Me.vaSpread1_Sheet1.Cells.Get(5, 2).Value = "00000030"
        Me.vaSpread1_Sheet1.Cells.Get(5, 3).Value = "�ƎЂR�O"
        Me.vaSpread1_Sheet1.Cells.Get(5, 4).Value = "35,500"
        Me.vaSpread1_Sheet1.Cells.Get(6, 2).Value = "99999999"
        Me.vaSpread1_Sheet1.Cells.Get(6, 3).Value = "�ƎЖ���"
        Me.vaSpread1_Sheet1.Cells.Get(6, 4).Value = "29,590"
        TextCellType3.Static = True
        Me.vaSpread1_Sheet1.Cells.Get(24, 4).CellType = TextCellType3
        Me.vaSpread1_Sheet1.Cells.Get(24, 4).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Right
        Me.vaSpread1_Sheet1.Cells.Get(24, 4).Value = "999,999,999"
        Me.vaSpread1_Sheet1.Cells.Get(24, 4).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.vaSpread1_Sheet1.ColumnFooter.Columns.Default.Resizable = True
        Me.vaSpread1_Sheet1.ColumnFooter.Columns.Default.SortIndicator = FarPoint.Win.Spread.Model.SortIndicator.None
        Me.vaSpread1_Sheet1.ColumnFooter.Columns.Default.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.vaSpread1_Sheet1.ColumnFooter.DefaultStyle.BackColor = System.Drawing.Color.Empty
        Me.vaSpread1_Sheet1.ColumnFooter.DefaultStyle.ForeColor = System.Drawing.Color.Empty
        Me.vaSpread1_Sheet1.ColumnFooter.DefaultStyle.Locked = False
        Me.vaSpread1_Sheet1.ColumnFooter.DefaultStyle.Parent = "HeaderDefault"
        Me.vaSpread1_Sheet1.ColumnFooter.DefaultStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.vaSpread1_Sheet1.ColumnFooter.Rows.Default.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.vaSpread1_Sheet1.ColumnFooterSheetCornerStyle.BackColor = System.Drawing.Color.Empty
        Me.vaSpread1_Sheet1.ColumnFooterSheetCornerStyle.ForeColor = System.Drawing.Color.Empty
        Me.vaSpread1_Sheet1.ColumnFooterSheetCornerStyle.Locked = False
        Me.vaSpread1_Sheet1.ColumnFooterSheetCornerStyle.Parent = "HeaderDefault"
        Me.vaSpread1_Sheet1.ColumnFooterSheetCornerStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.vaSpread1_Sheet1.ColumnHeader.Cells.Get(0, 0).Value = "������"
        Me.vaSpread1_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = "���@�@��"
        Me.vaSpread1_Sheet1.ColumnHeader.Cells.Get(0, 2).Value = "�Ǝк���"
        Me.vaSpread1_Sheet1.ColumnHeader.Cells.Get(0, 3).Value = "�ƎЖ���"
        Me.vaSpread1_Sheet1.ColumnHeader.Cells.Get(0, 4).Value = "����x���z"
        Me.vaSpread1_Sheet1.ColumnHeader.Cells.Get(0, 5).Value = "�O������"
        Me.vaSpread1_Sheet1.ColumnHeader.Cells.Get(0, 6).Value = "���Z"
        Me.vaSpread1_Sheet1.ColumnHeader.Columns.Default.Resizable = True
        Me.vaSpread1_Sheet1.ColumnHeader.Columns.Default.SortIndicator = FarPoint.Win.Spread.Model.SortIndicator.None
        Me.vaSpread1_Sheet1.ColumnHeader.Columns.Default.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.vaSpread1_Sheet1.ColumnHeader.DefaultStyle.BackColor = System.Drawing.Color.Empty
        Me.vaSpread1_Sheet1.ColumnHeader.DefaultStyle.ForeColor = System.Drawing.Color.Empty
        Me.vaSpread1_Sheet1.ColumnHeader.DefaultStyle.Locked = False
        Me.vaSpread1_Sheet1.ColumnHeader.DefaultStyle.Parent = "HeaderDefault"
        Me.vaSpread1_Sheet1.ColumnHeader.DefaultStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.vaSpread1_Sheet1.ColumnHeader.Rows.Default.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.vaSpread1_Sheet1.ColumnHeader.Rows.Get(0).Height = 25.0!
        Me.vaSpread1_Sheet1.Columns.Default.Resizable = True
        Me.vaSpread1_Sheet1.Columns.Default.SortIndicator = FarPoint.Win.Spread.Model.SortIndicator.None
        Me.vaSpread1_Sheet1.Columns.Get(0).CellType = TextCellType1
        Me.vaSpread1_Sheet1.Columns.Get(0).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.vaSpread1_Sheet1.Columns.Get(0).Label = "������"
        Me.vaSpread1_Sheet1.Columns.Get(0).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.vaSpread1_Sheet1.Columns.Get(1).CellType = TextCellType2
        Me.vaSpread1_Sheet1.Columns.Get(1).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Left
        Me.vaSpread1_Sheet1.Columns.Get(1).Label = "���@�@��"
        Me.vaSpread1_Sheet1.Columns.Get(1).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.vaSpread1_Sheet1.Columns.Get(1).Width = 247.0!
        Me.vaSpread1_Sheet1.Columns.Get(2).CellType = TextCellType1
        Me.vaSpread1_Sheet1.Columns.Get(2).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.vaSpread1_Sheet1.Columns.Get(2).Label = "�Ǝк���"
        Me.vaSpread1_Sheet1.Columns.Get(2).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.vaSpread1_Sheet1.Columns.Get(2).Width = 89.0!
        Me.vaSpread1_Sheet1.Columns.Get(3).CellType = TextCellType2
        Me.vaSpread1_Sheet1.Columns.Get(3).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Left
        Me.vaSpread1_Sheet1.Columns.Get(3).Label = "�ƎЖ���"
        Me.vaSpread1_Sheet1.Columns.Get(3).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.vaSpread1_Sheet1.Columns.Get(3).Width = 253.0!
        Me.vaSpread1_Sheet1.Columns.Get(4).CellType = TextCellType3
        Me.vaSpread1_Sheet1.Columns.Get(4).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Right
        Me.vaSpread1_Sheet1.Columns.Get(4).Label = "����x���z"
        Me.vaSpread1_Sheet1.Columns.Get(4).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.vaSpread1_Sheet1.Columns.Get(4).Width = 125.0!
        Me.vaSpread1_Sheet1.Columns.Get(5).CellType = TextCellType1
        Me.vaSpread1_Sheet1.Columns.Get(5).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.vaSpread1_Sheet1.Columns.Get(5).Label = "�O������"
        Me.vaSpread1_Sheet1.Columns.Get(5).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.vaSpread1_Sheet1.Columns.Get(5).Width = 84.0!
        Me.vaSpread1_Sheet1.Columns.Get(6).CellType = TextCellType1
        Me.vaSpread1_Sheet1.Columns.Get(6).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.vaSpread1_Sheet1.Columns.Get(6).Label = "���Z"
        Me.vaSpread1_Sheet1.Columns.Get(6).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.vaSpread1_Sheet1.Columns.Get(6).Width = 55.0!
        Me.vaSpread1_Sheet1.DefaultStyle.BackColor = System.Drawing.Color.Empty
        Me.vaSpread1_Sheet1.DefaultStyle.ForeColor = System.Drawing.Color.Empty
        Me.vaSpread1_Sheet1.DefaultStyle.Locked = False
        Me.vaSpread1_Sheet1.DefaultStyle.Parent = "DataAreaDefault"
        Me.vaSpread1_Sheet1.FilterBar.DefaultStyle.BackColor = System.Drawing.Color.Empty
        Me.vaSpread1_Sheet1.FilterBar.DefaultStyle.ForeColor = System.Drawing.Color.Empty
        Me.vaSpread1_Sheet1.FilterBar.DefaultStyle.Locked = False
        Me.vaSpread1_Sheet1.FilterBar.DefaultStyle.Parent = "FilterBarDefault"
        Me.vaSpread1_Sheet1.FilterBar.DefaultStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.vaSpread1_Sheet1.FilterBarHeaderStyle.BackColor = System.Drawing.Color.Empty
        Me.vaSpread1_Sheet1.FilterBarHeaderStyle.ForeColor = System.Drawing.Color.Empty
        Me.vaSpread1_Sheet1.FilterBarHeaderStyle.Locked = False
        Me.vaSpread1_Sheet1.FilterBarHeaderStyle.Parent = "RowHeaderDefault"
        Me.vaSpread1_Sheet1.FilterBarHeaderStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.vaSpread1_Sheet1.OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        Me.vaSpread1_Sheet1.Protect = True
        Me.vaSpread1_Sheet1.RowHeader.Columns.Default.Resizable = False
        Me.vaSpread1_Sheet1.RowHeader.Columns.Default.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.vaSpread1_Sheet1.RowHeader.Columns.Get(0).Width = 44.0!
        Me.vaSpread1_Sheet1.RowHeader.DefaultStyle.BackColor = System.Drawing.Color.Empty
        Me.vaSpread1_Sheet1.RowHeader.DefaultStyle.ForeColor = System.Drawing.Color.Empty
        Me.vaSpread1_Sheet1.RowHeader.DefaultStyle.Locked = False
        Me.vaSpread1_Sheet1.RowHeader.DefaultStyle.Parent = "HeaderDefault"
        Me.vaSpread1_Sheet1.RowHeader.DefaultStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.vaSpread1_Sheet1.RowHeader.Rows.Default.Resizable = False
        Me.vaSpread1_Sheet1.RowHeader.Rows.Default.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.vaSpread1_Sheet1.Rows.Default.Resizable = False
        Me.vaSpread1_Sheet1.SelectionUnit = FarPoint.Win.Spread.Model.SelectionUnit.Row
        Me.vaSpread1_Sheet1.SheetCornerStyle.BackColor = System.Drawing.Color.Empty
        Me.vaSpread1_Sheet1.SheetCornerStyle.ForeColor = System.Drawing.Color.Empty
        Me.vaSpread1_Sheet1.SheetCornerStyle.Locked = False
        Me.vaSpread1_Sheet1.SheetCornerStyle.Parent = "HeaderDefault"
        Me.vaSpread1_Sheet1.SheetCornerStyle.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.vaSpread1_Sheet1.SheetCornerStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.vaSpread1_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1
        '
        '_Label1_1
        '
        Me._Label1_1.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_1.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_1.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_1.ForeColor = System.Drawing.Color.White
        Me._Label1_1.Location = New System.Drawing.Point(18, 46)
        Me._Label1_1.Name = "_Label1_1"
        Me._Label1_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_1.Size = New System.Drawing.Size(100, 23)
        Me._Label1_1.TabIndex = 22
        Me._Label1_1.Text = "���N��"
        Me._Label1_1.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        '_Label1_0
        '
        Me._Label1_0.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me._Label1_0.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_0.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_0.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._Label1_0.ForeColor = System.Drawing.Color.White
        Me._Label1_0.Location = New System.Drawing.Point(588, 634)
        Me._Label1_0.Name = "_Label1_0"
        Me._Label1_0.Padding = New System.Windows.Forms.Padding(0, 1, 0, 0)
        Me._Label1_0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_0.Size = New System.Drawing.Size(118, 23)
        Me._Label1_0.TabIndex = 17
        Me._Label1_0.Text = "���v���z"
        Me._Label1_0.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'lblTitle
        '
        Me.lblTitle.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblTitle.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTitle.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblTitle.Font = New System.Drawing.Font("MS Mincho", 20.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblTitle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.lblTitle.Location = New System.Drawing.Point(0, 0)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblTitle.Size = New System.Drawing.Size(1015, 34)
        Me.lblTitle.TabIndex = 15
        Me.lblTitle.Text = " �O���ꗗ�i�y�؁j"
        '
        'frmSYKD140
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(1016, 742)
        Me.Controls.Add(Me.Picture1)
        Me.Controls.Add(Me.StatusBar1)
        Me.Controls.Add(Me._imText1_1)
        Me.Controls.Add(Me._imText2_2)
        Me.Controls.Add(Me._imText2_0)
        Me.Controls.Add(Me._imText2_1)
        Me.Controls.Add(Me._imText1_0)
        Me.Controls.Add(Me._Label1_1)
        Me.Controls.Add(Me._Label1_0)
        Me.Controls.Add(Me.lblTitle)
        Me.Controls.Add(Me.vaSpread1)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.KeyPreview = True
        Me.Location = New System.Drawing.Point(4, 23)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmSYKD140"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "�H���Ǘ��V�X�e��"
        Me.Picture1.ResumeLayout(False)
        Me.StatusBar1.ResumeLayout(False)
        Me.StatusBar1.PerformLayout()
        CType(Me._imText1_1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._imText2_2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._imText2_0, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._imText2_1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._imText1_0, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.vaSpread1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.vaSpread1_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents vaSpread1_Sheet1 As FarPoint.Win.Spread.SheetView
#End Region
End Class