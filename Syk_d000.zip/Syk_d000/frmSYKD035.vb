Option Strict Off
Option Explicit On
Friend Class frmSYKD035
	Inherits System.Windows.Forms.Form
	'
	
	Private Sub cmdKey_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Click
		Dim Index As Short = cmdKey.GetIndex(eventSender)
		
		Dim wkCD1 As String
		Dim wkCD2 As String
		Dim Jouken As String
		Dim Msg As String
		
		'----- �ϐ��̏�����
		wkCD1 = ""
		wkCD2 = ""
		
		Select Case Index
			Case 1 '----- �������
				'2021.09.14 UPGRADE S  AIT)dannnl
				'If MsgBox("�ꗗ��������܂��B��낵���ł����H", MsgBoxStyle.YesNo) = MsgBoxResult.No Then
				If MsgBox("�ꗗ��������܂��B��낵���ł����H", MsgBoxStyle.YesNo, Me.Text) = MsgBoxResult.No Then
				'2021.09.14 UPGRADE E
					Exit Sub
				End If
				
				'----- ���o���̎擾
				wkCD1 = Trim(imText1(0).Text)
				wkCD2 = Trim(imText1(1).Text)
				
				System.Windows.Forms.Application.DoEvents()
				System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
				StatusBar1.Items.Item("Message").Text = "����f�[�^�쐬���E�E�E"
				System.Windows.Forms.Application.DoEvents()
				If PrnMainD035(wkCD1, wkCD2) = True Then
					'2001/01/21 �ҏW�̏ꍇ�̂ݍX�V����
					If INPMODE = "2" Then '�ҏW��
						' �H�����i����j���z�̍X�V
						CtlKouji.P_FLG_WARIDASI = "1" '���FLG ���c�E�O�����o���ꗗ
						Jouken = "KOUJI_NO = '" & CtlKouji.KOUJI_NO & "' AND EDA_NO = '" & CtlKouji.EDA_NO & "'"
						If UPDATE_KOUJI_CTRL_D(Jouken, CtlKouji) = False Then
							Msg = "�H�����i����j���z�̍X�V�Ɏ��s���܂����B"
							'2021.09.14 UPGRADE S  AIT)dannnl
							'MsgBox(Msg, MsgBoxStyle.OKOnly)
							MsgBox(Msg, MsgBoxStyle.OKOnly, Me.Text)
							'2021.09.14 UPGRADE E
							Exit Sub
						End If
					End If
				End If
				System.Windows.Forms.Application.DoEvents()
				System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
				StatusBar1.Items.Item("Message").Text = ""
				System.Windows.Forms.Application.DoEvents()
				
			Case 12 '----- �����I��
	' \\TODO: Please confirm and migrate This case manual
				Me.Close()
		End Select
		
	End Sub
	
	Private Sub cmdKey_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Enter
		Dim Index As Short = cmdKey.GetIndex(eventSender)
		Call GotFocus(cmdKey(Index), StatusBar1)
	End Sub
	
	Private Sub cmdKey_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Leave
		Dim Index As Short = cmdKey.GetIndex(eventSender)
		Call LostFocus(cmdKey(Index), StatusBar1)
	End Sub
	Private Sub cmdLook_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdLook.Click
		Dim Index As Short = cmdLook.GetIndex(eventSender)
		
		Select Case Index
			Case 0 '�H��}�X�^����
				frmSearch.MastNo = 1
				frmSearch.ZENTEI = "GYOUSYU_KB = '" & GyosyuID & "' AND KOUSYU_NO = '00'"
				frmSearch.ShowDialog()
				If frmSearch.GetCD <> "" Then
					imText1(Index).Text = Mid(Trim(frmSearch.GetCD), 1, 1)
					imText2(Index).Text = frmSearch.GetNM
					imText1(Index).Focus()
					Exit Sub
				End If
				imText1(1).Focus()
				
			Case 1 '�H��}�X�^����
				frmSearch.MastNo = 1
				frmSearch.ZENTEI = "GYOUSYU_KB = '" & GyosyuID & "' AND KOUSYU_NO = '00'"
				frmSearch.ShowDialog()
				If frmSearch.GetCD <> "" Then
					imText1(Index).Text = Mid(Trim(frmSearch.GetCD), 1, 1)
					imText2(Index).Text = frmSearch.GetNM
					imText1(1).Focus()
					Exit Sub
				End If
				cmdKey(1).Focus()
		End Select
		
	End Sub
	
	Private Sub frmSYKD035_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown
		Dim KeyCode As Short = eventArgs.KeyCode
		Dim Shift As Short = eventArgs.KeyData \ &H10000
		Select Case KeyCode
			Case System.Windows.Forms.Keys.Return
				Call NextCntlGet(Me, Me.ActiveControl.TabIndex)
			Case System.Windows.Forms.Keys.F1
				If cmdKey(1).Enabled = True Then cmdKey(1).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(1), New System.EventArgs())
			Case System.Windows.Forms.Keys.F12
				If cmdKey(12).Enabled = True Then cmdKey(12).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(12), New System.EventArgs())
		End Select
	End Sub
	
	Private Sub frmSYKD035_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
		Call FormDisp(Me)
	End Sub
	
	Private Sub imText1_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles imText1.Enter
		Dim Index As Short = imText1.GetIndex(eventSender)
		Call GotFocus(imText1(Index), StatusBar1)
	End Sub
	
	Private Sub imText1_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles imText1.KeyDown
		Dim KeyCode As Short = eventArgs.KeyCode
		Dim Shift As Short = eventArgs.KeyData \ &H10000
		Dim Index As Short = imText1.GetIndex(eventSender)
		Select Case KeyCode
			Case System.Windows.Forms.Keys.Space
				Call cmdLook_Click(cmdLook.Item(Index), New System.EventArgs())
		End Select
	End Sub
	
	Private Sub imText1_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles imText1.Leave
		Dim Index As Short = imText1.GetIndex(eventSender)
		Call LostFocus(imText1(Index), StatusBar1)
		Select Case Index
			Case 0 '----- �H�햼��
				imText2(Index).Text = GetNameKousyu(GyosyuID, imText1(Index).Text)
			Case 1 '----- �H�햼��
				imText2(Index).Text = GetNameKousyu(GyosyuID, imText1(Index).Text)
		End Select
	End Sub
End Class
