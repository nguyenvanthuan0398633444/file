Option Strict Off
Option Explicit On

Module SykTool
    '
    Public INPMODE As String ' ���̓��[�h
    Public SEIGYO As SEIGYO_MAST_DBT ' ������

    Public Const KISHU As String = "06"
    Public Const Kasi20CD As String = "301100" ' 20������ �ݕ��Ȗں���
    Public Const Kasi27CD As String = "301200" ' 27������ �ݕ��Ȗں���
    '

    '-------------------------------------------------------------------------------
    '   ����   :   �ύX�t���O�̍X�V
    '   �֐�   :   Function UpdateHenkoFlg()
    '   ����   :   TableID  �ύXð��ٖ�
    '   �@�@       Jouken   �X�V����
    '   �@�@       SetFlg   �ݒ�l
    '   �ߒl   :   True     ����I��
    '   �@�@       False    �ُ�I��
    '   �@�\   :   �ύX�t���O�̍X�V���s���B
    '-------------------------------------------------------------------------------
    Public Function UpdateHenkoFlg(ByRef TableID As String, ByRef Jouken As String, ByRef SetFlg As String) As Boolean

        Dim SQL As String

        '2021.07.26 UPGRADE S  AIT)Tool Convert
        'On Error GoTo UpdateHenkoFlg_Err
        Try
            '2021.07.26 UPGRADE E

            '�߂�l�̏�����
            UpdateHenkoFlg = False

            'SQL/UPDATE���g��
            SQL = "UPDATE " & TableID
            SQL = SQL & " SET HENKOU_FLG = '" & SetFlg & "'"
            If Trim(Jouken) <> "" Then
                SQL = SQL & " WHERE " & Trim(Jouken)
            End If

            'SQL�����s
            '2021.08.04 UPGRADE S  AIT)dannnl
            'SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText + ADODB.ExecuteOptionEnum.adExecuteNoRecords)
            ExecSQL(SQL)
            '2021.08.04 UPGRADE E

            '�߂�l�̃Z�b�g
            UpdateHenkoFlg = True
            Exit Function

            '2021.07.26 UPGRADE S  AIT)Tool Convert
            'UpdateHenkoFlg_Err:

            'Call Sql_Error_Msg("HENKOU_FLG UPDATE")
        Catch ex As Exception
            '2021.07.26 UPGRADE E

            Call Sql_Error_Msg(ex, "HENKOU_FLG UPDATE")

        End Try     '2021.07.26 UPGRADE ADD AIT)Tool Convert
    End Function

    '-------------------------------------------------------------------------------
    '   ����   :   ���Z�t���O�̍X�V
    '   �֐�   :   Function UpdateSeisanFlg()
    '   ����   :   TableID  �ύXð��ٖ�
    '   �@�@       Jouken   �X�V����
    '   �@�@       SetFlg   �ݒ�l
    '   �ߒl   :   True     ����I��
    '   �@�@       False    �ُ�I��
    '   �@�\   :   ���Z�t���O�̍X�V���s���B
    '-------------------------------------------------------------------------------
    Public Function UpdateSeisanFlg(ByRef TableID As String, ByRef Jouken As String, ByRef SetFlg As String) As Boolean

        Dim SQL As String

        '2021.07.26 UPGRADE S  AIT)Tool Convert
        'On Error GoTo UpdateSeisanFlg_Err
        Try
            '2021.07.26 UPGRADE E

            '�߂�l�̏�����
            UpdateSeisanFlg = False

            'SQL/UPDATE���g��
            SQL = "UPDATE " & TableID
            SQL = SQL & " SET SEISAN_FLG = '" & SetFlg & "'"
            If Trim(Jouken) <> "" Then
                SQL = SQL & " WHERE " & Trim(Jouken)
            End If

            'SQL�����s
            '2021.08.04 UPGRADE S  AIT)dannnl
            'SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText + ADODB.ExecuteOptionEnum.adExecuteNoRecords)
            ExecSQL(SQL)
            '2021.08.04 UPGRADE E

            '�߂�l�̃Z�b�g
            UpdateSeisanFlg = True
            Exit Function

            '2021.07.26 UPGRADE S  AIT)Tool Convert
            'UpdateSeisanFlg_Err:

            'Call Sql_Error_Msg("SEISAN_FLG UPDATE")
        Catch ex As Exception
            '2021.07.26 UPGRADE E

            Call Sql_Error_Msg(ex, "SEISAN_FLG UPDATE")

        End Try     '2021.07.26 UPGRADE ADD AIT)Tool Convert
    End Function

    '-------------------------------------------------------------------------------
    '   ����   :   �O����N���̎擾
    '   �֐�   :   Function GetPreSimeYM()
    '   ����   :   TableID  �擾ð��ٖ�
    '   �@�@       Jouken   ���o����
    '   �ߒl   :   �O����N��
    '   �@�\   :   �O��̒��N���̎擾���s���B
    '-------------------------------------------------------------------------------
    Public Function GetPreSimeYM(ByRef TableID As String, ByRef Jouken As String) As String

        Dim SQL As String
        '2021.08.04 UPGRADE S  AIT)dannnl
        'Dim Rs As ADODB.Recordset
        Dim Rs As New DataTable
        '2021.08.04 UPGRADE E
        Dim strBuf As String

        On Error Resume Next

        '�߂�l�̏�����
        GetPreSimeYM = ""

        'SQL/SELECT���g��
        '2021.08.10 UPGRADE S  AIT)hieutv
        'SQL = "SELECT MAX(SIME_YM) FROM " & TableID
        SQL = "SELECT MAX(SIME_YM) AS MAXDATA FROM " & TableID
        '2021.08.10 UPGRADE E
        If Trim(Jouken) <> "" Then
            SQL = SQL & " WHERE " & Trim(Jouken)
        End If

        'SQL�����s
        '2021.08.04 UPGRADE S  AIT)dannnl
        'Rs = SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText)
        Rs = RsOpen(SQL)
        '2021.08.04 UPGRADE E
        strBuf = ""
        '2021.08.04 UPGRADE S  AIT)dannnl
        'If Rs.EOF = False Then
        '    If IsDBNull(Rs.Fields(0).Value) = False Then
        '        strBuf = Rs.Fields(0).Value
        '    End If
        'End If
        'Rs.Close()
        If Rs.Rows.Count > 0 Then
            If IsDBNull(Rs.Rows(0)("MAXDATA")) = False Then
                strBuf = Rs.Rows(0)("MAXDATA")
            End If
        End If
        Rs.Dispose()
        '2021.08.04 UPGRADE E
        Rs = Nothing

        '�߂�l�̃Z�b�g
        GetPreSimeYM = strBuf

    End Function

    '-------------------------------------------------------------------------------
    '   ����   :   �}�X�^�ύX���t�̍X�V
    '   �֐�   :   Function UpdateMastDate()
    '   ����   :   Mode     0=�Ǝ� 1=�H�� 2=�Ј� 3:�ז�
    '   �ߒl   :   True     ����I��
    '   �@�@       False    �ُ�I��
    '   �@�\   :   �}�X�^�̕ύX���t�̍X�V���s���B
    '-------------------------------------------------------------------------------
    Public Function UpdateMastDate(ByRef Mode As Short) As Boolean

        Dim SQL As String

        '2021.07.26 UPGRADE S  AIT)Tool Convert
        'On Error GoTo UpdateMastDate_Err
        Try
            '2021.07.26 UPGRADE E

            '�߂�l�̃Z�b�g
            UpdateMastDate = True
            Exit Function

            '�߂�l�̏�����
            UpdateMastDate = False

            'SQL/UPDATE���g��
            SQL = "UPDATE SEIGYO_MAST SET"
            Select Case Mode
                Case 0 : SQL = SQL & " H_YMD_GYOUSYA ="
                Case 1 : SQL = SQL & " H_YMD_KOUSYU ="
                Case 2 : SQL = SQL & " H_YMD_SYAIN ="
                Case 3 : SQL = SQL & " H_YMD_SAIMOKU ="
            End Select
            '2021.07.26 UPGRADE S  AIT)Tool Convert
            'SQL = SQL & " '" & VB6.Format(Today, "yyyymmdd") & "'"
            SQL = SQL & " '" & Today.ToString("yyyyMMdd") & "'"
            '2021.07.26 UPGRADE E
            SQL = SQL & " WHERE KEY_NO = '0000'"

            'SQL�����s
            '2021.08.04 UPGRADE S  AIT)dannnl
            'SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText + ADODB.ExecuteOptionEnum.adExecuteNoRecords)
            ExecSQL(SQL)
            '2021.08.04 UPGRADE E

            '�߂�l�̃Z�b�g
            UpdateMastDate = True
            Exit Function

            '2021.07.26 UPGRADE S  AIT)Tool Convert
            'UpdateMastDate_Err:

            'Call Sql_Error_Msg("SEIGYO_MAST UPDATE")
        Catch ex As Exception
            '2021.07.26 UPGRADE E

            Call Sql_Error_Msg(ex, "SEIGYO_MAST UPDATE")

        End Try     '2021.07.26 UPGRADE ADD AIT)Tool Convert
    End Function

    '-------------------------------------------------------------------------------
    '   ����   :   �e�L�X�g�̍��ڐ��̎擾
    '   �֐�   :   Function ItemCntGet()
    '   ����   :   StrBuf�@ �e�L�X�g���
    '   �ߒl   :   ���ڐ�
    '   �@�\   :   �e�L�X�g�̃J���}�����擾���܂��B
    '-------------------------------------------------------------------------------
    Public Function ItemCntGet(ByRef strBuf As String) As Integer

        Dim Bp As Integer
        Dim Sp As Integer
        Dim Cnt As Integer
        Dim Sign As String

        Cnt = 0 : Bp = 1 : Sign = ","
        Do
            Sp = InStr(Bp, strBuf, Sign)
            If Sp = 0 Then Exit Do
            '----- �����J�n�ʒu
            Bp = Sp + 1
            '----- �J���}��
            If Sign = "," Then
                Cnt = Cnt + 1
            End If
            If Mid(strBuf, Bp, 1) = Chr(&H22) Then
                Sign = Chr(&H22)
                Bp = Bp + 1
            Else
                Sign = ","
            End If
        Loop
        ItemCntGet = Cnt

    End Function
End Module
