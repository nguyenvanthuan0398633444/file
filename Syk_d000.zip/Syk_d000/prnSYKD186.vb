Option Strict Off
Option Explicit On
Imports System.Drawing.Printing
Imports C1.Win.FlexReport

Module prnSYKD186
    '=============================================================
    ' ���[�U�[���@  �F  �R�z�H�Ɗ������
    ' �V�X�e�����@  �F  �H���Ǘ��V�X�e��
    ' ���W���[����  �F  �H������ڍ�(�y��)���
    ' ���W���[��ID�@�F  prnSYKD150.bas
    ' �쐬���@ �@�@ �F  ���� 13 �N 08 �� 15 ��
    ' �X�V���@�@  �@�F  ���� 13 �N 08 �� 29 ��
    '=============================================================
    '

    Private P_Cnt As Short ' ����y�[�W�J�E���g
    Private XX() As Single ' ����w�ʒu
    Private YY() As Single ' ����x�ʒu

    ' �H������f�[�^
    Private Structure GEPPOU_LIST_SUB
        '2021.08.03 UPGRADE S  AIT)Tool Convert
        '<VBFixedString(2),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=2)> Public WARIDASI_NO() As Char ' ���o�ԍ�
        '<VBFixedString(1),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=1)> Public WARIDASI_KB() As Char ' ���o�敪
        '<VBFixedString(1),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=1)> Public KOUSYU_CD() As Char ' �H������
        '<VBFixedString(2),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=2)> Public KOUSYU_NO() As Char ' �H��ԍ�
        '<VBFixedString(40),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=40)> Public MEISYOU() As Char ' ���o����
        '<VBFixedString(4),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=4)> Public TANI() As Char ' ���s�\�Z<�P��>
        <VBFixedStringAttribute(2)> Public WARIDASI_NO As String     ' ���o�ԍ�
        <VBFixedStringAttribute(1)> Public WARIDASI_KB As String     ' ���o�敪
        <VBFixedStringAttribute(1)> Public KOUSYU_CD As String   ' �H������
        <VBFixedStringAttribute(2)> Public KOUSYU_NO As String   ' �H��ԍ�
        <VBFixedStringAttribute(40)> Public MEISYOU As String    ' ���o����
        <VBFixedStringAttribute(4)> Public TANI As String    ' ���s�\�Z<�P��>
        '2021.08.03 UPGRADE E
        Dim SUURYOU As Decimal ' ���s�\�Z<����>
        Dim TANKA As Decimal ' ���s�\�Z<�P��>
        Dim YOSAN_GAKU As Decimal ' ���s�\�Z
        Dim KINGAKU As Decimal ' ���ы��z
        Dim RUIGAKU As Decimal ' �݌v���z
        Dim KONGO_GAKU As Decimal ' ���㌩��
        Dim JISSI_GAKU As Decimal ' ���{����
        Dim TAIHI_GAKU As Decimal ' �\�Z�Δ�
        Dim ZOGEN_GAKU As Decimal ' �ύX����
        Dim JITU_SUU As Decimal ' ���ѐ���
        Dim RUI_SUU As Decimal ' �O�񖘗ݐϐ���
        Dim KONGO_SUU As Decimal ' ���㏊�v��������
        Dim JISSI_SUU As Decimal ' ���{��������
    End Structure

    '-------------------------------------------------------------------------------
    '   ����   :   ���o�ԍ��ʋ��z�̎擾
    '   �֐�   :   Function SelectJisseki()
    '   ����   :   DT()�@   GEPPOU_LIST_SUB
    '   �ߒl   :   �ް���   ����I��
    '   �@�@       -1�@     �ُ�I��
    '   �@�\   :   ���o�ԍ��ʂ̊��o�������o�����f�[�^���擾���܂��B
    '-------------------------------------------------------------------------------
    Private Function SelectJisseki(ByRef DT() As GEPPOU_LIST_SUB) As Integer

        Dim QRY1 As String
        Dim QRY2 As String
        Dim QRY3 As String
        Dim QRY4 As String
        Dim SQL As String
        '2021.08.12 UPGRADE S  AIT)hieutv
        'Dim Rs As ADODB.Recordset
        'Dim Fld As ADODB.Field
        Dim Rs As New DataTable
        Dim Fld As DataColumn
        '2021.08.12 UPGRADE E
        Dim Cnt As Integer
        Dim OpenFlg As Short

        '2021.08.03 UPGRADE S  AIT)Tool Convert
        'On Error GoTo SelectJisseki_Err
        Try
            '2021.08.03 UPGRADE E

            ' �߂�l�̏�����
            SelectJisseki = -1

            ' QRY/SELECT���g��
            QRY1 = "(SELECT WARIDASI_NO, MEISYOU"
            QRY1 = QRY1 & " FROM WARIDASI_MAST"
            QRY1 = QRY1 & " WHERE EDA_NO = '" & KeyKouji.EDA_NO & "'"
            QRY1 = QRY1 & " AND KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"
            QRY1 = QRY1 & ") AS MASTDT"

            ' QRY/SELECT���g��
            '----- 2001/10/29 �C��
            '    QRY2 = "(SELECT WARIDASI_NO, WARIDASI_KB, KOUSYU_CD, KOUSYU_NO, MEISAI_NO, MEISYOU, J_SUURYOU, TANI, J_TANKA, J_KINGAKU"
            QRY2 = "(SELECT WARIDASI_NO, WARIDASI_KB, KOUSYU_CD, KOUSYU_NO, MEISAI_NO, MEISYOU, TANI,"
            QRY2 = QRY2 & " T_SUURYOU + G_SUURYOU AS J_SUURYOU,"
            QRY2 = QRY2 & " T_TANKA + G_TANKA AS J_TANKA,"
            QRY2 = QRY2 & " T_KINGAKU + G_KINGAKU AS J_KINGAKU"
            QRY2 = QRY2 & " FROM WARIDASI_DATA"
            QRY2 = QRY2 & " WHERE WARIDASI_KB <> '0'"
            QRY2 = QRY2 & " AND EDA_NO = '" & KeyKouji.EDA_NO & "'"
            QRY2 = QRY2 & " AND KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"
            QRY2 = QRY2 & ") AS WARIDT"

            ' QRY/SELECT���g���i���c�j
            QRY3 = "(SELECT KOUSYU_CD, KOUSYU_NO, MEISAI_NO,"
            QRY3 = QRY3 & " SI_GAKU, SI_KEI, KONGO_GAKU, JISSI_GAKU, TAIHI_GAKU, ZOUGEN_GAKU"
            QRY3 = QRY3 & " FROM MIKOMI_DATA"
            QRY3 = QRY3 & " WHERE SIME_YM = '" & CtlKouji.SYORI_YM & "'"
            QRY3 = QRY3 & " AND EDA_NO = '" & KeyKouji.EDA_NO & "'"
            QRY3 = QRY3 & " AND KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"
            QRY3 = QRY3 & ") AS MIKOMI"

            ' QRY/SELECT���g���i�O���j
            QRY4 = "(SELECT KOUSYU_CD, KOUSYU_NO, MEISAI_NO,"
            QRY4 = QRY4 & " JITU_GAKU, RUI_GAKU, KONGO_GAKU, JISSI_GAKU, TAIHI_GAKU, ZOUGEN_GAKU,"
            QRY4 = QRY4 & " JITU_SUU, RUI_SUU, KONGO_SUU, JISSI_SUU"
            QRY4 = QRY4 & " FROM DEKIDAKA_DATA"
            QRY4 = QRY4 & " WHERE SIME_YM = '" & CtlKouji.SYORI_YM & "'"
            QRY4 = QRY4 & " AND EDA_NO = '" & KeyKouji.EDA_NO & "'"
            QRY4 = QRY4 & " AND KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"
            QRY4 = QRY4 & ") AS DEKIDT"

            ' SQL/SELECT���g��
            SQL = "SELECT"
            SQL = SQL & " WARIDT.WARIDASI_NO      AS F01," ' ���o�ԍ�
            SQL = SQL & " WARIDT.WARIDASI_KB      AS F02," ' ���o�敪
            SQL = SQL & " WARIDT.KOUSYU_CD        AS F22," ' �H������
            SQL = SQL & " WARIDT.KOUSYU_NO        AS F23," ' �H��ԍ�
            SQL = SQL & " WARIDT.MEISAI_NO        AS F20," ' ���הԍ�
            SQL = SQL & " MIN(WARIDT.MEISYOU)     AS F21," ' ����
            SQL = SQL & " MIN(MASTDT.MEISYOU)     AS F03," ' ���o����
            SQL = SQL & " SUM(WARIDT.J_SUURYOU)   AS F24," ' ���s�\�Z<����>
            SQL = SQL & " MIN(WARIDT.TANI)        AS F25," ' ���s�\�Z<�P��>
            SQL = SQL & " SUM(WARIDT.J_TANKA)     AS F26," ' ���s�\�Z<�P��>
            SQL = SQL & " SUM(WARIDT.J_KINGAKU)   AS F04," ' ���s�\�Z
            SQL = SQL & " SUM(MIKOMI.SI_GAKU)     AS F05," ' ���ы��z�i���c�j
            SQL = SQL & " SUM(MIKOMI.SI_KEI)      AS F06," ' ���ї݌v
            SQL = SQL & " SUM(MIKOMI.KONGO_GAKU)  AS F07," ' ���㌩��
            SQL = SQL & " SUM(MIKOMI.JISSI_GAKU)  AS F08," ' ���{����
            SQL = SQL & " SUM(MIKOMI.TAIHI_GAKU)  AS F09," ' �\�Z�Δ�
            SQL = SQL & " SUM(MIKOMI.ZOUGEN_GAKU) As F10," ' �ύX����
            SQL = SQL & " SUM(DEKIDT.JITU_GAKU)   AS F11," ' ���ы��z�i�O���j
            SQL = SQL & " SUM(DEKIDT.RUI_GAKU)    AS F12," ' ���ї݌v
            SQL = SQL & " SUM(DEKIDT.KONGO_GAKU)  AS F13," ' ���㌩��
            SQL = SQL & " SUM(DEKIDT.JISSI_GAKU)  AS F14," ' ���{����
            SQL = SQL & " SUM(DEKIDT.TAIHI_GAKU)  As F15," ' �\�Z�Δ�
            SQL = SQL & " SUM(DEKIDT.ZOUGEN_GAKU) As F16," ' �ύX����
            SQL = SQL & " SUM(DEKIDT.JITU_SUU)    As F30," ' ���ѐ���
            SQL = SQL & " SUM(DEKIDT.RUI_SUU)     As F31," ' �O�񖘗ݐϐ���
            SQL = SQL & " SUM(DEKIDT.KONGO_SUU)   As F32," ' ���㏊�v��������
            SQL = SQL & " SUM(DEKIDT.JISSI_SUU)   As F33" ' ���{��������
            SQL = SQL & " FROM ((" & QRY2
            SQL = SQL & " LEFT JOIN " & QRY3
            SQL = SQL & " ON (WARIDT.MEISAI_NO = MIKOMI.MEISAI_NO)"
            SQL = SQL & " AND (WARIDT.KOUSYU_NO = MIKOMI.KOUSYU_NO)"
            SQL = SQL & " AND (WARIDT.KOUSYU_CD = MIKOMI.KOUSYU_CD))"
            SQL = SQL & " LEFT JOIN " & QRY4
            SQL = SQL & " ON (WARIDT.MEISAI_NO = DEKIDT.MEISAI_NO)"
            SQL = SQL & " AND (WARIDT.KOUSYU_NO = DEKIDT.KOUSYU_NO)"
            SQL = SQL & " AND (WARIDT.KOUSYU_CD = DEKIDT.KOUSYU_CD))"
            SQL = SQL & " LEFT JOIN " & QRY1
            SQL = SQL & " ON WARIDT.WARIDASI_NO = MASTDT.WARIDASI_NO"
            SQL = SQL & " GROUP BY WARIDT.WARIDASI_KB, WARIDT.WARIDASI_NO, WARIDT.KOUSYU_CD, WARIDT.KOUSYU_NO, WARIDT.MEISAI_NO"
            SQL = SQL & " ORDER BY WARIDT.WARIDASI_KB DESC, WARIDT.WARIDASI_NO, WARIDT.KOUSYU_CD, WARIDT.KOUSYU_NO, WARIDT.MEISAI_NO"

            ' SQL�����s
            '2021.08.12 UPGRADE S  AIT)hieutv
            'Rs = SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText)
            Rs = RsOpen(SQL)
            '2021.08.12 UPGRADE E
            OpenFlg = 1

            Cnt = 0
            '2021.08.12 UPGRADE S  AIT)hieutv
            'Do Until Rs.EOF
            For Each Row As DataRow In Rs.Rows
                '2021.08.12 UPGRADE E
                ReDim Preserve DT(Cnt)
                With DT(Cnt)
                    '----- ������
                    .WARIDASI_NO = "" ' ���o�ԍ�
                    .WARIDASI_KB = "" ' ���o�敪
                    .KOUSYU_CD = "" ' �H������
                    .KOUSYU_NO = "" ' �H��ԍ�
                    .MEISYOU = "" ' ���o����
                    .SUURYOU = 0 ' ���s�\�Z<����>
                    .TANI = "" ' ���s�\�Z<�P��>
                    .TANKA = 0 ' ���s�\�Z<�P��>
                    .YOSAN_GAKU = 0 ' ���s�\�Z
                    .KINGAKU = 0 ' ���ы��z
                    .RUIGAKU = 0 ' ���ї݌v
                    .KONGO_GAKU = 0 ' ���㌩��
                    .JISSI_GAKU = 0 ' ���{����
                    .TAIHI_GAKU = 0 ' �\�Z�Δ�
                    .ZOGEN_GAKU = 0 ' �ύX����
                    .JITU_SUU = 0 ' ���ѐ���
                    .RUI_SUU = 0 ' �O�񖘗ݐϐ���
                    .KONGO_SUU = 0 ' ���㏊�v��������
                    .JISSI_SUU = 0 ' ���{��������

                    '----- �\���̂�
                    '2021.08.12 UPGRADE S  AIT)hieutv
                    'For	Each Fld In Rs.Fields
                    '	If IsDbNull(Fld.Name) = False And IsDbNull(Fld.Value) = False Then
                    '		Select Case UCase(Fld.Name)
                    '			Case "F01" : .WARIDASI_NO = Fld.Value ' ���o�ԍ�
                    '			Case "F02" : .WARIDASI_KB = Fld.Value ' ���o�敪
                    '				'Case "F03": .MEISYOU = Fld.Value                    ' ���o����
                    '			Case "F04" : .YOSAN_GAKU = Fld.Value ' ���s�\�Z
                    '			Case "F05" : .KINGAKU = .KINGAKU + Fld.Value ' ���ы��z�i���c�j
                    '			Case "F06" : .RUIGAKU = .RUIGAKU + Fld.Value ' ���ї݌v
                    '			Case "F07" : .KONGO_GAKU = .KONGO_GAKU + Fld.Value ' ���㌩��
                    '			Case "F08" : .JISSI_GAKU = .JISSI_GAKU + Fld.Value ' ���{����
                    '			Case "F09" : .TAIHI_GAKU = .TAIHI_GAKU + Fld.Value ' �\�Z�Δ�
                    '			Case "F10" : .ZOGEN_GAKU = .ZOGEN_GAKU + Fld.Value ' �ύX����
                    '			Case "F11" : .KINGAKU = .KINGAKU + Fld.Value ' ���ы��z�i�O���j
                    '			Case "F12" : .RUIGAKU = .RUIGAKU + Fld.Value ' ���ї݌v
                    '			Case "F13" : .KONGO_GAKU = .KONGO_GAKU + Fld.Value ' ���㌩��
                    '			Case "F14" : .JISSI_GAKU = .JISSI_GAKU + Fld.Value ' ���{����
                    '			Case "F15" : .TAIHI_GAKU = .TAIHI_GAKU + Fld.Value ' �\�Z�Δ�
                    '			Case "F16" : .ZOGEN_GAKU = .ZOGEN_GAKU + Fld.Value ' �ύX����
                    '			Case "F21" : .MEISYOU = Fld.Value ' ����
                    '			Case "F22" : .KOUSYU_CD = Fld.Value ' �H������
                    '			Case "F23" : .KOUSYU_NO = Fld.Value ' �H��ԍ�
                    '			Case "F24" : .SUURYOU = Fld.Value ' ���s�\�Z<����>
                    '			Case "F25" : .TANI = Fld.Value ' ���s�\�Z<�P��>
                    '			Case "F26" : .TANKA = Fld.Value ' ���s�\�Z<�P��>
                    '			Case "F30" : .JITU_SUU = Fld.Value ' ���ѐ���
                    '			Case "F31" : .RUI_SUU = Fld.Value ' �O�񖘗ݐϐ���
                    '			Case "F32" : .KONGO_SUU = Fld.Value ' ���㏊�v��������
                    '			Case "F33" : .JISSI_SUU = Fld.Value ' ���{��������
                    '		End Select
                    '	End If
                    'Next Fld
                    For Each Fld In Row.Table.Columns
                        If IsDBNull(Fld.ColumnName) = False And IsDBNull(Row(Fld.ColumnName)) = False Then
                            Select Case UCase(Fld.ColumnName)
                                Case "F01" : .WARIDASI_NO = Row(Fld.ColumnName) ' ���o�ԍ�
                                Case "F02" : .WARIDASI_KB = Row(Fld.ColumnName) ' ���o�敪
                                'Case "F03": .MEISYOU = Row(Fld.ColumnName)                    ' ���o����
                                Case "F04" : .YOSAN_GAKU = Row(Fld.ColumnName) ' ���s�\�Z
                                Case "F05" : .KINGAKU = .KINGAKU + Row(Fld.ColumnName) ' ���ы��z�i���c�j
                                Case "F06" : .RUIGAKU = .RUIGAKU + Row(Fld.ColumnName) ' ���ї݌v
                                Case "F07" : .KONGO_GAKU = .KONGO_GAKU + Row(Fld.ColumnName) ' ���㌩��
                                Case "F08" : .JISSI_GAKU = .JISSI_GAKU + Row(Fld.ColumnName) ' ���{����
                                Case "F09" : .TAIHI_GAKU = .TAIHI_GAKU + Row(Fld.ColumnName) ' �\�Z�Δ�
                                Case "F10" : .ZOGEN_GAKU = .ZOGEN_GAKU + Row(Fld.ColumnName) ' �ύX����
                                Case "F11" : .KINGAKU = .KINGAKU + Row(Fld.ColumnName) ' ���ы��z�i�O���j
                                Case "F12" : .RUIGAKU = .RUIGAKU + Row(Fld.ColumnName) ' ���ї݌v
                                Case "F13" : .KONGO_GAKU = .KONGO_GAKU + Row(Fld.ColumnName) ' ���㌩��
                                Case "F14" : .JISSI_GAKU = .JISSI_GAKU + Row(Fld.ColumnName) ' ���{����
                                Case "F15" : .TAIHI_GAKU = .TAIHI_GAKU + Row(Fld.ColumnName) ' �\�Z�Δ�
                                Case "F16" : .ZOGEN_GAKU = .ZOGEN_GAKU + Row(Fld.ColumnName) ' �ύX����
                                Case "F21" : .MEISYOU = Row(Fld.ColumnName) ' ����
                                Case "F22" : .KOUSYU_CD = Row(Fld.ColumnName) ' �H������
                                Case "F23" : .KOUSYU_NO = Row(Fld.ColumnName) ' �H��ԍ�
                                Case "F24" : .SUURYOU = Row(Fld.ColumnName) ' ���s�\�Z<����>
                                Case "F25" : .TANI = Row(Fld.ColumnName) ' ���s�\�Z<�P��>
                                Case "F26" : .TANKA = Row(Fld.ColumnName) ' ���s�\�Z<�P��>
                                Case "F30" : .JITU_SUU = Row(Fld.ColumnName) ' ���ѐ���
                                Case "F31" : .RUI_SUU = Row(Fld.ColumnName) ' �O�񖘗ݐϐ���
                                Case "F32" : .KONGO_SUU = Row(Fld.ColumnName) ' ���㏊�v��������
                                Case "F33" : .JISSI_SUU = Row(Fld.ColumnName) ' ���{��������
                            End Select
                        End If
                    Next Fld
                    '2021.08.12 UPGRADE E
                End With
                Cnt = Cnt + 1
                '2021.08.12 UPGRADE S  AIT)hieutv
                '	Rs.MoveNext()
                'Loop

                'Rs.Close()
            Next

            Rs.Dispose()
            '2021.08.12 UPGRADE E
            Rs = Nothing

            ' �߂�l�̃Z�b�g
            SelectJisseki = Cnt
            Exit Function

            '2021.08.03 UPGRADE S  AIT)Tool Convert
            'SelectJisseki_Err:
        Catch ex As Exception
            '2021.08.03 UPGRADE E

            If OpenFlg = 1 Then
                '2021.08.12 UPGRADE S  AIT)hieutvs
                'Rs.Close()
                Rs.Dispose()
                '2021.08.12 UPGRADE E
            End If
            Rs = Nothing

            '2021.08.12 UPGRADE S  AIT)hieutv
            'Call Sql_Error_Msg("SelectJisseki")
            Call Sql_Error_Msg(ex, "SelectJisseki")
            '2021.08.12 UPGRADE E

        End Try     '2021.08.03 UPGRADE ADD AIT)Tool Convert
    End Function

    '-------------------------------------------------------------------------------
    '   ����    :   �P�����z�̎Z�o
    '   �֐�    :   Function GetCalcTankasa()
    '   ����    :   �Ȃ�
    '   �ߒl    :   �P�����z
    '   �@�\    :   �P�����z�̎Z�o���s���B
    '-------------------------------------------------------------------------------
    Public Function GetCalcTankasa(ByRef N_Buf As Decimal) As Decimal

        Dim SQL As String
        '2021.08.12 UPGRADE S  AIT)hieutv
        'Dim Rs As ADODB.Recordset
        Dim Rs As New DataTable
        '2021.08.12 UPGRADE E
        Dim CurBuf1 As Decimal
        Dim CurBuf2 As Decimal

        On Error Resume Next

        ' �߂�l�̏�����
        GetCalcTankasa = 0
        N_Buf = 0

        '�����������@��ʕ��f�[�^���P�������Z�o����@����������

        '2014/02/21 �P�����z�̌v�Z���@���C�� ---------------------------------------����������
        ' SQL/SELECT���g��
        'SQL = "SELECT SUM((H_TANKA - TANKA) * H_SUURYOU) FROM IPPAN_DATA"
        'SQL = SQL & " WHERE TANKA <> H_TANKA"
        'SQL = SQL & " AND SIME_YM <= '" & CtlKouji.SYORI_YM & "'"
        'SQL = SQL & " AND EDA_NO = '" & KeyKouji.EDA_NO & "'"
        'SQL = SQL & " AND KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"
        '������
        If SYSTEMID = "S" Then
            '2021.08.12 UPGRADE S  AIT)hieutv
            'SQL = "SELECT SUM(ROUND(H_TANKA * H_SUURYOU,0) - ROUND(TANKA * H_SUURYOU,0)) FROM IPPAN_DATA"
            SQL = "SELECT SUM(ROUND(H_TANKA * H_SUURYOU,0) - ROUND(TANKA * H_SUURYOU,0)) AS SUMDATA FROM IPPAN_DATA"
            '2021.08.12 UPGRADE E
        Else
            '2021.08.12 UPGRADE S  AIT)hieutv
            'SQL = "SELECT SUM(INT(H_TANKA * H_SUURYOU + 0.5) - INT(TANKA * H_SUURYOU + 0.5)) FROM IPPAN_DATA"
            SQL = "SELECT SUM(INT(H_TANKA * H_SUURYOU + 0.5) - INT(TANKA * H_SUURYOU + 0.5)) AS SUMDATA FROM IPPAN_DATA"
            '2021.08.12 UPGRADE E
        End If
        SQL = SQL & " WHERE TANKA <> H_TANKA"
        SQL = SQL & " AND SIME_YM <= '" & CtlKouji.SYORI_YM & "'"
        SQL = SQL & " AND EDA_NO = '" & KeyKouji.EDA_NO & "'"
        SQL = SQL & " AND KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"
        '---------------------------------------------------------------------------����������

        ' SQL�����s
        '2021.08.12 UPGRADE S  AIT)hieutv
        'Rs = SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText)
        Rs = RsOpen(SQL)
        '2021.08.12 UPGRADE E
        CurBuf1 = 0
        '2021.08.12 UPGRADE S  AIT)hieutv
        'If Rs.EOF = False Then
        '    If IsDBNull(Rs.Fields(0).Value) = False Then
        '        CurBuf1 = Rs.Fields(0).Value
        '    End If
        'End If
        'Rs.Close()
        If Rs.Rows.Count > 0 Then
            If IsDBNull(Rs.Rows(0)("SUMDATA")) = False Then
                CurBuf1 = Rs.Rows(0)("SUMDATA")
            End If
        End If
        Rs.Dispose()
        '2021.08.12 UPGRADE E
        Rs = Nothing

        '�����������@�O���x���f�[�^���C�ӘJ�Ђ��W�v����@����������

        ' SQL/SELECT���g��
        '2021.08.12 UPGRADE S  AIT)hieutv
        'SQL = "SELECT SUM(NIN_ROU_GAKU) FROM GAI_KIHON_DATA"
        SQL = "SELECT SUM(NIN_ROU_GAKU) AS SUMDATA FROM GAI_KIHON_DATA"
        '2021.08.12 UPGRADE E
        SQL = SQL & " WHERE SIME_YM <= '" & CtlKouji.SYORI_YM & "'"
        SQL = SQL & " AND EDA_NO = '" & KeyKouji.EDA_NO & "'"
        SQL = SQL & " AND KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"

        ' SQL�����s
        '2021.08.12 UPGRADE S  AIT)hieutv
        'Rs = SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText)
        Rs = RsOpen(SQL)
        '2021.08.12 UPGRADE E
        CurBuf2 = 0
        '2021.08.12 UPGRADE S  AIT)hieutv
        'If Rs.EOF = False Then
        '    If IsDBNull(Rs.Fields(0).Value) = False Then
        '        CurBuf2 = Rs.Fields(0).Value
        '    End If
        'End If
        'Rs.Close()
        If Rs.Rows.Count > 0 Then
            If IsDBNull(Rs.Rows(0)("SUMDATA")) = False Then
                CurBuf2 = Rs.Rows(0)("SUMDATA")
            End If
        End If
        Rs.Dispose()
        '2021.08.12 UPGRADE E
        Rs = Nothing

        ' �߂�l�̃Z�b�g
        N_Buf = CurBuf2
        GetCalcTankasa = CurBuf1

    End Function

    '-------------------------------------------------------------------------------
    '   ����    :   �P�����z�̎Z�o�i�O�񖘁j
    '   �֐�    :   Function GetCalcTankasaZenMade()
    '   ����    :   �Ȃ�
    '   �ߒl    :   �P�����z
    '   �@�\    :   �P�����z�̎Z�o���s���B
    '-------------------------------------------------------------------------------
    Public Function GetCalcTankasaZenMade(ByRef N_Buf As Decimal) As Decimal

        Dim SQL As String
        '2021.08.12 UPGRADE S  AIT)hieutvs
        'Dim Rs As ADODB.Recordset
        Dim Rs As New DataTable
        '2021.08.12 UPGRADE E
        Dim CurBuf1 As Decimal
        Dim CurBuf2 As Decimal

        On Error Resume Next

        ' �߂�l�̏�����
        GetCalcTankasaZenMade = 0
        N_Buf = 0

        '�����������@��ʕ��f�[�^���P�������Z�o����@����������

        '2014/02/21 �P�����z�̌v�Z���@���C�� ---------------------------------------����������
        ' SQL/SELECT���g��
        'SQL = "SELECT SUM((H_TANKA - TANKA) * H_SUURYOU) FROM IPPAN_DATA"
        'SQL = SQL & " WHERE TANKA <> H_TANKA"
        'SQL = SQL & " AND SIME_YM < '" & CtlKouji.SYORI_YM & "'"
        'SQL = SQL & " AND EDA_NO = '" & KeyKouji.EDA_NO & "'"
        'SQL = SQL & " AND KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"
        '������
        If SYSTEMID = "S" Then
            '2021.08.12 UPGRADE S  AIT)hieutv
            'SQL = "SELECT SUM(ROUND(H_TANKA * H_SUURYOU,0) - ROUND(TANKA * H_SUURYOU,0)) FROM IPPAN_DATA"
            SQL = "SELECT SUM(ROUND(H_TANKA * H_SUURYOU,0) - ROUND(TANKA * H_SUURYOU,0)) AS SUMDATA FROM IPPAN_DATA"
            '2021.08.12 UPGRADE E
        Else
            '2021.08.12 UPGRADE S  AIT)hieutv
            'SQL = "SELECT SUM(INT(H_TANKA * H_SUURYOU + 0.5) - INT(TANKA * H_SUURYOU + 0.5)) FROM IPPAN_DATA"
            SQL = "SELECT SUM(INT(H_TANKA * H_SUURYOU + 0.5) - INT(TANKA * H_SUURYOU + 0.5)) AS SUMDATA FROM IPPAN_DATA"
            '2021.08.12 UPGRADE E
        End If
        SQL = SQL & " WHERE TANKA <> H_TANKA"
        SQL = SQL & " AND SIME_YM < '" & CtlKouji.SYORI_YM & "'"
        SQL = SQL & " AND EDA_NO = '" & KeyKouji.EDA_NO & "'"
        SQL = SQL & " AND KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"
        '---------------------------------------------------------------------------����������

        ' SQL�����s
        '2021.08.12 UPGRADE S  AIT)hieutvS
        'Rs = SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText)
        Rs = RsOpen(SQL)
        '2021.08.12 UPGRADE E
        CurBuf1 = 0
        '2021.08.12 UPGRADE S  AIT)hieutv
        'If Rs.EOF = False Then
        '    If IsDBNull(Rs.Fields(0).Value) = False Then
        '        CurBuf1 = Rs.Fields(0).Value
        '    End If
        'End If
        'Rs.Close()
        If Rs.Rows.Count > 0 Then
            If IsDBNull(Rs.Rows(0)("SUMDATA")) = False Then
                CurBuf1 = Rs.Rows(0)("SUMDATA")
            End If
        End If
        Rs.Dispose()
        '2021.08.12 UPGRADE E
        Rs = Nothing

        '�����������@�O���x���f�[�^���C�ӘJ�Ђ��W�v����@����������

        ' SQL/SELECT���g��
        '2021.08.12 UPGRADE S  AIT)hieutv
        'SQL = "SELECT SUM(NIN_ROU_GAKU) FROM GAI_KIHON_DATA"
        SQL = "SELECT SUM(NIN_ROU_GAKU) AS SUMDATA FROM GAI_KIHON_DATA"
        '2021.08.12 UPGRADE E
        SQL = SQL & " WHERE SIME_YM < '" & CtlKouji.SYORI_YM & "'"
        SQL = SQL & " AND EDA_NO = '" & KeyKouji.EDA_NO & "'"
        SQL = SQL & " AND KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"

        ' SQL�����s
        '2021.08.12 UPGRADE S  AIT)hieutv
        'Rs = SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText)
        Rs = RsOpen(SQL)
        CurBuf2 = 0
        '2021.08.12 UPGRADE S  AIT)hieutv
        'If Rs.EOF = False Then
        '    If IsDBNull(Rs.Fields(0).Value) = False Then
        '        CurBuf2 = Rs.Fields(0).Value
        '    End If
        'End If
        'Rs.Close()
        If Rs.Rows.Count > 0 Then
            If IsDBNull(Rs.Rows(0)("SUMDATA")) = False Then
                CurBuf2 = Rs.Rows(0)("SUMDATA")
            End If
        End If
        Rs.Dispose()
        Rs = Nothing

        ' �߂�l�̃Z�b�g
        N_Buf = CurBuf2
        GetCalcTankasaZenMade = CurBuf1

    End Function

    '-------------------------------------------------------------------------------
    '   ����    :   �H������ڍ�(�y��)���
    '   �֐�    :   Function PrnMainD186()
    '   ����    :   ����
    '   �ߒl    :   True    ����I��
    '   �@�@        False   ���f
    '-------------------------------------------------------------------------------
    Public Function PrnMainD186() As Object

        Dim DT() As GEPPOU_LIST_SUB
        Dim Cnt As Integer
        Dim lp As Integer
        Dim pryy As Single
        Dim W_WARIDASI_KB As String
        Dim W_WARIDASI_NO As String
        Dim KOUMOKU_KEI(8) As Decimal
        Dim G_KOUMOKU_KEI(8) As Decimal
        Dim i As Short
        Dim R_Cnt As Integer
        Dim L_Length As Single

        '�ڍ׃f�[�^�̓ǂݍ���
        Cnt = 0
        Cnt = SelectJisseki(DT)

        If Cnt <= 0 Then
            Exit Function
        End If

        ' �v�����^�[�f�o�C�X�̓ǂݍ���
        Call INI_PRN_Read(1)

        ' �����ݒ�
        If PrnFirstD186() = False Then
            Exit Function
        End If

        ' ����ʒu�̎擾
        Call PrXYGetD186()

        ' ������
        P_Cnt = 1 : pryy = YY(1)
        W_WARIDASI_KB = DT(0).WARIDASI_KB
        W_WARIDASI_NO = DT(0).WARIDASI_NO
        For i = 1 To UBound(KOUMOKU_KEI)
            KOUMOKU_KEI(i) = 0
            G_KOUMOKU_KEI(i) = 0
        Next i

        ' ���o����(�y�[�W���o��)
        Call PrItemD186(pryy)
        '----- ���s
        pryy = pryy + ((P_YY * 1.5) * 4.5)
        ' ���o����(���ڌ��o��)
        Call PrItem2D186(pryy, DT(0))
        '----- ���s
        pryy = pryy + ((P_YY * 1.5) * 2.5)

        If PrnCancel = 1 Then
            '----- ���f
            Call PRN_ErrEnd()
            Exit Function
        End If

        For lp = 0 To Cnt - 1
            '----- �H�����ށE�H��ԍ��`�F�b�N
            If W_WARIDASI_KB <> DT(lp).WARIDASI_KB Or W_WARIDASI_NO <> DT(lp).WARIDASI_NO Then
                ' ���o�敪���̍��v
                Call PrDataGD186(pryy, KOUMOKU_KEI)
                '----- ���s
                pryy = pryy + ((P_YY * 1.5) * 1.5)
                '----- ����(�؂����)
                Call PRN_LINE(XX(0), pryy, XX(UBound(XX)), pryy, 20, "")
                '���y�[�W�`�F�b�N
                '----- ���R�[�h�����̎擾
                R_Cnt = PrRcntD186(DT(lp))
                '----- �󎚕��̎擾(�f�[�^�s(R_Cnt) + ���o���s(1)+���v�s(3))
                L_Length = P_YY * (R_Cnt + 4) + P_YY * 5
                '2001/12/25 ���o�敪���ς�����ꍇ�́A�K�����ł���
                If NewPage_CHK(pryy, L_Length) = False Or W_WARIDASI_KB <> DT(lp).WARIDASI_KB Then
                    '----- ���y�[�W
                    Call PRN_NewPage()
                    '----- �y�[�W���̍X�V
                    P_Cnt = P_Cnt + 1
                    '----- �󎚈ʒu�̃��Z�b�g
                    pryy = YY(1)
                    ' ���o����(�y�[�W���o��)
                    Call PrItemD186(pryy)
                    '----- ���s
                    pryy = pryy + ((P_YY * 1.5) * 4.5)
                End If
                ' ���o���� (���ڌ��o��)
                Call PrItem2D186(pryy, DT(lp))
                '----- ���s
                pryy = pryy + ((P_YY * 1.5) * 2.5)
                ' �������E�Đݒ�
                W_WARIDASI_KB = DT(lp).WARIDASI_KB
                W_WARIDASI_NO = DT(lp).WARIDASI_NO
                For i = 1 To UBound(G_KOUMOKU_KEI)
                    G_KOUMOKU_KEI(i) = G_KOUMOKU_KEI(i) + KOUMOKU_KEI(i)
                    KOUMOKU_KEI(i) = 0
                Next i
                If PrnCancel = 1 Then
                    '----- ���f
                    Call PRN_ErrEnd()
                    Exit Function
                End If
            Else
                L_Length = P_YY * 1.5 + P_YY * 5
                If NewPage_CHK(pryy, L_Length) = False Then
                    '----- ���y�[�W
                    Call PRN_NewPage()
                    '----- �y�[�W���̍X�V
                    P_Cnt = P_Cnt + 1
                    '----- �󎚈ʒu�̃��Z�b�g
                    pryy = YY(1)
                    ' ���o����(�y�[�W���o��)
                    Call PrItemD186(pryy)
                    '----- ���s
                    pryy = pryy + ((P_YY * 1.5) * 4.5)

                    ' ���o���� (���ڌ��o��)
                    Call PrItem2D186(pryy, DT(lp))
                    '----- ���s
                    pryy = pryy + ((P_YY * 1.5) * 2.5)
                End If
            End If
            ' �f�[�^��
            Call PrDataD186(pryy, DT(lp))
            If PrnCancel = 1 Then
                '----- ���f
                Call PRN_ErrEnd()
                Exit Function
            End If
            ' �e���ڋ��z���v����
            KOUMOKU_KEI(1) = KOUMOKU_KEI(1) + DT(lp).YOSAN_GAKU
            KOUMOKU_KEI(2) = KOUMOKU_KEI(2) + DT(lp).KINGAKU + DT(lp).RUIGAKU
            KOUMOKU_KEI(3) = KOUMOKU_KEI(3) + DT(lp).KONGO_GAKU
            KOUMOKU_KEI(4) = KOUMOKU_KEI(4) + DT(lp).JISSI_GAKU
            KOUMOKU_KEI(5) = KOUMOKU_KEI(5) + DT(lp).TAIHI_GAKU
            KOUMOKU_KEI(6) = KOUMOKU_KEI(6) + DT(lp).ZOGEN_GAKU
            '2013/12/11 �ǉ� -----------------------------------------------------------------------����������
            KOUMOKU_KEI(7) = KOUMOKU_KEI(7) + DT(lp).RUIGAKU
            KOUMOKU_KEI(8) = KOUMOKU_KEI(8) + DT(lp).KINGAKU
            '---------------------------------------------------------------------------------------����������
            '----- ���s
            pryy = pryy + (P_YY * 1.5)
        Next lp

        ' ���o�敪���̍��v
        Call PrDataGD186(pryy, KOUMOKU_KEI)
        ' �����v�󎚁`�P�����z��
        For i = 1 To UBound(G_KOUMOKU_KEI)
            G_KOUMOKU_KEI(i) = G_KOUMOKU_KEI(i) + KOUMOKU_KEI(i)
        Next i

        '----- �󎚕��̎擾(���v�s(5)+���v�s(3))
        L_Length = P_YY * 5 + P_YY * 5
        If NewPage_CHK(pryy, L_Length) = False Then
            '----- ���y�[�W
            Call PRN_NewPage()
            '----- �y�[�W���̍X�V
            P_Cnt = P_Cnt + 1
            '----- �󎚈ʒu�̃��Z�b�g
            pryy = YY(1)
            ' ���o����(�y�[�W���o��)
            Call PrItemD186(pryy)
            '----- ���s
            pryy = pryy + ((P_YY * 1.5) * 4.5)

            ' ���o���� (���ڌ��o��)
            Call PrItem2D186(pryy, DT(0), 1)
            '----- ���s
            pryy = pryy + ((P_YY * 1.5) * 2.5)
        End If

        ' ���v��
        Call PrDataG2D186(pryy, G_KOUMOKU_KEI)

        If PrnCancel = 1 Then
            '----- ���f
            Call PRN_ErrEnd()
            Exit Function
        End If

        ' ����I��
        Call PRN_END()

        ' �v���r���[�\��
        If ViewFlg = True Then
            frmSYKD185.StatusBar1.Items.Item("Message").Text = ""
            ViewForm.ShowDialog()
        End If

        ' ����I��
        PrnMainD186 = True

    End Function

    '-------------------------------------------------------------------------------
    '   ����    :   �����ݒ�
    '   �֐�    :   Sub     PrnFirstD186()
    '   ����    :   ����
    '   �ߒl    :   True    ����I��
    '   �@�@        False   �Y���Ȃ�
    '-------------------------------------------------------------------------------
    Private Function PrnFirstD186() As Boolean

        ' �߂�l�̏�����
        PrnFirstD186 = False

        ' �^�C�g���ݒ�
        DocName = "�H������ڍ�"

        ' �v�����^�[�f�o�C�X�̐ݒ�
        If Printer_Set(PRN1) = False Then
            '2021.09.14 UPGRADE S  AIT)dannnl
            'MsgBox("�ݒ�ɖ����v�����^�[�f�o�C�X���w�肳��܂����B")
            MsgBox("�ݒ�ɖ����v�����^�[�f�o�C�X���w�肳��܂����B", MsgBoxStyle.ApplicationModal, SYSTEMNM)
            '2021.09.14 UPGRADE E
            Exit Function
        End If

        ' �p���ݒ�
        '2021.08.18 UPGRADE S  AIT)hieutv
        'P_SIZE = PrinterObjectConstants.vbPRPSA4 ' �`�S
        'P_ORIENT = VSPrinter7Lib.OrientationSettings.orLandscape ' ��:orLandscape,�c:orPortrait
        P_SIZE = PaperKind.A4  ' �`�S
        P_ORIENT = OrientationEnum.Landscape  ' ��:orLandscape,�c:orPortrait
        '2021.08.18 UPGRADE E
        F_SIZE = 12

        ' ����ďo��ʂ̃Z�b�g
        CallForm = frmSYKD185

        ' ��������ݒ�
        If PRN_First(ViewForm) = False Then
            '2021.09.14 UPGRADE S  AIT)dannnl
            'MsgBox("�v�����^�̐ݒ�Ɏ��s���܂����B", MsgBoxStyle.Exclamation)
            MsgBox("�v�����^�̐ݒ�Ɏ��s���܂����B", MsgBoxStyle.Exclamation, SYSTEMNM)
            '2021.09.14 UPGRADE E
            Exit Function
        End If

        ' ����I��
        PrnFirstD186 = True

    End Function

    '-------------------------------------------------------------------------------
    '   ����    :   ����ʒu�ݒ菈��
    '   �֐�    :   Sub PrXYGetD186()
    '   ����    :   ����
    '   �ߒl    :   ����
    '-------------------------------------------------------------------------------
    Private Sub PrXYGetD186()

        Dim PrLen As Short
        Dim xMargn As Short

        ' ���ڐ��̐ݒ�
        ReDim XX(18)
        ReDim YY(1)

        ' �����񒷂̎Z�o(PrLen=102)
        PrLen = 0
        PrLen = PrLen + Len(Space(6 + 1)) ' �H��
        PrLen = PrLen + Len(Space(40 + 1)) ' ����
        PrLen = PrLen + Len(Space(8 + 1)) ' ���s�\�Z<����>
        PrLen = PrLen + Len(Space(4 + 1)) ' ���s�\�Z<�P��>
        PrLen = PrLen + Len(Space(10 + 1)) ' ���s�\�Z<�P��>
        PrLen = PrLen + Len(Space(10 + 1)) ' ���s�\�Z<���z>
        PrLen = PrLen + Len(Space(8 + 1)) ' �݌v���{���z<����>
        PrLen = PrLen + Len(Space(10 + 1)) ' �݌v���{���z
        PrLen = PrLen + Len(Space(8 + 1)) ' ���㏊�v����<����>
        PrLen = PrLen + Len(Space(10 + 1)) ' ���㏊�v����
        PrLen = PrLen + Len(Space(8 + 1)) ' ���{�������z<����>
        PrLen = PrLen + Len(Space(10 + 1)) ' ���{�������z
        PrLen = PrLen + Len(Space(10 + 1)) ' �\�Z�Δ�
        PrLen = PrLen + Len(Space(10 + 1)) ' �ύX����

        ' �t�H���g�T�C�Y�̎Z�o
        xMargn = 9
        '2021.08.18 UPGRADE S  AIT)hieutv
        'F_SIZE = PRN_FontGet(P_XX * xMargn * 2, P_WIDTH, Basic_F, Space(PrLen))
        F_SIZE = PRN_FontGet(P_XX * xMargn * 2, P_WIDTH, Basic_F, New String(")", PrLen)) + 0.25
        PRN.Font.Size = F_SIZE
        '2021.08.18 UPGRADE E

        ' �P�������E�����̍Đݒ�
        '2021.08.18 UPGRADE S  AIT)hieutv
        'P_XX = PRN.TextWidth("M")
        'P_YY = PRN.TextHeight("M")
        P_XX = TextWidthToTwips("M")
        P_YY = TextHeightToTwips("M")
        '2021.08.18 UPGRADE E

        ' ���ڈ󎚈ʒu�̐ݒ� Y��
        YY(0) = P_YY * 7
        YY(1) = YY(0) + P_YY * 1.5

        ' ���ڈ󎚈ʒu�̐ݒ� X��
        XX(0) = P_XX * xMargn ' �r�����[
        XX(1) = XX(0) + P_XX * 1 '
        XX(2) = XX(1) + P_XX * (4 + 3) ' �H��
        XX(3) = XX(2) + P_XX * (40 + 3) ' ����
        XX(4) = XX(3) + P_XX * (8 + 3) ' ���s�\�Z<����>
        XX(5) = XX(4) + P_XX * (4 + 3) ' ���s�\�Z<�P��>
        XX(6) = XX(5) + P_XX * (10 + 4) ' ���s�\�Z<�P��>
        XX(7) = XX(6) + P_XX * (10 + 4) ' ���s�\�Z<���z>
        XX(8) = XX(7)
        XX(9) = XX(8)
        XX(10) = XX(9) + P_XX * (8 + 3) ' �݌v���{���z<����>
        XX(11) = XX(10) + P_XX * (10 + 4) ' �݌v���{���z
        XX(12) = XX(11) + P_XX * (8 + 3) ' ���㏊�v����<����>
        XX(13) = XX(12) + P_XX * (10 + 4) ' ���㏊�v����
        XX(14) = XX(13) + P_XX * (8 + 3) ' ���{�������z<����>
        XX(15) = XX(14) + P_XX * (10 + 4) ' ���{�������z
        XX(16) = XX(15) + P_XX * (10 + 4) ' �\�Z�Δ�
        XX(17) = XX(16) + P_XX * (10 + 4) ' �ύX����
        XX(18) = P_WIDTH - P_XX * xMargn ' �r���E�[

    End Sub

    '-------------------------------------------------------------------------------
    '   ����    :   ���ڈ������(�y�[�W���o��)
    '   �֐�    :   Sub PrItemD186()
    '   ����    :   �Ȃ�
    '   �ߒl    :   �Ȃ�
    '-------------------------------------------------------------------------------

    Private Sub PrItemD186(ByRef pryy As Single)

        Dim PR_WK_Renamed As PR_WK
        Dim PR_Text As String
        Dim yMargn As Single
        Dim i As Short

        ' dummy
        PR_WK_Renamed.DT = ""
        PR_WK_Renamed.FS = F_SIZE
        PR_WK_Renamed.X = XX(0)
        PR_WK_Renamed.Y = YY(0)
        Call PRN_DATA(PR_WK_Renamed)

        '----- �]��
        yMargn = P_YY * 0.25

        '----- �w�b�_
        ' �^�C�g��
        PR_WK_Renamed.DT = "���� �H������ڍ� ����"
        PR_WK_Renamed.FS = 12
        '2021.08.18 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.X = PRN_XGet(1, XX(0), XX(5), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(1, XX(0), XX(5), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = YY(0)
        Call PRN_DATA(PR_WK_Renamed, Nothing, Nothing, True)
        ' ����
        Call PRN_LINE(XX(UBound(XX)) - P_XX * 10 * 5, YY(0), XX(UBound(XX)), YY(0), 20, "")
        Call PRN_LINE(XX(UBound(XX)) - P_XX * 10 * 5, YY(1), XX(UBound(XX)), YY(1), 20, "")
        Call PRN_LINE(XX(UBound(XX)) - P_XX * 10 * 5, pryy + (P_YY * 5.75), XX(UBound(XX)), pryy + (P_YY * 5.75), 20, "")

        For i = 0 To 5
            Call PRN_LINE(XX(UBound(XX)) - P_XX * 10 * (5 - i), YY(0), XX(UBound(XX)) - P_XX * 10 * (5 - i), pryy + (P_YY * 5.75), 20, "")
        Next i

        For i = 0 To 4
            Select Case i
                Case 0 : PR_WK_Renamed.DT = Trim(G_SYOUSAI01)
                Case 1 : PR_WK_Renamed.DT = Trim(G_SYOUSAI02)
                Case 2 : PR_WK_Renamed.DT = Trim(G_SYOUSAI03)
                Case 3 : PR_WK_Renamed.DT = Trim(G_SYOUSAI04)
                Case 4 : PR_WK_Renamed.DT = Trim(G_SYOUSAI05)
            End Select
            PR_WK_Renamed.FS = 7.25
            '2021.08.18 UPGRADE S  AIT)hieutv
            'PR_WK_Renamed.X = PRN_XGet(1, XX(UBound(XX)) - P_XX * 10 * (5 - i), XX(UBound(XX)) - P_XX * 10 * (5 - i - 1), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
            PRN_XGet(1, XX(UBound(XX)) - P_XX * 10 * (5 - i), XX(UBound(XX)) - P_XX * 10 * (5 - i - 1), PR_WK_Renamed)
            '2021.08.18 UPGRADE E
            PR_WK_Renamed.Y = YY(0) + yMargn
            Call PRN_DATA(PR_WK_Renamed)
        Next i

        ' ����y�[�W
        '2021.08.12 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.DT = VB6.Format(P_Cnt) & " ��"
        PR_WK_Renamed.DT = P_Cnt.ToString & " ��"
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.18 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.X = PRN_XGet(2, XX(0), XX(13), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(0), XX(13), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + ((P_YY * 1.5) * 2)
        Call PRN_DATA(PR_WK_Renamed)
        ' �����
        '2021.08.03 UPGRADE S  AIT)Tool Convert
        'PR_WK_Renamed.DT = "������t�F" & VB6.Format(Today, "yyyy/mm/dd")
        PR_WK_Renamed.DT = "������t�F" & Today.ToString("yyyy/MM/dd")
        '2021.08.03 UPGRADE E
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.18 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.X = PRN_XGet(2, XX(0), XX(13), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(0), XX(13), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + ((P_YY * 1.5) * 3)
        Call PRN_DATA(PR_WK_Renamed)
        ' ����
        '2021.08.03 UPGRADE S  AIT)Tool Convert
        'PR_WK_Renamed.DT = "�����F" & VB6.Format(CtlKouji.SYORI_YM, "0000/00")
        PR_WK_Renamed.DT = "�����F" & CDec(CtlKouji.SYORI_YM).ToString("0000/00")
        '2021.08.03 UPGRADE E
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.18 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.X = PRN_XGet(0, XX(0), XX(5), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(0, XX(0), XX(5), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + ((P_YY * 1.5) * 2)
        Call PRN_DATA(PR_WK_Renamed)
        ' �H���ԍ��{�}�ԁ{�H������
        PR_Text = ""
        If CtlKouji.EDA_NO <> "0000" Then PR_Text = "-" & CtlKouji.EDA_NO & Space(1)
        PR_WK_Renamed.DT = "�H���ԍ��F" & CtlKouji.KOUJI_NO & PR_Text & "  " & GetNameKouji(CtlKouji.KOUJI_NO, CtlKouji.EDA_NO)
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.18 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.X = PRN_XGet(0, XX(0), XX(5), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(0, XX(0), XX(5), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + ((P_YY * 1.5) * 3)
        Call PRN_DATA(PR_WK_Renamed)

    End Sub

    '-------------------------------------------------------------------------------
    '   ����    :   ���ڈ������(���ڌ��o��)
    '   �֐�    :   Sub PrItem2D186()
    '   ����    :   pryy    �󎚂x�ʒu
    '   �@�@        DT()    GEPPOU_LIST_SUB
    '   �ߒl    :   �Ȃ�
    '-------------------------------------------------------------------------------
    Private Sub PrItem2D186(ByRef pryy As Single, ByRef DT As GEPPOU_LIST_SUB, Optional ByRef Flg As Short = 0)

        Dim PR_WK_Renamed As PR_WK
        Dim PR_Text As String
        Dim yMargn As Single

        '----- ����
        Call PRN_LINE(XX(0), pryy, XX(UBound(XX)), pryy, 20, "")
        Call PRN_LINE(XX(0), pryy + (P_YY * 3.5), XX(UBound(XX)), pryy + (P_YY * 3.5), 20, "")

        ' ���f
        If PrnCancel = 1 Then Exit Sub

        '----- �]��
        yMargn = P_YY * 0.75

        '----- �P�s��
        '----- �񍀖�
        If Flg = 0 Then
            '�O���E���cNo.(���o��)
            Select Case DT.WARIDASI_KB
                Case "1" : PR_Text = "���cNo." & DT.WARIDASI_NO & " " & GetNameWaridasi(CtlKouji.KOUJI_NO, CtlKouji.EDA_NO, DT.WARIDASI_NO)
                Case "2" : PR_Text = "�O��No." & DT.WARIDASI_NO & " " & GetNameWaridasi(CtlKouji.KOUJI_NO, CtlKouji.EDA_NO, DT.WARIDASI_NO)
            End Select
            PR_WK_Renamed.DT = PR_Text
            PR_WK_Renamed.FS = F_SIZE
            '2021.08.18 UPGRADE S  AIT)hieutv
            'PR_WK_Renamed.X = PRN_XGet(0, XX(1), XX(2), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
            PRN_XGet(0, XX(1), XX(3), PR_WK_Renamed)
            '2021.08.18 UPGRADE E
            PR_WK_Renamed.Y = pryy + yMargn
            Call PRN_DATA(PR_WK_Renamed)
        End If
        ' ���s�\�Z
        'PR_WK.DT = "���s�\�Z"  '----- 2004/03/17 �C��
        PR_WK_Renamed.DT = "��Ɋz ���� ��ɗ\��z"
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.X = PRN_XGet(1, XX(3), XX(7), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(1, XX(3), XX(7), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        '    '2013/12/10 �ǉ� -----------------------------------------------------------------------����������
        '    PR_WK.DT = "�O��"
        '    PR_WK.FS = F_SIZE
        '    PR_WK.X = PRN_XGet(1, XX(7), XX(8), PR_WK.FS, PR_WK.DT)
        '    PR_WK.Y = pryy + yMargn
        '    Call PRN_DATA(PR_WK)
        '    PR_WK.DT = "����"
        '    PR_WK.FS = F_SIZE
        '    PR_WK.X = PRN_XGet(1, XX(8), XX(9), PR_WK.FS, PR_WK.DT)
        '    PR_WK.Y = pryy + yMargn
        '    Call PRN_DATA(PR_WK)
        '    '---------------------------------------------------------------------------------------����������
        ' �݌v���{���z
        PR_WK_Renamed.DT = "�݌v���{���z"
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.X = PRN_XGet(1, XX(9), XX(11), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(1, XX(9), XX(11), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' ���㏊�v����
        PR_WK_Renamed.DT = "���㏊�v����"
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.X = PRN_XGet(1, XX(11), XX(13), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(1, XX(11), XX(13), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' ���{�������z
        PR_WK_Renamed.DT = "���{�������z"
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.X = PRN_XGet(1, XX(13), XX(15), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(1, XX(13), XX(15), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        '----- �]��
        yMargn = (P_YY * 1.5) * 1.5

        ' �H��
        PR_WK_Renamed.DT = "�H��"
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.X = PRN_XGet(0, XX(1), XX(2), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(0, XX(1), XX(2), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' ���s�\�Z<����>
        PR_WK_Renamed.DT = "����"
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.X = PRN_XGet(2, XX(3), XX(4), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(3), XX(4), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' ���s�\�Z<�P��>
        PR_WK_Renamed.DT = "�P��"
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.X = PRN_XGet(2, XX(4), XX(5), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(4), XX(5), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' ���s�\�Z<�P��>
        PR_WK_Renamed.DT = "�P��"
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.X = PRN_XGet(2, XX(5), XX(6), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(5), XX(6), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' ���s�\�Z<���z>
        PR_WK_Renamed.DT = "���z"
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.X = PRN_XGet(2, XX(6), XX(7), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(6), XX(7), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        '    '2013/12/10 �ǉ� -----------------------------------------------------------------------����������
        '    PR_WK.DT = "���{���z"
        '    PR_WK.FS = F_SIZE
        '    PR_WK.X = PRN_XGet(2, XX(7), XX(8), PR_WK.FS, PR_WK.DT)
        '    PR_WK.Y = pryy + yMargn
        '    Call PRN_DATA(PR_WK)
        '    PR_WK.DT = "���{���z"
        '    PR_WK.FS = F_SIZE
        '    PR_WK.X = PRN_XGet(2, XX(8), XX(9), PR_WK.FS, PR_WK.DT)
        '    PR_WK.Y = pryy + yMargn
        '    Call PRN_DATA(PR_WK)
        '    '---------------------------------------------------------------------------------------����������
        ' �ݐώ��{���z<����>
        PR_WK_Renamed.DT = "����"
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.X = PRN_XGet(2, XX(9), XX(10), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(9), XX(10), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' �݌v���{���z
        PR_WK_Renamed.DT = "���z"
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.X = PRN_XGet(2, XX(10), XX(11), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(10), XX(11), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' ���㏊�v����<����>
        PR_WK_Renamed.DT = "����"
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.X = PRN_XGet(2, XX(11), XX(12), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(11), XX(12), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' ���㏊�v����
        PR_WK_Renamed.DT = "���z"
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.X = PRN_XGet(2, XX(12), XX(13), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(12), XX(13), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' ���{�������z<����>
        PR_WK_Renamed.DT = "����"
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.X = PRN_XGet(2, XX(13), XX(14), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(13), XX(14), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' ���{�������z
        PR_WK_Renamed.DT = "���z"
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.X = PRN_XGet(2, XX(14), XX(15), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(14), XX(15), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' �\�Z�Δ�
        PR_WK_Renamed.DT = "�\�Z�Δ�"
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.X = PRN_XGet(2, XX(15), XX(16), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(15), XX(16), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' �ύX����
        PR_WK_Renamed.DT = "�ύX����"
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.X = PRN_XGet(2, XX(16), XX(17), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(16), XX(17), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)

    End Sub

    '-------------------------------------------------------------------------------
    '   ����    :   ����ڍ׃f�[�^�������
    '   �֐�    :   Sub PrDataD186()
    '   ����    :   pryy    ����x�ʒu
    '   �@�@        DT()    GEPPOU_LIST_SUB
    '   �ߒl    :   �Ȃ�
    '-------------------------------------------------------------------------------
    Private Sub PrDataD186(ByRef pryy As Single, ByRef DT As GEPPOU_LIST_SUB)

        Dim PR_WK_Renamed As PR_WK
        Dim yMargn As Single
        Dim PR_Text As String

        '----- �]��
        yMargn = P_YY * 0.25

        ' �H��
        PR_WK_Renamed.DT = DT.KOUSYU_CD & "-" & DT.KOUSYU_NO
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.X = PRN_XGet(0, XX(1), XX(2), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(0, XX(1), XX(2), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' ����
        PR_WK_Renamed.DT = DT.MEISYOU
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.X = PRN_XGet(0, XX(2), XX(3), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(0, XX(2), XX(3), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' ���s�\�Z<����>
        '2021.08.03 UPGRADE S  AIT)Tool Convert
        'PR_Text = VB6.Format(DT.SUURYOU, "##,###.##")
        PR_Text = DT.SUURYOU.ToString("##,###.##")
        '2021.08.03 UPGRADE E
        If Right(PR_Text, 1) = "." Then PR_Text = Left(PR_Text, Len(PR_Text) - 1)
        If Left(PR_Text, 1) = "." Then PR_Text = "0" & PR_Text
        If PR_Text = "0" Then PR_Text = ""
        PR_WK_Renamed.DT = PR_Text
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.X = PRN_XGet(2, XX(3), XX(4), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(3), XX(4), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' ���s�\�Z<�P��>
        PR_WK_Renamed.DT = Trim(DT.TANI)
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.X = PRN_XGet(1, XX(4), XX(5), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(1, XX(4), XX(5), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' ���s�\�Z<�P��>
        '2021.08.12 UPGRADE S  AIT)hieutv
        'PR_Text = VB6.Format(DT.TANKA, "#,###,###,##0")
        PR_Text = DT.TANKA.ToString("#,###,###,##0")
        '2021.08.12 UPGRADE E
        If PR_Text = "0" Then PR_Text = ""
        PR_WK_Renamed.DT = PR_Text
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.X = PRN_XGet(2, XX(5), XX(6), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(5), XX(6), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' ���s�\�Z<���z>
        '2021.08.12 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.DT = VB6.Format(DT.YOSAN_GAKU, "#,###,###,##0")
        PR_WK_Renamed.DT = DT.YOSAN_GAKU.ToString("#,###,###,##0")
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.X = PRN_XGet(2, XX(6), XX(7), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(6), XX(7), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        '    '2013/12/10 �ǉ� -----------------------------------------------------------------------����������
        '    ' �O�񖘎��{���z
        '    PR_WK.DT = Format$(DT.RUIGAKU, "#,###,###,##0")
        '    PR_WK.FS = F_SIZE
        '    PR_WK.X = PRN_XGet(2, XX(7), XX(8), PR_WK.FS, PR_WK.DT)
        '    PR_WK.Y = pryy + yMargn
        '    Call PRN_DATA(PR_WK)
        '    ' ������{���z
        '    PR_WK.DT = Format$(DT.KINGAKU, "#,###,###,##0")
        '    PR_WK.FS = F_SIZE
        '    PR_WK.X = PRN_XGet(2, XX(8), XX(9), PR_WK.FS, PR_WK.DT)
        '    PR_WK.Y = pryy + yMargn
        '    Call PRN_DATA(PR_WK)
        '    '---------------------------------------------------------------------------------------����������
        ' �݌v���{���z<����>
        '2021.08.03 UPGRADE S  AIT)Tool Convert
        'PR_Text = VB6.Format(DT.JITU_SUU + DT.RUI_SUU, "##,###.##")
        PR_Text = (DT.JITU_SUU + DT.RUI_SUU).ToString("##,###.##")
        '2021.08.03 UPGRADE E
        If Right(PR_Text, 1) = "." Then PR_Text = Left(PR_Text, Len(PR_Text) - 1)
        If Left(PR_Text, 1) = "." Then PR_Text = "0" & PR_Text
        If PR_Text = "0" Then PR_Text = ""
        PR_WK_Renamed.DT = PR_Text
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.X = PRN_XGet(2, XX(9), XX(10), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(9), XX(10), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' �݌v���{���z
        '2021.08.12 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.DT = VB6.Format(DT.KINGAKU + DT.RUIGAKU, "#,###,###,##0")
        PR_WK_Renamed.DT = (DT.KINGAKU + DT.RUIGAKU).ToString("#,###,###,##0")
        '2021.08.12 UPGRADE S  AIT)hieutv
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.X = PRN_XGet(2, XX(10), XX(11), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(10), XX(11), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' ���㏊�v����<����>
        '2021.08.03 UPGRADE S  AIT)Tool Convert
        'PR_Text = VB6.Format(DT.KONGO_SUU, "##,###.##")
        PR_Text = DT.KONGO_SUU.ToString("##,###.##")
        '2021.08.03 UPGRADE E
        If Right(PR_Text, 1) = "." Then PR_Text = Left(PR_Text, Len(PR_Text) - 1)
        If Left(PR_Text, 1) = "." Then PR_Text = "0" & PR_Text
        If PR_Text = "0" Then PR_Text = ""
        PR_WK_Renamed.DT = PR_Text
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.X = PRN_XGet(2, XX(11), XX(12), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(11), XX(12), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' ���㏊�v����
        '2021.08.12 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.DT = VB6.Format(DT.KONGO_GAKU, "#,###,###,##0")
        PR_WK_Renamed.DT = DT.KONGO_GAKU.ToString("#,###,###,##0")
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.X = PRN_XGet(2, XX(12), XX(13), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(12), XX(13), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' ���{�������z<����>
        '2021.08.03 UPGRADE S  AIT)Tool Convert
        'PR_Text = VB6.Format(DT.JISSI_SUU, "##,###.##")
        PR_Text = DT.JISSI_SUU.ToString("##,###.##")
        '2021.08.03 UPGRADE E
        If Right(PR_Text, 1) = "." Then PR_Text = Left(PR_Text, Len(PR_Text) - 1)
        If Left(PR_Text, 1) = "." Then PR_Text = "0" & PR_Text
        If PR_Text = "0" Then PR_Text = ""
        PR_WK_Renamed.DT = PR_Text
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.X = PRN_XGet(2, XX(13), XX(14), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(13), XX(14), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' ���{�������z
        '2021.08.12 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.DT = VB6.Format(DT.JISSI_GAKU, "#,###,###,##0")
        PR_WK_Renamed.DT = DT.JISSI_GAKU.ToString("#,###,###,##0")
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.X = PRN_XGet(2, XX(14), XX(15), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(14), XX(15), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' �\�Z�Δ�
        '2021.08.12 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.DT = VB6.Format(DT.TAIHI_GAKU, "#,###,###,##0")
        PR_WK_Renamed.DT = DT.TAIHI_GAKU.ToString("#,###,###,##0")
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.X = PRN_XGet(2, XX(15), XX(16), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(15), XX(16), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' �ύX����
        '2021.08.12 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.DT = VB6.Format(DT.ZOGEN_GAKU, "#,###,###,##0")
        PR_WK_Renamed.DT = DT.ZOGEN_GAKU.ToString("#,###,###,##0")
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.X = PRN_XGet(2, XX(16), XX(17), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(16), XX(17), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)

    End Sub

    '-------------------------------------------------------------------------------
    '   ����    :   ����ڍ׃f�[�^���v�������
    '   �֐�    :   Sub PrDataGD186()
    '   ����    :   pryy            ����x�ʒu
    '   �@�@        KOUMOKU_KEI()   �e���ڋ��z���v
    '   �ߒl    :   �Ȃ�
    '-------------------------------------------------------------------------------
    Private Sub PrDataGD186(ByRef pryy As Single, ByRef KOUMOKU_KEI() As Decimal)

        Dim PR_WK_Renamed As PR_WK
        Dim yMargn As Single

        '----- �]��
        yMargn = P_YY * 0.25

        '----- ����
        Call PRN_LINE(XX(2) + P_XX * (35), pryy, XX(UBound(XX)), pryy, 10, "")

        ' ���v(���o��)
        PR_WK_Renamed.DT = "���v"
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.X = PRN_XGet(2, XX(1), XX(3), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(1), XX(3), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' ���s�\�Z
        '2021.08.12 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.DT = VB6.Format(KOUMOKU_KEI(1), "#,###,###,##0")
        PR_WK_Renamed.DT = KOUMOKU_KEI(1).ToString("#,###,###,##0")
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.X = PRN_XGet(2, XX(6), XX(7), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(6), XX(7), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        '    '2013/12/10 �ǉ� -----------------------------------------------------------------------����������
        '    ' �O�񖘎��{���z
        '    PR_WK.DT = Format$(KOUMOKU_KEI(7), "#,###,###,##0")
        '    PR_WK.FS = F_SIZE
        '    PR_WK.X = PRN_XGet(2, XX(7), XX(8), PR_WK.FS, PR_WK.DT)
        '    PR_WK.Y = pryy + yMargn
        '    Call PRN_DATA(PR_WK)
        '    ' ������{���z
        '    PR_WK.DT = Format$(KOUMOKU_KEI(8), "#,###,###,##0")
        '    PR_WK.FS = F_SIZE
        '    PR_WK.X = PRN_XGet(2, XX(8), XX(9), PR_WK.FS, PR_WK.DT)
        '    PR_WK.Y = pryy + yMargn
        '    Call PRN_DATA(PR_WK)
        '    '---------------------------------------------------------------------------------------����������
        ' �݌v���{���z
        '2021.08.12 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.DT = VB6.Format(KOUMOKU_KEI(2), "#,###,###,##0")
        PR_WK_Renamed.DT = KOUMOKU_KEI(2).ToString("#,###,###,##0")
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.X = PRN_XGet(2, XX(10), XX(11), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(10), XX(11), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' ���㏊�v����
        '2021.08.12 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.DT = VB6.Format(KOUMOKU_KEI(3), "#,###,###,##0")
        PR_WK_Renamed.DT = KOUMOKU_KEI(3).ToString("#,###,###,##0")
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.X = PRN_XGet(2, XX(12), XX(13), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(12), XX(13), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' ���{�������z
        '2021.08.12 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.DT = VB6.Format(KOUMOKU_KEI(4), "#,###,###,##0")
        PR_WK_Renamed.DT = KOUMOKU_KEI(4).ToString("#,###,###,##0")
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.X = PRN_XGet(2, XX(14), XX(15), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(14), XX(15), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' �\�Z�Δ�
        '2021.08.12 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.DT = VB6.Format(KOUMOKU_KEI(5), "#,###,###,##0")
        PR_WK_Renamed.DT = KOUMOKU_KEI(5).ToString("#,###,###,##0")
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.X = PRN_XGet(2, XX(15), XX(16), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(15), XX(16), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' �ύX����
        '2021.08.12 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.DT = VB6.Format(KOUMOKU_KEI(6), "#,###,###,##0")
        PR_WK_Renamed.DT = KOUMOKU_KEI(6).ToString("#,###,###,##0")
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.X = PRN_XGet(2, XX(16), XX(17), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(16), XX(17), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)

    End Sub

    '-------------------------------------------------------------------------------
    '   ����    :   ����ڍ׃f�[�^�����v�E�P�����z�������
    '   �֐�    :   Sub PrDataG2D186()
    '   ����    :   pryy            ����x�ʒu
    '   �@�@        KOUMOKU_KEI()   �e���ڋ��z���v
    '   �ߒl    :   �Ȃ�
    '-------------------------------------------------------------------------------
    Private Sub PrDataG2D186(ByRef pryy As Single, ByRef G_KOUMOKU_KEI() As Decimal)

        Dim PR_WK_Renamed As PR_WK
        Dim PR_Text As String
        Dim yMargn As Single
        Dim CurBuf1 As Decimal
        Dim CurBuf2 As Decimal

        '----- �]��
        yMargn = P_YY * 0.25

        '----- ���s
        pryy = pryy + ((P_YY * 1.5) * 1.5)

        '----- ����(�O�g)
        Call PRN_LINE(XX(0), pryy, XX(UBound(XX)), pryy, 20, "")
        Call PRN_LINE(XX(0), pryy + P_YY * 2.25, XX(UBound(XX)), pryy + P_YY * 2.25, 20, "")

        '----- ���s
        pryy = pryy + P_YY * 0.5

        ' �����v(���o��)
        PR_WK_Renamed.DT = "�����v"
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.X = PRN_XGet(2, XX(1), XX(2), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(1), XX(2), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' ���s�\�Z
        '2021.08.12 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.DT = VB6.Format(G_KOUMOKU_KEI(1), "#,###,###,##0")
        PR_WK_Renamed.DT = G_KOUMOKU_KEI(1).ToString("#,###,###,##0")
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.X = PRN_XGet(2, XX(6), XX(7), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(6), XX(7), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        '    '2013/12/10 �ǉ� -----------------------------------------------------------------------����������
        '    ' �O�񖘎��{���z
        '    PR_WK.DT = Format$(G_KOUMOKU_KEI(7), "#,###,###,##0")
        '    PR_WK.FS = F_SIZE
        '    PR_WK.X = PRN_XGet(2, XX(7), XX(8), PR_WK.FS, PR_WK.DT)
        '    PR_WK.Y = pryy + yMargn
        '    Call PRN_DATA(PR_WK)
        '    ' ������{���z
        '    PR_WK.DT = Format$(G_KOUMOKU_KEI(8), "#,###,###,##0")
        '    PR_WK.FS = F_SIZE
        '    PR_WK.X = PRN_XGet(2, XX(8), XX(9), PR_WK.FS, PR_WK.DT)
        '    PR_WK.Y = pryy + yMargn
        '    Call PRN_DATA(PR_WK)
        '    '---------------------------------------------------------------------------------------����������
        ' �݌v���{���z
        '2021.08.12 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.DT = VB6.Format(G_KOUMOKU_KEI(2), "#,###,###,##0")
        PR_WK_Renamed.DT = G_KOUMOKU_KEI(2).ToString("#,###,###,##0")
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.X = PRN_XGet(2, XX(10), XX(11), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(10), XX(11), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' ���㏊�v����
        '2021.08.12 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.DT = VB6.Format(G_KOUMOKU_KEI(3), "#,###,###,##0")
        PR_WK_Renamed.DT = G_KOUMOKU_KEI(3).ToString("#,###,###,##0")
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.X = PRN_XGet(2, XX(12), XX(13), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(12), XX(13), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' ���{�������z
        '2021.08.12 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.DT = VB6.Format(G_KOUMOKU_KEI(4), "#,###,###,##0")
        PR_WK_Renamed.DT = G_KOUMOKU_KEI(4).ToString("#,###,###,##0")
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.X = PRN_XGet(2, XX(14), XX(15), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(14), XX(15), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' �\�Z�Δ�
        '2021.08.12 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.DT = VB6.Format(G_KOUMOKU_KEI(5), "#,###,###,##0")
        PR_WK_Renamed.DT = G_KOUMOKU_KEI(5).ToString("#,###,###,##0")
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.X = PRN_XGet(2, XX(15), XX(16), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(15), XX(16), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' �ύX����
        '2021.08.12 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.DT = VB6.Format(G_KOUMOKU_KEI(6), "#,###,###,##0")
        PR_WK_Renamed.DT = G_KOUMOKU_KEI(6).ToString("#,###,###,##0")
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.X = PRN_XGet(2, XX(16), XX(17), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(16), XX(17), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)

        '----- ���s
        pryy = pryy + ((P_YY * 1.5) * 1.5)

        '----- ����
        Call PRN_LINE(XX(0), pryy, XX(UBound(XX)), pryy, 20, "")
        Call PRN_LINE(XX(0), pryy + P_YY * 2.25, XX(UBound(XX)), pryy + P_YY * 2.25, 20, "")

        '----- ���s
        pryy = pryy + (P_YY * 0.5)

        ' �P�����z(���o��)
        PR_WK_Renamed.DT = "�P�����z"
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.X = PRN_XGet(1, XX(7), XX(8), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(1, XX(7), XX(10), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)

        '�P�����z��
        CurBuf1 = GetCalcTankasa(CurBuf1)
        '2021.08.12 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.DT = VB6.Format(CurBuf1, "#,###,###,##0")
        PR_WK_Renamed.DT = CurBuf1.ToString("#,###,###,##0")
        '2021.08.12 UPGRADE E
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.X = PRN_XGet(2, XX(10), XX(11), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(10), XX(11), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)

        ' �C�ӘJ��(���o��)
        'PR_WK.DT = "�C�ӘJ��"
        PR_WK_Renamed.DT = "���S������"
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.X = PRN_XGet(2, XX(11), XX(12), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(11), XX(12), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)

        '�C�ӘJ�Њz��
        CurBuf1 = GetCalcTankasa(CurBuf2)
        '2021.08.12 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.DT = VB6.Format(CurBuf2, "#,###,###,##0")
        PR_WK_Renamed.DT = CurBuf2.ToString("#,###,###,##0")
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.18 UPGRADE S  AIT)hieutv
        'PR_WK_Renamed.X = PRN_XGet(2, XX(12), XX(13), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(12), XX(13), PR_WK_Renamed)
        '2021.08.18 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)

    End Sub

    '-------------------------------------------------------------------------------
    '   ����    :   ���y�[�W�`�F�b�N�p���R�[�h�������o����
    '   �֐�    :   Sub PrRcntD186()
    '   ����    :   DT()    GEPPOU_LIST_SUB
    '   �ߒl    :   R_Cnt   ���o���R�[�h����
    '-------------------------------------------------------------------------------
    Private Function PrRcntD186(ByRef DT As GEPPOU_LIST_SUB) As Object

        Dim QRY1 As String
        Dim QRY2 As String
        Dim QRY3 As String
        Dim QRY4 As String
        Dim SQL As String
        '2021.08.12 UPGRADE S  AIT)hieutv
        'Dim Rs As ADODB.Recordset
        'Dim Fld As ADODB.Field
        Dim Rs As New DataTable
        '2021.08.12 UPGRADE E
        Dim Cnt As Integer
        Dim OpenFlg As Short

        '2021.08.03 UPGRADE S  AIT)Tool Convert
        'On Error GoTo PrRcntD186_Err
        Try
            '2021.08.03 UPGRADE E

            ' �߂�l�̏�����
            PrRcntD186 = 0

            ' QRY/SELECT���g��
            QRY1 = "(SELECT WARIDASI_NO, MEISYOU"
            QRY1 = QRY1 & " FROM WARIDASI_MAST"
            QRY1 = QRY1 & " WHERE EDA_NO = '" & KeyKouji.EDA_NO & "'"
            QRY1 = QRY1 & " AND KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"
            QRY1 = QRY1 & ") AS MASTDT"

            ' QRY/SELECT���g��
            QRY2 = "(SELECT WARIDASI_NO, WARIDASI_KB, KOUSYU_CD, KOUSYU_NO, MEISAI_NO, J_KINGAKU"
            QRY2 = QRY2 & " FROM WARIDASI_DATA"
            QRY2 = QRY2 & " WHERE WARIDASI_KB <> '0'"
            QRY2 = QRY2 & " AND EDA_NO = '" & KeyKouji.EDA_NO & "'"
            QRY2 = QRY2 & " AND KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"
            QRY2 = QRY2 & ") AS WARIDT"

            ' QRY/SELECT���g��
            QRY3 = "(SELECT KOUSYU_CD, KOUSYU_NO, MEISAI_NO,"
            QRY3 = QRY3 & " SI_GAKU, SI_KEI, KONGO_GAKU, JISSI_GAKU, TAIHI_GAKU, ZOUGEN_GAKU"
            QRY3 = QRY3 & " FROM MIKOMI_DATA"
            QRY3 = QRY3 & " WHERE SIME_YM = '" & CtlKouji.SYORI_YM & "'"
            QRY3 = QRY3 & " AND EDA_NO = '" & KeyKouji.EDA_NO & "'"
            QRY3 = QRY3 & " AND KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"
            QRY3 = QRY3 & ") AS MIKOMI"

            ' QRY/SELECT���g��
            QRY4 = "(SELECT KOUSYU_CD, KOUSYU_NO, MEISAI_NO,"
            QRY4 = QRY4 & " JITU_GAKU, RUI_GAKU, KONGO_GAKU, JISSI_GAKU, TAIHI_GAKU, ZOUGEN_GAKU"
            QRY4 = QRY4 & " FROM DEKIDAKA_DATA"
            QRY4 = QRY4 & " WHERE SIME_YM = '" & CtlKouji.SYORI_YM & "'"
            QRY4 = QRY4 & " AND EDA_NO = '" & KeyKouji.EDA_NO & "'"
            QRY4 = QRY4 & " AND KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"
            QRY4 = QRY4 & ") AS DEKIDT"

            ' SQL/SELECT���g��
            SQL = "SELECT"
            SQL = SQL & " WARIDT.WARIDASI_NO      AS F01," ' ���o�ԍ�
            SQL = SQL & " WARIDT.WARIDASI_KB      AS F02," ' ���o�敪
            SQL = SQL & " MIN(MASTDT.MEISYOU)     AS F03," ' ���o����
            SQL = SQL & " SUM(WARIDT.J_KINGAKU)   AS F04," ' ���s�\�Z
            SQL = SQL & " SUM(MIKOMI.SI_GAKU)     AS F05," ' ���ы��z�i���c�j
            SQL = SQL & " SUM(MIKOMI.SI_KEI)      AS F06," ' ���ї݌v
            SQL = SQL & " SUM(MIKOMI.KONGO_GAKU)  AS F07," ' ���㌩��
            SQL = SQL & " SUM(MIKOMI.JISSI_GAKU)  AS F08," ' ���{����
            SQL = SQL & " SUM(MIKOMI.TAIHI_GAKU)  AS F09," ' �\�Z�Δ�
            SQL = SQL & " SUM(MIKOMI.ZOUGEN_GAKU) As F10," ' �ύX����
            SQL = SQL & " SUM(DEKIDT.JITU_GAKU)   AS F11," ' ���ы��z�i�O���j
            SQL = SQL & " SUM(DEKIDT.RUI_GAKU)    AS F12," ' ���ї݌v
            SQL = SQL & " SUM(DEKIDT.KONGO_GAKU)  AS F13," ' ���㌩��
            SQL = SQL & " SUM(DEKIDT.JISSI_GAKU)  AS F14," ' ���{����
            SQL = SQL & " SUM(DEKIDT.TAIHI_GAKU)  As F15," ' �\�Z�Δ�
            SQL = SQL & " SUM(DEKIDT.ZOUGEN_GAKU) As F16" ' �ύX����
            SQL = SQL & " FROM ((" & QRY2
            SQL = SQL & " LEFT JOIN " & QRY3
            SQL = SQL & " ON (WARIDT.MEISAI_NO = MIKOMI.MEISAI_NO)"
            SQL = SQL & " AND (WARIDT.KOUSYU_NO = MIKOMI.KOUSYU_NO)"
            SQL = SQL & " AND (WARIDT.KOUSYU_CD = MIKOMI.KOUSYU_CD))"
            SQL = SQL & " LEFT JOIN " & QRY4
            SQL = SQL & " ON (WARIDT.MEISAI_NO = DEKIDT.MEISAI_NO)"
            SQL = SQL & " AND (WARIDT.KOUSYU_NO = DEKIDT.KOUSYU_NO)"
            SQL = SQL & " AND (WARIDT.KOUSYU_CD = DEKIDT.KOUSYU_CD))"
            SQL = SQL & " LEFT JOIN " & QRY1
            SQL = SQL & " ON WARIDT.WARIDASI_NO = MASTDT.WARIDASI_NO"
            SQL = SQL & " WHERE WARIDT.WARIDASI_KB = '" & DT.WARIDASI_KB & "'"
            SQL = SQL & " AND WARIDT.WARIDASI_NO = '" & DT.WARIDASI_NO & "'"
            SQL = SQL & " GROUP BY WARIDT.WARIDASI_KB, WARIDT.WARIDASI_NO, WARIDT.KOUSYU_CD, WARIDT.KOUSYU_NO, WARIDT.MEISAI_NO"
            SQL = SQL & " ORDER BY WARIDT.WARIDASI_KB DESC, WARIDT.WARIDASI_NO, WARIDT.KOUSYU_CD, WARIDT.KOUSYU_NO, WARIDT.MEISAI_NO"

            ' SQL�����s
            '2021.08.12 UPGRADE S  AIT)hieutv
            'Rs = SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText)
            Rs = RsOpen(SQL)
            '2021.08.12 UPGRADE E
            OpenFlg = 1

            Cnt = 0
            '2021.08.12 UPGRADE S  AIT)hieutv
            'Do Until Rs.EOF
            '    Cnt = Cnt + 1
            '    Rs.MoveNext()
            'Loop

            'Rs.Close()
            For Each Row As DataRow In Rs.Rows
                Cnt = Cnt + 1
            Next

            Rs.Dispose()
            '2021.08.12 UPGRADE E
            Rs = Nothing

            ' �߂�l�̃Z�b�g
            PrRcntD186 = Cnt

            Exit Function

            '2021.08.03 UPGRADE S  AIT)Tool Convert
            'PrRcntD186_Err:
        Catch ex As Exception
            '2021.08.03 UPGRADE E

            If OpenFlg = 1 Then
                '2021.08.12 UPGRADE S  AIT)hieutv
                'Rs.Close()
                Rs.Dispose()
                '2021.08.12 UPGRADE E
            End If
            Rs = Nothing

            '2021.08.12 UPGRADE S  AIT)hieutv
            'Call Sql_Error_Msg("PrRcntD186")
            Call Sql_Error_Msg(ex, "PrRcntD186")
            '2021.08.12 UPGRADE E

        End Try     '2021.08.03 UPGRADE ADD AIT)Tool Convert
    End Function
End Module
