Option Strict Off
Option Explicit On

Module DB_WARIDASI_MAST

    Public Const WARIDASI_MAST_TBLNAME As String = "WARIDASI_MAST"

    '���o���}�X�^
    Structure WARIDASI_MAST_DBT
        '2021.07.26 UPGRADE S  AIT)Tool Convert
        '<VBFixedString(8),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=8)> Public KOUJI_NO() As Char '�H���ԍ�
        '<VBFixedString(4),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=4)> Public EDA_NO() As Char '�H���}��
        '<VBFixedString(2),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=2)> Public WARIDASI_NO() As Char '���o�ԍ�
        '<VBFixedString(1),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=1)> Public CHOKUEI_KB() As Char '���c�敪
        '<VBFixedString(1),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=1)> Public HIYOU_KB() As Char '��p�敪
        '<VBFixedString(8),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=8)> Public GYOUSYA_CD() As Char '�Ǝк���
        '<VBFixedString(40),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=40)> Public MEISYOU() As Char '����
        <VBFixedStringAttribute(8)> Public KOUJI_NO As String    '�H���ԍ�
        <VBFixedStringAttribute(4)> Public EDA_NO As String  '�H���}��
        <VBFixedStringAttribute(2)> Public WARIDASI_NO As String     '���o�ԍ�
        <VBFixedStringAttribute(1)> Public CHOKUEI_KB As String  '���c�敪
        <VBFixedStringAttribute(1)> Public HIYOU_KB As String    '��p�敪
        <VBFixedStringAttribute(8)> Public GYOUSYA_CD As String  '�Ǝк���
        <VBFixedStringAttribute(40)> Public MEISYOU As String    '����
        '2021.07.26 UPGRADE E
        Dim KEIYAKU_GAKU As Decimal '�_����z
        Dim ZEIRITU As Single '����ŗ�
        '2021.07.26 UPGRADE S  AIT)Tool Convert
        '<VBFixedString(1),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=1)> Public SEISAN_FLG() As Char '���Z�t���O
        '<VBFixedString(1),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=1)> Public HENKOU_FLG() As Char '�ύX�t���O
        <VBFixedStringAttribute(1)> Public SEISAN_FLG As String  '���Z�t���O
        <VBFixedStringAttribute(1)> Public HENKOU_FLG As String  '�ύX�t���O
        '2021.07.26 UPGRADE E
    End Structure

    '-------------------------------------------------------------------------------
    '   ����   :   WARIDASI_MAST_DBT �\���̃N���A����
    '   �֐�   :   Sub CLEAR_WARIDASI_MAST()
    '   ����   :   DT  WARIDASI_MAST_DBT
    '   �@�\   :   �\���̂�����������
    '-------------------------------------------------------------------------------
    Public Sub CLEAR_WARIDASI_MAST(ByRef DT As WARIDASI_MAST_DBT)

        With DT
            .KOUJI_NO = "" '�H���ԍ�
            .EDA_NO = "" '�H���}��
            .WARIDASI_NO = "" '���o�ԍ�
            .CHOKUEI_KB = "" '���c�敪
            .HIYOU_KB = "" '��p�敪
            .GYOUSYA_CD = "" '�Ǝк���
            .MEISYOU = "" '����
            .KEIYAKU_GAKU = 0 '�_����z
            .ZEIRITU = 0 '����ŗ�
            .SEISAN_FLG = "" '���Z�t���O
            .HENKOU_FLG = "" '�ύX�t���O
        End With

    End Sub

    '-------------------------------------------------------------------------------
    '   ����   :   WARIDASI_MAST Delete
    '   �֐�   :   Function DELETE_WARIDASI_MAST()
    '   ����   :   Jouken   ������
    '   �ߒl   :   True     ����I��
    '   �@�@       False    �ُ�I��
    '   �@�\   :   WARIDASI_MAST DELETE����
    '-------------------------------------------------------------------------------
    Public Function DELETE_WARIDASI_MAST(ByRef Jouken As String) As Boolean

        Dim SQL As String

        '2021.07.26 UPGRADE S  AIT)Tool Convert
        'On Error GoTo DELETE_WARIDASI_MAST_Err
        Try
            '2021.07.26 UPGRADE E

            '�߂�l�̏�����
            DELETE_WARIDASI_MAST = False

            'SQL/DELETE���g��
            SQL = "DELETE FROM " & WARIDASI_MAST_TBLNAME
            If Trim(Jouken) <> "" Then
                SQL = SQL & " WHERE " & Jouken
            End If

            'SQL�����s
            '2021.08.04 UPGRADE S  AIT)dannnl
            'SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText + ADODB.ExecuteOptionEnum.adExecuteNoRecords)
            ExecSQL(SQL)
            '2021.08.04 UPGRADE E

            '�߂�l�̃Z�b�g
            DELETE_WARIDASI_MAST = True
            Exit Function

            '2021.07.26 UPGRADE S  AIT)Tool Convert
            'DELETE_WARIDASI_MAST_Err:

            'Call Sql_Error_Msg("WARIDASI_MAST DELETE")
        Catch ex As Exception
            '2021.07.26 UPGRADE E

            Call Sql_Error_Msg(ex, "WARIDASI_MAST DELETE")

        End Try     '2021.07.26 UPGRADE ADD AIT)Tool Convert
    End Function

    '-------------------------------------------------------------------------------
    '   ����   :   WARIDASI_MAST INSERT����
    '   �֐�   :   Function INSERT_WARIDASI_MAST()
    '   ����   :   DT       WARIDASI_MAST_DBT
    '   �ߒl   :   True     ����I��
    '   �@�@       False    �ُ�I��
    '   �@�\   :   WARIDASI_MAST INSERT����
    '-------------------------------------------------------------------------------
    Public Function INSERT_WARIDASI_MAST(ByRef DT As WARIDASI_MAST_DBT) As Boolean

        Dim SQL As String

        '2021.07.26 UPGRADE S  AIT)Tool Convert
        'On Error GoTo INSERT_WARIDASI_MAST_Err
        Try
            '2021.07.26 UPGRADE E

            '�߂�l�̏�����
            INSERT_WARIDASI_MAST = False

            'SQL/INSERT���g��
            SQL = "INSERT INTO " & WARIDASI_MAST_TBLNAME
            SQL = SQL & " ("
            SQL = SQL & " KOUJI_NO,"
            SQL = SQL & " EDA_NO,"
            SQL = SQL & " WARIDASI_NO,"
            SQL = SQL & " CHOKUEI_KB,"
            SQL = SQL & " HIYOU_KB,"
            SQL = SQL & " GYOUSYA_CD,"
            SQL = SQL & " MEISYOU,"
            SQL = SQL & " KEIYAKU_GAKU,"
            SQL = SQL & " ZEIRITU,"
            SQL = SQL & " SEISAN_FLG,"
            SQL = SQL & " HENKOU_FLG"
            SQL = SQL & " ) VALUES("
            SQL = SQL & " '" & Trim(DT.KOUJI_NO) & "'," '�H���ԍ�
            SQL = SQL & " '" & Trim(DT.EDA_NO) & "'," '�H���}��
            SQL = SQL & " '" & Trim(DT.WARIDASI_NO) & "'," '���o�ԍ�
            SQL = SQL & " '" & Trim(DT.CHOKUEI_KB) & "'," '���c�敪
            SQL = SQL & " '" & Trim(DT.HIYOU_KB) & "'," '��p�敪
            SQL = SQL & " '" & Trim(DT.GYOUSYA_CD) & "'," '�Ǝк���
            SQL = SQL & " '" & Trim(DT.MEISYOU) & "'," '����
            SQL = SQL & " " & DT.KEIYAKU_GAKU & "," '�_����z
            SQL = SQL & " " & DT.ZEIRITU & "," '����ŗ�
            SQL = SQL & " '" & Trim(DT.SEISAN_FLG) & "'," '���Z�t���O
            SQL = SQL & " '" & Trim(DT.HENKOU_FLG) & "'" '�ύX�t���O
            SQL = SQL & " )"

            'SQL�����s
            '2021.08.04 UPGRADE S  AIT)dannnl
            'SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText + ADODB.ExecuteOptionEnum.adExecuteNoRecords)
            ExecSQL(SQL)
            '2021.08.04 UPGRADE E

            '�߂�l�̃Z�b�g
            INSERT_WARIDASI_MAST = True
            Exit Function

            '2021.07.26 UPGRADE S  AIT)Tool Convert
            'INSERT_WARIDASI_MAST_Err:

            'Call Sql_Error_Msg("WARIDASI_MAST INSERT")
        Catch ex As Exception
            '2021.07.26 UPGRADE E

            Call Sql_Error_Msg(ex, "WARIDASI_MAST INSERT")

        End Try     '2021.07.26 UPGRADE ADD AIT)Tool Convert
    End Function

    '-------------------------------------------------------------------------------
    '   ����   :   WARIDASI_MAST UPDATE
    '   �֐�   :   Function UPDATE_WARIDASI_MAST()
    '   ����   :   Jouken   ������
    '   �@�@       DT       WARIDASI_MAST_DBT
    '   �ߒl   :   True     ����I��
    '   �@�@       False    �ُ�I��
    '   �@�\   :   WARIDASI_MAST UPDATE����
    '-------------------------------------------------------------------------------
    Public Function UPDATE_WARIDASI_MAST(ByRef Jouken As String, ByRef DT As WARIDASI_MAST_DBT) As Boolean

        Dim SQL As String

        '2021.07.26 UPGRADE S  AIT)Tool Convert
        'On Error GoTo UPDATE_WARIDASI_MAST_Err
        Try
            '2021.07.26 UPGRADE E

            '�߂�l�̏�����
            UPDATE_WARIDASI_MAST = False

            'SQL/UPDATE���g��
            SQL = "UPDATE " & WARIDASI_MAST_TBLNAME
            SQL = SQL & " SET"
            SQL = SQL & " KOUJI_NO = '" & Trim(DT.KOUJI_NO) & "'," '�H���ԍ�
            SQL = SQL & " EDA_NO = '" & Trim(DT.EDA_NO) & "'," '�H���}��
            SQL = SQL & " WARIDASI_NO = '" & Trim(DT.WARIDASI_NO) & "'," '���o�ԍ�
            SQL = SQL & " CHOKUEI_KB = '" & Trim(DT.CHOKUEI_KB) & "'," '���c�敪
            SQL = SQL & " HIYOU_KB = '" & Trim(DT.HIYOU_KB) & "'," '��p�敪
            SQL = SQL & " GYOUSYA_CD = '" & Trim(DT.GYOUSYA_CD) & "'," '�Ǝк���
            SQL = SQL & " MEISYOU = '" & Trim(DT.MEISYOU) & "'," '����
            SQL = SQL & " KEIYAKU_GAKU = " & DT.KEIYAKU_GAKU & "," '�_����z
            SQL = SQL & " ZEIRITU = " & DT.ZEIRITU & "," '����ŗ�
            SQL = SQL & " SEISAN_FLG = '" & Trim(DT.SEISAN_FLG) & "'," '���Z�t���O
            SQL = SQL & " HENKOU_FLG = '" & Trim(DT.HENKOU_FLG) & "'" '�ύX�t���O
            If Trim(Jouken) <> "" Then
                SQL = SQL & " WHERE " & Jouken
            End If

            'SQL�����s
            '2021.08.04 UPGRADE S  AIT)dannnl
            'SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText + ADODB.ExecuteOptionEnum.adExecuteNoRecords)
            ExecSQL(SQL)
            '2021.08.04 UPGRADE E

            '�߂�l�̃Z�b�g
            UPDATE_WARIDASI_MAST = True
            Exit Function

            '2021.07.26 UPGRADE S  AIT)Tool Convert
            'UPDATE_WARIDASI_MAST_Err:

            'Call Sql_Error_Msg("WARIDASI_MAST UPDATE")
        Catch ex As Exception
            '2021.07.26 UPGRADE E

            Call Sql_Error_Msg(ex, "WARIDASI_MAST UPDATE")

        End Try     '2021.07.26 UPGRADE ADD AIT)Tool Convert
    End Function

    '-------------------------------------------------------------------------------
    '   ����   :   WARIDASI_MAST �f�[�^�Z�b�g����
    '   �֐�   :   Sub DATSET_WARIDASI_MAST()
    '   ����   :   Rs  DataRow
    '   �@�@       DT  WARIDASI_MAST_DBT
    '   �@�\   :   �\���̂Ƀf�[�^���Z�b�g����
    '-------------------------------------------------------------------------------
    '2021.08.04 UPGRADE S  AIT)dannnl
    'Public Sub DATSET_WARIDASI_MAST(ByRef Rs As ADODB.Recordset, ByRef DT As WARIDASI_MAST_DBT)

    '    Dim Fld As ADODB.Field
    Public Sub DATSET_WARIDASI_MAST(ByRef Rs As DataRow, ByRef DT As WARIDASI_MAST_DBT)

        Dim Fld As DataColumn
        '2021.08.04 UPGRADE E

        '�\���̂̏�����
        Call CLEAR_WARIDASI_MAST(DT)

        '�t�B�[���h�����������s
        '2021.08.04 UPGRADE S  AIT)dannnl
        'For Each Fld In Rs.Fields
        '    If IsDBNull(Fld.Name) = False And IsDBNull(Fld.Value) = False Then
        '        Select Case UCase(Fld.Name)
        '            Case "KOUJI_NO" : DT.KOUJI_NO = Fld.Value '�H���ԍ�
        '            Case "EDA_NO" : DT.EDA_NO = Fld.Value '�H���}��
        '            Case "WARIDASI_NO" : DT.WARIDASI_NO = Fld.Value '���o�ԍ�
        '            Case "CHOKUEI_KB" : DT.CHOKUEI_KB = Fld.Value '���c�敪
        '            Case "HIYOU_KB" : DT.HIYOU_KB = Fld.Value '��p�敪
        '            Case "GYOUSYA_CD" : DT.GYOUSYA_CD = Fld.Value '�Ǝк���
        '            Case "MEISYOU" : DT.MEISYOU = Fld.Value '����
        '            Case "KEIYAKU_GAKU" : DT.KEIYAKU_GAKU = Fld.Value '�_����z
        '            Case "ZEIRITU" : DT.ZEIRITU = Fld.Value '����ŗ�
        '            Case "SEISAN_FLG" : DT.SEISAN_FLG = Fld.Value '���Z�t���O
        '            Case "HENKOU_FLG" : DT.HENKOU_FLG = Fld.Value '�ύX�t���O
        Dim cellValue As Object
        For Each Fld In Rs.Table.Columns
            If IsDBNull(Fld.ColumnName) = False And IsDBNull(Rs(Fld.ColumnName)) = False Then
                cellValue = Rs(Fld.ColumnName)
                If cellValue IsNot Nothing AndAlso cellValue.ToString = "0.0000" Then cellValue = 0
                Select Case UCase(Fld.ColumnName)
                    Case "KOUJI_NO" : DT.KOUJI_NO = cellValue '�H���ԍ�
                    Case "EDA_NO" : DT.EDA_NO = cellValue '�H���}��
                    Case "WARIDASI_NO" : DT.WARIDASI_NO = cellValue '���o�ԍ�
                    Case "CHOKUEI_KB" : DT.CHOKUEI_KB = cellValue '���c�敪
                    Case "HIYOU_KB" : DT.HIYOU_KB = cellValue '��p�敪
                    Case "GYOUSYA_CD" : DT.GYOUSYA_CD = cellValue '�Ǝк���
                    Case "MEISYOU" : DT.MEISYOU = cellValue '����
                    Case "KEIYAKU_GAKU" : DT.KEIYAKU_GAKU = cellValue '�_����z
                    Case "ZEIRITU" : DT.ZEIRITU = cellValue '����ŗ�
                    Case "SEISAN_FLG" : DT.SEISAN_FLG = cellValue '���Z�t���O
                    Case "HENKOU_FLG" : DT.HENKOU_FLG = cellValue '�ύX�t���O
                        '2021.08.04 UPGRADE E
                End Select
            End If
        Next Fld

    End Sub

    '-------------------------------------------------------------------------------
    '   ����   :   WARIDASI_MAST �ǂݍ��ݏ���
    '   �֐�   :   Function SELECT_WARIDASI_MAST()
    '   ����   :   Jouken�@ ������
    '   �@�@       strSort�@�\�[�g����
    '   �@�@       DT()�@   WARIDASI_MAST_DBT
    '   �ߒl   :   �ް���   ����I��
    '   �@�@       -1�@     �ُ�I��
    '   �@�\   :   WARIDASI_MAST SELECT����
    '-------------------------------------------------------------------------------
    Public Function SELECT_WARIDASI_MAST(ByRef Jouken As String, ByRef strSort As String, ByRef DT() As WARIDASI_MAST_DBT) As Integer

        Dim SQL As String
        '2021.08.04 UPGRADE S  AIT)dannnl
        'Dim Rs As ADODB.Recordset
        Dim Rs As New DataTable
        '2021.08.04 UPGRADE E
        Dim Cnt As Integer
        Dim OpenFlg As Short

        '2021.07.26 UPGRADE S  AIT)Tool Convert
        'On Error GoTo SELECT_WARIDASI_MAST_Err
        Try
            '2021.07.26 UPGRADE E

            '�߂�l�̏�����
            SELECT_WARIDASI_MAST = -1

            'SQL/SELECT���g��
            SQL = "SELECT * FROM " & WARIDASI_MAST_TBLNAME
            If Trim(Jouken) <> "" Then
                SQL = SQL & " WHERE " & Jouken
            End If
            If Trim(strSort) <> "" Then
                SQL = SQL & " ORDER BY " & strSort
            End If

            'SQL�����s
            '2021.08.04 UPGRADE S  AIT)dannnl
            'Rs = SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText)
            Rs = RsOpen(SQL)
            '2021.08.04 UPGRADE E
            OpenFlg = 1

            Cnt = 0
            '2021.08.04 UPGRADE S  AIT)dannnl
            'Do Until Rs.EOF
            For Each Row As DataRow In Rs.Rows
                '2021.08.04 UPGRADE E
                ReDim Preserve DT(Cnt)
                '2021.08.04 UPGRADE S  AIT)dannnl
                'Call DATSET_WARIDASI_MAST(Rs, DT(Cnt))
                Call DATSET_WARIDASI_MAST(Row, DT(Cnt))
                '2021.08.04 UPGRADE E	
                Cnt = Cnt + 1
                '2021.08.04 UPGRADE S  AIT)dannnl
                '    Rs.MoveNext()
                'Loop

                'Rs.Close()
            Next
            Rs.Dispose()
            '2021.08.04 UPGRADE E
            Rs = Nothing

            '�߂�l�̃Z�b�g
            SELECT_WARIDASI_MAST = Cnt
            Exit Function

            '2021.07.26 UPGRADE S  AIT)Tool Convert
            'SELECT_WARIDASI_MAST_Err:
        Catch ex As Exception
            '2021.07.26 UPGRADE E

            If OpenFlg = 1 Then
                '2021.08.04 UPGRADE S  AIT)dannnl
                'Rs.Close()
                Rs.Dispose()
                '2021.08.04 UPGRADE E	
            End If
            Rs = Nothing

            '2021.08.04 UPGRADE S  AIT)dannnl
            'Call Sql_Error_Msg("WARIDASI_MAST SELECT")
            Call Sql_Error_Msg(ex, "WARIDASI_MAST SELECT")
            '2021.08.04 UPGRADE E	

        End Try     '2021.07.26 UPGRADE ADD AIT)Tool Convert
    End Function

    '-------------------------------------------------------------------------------
    '   ����   :   WARIDASI_MAST �ǂݍ��݌����擾����
    '   �֐�   :   Function CNTGET_WARIDASI_MAST()
    '   ����   :   Jouken�@ ������
    '   �ߒl   :   �ް���   ����I��
    '   �@�@       -1�@     �ُ�I��
    '   �@�\   :   WARIDASI_MAST CNTGET����
    '-------------------------------------------------------------------------------
    Public Function CNTGET_WARIDASI_MAST(ByRef Jouken As String) As Integer

        Dim SQL As String
        '2021.08.04 UPGRADE S  AIT)dannnl
        'Dim Rs As ADODB.Recordset
        Dim Rs As New DataTable
        '2021.08.04 UPGRADE E
        Dim Cnt As Integer
        Dim OpenFlg As Short

        '2021.07.26 UPGRADE S  AIT)Tool Convert
        'On Error GoTo CNTGET_WARIDASI_MAST_Err
        Try
            '2021.07.26 UPGRADE E

            '�߂�l�̏�����
            CNTGET_WARIDASI_MAST = -1

            'SQL/SELECT���g��
            '2021.08.10 UPGRADE S  AIT)hieutv
            'SQL = "SELECT COUNT(*) FROM " & WARIDASI_MAST_TBLNAME
            SQL = "SELECT COUNT(*) AS COUNTDATA FROM " & WARIDASI_MAST_TBLNAME
            '2021.08.10 UPGRADE E
            If Trim(Jouken) <> "" Then
                SQL = SQL & " WHERE " & Jouken
            End If

            'SQL�����s
            '2021.08.04 UPGRADE S  AIT)dannnl
            'Rs = SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText)
            Rs = RsOpen(SQL)
            '2021.08.04 UPGRADE E
            OpenFlg = 1

            Cnt = 0
            '2021.08.04 UPGRADE S  AIT)dannnl
            'If Rs.EOF = False Then
            '    If IsDBNull(Rs.Fields(0).Value) = False Then
            '        Cnt = Rs.Fields(0).Value
            If Rs.Rows.Count > 0 Then
                If IsDBNull(Rs.Rows(0)("COUNTDATA")) = False Then
                    Cnt = Rs.Rows(0)("COUNTDATA")
                    '2021.08.04 UPGRADE E
                End If
            End If

            '2021.08.04 UPGRADE S  AIT)dannnl
            'Rs.Close()
            Rs.Dispose()
            '2021.08.04 UPGRADE E
            Rs = Nothing

            '�߂�l�̃Z�b�g
            CNTGET_WARIDASI_MAST = Cnt
            Exit Function

            '2021.07.26 UPGRADE S  AIT)Tool Convert
            'CNTGET_WARIDASI_MAST_Err:
        Catch ex As Exception
            '2021.07.26 UPGRADE E

            If OpenFlg = 1 Then
                '2021.08.04 UPGRADE S  AIT)dannnl
                'Rs.Close()
                Rs.Dispose()
                '2021.08.04 UPGRADE E
            End If
            Rs = Nothing

            '2021.08.04 UPGRADE S  AIT)dannnl
            'Call Sql_Error_Msg("WARIDASI_MAST CNTGET")
            Call Sql_Error_Msg(ex, "WARIDASI_MAST CNTGET")
            '2021.08.04 UPGRADE E

        End Try     '2021.07.26 UPGRADE ADD AIT)Tool Convert
    End Function

    '-------------------------------------------------------------------------------
    '   ����   :   WARIDASI_MAST CREATE
    '   �֐�   :   Function CREATE_WARIDASI_MAST()
    '   �ߒl   :   True     ����I��
    '   �@�@       False    �ُ�I��
    '   �@�\   :   WARIDASI_MAST CREATE����
    '-------------------------------------------------------------------------------
    Public Function CREATE_WARIDASI_MAST() As Boolean

        Dim SQL As String

        '2021.07.26 UPGRADE S  AIT)Tool Convert
        'On Error GoTo CREATE_WARIDASI_MAST_Err
        Try
            '2021.07.26 UPGRADE E

            '�߂�l�̏�����
            CREATE_WARIDASI_MAST = False

            'SQL/CREATE���g��
            SQL = "CREATE TABLE " & WARIDASI_MAST_TBLNAME
            SQL = SQL & " ("
            SQL = SQL & " KOUJI_NO       Text(8)," '�H���ԍ�
            SQL = SQL & " EDA_NO         Text(4)," '�H���}��
            SQL = SQL & " WARIDASI_NO    Text(2)," '���o�ԍ�
            SQL = SQL & " CHOKUEI_KB     Text(1)," '���c�敪
            SQL = SQL & " HIYOU_KB       Text(1)," '��p�敪
            SQL = SQL & " GYOUSYA_CD     Text(8)," '�Ǝк���
            SQL = SQL & " MEISYOU        Text(40)," '����
            SQL = SQL & " KEIYAKU_GAKU   Currency," '�_����z
            SQL = SQL & " ZEIRITU        Single," '����ŗ�
            SQL = SQL & " SEISAN_FLG     Text(1)," '���Z�t���O
            SQL = SQL & " HENKOU_FLG     Text(1)," '�ύX�t���O
            SQL = SQL & " CONSTRAINT WARIDASI_MAST_UNIQUE PRIMARY KEY ("
            SQL = SQL & " KOUJI_NO," '�H���ԍ�
            SQL = SQL & " EDA_NO," '�H���}��
            SQL = SQL & " WARIDASI_NO" '���o�ԍ�
            SQL = SQL & " ))"

            'SQL�����s
            '2021.08.04 UPGRADE S  AIT)dannnl
            'SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText + ADODB.ExecuteOptionEnum.adExecuteNoRecords)
            ExecSQL(SQL)
            '2021.08.04 UPGRADE E

            '�߂�l�̃Z�b�g
            CREATE_WARIDASI_MAST = True
            Exit Function

            '2021.07.26 UPGRADE S  AIT)Tool Convert
            'CREATE_WARIDASI_MAST_Err:

            'Call Sql_Error_Msg("WARIDASI_MAST CREATE")
        Catch ex As Exception
            '2021.07.26 UPGRADE E

            Call Sql_Error_Msg(ex, "WARIDASI_MAST CREATE")

        End Try     '2021.07.26 UPGRADE ADD AIT)Tool Convert
    End Function

    '-------------------------------------------------------------------------------
    '   ����   :   WARIDASI_MAST TEXT WRITE
    '   �֐�   :   Sub TXT_WRITE_WARIDASI_MAST()
    '   ����   :   TextName �e�L�X�g�t�@�C����
    '   �@�@       DT()�@   WARIDASI_MAST_DBT
    '   �@�\   :   WARIDASI_MAST TEXT WRITE ����(CSV�`��)
    '-------------------------------------------------------------------------------
    Public Sub TXT_WRITE_WARIDASI_MAST(ByRef TextName As String, ByRef DT() As WARIDASI_MAST_DBT)

        Dim Msg As String
        Dim lp As Integer
        Dim Out_Buf As String
        Dim FNo As Short

        On Error Resume Next

        '�e�L�X�g�t�@�C���̍폜
        If Dir(Trim(TextName)) <> "" Then
            Msg = "���ɓ����̃t�@�C�������݂��܂��B�㏑�����Ă���낵���ł����H"
            Msg = Msg & vbCrLf & vbCrLf & Trim(TextName)
            '2021.09.14 UPGRADE S  AIT)dannnl
            'If MsgBox(Msg, MsgBoxStyle.YesNo) = MsgBoxResult.No Then Exit Sub
            If MsgBox(Msg, MsgBoxStyle.YesNo, SYSTEMNM) = MsgBoxResult.No Then Exit Sub
            '2021.09.14 UPGRADE E
            Kill(Trim(TextName))
        End If

        '�e�L�X�g�t�@�C���I�[�v��
        FNo = FreeFile()
        FileOpen(FNo, Trim(TextName), OpenMode.Output, OpenAccess.Write)

        '-----------------
        '�e�L�X�g���o������
        '-----------------
        For lp = 0 To UBound(DT)
            '�e�L�X�g�f�[�^���쐬���e�L�X�g�t�@�C������������
            Out_Buf = ""
            Out_Buf = Out_Buf & Chr(34) & CRSet(DT(lp).KOUJI_NO) & Chr(34) & "," '�H���ԍ�
            Out_Buf = Out_Buf & Chr(34) & CRSet(DT(lp).EDA_NO) & Chr(34) & "," '�H���}��
            Out_Buf = Out_Buf & Chr(34) & CRSet(DT(lp).WARIDASI_NO) & Chr(34) & "," '���o�ԍ�
            Out_Buf = Out_Buf & Chr(34) & CRSet(DT(lp).CHOKUEI_KB) & Chr(34) & "," '���c�敪
            Out_Buf = Out_Buf & Chr(34) & CRSet(DT(lp).HIYOU_KB) & Chr(34) & "," '��p�敪
            Out_Buf = Out_Buf & Chr(34) & CRSet(DT(lp).GYOUSYA_CD) & Chr(34) & "," '�Ǝк���
            Out_Buf = Out_Buf & Chr(34) & CRSet(DT(lp).MEISYOU) & Chr(34) & "," '����
            Out_Buf = Out_Buf & Chr(34) & CRSet(DT(lp).KEIYAKU_GAKU) & Chr(34) & "," '�_����z
            Out_Buf = Out_Buf & Chr(34) & CRSet(DT(lp).ZEIRITU) & Chr(34) & "," '����ŗ�
            Out_Buf = Out_Buf & Chr(34) & CRSet(DT(lp).SEISAN_FLG) & Chr(34) & "," '���Z�t���O
            Out_Buf = Out_Buf & Chr(34) & CRSet(DT(lp).HENKOU_FLG) & Chr(34) & "" '�ύX�t���O
            PrintLine(FNo, Out_Buf)
        Next lp

        '�e�L�X�g�t�@�C���N���[�Y
        FileClose(FNo)

    End Sub

    '-------------------------------------------------------------------------------
    '   ����   :   WARIDASI_MAST TEXT READ
    '   �֐�   :   Function TXT_READ_WARIDASI_MAST()
    '   ����   :   TextName �e�L�X�g�t�@�C����
    '   �ߒl   :   �ް���   ����I��
    '   �@�@       -1�@     �ُ�I��
    '   �@�\   :   WARIDASI_MAST TEXT READ ����(CSV�`��)
    '-------------------------------------------------------------------------------
    Public Function TXT_READ_WARIDASI_MAST(ByRef TextName As String) As Integer

        Dim Jouken As String
        Dim FNo As Short
        Dim IB As String
        Dim Bp As Short
        Dim Sp As Short
        Dim Cnt As Integer
        Dim FLen As Integer
        Dim DT As WARIDASI_MAST_DBT

        On Error Resume Next

        '�߂�l�̏�����
        TXT_READ_WARIDASI_MAST = -1

        '�t�@�C�����݃`�F�b�N
        Err.Clear()
        FLen = FileLen(TextName)
        If Err.Number <> 0 Then
            TXT_READ_WARIDASI_MAST = 0
            Exit Function
        End If

        '�e�L�X�g�t�@�C���I�[�v��
        FNo = FreeFile()
        FileOpen(FNo, Trim(TextName), OpenMode.Input, OpenAccess.Read)

        '�e�L�X�g�t�@�C����ǂݍ���
        Do
            IB = LineInput(FNo)

            '�G���[�̏ꍇ�̓��[�v�𔲂���
            If Err.Number <> 0 Then Exit Do

            IB = IB & "," & Chr(34)
            Do
                Sp = InStr(IB, "~|")
                If Sp > 0 Then Mid(IB, Sp, 2) = Chr(13) & Chr(10) Else Exit Do
            Loop

            '�\���̂ɃZ�b�g
            Bp = 2
            Sp = InStr(Bp, IB, "," & Chr(34)) : DT.KOUJI_NO = Mid(IB, Bp, Sp - Bp - 1) : Bp = Sp + 2 '�H���ԍ�
            Sp = InStr(Bp, IB, "," & Chr(34)) : DT.EDA_NO = Mid(IB, Bp, Sp - Bp - 1) : Bp = Sp + 2 '�H���}��
            Sp = InStr(Bp, IB, "," & Chr(34)) : DT.WARIDASI_NO = Mid(IB, Bp, Sp - Bp - 1) : Bp = Sp + 2 '���o�ԍ�
            Sp = InStr(Bp, IB, "," & Chr(34)) : DT.CHOKUEI_KB = Mid(IB, Bp, Sp - Bp - 1) : Bp = Sp + 2 '���c�敪
            Sp = InStr(Bp, IB, "," & Chr(34)) : DT.HIYOU_KB = Mid(IB, Bp, Sp - Bp - 1) : Bp = Sp + 2 '��p�敪
            Sp = InStr(Bp, IB, "," & Chr(34)) : DT.GYOUSYA_CD = Mid(IB, Bp, Sp - Bp - 1) : Bp = Sp + 2 '�Ǝк���
            Sp = InStr(Bp, IB, "," & Chr(34)) : DT.MEISYOU = Mid(IB, Bp, Sp - Bp - 1) : Bp = Sp + 2 '����
            Sp = InStr(Bp, IB, "," & Chr(34)) : DT.KEIYAKU_GAKU = CDec(Mid(IB, Bp, Sp - Bp - 1)) : Bp = Sp + 2 '�_����z
            Sp = InStr(Bp, IB, "," & Chr(34)) : DT.ZEIRITU = CSng(Mid(IB, Bp, Sp - Bp - 1)) : Bp = Sp + 2 '����ŗ�
            Sp = InStr(Bp, IB, "," & Chr(34)) : DT.SEISAN_FLG = Mid(IB, Bp, Sp - Bp - 1) : Bp = Sp + 2 '���Z�t���O
            Sp = InStr(Bp, IB, "," & Chr(34)) : DT.HENKOU_FLG = Mid(IB, Bp, Sp - Bp - 1) : Bp = Sp + 2 '�ύX�t���O

            '�f�[�^��o�^
            Jouken = ""
            Jouken = Jouken & " KOUJI_NO = '" & DT.KOUJI_NO & "' AND" '�H���ԍ�
            Jouken = Jouken & " EDA_NO = '" & DT.EDA_NO & "' AND" '�H���}��
            Jouken = Jouken & " WARIDASI_NO = '" & DT.WARIDASI_NO & "' AND" '���o�ԍ�
            If Right(Jouken, 4) = " AND" Then Jouken = Left(Jouken, Len(Jouken) - 4)
            If CNTGET_WARIDASI_MAST(Jouken) = 0 Then
                If INSERT_WARIDASI_MAST(DT) = False Then
                    Cnt = -1
                    Exit Do
                End If
            Else
                If UPDATE_WARIDASI_MAST(Jouken, DT) = False Then
                    Cnt = -1
                    Exit Do
                End If
            End If

            '�f�[�^���J�E���g
            Cnt = Cnt + 1
        Loop

        '�e�L�X�g�t�@�C���N���[�Y
        FileClose(FNo)

        '�߂�l�̃Z�b�g
        TXT_READ_WARIDASI_MAST = Cnt

    End Function
End Module
