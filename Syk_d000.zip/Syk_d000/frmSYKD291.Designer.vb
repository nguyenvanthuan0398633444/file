Imports GrapeCity.Win.Editors

<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frmSYKD291
#Region "Windows Form Designer generated code "
    <System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
        MyBase.New()
        InitializeComponent()
        '2021.08.25 UPGRADE ADD S AIT)hieutv
        Frame1 = New ArrayList()
        Frame1.Add(_Frame1_0)

        Label1 = New ArrayList(New Object(6){})
        Label1(6) = (_Label1_6)

        Option1 = New ArrayList()
        Option1.Add(_Option1_0)
        Option1.Add(_Option1_1)

        cmdKey = New ArrayList(New Object(12){})
        cmdKey(1) = _cmdKey_1
        cmdKey(12) = _cmdKey_12

        imText1 = New ArrayList()
        imText1.Add(_imText1_0)
        '2021.08.25 UPGRADE ADD E
    End Sub
    <System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
        If Disposing Then
            If Not components Is Nothing Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(Disposing)
    End Sub
    Private components As System.ComponentModel.IContainer
    Public ToolTip1 As System.Windows.Forms.ToolTip
    Public WithEvents Command1 As System.Windows.Forms.Button
    Public WithEvents Picture2 As System.Windows.Forms.Panel
    Public WithEvents _Option1_0 As System.Windows.Forms.RadioButton
    Public WithEvents _Option1_1 As System.Windows.Forms.RadioButton
    Public WithEvents Frame3 As System.Windows.Forms.GroupBox
    '2021.08.25 UPGRADE S  AIT)hieutv
    'Public WithEvents Dir1 As Microsoft.VisualBasic.Compatibility.VB6.DirListBox
    'Public WithEvents Drive1 As Microsoft.VisualBasic.Compatibility.VB6.DriveListBox
    'Public WithEvents _imText1_0 As imText6.imText
    Public WithEvents TreeView1 As TreeView
    Public WithEvents Drive1 As ComboBox
    Public WithEvents _imText1_0 As GcTextBox
    '2021.08.25 UPGRADE E
    Public WithEvents _Label1_6 As System.Windows.Forms.Label
    Public WithEvents _Frame1_0 As System.Windows.Forms.GroupBox
    Public WithEvents _cmdKey_1 As System.Windows.Forms.Button
    Public WithEvents _cmdKey_12 As System.Windows.Forms.Button
    Public WithEvents Picture1 As System.Windows.Forms.Panel
    Public WithEvents _StatusBar1_Panel1 As System.Windows.Forms.ToolStripStatusLabel
    Public WithEvents Message As System.Windows.Forms.ToolStripStatusLabel
    Public WithEvents StatusBar1 As System.Windows.Forms.StatusStrip
    Public WithEvents lblTitle As System.Windows.Forms.Label
    '2021.08.25 UPGRADE S  AIT)hieutv
    'Public WithEvents Frame1 As Microsoft.VisualBasic.Compatibility.VB6.GroupBoxArray
    'Public WithEvents Label1 As Microsoft.VisualBasic.Compatibility.VB6.LabelArray
    'Public WithEvents Option1 As Microsoft.VisualBasic.Compatibility.VB6.RadioButtonArray
    'Public WithEvents cmdKey As Microsoft.VisualBasic.Compatibility.VB6.ButtonArray
    'Public WithEvents imText1 As imTextArray
    Public WithEvents Frame1 As ArrayList
    Public WithEvents Label1 As ArrayList
    Public WithEvents Option1 As ArrayList
    Public WithEvents cmdKey As ArrayList
    Public WithEvents imText1 As ArrayList
    '2021.08.25 UPGRADE E

    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmSYKD291))
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.Picture2 = New System.Windows.Forms.Panel()
        Me.Command1 = New System.Windows.Forms.Button()
        Me.Frame3 = New System.Windows.Forms.GroupBox()
        Me._Option1_0 = New System.Windows.Forms.RadioButton()
        Me._Option1_1 = New System.Windows.Forms.RadioButton()
        Me._Frame1_0 = New System.Windows.Forms.GroupBox()
        Me.TreeView1 = New System.Windows.Forms.TreeView()
        Me.ImageList1 = New System.Windows.Forms.ImageList(Me.components)
        Me.Drive1 = New System.Windows.Forms.ComboBox()
        Me._imText1_0 = New GrapeCity.Win.Editors.GcTextBox(Me.components)
        Me._Label1_6 = New System.Windows.Forms.Label()
        Me.Picture1 = New System.Windows.Forms.Panel()
        Me._cmdKey_1 = New System.Windows.Forms.Button()
        Me._cmdKey_12 = New System.Windows.Forms.Button()
        Me.StatusBar1 = New System.Windows.Forms.StatusStrip()
        Me._StatusBar1_Panel1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.Message = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.Picture2.SuspendLayout
        Me.Frame3.SuspendLayout
        Me._Frame1_0.SuspendLayout
        CType(Me._imText1_0,System.ComponentModel.ISupportInitialize).BeginInit
        Me.Picture1.SuspendLayout
        Me.StatusBar1.SuspendLayout
        Me.SuspendLayout
        '
        'Picture2
        '
        Me.Picture2.BackColor = System.Drawing.SystemColors.Control
        Me.Picture2.Controls.Add(Me.Command1)
        Me.Picture2.Cursor = System.Windows.Forms.Cursors.Default
        Me.Picture2.Enabled = false
        Me.Picture2.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Picture2.Location = New System.Drawing.Point(164, 36)
        Me.Picture2.Name = "Picture2"
        Me.Picture2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Picture2.Size = New System.Drawing.Size(311, 43)
        Me.Picture2.TabIndex = 13
        Me.Picture2.Visible = false
        '
        'Command1
        '
        Me.Command1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255,Byte),Integer), CType(CType(192,Byte),Integer), CType(CType(255,Byte),Integer))
        Me.Command1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Command1.Font = New System.Drawing.Font("MS Mincho", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128,Byte))
        Me.Command1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Command1.Location = New System.Drawing.Point(0, 0)
        Me.Command1.Name = "Command1"
        Me.Command1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Command1.Size = New System.Drawing.Size(311, 43)
        Me.Command1.TabIndex = 14
        Me.Command1.TabStop = false
        Me.Command1.Text = "�f�[�^�̓]�������     "
        Me.Command1.UseVisualStyleBackColor = false
        '
        'Frame3
        '
        Me.Frame3.BackColor = System.Drawing.SystemColors.Control
        Me.Frame3.Controls.Add(Me._Option1_0)
        Me.Frame3.Controls.Add(Me._Option1_1)
        Me.Frame3.Font = New System.Drawing.Font("MS PMincho", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128,Byte))
        Me.Frame3.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Frame3.Location = New System.Drawing.Point(24, 122)
        Me.Frame3.Name = "Frame3"
        Me.Frame3.Padding = New System.Windows.Forms.Padding(0)
        Me.Frame3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame3.Size = New System.Drawing.Size(307, 167)
        Me.Frame3.TabIndex = 2
        Me.Frame3.TabStop = false
        Me.Frame3.Text = " �t���b�s�[�f�B�X�N "
        '
        '_Option1_0
        '
        Me._Option1_0.BackColor = System.Drawing.SystemColors.Control
        Me._Option1_0.Checked = true
        Me._Option1_0.Cursor = System.Windows.Forms.Cursors.Default
        Me._Option1_0.Font = New System.Drawing.Font("MS PMincho", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128,Byte))
        Me._Option1_0.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Option1_0.Location = New System.Drawing.Point(16, 24)
        Me._Option1_0.Name = "_Option1_0"
        Me._Option1_0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Option1_0.Size = New System.Drawing.Size(97, 17)
        Me._Option1_0.TabIndex = 2
        Me._Option1_0.TabStop = true
        Me._Option1_0.Tag = "�t���b�s�[�f�B�X�N�̃t�H�[�}�b�g�`����I�����܂��B"
        Me._Option1_0.Text = "1.44MB"
        Me._Option1_0.UseVisualStyleBackColor = false
        '
        '_Option1_1
        '
        Me._Option1_1.BackColor = System.Drawing.SystemColors.Control
        Me._Option1_1.Cursor = System.Windows.Forms.Cursors.Default
        Me._Option1_1.Enabled = false
        Me._Option1_1.Font = New System.Drawing.Font("MS PMincho", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128,Byte))
        Me._Option1_1.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Option1_1.Location = New System.Drawing.Point(16, 42)
        Me._Option1_1.Name = "_Option1_1"
        Me._Option1_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Option1_1.Size = New System.Drawing.Size(85, 25)
        Me._Option1_1.TabIndex = 3
        Me._Option1_1.TabStop = true
        Me._Option1_1.Tag = "�t���b�s�[�f�B�X�N�̃t�H�[�}�b�g�`����I�����܂��B"
        Me._Option1_1.Text = "1.25MB"
        Me._Option1_1.UseVisualStyleBackColor = false
        '
        '_Frame1_0
        '
        Me._Frame1_0.BackColor = System.Drawing.SystemColors.Control
        Me._Frame1_0.Controls.Add(Me.TreeView1)
        Me._Frame1_0.Controls.Add(Me.Drive1)
        Me._Frame1_0.Controls.Add(Me._imText1_0)
        Me._Frame1_0.Controls.Add(Me._Label1_6)
        Me._Frame1_0.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Frame1_0.Location = New System.Drawing.Point(6, 38)
        Me._Frame1_0.Name = "_Frame1_0"
        Me._Frame1_0.Padding = New System.Windows.Forms.Padding(0)
        Me._Frame1_0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Frame1_0.Size = New System.Drawing.Size(465, 281)
        Me._Frame1_0.TabIndex = 0
        Me._Frame1_0.TabStop = false
        Me._Frame1_0.Tag = "�o�͐�f�B���N�g����I�����܂��B"
        '
        'TreeView1
        '
        Me.TreeView1.BackColor = System.Drawing.Color.White
        Me.TreeView1.Cursor = System.Windows.Forms.Cursors.Default
        Me.TreeView1.ForeColor = System.Drawing.SystemColors.WindowText
        Me.TreeView1.ImageIndex = 0
        Me.TreeView1.ImageList = Me.ImageList1
        Me.TreeView1.Location = New System.Drawing.Point(18, 90)
        Me.TreeView1.Name = "TreeView1"
        Me.TreeView1.SelectedImageIndex = 1
        Me.TreeView1.ShowLines = false
        Me.TreeView1.ShowPlusMinus = false
        Me.TreeView1.ShowRootLines = false
        Me.TreeView1.Size = New System.Drawing.Size(307, 160)
        Me.TreeView1.TabIndex = 4
        Me.TreeView1.Tag = "�o�͐�f�B���N�g����I�����܂��B"
        '
        'ImageList1
        '
        Me.ImageList1.ImageStream = CType(resources.GetObject("ImageList1.ImageStream"),System.Windows.Forms.ImageListStreamer)
        Me.ImageList1.TransparentColor = System.Drawing.Color.Transparent
        Me.ImageList1.Images.SetKeyName(0, "closedfolder.bmp")
        Me.ImageList1.Images.SetKeyName(1, "openfolder.bmp")
        '
        'Drive1
        '
        Me.Drive1.BackColor = System.Drawing.SystemColors.Window
        Me.Drive1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Drive1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Drive1.Font = New System.Drawing.Font("MS PGothic", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128,Byte))
        Me.Drive1.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Drive1.Location = New System.Drawing.Point(18, 56)
        Me.Drive1.Name = "Drive1"
        Me.Drive1.Size = New System.Drawing.Size(307, 20)
        Me.Drive1.TabIndex = 1
        Me.Drive1.Tag = "�o�͐�h���C�u��I�����܂��B"
        '
        '_imText1_0
        '
        Me._imText1_0.Font = New System.Drawing.Font("MS Mincho", 12!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me._imText1_0.HighlightText = true
        Me._imText1_0.ImeMode = System.Windows.Forms.ImeMode.Off
        Me._imText1_0.Location = New System.Drawing.Point(130, 20)
        Me._imText1_0.MaxLength = 128
        Me._imText1_0.Name = "_imText1_0"
        Me._imText1_0.Size = New System.Drawing.Size(195, 23)
        Me._imText1_0.TabIndex = 0
        Me._imText1_0.TabStop = false
        Me._imText1_0.Tag = "�t�@�C��������͂��ĉ������B"
        '
        '_Label1_6
        '
        Me._Label1_6.BackColor = System.Drawing.Color.FromArgb(CType(CType(0,Byte),Integer), CType(CType(128,Byte),Integer), CType(CType(128,Byte),Integer))
        Me._Label1_6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._Label1_6.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_6.Font = New System.Drawing.Font("MS Mincho", 12!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128,Byte))
        Me._Label1_6.ForeColor = System.Drawing.Color.White
        Me._Label1_6.Location = New System.Drawing.Point(18, 20)
        Me._Label1_6.Name = "_Label1_6"
        Me._Label1_6.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_6.Size = New System.Drawing.Size(106, 23)
        Me._Label1_6.TabIndex = 12
        Me._Label1_6.Text = "�t�@�C����"
        Me._Label1_6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Picture1
        '
        Me.Picture1.BackColor = System.Drawing.Color.FromArgb(CType(CType(128,Byte),Integer), CType(CType(128,Byte),Integer), CType(CType(128,Byte),Integer))
        Me.Picture1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Picture1.Controls.Add(Me._cmdKey_1)
        Me.Picture1.Controls.Add(Me._cmdKey_12)
        Me.Picture1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Picture1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Picture1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Picture1.Location = New System.Drawing.Point(0, 325)
        Me.Picture1.Name = "Picture1"
        Me.Picture1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Picture1.Size = New System.Drawing.Size(481, 51)
        Me.Picture1.TabIndex = 8
        '
        '_cmdKey_1
        '
        Me._cmdKey_1.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_1.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_1.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128,Byte))
        Me._cmdKey_1.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_1.Location = New System.Drawing.Point(4, 4)
        Me._cmdKey_1.Name = "_cmdKey_1"
        Me._cmdKey_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_1.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_1.TabIndex = 5
        Me._cmdKey_1.Tag = "�o�͐�Ƀf�[�^��]�����܂��B"
        Me._cmdKey_1.Text = "F1"&Global.Microsoft.VisualBasic.ChrW(13)&Global.Microsoft.VisualBasic.ChrW(10)&"�] ��"
        Me._cmdKey_1.UseVisualStyleBackColor = false
        '
        '_cmdKey_12
        '
        Me._cmdKey_12.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_12.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_12.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128,Byte))
        Me._cmdKey_12.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_12.Location = New System.Drawing.Point(394, 4)
        Me._cmdKey_12.Name = "_cmdKey_12"
        Me._cmdKey_12.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_12.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_12.TabIndex = 6
        Me._cmdKey_12.Tag = "�I�����܂��B"
        Me._cmdKey_12.Text = "F12"&Global.Microsoft.VisualBasic.ChrW(13)&Global.Microsoft.VisualBasic.ChrW(10)&"�I ��"
        Me._cmdKey_12.UseVisualStyleBackColor = false
        '
        'StatusBar1
        '
        Me.StatusBar1.Font = New System.Drawing.Font("MS Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128,Byte))
        Me.StatusBar1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me._StatusBar1_Panel1, Me.Message})
        Me.StatusBar1.Location = New System.Drawing.Point(0, 376)
        Me.StatusBar1.Name = "StatusBar1"
        Me.StatusBar1.Size = New System.Drawing.Size(481, 23)
        Me.StatusBar1.TabIndex = 7
        '
        '_StatusBar1_Panel1
        '
        Me._StatusBar1_Panel1.AutoSize = false
        Me._StatusBar1_Panel1.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top)  _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right)  _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom),System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me._StatusBar1_Panel1.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter
        Me._StatusBar1_Panel1.Margin = New System.Windows.Forms.Padding(0)
        Me._StatusBar1_Panel1.Name = "_StatusBar1_Panel1"
        Me._StatusBar1_Panel1.Size = New System.Drawing.Size(117, 23)
        '
        'Message
        '
        Me.Message.AutoSize = false
        Me.Message.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top)  _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right)  _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom),System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me.Message.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter
        Me.Message.Margin = New System.Windows.Forms.Padding(0)
        Me.Message.Name = "Message"
        Me.Message.Size = New System.Drawing.Size(345, 23)
        Me.Message.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblTitle
        '
        Me.lblTitle.BackColor = System.Drawing.Color.FromArgb(CType(CType(192,Byte),Integer), CType(CType(255,Byte),Integer), CType(CType(255,Byte),Integer))
        Me.lblTitle.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTitle.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblTitle.Font = New System.Drawing.Font("MS Mincho", 20.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic),System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(128,Byte))
        Me.lblTitle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0,Byte),Integer), CType(CType(0,Byte),Integer), CType(CType(128,Byte),Integer))
        Me.lblTitle.Location = New System.Drawing.Point(0, 0)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblTitle.Size = New System.Drawing.Size(479, 31)
        Me.lblTitle.TabIndex = 10
        Me.lblTitle.Text = " �o�͐�I��"
        '
        'frmSYKD291
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(481, 399)
        Me.Controls.Add(Me.Picture2)
        Me.Controls.Add(Me.Frame3)
        Me.Controls.Add(Me._Frame1_0)
        Me.Controls.Add(Me.Picture1)
        Me.Controls.Add(Me.StatusBar1)
        Me.Controls.Add(Me.lblTitle)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"),System.Drawing.Icon)
        Me.KeyPreview = true
        Me.Location = New System.Drawing.Point(236, 210)
        Me.MaximizeBox = false
        Me.MinimizeBox = false
        Me.Name = "frmSYKD291"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "�H���Ǘ��V�X�e��"
        Me.Picture2.ResumeLayout(false)
        Me.Frame3.ResumeLayout(false)
        Me._Frame1_0.ResumeLayout(false)
        CType(Me._imText1_0,System.ComponentModel.ISupportInitialize).EndInit
        Me.Picture1.ResumeLayout(false)
        Me.StatusBar1.ResumeLayout(false)
        Me.StatusBar1.PerformLayout
        Me.ResumeLayout(false)
        Me.PerformLayout

End Sub

    Friend WithEvents ImageList1 As ImageList
#End Region
End Class