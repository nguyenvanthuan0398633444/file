Option Strict Off
Option Explicit On
Friend Class frmSYKD010
	Inherits System.Windows.Forms.Form
	'=============================================================
	' ���[�U�[���@  �F  �R�z�H�Ɗ������
	' �V�X�e�����@  �F  �H���Ǘ��V�X�e��
	' ���W���[����  �F  �H���Ǘ����j���[�i�y�؁j
	' ���W���[��ID�@�F  frmSYKD010.frm
	' �쐬���@ �@�@ �F  ���� 13 �N 06 �� 18 ��
	' �X�V���@�@  �@�F  ����    �N    ��    ��
	'=============================================================
	'
	
	Private StopFlg As Short '�����I���t���O
	Private ClkPos As Short
	Private ClkCnt As Short
	'

	'2021.08.02 UPGRADE S  AIT)Hoangtx
	'	Private Sub cmdKey_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Click
	Private Sub cmdKey_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _cmdKey_1.Click, _cmdKey_2.Click, _cmdKey_3.Click,
		_cmdKey_4.Click, _cmdKey_5.Click, _cmdKey_6.Click, _cmdKey_7.Click, _cmdKey_8.Click, _cmdKey_9.Click, _cmdKey_10.Click, _cmdKey_11.Click, _cmdKey_12.Click
		'Dim Index As Short = cmdKey.GetIndex(eventSender)
		Dim Index As Short = cmdKey.IndexOf(eventSender)
		'2021.08.02 UPGRADE E

		Select Case Index
			Case 12 '----- �I��
				' �H���I��
				'2021.08.02 add S  AIT)Hoangtx
				Me.Message.Text = ""
				cmdKey(12).BackColor = SystemColors.Control
				'2021.08.02 add E
				frmSYKD011.ShowDialog()
				' �H�����
				If frmSYKD011.SetKouji <> "" Then
					With KeyKouji
						imText2(0).Text = .KOUJI_NO
						If .EDA_NO <> "0000" Then imText2(1).Text = .EDA_NO
						imText2(2).Text = .MEISYOU
					End With
					If Command1(0).Enabled = True Then Command1(0).Focus()
				End If
		End Select

	End Sub

	'2021.08.02 UPGRADE S  AIT)Hoangtx
	'	Private Sub cmdKey_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Enter
	Private Sub cmdKey_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _cmdKey_1.Enter, _cmdKey_2.Enter, _cmdKey_3.Enter,
		_cmdKey_4.Enter, _cmdKey_5.Enter, _cmdKey_6.Enter, _cmdKey_7.Enter, _cmdKey_8.Enter, _cmdKey_9.Enter, _cmdKey_10.Enter, _cmdKey_11.Enter, _cmdKey_12.Enter
		'Dim Index As Short = cmdKey.GetIndex(eventSender)
		Dim Index As Short = cmdKey.IndexOf(eventSender)
		'Call GotFocus(cmdKey(Index), StatusBar1)
		Call MtyTool.GotFocus(cmdKey(Index), StatusBar1)
	End Sub
	'2021.08.02 UPGRADE E

	'2021.08.02 UPGRADE S  AIT)Hoangtx
	'Private Sub cmdKey_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Leave
	Private Sub cmdKey_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _cmdKey_1.Leave, _cmdKey_2.Leave, _cmdKey_3.Leave,
		_cmdKey_4.Leave, _cmdKey_5.Leave, _cmdKey_6.Leave, _cmdKey_7.Leave, _cmdKey_8.Leave, _cmdKey_9.Leave, _cmdKey_10.Leave, _cmdKey_11.Leave, _cmdKey_12.Leave
		'Dim Index As Short = cmdKey.GetIndex(eventSender)
		Dim Index As Short = cmdKey.IndexOf(eventSender)
		'Call LostFocus(cmdKey(Index), StatusBar1)
		Call MtyTool.LostFocus(cmdKey(Index), StatusBar1)
	End Sub
	'2021.08.02 UPGRADE E

	'2021.08.02 UPGRADE S  AIT)Hoangtx
	'	Private Sub Command1_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles Command1.Click
	Private Sub Command1_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _Command1_0.Click,
		_Command1_1.Click, _Command1_2.Click, _Command1_3.Click, _Command1_4.Click, _Command1_5.Click, _Command1_6.Click,
		_Command1_7.Click, _Command1_8.Click, _Command1_9.Click, _Command1_10.Click, _Command1_11.Click, _Command1_12.Click,
		_Command1_13.Click, _Command1_14.Click
		'Dim Index As Short = Command1.GetIndex(eventSender)
		Dim Index As Short = Command1.IndexOf(eventSender)
		'2021.08.02 UPGRADE E

		Select Case Index
			Case 0 '----- �o���f�[�^���
				If DMenuModeCheck(12) = False Then Exit Sub
				Call KeiriDataUketoriD(KeyKouji.KOUJI_NO, KeyKouji.EDA_NO)
				' ���j���[�̍ĕ\��
				Call DMenuRefresh()
				Exit Sub
			Case 1 '----- ���c��O�����o���ꗗ
				If DMenuModeCheck(1) = False Then Exit Sub
				frmSYKD020.Show()
			Case 2 '----- ��ʕ��ꗗ
				If DMenuModeCheck(2) = False Then Exit Sub
				frmSYKD060.Show()
			Case 3 '-----�@���c�E�O�������ꗗ
				If DMenuModeCheck(3) = False Then Exit Sub
				frmSYKD080.Show()
			Case 4 '----- �O���ꗗ
				If DMenuModeCheck(4) = False Then Exit Sub
				frmSYKD140.Show()
			Case 5 '----- �H������ꗗ
				If DMenuModeCheck(6) = False Then Exit Sub
				frmSYKD180.Show()
			Case 6 '----- ��ʕ����̓`�F�b�N���X�g���
				If DMenuModeCheck(7) = False Then Exit Sub
				frmSYKD075.ShowDialog()
				Exit Sub
			Case 7 '----- ���c�E�O�����o���ꗗ���
				'2021.10.01  UPGRADE DEL S  AIT)dannnl
				'If DMenuModeCheck(8) = False Then Exit Sub
				'frmSYKD035.ShowDialog()
				'Exit Sub
				'2021.10.01 UPGRADE DEL E	
			Case 8 '----- �O���o�����񍐏����
				If DMenuModeCheck(9) = False Then Exit Sub
				frmSYKD115.ShowDialog()
				Exit Sub
			Case 9 '----- ��ʕ��ꗗ���
				'2021.10.01  UPGRADE DEL S  AIT)dannnl
				'If DMenuModeCheck(10) = False Then Exit Sub
				'frmSYKD155.ShowDialog()
				'Exit Sub
				'2021.10.01 UPGRADE DEL E	
			Case 10 '----- �H��������
				If DMenuModeCheck(11) = False Then Exit Sub
				frmSYKD185.ShowDialog()
				Exit Sub
			Case 11 '----- ����f�[�^�쐬�i��ʂȂ��j
				If DMenuModeCheck(13) = False Then Exit Sub
				Call DGeppouDataMake(KeyKouji.KOUJI_NO, KeyKouji.EDA_NO)
				Exit Sub
			Case 12 '----- �m�茎��f�[�^���
				If DMenuModeCheck(14) = False Then Exit Sub
				Call DKakuteiGeppou(KeyKouji.KOUJI_NO, KeyKouji.EDA_NO)
				Exit Sub
			Case 13 '----- ���M�f�[�^�ꗗ
				If DMenuModeCheck(15) = False Then Exit Sub
				frmSYKD290.Show()
			Case 14 '----- ��M�f�[�^�ꗗ
				If DMenuModeCheck(16) = False Then Exit Sub
				frmSYKD300.D300ShowMode = 0
				frmSYKD300.Show()
		End Select
		Me.Hide()

	End Sub

	'2021.08.02 UPGRADE S  AIT)Hoangtx
	'	Private Sub Command1_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles Command1.Enter
	Private Sub Command1_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _Command1_0.Enter, _Command1_1.Enter,
		_Command1_2.Enter, _Command1_3.Enter, _Command1_4.Enter, _Command1_5.Enter, _Command1_6.Enter, _Command1_7.Enter, _Command1_8.Enter,
		_Command1_9.Enter, _Command1_10.Enter, _Command1_11.Enter, _Command1_12.Enter, _Command1_13.Enter, _Command1_14.Enter
		'Dim Index As Short = Command1.GetIndex(eventSender)
		Dim Index As Short = Command1.IndexOf(eventSender)
		'Call GotFocus(Command1(Index), StatusBar1)
		Call MtyTool.GotFocus(Command1(Index), StatusBar1)
		'2021.08.02 UPGRADE E
	End Sub

	'2021.08.02 UPGRADE S  AIT)Hoangtx
	'	Private Sub Command1_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles Command1.Leave
	Private Sub Command1_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _Command1_0.Leave, _Command1_1.Leave,
		_Command1_2.Leave, _Command1_3.Leave, _Command1_4.Leave, _Command1_5.Leave, _Command1_6.Leave, _Command1_7.Leave, _Command1_8.Leave,
		_Command1_9.Leave, _Command1_10.Leave, _Command1_11.Leave, _Command1_12.Leave, _Command1_13.Leave, _Command1_14.Leave
		'Dim Index As Short = Command1.GetIndex(eventSender)
		Dim Index As Short = Command1.IndexOf(eventSender)
		'Call LostFocus(Command1(Index), StatusBar1)
		Call MtyTool.LostFocus(Command1(Index), StatusBar1)
		'2021.08.02 UPGRADE E
	End Sub

	Private Sub frmSYKD010_Activated(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Activated

		' �����I��
		If StopFlg = 1 Then
			'2021.08.17 UPGRADE S  AIT)Hoangtx
			'Me.Close()
			Me.Dispose()
			'2021.08.17 UPGRADE E
			Exit Sub
		End If

		' ���̓��[�h�̏�����
		INPMODE = B10INPMODE

		' ���j���[�̍ĕ\��
		If DMenuRefresh = False Then
			'2021.08.17 UPGRADE S  AIT)Hoangtx
			'Me.Close()
			Me.Dispose()
			'2021.08.17 UPGRADE E
			Exit Sub
		End If
	End Sub
	
	Private Sub frmSYKD010_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown
		Dim KeyCode As Short = eventArgs.KeyCode
		Dim Shift As Short = eventArgs.KeyData \ &H10000
		Select Case KeyCode
			Case System.Windows.Forms.Keys.F1
				If cmdKey(1).Enabled = True Then cmdKey(1).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(1), New System.EventArgs())
			Case System.Windows.Forms.Keys.F2
				If cmdKey(2).Enabled = True Then cmdKey(2).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(2), New System.EventArgs())
			Case System.Windows.Forms.Keys.F3
				If cmdKey(3).Enabled = True Then cmdKey(3).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(3), New System.EventArgs())
			Case System.Windows.Forms.Keys.F4
				If cmdKey(4).Enabled = True Then cmdKey(4).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(4), New System.EventArgs())
			Case System.Windows.Forms.Keys.F5
				If cmdKey(5).Enabled = True Then cmdKey(5).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(5), New System.EventArgs())
			Case System.Windows.Forms.Keys.F6
				If cmdKey(6).Enabled = True Then cmdKey(6).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(6), New System.EventArgs())
			Case System.Windows.Forms.Keys.F7
				If cmdKey(7).Enabled = True Then cmdKey(7).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(7), New System.EventArgs())
			Case System.Windows.Forms.Keys.F8
				If cmdKey(8).Enabled = True Then cmdKey(8).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(8), New System.EventArgs())
			Case System.Windows.Forms.Keys.F9
				If cmdKey(9).Enabled = True Then cmdKey(9).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(9), New System.EventArgs())
			Case System.Windows.Forms.Keys.F10
				If cmdKey(10).Enabled = True Then cmdKey(10).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(10), New System.EventArgs())
			Case System.Windows.Forms.Keys.F11
				If cmdKey(11).Enabled = True Then cmdKey(11).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(11), New System.EventArgs())
			Case System.Windows.Forms.Keys.F12
				If Shift = 1 Then
					Call JobEnd()
				End If
				If cmdKey(12).Enabled = True Then cmdKey(12).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(12), New System.EventArgs())
		End Select
	End Sub
	
	Private Sub frmSYKD010_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load


		Dim lp As Short
		Dim Jouken As String
		Dim Order As String
		Dim DT() As SEIGYO_MAST_DBT
		
		''���܂�2007/09/06-------------------------------------------------------------------------����������-
		''�o�[�W�����\�����A�v���P�[�V����VERSION����Z�b�g(���r�W�����͖��g�p)
		VerCommand.Text = "Ver" & My.Application.Info.Version.Major & "." & My.Application.Info.Version.Minor & " " '& "." & App.Revision
		''���܂�2007/09/06-------------------------------------------------------------------------����������-
		
		
		' �����\��
		Call FormDisp(Me)
		
		' ������
		StopFlg = 0
		ClkPos = -1 : ClkCnt = 0
		Call CLEAR_KOUJI_NO_MAST(KeyKouji)
		imText1.Text = ""
		For lp = 0 To 2
			imText2(lp).Text = ""
		Next lp
		
		Me.Show()
		System.Windows.Forms.Application.DoEvents()
		StatusBar1.Items.Item("Message").Text = "�H������ǂݍ���ł��܂��E�E�E"
		System.Windows.Forms.Application.DoEvents()
		' ����t�@�C���̓Ǎ���
		Jouken = "" : Order = ""
		If SELECT_SEIGYO_MAST(Jouken, Order, DT) <= 0 Then
			'2021.09.14 UPGRADE S  AIT)dannnl
			'MsgBox("�����񂪌�����܂���B", MsgBoxStyle.OKOnly + MsgBoxStyle.Information)
			MsgBox("�����񂪌�����܂���B", MsgBoxStyle.OkOnly + MsgBoxStyle.Information, SYSTEMNM)
			'2021.09.14 UPGRADE E
			StopFlg = 1
			Exit Sub
		End If
		SEIGYO = DT(0)

		'2021.08.02 add S  AIT)Hoangtx
		Me.Message.Text = ""
		'2021.08.02 add E

		' �H���I��
		frmSYKD011.ShowDialog()
		System.Windows.Forms.Application.DoEvents()
		StatusBar1.Items.Item("Message").Text = ""
		System.Windows.Forms.Application.DoEvents()
		' �H�����

		If frmSYKD011.SetKouji <> "" Then
			With KeyKouji
				imText2(0).Text = .KOUJI_NO
				If .EDA_NO <> "0000" Then imText2(1).Text = .EDA_NO
				imText2(2).Text = .MEISYOU
			End With
		End If

	End Sub

	Private Sub frmSYKD010_FormClosing(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
		Dim Cancel As Boolean = eventArgs.Cancel
		Dim UnloadMode As System.Windows.Forms.CloseReason = eventArgs.CloseReason
		If UnloadMode = System.Windows.Forms.CloseReason.UserClosing Then
			' �H���I��
			frmSYKD011.ShowDialog()
			' �H�����
			If frmSYKD011.SetKouji <> "" Then
				With KeyKouji
					imText2(0).Text = .KOUJI_NO
					If .EDA_NO <> "0000" Then imText2(1).Text = .EDA_NO
					imText2(2).Text = .MEISYOU
				End With
				Command1(0).Focus()
				Cancel = True
			End If
		End If
		eventArgs.Cancel = Cancel
	End Sub

	'2021.08.02 UPGRADE S  AIT)Hoangtx
	'	Private Sub Picture2_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles Picture2.Click
	Private Sub Picture2_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _Picture2_0.Click,
		_Picture2_1.Click, _Picture2_2.Click, _Picture2_3.Click, _Picture2_4.Click, _Picture2_5.Click, _Picture2_6.Click,
		_Picture2_7.Click, _Picture2_8.Click, _Picture2_9.Click, _Picture2_10.Click, _Picture2_11.Click, _Picture2_12.Click,
		_Picture2_13.Click, _Picture2_14.Click
		'Dim Index As Short = Picture2.GetIndex(eventSender)
		Dim Index As Short = Picture2.IndexOf(eventSender)
		'2021.08.02 UPGRADE E

		Dim Jouken As String
		Dim Msg As String

		If ClkPos <> Index Then
			ClkPos = Index
			ClkCnt = 1
		Else
			ClkCnt = ClkCnt + 1
			If ClkCnt > 10 Then
				'----- ����t���O�X�V
				With CtlKouji
					Select Case ClkPos
						Case 0
							Select Case .R_FLG_KEIRI '�A�gFLG �o���f�[�^
								Case "0" : .R_FLG_KEIRI = "1"
								Case "1" : .R_FLG_KEIRI = "2"
								Case "2" : .R_FLG_KEIRI = "0"
							End Select
						Case 2 : If .H_FLG_IPPAN = "1" Then .H_FLG_IPPAN = "0" Else .H_FLG_IPPAN = "1" '�ύXFLG ��ʕ��ꗗ
						Case 3 : If .H_FLG_MIKOMI = "1" Then .H_FLG_MIKOMI = "0" Else .H_FLG_MIKOMI = "1" '�ύXFLG ���c��O�������ꗗ
						Case 4 : If .H_FLG_GAICHUU = "1" Then .H_FLG_GAICHUU = "0" Else .H_FLG_GAICHUU = "1" '�ύXFLG �O���ꗗ
						Case 5 : If .H_FLG_GEPPOU = "1" Then .H_FLG_GEPPOU = "0" Else .H_FLG_GEPPOU = "1" '�ύXFLG �H������ꗗ
						Case 6 : If .P_FLG_CHECK = "0" Then .P_FLG_CHECK = "1" Else .P_FLG_CHECK = "0" '���FLG ��ʕ���������ؽ�
						Case 7 : If .P_FLG_WARIDASI = "0" Then .P_FLG_WARIDASI = "1" Else .P_FLG_WARIDASI = "0" '���FLG ���c��O�����o���ꗗ
						Case 8 : If .P_FLG_DEKIDAKA = "0" Then .P_FLG_DEKIDAKA = "1" Else .P_FLG_DEKIDAKA = "0" '���FLG �O���o�����񍐏�
						Case 9 : If .P_FLG_IPPAN = "0" Then .P_FLG_IPPAN = "1" Else .P_FLG_IPPAN = "0" '���FLG ��ʕ��ꗗ
						Case 10 : If .P_FLG_GEPPOU = "0" Then .P_FLG_GEPPOU = "1" Else .P_FLG_GEPPOU = "0" '���FLG �H������
						Case 11 : If .R_FLG_GEPPOU = "0" Then .R_FLG_GEPPOU = "1" Else .R_FLG_GEPPOU = "0" '�A�gFLG ����f�[�^
						Case 12
							Select Case .R_FLG_TUKISIME '�A�gFLG ����
								Case "0" : .R_FLG_TUKISIME = "1"
								Case "1" : .R_FLG_TUKISIME = "2"
								Case "2" : .R_FLG_TUKISIME = "0"
							End Select
					End Select
				End With
				' �H�����i����j�y�؂̍X�V
				Jouken = "KOUJI_NO = '" & CtlKouji.KOUJI_NO & "' AND EDA_NO = '" & CtlKouji.EDA_NO & "'"
				If UPDATE_KOUJI_CTRL_D(Jouken, CtlKouji) = False Then
					Msg = "�H�����i����j���z�̍X�V�Ɏ��s���܂����B"
					'2021.09.14 UPGRADE S  AIT)dannnl
					'MsgBox(Msg, MsgBoxStyle.OkOnly + MsgBoxStyle.Information)
					MsgBox(Msg, MsgBoxStyle.OkOnly + MsgBoxStyle.Information, SYSTEMNM)
					'2021.09.14 UPGRADE E
					Exit Sub
				End If
				' ���j���[�̍ĕ\��
				Call DMenuRefresh()
				ClkPos = -1 : ClkCnt = 0
			End If
		End If

	End Sub
End Class
