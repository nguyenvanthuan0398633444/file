<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frmSYKD300
#Region "Windows Form Designer generated code "
	<System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
		MyBase.New()
        'This call is required by the Windows Form Designer.
        InitializeComponent()
        '2021.08.05 UPGRADE ADD  AIT)vyhnt
        cmdKey = New ArrayList()
        cmdKey.Add(Nothing)
        cmdKey.Add(_cmdKey_1)
        cmdKey.Add(_cmdKey_2)
        cmdKey.Add(_cmdKey_3)
        cmdKey.Add(_cmdKey_4)
        cmdKey.Add(_cmdKey_5)
        cmdKey.Add(_cmdKey_6)
        cmdKey.Add(_cmdKey_7)
        cmdKey.Add(_cmdKey_8)
        cmdKey.Add(_cmdKey_9)
        cmdKey.Add(_cmdKey_10)
        cmdKey.Add(_cmdKey_11)
        cmdKey.Add(_cmdKey_12)
        '2021.08.05  UPGRADE S  AIT)***   
    End Sub
	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer
	Public ToolTip1 As System.Windows.Forms.ToolTip
	Public WithEvents Command1 As System.Windows.Forms.Button
	Public WithEvents Picture2 As System.Windows.Forms.Panel
	Public WithEvents _cmdKey_5 As System.Windows.Forms.Button
	Public WithEvents _cmdKey_2 As System.Windows.Forms.Button
	Public WithEvents _cmdKey_11 As System.Windows.Forms.Button
	Public WithEvents _cmdKey_1 As System.Windows.Forms.Button
	Public WithEvents _cmdKey_9 As System.Windows.Forms.Button
	Public WithEvents _cmdKey_8 As System.Windows.Forms.Button
	Public WithEvents _cmdKey_7 As System.Windows.Forms.Button
	Public WithEvents _cmdKey_6 As System.Windows.Forms.Button
	Public WithEvents _cmdKey_10 As System.Windows.Forms.Button
	Public WithEvents _cmdKey_4 As System.Windows.Forms.Button
	Public WithEvents _cmdKey_12 As System.Windows.Forms.Button
	Public WithEvents _cmdKey_3 As System.Windows.Forms.Button
	Public WithEvents Picture1 As System.Windows.Forms.Panel
	Public WithEvents Message As System.Windows.Forms.ToolStripStatusLabel
    Public WithEvents _StatusBar1_Panel2 As System.Windows.Forms.ToolStripStatusLabel
    Public WithEvents StatusBar1 As System.Windows.Forms.StatusStrip
	'2021.08.02 UPGRADE S  AIT)vyhnt
	'Public WithEvents vaSpread1 As AxFPSpread.AxvaSpread
	Public WithEvents vaSpread1 As FarPoint.Win.Spread.FpSpread
	'2021.08.02 UPGRADE E     
	Public WithEvents lblTitle As System.Windows.Forms.Label
	'2021.08.02 UPGRADE S  AIT)vyhnt
	'Public WithEvents cmdKey As Microsoft.VisualBasic.Compatibility.VB6.ButtonArray
	Public WithEvents cmdKey As ArrayList
	'2021.08.02 UPGRADE E

	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim CustomSpdHeader As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim CustomSpdHeader1 As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim DefaultFocusIndicatorRenderer1 As FarPoint.Win.Spread.DefaultFocusIndicatorRenderer = New FarPoint.Win.Spread.DefaultFocusIndicatorRenderer()
        Dim DefaultScrollBarRenderer1 As FarPoint.Win.Spread.DefaultScrollBarRenderer = New FarPoint.Win.Spread.DefaultScrollBarRenderer()
        Dim NamedStyle1 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("Color65637635197252586075")
        Dim NamedStyle2 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("Font193637635197252586075")
        Dim NamedStyle3 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("Color633637635197252606109")
        Dim TipAppearance1 As FarPoint.Win.Spread.TipAppearance = New FarPoint.Win.Spread.TipAppearance()
        Dim DefaultScrollBarRenderer2 As FarPoint.Win.Spread.DefaultScrollBarRenderer = New FarPoint.Win.Spread.DefaultScrollBarRenderer()
        Dim TextCellType1 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType()
        Dim ComplexBorder1 As FarPoint.Win.ComplexBorder = New FarPoint.Win.ComplexBorder(New FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThinLine))
        Dim CheckBoxCellType1 As FarPoint.Win.Spread.CellType.CheckBoxCellType = New FarPoint.Win.Spread.CellType.CheckBoxCellType()
        Dim TextCellType2 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType()
        Dim TextCellType3 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType()
        Dim TextCellType4 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmSYKD300))
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.Picture2 = New System.Windows.Forms.Panel()
        Me.Command1 = New System.Windows.Forms.Button()
        Me.Picture1 = New System.Windows.Forms.Panel()
        Me._cmdKey_5 = New System.Windows.Forms.Button()
        Me._cmdKey_2 = New System.Windows.Forms.Button()
        Me._cmdKey_11 = New System.Windows.Forms.Button()
        Me._cmdKey_1 = New System.Windows.Forms.Button()
        Me._cmdKey_9 = New System.Windows.Forms.Button()
        Me._cmdKey_8 = New System.Windows.Forms.Button()
        Me._cmdKey_7 = New System.Windows.Forms.Button()
        Me._cmdKey_6 = New System.Windows.Forms.Button()
        Me._cmdKey_10 = New System.Windows.Forms.Button()
        Me._cmdKey_4 = New System.Windows.Forms.Button()
        Me._cmdKey_12 = New System.Windows.Forms.Button()
        Me._cmdKey_3 = New System.Windows.Forms.Button()
        Me.StatusBar1 = New System.Windows.Forms.StatusStrip()
        Me._StatusBar1_Panel2 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.Message = New System.Windows.Forms.ToolStripStatusLabel()
        Me.vaSpread1 = New FarPoint.Win.Spread.FpSpread()
        Me.vaSpread1_Sheet1 = New FarPoint.Win.Spread.SheetView()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.Picture2.SuspendLayout()
        Me.Picture1.SuspendLayout()
        Me.StatusBar1.SuspendLayout()
        CType(Me.vaSpread1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.vaSpread1_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        CustomSpdHeader.Name = "CustomSpdHeader"
        CustomSpdHeader.PictureZoomEffect = False
        CustomSpdHeader.TextRotationAngle = 0R
        CustomSpdHeader.ZoomFactor = 1.0!
        CustomSpdHeader1.Name = "CustomSpdHeader1"
        CustomSpdHeader1.PictureZoomEffect = False
        CustomSpdHeader1.TextRotationAngle = 0R
        CustomSpdHeader1.ZoomFactor = 1.0!
        '
        'Picture2
        '
        Me.Picture2.BackColor = System.Drawing.SystemColors.Control
        Me.Picture2.Controls.Add(Me.Command1)
        Me.Picture2.Cursor = System.Windows.Forms.Cursors.Default
        Me.Picture2.Enabled = False
        Me.Picture2.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Picture2.Location = New System.Drawing.Point(642, 36)
        Me.Picture2.Name = "Picture2"
        Me.Picture2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Picture2.Size = New System.Drawing.Size(371, 53)
        Me.Picture2.TabIndex = 16
        Me.Picture2.Visible = False
        '
        'Command1
        '
        Me.Command1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Command1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Command1.Font = New System.Drawing.Font("MS Mincho", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Command1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Command1.Location = New System.Drawing.Point(3, -3)
        Me.Command1.Name = "Command1"
        Me.Command1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Command1.Size = New System.Drawing.Size(371, 53)
        Me.Command1.TabIndex = 17
        Me.Command1.TabStop = False
        Me.Command1.Text = "�f�[�^�̓]�������     "
        Me.Command1.UseVisualStyleBackColor = False
        '
        'Picture1
        '
        Me.Picture1.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Picture1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Picture1.Controls.Add(Me._cmdKey_5)
        Me.Picture1.Controls.Add(Me._cmdKey_2)
        Me.Picture1.Controls.Add(Me._cmdKey_11)
        Me.Picture1.Controls.Add(Me._cmdKey_1)
        Me.Picture1.Controls.Add(Me._cmdKey_9)
        Me.Picture1.Controls.Add(Me._cmdKey_8)
        Me.Picture1.Controls.Add(Me._cmdKey_7)
        Me.Picture1.Controls.Add(Me._cmdKey_6)
        Me.Picture1.Controls.Add(Me._cmdKey_10)
        Me.Picture1.Controls.Add(Me._cmdKey_4)
        Me.Picture1.Controls.Add(Me._cmdKey_12)
        Me.Picture1.Controls.Add(Me._cmdKey_3)
        Me.Picture1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Picture1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Picture1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Picture1.Location = New System.Drawing.Point(0, 668)
        Me.Picture1.Name = "Picture1"
        Me.Picture1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Picture1.Size = New System.Drawing.Size(1016, 51)
        Me.Picture1.TabIndex = 13
        '
        '_cmdKey_5
        '
        Me._cmdKey_5.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_5.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_5.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_5.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_5.Location = New System.Drawing.Point(348, 4)
        Me._cmdKey_5.Name = "_cmdKey_5"
        Me._cmdKey_5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_5.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_5.TabIndex = 4
        Me._cmdKey_5.Tag = "�f�[�^���󂯎��܂��B"
        Me._cmdKey_5.Text = "F5" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "�� ��"
        Me._cmdKey_5.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_5.UseVisualStyleBackColor = False
        '
        '_cmdKey_2
        '
        Me._cmdKey_2.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_2.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_2.Enabled = False
        Me._cmdKey_2.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_2.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_2.Location = New System.Drawing.Point(86, 4)
        Me._cmdKey_2.Name = "_cmdKey_2"
        Me._cmdKey_2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_2.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_2.TabIndex = 1
        Me._cmdKey_2.Text = "F2"
        Me._cmdKey_2.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_2.UseVisualStyleBackColor = False
        '
        '_cmdKey_11
        '
        Me._cmdKey_11.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_11.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_11.Enabled = False
        Me._cmdKey_11.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_11.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_11.Location = New System.Drawing.Point(849, 4)
        Me._cmdKey_11.Name = "_cmdKey_11"
        Me._cmdKey_11.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_11.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_11.TabIndex = 10
        Me._cmdKey_11.Text = "F11"
        Me._cmdKey_11.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_11.UseVisualStyleBackColor = False
        '
        '_cmdKey_1
        '
        Me._cmdKey_1.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_1.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_1.Enabled = False
        Me._cmdKey_1.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_1.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_1.Location = New System.Drawing.Point(6, 4)
        Me._cmdKey_1.Name = "_cmdKey_1"
        Me._cmdKey_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_1.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_1.TabIndex = 0
        Me._cmdKey_1.Text = "F1"
        Me._cmdKey_1.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_1.UseVisualStyleBackColor = False
        '
        '_cmdKey_9
        '
        Me._cmdKey_9.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_9.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_9.Enabled = False
        Me._cmdKey_9.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_9.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_9.Location = New System.Drawing.Point(689, 4)
        Me._cmdKey_9.Name = "_cmdKey_9"
        Me._cmdKey_9.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_9.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_9.TabIndex = 8
        Me._cmdKey_9.Text = "F9"
        Me._cmdKey_9.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_9.UseVisualStyleBackColor = False
        '
        '_cmdKey_8
        '
        Me._cmdKey_8.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_8.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_8.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_8.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_8.Location = New System.Drawing.Point(588, 4)
        Me._cmdKey_8.Name = "_cmdKey_8"
        Me._cmdKey_8.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_8.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_8.TabIndex = 7
        Me._cmdKey_8.Tag = "�e�c������͂��܂��B"
        Me._cmdKey_8.Text = "F8" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "�e�c����"
        Me._cmdKey_8.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_8.UseVisualStyleBackColor = False
        '
        '_cmdKey_7
        '
        Me._cmdKey_7.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_7.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_7.Enabled = False
        Me._cmdKey_7.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_7.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_7.Location = New System.Drawing.Point(508, 4)
        Me._cmdKey_7.Name = "_cmdKey_7"
        Me._cmdKey_7.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_7.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_7.TabIndex = 6
        Me._cmdKey_7.Text = "F7"
        Me._cmdKey_7.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_7.UseVisualStyleBackColor = False
        '
        '_cmdKey_6
        '
        Me._cmdKey_6.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_6.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_6.Enabled = False
        Me._cmdKey_6.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_6.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_6.Location = New System.Drawing.Point(428, 4)
        Me._cmdKey_6.Name = "_cmdKey_6"
        Me._cmdKey_6.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_6.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_6.TabIndex = 5
        Me._cmdKey_6.Text = "F6"
        Me._cmdKey_6.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_6.UseVisualStyleBackColor = False
        '
        '_cmdKey_10
        '
        Me._cmdKey_10.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_10.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_10.Enabled = False
        Me._cmdKey_10.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_10.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_10.Location = New System.Drawing.Point(769, 4)
        Me._cmdKey_10.Name = "_cmdKey_10"
        Me._cmdKey_10.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_10.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_10.TabIndex = 9
        Me._cmdKey_10.Text = "F10"
        Me._cmdKey_10.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_10.UseVisualStyleBackColor = False
        '
        '_cmdKey_4
        '
        Me._cmdKey_4.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_4.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_4.Enabled = False
        Me._cmdKey_4.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_4.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_4.Location = New System.Drawing.Point(246, 4)
        Me._cmdKey_4.Name = "_cmdKey_4"
        Me._cmdKey_4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_4.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_4.TabIndex = 3
        Me._cmdKey_4.Text = "F4"
        Me._cmdKey_4.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_4.UseVisualStyleBackColor = False
        '
        '_cmdKey_12
        '
        Me._cmdKey_12.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_12.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_12.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_12.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_12.Location = New System.Drawing.Point(929, 4)
        Me._cmdKey_12.Name = "_cmdKey_12"
        Me._cmdKey_12.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_12.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_12.TabIndex = 11
        Me._cmdKey_12.Tag = "�������I�����܂��B"
        Me._cmdKey_12.Text = "F12" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "�I ��"
        Me._cmdKey_12.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_12.UseVisualStyleBackColor = False
        '
        '_cmdKey_3
        '
        Me._cmdKey_3.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_3.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_3.Enabled = False
        Me._cmdKey_3.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_3.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_3.Location = New System.Drawing.Point(166, 4)
        Me._cmdKey_3.Name = "_cmdKey_3"
        Me._cmdKey_3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_3.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_3.TabIndex = 2
        Me._cmdKey_3.Text = "F3"
        Me._cmdKey_3.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me._cmdKey_3.UseVisualStyleBackColor = False
        '
        'StatusBar1
        '
        Me.StatusBar1.Font = New System.Drawing.Font("MS Mincho", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.StatusBar1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me._StatusBar1_Panel2, Me.Message})
        Me.StatusBar1.Location = New System.Drawing.Point(0, 719)
        Me.StatusBar1.Name = "StatusBar1"
        Me.StatusBar1.Size = New System.Drawing.Size(1016, 23)
        Me.StatusBar1.SizingGrip = False
        Me.StatusBar1.TabIndex = 12
        '
        '_StatusBar1_Panel2
        '
        Me._StatusBar1_Panel2.AutoSize = False
        Me._StatusBar1_Panel2.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me._StatusBar1_Panel2.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter
        Me._StatusBar1_Panel2.Margin = New System.Windows.Forms.Padding(0)
        Me._StatusBar1_Panel2.Name = "_StatusBar1_Panel2"
        Me._StatusBar1_Panel2.Size = New System.Drawing.Size(117, 23)
        Me._StatusBar1_Panel2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Message
        '
        Me.Message.AutoSize = False
        Me.Message.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me.Message.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter
        Me.Message.Margin = New System.Windows.Forms.Padding(0)
        Me.Message.Name = "Message"
        Me.Message.Size = New System.Drawing.Size(902, 23)
        Me.Message.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'vaSpread1
        '
        Me.vaSpread1.AccessibleDescription = "vaSpread1, Sheet1, Row 0, Column 0"
        Me.vaSpread1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.vaSpread1.FocusRenderer = DefaultFocusIndicatorRenderer1
        Me.vaSpread1.HorizontalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.vaSpread1.HorizontalScrollBar.Name = ""
        Me.vaSpread1.HorizontalScrollBar.Renderer = DefaultScrollBarRenderer1
        Me.vaSpread1.HorizontalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.Never
        Me.vaSpread1.Location = New System.Drawing.Point(62, 78)
        Me.vaSpread1.Name = "vaSpread1"
        NamedStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        NamedStyle1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        NamedStyle1.Locked = False
        NamedStyle2.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        NamedStyle2.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold)
        NamedStyle2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        NamedStyle2.Locked = False
        NamedStyle3.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        NamedStyle3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.vaSpread1.RowSplitBoxAlignment = FarPoint.Win.Spread.SplitBoxAlignment.Trailing
        Me.vaSpread1.RowSplitBoxPolicy = FarPoint.Win.Spread.SplitBoxPolicy.Never
        Me.vaSpread1.ScrollBarTrackPolicy = FarPoint.Win.Spread.ScrollBarTrackPolicy.Vertical
        Me.vaSpread1.SelectionBlockOptions = FarPoint.Win.Spread.SelectionBlockOptions.Rows
        Me.vaSpread1.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.vaSpread1_Sheet1})
        Me.vaSpread1.Size = New System.Drawing.Size(733, 553)
        Me.vaSpread1.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Classic
        Me.vaSpread1.NamedStyles.AddRange(New FarPoint.Win.Spread.NamedStyle() {NamedStyle1, NamedStyle2, NamedStyle3})
        Me.vaSpread1.TabIndex = 15
        Me.vaSpread1.Tag = "�f�[�^��I�����ĉ������B"
        TipAppearance1.BackColor = System.Drawing.SystemColors.Info
        TipAppearance1.Font = New System.Drawing.Font("MS PGothic", 9.0!)
        TipAppearance1.ForeColor = System.Drawing.SystemColors.InfoText
        Me.vaSpread1.TextTipAppearance = TipAppearance1
        Me.vaSpread1.VerticalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.vaSpread1.VerticalScrollBar.Name = ""
        Me.vaSpread1.VerticalScrollBar.Renderer = DefaultScrollBarRenderer2
        Me.vaSpread1.VerticalScrollBarWidth = 20
        Me.vaSpread1.VisualStyles = FarPoint.Win.VisualStyles.Off
        '
        'vaSpread1_Sheet1
        '
        Me.vaSpread1_Sheet1.Reset()
        Me.vaSpread1_Sheet1.SheetName = "Sheet1"
        'Formulas and custom names must be loaded with R1C1 reference style
        Me.vaSpread1_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1
        Me.vaSpread1_Sheet1.ColumnCount = 6
        Me.vaSpread1_Sheet1.RowCount = 100
        Me.vaSpread1_Sheet1.ActiveSkin = FarPoint.Win.Spread.DefaultSkins.Default
        Me.vaSpread1_Sheet1.Cells.Get(0, 0).Value = 0
        Me.vaSpread1_Sheet1.Cells.Get(0, 1).Value = "00000001"
        Me.vaSpread1_Sheet1.Cells.Get(0, 2).Value = "0000"
        TextCellType1.Static = True
        Me.vaSpread1_Sheet1.Cells.Get(0, 3).CellType = TextCellType1
        Me.vaSpread1_Sheet1.Cells.Get(0, 3).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Left
        Me.vaSpread1_Sheet1.Cells.Get(0, 3).Value = "�P�Q�R�S�T�U�V�W�X�O�P�Q�R�S�T�U�V�W�X�O"
        Me.vaSpread1_Sheet1.Cells.Get(0, 3).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.vaSpread1_Sheet1.Cells.Get(0, 4).Value = "���z����"
        Me.vaSpread1_Sheet1.Cells.Get(0, 5).Value = "�m��"
        Me.vaSpread1_Sheet1.Cells.Get(1, 1).Value = "00000002"
        Me.vaSpread1_Sheet1.Cells.Get(1, 3).CellType = TextCellType1
        Me.vaSpread1_Sheet1.Cells.Get(1, 3).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Left
        Me.vaSpread1_Sheet1.Cells.Get(1, 3).Value = "1234567890123456789012345678901234567890"
        Me.vaSpread1_Sheet1.Cells.Get(1, 3).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.vaSpread1_Sheet1.Cells.Get(2, 1).Value = "00000003"
        Me.vaSpread1_Sheet1.Cells.Get(2, 3).Value = "���O�O�O�R"
        Me.vaSpread1_Sheet1.Cells.Get(3, 1).Value = "00000004"
        Me.vaSpread1_Sheet1.Cells.Get(3, 3).Value = "���O�O�O�S"
        Me.vaSpread1_Sheet1.Cells.Get(4, 1).Value = "00000005"
        Me.vaSpread1_Sheet1.Cells.Get(4, 3).Value = "���O�O�O�T"
        Me.vaSpread1_Sheet1.Cells.Get(5, 1).Value = "00000006"
        Me.vaSpread1_Sheet1.Cells.Get(5, 3).Value = "���O�O�O�U"
        Me.vaSpread1_Sheet1.Cells.Get(6, 1).Value = "00000007"
        Me.vaSpread1_Sheet1.Cells.Get(6, 3).Value = "���O�O�O�V"
        Me.vaSpread1_Sheet1.Cells.Get(7, 1).Value = "00000008"
        Me.vaSpread1_Sheet1.Cells.Get(7, 3).Value = "���O�O�O�W"
        Me.vaSpread1_Sheet1.Cells.Get(8, 1).Value = "00000009"
        Me.vaSpread1_Sheet1.Cells.Get(8, 3).Value = "���O�O�O�X"
        Me.vaSpread1_Sheet1.Cells.Get(9, 1).Value = "00000010"
        Me.vaSpread1_Sheet1.Cells.Get(9, 3).Value = "���O�O�P�O"
        Me.vaSpread1_Sheet1.Cells.Get(10, 1).Value = "00000011"
        Me.vaSpread1_Sheet1.Cells.Get(10, 3).Value = "���O�O�P�P"
        Me.vaSpread1_Sheet1.Cells.Get(11, 1).Value = "00000012"
        Me.vaSpread1_Sheet1.Cells.Get(11, 3).Value = "���O�O�P�Q"
        Me.vaSpread1_Sheet1.Cells.Get(12, 1).Value = "00000013"
        Me.vaSpread1_Sheet1.Cells.Get(12, 3).Value = "���O�O�P�R"
        Me.vaSpread1_Sheet1.Cells.Get(13, 1).Value = "00000014"
        Me.vaSpread1_Sheet1.Cells.Get(13, 3).Value = "���O�O�P�S"
        Me.vaSpread1_Sheet1.Cells.Get(14, 1).Value = "00000015"
        Me.vaSpread1_Sheet1.Cells.Get(14, 3).Value = "���O�O�P�T"
        Me.vaSpread1_Sheet1.Cells.Get(15, 1).Value = "00000016"
        Me.vaSpread1_Sheet1.Cells.Get(15, 3).Value = "���O�O�P�U"
        Me.vaSpread1_Sheet1.Cells.Get(16, 1).Value = "00000017"
        Me.vaSpread1_Sheet1.Cells.Get(16, 3).Value = "���O�O�P�V"
        Me.vaSpread1_Sheet1.Cells.Get(17, 1).Value = "00000018"
        Me.vaSpread1_Sheet1.Cells.Get(17, 3).Value = "���O�O�P�W"
        Me.vaSpread1_Sheet1.Cells.Get(18, 1).Value = "00000019"
        Me.vaSpread1_Sheet1.Cells.Get(18, 3).Value = "���O�O�P�X"
        Me.vaSpread1_Sheet1.Cells.Get(19, 1).Value = "00000020"
        Me.vaSpread1_Sheet1.Cells.Get(19, 3).Value = "���O�O�Q�O"
        Me.vaSpread1_Sheet1.Cells.Get(20, 1).Value = "00000021"
        Me.vaSpread1_Sheet1.Cells.Get(20, 3).Value = "���O�O�Q�P"
        Me.vaSpread1_Sheet1.Cells.Get(21, 1).Value = "00000022"
        Me.vaSpread1_Sheet1.Cells.Get(21, 3).Value = "���O�O�Q�Q"
        Me.vaSpread1_Sheet1.Cells.Get(22, 1).Value = "00000023"
        Me.vaSpread1_Sheet1.Cells.Get(22, 3).Value = "���O�O�Q�R"
        Me.vaSpread1_Sheet1.Cells.Get(23, 1).Value = "00000024"
        Me.vaSpread1_Sheet1.Cells.Get(23, 3).Value = "���O�O�Q�S"
        Me.vaSpread1_Sheet1.Cells.Get(24, 1).Value = "00000025"
        Me.vaSpread1_Sheet1.Cells.Get(24, 3).Value = "���O�O�Q�T"
        Me.vaSpread1_Sheet1.ColumnFooter.Columns.Default.Resizable = False
        Me.vaSpread1_Sheet1.ColumnFooter.Columns.Default.SortIndicator = FarPoint.Win.Spread.Model.SortIndicator.None
        Me.vaSpread1_Sheet1.ColumnFooter.Columns.Default.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.vaSpread1_Sheet1.ColumnFooter.DefaultStyle.BackColor = System.Drawing.Color.Empty
        Me.vaSpread1_Sheet1.ColumnFooter.DefaultStyle.ForeColor = System.Drawing.Color.Empty
        Me.vaSpread1_Sheet1.ColumnFooter.DefaultStyle.Locked = False
        Me.vaSpread1_Sheet1.ColumnFooter.DefaultStyle.Parent = "HeaderDefault"
        Me.vaSpread1_Sheet1.ColumnFooter.DefaultStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.vaSpread1_Sheet1.ColumnFooter.Rows.Default.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.vaSpread1_Sheet1.ColumnFooterSheetCornerStyle.BackColor = System.Drawing.Color.Empty
        Me.vaSpread1_Sheet1.ColumnFooterSheetCornerStyle.ForeColor = System.Drawing.Color.Empty
        Me.vaSpread1_Sheet1.ColumnFooterSheetCornerStyle.Locked = False
        Me.vaSpread1_Sheet1.ColumnFooterSheetCornerStyle.Parent = "RowHeaderDefault"
        Me.vaSpread1_Sheet1.ColumnFooterSheetCornerStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.vaSpread1_Sheet1.ColumnHeader.AutoText = FarPoint.Win.Spread.HeaderAutoText.Blank
        Me.vaSpread1_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = "�H���ԍ�"
        Me.vaSpread1_Sheet1.ColumnHeader.Cells.Get(0, 3).Value = "�H�@�@���@�@��"
        Me.vaSpread1_Sheet1.ColumnHeader.Cells.Get(0, 4).Value = "�H���敪"
        Me.vaSpread1_Sheet1.ColumnHeader.Cells.Get(0, 5).Value = "���"
        Me.vaSpread1_Sheet1.ColumnHeader.Columns.Default.Resizable = False
        Me.vaSpread1_Sheet1.ColumnHeader.Columns.Default.SortIndicator = FarPoint.Win.Spread.Model.SortIndicator.None
        Me.vaSpread1_Sheet1.ColumnHeader.Columns.Default.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.vaSpread1_Sheet1.ColumnHeader.DefaultStyle.BackColor = System.Drawing.Color.Empty
        Me.vaSpread1_Sheet1.ColumnHeader.DefaultStyle.Border = ComplexBorder1
        Me.vaSpread1_Sheet1.ColumnHeader.DefaultStyle.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.vaSpread1_Sheet1.ColumnHeader.DefaultStyle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.vaSpread1_Sheet1.ColumnHeader.DefaultStyle.Locked = False
        Me.vaSpread1_Sheet1.ColumnHeader.DefaultStyle.LockFont = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.vaSpread1_Sheet1.ColumnHeader.DefaultStyle.Parent = "HeaderDefault"
        Me.vaSpread1_Sheet1.ColumnHeader.DefaultStyle.Renderer = CustomSpdHeader1
        Me.vaSpread1_Sheet1.ColumnHeader.DefaultStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.vaSpread1_Sheet1.ColumnHeader.Rows.Default.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.vaSpread1_Sheet1.ColumnHeader.Rows.Get(0).Height = 26.0!
        Me.vaSpread1_Sheet1.Columns.Default.Resizable = False
        Me.vaSpread1_Sheet1.Columns.Default.SortIndicator = FarPoint.Win.Spread.Model.SortIndicator.None
        Me.vaSpread1_Sheet1.Columns.Get(0).BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        CheckBoxCellType1.TextFalse = "0"
        CheckBoxCellType1.TextTrue = "1"
        CheckBoxCellType1.ThreeState = True
        Me.vaSpread1_Sheet1.Columns.Get(0).CellType = CheckBoxCellType1
        Me.vaSpread1_Sheet1.Columns.Get(0).ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.vaSpread1_Sheet1.Columns.Get(0).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.vaSpread1_Sheet1.Columns.Get(0).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.vaSpread1_Sheet1.Columns.Get(0).Width = 20.0!
        TextCellType2.Static = True
        Me.vaSpread1_Sheet1.Columns.Get(1).CellType = TextCellType2
        Me.vaSpread1_Sheet1.Columns.Get(1).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.vaSpread1_Sheet1.Columns.Get(1).Label = "�H���ԍ�"
        Me.vaSpread1_Sheet1.Columns.Get(1).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.vaSpread1_Sheet1.Columns.Get(1).Width = 86.0!
        Me.vaSpread1_Sheet1.Columns.Get(2).CellType = TextCellType2
        Me.vaSpread1_Sheet1.Columns.Get(2).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.vaSpread1_Sheet1.Columns.Get(2).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.vaSpread1_Sheet1.Columns.Get(2).Width = 49.0!
        Me.vaSpread1_Sheet1.Columns.Get(3).CellType = TextCellType1
        Me.vaSpread1_Sheet1.Columns.Get(3).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Left
        Me.vaSpread1_Sheet1.Columns.Get(3).Label = "�H�@�@���@�@��"
        Me.vaSpread1_Sheet1.Columns.Get(3).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.vaSpread1_Sheet1.Columns.Get(3).Width = 370.0!
        Me.vaSpread1_Sheet1.Columns.Get(4).CellType = TextCellType2
        Me.vaSpread1_Sheet1.Columns.Get(4).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.vaSpread1_Sheet1.Columns.Get(4).Label = "�H���敪"
        Me.vaSpread1_Sheet1.Columns.Get(4).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.vaSpread1_Sheet1.Columns.Get(4).Width = 80.0!
        Me.vaSpread1_Sheet1.Columns.Get(5).CellType = TextCellType2
        Me.vaSpread1_Sheet1.Columns.Get(5).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.vaSpread1_Sheet1.Columns.Get(5).Label = "���"
        Me.vaSpread1_Sheet1.Columns.Get(5).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.vaSpread1_Sheet1.Columns.Get(5).Width = 61.0!
        Me.vaSpread1_Sheet1.DefaultStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        TextCellType3.MaxLength = 60
        Me.vaSpread1_Sheet1.DefaultStyle.CellType = TextCellType3
        Me.vaSpread1_Sheet1.DefaultStyle.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold)
        Me.vaSpread1_Sheet1.DefaultStyle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.vaSpread1_Sheet1.DefaultStyle.Locked = False
        Me.vaSpread1_Sheet1.DefaultStyle.Parent = "DataAreaDefault"
        Me.vaSpread1_Sheet1.DefaultStyle.Renderer = TextCellType3
        Me.vaSpread1_Sheet1.FilterBar.DefaultStyle.BackColor = System.Drawing.Color.Empty
        Me.vaSpread1_Sheet1.FilterBar.DefaultStyle.ForeColor = System.Drawing.Color.Empty
        Me.vaSpread1_Sheet1.FilterBar.DefaultStyle.Locked = False
        Me.vaSpread1_Sheet1.FilterBar.DefaultStyle.Parent = "FilterBarDefault"
        Me.vaSpread1_Sheet1.FilterBar.DefaultStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.vaSpread1_Sheet1.FilterBarHeaderStyle.BackColor = System.Drawing.Color.Empty
        Me.vaSpread1_Sheet1.FilterBarHeaderStyle.ForeColor = System.Drawing.Color.Empty
        Me.vaSpread1_Sheet1.FilterBarHeaderStyle.Locked = False
        Me.vaSpread1_Sheet1.FilterBarHeaderStyle.Parent = "RowHeaderDefault"
        Me.vaSpread1_Sheet1.FilterBarHeaderStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.vaSpread1_Sheet1.HorizontalGridLine = New FarPoint.Win.Spread.GridLine(FarPoint.Win.Spread.GridLineType.Flat, System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer)))
        Me.vaSpread1_Sheet1.OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        Me.vaSpread1_Sheet1.Protect = True
        Me.vaSpread1_Sheet1.RowHeader.Columns.Default.Resizable = False
        Me.vaSpread1_Sheet1.RowHeader.Columns.Default.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.vaSpread1_Sheet1.RowHeader.Columns.Get(0).Width = 44.0!
        Me.vaSpread1_Sheet1.RowHeader.DefaultStyle.BackColor = System.Drawing.Color.Empty
        Me.vaSpread1_Sheet1.RowHeader.DefaultStyle.Border = ComplexBorder1
        Me.vaSpread1_Sheet1.RowHeader.DefaultStyle.CellType = TextCellType4
        Me.vaSpread1_Sheet1.RowHeader.DefaultStyle.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.vaSpread1_Sheet1.RowHeader.DefaultStyle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.vaSpread1_Sheet1.RowHeader.DefaultStyle.Locked = False
        Me.vaSpread1_Sheet1.RowHeader.DefaultStyle.LockFont = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.vaSpread1_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderDefault"
        Me.vaSpread1_Sheet1.RowHeader.DefaultStyle.Renderer = TextCellType4
        Me.vaSpread1_Sheet1.RowHeader.DefaultStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.vaSpread1_Sheet1.RowHeader.Rows.Default.Resizable = False
        Me.vaSpread1_Sheet1.RowHeader.Rows.Default.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.vaSpread1_Sheet1.Rows.Default.Resizable = False
        Me.vaSpread1_Sheet1.SelectionUnit = FarPoint.Win.Spread.Model.SelectionUnit.Row
        Me.vaSpread1_Sheet1.SheetCornerStyle.BackColor = System.Drawing.Color.Empty
        Me.vaSpread1_Sheet1.SheetCornerStyle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.vaSpread1_Sheet1.SheetCornerStyle.Locked = False
        Me.vaSpread1_Sheet1.SheetCornerStyle.Parent = "RowHeaderDefault"
        Me.vaSpread1_Sheet1.SheetCornerStyle.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.vaSpread1_Sheet1.SheetCornerStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.vaSpread1_Sheet1.VerticalGridLine = New FarPoint.Win.Spread.GridLine(FarPoint.Win.Spread.GridLineType.Flat, System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer)))
        Me.vaSpread1_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1
        '
        'lblTitle
        '
        Me.lblTitle.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblTitle.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTitle.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblTitle.Font = New System.Drawing.Font("MS Mincho", 20.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblTitle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.lblTitle.Location = New System.Drawing.Point(0, 0)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblTitle.Size = New System.Drawing.Size(1015, 33)
        Me.lblTitle.TabIndex = 14
        Me.lblTitle.Text = " ��M�f�[�^�ꗗ"
        '
        'frmSYKD300
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(1016, 742)
        Me.Controls.Add(Me.Picture2)
        Me.Controls.Add(Me.Picture1)
        Me.Controls.Add(Me.StatusBar1)
        Me.Controls.Add(Me.vaSpread1)
        Me.Controls.Add(Me.lblTitle)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.KeyPreview = True
        Me.Location = New System.Drawing.Point(4, 23)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmSYKD300"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "�H���Ǘ��V�X�e��"
        Me.Picture2.ResumeLayout(False)
        Me.Picture1.ResumeLayout(False)
        Me.StatusBar1.ResumeLayout(False)
        Me.StatusBar1.PerformLayout()
        CType(Me.vaSpread1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.vaSpread1_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents vaSpread1_Sheet1 As FarPoint.Win.Spread.SheetView
#End Region
End Class