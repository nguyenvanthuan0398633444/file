Option Strict Off
Option Explicit On
Friend Class frmWaridasi
	Inherits System.Windows.Forms.Form
	'=============================================================
	' ���[�U�[���@  �F  �Ђ났��L���b�V���T�[�r�X
	' �V�X�e�����@  �F  �Ɩ��V�X�e��
	' ���W���[����  �F  ��񌟍�
	' ���W���[��ID�@�F  frmWaridasi.frm
	' �쐬���@ �@�@ �F  ���� 13 �N 06 �� 29 ��
	' �X�V���@�@  �@�F  ����    �N    ��    ��
	'=============================================================
	'
	
	'��ʕ\���p�\����
	Private Structure DspList
		Dim Mesyo As String
		Dim Bango As String
		Dim Yobi1 As String
		Dim Yobi2 As String
		Dim Yobi3 As String
		Dim Yobi4 As String
	End Structure

	'2021.08.04 UPGRADE S  AIT)Hoangtx
	'Public ZENTEI As String ' �O�񌟍�����
	'Public GetNO As String ' �I��ԍ�
	'Public GetNM As String ' �I�𖼏�
	Public Shared ZENTEI As String ' �O�񌟍�����
	Public Shared GetNO As String ' �I��ԍ�
	Public Shared GetNM As String ' �I�𖼏�
	'2021.08.04 UPGRADE E
	Private SortMode(1) As Short ' ���� Or �~��
	'

	'-------------------------------------------------------------------------------
	'   ����    :   ��ʃN���A
	'   �֐�    :   Sub DispClear()
	'   ����    :   ����
	'   �@�\    :   ��ʂ��N���A���܂��B
	'-------------------------------------------------------------------------------
	Private Sub DispClear()
		SortMode(0) = -1
		SortMode(1) = -1

		'2021.08.04 UPGRADE S  AIT)Hoangtx
		'vaSpread1.MaxRows = 0
		FpSpread1.ActiveSheet.RowCount = 0
		'vaSpread1.set_SortKey(1, 1)
		FpSpread1.ActiveSheet.SetColumnAutoSortIndex(0, 0)
		'2021.08.04 UPGRADE E
		cmdKey(1).Enabled = False
	End Sub

	'-------------------------------------------------------------------------------
	'   ����    :   �������ʕ\��
	'   �֐�    :   Function FormFirstSet()
	'   ����    :   ����
	'   �ߒl    :   True    �f�[�^����
	'   �@�@        False   �f�[�^�Ȃ�
	'   �@�\    :   InfoNo���e�}�X�^�̌������ʂ�\������B
	'-------------------------------------------------------------------------------
	Private Function FormFirstSet() As Boolean

		Dim lp As Short
		Dim Cnt As Short
		Dim DT() As DspList

		'��ʏ����ݒ�

		'2021.08.04 UPGRADE S  AIT)Hoangtx
		'FpSpread1.MaxRows = 0
		FpSpread1.ActiveSheet.RowCount = 0
		'2021.08.04 UPGRADE E
		cmdKey(1).Enabled = False

		ReDim DT(0)

		'----- ���o���̎擾
		Cnt = GetWaridasi(DT)
		If Cnt <= 0 Then
			If Me.Visible = True Then
				MsgBox("�Y���f�[�^���P��������܂���", MsgBoxStyle.OkOnly, "����")
			End If
			FormFirstSet = False
			Exit Function
		End If

		'2021.08.04 UPGRADE S  AIT)Hoangtx
		'vaSpread1.ReDraw = False
		'vaSpread1.MaxRows = Cnt
		FpSpread1.ResumeLayout(False)
		FpSpread1.ActiveSheet.RowCount = Cnt
		'2021.08.04 UPGRADE E

		cmdKey(1).Enabled = True

		'�f�[�^�\��
		With FpSpread1
			For lp = 1 To Cnt

				'2021.08.04 UPGRADE S  AIT)Hoangtx
				'.Col = 1 : .Col2 = .MaxCols
				'.Row = lp : .Row2 = lp
				'.set_RowHeight(lp, 15.0#)
				'.BlockMode = True
				.ActiveSheet.SetRowHeight(lp - 1, 21)
				.ActiveSheet.OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
				.ActiveSheet.AddSelection(0, 0, 1, 1)
				'2021.08.04 UPGRADE E

				'2021.07.26 UPGRADE S  AIT)Tool Convert
				'.Font = VB6.FontChangeBold(.Font, True)
				.Font = New Font(.Font, FontStyle.Bold)
				'2021.07.26 UPGRADE E

				'2021.08.04 UPGRADE S  AIT)Hoangtx
				'.BlockMode = False
				'.SetText(1, lp, CObj(DT(lp - 1).Mesyo))
				.ActiveSheet.SetText(lp - 1, 0, CObj(DT(lp - 1).Mesyo))
				'.SetText(6, lp, CObj(DT(lp - 1).Bango))
				.ActiveSheet.SetText(lp - 1, 5, CObj(DT(lp - 1).Bango))
				'.SetText(2, lp, CObj(VB6.Format(DT(lp - 1).Yobi1, "#,###")))
				If CObj(CDec(DT(lp - 1).Yobi1).ToString("#,##0")) = "0" Then
					.ActiveSheet.SetText(lp - 1, 1, "")
				Else
					.ActiveSheet.SetText(lp - 1, 1, CObj(CDec(DT(lp - 1).Yobi1).ToString("#,##0")))
				End If
				'.SetText(3, lp, CObj(DT(lp - 1).Yobi2))
				.ActiveSheet.SetText(lp - 1, 2, CObj(DT(lp - 1).Yobi2))
				'.SetText(4, lp, CObj(VB6.Format(DT(lp - 1).Yobi3, "#,###")))
				If CObj(CDec(DT(lp - 1).Yobi3).ToString("#,##0")) = 0 Then
					.ActiveSheet.SetText(lp - 1, 3, "")
				Else
					.ActiveSheet.SetText(lp - 1, 3, CObj(CDec(DT(lp - 1).Yobi3).ToString("#,##0")))
				End If
				'2021.07.26 UPGRADE S  AIT)Tool Convert
				'.SetText(5, lp, CObj(VB6.Format(DT(lp - 1).Yobi4, "#,##0")))
				.ActiveSheet.SetText(lp - 1, 4, CObj(CDec(DT(lp - 1).Yobi4).ToString("#,##0")))
				'2021.08.04 UPGRADE E

				'2021.07.26 UPGRADE E
			Next lp
		End With

		'2021.08.04 UPGRADE S  AIT)Hoangtx
		'FpSpread1.ReDraw = True
		FpSpread1.ResumeLayout(True)
		'If vaSpread1.Visible = True Then
		'	vaSpread1.Focus()
		If FpSpread1.Visible = True Then
			FpSpread1.Focus()
			'2021.08.04 UPGRADE E
		End If

		FormFirstSet = True

	End Function

	'-------------------------------------------------------------------------------
	'   ����    :   �I���f�[�^�̎擾
	'   �֐�    :   Function GetData()
	'   ����    :   ����
	'   �ߒl    :   ����
	'   �@�\    :   �I�����ꂽ�f�[�^��Public�ϐ���GetCD�^GetNM�ɃZ�b�g���܂��B
	'-------------------------------------------------------------------------------
	Private Sub GetData()

		Dim ssText As Object

		'2021.08.04 UPGRADE S  AIT)Hoangtx
		'Call FpSpread1.GetText(1, vaSpread1.ActiveRow, ssText)
		ssText = FpSpread1.ActiveSheet.GetText(FpSpread1.ActiveSheet.ActiveRowIndex, 0)
		GetNM = Trim(ssText)
		'Call FpSpread1.GetText(6, vaSpread1.ActiveRow, ssText)
		ssText = FpSpread1.ActiveSheet.GetText(FpSpread1.ActiveSheet.ActiveRowIndex, 5)
		GetNO = Trim(ssText)
		'2021.08.04 UPGRADE E

	End Sub

	'-------------------------------------------------------------------------------
	'   ����    :   ���o��񌟍��f�[�^�̎擾
	'   �֐�    :   Function GetWaridasi()
	'   ����    :   DT()    DspList
	'   �ߒl    :   Cnt     ���o����
	'   �@�@        -1      �ُ�I��
	'   �@�\    :   �����ɊY������R�[�h�^���̂̎擾���s���B
	'-------------------------------------------------------------------------------
	Private Function GetWaridasi(ByRef DT() As DspList) As Integer

		Dim SQL As String

		'2021.08.04 UPGRADE S  AIT)Hoangtx
		'Dim Rs As ADODB.Recordset
		Dim Rs As New DataTable
		'2021.08.04 UPGRADE E

		Dim OpenFlg As Short
		Dim Cnt As Integer
		Dim Jouken As String

		'2021.07.26 UPGRADE S  AIT)Tool Convert
		'On Error GoTo GetWaridasi_Err
		Try
			'2021.07.26 UPGRADE E

			'�߂�l�̏�����
			GetWaridasi = -1

			'----- WHERE���̑g�ݗ���
			Jouken = ""
			If Trim(ZENTEI) <> "" Then
				Jouken = "(" & ZENTEI & ")"
			End If

			'----- SQL/SELECT���̑g�ݗ���
			SQL = "SELECT"
			SQL = SQL & " MEISYOU     AS F01,"
			SQL = SQL & " MEISAI_NO   AS F02,"
			SQL = SQL & " T_SUURYOU   AS F03,"
			SQL = SQL & " TANI        AS F04,"
			SQL = SQL & " T_TANKA     AS F05,"
			SQL = SQL & " T_KINGAKU   AS F06"
			SQL = SQL & " FROM WARIDASI_DATA"
			If Jouken <> "" Then
				SQL = SQL & " WHERE " & Jouken
			End If
			SQL = SQL & " ORDER BY MEISAI_NO"

			'----- SQL�����s
			'2021.08.04 UPGRADE S  AIT)Hoangtx
			'Rs = SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText)
			Rs = RsOpen(SQL)
			'2021.08.04 UPGRADE E
			OpenFlg = 1

			Cnt = 0
			'Do Until Rs.EOF
			For Each Row As DataRow In Rs.Rows
				ReDim Preserve DT(Cnt)
				'DT(Cnt).Mesyo = RsNull(Rs, "F01")
				DT(Cnt).Mesyo = RsNull(Row, "F01")
				'DT(Cnt).Bango = RsNull(Rs, "F02")
				DT(Cnt).Bango = RsNull(Row, "F02")
				'DT(Cnt).Yobi1 = RsNull(Rs, "F03")
				DT(Cnt).Yobi1 = RsNull(Row, "F03")
				'DT(Cnt).Yobi2 = RsNull(Rs, "F04")
				DT(Cnt).Yobi2 = RsNull(Row, "F04")
				'DT(Cnt).Yobi3 = RsNull(Rs, "F05")
				DT(Cnt).Yobi3 = RsNull(Row, "F05")
				'DT(Cnt).Yobi4 = RsNull(Rs, "F06")
				DT(Cnt).Yobi4 = RsNull(Row, "F06")
				Cnt = Cnt + 1
				'Rs.MoveNext()
				'Loop
			Next

			'Rs.Close()
			Rs.Dispose()
			'2021.08.06 UPGRADE E

			Rs = Nothing

			'�߂�l�Ɍ������Z�b�g
			GetWaridasi = Cnt

			Exit Function

			'2021.07.26 UPGRADE S  AIT)Tool Convert
			'GetWaridasi_Err:
		Catch ex As Exception
			'2021.07.26 UPGRADE E

			'2021.08.06 UPGRADE S  AIT)Hoangtx
			If OpenFlg = 1 Then
				'Rs.close()
				Rs.Dispose()
			End If
			Rs = Nothing

			'Call Sql_Error_Msg("WARIDASI_DATA SELECT")
			Call Sql_Error_Msg(ex, "WARIDASI_DATA SELECT")
			'2021.08.06 UPGRADE E

		End Try     '2021.07.26 UPGRADE ADD AIT)Tool Convert
	End Function

	'2021.08.04 UPGRADE S AIT)Hoangtx
	'Private Sub cmdKey_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Click
	Private Sub cmdKey_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _cmdKey_1.Click, _cmdKey_12.Click
		'	Dim Index As Short = cmdKey.GetIndex(eventSender)
		Dim Index As Short = cmdKey.IndexOf(eventSender)
		'2021.08.04 UPGRADE E
		Select Case Index
			Case 1 '----- ����
				Call GetData()
				ZENTEI = ""
				'2021.08.06 UPGRADE S  AIT)Hoangtx
				'Me.Close()
				Me.Dispose()
				'2021.08.06 UPGRADE E

			Case 12 '----- �I��
				ZENTEI = ""
				GetNO = ""
				GetNM = ""
				'2021.08.04 UPGRADE S AIT)Hoangtx
				'Me.Close()
				Me.Dispose()
				'2021.08.04 UPGRADE E
		End Select

	End Sub

	'2021.08.04 UPGRADE S AIT)Hoangtx
	'Private Sub cmdKey_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Enter
	Private Sub cmdKey_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _cmdKey_1.Enter, _cmdKey_12.Enter
		'Dim Index As Short = cmdKey.GetIndex(eventSender)
		Dim Index As Short = cmdKey.IndexOf(eventSender)
		'Call GotFocus(cmdKey(Index), StatusBar1)
		Call MtyTool.GotFocus(cmdKey(Index), StatusBar1)
		'2021.08.04 UPGRADE E
	End Sub

	'2021.08.04 UPGRADE S AIT)Hoangtx
	'Private Sub cmdKey_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Leave
	Private Sub cmdKey_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _cmdKey_1.Leave, _cmdKey_12.Leave
		'Dim Index As Short = cmdKey.GetIndex(eventSender)
		Dim Index As Short = cmdKey.IndexOf(eventSender)
		'Call LostFocus(cmdKey(Index), StatusBar1)
		Call MtyTool.LostFocus(cmdKey(Index), StatusBar1)
		'2021.08.04 UPGRADE E
	End Sub

	Private Sub frmWaridasi_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown
		Dim KeyCode As Short = eventArgs.KeyCode
		Dim Shift As Short = eventArgs.KeyData \ &H10000
		Select Case KeyCode
			Case System.Windows.Forms.Keys.F1 '----- ����
				If cmdKey(1).Enabled = True Then cmdKey(1).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(1), New System.EventArgs())
			Case System.Windows.Forms.Keys.F12 '----- �I��
				If cmdKey(12).Enabled = True Then cmdKey(12).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(12), New System.EventArgs())
		End Select
	End Sub

	Private Sub frmWaridasi_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
		Call FormDisp(Me)
		GetNO = ""
		GetNM = ""
		System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
		If FormFirstSet() = False Then
			'
		End If
		System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
	End Sub

	Private Sub frmWaridasi_FormClosing(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
		Dim Cancel As Boolean = eventArgs.Cancel
		Dim UnloadMode As System.Windows.Forms.CloseReason = eventArgs.CloseReason
		If UnloadMode = System.Windows.Forms.CloseReason.UserClosing Then
			'----- �I������
			Call cmdKey_Click(cmdKey.Item(12), New System.EventArgs())
		End If
		eventArgs.Cancel = Cancel
	End Sub

	'2021.08.04 UPGRADE S  AIT)Hoangtx
	'Private Sub vaSpread1_ClickEvent(ByVal eventSender As System.Object, ByVal eventArgs As AxFPSpread._DSpreadEvents_ClickEvent) Handles FpSpread1.ClickEvent
	Private Sub vaSpread1_ClickEvent(ByVal eventSender As System.Object, ByVal eventArgs As FarPoint.Win.Spread.CellClickEventArgs) Handles FpSpread1.CellClick
		'If eventArgs.Row = 0 And eventArgs.Col = 1 Then
		'	If vaSpread1.get_SortKey(1) = eventArgs.Col Then
		'		SortMode(eventArgs.Col - 1) = Not SortMode(eventArgs.Col - 1)
		'	Else
		'		SortMode(eventArgs.Col - 1) = -1
		'	End If
		'	With vaSpread1
		'		.eventArgs.Col = 1
		'		.eventArgs.Row = 1
		'		.Col2 = .MaxCols
		'		.Row2 = .MaxRows
		'		.SortBy = FPSpread.SortByConstants.SortByRow
		'		.set_SortKey(1, eventArgs.Col)
		'		.set_SortKeyOrder(1, SortMode(eventArgs.Col - 1) + 2)
		'		.Action = FPSpread.ActionConstants.ActionSort
		'	End With
		'End If
		If eventArgs.Row = 0 AndAlso eventArgs.Column = 0 AndAlso eventArgs.ColumnHeader = True Then
			With FpSpread1
				Dim sort(1) As FarPoint.Win.Spread.SortInfo
				If SortMode(1) = -1 Then
					sort(0) = New FarPoint.Win.Spread.SortInfo(0, False, System.Collections.Comparer.Default)
					SortMode(1) = Not -1
				Else
					sort(0) = New FarPoint.Win.Spread.SortInfo(0, True, System.Collections.Comparer.Default)
					SortMode(1) = -1
				End If
				.ActiveSheet.SortRange(0, 0, .ActiveSheet.RowCount, .ActiveSheet.ColumnCount, True, sort)
				'2021.08.04 UPGRADE E
			End With
		End If
	End Sub

	'2021.08.04 UPGRADE S  AIT)Hoangtx
	'Private Sub vaSpread1_DblClick(ByVal eventSender As System.Object, ByVal eventArgs As AxFPSpread._DSpreadEvents_DblClickEvent) Handles FpSpread1.DblClick
	Private Sub vaSpread1_DblClick(ByVal eventSender As System.Object, ByVal eventArgs As FarPoint.Win.Spread.CellClickEventArgs) Handles FpSpread1.CellDoubleClick
		'If eventArgs.Col > 0 And eventArgs.Row > 0 Then
		If eventArgs.Column >= 0 AndAlso eventArgs.Row >= 0 AndAlso eventArgs.ColumnHeader = False AndAlso eventArgs.RowHeader = False Then
			'2021.08.04 UPGRADE E
			Call frmWaridasi_KeyDown(Me, New System.Windows.Forms.KeyEventArgs(System.Windows.Forms.Keys.F1 Or 0 * &H10000))
		End If
	End Sub

	Private Sub vaSpread1_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles FpSpread1.Enter
		'2021.08.04 UPGRADE S  AIT)Hoangtx
		'Call GotFocus(FpSpread1, StatusBar1)
		Call MtyTool.GotFocus(FpSpread1, StatusBar1)
		'2021.08.04 UPGRADE E
	End Sub

	'2021.08.04 UPGRADE S  AIT)Hoangtx
	'Private Sub vaSpread1_KeyDownEvent(ByVal eventSender As System.Object, ByVal eventArgs As AxFPSpread._DSpreadEvents_KeyDownEvent) Handles FpSpread1.KeyDownEvent
	Private Sub vaSpread1_KeyDownEvent(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles FpSpread1.KeyDown
		If eventArgs.KeyCode = System.Windows.Forms.Keys.Return Then
			'If FpSpread1.ActiveRow > 0 Then
			If FpSpread1.ActiveSheet.ActiveRowIndex > 0 Then
				Call frmWaridasi_KeyDown(Me, New System.Windows.Forms.KeyEventArgs(System.Windows.Forms.Keys.F1 Or 0 * &H10000))
			End If
		End If
	End Sub
	'2021.08.04 UPGRADE E

	Private Sub vaSpread1_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles FpSpread1.Leave
		'2021.08.04 UPGRADE S  AIT)Hoangtx
		'Call LostFocus(FpSpread1, StatusBar1)
		Call MtyTool.LostFocus(FpSpread1, StatusBar1)
		'2021.08.04 UPGRADE E
	End Sub
End Class
