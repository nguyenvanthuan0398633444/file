Option Strict Off
Option Explicit On
Imports C1.Win.FlexReport
Imports System.Drawing.Printing

Module prnSYKD185
    '=============================================================
    ' ���[�U�[���@  �F  �R�z�H�Ɗ������
    ' �V�X�e�����@  �F  �H���Ǘ��V�X�e��
    ' ���W���[����  �F  �H������(�y��)���
    ' ���W���[��ID�@�F  prnSYKD185.bas
    ' �쐬���@ �@�@ �F  ���� 13 �N 08 �� 09 ��
    ' �X�V���@�@  �@�F  ���� 13 �N 08 �� 29 ��
    '=============================================================
    '
    '-------------------------------------------------------------------------------------------
    ' �������F2003/08/25
    ' �����ꏈ����
    '   �H��FB-00�ȍ~�ŊO���̂��̂��A�H��FA-01(�{�H��)�Ƃ��ďW�v����
    '   �X�ɍH��FA-01(�{�H��)�̓���Ƃ��āA�e�O�����v�ƒ��c���v���W�v����
    '-------------------------------------------------------------------------------------------


    ' �H������f�[�^�\����(1)
    Private Structure GEPPOU_DATA_SUB
        '2021.08.03 UPGRADE S  AIT)Tool Convert
        '<VBFixedString(2),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=2)> Public GYOU_NO() As Char ' �s�ԍ�
        '<VBFixedString(12),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=12)> Public BIKOU() As Char ' ���l
        <VBFixedStringAttribute(2)> Public GYOU_NO As String     ' �s�ԍ�
        <VBFixedStringAttribute(12)> Public BIKOU As String  ' ���l
        '2021.08.03 UPGRADE E
        Dim UKEOI_GAKU As Decimal ' �������z
        Dim YOSAN_GAKU As Decimal ' ���s�\�Z
        Dim RIEKI_GAKU As Decimal ' �H�����v
        '2021.08.03 UPGRADE S  AIT)Tool Convert
        '<VBFixedString(6),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=6)> Public RIEKI_RITU() As Char ' ���v��
        <VBFixedStringAttribute(6)> Public RIEKI_RITU As String  ' ���v��
        '2021.08.03 UPGRADE E
    End Structure

    ' �H������f�[�^�\����(2)
    Private Structure GEPPOU_LIST_SUB
        '2021.08.03 UPGRADE S  AIT)Tool Convert
        '<VBFixedString(1),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=1)> Public KOUSYU_CD() As Char ' �H������
        '<VBFixedString(2),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=2)> Public KOUSYU_NO() As Char ' �H��ԍ�
        '<VBFixedString(40),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=40)> Public MEISYOU() As Char ' �H�햼��
        <VBFixedStringAttribute(1)> Public KOUSYU_CD As String   ' �H������
        <VBFixedStringAttribute(2)> Public KOUSYU_NO As String   ' �H��ԍ�
        <VBFixedStringAttribute(40)> Public MEISYOU As String    ' �H�햼��
        '2021.08.03 UPGRADE E
        Dim YOSAN_GAKU As Decimal ' ���s�\�Z �� ��Ɋz
        Dim KINGAKU As Decimal ' ���ы��z
        Dim RUIGAKU As Decimal ' �݌v���z
        Dim KONGO_GAKU As Decimal ' ���㌩��
        Dim JISSI_GAKU As Decimal ' ���{����
        Dim TAIHI_GAKU As Decimal ' �\�Z�Δ�
        Dim ZOGEN_GAKU As Decimal ' �ύX����
        '----- 2004/03/17 �ǉ�
        Dim J_YOSAN As Decimal ' ���s�\�Z
    End Structure

    ' �H������f�[�^�\����(3)
    Private Structure GEPPOU_LIST_GAI
        '2021.08.03 UPGRADE S  AIT)Tool Convert
        '<VBFixedString(2),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=2)> Public WARIDASI_NO() As Char ' ���o�ԍ�
        '<VBFixedString(1),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=1)> Public WARIDASI_KB() As Char ' ���o�敪
        '<VBFixedString(40),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=40)> Public MEISYOU() As Char ' ���o����
        <VBFixedStringAttribute(2)> Public WARIDASI_NO As String     ' ���o�ԍ�
        <VBFixedStringAttribute(1)> Public WARIDASI_KB As String     ' ���o�敪
        <VBFixedStringAttribute(40)> Public MEISYOU As String    ' ���o����
        '2021.08.03 UPGRADE E
        Dim YOSAN_GAKU As Decimal ' ���s�\�Z �� ��Ɋz
        Dim KINGAKU As Decimal ' ���ы��z
        Dim RUIGAKU As Decimal ' �݌v���z
        Dim KONGO_GAKU As Decimal ' ���㌩��
        Dim JISSI_GAKU As Decimal ' ���{����
        Dim TAIHI_GAKU As Decimal ' �\�Z�Δ�
        Dim ZOGEN_GAKU As Decimal ' �ύX����
        '----- 2004/03/17 �ǉ�
        Dim J_YOSAN As Decimal ' ���s�\�Z
    End Structure

    Private P_Cnt As Short ' ����y�[�W�J�E���g
    Private XX() As Single ' ����w�ʒu
    Private YY() As Single ' ����x�ʒu
    Private Bupyy As Single
    Private XX2() As Single ' ����w�ʒu

    Private PrnModeNo As Integer
    Private Const PageDataDnt As Short = 48
    'Private Const PageDataDnt As Integer = 61
    '
    '-------------------------------------------------------------------------------
    '   ����    :   �H������(�y��)���
    '   �֐�    :   Function PrnMainD185()
    '   ����    :   ����
    '   �ߒl    :   True    ����I��
    '   �@�@        False   ���f
    '-------------------------------------------------------------------------------
    Public Function PrnMainD185() As Object

        Dim Jouken As String
        Dim QRY1 As String
        Dim QRY2 As String
        Dim QRY3 As String
        Dim QRY4 As String
        Dim QRY5 As String
        Dim QRY6 As String
        Dim SQL As String
        Dim DT() As GEPPOU_DATA_D_DBT
        Dim ZDT() As GEPPOU_DATA_D_DBT
        Dim DT2() As GEPPOU_LIST_SUB
        Dim DT3() As GEPPOU_LIST_SUB
        Dim DT4() As GEPPOU_LIST_GAI
        '2021.08.11 UPGRADE S  AIT)dannnl
        'Dim Rs As ADODB.Recordset
        'Dim Fld As ADODB.Field
        Dim Rs As New DataTable
        Dim Fld As DataColumn
        '2021.08.11 UPGRADE E
        Dim Cnt As Integer
        Dim Cnt2 As Integer
        Dim Cnt4 As Integer
        Dim OpenFlg As Short
        Dim lp As Integer
        Dim lp2 As Integer
        Dim pryy As Single
        Dim KOUMOKU_KEI(9) As Decimal ' �e���ڍ��v�p
        '2021.08.11 UPGRADE DEL S  AIT)dannnl
        'Dim R_Cnt As Integer
        'Dim L_Length As Single
        '2021.08.11 UPGRADE DEL E

        Dim G_YOSAN_GAKU As Decimal
        Dim G_KINGAKU As Decimal
        Dim G_RUIGAKU As Decimal
        Dim G_KONGO_GAKU As Decimal
        Dim G_JISSI_GAKU As Decimal
        Dim G_TAIHI_GAKU As Decimal
        Dim G_ZOGEN_GAKU As Decimal
        Dim Pos As Integer

        Dim G_JIKOU_GAKU As Decimal

        Dim TanGaku As Decimal '�P�����z
        Dim NinGaku As Decimal '�C�ӘJ��
        Dim TtlGaku As Decimal
        Dim ZenTanGaku As Decimal '�O�����P�����z
        Dim ZenNinGaku As Decimal '�O�����C�ӘJ��
        Dim ZenTtlGaku As Decimal

        '----- ����f�[�^
        ' �����̐ݒ�
        Jouken = "KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"
        Jouken = Jouken & " AND EDA_NO = '" & KeyKouji.EDA_NO & "'"
        Jouken = Jouken & " AND SIME_YM = '" & CtlKouji.SYORI_YM & "'"
        Cnt = SELECT_GEPPOU_DATA_D(Jouken, "", DT)
        If Cnt <= 0 Then
            Exit Function
        End If

        '----- �O�񌎕�f�[�^
        Jouken = "KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"
        Jouken = Jouken & " AND EDA_NO = '" & KeyKouji.EDA_NO & "'"
        Jouken = Jouken & " AND SIME_YM < '" & CtlKouji.SYORI_YM & "'"
        Cnt = SELECT_GEPPOU_DATA_D(Jouken, "SIME_YM DESC", ZDT)
        If Cnt <= 0 Then
            ReDim ZDT(0)
            Call CLEAR_GEPPOU_DATA_D(ZDT(0))
        End If

        '----- �H�����ޕ� ----------------------------------------------------------------------------
        ' QRY/SELECT���g��
        QRY1 = "(SELECT KOUSYU_CD, KOUSYU_NO, MEISYOU"
        QRY1 = QRY1 & " FROM KOUSYU_MAST"
        QRY1 = QRY1 & " WHERE GYOUSYU_KB = '" & GyosyuID & "'"
        QRY1 = QRY1 & ") AS MASTDT"

        ' QRY/SELECT���g��
        QRY2 = "(SELECT KOUSYU_CD, KOUSYU_NO,"
        '----- 2001/10/29 �C�� -----------------------------------
        QRY2 = QRY2 & " SUM(T_KINGAKU + G_KINGAKU) AS YOSAN,"
        '---------------------------------------------------------
        '----- 2004/03/17 �ǉ� -----------------------------------
        QRY2 = QRY2 & " SUM(S_KINGAKU)             AS JIKOU"
        '---------------------------------------------------------
        QRY2 = QRY2 & " FROM WARIDASI_DATA"
        QRY2 = QRY2 & " WHERE EDA_NO = '" & KeyKouji.EDA_NO & "'"
        QRY2 = QRY2 & " AND KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"
        QRY2 = QRY2 & " GROUP BY KOUSYU_CD, KOUSYU_NO"
        QRY2 = QRY2 & ") AS WARIDT"

        ' QRY/SELECT���g��
        QRY3 = "(SELECT KOUSYU_CD, KOUSYU_NO,"
        QRY3 = QRY3 & " SUM(SI_GAKU)     AS KINGAKU,"
        QRY3 = QRY3 & " SUM(SI_KEI)      AS RUIGAKU,"
        QRY3 = QRY3 & " SUM(KONGO_GAKU)  AS KONGO,"
        QRY3 = QRY3 & " SUM(JISSI_GAKU)  AS JISSI,"
        QRY3 = QRY3 & " SUM(TAIHI_GAKU)  AS TAIHI,"
        QRY3 = QRY3 & " SUM(ZOUGEN_GAKU) AS ZOGEN"
        QRY3 = QRY3 & " FROM MIKOMI_DATA"
        QRY3 = QRY3 & " WHERE SIME_YM = '" & CtlKouji.SYORI_YM & "'"
        QRY3 = QRY3 & " AND EDA_NO = '" & KeyKouji.EDA_NO & "'"
        QRY3 = QRY3 & " AND KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"
        QRY3 = QRY3 & " GROUP BY KOUSYU_CD, KOUSYU_NO"
        QRY3 = QRY3 & ") AS MIKOMI"

        ' QRY/SELECT���g��
        QRY4 = "(SELECT KOUSYU_CD, KOUSYU_NO,"
        QRY4 = QRY4 & " SUM(JITU_GAKU)   AS KINGAKU,"
        QRY4 = QRY4 & " SUM(RUI_GAKU)    AS RUIGAKU,"
        QRY4 = QRY4 & " SUM(KONGO_GAKU)  AS KONGO,"
        QRY4 = QRY4 & " SUM(JISSI_GAKU)  AS JISSI,"
        QRY4 = QRY4 & " SUM(TAIHI_GAKU)  AS TAIHI,"
        QRY4 = QRY4 & " SUM(ZOUGEN_GAKU) AS ZOGEN"
        QRY4 = QRY4 & " FROM DEKIDAKA_DATA"
        QRY4 = QRY4 & " WHERE SIME_YM = '" & CtlKouji.SYORI_YM & "'"
        QRY4 = QRY4 & " AND EDA_NO = '" & KeyKouji.EDA_NO & "'"
        QRY4 = QRY4 & " AND KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"
        QRY4 = QRY4 & " GROUP BY KOUSYU_CD, KOUSYU_NO"
        QRY4 = QRY4 & ") AS DEKIDT"

        'QRY/SELECT���g��
        QRY5 = "(SELECT KOUSYU_CD, KOUSYU_NO,"
        '----- 2001/10/29 �C�� -----------------------------------
        QRY5 = QRY5 & " SUM(T_KINGAKU + G_KINGAKU) AS YOSAN,"
        '---------------------------------------------------------
        '----- 2004/03/17 �ǉ� -----------------------------------
        QRY5 = QRY5 & " SUM(S_KINGAKU)             AS JIKOU"
        '---------------------------------------------------------
        QRY5 = QRY5 & " FROM WARIDASI_DATA"
        QRY5 = QRY5 & " WHERE EDA_NO = '" & KeyKouji.EDA_NO & "'"
        QRY5 = QRY5 & " AND KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"
        QRY5 = QRY5 & " AND WARIDASI_KB <> '2'"
        QRY5 = QRY5 & " GROUP BY KOUSYU_CD, KOUSYU_NO"
        QRY5 = QRY5 & ") AS WARIDT_1"

        'QRY/SELECT���g��
        QRY6 = "(SELECT KOUSYU_CD, KOUSYU_NO,"
        '----- 2001/10/29 �C�� -----------------------------------
        QRY6 = QRY6 & " SUM(T_KINGAKU + G_KINGAKU) AS YOSAN,"
        '---------------------------------------------------------
        '----- 2004/03/17 �ǉ� -----------------------------------
        QRY6 = QRY6 & " SUM(S_KINGAKU)             AS JIKOU"
        '---------------------------------------------------------
        QRY6 = QRY6 & " FROM WARIDASI_DATA"
        QRY6 = QRY6 & " WHERE EDA_NO = '" & KeyKouji.EDA_NO & "'"
        QRY6 = QRY6 & " AND KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"
        QRY6 = QRY6 & " AND WARIDASI_KB = '2'"
        QRY6 = QRY6 & " GROUP BY KOUSYU_CD, KOUSYU_NO"
        QRY6 = QRY6 & ") AS WARIDT_2"

        ' SQL/SELECT���g��
        SQL = "SELECT"
        SQL = SQL & " WARIDT.KOUSYU_CD      AS F01," ' �H������
        SQL = SQL & " MIN(WARIDT.KOUSYU_NO) AS F02," ' �H��ԍ�
        SQL = SQL & " MIN(MASTDT.MEISYOU)   AS F03," ' �H�햼
        SQL = SQL & " SUM(WARIDT.YOSAN)     AS F04," ' ���s�\�Z �� ��Ɋz
        SQL = SQL & " SUM(WARIDT_1.YOSAN)   AS F20," ' ���s�\�Z�i�O���ȊO�j
        SQL = SQL & " SUM(WARIDT_2.YOSAN)   AS F21," ' ���s�\�Z�i�O���j
        '----- 2004/03/17 �ǉ� ----------------------------------------------------------
        SQL = SQL & " SUM(WARIDT.JIKOU)     AS F30," ' ���s�\�Z
        SQL = SQL & " SUM(WARIDT_1.JIKOU)   AS F31," ' ���s�\�Z�i�O���ȊO�j
        SQL = SQL & " SUM(WARIDT_2.JIKOU)   AS F32," ' ���s�\�Z�i�O���j
        '-------------------------------------------------------------------------------
        SQL = SQL & " SUM(MIKOMI.KINGAKU)   AS F05," ' ���ы��z�i���c�j
        SQL = SQL & " SUM(MIKOMI.RUIGAKU)   AS F06," ' ���ї݌v
        SQL = SQL & " SUM(MIKOMI.KONGO)     AS F07," ' ���㌩��
        SQL = SQL & " SUM(MIKOMI.JISSI)     AS F08," ' ���{����
        SQL = SQL & " SUM(MIKOMI.TAIHI)     AS F09," ' �\�Z�Δ�
        SQL = SQL & " SUM(MIKOMI.ZOGEN)     AS F10," ' �ύX����
        SQL = SQL & " SUM(DEKIDT.KINGAKU)   AS F11," ' ���ы��z�i�O���j
        SQL = SQL & " SUM(DEKIDT.RUIGAKU)   AS F12," ' ���ї݌v
        SQL = SQL & " SUM(DEKIDT.KONGO)     AS F13," ' ���㌩��
        SQL = SQL & " SUM(DEKIDT.JISSI)     AS F14," ' ���{����
        SQL = SQL & " SUM(DEKIDT.TAIHI)     AS F15," ' �\�Z�Δ�
        SQL = SQL & " SUM(DEKIDT.ZOGEN)     AS F16" ' �ύX����
        SQL = SQL & " FROM ((((" & QRY2
        SQL = SQL & " LEFT JOIN " & QRY5
        SQL = SQL & " ON (WARIDT.KOUSYU_NO = WARIDT_1.KOUSYU_NO)"
        SQL = SQL & " AND (WARIDT.KOUSYU_CD = WARIDT_1.KOUSYU_CD))"
        SQL = SQL & " LEFT JOIN " & QRY6
        SQL = SQL & " ON (WARIDT.KOUSYU_NO = WARIDT_2.KOUSYU_NO)"
        SQL = SQL & " AND (WARIDT.KOUSYU_CD = WARIDT_2.KOUSYU_CD))"
        SQL = SQL & " LEFT JOIN " & QRY3
        SQL = SQL & " ON (WARIDT.KOUSYU_NO = MIKOMI.KOUSYU_NO)"
        SQL = SQL & " AND (WARIDT.KOUSYU_CD = MIKOMI.KOUSYU_CD))"
        SQL = SQL & " LEFT JOIN " & QRY4
        SQL = SQL & " ON (WARIDT.KOUSYU_NO = DEKIDT.KOUSYU_NO)"
        SQL = SQL & " AND (WARIDT.KOUSYU_CD = DEKIDT.KOUSYU_CD))"
        SQL = SQL & " LEFT JOIN " & QRY1
        SQL = SQL & " ON (WARIDT.KOUSYU_NO = MASTDT.KOUSYU_NO)"
        SQL = SQL & " AND (WARIDT.KOUSYU_CD = MASTDT.KOUSYU_CD)"
        SQL = SQL & " GROUP BY WARIDT.KOUSYU_CD"
        SQL = SQL & " ORDER BY WARIDT.KOUSYU_CD"

        ' SQL�����s
        '2021.08.11 UPGRADE S  AIT)dannnl
        'Rs = SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText)
        Rs = RsOpen(SQL)
        '2021.08.11 UPGRADE E
        OpenFlg = 1

        '�O�����z�̏�����
        G_JIKOU_GAKU = 0
        G_YOSAN_GAKU = 0
        G_KINGAKU = 0
        G_RUIGAKU = 0
        G_KONGO_GAKU = 0
        G_JISSI_GAKU = 0
        G_TAIHI_GAKU = 0
        G_ZOGEN_GAKU = 0

        Cnt = 0
        '2021.08.11 UPGRADE S  AIT)dannnl
        'Do Until Rs.EOF
        For Each Row As DataRow In Rs.Rows
            '2021.08.11 UPGRADE E
            ReDim Preserve DT2(Cnt)
            With DT2(Cnt)
                '----- ������
                .KOUSYU_CD = "" ' �H������
                .KOUSYU_NO = "" ' �H��ԍ�
                .MEISYOU = "" ' �H�햼��
                .YOSAN_GAKU = 0 ' ���s�\�Z �� ��Ɋz
                .KINGAKU = 0 ' ���ы��z
                .RUIGAKU = 0 ' ���ї݌v
                .KONGO_GAKU = 0 ' ���㌩��
                .JISSI_GAKU = 0 ' ���{����
                .TAIHI_GAKU = 0 ' �\�Z�Δ�
                .ZOGEN_GAKU = 0 ' �ύX����
                .J_YOSAN = 0 ' ���s�\�Z
                '----- �\���̂�
                '2021.08.11 UPGRADE S  AIT)dannnl
                'For Each Fld In Rs.Fields
                '	If IsDBNull(Fld.Name) = False And IsDBNull(Fld.Value) = False Then
                '		Select Case UCase(Fld.Name)
                '			Case "F01" : .KOUSYU_CD = Fld.Value '�H������
                '			Case "F02" : .KOUSYU_NO = "00" '�H��ԍ�
                '			Case "F03" : .MEISYOU = GetNameKousyu("01", .KOUSYU_CD, "00") '�H�햼
                '			Case "F20" : .YOSAN_GAKU = .YOSAN_GAKU + Fld.Value '���s�\�Z�i�O���ȊO�j�� ��Ɋz
                '			Case "F21" : G_YOSAN_GAKU = G_YOSAN_GAKU + Fld.Value '���s�\�Z�i�O���j
                '				'----- 2004/03/17 �ǉ� ----------------------------------------------------------------------
                '			Case "F31" : .J_YOSAN = .J_YOSAN + Fld.Value '���s�\�Z�i�O���ȊO�j
                '			Case "F32" : G_JIKOU_GAKU = G_JIKOU_GAKU + Fld.Value '���s�\�Z�i�O���j
                '				'--------------------------------------------------------------------------------------------
                '			Case "F05" : .KINGAKU = .KINGAKU + Fld.Value '���ы��z�i���c�j
                '			Case "F06" : .RUIGAKU = .RUIGAKU + Fld.Value '���ї݌v
                '			Case "F07" : .KONGO_GAKU = .KONGO_GAKU + Fld.Value '���㌩��
                '			Case "F08" : .JISSI_GAKU = .JISSI_GAKU + Fld.Value '���{����
                '			Case "F09" : .TAIHI_GAKU = .TAIHI_GAKU + Fld.Value '�\�Z�Δ�
                '			Case "F10" : .ZOGEN_GAKU = .ZOGEN_GAKU + Fld.Value '�ύX����
                '			Case "F11" : G_KINGAKU = G_KINGAKU + Fld.Value '���ы��z�i�O���j
                '			Case "F12" : G_RUIGAKU = G_RUIGAKU + Fld.Value '���ї݌v
                '			Case "F13" : G_KONGO_GAKU = G_KONGO_GAKU + Fld.Value '���㌩��
                '			Case "F14" : G_JISSI_GAKU = G_JISSI_GAKU + Fld.Value '���{����
                '			Case "F15" : G_TAIHI_GAKU = G_TAIHI_GAKU + Fld.Value '�\�Z�Δ�
                '			Case "F16" : G_ZOGEN_GAKU = G_ZOGEN_GAKU + Fld.Value '�ύX����
                For Each Fld In Rs.Columns
                    Dim CellValue = Row(Fld.ColumnName)
                    If IsDBNull(Fld.ColumnName) = False And IsDBNull(CellValue) = False Then
                        Select Case UCase(Fld.ColumnName)
                            Case "F01" : .KOUSYU_CD = CellValue '�H������
                            Case "F02" : .KOUSYU_NO = "00" '�H��ԍ�
                            Case "F03" : .MEISYOU = GetNameKousyu("01", .KOUSYU_CD, "00") '�H�햼
                            Case "F20" : .YOSAN_GAKU = .YOSAN_GAKU + CellValue '���s�\�Z�i�O���ȊO�j�� ��Ɋz
                            Case "F21" : G_YOSAN_GAKU = G_YOSAN_GAKU + CellValue '���s�\�Z�i�O���j
                                '----- 2004/03/17 �ǉ� ----------------------------------------------------------------------
                            Case "F31" : .J_YOSAN = .J_YOSAN + CellValue '���s�\�Z�i�O���ȊO�j
                            Case "F32" : G_JIKOU_GAKU = G_JIKOU_GAKU + CellValue '���s�\�Z�i�O���j
                                '--------------------------------------------------------------------------------------------
                            Case "F05" : .KINGAKU = .KINGAKU + CellValue '���ы��z�i���c�j
                            Case "F06" : .RUIGAKU = .RUIGAKU + CellValue '���ї݌v
                            Case "F07" : .KONGO_GAKU = .KONGO_GAKU + CellValue '���㌩��
                            Case "F08" : .JISSI_GAKU = .JISSI_GAKU + CellValue '���{����
                            Case "F09" : .TAIHI_GAKU = .TAIHI_GAKU + CellValue '�\�Z�Δ�
                            Case "F10" : .ZOGEN_GAKU = .ZOGEN_GAKU + CellValue '�ύX����
                            Case "F11" : G_KINGAKU = G_KINGAKU + CellValue '���ы��z�i�O���j
                            Case "F12" : G_RUIGAKU = G_RUIGAKU + CellValue '���ї݌v
                            Case "F13" : G_KONGO_GAKU = G_KONGO_GAKU + CellValue '���㌩��
                            Case "F14" : G_JISSI_GAKU = G_JISSI_GAKU + CellValue '���{����
                            Case "F15" : G_TAIHI_GAKU = G_TAIHI_GAKU + CellValue '�\�Z�Δ�
                            Case "F16" : G_ZOGEN_GAKU = G_ZOGEN_GAKU + CellValue '�ύX����
                                '2021.08.11 UPGRADE E
                        End Select
                    End If
                Next Fld
            End With
            Cnt = Cnt + 1
            '2021.08.11 UPGRADE S  AIT)dannnl
            '	Rs.MoveNext()
            'Loop

            'Rs.Close()
        Next

        Rs.Dispose()
        '2021.08.11 UPGRADE E
        Rs = Nothing

        '�W�v�����O�����z���wA-00�x�ɑ�������
        Pos = -1
        For lp = 0 To Cnt - 1
            If DT2(lp).KOUSYU_CD = "A" And DT2(lp).KOUSYU_NO = "00" Then
                Pos = lp
                Exit For
            End If
        Next lp
        If Pos > -1 Then
            With DT2(Pos)
                .J_YOSAN = .J_YOSAN + G_JIKOU_GAKU '���s�\�Z�i�O���j
                .YOSAN_GAKU = .YOSAN_GAKU + G_YOSAN_GAKU '���s�\�Z�i�O���j�� ��Ɋz
                .KINGAKU = .KINGAKU + G_KINGAKU '���ы��z�i�O���j
                .RUIGAKU = .RUIGAKU + G_RUIGAKU '���ї݌v
                .KONGO_GAKU = .KONGO_GAKU + G_KONGO_GAKU '���㌩��
                .JISSI_GAKU = .JISSI_GAKU + G_JISSI_GAKU '���{����
                .TAIHI_GAKU = .TAIHI_GAKU + G_TAIHI_GAKU '�\�Z�Δ�
                .ZOGEN_GAKU = .ZOGEN_GAKU + G_ZOGEN_GAKU '�ύX����
            End With
        End If

        '----- �H��ԍ��� ----------------------------------------------------------------------------
        ' QRY/SELECT���g��
        QRY1 = "(SELECT KOUSYU_CD, KOUSYU_NO, MEISYOU"
        QRY1 = QRY1 & " FROM KOUSYU_MAST"
        QRY1 = QRY1 & " WHERE GYOUSYU_KB = '" & GyosyuID & "'"
        QRY1 = QRY1 & ") AS MASTDT"

        ' QRY/SELECT���g��
        QRY2 = "(SELECT KOUSYU_CD, KOUSYU_NO,"
        '----- 2001/10/29 �C�� -----------------------------------
        QRY2 = QRY2 & " SUM(T_KINGAKU + G_KINGAKU) AS YOSAN,"
        '---------------------------------------------------------
        '----- 2004/03/17 �ǉ� -----------------------------------
        QRY2 = QRY2 & " SUM(S_KINGAKU)             AS JIKOU"
        '---------------------------------------------------------
        QRY2 = QRY2 & " FROM WARIDASI_DATA"
        QRY2 = QRY2 & " WHERE EDA_NO = '" & KeyKouji.EDA_NO & "'"
        QRY2 = QRY2 & " AND KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"
        QRY2 = QRY2 & " GROUP BY KOUSYU_CD, KOUSYU_NO"
        QRY2 = QRY2 & ") AS WARIDT"

        ' QRY/SELECT���g��
        QRY3 = "(SELECT KOUSYU_CD, KOUSYU_NO,"
        QRY3 = QRY3 & " SUM(SI_GAKU)     AS KINGAKU,"
        QRY3 = QRY3 & " SUM(SI_KEI)      AS RUIGAKU,"
        QRY3 = QRY3 & " SUM(KONGO_GAKU)  AS KONGO,"
        QRY3 = QRY3 & " SUM(JISSI_GAKU)  AS JISSI,"
        QRY3 = QRY3 & " SUM(TAIHI_GAKU)  AS TAIHI,"
        QRY3 = QRY3 & " SUM(ZOUGEN_GAKU) AS ZOGEN"
        QRY3 = QRY3 & " FROM MIKOMI_DATA"
        QRY3 = QRY3 & " WHERE SIME_YM = '" & CtlKouji.SYORI_YM & "'"
        QRY3 = QRY3 & " AND EDA_NO = '" & KeyKouji.EDA_NO & "'"
        QRY3 = QRY3 & " AND KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"
        QRY3 = QRY3 & " GROUP BY KOUSYU_CD, KOUSYU_NO"
        QRY3 = QRY3 & ") AS MIKOMI"

        ' QRY/SELECT���g��
        QRY4 = "(SELECT KOUSYU_CD, KOUSYU_NO,"
        QRY4 = QRY4 & " SUM(JITU_GAKU)   AS KINGAKU,"
        QRY4 = QRY4 & " SUM(RUI_GAKU)    AS RUIGAKU,"
        QRY4 = QRY4 & " SUM(KONGO_GAKU)  AS KONGO,"
        QRY4 = QRY4 & " SUM(JISSI_GAKU)  AS JISSI,"
        QRY4 = QRY4 & " SUM(TAIHI_GAKU)  AS TAIHI,"
        QRY4 = QRY4 & " SUM(ZOUGEN_GAKU) AS ZOGEN"
        QRY4 = QRY4 & " FROM DEKIDAKA_DATA"
        QRY4 = QRY4 & " WHERE SIME_YM = '" & CtlKouji.SYORI_YM & "'"
        QRY4 = QRY4 & " AND EDA_NO = '" & KeyKouji.EDA_NO & "'"
        QRY4 = QRY4 & " AND KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"
        QRY4 = QRY4 & " GROUP BY KOUSYU_CD, KOUSYU_NO"
        QRY4 = QRY4 & ") AS DEKIDT"

        'QRY/SELECT���g��
        QRY5 = "(SELECT KOUSYU_CD, KOUSYU_NO,"
        '----- 2001/10/29 �C�� -----------------------------------
        QRY5 = QRY5 & " SUM(T_KINGAKU + G_KINGAKU) AS YOSAN,"
        '---------------------------------------------------------
        '----- 2004/03/17 �ǉ� -----------------------------------
        QRY5 = QRY5 & " SUM(S_KINGAKU)             AS JIKOU"
        '---------------------------------------------------------
        QRY5 = QRY5 & " FROM WARIDASI_DATA"
        QRY5 = QRY5 & " WHERE EDA_NO = '" & KeyKouji.EDA_NO & "'"
        QRY5 = QRY5 & " AND KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"
        QRY5 = QRY5 & " AND WARIDASI_KB <> '2'"
        QRY5 = QRY5 & " GROUP BY KOUSYU_CD, KOUSYU_NO"
        QRY5 = QRY5 & ") AS WARIDT_1"

        'QRY/SELECT���g��
        QRY6 = "(SELECT KOUSYU_CD, KOUSYU_NO,"
        '----- 2001/10/29 �C�� -----------------------------------
        QRY6 = QRY6 & " SUM(T_KINGAKU + G_KINGAKU) AS YOSAN,"
        '---------------------------------------------------------
        '----- 2004/03/17 �ǉ� -----------------------------------
        QRY6 = QRY6 & " SUM(S_KINGAKU)             AS JIKOU"
        '---------------------------------------------------------
        QRY6 = QRY6 & " FROM WARIDASI_DATA"
        QRY6 = QRY6 & " WHERE EDA_NO = '" & KeyKouji.EDA_NO & "'"
        QRY6 = QRY6 & " AND KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"
        QRY6 = QRY6 & " AND WARIDASI_KB = '2'"
        QRY6 = QRY6 & " GROUP BY KOUSYU_CD, KOUSYU_NO"
        QRY6 = QRY6 & ") AS WARIDT_2"

        ' SQL/SELECT���g��
        SQL = "SELECT"
        SQL = SQL & " WARIDT.KOUSYU_CD  AS F01," ' �H������
        SQL = SQL & " WARIDT.KOUSYU_NO  AS F02," ' �H��ԍ�
        SQL = SQL & " MASTDT.MEISYOU    AS F03," ' �H�햼
        SQL = SQL & " WARIDT.YOSAN      AS F04," ' ���s�\�Z �� ��Ɋz
        SQL = SQL & " WARIDT_1.YOSAN    AS F20," ' ���s�\�Z�i�O���ȊO�j
        SQL = SQL & " WARIDT_2.YOSAN    AS F21," ' ���s�\�Z�i�O���j
        '----- 2004/03/17 �ǉ� ----------------------------------------------------------
        SQL = SQL & " WARIDT.JIKOU      AS F30," ' ���s�\�Z
        SQL = SQL & " WARIDT_1.JIKOU    AS F31," ' ���s�\�Z�i�O���ȊO�j
        SQL = SQL & " WARIDT_2.JIKOU    AS F32," ' ���s�\�Z�i�O���j
        '-------------------------------------------------------------------------------
        SQL = SQL & " MIKOMI.KINGAKU    AS F05," ' ���ы��z�i���c�j
        SQL = SQL & " MIKOMI.RUIGAKU    AS F06," ' ���ї݌v
        SQL = SQL & " MIKOMI.KONGO      AS F07," ' ���㌩��
        SQL = SQL & " MIKOMI.JISSI      AS F08," ' ���{����
        SQL = SQL & " MIKOMI.TAIHI      AS F09," ' �\�Z�Δ�
        SQL = SQL & " MIKOMI.ZOGEN      AS F10," ' �ύX����
        SQL = SQL & " DEKIDT.KINGAKU    AS F11," ' ���ы��z�i�O���j
        SQL = SQL & " DEKIDT.RUIGAKU    AS F12," ' ���ї݌v
        SQL = SQL & " DEKIDT.KONGO      AS F13," ' ���㌩��
        SQL = SQL & " DEKIDT.JISSI      AS F14," ' ���{����
        SQL = SQL & " DEKIDT.TAIHI      AS F15," ' �\�Z�Δ�
        SQL = SQL & " DEKIDT.ZOGEN      AS F16" ' �ύX����
        SQL = SQL & " FROM ((((" & QRY2
        SQL = SQL & " LEFT JOIN " & QRY5
        SQL = SQL & " ON (WARIDT.KOUSYU_NO = WARIDT_1.KOUSYU_NO)"
        SQL = SQL & " AND (WARIDT.KOUSYU_CD = WARIDT_1.KOUSYU_CD))"
        SQL = SQL & " LEFT JOIN " & QRY6
        SQL = SQL & " ON (WARIDT.KOUSYU_NO = WARIDT_2.KOUSYU_NO)"
        SQL = SQL & " AND (WARIDT.KOUSYU_CD = WARIDT_2.KOUSYU_CD))"
        SQL = SQL & " LEFT JOIN " & QRY3
        SQL = SQL & " ON (WARIDT.KOUSYU_NO = MIKOMI.KOUSYU_NO)"
        SQL = SQL & " AND (WARIDT.KOUSYU_CD = MIKOMI.KOUSYU_CD))"
        SQL = SQL & " LEFT JOIN " & QRY4
        SQL = SQL & " ON (WARIDT.KOUSYU_NO = DEKIDT.KOUSYU_NO)"
        SQL = SQL & " AND (WARIDT.KOUSYU_CD = DEKIDT.KOUSYU_CD))"
        SQL = SQL & " LEFT JOIN " & QRY1
        SQL = SQL & " ON (WARIDT.KOUSYU_NO = MASTDT.KOUSYU_NO)"
        SQL = SQL & " AND (WARIDT.KOUSYU_CD = MASTDT.KOUSYU_CD)"
        SQL = SQL & " ORDER BY WARIDT.KOUSYU_CD, WARIDT.KOUSYU_NO"

        ' SQL�����s
        '2021.08.11 UPGRADE S  AIT)dannnl
        'Rs = SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText)
        Rs = RsOpen(SQL)
        '2021.08.11 UPGRADE E
        OpenFlg = 1

        '�O�����z�̏�����
        G_JIKOU_GAKU = 0
        G_YOSAN_GAKU = 0
        G_KINGAKU = 0
        G_RUIGAKU = 0
        G_KONGO_GAKU = 0
        G_JISSI_GAKU = 0
        G_TAIHI_GAKU = 0
        G_ZOGEN_GAKU = 0

        Cnt2 = 0
        '2021.08.11 UPGRADE S  AIT)dannnl
        'Do Until Rs.EOF
        For Each Row As DataRow In Rs.Rows
            '2021.08.11 UPGRADE E
            ReDim Preserve DT3(Cnt2)
            With DT3(Cnt2)
                '----- ������
                .KOUSYU_CD = "" ' �H������
                .KOUSYU_NO = "" ' �H��ԍ�
                .MEISYOU = "" ' �H�햼��
                .YOSAN_GAKU = 0 ' ���s�\�Z �� ��Ɋz
                .KINGAKU = 0 ' ���ы��z
                .RUIGAKU = 0 ' ���ї݌v
                .KONGO_GAKU = 0 ' ���㌩��
                .JISSI_GAKU = 0 ' ���{����
                .TAIHI_GAKU = 0 ' �\�Z�Δ�
                .ZOGEN_GAKU = 0 ' �ύX����
                .J_YOSAN = 0 ' ���s�\�Z
                '----- �\���̂�
                '2021.08.11 UPGRADE S  AIT)dannnl
                'For Each Fld In Rs.Fields
                '	If IsDBNull(Fld.Name) = False And IsDBNull(Fld.Value) = False Then
                '		Select Case UCase(Fld.Name)
                '			Case "F01" : .KOUSYU_CD = Fld.Value '�H������
                '			Case "F02" : .KOUSYU_NO = Fld.Value '�H��ԍ�
                '			Case "F03" : .MEISYOU = Fld.Value '�H�햼
                '			Case "F20" : .YOSAN_GAKU = .YOSAN_GAKU + Fld.Value '���s�\�Z�i�O���ȊO�j�� ��Ɋz
                '			Case "F21" : G_YOSAN_GAKU = G_YOSAN_GAKU + Fld.Value '���s�\�Z�i�O���j
                '				'----- 2004/03/17 �ǉ� -------------------------------------------------------------
                '			Case "F31" : .J_YOSAN = .J_YOSAN + Fld.Value '���s�\�Z�i�O���ȊO�j
                '			Case "F32" : G_JIKOU_GAKU = G_JIKOU_GAKU + Fld.Value '���s�\�Z�i�O���j
                '				'-----------------------------------------------------------------------------------
                '			Case "F05" : .KINGAKU = .KINGAKU + Fld.Value '���ы��z�i���c�j
                '			Case "F06" : .RUIGAKU = .RUIGAKU + Fld.Value '���ї݌v
                '			Case "F07" : .KONGO_GAKU = .KONGO_GAKU + Fld.Value '���㌩��
                '			Case "F08" : .JISSI_GAKU = .JISSI_GAKU + Fld.Value '���{����
                '			Case "F09" : .TAIHI_GAKU = .TAIHI_GAKU + Fld.Value '�\�Z�Δ�
                '			Case "F10" : .ZOGEN_GAKU = .ZOGEN_GAKU + Fld.Value '�ύX����
                '			Case "F11" : G_KINGAKU = G_KINGAKU + Fld.Value '���ы��z�i�O���j
                '			Case "F12" : G_RUIGAKU = G_RUIGAKU + Fld.Value '���ї݌v
                '			Case "F13" : G_KONGO_GAKU = G_KONGO_GAKU + Fld.Value '���㌩��
                '			Case "F14" : G_JISSI_GAKU = G_JISSI_GAKU + Fld.Value '���{����
                '			Case "F15" : G_TAIHI_GAKU = G_TAIHI_GAKU + Fld.Value '�\�Z�Δ�
                '			Case "F16" : G_ZOGEN_GAKU = G_ZOGEN_GAKU + Fld.Value '�ύX����
                For Each Fld In Rs.Columns
                    Dim CellValue = Row(Fld.ColumnName)
                    If IsDBNull(Fld.ColumnName) = False And IsDBNull(CellValue) = False Then
                        Select Case UCase(Fld.ColumnName)
                            Case "F01" : .KOUSYU_CD = CellValue '�H������
                            Case "F02" : .KOUSYU_NO = CellValue '�H��ԍ�
                            Case "F03" : .MEISYOU = CellValue '�H�햼
                            Case "F20" : .YOSAN_GAKU = .YOSAN_GAKU + CellValue '���s�\�Z�i�O���ȊO�j�� ��Ɋz
                            Case "F21" : G_YOSAN_GAKU = G_YOSAN_GAKU + CellValue '���s�\�Z�i�O���j
                                '----- 2004/03/17 �ǉ� -------------------------------------------------------------
                            Case "F31" : .J_YOSAN = .J_YOSAN + CellValue '���s�\�Z�i�O���ȊO�j
                            Case "F32" : G_JIKOU_GAKU = G_JIKOU_GAKU + CellValue '���s�\�Z�i�O���j
                                '-----------------------------------------------------------------------------------
                            Case "F05" : .KINGAKU = .KINGAKU + CellValue '���ы��z�i���c�j
                            Case "F06" : .RUIGAKU = .RUIGAKU + CellValue '���ї݌v
                            Case "F07" : .KONGO_GAKU = .KONGO_GAKU + CellValue '���㌩��
                            Case "F08" : .JISSI_GAKU = .JISSI_GAKU + CellValue '���{����
                            Case "F09" : .TAIHI_GAKU = .TAIHI_GAKU + CellValue '�\�Z�Δ�
                            Case "F10" : .ZOGEN_GAKU = .ZOGEN_GAKU + CellValue '�ύX����
                            Case "F11" : G_KINGAKU = G_KINGAKU + CellValue '���ы��z�i�O���j
                            Case "F12" : G_RUIGAKU = G_RUIGAKU + CellValue '���ї݌v
                            Case "F13" : G_KONGO_GAKU = G_KONGO_GAKU + CellValue '���㌩��
                            Case "F14" : G_JISSI_GAKU = G_JISSI_GAKU + CellValue '���{����
                            Case "F15" : G_TAIHI_GAKU = G_TAIHI_GAKU + CellValue '�\�Z�Δ�
                            Case "F16" : G_ZOGEN_GAKU = G_ZOGEN_GAKU + CellValue '�ύX����
                                '2021.08.11 UPGRADE E
                        End Select
                    End If
                Next Fld
            End With
            Cnt2 = Cnt2 + 1
            '2021.08.11 UPGRADE S  AIT)dannnl
            '	Rs.MoveNext()
            'Loop

            'Rs.Close()
        Next

        Rs.Dispose()
        '2021.08.11 UPGRADE E
        Rs = Nothing

        '�W�v�����O�����z���wA-01�x�ɑ�������
        Pos = -1
        For lp = 0 To Cnt2 - 1
            If DT3(lp).KOUSYU_CD = "A" And DT3(lp).KOUSYU_NO = "01" Then
                Pos = lp
                Exit For
            End If
        Next lp

        '2005/08/11 �P�����z�ƔC�ӘJ�Ђ��Z�o
        TanGaku = GetCalcTankasa(NinGaku)
        TtlGaku = TanGaku + NinGaku
        ZenTanGaku = GetCalcTankasaZenMade(ZenNinGaku)
        ZenTtlGaku = ZenTanGaku + ZenNinGaku
        If TanGaku <> 0 Or NinGaku <> 0 Then
            ReDim Preserve DT2(Cnt)
            With DT2(Cnt)
                .KOUSYU_CD = "*" ' �H������
                .KOUSYU_NO = "00" ' �H��ԍ�
                .MEISYOU = "" ' �H�햼��
                .YOSAN_GAKU = 0 ' ���s�\�Z �� ��Ɋz
                '2013/12/10 �C�� ---------------------------------����������
                '.KINGAKU = 0                ' ���ы��z
                '.RUIGAKU = -TtlGaku         ' ���ї݌v
                .KINGAKU = -(TtlGaku - ZenTtlGaku) ' ���ы��z
                .RUIGAKU = -(ZenTtlGaku) ' ���ї݌v
                '-------------------------------------------------����������
                .KONGO_GAKU = 0 ' ���㌩��
                .JISSI_GAKU = -TtlGaku ' ���{����
                .TAIHI_GAKU = TtlGaku ' �\�Z�Δ�
                .ZOGEN_GAKU = 0 ' �ύX����
                .J_YOSAN = 0 ' ���s�\�Z
            End With
            Cnt = Cnt + 1
        End If
        '2005/08/11 �P�����z��ǉ�����
        If TanGaku <> 0 Then
            ReDim Preserve DT3(Cnt2)
            With DT3(Cnt2)
                .KOUSYU_CD = "*" '�H������
                .KOUSYU_NO = "*1" '�H��ԍ�
                .MEISYOU = "���P�����z��" '�H�햼��
                .YOSAN_GAKU = 0 '���s�\�Z
                '2013/12/10 �C�� ---------------------------------����������
                '.KINGAKU = 0                '���ы��z
                '.RUIGAKU = -TanGaku         '���ї݌v
                .KINGAKU = -(TanGaku - ZenTanGaku) '���ы��z
                .RUIGAKU = -(ZenTanGaku) '���ї݌v
                '-------------------------------------------------����������
                .KONGO_GAKU = 0 '���㌩��
                .JISSI_GAKU = -TanGaku '���{����
                .TAIHI_GAKU = TanGaku '�\�Z�Δ�
                .ZOGEN_GAKU = 0 '�ύX����
                .J_YOSAN = 0 '���s�\�Z
            End With
            Cnt2 = Cnt2 + 1
        End If
        '2005/08/11 �C�ӘJ�Ђ�ǉ�����
        If NinGaku <> 0 Then
            ReDim Preserve DT3(Cnt2)
            With DT3(Cnt2)
                .KOUSYU_CD = "*" '�H������
                .KOUSYU_NO = "*2" '�H��ԍ�
                '.MEISYOU = "���C�ӘJ�Ё�"    '�H�햼��
                .MEISYOU = "�����S�����" '�H�햼��
                .YOSAN_GAKU = 0 '���s�\�Z
                '2013/12/10 �C�� ---------------------------------����������
                '.KINGAKU = 0                '���ы��z
                '.RUIGAKU = -NinGaku         '���ї݌v
                .KINGAKU = -(NinGaku - ZenNinGaku) '���ы��z
                .RUIGAKU = -(ZenNinGaku) '���ї݌v
                '-------------------------------------------------����������
                .KONGO_GAKU = 0 '���㌩��
                .JISSI_GAKU = -NinGaku '���{����
                .TAIHI_GAKU = NinGaku '�\�Z�Δ�
                .ZOGEN_GAKU = 0 '�ύX����
                .J_YOSAN = 0 '���s�\�Z
            End With
            Cnt2 = Cnt2 + 1
        End If

        '***** 2003/02/21 �ǉ� ***********************************************************************
        ' �H������ ���O������ �̎擾
        Cnt4 = SelectGaichu(DT4)
        If Cnt4 < 0 Then Cnt4 = 0
        If Pos > -1 Then
            ReDim Preserve DT4(Cnt4)
            With DT4(Cnt4)
                .WARIDASI_NO = "00" ' ���o�ԍ�
                .WARIDASI_KB = "1" ' ���o�敪
                .MEISYOU = "���c�H��" ' ���o����
                .J_YOSAN = DT3(Pos).J_YOSAN ' ���s�\�Z
                .YOSAN_GAKU = DT3(Pos).YOSAN_GAKU ' ���s�\�Z �� ��Ɋz
                .KINGAKU = DT3(Pos).KINGAKU ' ���ы��z
                .RUIGAKU = DT3(Pos).RUIGAKU ' ���ї݌v
                .KONGO_GAKU = DT3(Pos).KONGO_GAKU ' ���㌩��
                .JISSI_GAKU = DT3(Pos).JISSI_GAKU ' ���{����
                .TAIHI_GAKU = DT3(Pos).TAIHI_GAKU ' �\�Z�Δ�
                .ZOGEN_GAKU = DT3(Pos).ZOGEN_GAKU ' �ύX����
            End With
            Cnt4 = Cnt4 + 1
        End If
        '*********************************************************************************************

        '/// �W�v�����O�����z���wA-01�x�ɑ�������
        If Pos > -1 Then
            With DT3(Pos)
                .J_YOSAN = .J_YOSAN + G_JIKOU_GAKU '���s�\�Z�i�O���j
                .YOSAN_GAKU = .YOSAN_GAKU + G_YOSAN_GAKU '���s�\�Z�i�O���j�� ��Ɋz
                .KINGAKU = .KINGAKU + G_KINGAKU '���ы��z�i�O���j
                .RUIGAKU = .RUIGAKU + G_RUIGAKU '���ї݌v
                .KONGO_GAKU = .KONGO_GAKU + G_KONGO_GAKU '���㌩��
                .JISSI_GAKU = .JISSI_GAKU + G_JISSI_GAKU '���{����
                .TAIHI_GAKU = .TAIHI_GAKU + G_TAIHI_GAKU '�\�Z�Δ�
                .ZOGEN_GAKU = .ZOGEN_GAKU + G_ZOGEN_GAKU '�ύX����
            End With
        End If

        '---------------------------------------------------------------------------------------------

        ' �v�����^�[�f�o�C�X�̓ǂݍ���
        Call INI_PRN_Read(1)

        ' �����ݒ�
        If PrnFirstD185() = False Then
            Exit Function
        End If

        For PrnModeNo = 1 To 2

            ' ����ʒu�̎擾
            Call PrXYGetD185()

            ' ������
            P_Cnt = 1 : pryy = YY(1)
            For lp = 1 To UBound(KOUMOKU_KEI)
                KOUMOKU_KEI(lp) = 0
            Next lp

            ' ���o����
            Call PrItemD185(pryy)
            '----- ���s
            pryy = pryy + ((P_YY * 1.5) * 7)
            ' �ꗗ�\��
            Bupyy = pryy
            Call PrItem2D185(pryy, DT(0))
            '----- ���s
            pryy = pryy + ((P_YY * 1.5) * 2)
            ' ����f�[�^��
            pryy = YY(1) + P_YY * 6.5
            Call PrDataD185(pryy, DT(0), ZDT(0))
            '----- ���s
            pryy = pryy + ((P_YY * 1.5) * 4.5)

            If PrnCancel = 1 Then
                '----- ���f
                Call PRN_ErrEnd()
                Exit Function
            End If

            lp2 = 0
            For lp = 0 To Cnt - 1
                If DT2(lp).KOUSYU_CD <> "*" Then
                    Call PrData2D185(pryy, DT2(lp))
                    '----- ���s
                    pryy = pryy + (P_YY * 1.5)
                    If PrnCancel = 1 Then
                        '----- ���f
                        Call PRN_ErrEnd()
                        Exit Function
                    End If
                End If
                Do Until DT3(lp2).KOUSYU_CD <> DT2(lp).KOUSYU_CD
                    '���y�[�W�`�F�b�N
                    '2021.08.11 UPGRADE S  AIT)dannnl
                    'GoSub NewPage
                    NewPage(pryy, DT, ZDT)
                    '2021.08.11 UPGRADE E

                    ' ����f�[�^���
                    Call PrData2D185(pryy, DT3(lp2))
                    '----- ���s
                    pryy = pryy + (P_YY * 1.5)
                    '***** 2003/02/21 �ǉ� *************************************************
                    If DT3(lp2).KOUSYU_CD = "A" And DT3(lp2).KOUSYU_NO = "01" Then
                        If Cnt4 > 0 Then Call PrData3D185(pryy, DT4, Cnt4)
                    End If
                    '***********************************************************************
                    lp2 = lp2 + 1
                    If lp2 = Cnt2 Then Exit Do
                Loop
                ' �e���ڋ��z���v����
                KOUMOKU_KEI(1) = KOUMOKU_KEI(1) + DT2(lp).YOSAN_GAKU
                KOUMOKU_KEI(2) = KOUMOKU_KEI(2) + DT2(lp).KINGAKU + DT2(lp).RUIGAKU
                KOUMOKU_KEI(3) = KOUMOKU_KEI(3) + DT2(lp).KONGO_GAKU
                KOUMOKU_KEI(4) = KOUMOKU_KEI(4) + DT2(lp).JISSI_GAKU
                KOUMOKU_KEI(5) = KOUMOKU_KEI(5) + DT2(lp).TAIHI_GAKU
                KOUMOKU_KEI(6) = KOUMOKU_KEI(6) + DT2(lp).ZOGEN_GAKU
                '----- 2004/03/17 �ǉ� --------------------------------
                KOUMOKU_KEI(7) = KOUMOKU_KEI(7) + DT2(lp).J_YOSAN
                '------------------------------------------------------
                '2013/12/10 �ǉ� -----------------------------------------����������
                KOUMOKU_KEI(8) = KOUMOKU_KEI(8) + DT2(lp).RUIGAKU
                KOUMOKU_KEI(9) = KOUMOKU_KEI(9) + DT2(lp).KINGAKU
                '---------------------------------------------------------����������
            Next lp

            '���y�[�W�`�F�b�N 2009/12/07 �ǉ�
            '2021.08.11 UPGRADE S  AIT)dannnl
            'GoSub NewPage
            NewPage(pryy, DT, ZDT)
            '2021.08.11 UPGRADE E

            ' �e���ڋ��z���v��
            Call PrDataGD185(pryy, KOUMOKU_KEI)

            If PrnModeNo = 1 Then
                '----- ���y�[�W
                Call PRN_NewPage()
            End If

        Next PrnModeNo

        ' ����t���O(�`�F�b�N���X�g)�̍X�V
        SQL = "UPDATE " & GAI_KIHON_DATA_TBLNAME
        SQL = SQL & " SET"
        SQL = SQL & " P_FLG_CHECK = '1'" ' ���FLG ����ؽ�
        SQL = SQL & " WHERE KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'" ' �H���ԍ�
        SQL = SQL & " AND EDA_NO = '" & KeyKouji.EDA_NO & "'" ' �H���}��
        SQL = SQL & " AND SIME_YM = '" & CtlKouji.SYORI_YM & "'" ' ���N��
        SQL = SQL & " AND NYUURYOKU_FLG = '01'" ' ���͒[���t���O(�y��"01")
        SQL = SQL & " AND P_FLG_CHECK <> '1'"

        ' SQL�����s
        '2021.08.11 UPGRADE S  AIT)dannnl
        'SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText + ADODB.ExecuteOptionEnum.adExecuteNoRecords)
        ExecSQL(SQL)
        '2021.08.11 UPGRADE E

        ' ����I��
        Call PRN_END()

        ' �v���r���[�\��
        If ViewFlg = True Then
            frmSYKD185.StatusBar1.Items.Item("Message").Text = ""
            ViewForm.ShowDialog()
        End If

        ' ����I��
        PrnMainD185 = True

        Exit Function

        '2021.08.11 UPGRADE DEL S  AIT)dannnl
        'NewPage:
        '        If NewPage_CHK(pryy, P_YY * 5) = False Then
        '            Call PRN_LINE(XX(2), pryy - (P_YY * 1.75), XX(2), pryy - (P_YY * 0.25), 20, "")
        '            '----- ���y�[�W
        '            Call PRN_NewPage()
        '            '----- �y�[�W���̍X�V
        '            P_Cnt = P_Cnt + 1
        '            '----- �󎚈ʒu�̃��Z�b�g
        '            pryy = YY(1)
        '            ' ���o����
        '            Call PrItemD185(pryy)
        '            '----- ���s
        '            pryy = pryy + ((P_YY * 1.5) * 7)
        '            ' �ꗗ�\��
        '            Bupyy = pryy
        '            Call PrItem2D185(pryy, DT(0))
        '            '----- ���s
        '            pryy = pryy + ((P_YY * 1.5) * 2)
        '            ' ����f�[�^��
        '            pryy = YY(1) + (P_YY * 6.5)
        '            Call PrDataD185(pryy, DT(0), ZDT(0))
        '            '----- ���s
        '            pryy = pryy + ((P_YY * 1.5) * 4.5)
        '        End If
        '        Return
        '2021.08.11 UPGRADE DEL E

    End Function

    '2021.08.11 UPGRADE ADD S  AIT)dannnl
    '-------------------------------------------------------------------------------
    '   ����    :   ���y�[�W�`�F�b�N
    '   �֐�    :   Sub NewPage()
    '   ����    :   pryy�@   Single
    '               DT()�@   GEPPOU_DATA_D_DBT
    '               ZDT()�@   GEPPOU_DATA_D_DBT
    '-------------------------------------------------------------------------------
    Private Sub NewPage(ByRef pryy As Single, ByRef DT() As GEPPOU_DATA_D_DBT, ByRef ZDT() As GEPPOU_DATA_D_DBT)
        If NewPage_CHK(pryy, P_YY * 5) = False Then
            Call PRN_LINE(XX(2), pryy - (P_YY * 1.75), XX(2), pryy - (P_YY * 0.25), 20, "")
            '----- ���y�[�W
            Call PRN_NewPage()
            '----- �y�[�W���̍X�V
            P_Cnt = P_Cnt + 1
            '----- �󎚈ʒu�̃��Z�b�g
            pryy = YY(1)
            ' ���o����
            Call PrItemD185(pryy)
            '----- ���s
            pryy = pryy + ((P_YY * 1.5) * 7)
            ' �ꗗ�\��
            Bupyy = pryy
            Call PrItem2D185(pryy, DT(0))
            '----- ���s
            pryy = pryy + ((P_YY * 1.5) * 2)
            ' ����f�[�^��
            pryy = YY(1) + (P_YY * 6.5)
            Call PrDataD185(pryy, DT(0), ZDT(0))
            '----- ���s
            pryy = pryy + ((P_YY * 1.5) * 4.5)
        End If
    End Sub
    '2021.08.11 UPGRADE ADD E

    '-------------------------------------------------------------------------------
    '   ����    :   �H������(�y��)  ���O������
    '   �֐�    :   Function SelectGaichu()
    '   ����    :   DT()�@   GEPPOU_LIST_GAI
    '   �ߒl    :   �ް���   ����I��
    '   �@�@        -1�@     �ُ�I��
    '-------------------------------------------------------------------------------
    Private Function SelectGaichu(ByRef DT() As GEPPOU_LIST_GAI) As Integer

        Dim QRY1 As String
        Dim QRY2 As String
        Dim QRY3 As String
        Dim SQL As String
        '2021.08.11 UPGRADE S  AIT)dannnl
        'Dim Rs As ADODB.Recordset
        'Dim Fld As ADODB.Field
        Dim Rs As New DataTable
        Dim Fld As DataColumn
        '2021.08.11 UPGRADE E
        Dim Cnt As Integer
        Dim OpenFlg As Short

        '2021.08.03 UPGRADE S  AIT)Tool Convert
        'On Error GoTo SelectGaichu_Err
        Try
            '2021.08.03 UPGRADE E

            ' �߂�l�̏�����
            SelectGaichu = -1

            ' QRY/SELECT���g��
            QRY1 = "(SELECT WARIDASI_NO, MEISYOU"
            QRY1 = QRY1 & " FROM WARIDASI_MAST"
            QRY1 = QRY1 & " WHERE EDA_NO = '" & KeyKouji.EDA_NO & "'"
            QRY1 = QRY1 & " AND KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"
            QRY1 = QRY1 & ") AS MASTDT"

            ' QRY/SELECT���g��
            QRY2 = "(SELECT WARIDASI_NO, WARIDASI_KB, KOUSYU_CD, KOUSYU_NO, MEISAI_NO,"
            QRY2 = QRY2 & " T_KINGAKU + G_KINGAKU AS YOSAN_GAKU,"
            '----- 2004/03/17 �ǉ� -------------------------------------
            QRY2 = QRY2 & " S_KINGAKU             AS JIKOU_GAKU"
            '-----------------------------------------------------------
            QRY2 = QRY2 & " FROM WARIDASI_DATA"
            QRY2 = QRY2 & " WHERE WARIDASI_KB = '2'"
            QRY2 = QRY2 & " AND EDA_NO = '" & KeyKouji.EDA_NO & "'"
            QRY2 = QRY2 & " AND KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"
            QRY2 = QRY2 & ") AS WARIDT"

            ' QRY/SELECT���g���i�O���j
            QRY3 = "(SELECT KOUSYU_CD, KOUSYU_NO, MEISAI_NO,"
            QRY3 = QRY3 & " JITU_GAKU, RUI_GAKU, KONGO_GAKU, JISSI_GAKU, TAIHI_GAKU, ZOUGEN_GAKU"
            QRY3 = QRY3 & " FROM DEKIDAKA_DATA"
            QRY3 = QRY3 & " WHERE SIME_YM = '" & CtlKouji.SYORI_YM & "'"
            QRY3 = QRY3 & " AND EDA_NO = '" & KeyKouji.EDA_NO & "'"
            QRY3 = QRY3 & " AND KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"
            QRY3 = QRY3 & ") AS DEKIDT"

            ' SQL/SELECT���g��
            SQL = "SELECT"
            SQL = SQL & " WARIDT.WARIDASI_NO      AS F01," ' ���o�ԍ�
            SQL = SQL & " MIN(MASTDT.MEISYOU)     AS F03," ' ���o����
            SQL = SQL & " SUM(WARIDT.YOSAN_GAKU)  AS F04," ' ���s�\�Z �� ��Ɋz
            '----- 2004/03/17 �ǉ� -------------------------------------------------------
            SQL = SQL & " SUM(WARIDT.JIKOU_GAKU)  AS F20," ' ���s�\�Z
            '-----------------------------------------------------------------------------
            SQL = SQL & " SUM(DEKIDT.JITU_GAKU)   AS F05," ' ���ы��z
            SQL = SQL & " SUM(DEKIDT.RUI_GAKU)    AS F06," ' ���ї݌v
            SQL = SQL & " SUM(DEKIDT.KONGO_GAKU)  AS F07," ' ���㌩��
            SQL = SQL & " SUM(DEKIDT.JISSI_GAKU)  AS F08," ' ���{����
            SQL = SQL & " SUM(DEKIDT.TAIHI_GAKU)  As F09," ' �\�Z�Δ�
            SQL = SQL & " SUM(DEKIDT.ZOUGEN_GAKU) As F10" ' �ύX����
            SQL = SQL & " FROM (" & QRY2
            SQL = SQL & " LEFT JOIN " & QRY3
            SQL = SQL & " ON (WARIDT.MEISAI_NO = DEKIDT.MEISAI_NO)"
            SQL = SQL & " AND (WARIDT.KOUSYU_NO = DEKIDT.KOUSYU_NO)"
            SQL = SQL & " AND (WARIDT.KOUSYU_CD = DEKIDT.KOUSYU_CD))"
            SQL = SQL & " LEFT JOIN " & QRY1
            SQL = SQL & " ON WARIDT.WARIDASI_NO = MASTDT.WARIDASI_NO"
            SQL = SQL & " GROUP BY WARIDT.WARIDASI_NO"
            SQL = SQL & " ORDER BY WARIDT.WARIDASI_NO"

            ' SQL�����s
            '2021.08.11 UPGRADE S  AIT)dannnl
            'Rs = SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText)
            Rs = RsOpen(SQL)
            '2021.08.11 UPGRADE E
            OpenFlg = 1

            Cnt = 0
            '2021.08.11 UPGRADE S  AIT)dannnl
            'Do Until Rs.EOF
            For Each Row As DataRow In Rs.Rows
                '2021.08.11 UPGRADE E
                ReDim Preserve DT(Cnt)
                With DT(Cnt)
                    '----- ������
                    .WARIDASI_NO = "" ' ���o�ԍ�
                    .WARIDASI_KB = "2" ' ���o�敪
                    .MEISYOU = "" ' ���o����
                    .YOSAN_GAKU = 0 ' ���s�\�Z �� ��Ɋz
                    .KINGAKU = 0 ' ���ы��z
                    .RUIGAKU = 0 ' ���ї݌v
                    .KONGO_GAKU = 0 ' ���㌩��
                    .JISSI_GAKU = 0 ' ���{����
                    .TAIHI_GAKU = 0 ' �\�Z�Δ�
                    .ZOGEN_GAKU = 0 ' �ύX����
                    .J_YOSAN = 0 ' ���s�\�Z

                    '----- �\���̂�
                    '2021.08.11 UPGRADE S  AIT)dannnl
                    'For Each Fld In Rs.Fields
                    '	If IsDBNull(Fld.Name) = False And IsDBNull(Fld.Value) = False Then
                    '		Select Case UCase(Fld.Name)
                    '			Case "F01" : .WARIDASI_NO = Fld.Value ' ���o�ԍ�
                    '			Case "F03" : .MEISYOU = Fld.Value ' ���o����
                    '			Case "F04" : .YOSAN_GAKU = Fld.Value ' ���s�\�Z �� ��Ɋz
                    '			'----- 2004/03/17 �ǉ� ----------------------------------------
                    '			Case "F20" : .J_YOSAN = Fld.Value ' ���s�\�Z
                    '			'--------------------------------------------------------------
                    '			Case "F05" : .KINGAKU = Fld.Value ' ���ы��z
                    '			Case "F06" : .RUIGAKU = Fld.Value ' ���ї݌v
                    '			Case "F07" : .KONGO_GAKU = Fld.Value ' ���㌩��
                    '			Case "F08" : .JISSI_GAKU = Fld.Value ' ���{����
                    '			Case "F09" : .TAIHI_GAKU = Fld.Value ' �\�Z�Δ�
                    '			Case "F10" : .ZOGEN_GAKU = Fld.Value ' �ύX����
                    For Each Fld In Rs.Columns
                        Dim CellValue = Row(Fld.ColumnName)
                        If IsDBNull(Fld.ColumnName) = False And IsDBNull(CellValue) = False Then
                            Select Case UCase(Fld.ColumnName)
                                Case "F01" : .WARIDASI_NO = CellValue ' ���o�ԍ�
                                Case "F03" : .MEISYOU = CellValue ' ���o����
                                Case "F04" : .YOSAN_GAKU = CellValue ' ���s�\�Z �� ��Ɋz
                                '----- 2004/03/17 �ǉ� ----------------------------------------
                                Case "F20" : .J_YOSAN = CellValue ' ���s�\�Z
                                '--------------------------------------------------------------
                                Case "F05" : .KINGAKU = CellValue ' ���ы��z
                                Case "F06" : .RUIGAKU = CellValue ' ���ї݌v
                                Case "F07" : .KONGO_GAKU = CellValue ' ���㌩��
                                Case "F08" : .JISSI_GAKU = CellValue ' ���{����
                                Case "F09" : .TAIHI_GAKU = CellValue ' �\�Z�Δ�
                                Case "F10" : .ZOGEN_GAKU = CellValue ' �ύX����
                                    '2021.08.11 UPGRADE E
                            End Select
                        End If
                    Next Fld
                End With
                Cnt = Cnt + 1
                '2021.08.11 UPGRADE S  AIT)dannnl
                '	Rs.MoveNext()
                'Loop

                'Rs.Close()
            Next

            Rs.Dispose()
            '2021.08.11 UPGRADE E
            Rs = Nothing

            ' �߂�l�̃Z�b�g
            SelectGaichu = Cnt
            Exit Function

            '2021.08.03 UPGRADE S  AIT)Tool Convert
            'SelectGaichu_Err:
        Catch ex As Exception
            '2021.08.03 UPGRADE E

            If OpenFlg = 1 Then
                '2021.08.11 UPGRADE S  AIT)dannnl
                'Rs.Close()
                Rs.Dispose()
                '2021.08.11 UPGRADE E	
            End If
            Rs = Nothing

            '2021.08.11 UPGRADE S  AIT)dannnl
            'Call Sql_Error_Msg("SelectGaichu")
            Call Sql_Error_Msg(ex, "SelectGaichu")
            '2021.08.11 UPGRADE E

        End Try     '2021.08.03 UPGRADE ADD AIT)Tool Convert
    End Function

    '-------------------------------------------------------------------------------
    '   ����    :   �����ݒ�
    '   �֐�    :   Sub     PrnFirstD185()
    '   ����    :   ����
    '   �ߒl    :   True    ����I��
    '   �@�@        False   �Y���Ȃ�
    '-------------------------------------------------------------------------------
    Private Function PrnFirstD185() As Boolean

        ' �߂�l�̏�����
        PrnFirstD185 = False

        ' �^�C�g���ݒ�
        DocName = "�H������(�y��)"

        ' �v�����^�[�f�o�C�X�̐ݒ�
        If Printer_Set(PRN1) = False Then
            '2021.09.14 UPGRADE S  AIT)dannnl
            'MsgBox("�ݒ�ɖ����v�����^�[�f�o�C�X���w�肳��܂����B")
            MsgBox("�ݒ�ɖ����v�����^�[�f�o�C�X���w�肳��܂����B", MsgBoxStyle.ApplicationModal, SYSTEMNM)
            '2021.09.14 UPGRADE E
            Exit Function
        End If

        ' �p���ݒ�
        '2021.08.19 UPGRADE S  AIT)dannnl
        'P_SIZE = PrinterObjectConstants.vbPRPSA4 ' �`�S
        'P_ORIENT = VSPrinter7Lib.OrientationSettings.orPortrait ' ��:orLandscape,�c:orPortrait
        P_SIZE = PaperKind.A4 ' �`�S
        P_ORIENT = OrientationEnum.Portrait ' ��:orLandscape,�c:orPortrait
        '2021.08.19 UPGRADE E
        F_SIZE = 12

        ' ����ďo��ʂ̃Z�b�g
        CallForm = frmSYKD185

        ' ��������ݒ�
        If PRN_First(ViewForm) = False Then
            '2021.09.14 UPGRADE S  AIT)dannnl
            'MsgBox("�v�����^�̐ݒ�Ɏ��s���܂����B", MsgBoxStyle.Exclamation)
            MsgBox("�v�����^�̐ݒ�Ɏ��s���܂����B", MsgBoxStyle.Exclamation, SYSTEMNM)
            '2021.09.14 UPGRADE E
            Exit Function
        End If

        ' ����I��
        PrnFirstD185 = True

    End Function

    '-------------------------------------------------------------------------------
    '   ����    :   ����ʒu�ݒ菈��
    '   �֐�    :   Sub PrXYGetD185()
    '   ����    :   ����
    '   �ߒl    :   ����
    '-------------------------------------------------------------------------------
    Private Sub PrXYGetD185()

        Dim PrLen As Short
        Dim xMargn As Short

        ' ���ڐ��̐ݒ�
        ReDim XX(10)
        ReDim YY(1)
        ReDim XX2(12)

        ' �����񒷂̎Z�o(PrLrn=104)
        PrLen = 0
        PrLen = PrLen + Len(Space(4)) ' �H�����ށ{�H��ԍ�
        PrLen = PrLen + Len(Space(40)) ' �H�햼��
        PrLen = PrLen + Len(Space(10)) ' ���s�\�Z
        PrLen = PrLen + Len(Space(10)) ' �݌v���{���z
        PrLen = PrLen + Len(Space(10)) ' ���㏊�v����
        PrLen = PrLen + Len(Space(10)) ' ���{�������z
        PrLen = PrLen + Len(Space(10)) ' �\�Z�Δ�
        PrLen = PrLen + Len(Space(10)) ' �ύX����

        ' �t�H���g�T�C�Y�̎Z�o
        xMargn = 9
        If PrnModeNo = 1 Then
            '2021.08.19 UPGRADE S  AIT)dannnl
            'F_SIZE = PRN_FontGet(P_XX * xMargn * 2, P_WIDTH, Basic_F, Space(PrLen))
            F_SIZE = PRN_FontGet(P_XX * xMargn * 2, P_WIDTH, Basic_F, New String(")", PrLen))
            '2021.08.19 UPGRADE E
        End If

        ' �P�������E�����̍Đݒ�
        '2021.08.19 UPGRADE S  AIT)dannnl
        'P_XX = PRN.TextWidth("M")
        'P_YY = PRN.TextHeight("M")
        P_XX = TextWidthToTwips("M")
        P_YY = TextHeightToTwips("M") + 6.2
        '2021.08.19 UPGRADE E

        ' ���ڈ󎚈ʒu�̐ݒ� Y��
        YY(0) = P_YY * 7
        YY(1) = YY(0) + P_YY * 1.5

        ' ���ڈ󎚈ʒu�̐ݒ� X��
        XX(0) = P_XX * xMargn ' �r�����[
        XX(1) = XX(0) + P_XX * 1 ' �H�����ށ{�H��ԍ�
        '2021.08.20 UPGRADE S  AIT)dannnl
        'XX(2) = XX(1) + P_XX * (4 + 4) ' �H�햼��
        'XX(3) = XX(2) + P_XX * (26 + 4) ' ���s�\�Z
        'XX(4) = XX(3) + P_XX * (10 + 4) ' ���s�\�Z�i��Ɋz�j
        'XX(5) = XX(4) + P_XX * (10 + 4) ' �݌v���{���z
        'XX(6) = XX(5) + P_XX * (10 + 4) ' ���㏊�v����
        'XX(7) = XX(6) + P_XX * (10 + 4) ' ���{�������z
        'XX(8) = XX(7) + P_XX * (10 + 4) ' �\�Z�Δ�
        'XX(9) = XX(8) + P_XX * (10 + 4) ' �ύX����
        'XX(10) = XX(9) + P_XX * (10 + 4) ' �r���E�[
        XX(2) = XX(1) + P_XX * (4 + 4.5) ' �H�햼��
        XX(3) = XX(2) + P_XX * (26 + 4.5) ' ���s�\�Z
        XX(4) = XX(3) + P_XX * (10 + 4.5) ' ���s�\�Z�i��Ɋz�j
        XX(5) = XX(4) + P_XX * (10 + 4.5) ' �݌v���{���z
        XX(6) = XX(5) + P_XX * (10 + 4.5) ' ���㏊�v����
        XX(7) = XX(6) + P_XX * (10 + 4.5) ' ���{�������z
        XX(8) = XX(7) + P_XX * (10 + 4.5) ' �\�Z�Δ�
        XX(9) = XX(8) + P_XX * (10 + 4.5) ' �ύX����
        XX(10) = XX(9) + P_XX * (10 + 4.5) ' �r���E�[
        '2021.08.20 UPGRADE E
        If PrnModeNo = 1 Then
            ' ���ڈ󎚈ʒu�̐ݒ� X��
            XX2(0) = P_XX * xMargn ' �r�����[
            XX2(1) = XX2(0) + P_XX * 1 ' �H�����ށ{�H��ԍ�
            '2021.08.20 UPGRADE S  AIT)dannnl
            'XX2(2) = XX2(1) + P_XX * (4 + 4) ' �H�햼��
            'XX2(3) = XX2(2) + P_XX * (26 + 4) ' ���s�\�Z
            'XX2(4) = XX2(3) + P_XX * (10 + 4) ' ���s�\�Z�i��Ɋz�j
            'XX2(5) = XX2(4) + P_XX * (10 + 4) ' �݌v���{���z
            'XX2(6) = XX2(5)
            'XX2(7) = XX2(6)
            'XX2(8) = XX2(7) + P_XX * (10 + 4) ' ���㏊�v����
            'XX2(9) = XX2(8) + P_XX * (10 + 4) ' ���{�������z
            'XX2(10) = XX2(9) + P_XX * (10 + 4) ' �\�Z�Δ�
            'XX2(11) = XX2(10) + P_XX * (10 + 4) ' �ύX����
            'XX2(12) = P_WIDTH - P_XX * xMargn ' �r���E�[
            XX2(2) = XX2(1) + P_XX * (4 + 4.5) ' �H�햼��
            XX2(3) = XX2(2) + P_XX * (26 + 4.5) ' ���s�\�Z
            XX2(4) = XX2(3) + P_XX * (10 + 4.5) ' ���s�\�Z�i��Ɋz�j
            XX2(5) = XX2(4) + P_XX * (10 + 4.5) ' �݌v���{���z
            XX2(6) = XX2(5)
            XX2(7) = XX2(6)
            XX2(8) = XX2(7) + P_XX * (10 + 4.5) ' ���㏊�v����
            XX2(9) = XX2(8) + P_XX * (10 + 4.5) ' ���{�������z
            XX2(10) = XX2(9) + P_XX * (10 + 4.5) ' �\�Z�Δ�
            XX2(11) = XX2(10) + P_XX * (10 + 4.5) ' �ύX����
            XX2(12) = XX2(11) + P_XX * (10 + 4.5) ' �r���E�[
            '2021.08.20 UPGRADE E
        Else
            ' ���ڈ󎚈ʒu�̐ݒ� X��
            XX2(0) = P_XX * xMargn ' �r�����[
            XX2(1) = XX2(0) + P_XX * 1 ' �H�����ށ{�H��ԍ�
            '2021.08.19 UPGRADE S  AIT)dannnl
            'XX2(2) = XX2(1) + P_XX * (4 + 4) ' �H�햼��
            'XX2(3) = XX2(2) + P_XX * (26 + 4) ' ���s�\�Z
            'XX2(4) = XX2(3) + P_XX * (10 + 4) ' ���s�\�Z�i��Ɋz�j
            'XX2(5) = XX2(4) + P_XX * (10 + 4) ' �O�񖘎��{���z
            'XX2(6) = XX2(5) + P_XX * (10 + 4) ' ������{���z
            'XX2(7) = XX2(6) + P_XX * (10 + 4) ' �݌v���{���z
            'XX2(8) = XX2(7) + P_XX * (10 + 4)
            'XX2(9) = XX2(8)
            'XX2(10) = XX2(9)
            'XX2(11) = XX2(10) + P_XX * (10 + 4)
            'XX2(12) = P_WIDTH - P_XX * xMargn ' �r���E�[
            XX2(2) = XX2(1) + P_XX * (4 + 4.5) ' �H�햼��
            XX2(3) = XX2(2) + P_XX * (26 + 4.5) ' ���s�\�Z
            XX2(4) = XX2(3) + P_XX * (10 + 4.5) ' ���s�\�Z�i��Ɋz�j
            XX2(5) = XX2(4) + P_XX * (10 + 4.5) ' �O�񖘎��{���z
            XX2(6) = XX2(5) + P_XX * (10 + 4.5) ' ������{���z
            XX2(7) = XX2(6) + P_XX * (10 + 4.5) ' �݌v���{���z
            XX2(8) = XX2(7) + P_XX * (10 + 4.5)
            XX2(9) = XX2(8)
            XX2(10) = XX2(9)
            XX2(11) = XX2(10) + P_XX * (10 + 4.5)
            XX2(12) = XX2(11) + P_XX * (10 + 4.5) ' �r���E�[
            '2021.08.20 UPGRADE E
        End If

    End Sub

    '-------------------------------------------------------------------------------
    '   ����    :   ���ڈ������(�y�[�W���o���`����f�[�^���o��)
    '   �֐�    :   Sub PrItemD185()
    '   ����    :   pryy    �󎚂x�ʒu
    '   �ߒl    :   �Ȃ�
    '-------------------------------------------------------------------------------

    Private Sub PrItemD185(ByRef pryy As Single)

        Dim PR_WK_Renamed As PR_WK
        Dim PR_Text As String : PR_Text = ""
        Dim PR_Xget As Object
        PR_Xget = ""
        Dim yMargn As Single
        Dim i As Short

        ' dummy
        PR_WK_Renamed.DT = ""
        PR_WK_Renamed.FS = F_SIZE
        PR_WK_Renamed.X = XX(0)
        PR_WK_Renamed.Y = YY(0)
        Call PRN_DATA(PR_WK_Renamed)

        '----- �]��
        yMargn = P_YY * 0.25

        '----- ����1
        ' (�O�g)
        Call PRN_LINE(XX(0), YY(0), XX(2) + (P_XX * (40)), YY(0), 20, "")
        Call PRN_LINE(XX(0), pryy + (P_YY * 5.75), XX(2) + (P_XX * (40)), pryy + (P_YY * 5.75), 20, "")
        Call PRN_LINE(XX(0), YY(0), XX(0), pryy + (P_YY * 5.75), 20, "")
        Call PRN_LINE(XX(2) + (P_XX * (40)), YY(0), XX(2) + (P_XX * (40)), pryy + (P_YY * 5.75), 20, "")
        '2003/03/17 ���z����p�́w���z�x�ƈ������
        ' �^�C�g��
        'PR_WK.DT = "�H������(���z)"     '���z����p
        PR_WK_Renamed.DT = "�H������(�y��)"
        PR_WK_Renamed.FS = 12
        '2021.08.19  UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(1, XX(0), XX(2) + (P_XX * (40)), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(1, XX(0), XX(2) + (P_XX * (40)), PR_WK_Renamed)
        '2021.08.19  UPGRADE E
        PR_WK_Renamed.Y = pryy + (P_YY * 0.75)
        Call PRN_DATA(PR_WK_Renamed, Nothing, Nothing, True)
        ' ����
        '2021.08.03 UPGRADE S  AIT)Tool Convert
        'PR_WK_Renamed.DT = VB6.Format(CtlKouji.SYORI_YM, "0000/00")
        PR_WK_Renamed.DT = CDec(CtlKouji.SYORI_YM).ToString("0000/00")
        '2021.08.03 UPGRADE E
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.19  UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(1, XX(0), XX(2) + (P_XX * (40)), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(1, XX(0), XX(2) + (P_XX * (40)), PR_WK_Renamed)
        '2021.08.19  UPGRADE E
        PR_WK_Renamed.Y = pryy + ((P_YY * 1.5) * 2) + yMargn
        Call PRN_DATA(PR_WK_Renamed)

        ' ����
        Call PRN_LINE(XX(4), YY(0), XX(UBound(XX)), YY(0), 20, "")
        Call PRN_LINE(XX(4), YY(1), XX(UBound(XX)), YY(1), 20, "")
        Call PRN_LINE(XX(4), pryy + (P_YY * 5.75), XX(UBound(XX)), pryy + (P_YY * 5.75), 20, "")

        For i = 0 To 8
            Call PRN_LINE(XX(4) + (((XX(UBound(XX)) - XX(4)) / 8) * i), YY(0), XX(4) + (((XX(UBound(XX)) - XX(4)) / 8) * i), pryy + (P_YY * 5.75), 20, "")
        Next i
        '----- ����
        For i = 0 To 7
            Select Case i
                Case 0 : PR_Text = Trim(GEPPOU01)
                Case 1 : PR_Text = Trim(GEPPOU02)
                Case 2 : PR_Text = Trim(GEPPOU03)
                Case 3 : PR_Text = Trim(GEPPOU04)
                Case 4 : PR_Text = Trim(GEPPOU05)
                Case 5 : PR_Text = Trim(GEPPOU06)
                Case 6 : PR_Text = Trim(GEPPOU07)
                Case 7 : PR_Text = Trim(GEPPOU08)
            End Select
            PR_WK_Renamed.DT = PR_Text
            PR_WK_Renamed.FS = F_SIZE - 1
            '2021.08.19  UPGRADE S  AIT)dannnl
            'PR_WK_Renamed.X = PRN_XGet(1, XX(4) + (((XX(UBound(XX)) - XX(4)) / 8) * i), XX(4) + (((XX(UBound(XX)) - XX(4)) / 8) * (i + 1)), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
            PRN_XGet(1, XX(4) + (((XX(UBound(XX)) - XX(4)) / 8) * i), XX(4) + (((XX(UBound(XX)) - XX(4)) / 8) * (i + 1)), PR_WK_Renamed)
            '2021.08.19  UPGRADE E
            PR_WK_Renamed.Y = YY(0) + yMargn
            Call PRN_DATA(PR_WK_Renamed)
        Next i

        '----- ���s
        pryy = pryy + (P_YY * 6.5)

        '----- ����5
        ' (�O�g)
        Call PRN_LINE(XX(0), pryy, XX(2) + (P_XX * (40)), pryy, 20, "")
        Call PRN_LINE(XX(0), pryy + (P_YY * 6), XX(2) + (P_XX * (40)), pryy + (P_YY * 6), 20, "")
        Call PRN_LINE(XX(0), pryy, XX(0), pryy + (P_YY * 6), 20, "")
        Call PRN_LINE(XX(2) + (P_XX * (40)), pryy, XX(2) + (P_XX * (40)), pryy + (P_YY * 6), 20, "")
        ' �H���ԍ��{�}��
        PR_Text = ""
        If CtlKouji.EDA_NO <> "0000" Then PR_Text = "-" & CtlKouji.EDA_NO & Space(1)
        PR_WK_Renamed.DT = "�H���ԍ��F" & CtlKouji.KOUJI_NO & PR_Text
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.19  UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(0, XX(0), XX(5), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(0, XX(0), XX(5), PR_WK_Renamed)
        '2021.08.19  UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' �H������
        PR_WK_Renamed.DT = Space(2) & GetNameKouji(CtlKouji.KOUJI_NO, CtlKouji.EDA_NO)
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.19  UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(0, XX(0), XX(5), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(0, XX(0), XX(5), PR_WK_Renamed)
        '2021.08.19  UPGRADE E
        PR_WK_Renamed.Y = pryy + ((P_YY * 1.5) * 2) + yMargn
        Call PRN_DATA(PR_WK_Renamed)

        '----- ����3
        ' (�O�g)
        Call PRN_LINE(XX(4) + (P_XX * (4)), pryy, XX(7), pryy, 20, "")
        Call PRN_LINE(XX(4) + (P_XX * (4)), pryy + (P_YY * 6), XX(7), pryy + (P_YY * 6), 20, "")
        Call PRN_LINE(XX(4) + (P_XX * (4)), pryy, XX(4) + (P_XX * (4)), pryy + (P_YY * 6), 20, "")
        Call PRN_LINE(XX(7), pryy, XX(7), pryy + (P_YY * 6), 20, "")

        PR_WK_Renamed.DT = "���{���z"
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.19  UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(1, XX(5), XX(6) + (P_XX * (4)), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(1, XX(5), XX(6) + (P_XX * (4)), PR_WK_Renamed)
        '2021.08.19  UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        PR_WK_Renamed.DT = "��"
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.19  UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(1, XX(6) + (P_XX * (4)), XX(7), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(1, XX(6) + (P_XX * (4)), XX(7), PR_WK_Renamed)
        '2021.08.19  UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)

        For i = 0 To 3
            Select Case i
                Case 2
                    Call PRN_LINE(XX(4) + (P_XX * (4)), pryy + ((P_YY * 1.5) * i), XX(7), pryy + ((P_YY * 1.5) * i), 1, "")
                Case Else
                    Call PRN_LINE(XX(4) + (P_XX * (4)), pryy + ((P_YY * 1.5) * i), XX(7), pryy + ((P_YY * 1.5) * i), 20, "")
            End Select
            PR_Text = ""
            Select Case i
                Case 1 : PR_Text = "�O��"
                Case 2 : PR_Text = "����"
                Case 3 : PR_Text = "�݌v"
            End Select
            PR_WK_Renamed.DT = PR_Text
            PR_WK_Renamed.FS = F_SIZE - 1
            '2021.08.19  UPGRADE S  AIT)dannnl
            'PR_WK_Renamed.X = PRN_XGet(1, XX(4) + (P_XX * (4)), XX(5), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
            PRN_XGet(1, XX(4) + (P_XX * (4)), XX(5), PR_WK_Renamed)
            '2021.08.19  UPGRADE E
            PR_WK_Renamed.Y = pryy + ((P_YY * 1.5) * i) + yMargn
            Call PRN_DATA(PR_WK_Renamed)
        Next i
        Call PRN_LINE(XX(5), pryy, XX(5), pryy + (P_YY * 6), 20, "")
        Call PRN_LINE(XX(6) + (P_XX * (4)), pryy, XX(6) + (P_XX * (4)), pryy + (P_YY * 6), 20, "")

        '--- ����4
        ' (�O�g)
        Call PRN_LINE(XX(7) + (P_XX * (4)), pryy, XX(10), pryy, 20, "")
        Call PRN_LINE(XX(7) + (P_XX * (4)), pryy + (P_YY * 6), XX(10), pryy + (P_YY * 6), 20, "")
        Call PRN_LINE(XX(7) + (P_XX * (4)), pryy, XX(7) + (P_XX * (4)), pryy + (P_YY * 6), 20, "")
        Call PRN_LINE(XX(10), pryy, XX(10), pryy + (P_YY * 6), 20, "")

        PR_WK_Renamed.DT = "�������o����"
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.19  UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(1, XX(8), XX(9) + (P_XX * (4)), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(1, XX(8), XX(9) + (P_XX * (4)), PR_WK_Renamed)
        '2021.08.19  UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        PR_WK_Renamed.DT = "��"
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.19  UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(1, XX(9) + (P_XX * (4)), XX(10), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(1, XX(9) + (P_XX * (4)), XX(10), PR_WK_Renamed)
        '2021.08.19  UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)

        For i = 0 To 3
            Select Case i
                Case 2
                    Call PRN_LINE(XX(7) + (P_XX * (4)), pryy + ((P_YY * 1.5) * i), XX(10), pryy + ((P_YY * 1.5) * i), 1, "")
                Case Else
                    Call PRN_LINE(XX(7) + (P_XX * (4)), pryy + ((P_YY * 1.5) * i), XX(10), pryy + ((P_YY * 1.5) * i), 20, "")
            End Select
            PR_Text = ""
            Select Case i
                Case 1 : PR_Text = "�O��"
                Case 2 : PR_Text = "����"
                Case 3 : PR_Text = "�݌v"
            End Select
            PR_WK_Renamed.DT = PR_Text
            PR_WK_Renamed.FS = F_SIZE - 1
            '2021.08.19  UPGRADE S  AIT)dannnl
            'PR_WK_Renamed.X = PRN_XGet(1, XX(7) + (P_XX * (4)), XX(8), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
            PRN_XGet(1, XX(7) + (P_XX * (4)), XX(8), PR_WK_Renamed)
            '2021.08.19  UPGRADE E
            PR_WK_Renamed.Y = pryy + ((P_YY * 1.5) * i) + yMargn
            Call PRN_DATA(PR_WK_Renamed)
        Next i
        Call PRN_LINE(XX(8), pryy, XX(8), pryy + (P_YY * 6), 20, "")
        Call PRN_LINE(XX(9) + (P_XX * (4)), pryy, XX(9) + (P_XX * (4)), pryy + (P_YY * 6), 20, "")

        '----- ���s
        pryy = pryy + (P_YY * 7)

        '----- ����5
        ' (�O�g)
        For i = 0 To 9
            Select Case i
                Case 0, 1, 2, 7, 8, 9
                    Call PRN_LINE(XX(0), pryy + ((P_YY * 1.5) * i), XX(6), pryy + ((P_YY * 1.5) * i), 20, "")
                Case Else
                    Call PRN_LINE(XX(0), pryy + ((P_YY * 1.5) * i), XX(6), pryy + ((P_YY * 1.5) * i), 1, "")
            End Select
            PR_Text = "" : PR_WK_Renamed.X = 0
            Select Case i
                Case 1
                    PR_Text = "����"
                    '2021.08.19 UPGRADE S  AIT)dannnl
                    'PR_Xget = PRN_XGet(1, XX(0), XX(2) + (P_XX * (12)), PR_WK_Renamed.FS, PR_Text)
                    PR_WK_Renamed.DT = PR_Text
                    PRN_XGet(1, XX(0), XX(2) + (P_XX * (12)), PR_WK_Renamed)
                    '2021.08.19 UPGRADE E
                Case 2, 3, 4, 5, 6
                    PR_Text = CStr(i - 1)
                    '2021.08.19 UPGRADE S  AIT)dannnl
                    'PR_Xget = PRN_XGet(1, XX(0), XX(1) + (P_XX * (3)), PR_WK_Renamed.FS, PR_Text)
                    PR_WK_Renamed.DT = PR_Text
                    PRN_XGet(1, XX(0), XX(1) + (P_XX * (3)), PR_WK_Renamed)
                    '2021.08.19 UPGRADE E
                Case 7
                    PR_Text = "���Z����"
                    '2021.08.19 UPGRADE S  AIT)dannnl
                    'PR_Xget = PRN_XGet(1, XX(0), XX(2) + (P_XX * (12)), PR_WK_Renamed.FS, PR_Text)
                    PR_WK_Renamed.DT = PR_Text
                    PRN_XGet(1, XX(0), XX(2) + (P_XX * (12)), PR_WK_Renamed)
                    '2021.08.19 UPGRADE E
                Case 8
                    PR_Text = "�O�����Z����"
                    '2021.08.19 UPGRADE S  AIT)dannnl
                    'PR_Xget = PRN_XGet(1, XX(0), XX(2) + (P_XX * (12)), PR_WK_Renamed.FS, PR_Text)
                    PR_WK_Renamed.DT = PR_Text
                    PRN_XGet(1, XX(0), XX(2) + (P_XX * (12)), PR_WK_Renamed)
                    '2021.08.19 UPGRADE E
                Case Else
                    '2021.08.19 UPGRADE S  AIT)dannnl
                    'PR_Xget = PRN_XGet(1, XX(0), XX(2) + (P_XX * (12)), PR_WK_Renamed.FS, PR_Text)
                    PR_WK_Renamed.DT = PR_Text
                    PRN_XGet(1, XX(0), XX(2) + (P_XX * (12)), PR_WK_Renamed)
                    '2021.08.19 UPGRADE E
            End Select
            PR_WK_Renamed.DT = PR_Text
            PR_WK_Renamed.FS = F_SIZE - 1
            'PR_WK_Renamed.X = Val(PR_Xget)�@�@�@�@�@'2021.08.19 UPGRADE DEL  AIT)dannnl
            PR_WK_Renamed.Y = pryy + yMargn + ((P_YY * 1.5) * i)
            Call PRN_DATA(PR_WK_Renamed)
        Next i

        Call PRN_LINE(XX(0), pryy, XX(0), pryy + ((P_YY * 1.5) * 9), 20, "")
        Call PRN_LINE(XX(1) + (P_XX * (3)), pryy + ((P_YY * 1.5) * 2), XX(1) + (P_XX * (3)), pryy + ((P_YY * 1.5) * 7), 1, "")
        Call PRN_LINE(XX(2) + (P_XX * (12)), pryy, XX(2) + (P_XX * (12)), pryy + ((P_YY * 1.5) * 9), 20, "")
        Call PRN_LINE(XX(2) + (P_XX * (28)), pryy, XX(2) + (P_XX * (28)), pryy + ((P_YY * 1.5) * 9), 20, "")
        Call PRN_LINE(XX(4), pryy, XX(4), pryy + ((P_YY * 1.5) * 9), 20, "")
        Call PRN_LINE(XX(5) + (P_XX * (2)), pryy, XX(5) + (P_XX * (2)), pryy + ((P_YY * 1.5) * 9), 20, "")
        Call PRN_LINE(XX(6), pryy, XX(6), pryy + ((P_YY * 1.5) * 9), 20, "")

        PR_WK_Renamed.DT = "�������z"
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.19  UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(1, XX(2) + (P_XX * (12)), XX(2) + (P_XX * (28)), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(1, XX(2) + (P_XX * (12)), XX(2) + (P_XX * (28)), PR_WK_Renamed)
        '2021.08.19  UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        PR_WK_Renamed.DT = "���s�\�Z�z"
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.19  UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(1, XX(2) + (P_XX * (28)), XX(4), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(1, XX(2) + (P_XX * (28)), XX(4), PR_WK_Renamed)
        '2021.08.19  UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        PR_WK_Renamed.DT = "�H�����v"
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.19  UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(1, XX(4), XX(5) + (P_XX * (2)), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(1, XX(4), XX(5) + (P_XX * (2)), PR_WK_Renamed)
        '2021.08.19  UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        PR_WK_Renamed.DT = "���v��"
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.19  UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(1, XX(5) + (P_XX * (2)), XX(6), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(1, XX(5) + (P_XX * (2)), XX(6), PR_WK_Renamed)
        '2021.08.19  UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)

        '----- ����6-1
        ' (�O�g)
        Call PRN_LINE(XX(6) + (P_XX * (2)), pryy, XX(6) + (P_XX * (2)), pryy + (P_YY * 3), 20, "")
        Call PRN_LINE(XX(8), pryy, XX(8), pryy + (P_YY * 3), 20, "")
        For i = 0 To 2
            Select Case i
                Case 1
                    Call PRN_LINE(XX(6) + (P_XX * (2)), pryy + ((P_YY * 1.5) * i), XX(8), pryy + ((P_YY * 1.5) * i), 1, "")
                Case Else
                    Call PRN_LINE(XX(6) + (P_XX * (2)), pryy + ((P_YY * 1.5) * i), XX(8), pryy + ((P_YY * 1.5) * i), 20, "")
            End Select
            PR_Text = ""
            Select Case i
                Case 1 : PR_Text = "���@�H"
                Case 2 : PR_Text = "�v�@�H"
            End Select
            PR_WK_Renamed.DT = PR_Text
            PR_WK_Renamed.FS = F_SIZE - 1
            '2021.08.19  UPGRADE S  AIT)dannnl
            'PR_WK_Renamed.X = PRN_XGet(1, XX(6) + (P_XX * (2)), XX(7), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
            PRN_XGet(1, XX(6) + (P_XX * (2)), XX(7), PR_WK_Renamed)
            '2021.08.19  UPGRADE E
            PR_WK_Renamed.Y = pryy + ((P_YY * 1.5) * (i - 1)) + yMargn
            Call PRN_DATA(PR_WK_Renamed)
        Next i
        Call PRN_LINE(XX(7), pryy, XX(7), pryy + (P_YY * 3), 20, "")

        '----- ����6-2
        Call PRN_LINE(XX(8) + (P_XX * (2)), pryy + (P_YY * 1.5), XX(8) + (P_XX * (2)), pryy + (P_YY * 3), 20, "")
        Call PRN_LINE(XX(10), pryy + (P_YY * 1.5), XX(10), pryy + (P_YY * 3), 20, "")
        ' (�O�g)
        For i = 1 To 2
            Call PRN_LINE(XX(8) + (P_XX * (2)), pryy + ((P_YY * 1.5) * i), XX(10), pryy + ((P_YY * 1.5) * i), 20, "")
        Next i
        Call PRN_LINE(XX(9), pryy + (P_YY * 1.5), XX(9), pryy + (P_YY * 3), 20, "")

        PR_WK_Renamed.DT = "�����\��"
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.19  UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(1, XX(8) + (P_XX * (2)), XX(9), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(1, XX(8) + (P_XX * (2)), XX(9), PR_WK_Renamed)
        '2021.08.19  UPGRADE E
        PR_WK_Renamed.Y = pryy + (P_YY * 1.5) + yMargn
        Call PRN_DATA(PR_WK_Renamed)

        '----- ���s
        pryy = pryy + (P_YY * 1.5)

        '----- ����7
        ' (�O�g)
        For i = 0 To 3
            If i <> 2 Then
                Call PRN_LINE(XX(6) + (P_XX * (2)), pryy + ((P_YY * 1.5) * (2 + i)), XX(10), pryy + ((P_YY * 1.5) * (2 + i)), 20, "")
            End If
        Next i
        Call PRN_LINE(XX(6) + (P_XX * (2)), pryy + ((P_YY * 1.5) * 2), XX(6) + (P_XX * (2)), pryy + ((P_YY * 1.5) * 5), 20, "")
        Call PRN_LINE(XX(10), pryy + ((P_YY * 1.5) * 2), XX(10), pryy + ((P_YY * 1.5) * 5), 20, "")

        PR_WK_Renamed.DT = Space(2) & "���̑�"
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.19  UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(0, XX(6) + (P_XX * (2)), XX(10), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(0, XX(6) + (P_XX * (2)), XX(10), PR_WK_Renamed)
        '2021.08.19  UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + ((P_YY * 1.5) * 2)
        Call PRN_DATA(PR_WK_Renamed)

        '----- ���s
        pryy = pryy + (P_YY * 1.5)

        '----- ����8
        ' (�O�g)
        For i = 0 To 2
            Call PRN_LINE(XX(6) + (P_XX * (2)), pryy + ((P_YY * 1.5) * (5 + i)), XX(10), pryy + ((P_YY * 1.5) * (5 + i)), 20, "")
        Next i
        Call PRN_LINE(XX(6) + (P_XX * (2)), pryy + ((P_YY * 1.5) * 5), XX(6) + (P_XX * (2)), pryy + ((P_YY * 1.5) * 7), 20, "")
        Call PRN_LINE(XX(7) + (P_XX * (6)), pryy + ((P_YY * 1.5) * 5), XX(7) + (P_XX * (6)), pryy + ((P_YY * 1.5) * 7), 20, "")
        Call PRN_LINE(XX(8) + (P_XX * (10)), pryy + ((P_YY * 1.5) * 5), XX(8) + (P_XX * (10)), pryy + ((P_YY * 1.5) * 7), 20, "")
        Call PRN_LINE(XX(10), pryy + ((P_YY * 1.5) * 5), XX(10), pryy + ((P_YY * 1.5) * 7), 20, "")

        PR_WK_Renamed.DT = "�扺�z"
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.19  UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(1, XX(6) + (P_XX * (2)), XX(7) + (P_XX * (6)), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(1, XX(6) + (P_XX * (2)), XX(7) + (P_XX * (6)), PR_WK_Renamed)
        '2021.08.19  UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + ((P_YY * 1.5) * 5)
        Call PRN_DATA(PR_WK_Renamed)
        PR_WK_Renamed.DT = "�扺�c��"
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.19  UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(1, XX(7) + (P_XX * (6)), XX(8) + (P_XX * (10)), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(1, XX(7) + (P_XX * (6)), XX(8) + (P_XX * (10)), PR_WK_Renamed)
        '2021.08.19  UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + ((P_YY * 1.5) * 5)
        Call PRN_DATA(PR_WK_Renamed)
        PR_WK_Renamed.DT = "�����w�͖ڕW"
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.19  UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(1, XX(8) + (P_XX * (10)), XX(10), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(1, XX(8) + (P_XX * (10)), XX(10), PR_WK_Renamed)
        '2021.08.19  UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + ((P_YY * 1.5) * 5)
        Call PRN_DATA(PR_WK_Renamed)

        ' ���f
        If PrnCancel = 1 Then Exit Sub

    End Sub

    '-------------------------------------------------------------------------------
    '   ����    :   ���ڈ������(�\�g�E���ڌ��o��)
    '   �֐�    :   Sub PrItem2D185()
    '   ����    :   pryy    �󎚂x�ʒu
    '   �@�@        DT()    GEPPOU_DATA_D_DBT
    '   �ߒl    :   �Ȃ�
    '-------------------------------------------------------------------------------
    Private Sub PrItem2D185(ByRef pryy As Single, ByRef DT As GEPPOU_DATA_D_DBT)

        Dim PR_WK_Renamed As PR_WK
        Dim PR_Text As String
        'Dim PR_Xget As Object�@�@�@�@�@'2021.08.11 UPGRADE DEL  AIT)dannnl
        Dim yMargn As Single
        Dim i As Short

        '----- �]��
        yMargn = P_YY * 0.25

        '----- ���s
        pryy = pryy + (P_YY * 0.75)

        '----- ����
        For i = 0 To PageDataDnt
            Select Case i
                Case 1
                    '
                Case 0, 2, PageDataDnt - 1, PageDataDnt
                    Call PRN_LINE(XX2(0), pryy + ((P_YY * 1.5) * i), XX2(UBound(XX2)), pryy + ((P_YY * 1.5) * i), 20, "")
                Case Else
                    Call PRN_LINE(XX2(0), pryy + ((P_YY * 1.5) * i), XX2(UBound(XX2)), pryy + ((P_YY * 1.5) * i), 1, "")
            End Select
        Next i
        Call PRN_LINE(XX2(0), pryy, XX2(0), pryy + ((P_YY * 1.5) * PageDataDnt), 20, "")
        Call PRN_LINE(XX2(2), pryy + ((P_YY * 1.5) * 2), XX2(2), pryy + ((P_YY * 1.5) * (PageDataDnt - 1)), 20, "")

        For i = 3 To UBound(XX2)
            '2021.08.19 UPGRADE DEL S  AIT)phongdv
            'If i <> UBound(XX2) Then
            'Else
            '    Call PRN_LINE(XX2(i) - P_XX * 5, pryy, XX2(i) - P_XX * 5, pryy + ((P_YY * 1.5) * PageDataDnt), 20, "")
            'End If
'2021.08.19 UPGRADE DEL E

            Call PRN_LINE(XX2(i), pryy, XX2(i), pryy + ((P_YY * 1.5) * PageDataDnt), 20, "")

            '(�󎚕����F1�s��)
            PR_Text = ""
            If PrnModeNo = 1 Then
                Select Case i
                    Case 3 : PR_Text = "�H�����"
                    Case 4 : PR_Text = "���s�\�Z"
                    Case 5 : PR_Text = "��Ɋz ���� �@�@"
                    Case 8 : PR_Text = "�݌v���{���z"
                    Case 9 : PR_Text = "���㏊�v����"
                    Case 10 : PR_Text = "���{�������z"
                    Case 11 : PR_Text = "�\�Z�Δ�"
                    Case 12 : PR_Text = "�ύX����"
                End Select
            Else
                Select Case i
                    Case 3 : PR_Text = "�H�����"
                    Case 4 : PR_Text = "���s�\�Z"
                    Case 5 : PR_Text = "��Ɋz ���� �@�@"
                    Case 6 : PR_Text = "�O�񖘎��{���z"
                    Case 7 : PR_Text = "������{���z"
                    Case 8 : PR_Text = "�݌v���{���z"
                End Select
            End If

            PR_WK_Renamed.DT = PR_Text
            PR_WK_Renamed.FS = F_SIZE - 1
            If i = 5 Then
                PR_WK_Renamed.FS = F_SIZE - 1.5
            End If

            '(X���W)
            If i = 3 Then
                '2021.08.19 UPGRADE S  AIT)dannnl
                'PR_WK_Renamed.X = PRN_XGet(1, XX2(0), XX2(3), PR_WK_Renamed.FS, PR_Text)
                PRN_XGet(1, XX2(0), XX2(3), PR_WK_Renamed)
                '2021.08.19 UPGRADE E
            Else
                '2021.08.19 UPGRADE S  AIT)dannnl
                'PR_WK_Renamed.X = PRN_XGet(1, XX2(i - 1), XX2(i), PR_WK_Renamed.FS, PR_Text)
                If i = 5 Then PRN_XGet(0, XX2(i - 1), XX2(i), PR_WK_Renamed) Else PRN_XGet(1, XX2(i - 1), XX2(i), PR_WK_Renamed)
                '2021.08.19 UPGRADE E
            End If

            '(Y���W)
            If i = 5 Then
                PR_WK_Renamed.Y = pryy + yMargn + (P_YY * 0.4)
                Call PRN_DATA(PR_WK_Renamed)

                PR_WK_Renamed.DT = "�@�@�@��ɗ\��z"
                '2021.08.19 UPGRADE S  AIT)dannnl
                'PR_WK_Renamed.X = PRN_XGet(1, XX2(i - 1), XX2(i), PR_WK_Renamed.FS, PR_Text)
                PRN_XGet(1, XX2(i - 1), XX2(i), PR_WK_Renamed)
                '2021.08.19 UPGRADE E
                PR_WK_Renamed.Y = pryy + yMargn + (P_YY * 1.4)
                Call PRN_DATA(PR_WK_Renamed)

                If DT.SYOUNIN_FLG = "1" Then
                    PR_WK_Renamed.DT = "(���F)"
                    '2021.08.19 UPGRADE S  AIT)dannnl
                    'PR_WK_Renamed.X = PRN_XGet(0, XX2(i - 1), XX2(i), PR_WK_Renamed.FS, PR_Text)
                    PRN_XGet(0, XX2(i - 1), XX2(i), PR_WK_Renamed)
                    '2021.08.19 UPGRADE E
                    PR_WK_Renamed.Y = pryy + yMargn + (P_YY * 1.65)
                    Call PRN_DATA(PR_WK_Renamed)
                End If
            Else
                PR_WK_Renamed.Y = pryy + yMargn + (P_YY * 0.75)
                Call PRN_DATA(PR_WK_Renamed)
            End If
        Next i

        ' ���f
        If PrnCancel = 1 Then Exit Sub

    End Sub

    '-------------------------------------------------------------------------------
    '   ����    :   ����f�[�^�������
    '   �֐�    :   Sub PrDataD185()
    '   ����    :   pryy    �󎚂x�ʒu
    '   �@�@        DT()    GEPPOU_DATA_D_DBT
    '   �ߒl    :   �Ȃ�
    '-------------------------------------------------------------------------------
    Private Sub PrDataD185(ByRef pryy As Single, ByRef DT As GEPPOU_DATA_D_DBT, ByRef ZDT As GEPPOU_DATA_D_DBT)

        Dim PR_WK_Renamed As PR_WK
        Dim PR_Text As String
        Dim yMargn As Single

        '----- �]��
        yMargn = P_YY * 0.25

        '----- ����3�f�[�^
        ' �O�񖘎��{���z
        If DT.ZEN_JISSI_GAKU <> 0 Then
            '2021.08.11 UPGRADE S  AIT)dannnl
            'PR_WK_Renamed.DT = VB6.Format(DT.ZEN_JISSI_GAKU, "#,###,###,##0")
            PR_WK_Renamed.DT = DT.ZEN_JISSI_GAKU.ToString("#,###,###,##0")
            '2021.08.11 UPGRADE E
        Else
            PR_WK_Renamed.DT = ""
        End If
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.19  UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(2, XX(5), XX(6) + (P_XX * (4)), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(5), XX(6) + (P_XX * (4)), PR_WK_Renamed)
        '2021.08.19  UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + (P_YY * 1.5)
        Call PRN_DATA(PR_WK_Renamed)
        ' �������{���z
        '2021.08.11 UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.DT = VB6.Format(DT.KON_JISSI_GAKU, "#,###,###,##0")
        PR_WK_Renamed.DT = DT.KON_JISSI_GAKU.ToString("#,###,###,##0")
        '2021.08.11 UPGRADE E
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.19  UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(2, XX(5), XX(6) + (P_XX * (4)), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(5), XX(6) + (P_XX * (4)), PR_WK_Renamed)
        '2021.08.19  UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + ((P_YY * 1.5) * 2)
        Call PRN_DATA(PR_WK_Renamed)
        ' �݌v���{���z
        '2021.08.11 UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.DT = VB6.Format(DT.JISSI_KEI, "#,###,###,##0")
        PR_WK_Renamed.DT = DT.JISSI_KEI.ToString("#,###,###,##0")
        '2021.08.11 UPGRADE E
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.19  UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(2, XX(5), XX(6) + (P_XX * (4)), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(5), XX(6) + (P_XX * (4)), PR_WK_Renamed)
        '2021.08.19  UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + ((P_YY * 1.5) * 3)
        Call PRN_DATA(PR_WK_Renamed)
        ' ��
        PR_Text = CStr(0)
        If DT.JISSI_KEI <> 0 And DT.K_YOSAN_GAKU <> 0 Then
            '2021.08.03 UPGRADE S  AIT)Tool Convert
            'PR_Text = VB6.Format((DT.JISSI_KEI / DT.K_YOSAN_GAKU) * 100, "##0.00")
            PR_Text = CDec((DT.JISSI_KEI / DT.K_YOSAN_GAKU) * 100).ToString("##0.00")
            '2021.08.03 UPGRADE E
        End If
        PR_WK_Renamed.DT = PR_Text
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.19  UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(2, XX(6) + (P_XX * (4)), XX(7), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(6) + (P_XX * (4)), XX(7), PR_WK_Renamed)
        '2021.08.19  UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + ((P_YY * 1.5) * 3)
        Call PRN_DATA(PR_WK_Renamed)

        '----- ����4�f�[�^
        ' �O�񖘐����o����
        If DT.ZEN_UKE_GAKU <> 0 Then
            '2021.08.11 UPGRADE S  AIT)dannnl
            'PR_WK_Renamed.DT = VB6.Format(DT.ZEN_UKE_GAKU, "#,###,###,##0")
            PR_WK_Renamed.DT = DT.ZEN_UKE_GAKU.ToString("#,###,###,##0")
            '2021.08.11 UPGRADE E
        Else
            PR_WK_Renamed.DT = ""
        End If
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.19  UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(2, XX(8), XX(9) + (P_XX * (4)), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(8), XX(9) + (P_XX * (4)), PR_WK_Renamed)
        '2021.08.19  UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + (P_YY * 1.5)
        Call PRN_DATA(PR_WK_Renamed)
        ' ���񐿕��o����
        '2021.08.11 UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.DT = VB6.Format(DT.KON_UKE_GAKU, "#,###,###,##0")
        PR_WK_Renamed.DT = DT.KON_UKE_GAKU.ToString("#,###,###,##0")
        '2021.08.11 UPGRADE E
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.19  UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(2, XX(8), XX(9) + (P_XX * (4)), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(8), XX(9) + (P_XX * (4)), PR_WK_Renamed)
        '2021.08.19  UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + ((P_YY * 1.5) * 2)
        Call PRN_DATA(PR_WK_Renamed)
        ' �������o����
        '2021.08.11 UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.DT = VB6.Format(DT.DEKI_GAKU, "#,###,###,##0")
        PR_WK_Renamed.DT = DT.DEKI_GAKU.ToString("#,###,###,##0")
        '2021.08.11 UPGRADE E
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.19  UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(2, XX(8), XX(9) + (P_XX * (4)), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(8), XX(9) + (P_XX * (4)), PR_WK_Renamed)
        '2021.08.19  UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + ((P_YY * 1.5) * 3)
        Call PRN_DATA(PR_WK_Renamed)
        ' ��
        PR_Text = CStr(0)
        If DT.DEKI_GAKU <> 0 And DT.K_UKEOI_GAKU <> 0 Then
            '2021.08.03 UPGRADE S  AIT)Tool Convert
            'PR_Text = VB6.Format((DT.DEKI_GAKU / DT.K_UKEOI_GAKU) * 100, "##0.00")
            PR_Text = CDec((DT.DEKI_GAKU / DT.K_UKEOI_GAKU) * 100).ToString("##0.00")
            '2021.08.03 UPGRADE E
        End If
        PR_WK_Renamed.DT = PR_Text
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.19  UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(2, XX(9) + (P_XX * (4)), XX(10), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(9) + (P_XX * (4)), XX(10), PR_WK_Renamed)
        '2021.08.19  UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + ((P_YY * 1.5) * 3)
        Call PRN_DATA(PR_WK_Renamed)

        '----- ���s
        pryy = pryy + ((P_YY * 1.5) * 4.75)

        '----- ����5�f�[�^
        ' �������z(����)
        '2021.08.11 UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.DT = VB6.Format(DT.T_UKEOI_GAKU, "#,###,###,##0")
        PR_WK_Renamed.DT = DT.T_UKEOI_GAKU.ToString("#,###,###,##0")
        '2021.08.11 UPGRADE E
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.19  UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(2, XX(2) + (P_XX * (12)), XX(2) + (P_XX * (28)), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(2) + (P_XX * (12)), XX(2) + (P_XX * (28)), PR_WK_Renamed)
        '2021.08.19  UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + (P_YY * 1.5)
        Call PRN_DATA(PR_WK_Renamed)
        ' ���s�\�Z(����)
        '2021.08.11 UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.DT = VB6.Format(DT.T_YOSAN_GAKU, "#,###,###,##0")
        PR_WK_Renamed.DT = DT.T_YOSAN_GAKU.ToString("#,###,###,##0")
        '2021.08.11 UPGRADE E
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.19  UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(2, XX(2) + (P_XX * (28)), XX(4), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(2) + (P_XX * (28)), XX(4), PR_WK_Renamed)
        '2021.08.19  UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + (P_YY * 1.5)
        Call PRN_DATA(PR_WK_Renamed)
        ' �H�����v(����)
        '2021.08.11 UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.DT = VB6.Format(DT.T_RIEKI_GAKU, "#,###,###,##0")
        PR_WK_Renamed.DT = DT.T_RIEKI_GAKU.ToString("#,###,###,##0")
        '2021.08.11 UPGRADE E
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.19  UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(2, XX(4), XX(5) + (P_XX * (2)), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(4), XX(5) + (P_XX * (2)), PR_WK_Renamed)
        '2021.08.19  UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + (P_YY * 1.5)
        Call PRN_DATA(PR_WK_Renamed)
        ' ���v��(����)
        If DT.T_RIEKI_GAKU <> 0 And DT.T_UKEOI_GAKU <> 0 Then
            '2021.08.03 UPGRADE S  AIT)Tool Convert
            'PR_Text = VB6.Format((DT.T_RIEKI_GAKU / DT.T_UKEOI_GAKU) * 100, "##0.00")
            PR_Text = CDec((DT.T_RIEKI_GAKU / DT.T_UKEOI_GAKU) * 100).ToString("##0.00")
            '2021.08.03 UPGRADE E
        Else
            PR_Text = "0.00"
        End If
        PR_WK_Renamed.DT = PR_Text
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.19  UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(2, XX(5) + (P_XX * (2)), XX(6), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(5) + (P_XX * (2)), XX(6), PR_WK_Renamed)
        '2021.08.19  UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + (P_YY * 1.5)
        Call PRN_DATA(PR_WK_Renamed)
        ' �������z(�P)
        If DT.H1_UKEOI_GAKU <> 0 Then
            '2021.08.11 UPGRADE S  AIT)dannnl
            'PR_Text = VB6.Format(DT.H1_UKEOI_GAKU, "#,###,###,##0")
            PR_Text = DT.H1_UKEOI_GAKU.ToString("#,###,###,##0")
            '2021.08.11 UPGRADE E
        Else
            PR_Text = ""
        End If
        PR_WK_Renamed.DT = PR_Text
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.19  UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(2, XX(2) + (P_XX * (12)), XX(2) + (P_XX * (28)), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(2) + (P_XX * (12)), XX(2) + (P_XX * (28)), PR_WK_Renamed)
        '2021.08.19  UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + ((P_YY * 1.5) * 2)
        Call PRN_DATA(PR_WK_Renamed)
        ' ���l(�P)
        If Trim(DT.H1_BIKOU) <> "" Then
            PR_Text = DT.H1_BIKOU
        Else
            PR_Text = ""
        End If
        PR_WK_Renamed.DT = PR_Text
        '2021.08.19  UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(0, XX(1) + (P_XX * (3)), XX(2), PR_WK_Renamed.FS, PR_Text)
        PRN_XGet(0, XX(1) + (P_XX * (3)), XX(3), PR_WK_Renamed)
        '2021.08.19  UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + ((P_YY * 1.5) * 2)
        Call PRN_DATA(PR_WK_Renamed)
        ' ���s�\�Z(�P)
        If DT.H1_YOSAN_GAKU <> 0 Then
            '2021.08.11 UPGRADE S  AIT)dannnl
            'PR_Text = VB6.Format(DT.H1_YOSAN_GAKU, "#,###,###,##0")
            PR_Text = DT.H1_YOSAN_GAKU.ToString("#,###,###,##0")
            '2021.08.11 UPGRADE E
        Else
            PR_Text = ""
        End If
        PR_WK_Renamed.DT = PR_Text
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.19  UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(2, XX(2) + (P_XX * (28)), XX(4), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(2) + (P_XX * (28)), XX(4), PR_WK_Renamed)
        '2021.08.19  UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + ((P_YY * 1.5) * 2)
        Call PRN_DATA(PR_WK_Renamed)
        ' �H�����v(�P)
        If DT.H1_RIEKI_GAKU <> 0 Then
            '2021.08.11 UPGRADE S  AIT)dannnl
            'PR_Text = VB6.Format(DT.H1_RIEKI_GAKU, "#,###,###,##0")
            PR_Text = DT.H1_RIEKI_GAKU.ToString("#,###,###,##0")
            '2021.08.11 UPGRADE E
        Else
            PR_Text = ""
        End If
        PR_WK_Renamed.DT = PR_Text
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.19  UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(2, XX(4), XX(5) + (P_XX * (2)), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(4), XX(5) + (P_XX * (2)), PR_WK_Renamed)
        '2021.08.19  UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + ((P_YY * 1.5) * 2)
        Call PRN_DATA(PR_WK_Renamed)
        ' ���v��(�P)
        If DT.H1_UKEOI_GAKU <> 0 And DT.H1_RIEKI_GAKU <> 0 Then
            '2021.08.03 UPGRADE S  AIT)Tool Convert
            'PR_WK_Renamed.DT = VB6.Format((DT.H1_RIEKI_GAKU / DT.H1_UKEOI_GAKU) * 100, "##0.00")
            PR_WK_Renamed.DT = CDec((DT.H1_RIEKI_GAKU / DT.H1_UKEOI_GAKU) * 100).ToString("##0.00")
            '2021.08.03 UPGRADE E
        Else
            PR_WK_Renamed.DT = ""
        End If
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.19  UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(2, XX(5) + (P_XX * (2)), XX(6), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(5) + (P_XX * (2)), XX(6), PR_WK_Renamed)
        '2021.08.19  UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + ((P_YY * 1.5) * 2)
        Call PRN_DATA(PR_WK_Renamed)
        ' ���l(�Q)
        If Trim(DT.H2_BIKOU) <> "" Then
            PR_Text = DT.H2_BIKOU
        Else
            PR_Text = ""
        End If
        PR_WK_Renamed.DT = PR_Text
        '2021.08.19 UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(0, XX(1) + (P_XX * (3)), XX(2), PR_WK_Renamed.FS, PR_Text)
        PRN_XGet(0, XX(1) + (P_XX * (3)), XX(3), PR_WK_Renamed)
        '2021.08.19 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + ((P_YY * 1.5) * 3)
        Call PRN_DATA(PR_WK_Renamed)
        ' �������z(�Q)
        If DT.H2_UKEOI_GAKU <> 0 Then
            '2021.08.11 UPGRADE S  AIT)dannnl
            'PR_Text = VB6.Format(DT.H2_UKEOI_GAKU, "#,###,###,##0")
            PR_Text = DT.H2_UKEOI_GAKU.ToString("#,###,###,##0")
            '2021.08.11 UPGRADE E
        Else
            PR_Text = ""
        End If
        PR_WK_Renamed.DT = PR_Text
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.19  UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(2, XX(2) + (P_XX * (12)), XX(2) + (P_XX * (28)), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(2) + (P_XX * (12)), XX(2) + (P_XX * (28)), PR_WK_Renamed)
        '2021.08.19  UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + ((P_YY * 1.5) * 3)
        Call PRN_DATA(PR_WK_Renamed)
        ' ���s�\�Z(�Q)
        If DT.H2_YOSAN_GAKU <> 0 Then
            '2021.08.11 UPGRADE S  AIT)dannnl
            'PR_Text = VB6.Format(DT.H2_YOSAN_GAKU, "#,###,###,##0")
            PR_Text = DT.H2_YOSAN_GAKU.ToString("#,###,###,##0")
            '2021.08.11 UPGRADE E
        Else
            PR_Text = ""
        End If
        PR_WK_Renamed.DT = PR_Text
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.19  UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(2, XX(2) + (P_XX * (28)), XX(4), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(2) + (P_XX * (28)), XX(4), PR_WK_Renamed)
        '2021.08.19  UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + ((P_YY * 1.5) * 3)
        Call PRN_DATA(PR_WK_Renamed)
        ' �H�����v(�Q)
        If DT.H2_RIEKI_GAKU <> 0 Then
            '2021.08.11 UPGRADE S  AIT)dannnl
            'PR_Text = VB6.Format(DT.H2_RIEKI_GAKU, "#,###,###,##0")
            PR_Text = DT.H2_RIEKI_GAKU.ToString("#,###,###,##0")
            '2021.08.11 UPGRADE E
        Else
            PR_Text = ""
        End If
        PR_WK_Renamed.DT = PR_Text
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.19  UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(2, XX(4), XX(5) + (P_XX * (2)), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(4), XX(5) + (P_XX * (2)), PR_WK_Renamed)
        '2021.08.19  UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + ((P_YY * 1.5) * 3)
        Call PRN_DATA(PR_WK_Renamed)
        ' ���v��(�Q)
        If DT.H2_UKEOI_GAKU <> 0 And DT.H2_RIEKI_GAKU <> 0 Then
            '2021.08.03 UPGRADE S  AIT)Tool Convert
            'PR_Text = VB6.Format((DT.H2_RIEKI_GAKU / DT.H2_UKEOI_GAKU) * 100, "##0.00")
            PR_Text = CDec((DT.H2_RIEKI_GAKU / DT.H2_UKEOI_GAKU) * 100).ToString("##0.00")
            '2021.08.03 UPGRADE E
        Else
            PR_Text = ""
        End If
        PR_WK_Renamed.DT = PR_Text
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.19  UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(2, XX(5) + (P_XX * (2)), XX(6), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(5) + (P_XX * (2)), XX(6), PR_WK_Renamed)
        '2021.08.19  UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + ((P_YY * 1.5) * 3)
        Call PRN_DATA(PR_WK_Renamed)
        ' ���l(�R)
        If Trim(DT.H3_BIKOU) <> "" Then
            PR_Text = DT.H3_BIKOU
        Else
            PR_Text = ""
        End If
        PR_WK_Renamed.DT = PR_Text
        '2021.08.19 UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(0, XX(1) + (P_XX * (3)), XX(2), PR_WK_Renamed.FS, PR_Text)
        PRN_XGet(0, XX(1) + (P_XX * (3)), XX(3), PR_WK_Renamed)
        '2021.08.19 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + ((P_YY * 1.5) * 4)
        Call PRN_DATA(PR_WK_Renamed)
        ' �������z(�R)
        If DT.H3_UKEOI_GAKU <> 0 Then
            '2021.08.11 UPGRADE S  AIT)dannnl
            'PR_Text = VB6.Format(DT.H3_UKEOI_GAKU, "#,###,###,##0")
            PR_Text = DT.H3_UKEOI_GAKU.ToString("#,###,###,##0")
            '2021.08.11 UPGRADE E
        Else
            PR_Text = ""
        End If
        PR_WK_Renamed.DT = PR_Text
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.19  UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(2, XX(2) + (P_XX * (12)), XX(2) + (P_XX * (28)), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(2) + (P_XX * (12)), XX(2) + (P_XX * (28)), PR_WK_Renamed)
        '2021.08.19  UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + ((P_YY * 1.5) * 4)
        Call PRN_DATA(PR_WK_Renamed)
        ' ���s�\�Z(�R)
        If DT.H3_YOSAN_GAKU <> 0 Then
            '2021.08.11 UPGRADE S  AIT)dannnl
            'PR_Text = VB6.Format(DT.H3_YOSAN_GAKU, "#,###,###,##0")
            PR_Text = DT.H3_YOSAN_GAKU.ToString("#,###,###,##0")
            '2021.08.11 UPGRADE E
        Else
            PR_Text = ""
        End If
        PR_WK_Renamed.DT = PR_Text
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.19  UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(2, XX(2) + (P_XX * (28)), XX(4), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(2) + (P_XX * (28)), XX(4), PR_WK_Renamed)
        '2021.08.19  UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + ((P_YY * 1.5) * 4)
        Call PRN_DATA(PR_WK_Renamed)
        ' �H�����v(�R)
        If DT.H3_RIEKI_GAKU <> 0 Then
            '2021.08.11 UPGRADE S  AIT)dannnl
            'PR_Text = VB6.Format(DT.H3_RIEKI_GAKU, "#,###,###,##0")
            PR_Text = DT.H3_RIEKI_GAKU.ToString("#,###,###,##0")
            '2021.08.11 UPGRADE E
        Else
            PR_Text = ""
        End If
        PR_WK_Renamed.DT = PR_Text
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.19  UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(2, XX(4), XX(5) + (P_XX * (2)), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(4), XX(5) + (P_XX * (2)), PR_WK_Renamed)
        '2021.08.19  UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + ((P_YY * 1.5) * 4)
        Call PRN_DATA(PR_WK_Renamed)
        ' ���v��(�R)
        If DT.H3_UKEOI_GAKU <> 0 And DT.H3_RIEKI_GAKU <> 0 Then
            '2021.08.03 UPGRADE S  AIT)Tool Convert
            'PR_Text = VB6.Format((DT.H3_RIEKI_GAKU / DT.H3_UKEOI_GAKU) * 100, "##0.00")
            PR_Text = CDec((DT.H3_RIEKI_GAKU / DT.H3_UKEOI_GAKU) * 100).ToString("##0.00")
            '2021.08.03 UPGRADE E
        Else
            PR_Text = ""
        End If
        PR_WK_Renamed.DT = PR_Text
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.19  UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(2, XX(5) + (P_XX * (2)), XX(6), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(5) + (P_XX * (2)), XX(6), PR_WK_Renamed)
        '2021.08.19  UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + ((P_YY * 1.5) * 4)
        Call PRN_DATA(PR_WK_Renamed)
        ' ���l(�S)
        If Trim(DT.H4_BIKOU) <> "" Then
            PR_Text = DT.H4_BIKOU
        Else
            PR_Text = ""
        End If
        PR_WK_Renamed.DT = PR_Text
        '2021.08.19 UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(0, XX(1) + (P_XX * (3)), XX(2), PR_WK_Renamed.FS, PR_Text)
        PRN_XGet(0, XX(1) + (P_XX * (3)), XX(3), PR_WK_Renamed)
        '2021.08.19 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + ((P_YY * 1.5) * 5)
        Call PRN_DATA(PR_WK_Renamed)
        ' �������z(�S)
        If DT.H4_UKEOI_GAKU <> 0 Then
            '2021.08.11 UPGRADE S  AIT)dannnl
            'PR_Text = VB6.Format(DT.H4_UKEOI_GAKU, "#,###,###,##0")
            PR_Text = DT.H4_UKEOI_GAKU.ToString("#,###,###,##0")
            '2021.08.11 UPGRADE E
        Else
            PR_Text = ""
        End If
        PR_WK_Renamed.DT = PR_Text
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.19  UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(2, XX(2) + (P_XX * (12)), XX(2) + (P_XX * (28)), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(2) + (P_XX * (12)), XX(2) + (P_XX * (28)), PR_WK_Renamed)
        '2021.08.19  UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + ((P_YY * 1.5) * 5)
        Call PRN_DATA(PR_WK_Renamed)
        ' ���s�\�Z(�S)
        If DT.H4_YOSAN_GAKU <> 0 Then
            '2021.08.11 UPGRADE S  AIT)dannnl
            'PR_Text = VB6.Format(DT.H4_YOSAN_GAKU, "#,###,###,##0")
            PR_Text = DT.H4_YOSAN_GAKU.ToString("#,###,###,##0")
            '2021.08.11 UPGRADE E
        Else
            PR_Text = ""
        End If
        PR_WK_Renamed.DT = PR_Text
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.19  UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(2, XX(2) + (P_XX * (28)), XX(4), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(2) + (P_XX * (28)), XX(4), PR_WK_Renamed)
        '2021.08.19  UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + ((P_YY * 1.5) * 5)
        Call PRN_DATA(PR_WK_Renamed)
        ' �H�����v(�S)
        If DT.H4_RIEKI_GAKU <> 0 Then
            '2021.08.11 UPGRADE S  AIT)dannnl
            'PR_Text = VB6.Format(DT.H4_RIEKI_GAKU, "#,###,###,##0")
            PR_Text = DT.H4_RIEKI_GAKU.ToString("#,###,###,##0")
            '2021.08.11 UPGRADE E
        Else
            PR_Text = ""
        End If
        PR_WK_Renamed.DT = PR_Text
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.19  UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(2, XX(4), XX(5) + (P_XX * (2)), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(4), XX(5) + (P_XX * (2)), PR_WK_Renamed)
        '2021.08.19  UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + ((P_YY * 1.5) * 5)
        Call PRN_DATA(PR_WK_Renamed)
        ' ���v��(�S)
        If DT.H4_UKEOI_GAKU <> 0 And DT.H4_RIEKI_GAKU <> 0 Then
            '2021.08.03 UPGRADE S  AIT)Tool Convert
            'PR_Text = VB6.Format((DT.H4_RIEKI_GAKU / DT.H4_UKEOI_GAKU) * 100, "##0.00")
            PR_Text = CDec((DT.H4_RIEKI_GAKU / DT.H4_UKEOI_GAKU) * 100).ToString("##0.00")
            '2021.08.03 UPGRADE E
        Else
            PR_Text = ""
        End If
        PR_WK_Renamed.DT = PR_Text
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.19  UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(2, XX(5) + (P_XX * (2)), XX(6), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(5) + (P_XX * (2)), XX(6), PR_WK_Renamed)
        '2021.08.19  UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + ((P_YY * 1.5) * 5)
        Call PRN_DATA(PR_WK_Renamed)
        ' ���l(�T)
        If Trim(DT.H5_BIKOU) <> "" Then
            PR_Text = DT.H5_BIKOU
        Else
            PR_Text = ""
        End If
        PR_WK_Renamed.DT = PR_Text
        '2021.08.19 UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(0, XX(1) + (P_XX * (3)), XX(2), PR_WK_Renamed.FS, PR_Text)
        PRN_XGet(0, XX(1) + (P_XX * (3)), XX(3), PR_WK_Renamed)
        '2021.08.19 UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + ((P_YY * 1.5) * 6)
        Call PRN_DATA(PR_WK_Renamed)
        ' �������z(�T)
        If DT.H5_UKEOI_GAKU <> 0 Then
            '2021.08.11 UPGRADE S  AIT)dannnl
            'PR_Text = VB6.Format(DT.H5_UKEOI_GAKU, "#,###,###,##0")
            PR_Text = DT.H5_UKEOI_GAKU.ToString("#,###,###,##0")
            '2021.08.11 UPGRADE E
        Else
            PR_Text = ""
        End If
        PR_WK_Renamed.DT = PR_Text
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.19  UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(2, XX(2) + (P_XX * (12)), XX(2) + (P_XX * (28)), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(2) + (P_XX * (12)), XX(2) + (P_XX * (28)), PR_WK_Renamed)
        '2021.08.19  UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + ((P_YY * 1.5) * 6)
        Call PRN_DATA(PR_WK_Renamed)
        ' ���s�\�Z(�T)
        If DT.H5_YOSAN_GAKU <> 0 Then
            '2021.08.11 UPGRADE S  AIT)dannnl
            'PR_Text = VB6.Format(DT.H5_YOSAN_GAKU, "#,###,###,##0")
            PR_Text = DT.H5_YOSAN_GAKU.ToString("#,###,###,##0")
            '2021.08.11 UPGRADE E
        Else
            PR_Text = ""
        End If
        PR_WK_Renamed.DT = PR_Text
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.19  UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(2, XX(2) + (P_XX * (28)), XX(4), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(2) + (P_XX * (28)), XX(4), PR_WK_Renamed)
        '2021.08.19  UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + ((P_YY * 1.5) * 6)
        Call PRN_DATA(PR_WK_Renamed)
        ' �H�����v(�T)
        If DT.H5_RIEKI_GAKU <> 0 Then
            '2021.08.11 UPGRADE S  AIT)dannnl
            'PR_Text = VB6.Format(DT.H5_RIEKI_GAKU, "#,###,###,##0")
            PR_Text = DT.H5_RIEKI_GAKU.ToString("#,###,###,##0")
            '2021.08.11 UPGRADE E
        Else
            PR_Text = ""
        End If
        PR_WK_Renamed.DT = PR_Text
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.19  UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(2, XX(4), XX(5) + (P_XX * (2)), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(4), XX(5) + (P_XX * (2)), PR_WK_Renamed)
        '2021.08.19  UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + ((P_YY * 1.5) * 6)
        Call PRN_DATA(PR_WK_Renamed)
        ' ���v��(�T)
        If DT.H5_UKEOI_GAKU <> 0 And DT.H5_RIEKI_GAKU <> 0 Then
            '2021.08.03 UPGRADE S  AIT)Tool Convert
            'PR_Text = VB6.Format((DT.H5_RIEKI_GAKU / DT.H5_UKEOI_GAKU) * 100, "##0.00")
            PR_Text = CDec((DT.H5_RIEKI_GAKU / DT.H5_UKEOI_GAKU) * 100).ToString("##0.00")
            '2021.08.03 UPGRADE E
        Else
            PR_Text = ""
        End If
        PR_WK_Renamed.DT = PR_Text
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.19  UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(2, XX(5) + (P_XX * (2)), XX(6), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(5) + (P_XX * (2)), XX(6), PR_WK_Renamed)
        '2021.08.19  UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + ((P_YY * 1.5) * 6)
        Call PRN_DATA(PR_WK_Renamed)
        ' �������z(���Z����)
        '2021.08.11 UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.DT = VB6.Format(DT.K_UKEOI_GAKU, "#,###,###,##0")
        PR_WK_Renamed.DT = DT.K_UKEOI_GAKU.ToString("#,###,###,##0")
        '2021.08.11 UPGRADE E
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.19  UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(2, XX(2) + (P_XX * (12)), XX(2) + (P_XX * (28)), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(2) + (P_XX * (12)), XX(2) + (P_XX * (28)), PR_WK_Renamed)
        '2021.08.19  UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + ((P_YY * 1.5) * 7)
        Call PRN_DATA(PR_WK_Renamed)
        ' ���s�\�Z(���Z����)
        '2021.08.11 UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.DT = VB6.Format(DT.K_YOSAN_GAKU, "#,###,###,##0")
        PR_WK_Renamed.DT = DT.K_YOSAN_GAKU.ToString("#,###,###,##0")
        '2021.08.11 UPGRADE E
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.19  UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(2, XX(2) + (P_XX * (28)), XX(4), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(2) + (P_XX * (28)), XX(4), PR_WK_Renamed)
        '2021.08.19  UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + ((P_YY * 1.5) * 7)
        Call PRN_DATA(PR_WK_Renamed)
        ' �H�����v(���Z����)
        '2021.08.11 UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.DT = VB6.Format(DT.K_RIEKI_GAKU, "#,###,###,##0")
        PR_WK_Renamed.DT = DT.K_RIEKI_GAKU.ToString("#,###,###,##0")
        '2021.08.11 UPGRADE E
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.19  UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(2, XX(4), XX(5) + (P_XX * (2)), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(4), XX(5) + (P_XX * (2)), PR_WK_Renamed)
        '2021.08.19  UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + ((P_YY * 1.5) * 7)
        Call PRN_DATA(PR_WK_Renamed)
        ' ���v��(���Z����)
        If DT.K_RIEKI_GAKU <> 0 And DT.K_UKEOI_GAKU <> 0 Then
            '2021.08.03 UPGRADE S  AIT)Tool Convert
            'PR_Text = VB6.Format((DT.K_RIEKI_GAKU / DT.K_UKEOI_GAKU) * 100, "##0.00")
            PR_Text = CDec((DT.K_RIEKI_GAKU / DT.K_UKEOI_GAKU) * 100).ToString("##0.00")
            '2021.08.03 UPGRADE E
        Else
            PR_Text = "0.00"
        End If
        PR_WK_Renamed.DT = PR_Text
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.19  UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(2, XX(5) + (P_XX * (2)), XX(6), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(5) + (P_XX * (2)), XX(6), PR_WK_Renamed)
        '2021.08.19  UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + ((P_YY * 1.5) * 7)
        Call PRN_DATA(PR_WK_Renamed)
        ' �������z(�O�����Z����)
        If ZDT.K_UKEOI_GAKU <> 0 Then
            '2021.08.11 UPGRADE S  AIT)dannnl
            'PR_WK_Renamed.DT = VB6.Format(ZDT.K_UKEOI_GAKU, "#,###,###,##0")
            PR_WK_Renamed.DT = ZDT.K_UKEOI_GAKU.ToString("#,###,###,##0")
            '2021.08.11 UPGRADE E
        Else
            PR_WK_Renamed.DT = ""
        End If
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.19  UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(2, XX(2) + (P_XX * (12)), XX(2) + (P_XX * (28)), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(2) + (P_XX * (12)), XX(2) + (P_XX * (28)), PR_WK_Renamed)
        '2021.08.19  UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + ((P_YY * 1.5) * 8)
        Call PRN_DATA(PR_WK_Renamed)
        ' ���s�\�Z(�O�����Z����)
        If ZDT.K_YOSAN_GAKU <> 0 Then
            '2021.08.11 UPGRADE S  AIT)dannnl
            'PR_WK_Renamed.DT = VB6.Format(ZDT.K_YOSAN_GAKU, "#,###,###,##0")
            PR_WK_Renamed.DT = ZDT.K_YOSAN_GAKU.ToString("#,###,###,##0")
            '2021.08.11 UPGRADE E
        Else
            PR_WK_Renamed.DT = ""
        End If
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.19  UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(2, XX(2) + (P_XX * (28)), XX(4), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(2) + (P_XX * (28)), XX(4), PR_WK_Renamed)
        '2021.08.19  UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + ((P_YY * 1.5) * 8)
        Call PRN_DATA(PR_WK_Renamed)
        ' �H�����v(�O�����Z����)
        If ZDT.K_RIEKI_GAKU <> 0 Then
            '2021.08.11 UPGRADE S  AIT)dannnl
            'PR_WK_Renamed.DT = VB6.Format(ZDT.K_RIEKI_GAKU, "#,###,###,##0")
            PR_WK_Renamed.DT = ZDT.K_RIEKI_GAKU.ToString("#,###,###,##0")
            '2021.08.11 UPGRADE E
        Else
            PR_WK_Renamed.DT = ""
        End If
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.19  UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(2, XX(4), XX(5) + (P_XX * (2)), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(4), XX(5) + (P_XX * (2)), PR_WK_Renamed)
        '2021.08.19  UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + ((P_YY * 1.5) * 8)
        Call PRN_DATA(PR_WK_Renamed)
        ' ���v��(�O�����Z����)
        If ZDT.K_RIEKI_GAKU <> 0 And ZDT.K_UKEOI_GAKU <> 0 Then
            '2021.08.03 UPGRADE S  AIT)Tool Convert
            'PR_Text = VB6.Format((ZDT.K_RIEKI_GAKU / ZDT.K_UKEOI_GAKU) * 100, "##0.00")
            PR_Text = CDec((ZDT.K_RIEKI_GAKU / ZDT.K_UKEOI_GAKU) * 100).ToString("##0.00")
            '2021.08.03 UPGRADE E
        Else
            PR_Text = ""
        End If
        PR_WK_Renamed.DT = PR_Text
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.19  UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(2, XX(5) + (P_XX * (2)), XX(6), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(5) + (P_XX * (2)), XX(6), PR_WK_Renamed)
        '2021.08.19  UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + ((P_YY * 1.5) * 8)
        Call PRN_DATA(PR_WK_Renamed)

        '--- ����6�f�[�^
        ' �H���i���H�j
        '2021.08.03 UPGRADE S  AIT)Tool Convert
        'PR_WK_Renamed.DT = VB6.Format(DT.KOUKI_S_YMD, "0000/00/00")
        If Not String.IsNullOrEmpty(DT.KOUKI_S_YMD) Then
            PR_WK_Renamed.DT = Val(DT.KOUKI_S_YMD).ToString("0000/00/00")
        End If
        '2021.08.03 UPGRADE E
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.19  UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(1, XX(7), XX(8), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(1, XX(7), XX(8), PR_WK_Renamed)
        '2021.08.19  UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        ' �H���i�v�H�j
        '2021.08.03 UPGRADE S  AIT)Tool Convert
        'PR_WK_Renamed.DT = VB6.Format(DT.KOUKI_E_YMD, "0000/00/00")
        If Not String.IsNullOrEmpty(DT.KOUKI_E_YMD) Then
            PR_WK_Renamed.DT = Val(DT.KOUKI_E_YMD).ToString("0000/00/00")
        End If
        '2021.08.03 UPGRADE E
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.19  UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(1, XX(7), XX(8), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(1, XX(7), XX(8), PR_WK_Renamed)
        '2021.08.19  UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + (P_YY * 1.5)
        Call PRN_DATA(PR_WK_Renamed)
        ' �H���i�����j
        '2021.08.03 UPGRADE S  AIT)Tool Convert
        'PR_WK_Renamed.DT = VB6.Format(DT.KOUKI_K_YMD, "0000/00/00")
        If Not String.IsNullOrEmpty(DT.KOUKI_K_YMD) Then
            PR_WK_Renamed.DT = Val(DT.KOUKI_K_YMD).ToString("0000/00/00")
        End If
        '2021.08.03 UPGRADE E
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.19  UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(1, XX(9), XX(10), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(1, XX(9), XX(10), PR_WK_Renamed)
        '2021.08.19  UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + (P_YY * 1.5)
        Call PRN_DATA(PR_WK_Renamed)

        '----- ���s
        pryy = pryy + ((P_YY * 1.5) * 2) + (P_YY * 1.5)

        '----- ����7�f�[�^
        ' ���l�P
        PR_WK_Renamed.DT = DT.BIKOU1
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.19  UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(0, XX(6) + (P_XX * (2)), XX(10), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(0, XX(6) + (P_XX * (2)), XX(10), PR_WK_Renamed)
        '2021.08.19  UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + (P_YY * 1.5)
        Call PRN_DATA(PR_WK_Renamed)
        ' ���l�Q
        PR_WK_Renamed.DT = DT.BIKOU2
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.19  UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(0, XX(6) + (P_XX * (2)), XX(10), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(0, XX(6) + (P_XX * (2)), XX(10), PR_WK_Renamed)
        '2021.08.19  UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + ((P_YY * 1.5) * 2)
        Call PRN_DATA(PR_WK_Renamed)

        '----- ���s
        pryy = pryy + ((P_YY * 1.5) * 3) + (P_YY * 1.5)

        '----- ����8�f�[�^
        ' �扺�z
        '2021.08.11 UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.DT = VB6.Format(DT.TORISAGE_GAKU, "#,###,###,##0")
        PR_WK_Renamed.DT = DT.TORISAGE_GAKU.ToString("#,###,###,##0")
        '2021.08.11 UPGRADE E
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.19  UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(2, XX(6) + (P_XX * (2)), XX(7) + (P_XX * (6)), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(6) + (P_XX * (2)), XX(7) + (P_XX * (6)), PR_WK_Renamed)
        '2021.08.19  UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + (P_YY * 1.5)
        Call PRN_DATA(PR_WK_Renamed)
        ' �扺�c�z
        '2021.08.11 UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.DT = VB6.Format(DT.TORI_ZAN_GAKU, "#,###,###,##0")
        PR_WK_Renamed.DT = DT.TORI_ZAN_GAKU.ToString("#,###,###,##0")
        '2021.08.11 UPGRADE E
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.19  UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(2, XX(7) + (P_XX * (6)), XX(8) + (P_XX * (10)), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(7) + (P_XX * (6)), XX(8) + (P_XX * (10)), PR_WK_Renamed)
        '2021.08.19  UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + (P_YY * 1.5)
        Call PRN_DATA(PR_WK_Renamed)
        ' �����w�͖ڕW
        '2021.08.11 UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.DT = VB6.Format(DT.MOKU_GAKU, "#,###,###,##0")
        PR_WK_Renamed.DT = DT.MOKU_GAKU.ToString("#,###,###,##0")
        '2021.08.11 UPGRADE E
        PR_WK_Renamed.FS = F_SIZE - 1
        '2021.08.19  UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(2, XX(8) + (P_XX * (10)), XX(10), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX(8) + (P_XX * (10)), XX(10), PR_WK_Renamed)
        '2021.08.19  UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn + (P_YY * 1.5)
        Call PRN_DATA(PR_WK_Renamed)

    End Sub

    '-------------------------------------------------------------------------------
    '   ����    :   ����f�[�^(�H���)�������
    '   �֐�    :   Sub PrDataD185()
    '   ����    :   pryy    ����x�ʒu
    '   �@�@        DT2()   GEPPOU_LIST_SUB
    '   �ߒl    :   �Ȃ�
    '-------------------------------------------------------------------------------
    Private Sub PrData2D185(ByRef pryy As Single, ByRef DT2 As GEPPOU_LIST_SUB)

        Dim PR_WK_Renamed As PR_WK
        Dim PR_Text As String
        Dim yMargn As Single

        '----- �]��
        yMargn = P_YY * 0.25

        ' �H������
        If DT2.KOUSYU_CD <> "*" Then
            PR_Text = ""
            If DT2.KOUSYU_NO <> "00" Then PR_Text = "�@"
            PR_WK_Renamed.DT = PR_Text & Trim(DT2.KOUSYU_CD) & "-" & DT2.KOUSYU_NO
            PR_WK_Renamed.FS = F_SIZE
            '2021.08.19  UPGRADE S  AIT)dannnl
            'PR_WK_Renamed.X = PRN_XGet(0, XX2(1), XX2(2), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
            PRN_XGet(0, XX2(1), XX2(2), PR_WK_Renamed)
            '2021.08.19  UPGRADE E
            PR_WK_Renamed.Y = pryy + yMargn
            Call PRN_DATA(PR_WK_Renamed)
        End If
        ' �H�햼��
        PR_Text = ""
        If DT2.KOUSYU_NO <> "00" Then PR_Text = Space(2)
        PR_WK_Renamed.DT = PR_Text & DT2.MEISYOU
        '----- 2004/03/17 �ǉ� ---------------------------------------
        PR_Text = RTrim(PR_WK_Renamed.DT)
        PR_WK_Renamed.DT = RTrim(GetvbUnicode(PR_Text, 30))
        '-------------------------------------------------------------
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.19  UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(0, XX2(2), XX2(3), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(0, XX2(2), XX2(3), PR_WK_Renamed)
        '2021.08.19  UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        '----- 2004/03/17 �ǉ� ---------------------------------------
        ' ���s�\�Z
        If DT2.J_YOSAN <> 0 Then
            '2021.08.11 UPGRADE S  AIT)dannnl
            'PR_WK_Renamed.DT = VB6.Format(DT2.J_YOSAN, "#,###,###,##0")
            PR_WK_Renamed.DT = DT2.J_YOSAN.ToString("#,###,###,##0")
            '2021.08.11 UPGRADE E
        Else
            PR_WK_Renamed.DT = ""
        End If
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.19  UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(2, XX2(3), XX2(4), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX2(3), XX2(4), PR_WK_Renamed)
        '2021.08.19  UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        '-------------------------------------------------------------
        ' ���s�\�Z �� ��Ɋz
        If DT2.YOSAN_GAKU <> 0 Then
            '2021.08.11 UPGRADE S  AIT)dannnl
            'PR_WK_Renamed.DT = VB6.Format(DT2.YOSAN_GAKU, "#,###,###,##0")
            PR_WK_Renamed.DT = DT2.YOSAN_GAKU.ToString("#,###,###,##0")
            '2021.08.11 UPGRADE E
        Else
            PR_WK_Renamed.DT = ""
        End If
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.19  UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(2, XX2(4), XX2(5), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX2(4), XX2(5), PR_WK_Renamed)
        '2021.08.19  UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        '2013/12/10 �ǉ� ---------------------------------------------------------------------------����������
        If PrnModeNo = 1 Then
            '
        Else
            ' �O�񖘎��{���z
            If (DT2.RUIGAKU) <> 0 Then
                '2021.08.11 UPGRADE S  AIT)dannnl
                'PR_WK_Renamed.DT = VB6.Format(DT2.RUIGAKU, "#,###,###,##0")
                PR_WK_Renamed.DT = DT2.RUIGAKU.ToString("#,###,###,##0")
                '2021.08.11 UPGRADE E
            Else
                PR_WK_Renamed.DT = ""
            End If
            PR_WK_Renamed.FS = F_SIZE
            '2021.08.19  UPGRADE S  AIT)dannnl
            'PR_WK_Renamed.X = PRN_XGet(2, XX2(5), XX2(6), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
            PRN_XGet(2, XX2(5), XX2(6), PR_WK_Renamed)
            '2021.08.19  UPGRADE E
            PR_WK_Renamed.Y = pryy + yMargn
            Call PRN_DATA(PR_WK_Renamed)
            ' ������{���z
            If (DT2.KINGAKU) <> 0 Then
                '2021.08.11 UPGRADE S  AIT)dannnl
                'PR_WK_Renamed.DT = VB6.Format(DT2.KINGAKU, "#,###,###,##0")
                PR_WK_Renamed.DT = DT2.KINGAKU.ToString("#,###,###,##0")
                '2021.08.11 UPGRADE E
            Else
                PR_WK_Renamed.DT = ""
            End If
            PR_WK_Renamed.FS = F_SIZE
            '2021.08.19  UPGRADE S  AIT)dannnl
            'PR_WK_Renamed.X = PRN_XGet(2, XX2(6), XX2(7), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
            PRN_XGet(2, XX2(6), XX2(7), PR_WK_Renamed)
            '2021.08.19  UPGRADE E
            PR_WK_Renamed.Y = pryy + yMargn
            Call PRN_DATA(PR_WK_Renamed)
        End If
        '-------------------------------------------------------------------------------------------����������
        ' �݌v���{���z
        If (DT2.KINGAKU + DT2.RUIGAKU) <> 0 Then
            '2021.08.11 UPGRADE S  AIT)dannnl
            'PR_WK_Renamed.DT = VB6.Format(DT2.KINGAKU + DT2.RUIGAKU, "#,###,###,##0")
            PR_WK_Renamed.DT = (DT2.KINGAKU + DT2.RUIGAKU).ToString("#,###,###,##0")
            '2021.08.11 UPGRADE E
        Else
            PR_WK_Renamed.DT = ""
        End If
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.19  UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(2, XX2(7), XX2(8), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX2(7), XX2(8), PR_WK_Renamed)
        '2021.08.19  UPGRADE E
        PR_WK_Renamed.Y = pryy + yMargn
        Call PRN_DATA(PR_WK_Renamed)
        If PrnModeNo = 1 Then
            ' ���㏊�v����
            If DT2.KONGO_GAKU <> 0 Then
                '2021.08.11 UPGRADE S  AIT)dannnl
                'PR_WK_Renamed.DT = VB6.Format(DT2.KONGO_GAKU, "#,###,###,##0")
                PR_WK_Renamed.DT = DT2.KONGO_GAKU.ToString("#,###,###,##0")
                '2021.08.11 UPGRADE E
            Else
                PR_WK_Renamed.DT = ""
            End If
            PR_WK_Renamed.FS = F_SIZE
            '2021.08.19  UPGRADE S  AIT)dannnl
            'PR_WK_Renamed.X = PRN_XGet(2, XX2(8), XX2(9), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
            PRN_XGet(2, XX2(8), XX2(9), PR_WK_Renamed)
            '2021.08.19  UPGRADE E
            PR_WK_Renamed.Y = pryy + yMargn
            Call PRN_DATA(PR_WK_Renamed)
            ' ���{�������z
            If DT2.JISSI_GAKU <> 0 Then
                '2021.08.11 UPGRADE S  AIT)dannnl
                'PR_WK_Renamed.DT = VB6.Format(DT2.JISSI_GAKU, "#,###,###,##0")
                PR_WK_Renamed.DT = DT2.JISSI_GAKU.ToString("#,###,###,##0")
                '2021.08.11 UPGRADE E
            Else
                PR_WK_Renamed.DT = ""
            End If
            PR_WK_Renamed.FS = F_SIZE
            '2021.08.19  UPGRADE S  AIT)dannnl
            'PR_WK_Renamed.X = PRN_XGet(2, XX2(9), XX2(10), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
            PRN_XGet(2, XX2(9), XX2(10), PR_WK_Renamed)
            '2021.08.19  UPGRADE E
            PR_WK_Renamed.Y = pryy + yMargn
            Call PRN_DATA(PR_WK_Renamed)
            ' �\�Z�Δ�
            If DT2.TAIHI_GAKU <> 0 Then
                '2021.08.11 UPGRADE S  AIT)dannnl
                'PR_WK_Renamed.DT = VB6.Format(DT2.TAIHI_GAKU, "#,###,###,##0")
                PR_WK_Renamed.DT = DT2.TAIHI_GAKU.ToString("#,###,###,##0")
                '2021.08.11 UPGRADE E
            Else
                PR_WK_Renamed.DT = ""
            End If
            PR_WK_Renamed.FS = F_SIZE
            '2021.08.19  UPGRADE S  AIT)dannnl
            'PR_WK_Renamed.X = PRN_XGet(2, XX2(10), XX2(11), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
            PRN_XGet(2, XX2(10), XX2(11), PR_WK_Renamed)
            '2021.08.19  UPGRADE E
            PR_WK_Renamed.Y = pryy + yMargn
            Call PRN_DATA(PR_WK_Renamed)
            ' �ύX����
            If DT2.ZOGEN_GAKU <> 0 Then
                '2021.08.11 UPGRADE S  AIT)dannnl
                'PR_WK_Renamed.DT = VB6.Format(DT2.ZOGEN_GAKU, "#,###,###,##0")
                PR_WK_Renamed.DT = DT2.ZOGEN_GAKU.ToString("#,###,###,##0")
                '2021.08.11 UPGRADE E
            Else
                PR_WK_Renamed.DT = ""
            End If
            PR_WK_Renamed.FS = F_SIZE
            '2021.08.19  UPGRADE S  AIT)dannnl
            'PR_WK_Renamed.X = PRN_XGet(2, XX2(11), XX2(12), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
            PRN_XGet(2, XX2(11), XX2(12), PR_WK_Renamed)
            '2021.08.19  UPGRADE E
            PR_WK_Renamed.Y = pryy + yMargn
            Call PRN_DATA(PR_WK_Renamed)
        End If

    End Sub

    '-------------------------------------------------------------------------------
    '   ����    :   ����f�[�^�i����j�������
    '   �֐�    :   Sub PrData3D185()
    '   ����    :   pryy    ����x�ʒu
    '   �@�@        DT()    GEPPOU_LIST_GAI
    '   �@�@        Cnt     �f�[�^����
    '   �ߒl    :   �Ȃ�
    '-------------------------------------------------------------------------------
    Private Sub PrData3D185(ByRef pryy As Single, ByRef DT() As GEPPOU_LIST_GAI, ByRef Cnt As Integer)

        Dim lp As Integer
        Dim PR_WK_Renamed As PR_WK
        Dim PR_Text As String
        Dim yMargn As Single

        '----- �]��
        yMargn = P_YY * 0.25

        For lp = 0 To Cnt - 1
            ' ���o�ԍ��E���o����
            PR_Text = ""
            Select Case DT(lp).WARIDASI_KB
                Case "1"
                    PR_Text = Space(7)
                Case "2"
                    PR_Text = Space(4) & DT(lp).WARIDASI_NO & ":"
            End Select
            PR_WK_Renamed.DT = PR_Text & GetvbUnicode(DT(lp).MEISYOU, 22)
            PR_WK_Renamed.FS = F_SIZE
            '2021.08.19  UPGRADE S  AIT)dannnl
            'PR_WK_Renamed.X = PRN_XGet(0, XX2(2), XX2(3), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
            PRN_XGet(0, XX2(2), XX2(3), PR_WK_Renamed)
            '2021.08.19  UPGRADE E
            PR_WK_Renamed.Y = pryy + yMargn
            Call PRN_DATA(PR_WK_Renamed)
            ' ���s�\�Z
            If DT(lp).J_YOSAN <> 0 Then
                '2021.08.11 UPGRADE S  AIT)dannnl
                'PR_WK_Renamed.DT = VB6.Format(DT(lp).J_YOSAN, "#,###,###,##0")
                PR_WK_Renamed.DT = DT(lp).J_YOSAN.ToString("#,###,###,##0")
                '2021.08.11 UPGRADE E
            Else
                PR_WK_Renamed.DT = ""
            End If
            PR_WK_Renamed.FS = F_SIZE
            '2021.08.19  UPGRADE S  AIT)dannnl
            'PR_WK_Renamed.X = PRN_XGet(2, XX2(3), XX2(4), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
            PRN_XGet(2, XX2(3), XX2(4), PR_WK_Renamed)
            '2021.08.19  UPGRADE E
            PR_WK_Renamed.Y = pryy + yMargn
            Call PRN_DATA(PR_WK_Renamed)
            ' ���s�\�Z �� ��Ɋz
            If DT(lp).YOSAN_GAKU <> 0 Then
                '2021.08.11 UPGRADE S  AIT)dannnl
                'PR_WK_Renamed.DT = VB6.Format(DT(lp).YOSAN_GAKU, "#,###,###,##0")
                PR_WK_Renamed.DT = DT(lp).YOSAN_GAKU.ToString("#,###,###,##0")
                '2021.08.11 UPGRADE E
            Else
                PR_WK_Renamed.DT = ""
            End If
            PR_WK_Renamed.FS = F_SIZE
            '2021.08.19  UPGRADE S  AIT)dannnl
            'PR_WK_Renamed.X = PRN_XGet(2, XX2(4), XX2(5), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
            PRN_XGet(2, XX2(4), XX2(5), PR_WK_Renamed)
            '2021.08.19  UPGRADE E
            PR_WK_Renamed.Y = pryy + yMargn
            Call PRN_DATA(PR_WK_Renamed)
            '2013/12/10 �ǉ� ---------------------------------------------------------------------------����������
            If PrnModeNo = 1 Then
                '
            Else
                ' �O�񖘎��{���z
                If (DT(lp).RUIGAKU) <> 0 Then
                    '2021.08.11 UPGRADE S  AIT)dannnl
                    'PR_WK_Renamed.DT = VB6.Format(DT(lp).RUIGAKU, "#,###,###,##0")
                    PR_WK_Renamed.DT = DT(lp).RUIGAKU.ToString("#,###,###,##0")
                    '2021.08.11 UPGRADE E
                Else
                    PR_WK_Renamed.DT = ""
                End If
                PR_WK_Renamed.FS = F_SIZE
                '2021.08.19  UPGRADE S  AIT)dannnl
                'PR_WK_Renamed.X = PRN_XGet(2, XX2(5), XX2(6), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
                PRN_XGet(2, XX2(5), XX2(6), PR_WK_Renamed)
                '2021.08.19  UPGRADE E
                PR_WK_Renamed.Y = pryy + yMargn
                Call PRN_DATA(PR_WK_Renamed)
                ' ������{���z
                If (DT(lp).KINGAKU) <> 0 Then
                    '2021.08.11 UPGRADE S  AIT)dannnl
                    'PR_WK_Renamed.DT = VB6.Format(DT(lp).KINGAKU, "#,###,###,##0")
                    PR_WK_Renamed.DT = DT(lp).KINGAKU.ToString("#,###,###,##0")
                    '2021.08.11 UPGRADE E
                Else
                    PR_WK_Renamed.DT = ""
                End If
                PR_WK_Renamed.FS = F_SIZE
                '2021.08.19  UPGRADE S  AIT)dannnl
                'PR_WK_Renamed.X = PRN_XGet(2, XX2(6), XX2(7), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
                PRN_XGet(2, XX2(6), XX2(7), PR_WK_Renamed)
                '2021.08.19  UPGRADE E
                PR_WK_Renamed.Y = pryy + yMargn
                Call PRN_DATA(PR_WK_Renamed)
            End If
            '-------------------------------------------------------------------------------------------����������
            ' �݌v���{���z
            If (DT(lp).KINGAKU + DT(lp).RUIGAKU) <> 0 Then
                '2021.08.11 UPGRADE S  AIT)dannnl
                'PR_WK_Renamed.DT = VB6.Format(DT(lp).KINGAKU + DT(lp).RUIGAKU, "#,###,###,##0")
                PR_WK_Renamed.DT = (DT(lp).KINGAKU + DT(lp).RUIGAKU).ToString("#,###,###,##0")
                '2021.08.11 UPGRADE E
            Else
                PR_WK_Renamed.DT = ""
            End If
            PR_WK_Renamed.FS = F_SIZE
            '2021.08.19  UPGRADE S  AIT)dannnl
            'PR_WK_Renamed.X = PRN_XGet(2, XX2(7), XX2(8), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
            PRN_XGet(2, XX2(7), XX2(8), PR_WK_Renamed)
            '2021.08.19  UPGRADE E
            PR_WK_Renamed.Y = pryy + yMargn
            Call PRN_DATA(PR_WK_Renamed)
            If PrnModeNo = 1 Then
                ' ���㏊�v����
                If DT(lp).KONGO_GAKU <> 0 Then
                    '2021.08.11 UPGRADE S  AIT)dannnl
                    'PR_WK_Renamed.DT = VB6.Format(DT(lp).KONGO_GAKU, "#,###,###,##0")
                    PR_WK_Renamed.DT = DT(lp).KONGO_GAKU.ToString("#,###,###,##0")
                    '2021.08.11 UPGRADE E
                Else
                    PR_WK_Renamed.DT = ""
                End If
                PR_WK_Renamed.FS = F_SIZE
                '2021.08.19  UPGRADE S  AIT)dannnl
                'PR_WK_Renamed.X = PRN_XGet(2, XX2(8), XX2(9), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
                PRN_XGet(2, XX2(8), XX2(9), PR_WK_Renamed)
                '2021.08.19  UPGRADE E
                PR_WK_Renamed.Y = pryy + yMargn
                Call PRN_DATA(PR_WK_Renamed)
                ' ���{�������z
                If DT(lp).JISSI_GAKU <> 0 Then
                    '2021.08.11 UPGRADE S  AIT)dannnl
                    'PR_WK_Renamed.DT = VB6.Format(DT(lp).JISSI_GAKU, "#,###,###,##0")
                    PR_WK_Renamed.DT = DT(lp).JISSI_GAKU.ToString("#,###,###,##0")
                    '2021.08.11 UPGRADE E
                Else
                    PR_WK_Renamed.DT = ""
                End If
                PR_WK_Renamed.FS = F_SIZE
                '2021.08.19  UPGRADE S  AIT)dannnl
                'PR_WK_Renamed.X = PRN_XGet(2, XX2(9), XX2(10), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
                PRN_XGet(2, XX2(9), XX2(10), PR_WK_Renamed)
                '2021.08.19  UPGRADE E
                PR_WK_Renamed.Y = pryy + yMargn
                Call PRN_DATA(PR_WK_Renamed)
                ' �\�Z�Δ�
                If DT(lp).TAIHI_GAKU <> 0 Then
                    '2021.08.11 UPGRADE S  AIT)dannnl
                    'PR_WK_Renamed.DT = VB6.Format(DT(lp).TAIHI_GAKU, "#,###,###,##0")
                    PR_WK_Renamed.DT = DT(lp).TAIHI_GAKU.ToString("#,###,###,##0")
                    '2021.08.11 UPGRADE E
                Else
                    PR_WK_Renamed.DT = ""
                End If
                PR_WK_Renamed.FS = F_SIZE
                '2021.08.19  UPGRADE S  AIT)dannnl
                'PR_WK_Renamed.X = PRN_XGet(2, XX2(10), XX2(11), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
                PRN_XGet(2, XX2(10), XX2(11), PR_WK_Renamed)
                '2021.08.19  UPGRADE E
                PR_WK_Renamed.Y = pryy + yMargn
                Call PRN_DATA(PR_WK_Renamed)
                ' �ύX����
                If DT(lp).ZOGEN_GAKU <> 0 Then
                    '2021.08.11 UPGRADE S  AIT)dannnl
                    'PR_WK_Renamed.DT = VB6.Format(DT(lp).ZOGEN_GAKU, "#,###,###,##0")
                    PR_WK_Renamed.DT = DT(lp).ZOGEN_GAKU.ToString("#,###,###,##0")
                    '2021.08.11 UPGRADE E
                Else
                    PR_WK_Renamed.DT = ""
                End If
                PR_WK_Renamed.FS = F_SIZE
                '2021.08.19  UPGRADE S  AIT)dannnl
                'PR_WK_Renamed.X = PRN_XGet(2, XX2(11), XX2(12), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
                PRN_XGet(2, XX2(11), XX2(12), PR_WK_Renamed)
                '2021.08.19  UPGRADE E
                PR_WK_Renamed.Y = pryy + yMargn
                Call PRN_DATA(PR_WK_Renamed)
            End If

            '----- ���s
            pryy = pryy + (P_YY * 1.5)
        Next lp

    End Sub

    '-------------------------------------------------------------------------------
    '   ����    :   ����f�[�^(�H���)���v�������
    '   �֐�    :   Sub PrDataGD185()
    '   ����    :   pryy            ����x�ʒu
    '   �@�@        KOUMOKU_KEI()   �e���ڋ��z���v
    '   �ߒl    :   �Ȃ�
    '-------------------------------------------------------------------------------
    Private Sub PrDataGD185(ByRef pryy As Single, ByRef KOUMOKU_KEI() As Decimal)

        Dim PR_WK_Renamed As PR_WK
        'Dim yMargn As Single�@�@�@�@�@'2021.08.11 UPGRADE DEL  AIT)dannnl
        Dim Lpryy As Single

        Lpryy = Bupyy + (P_YY * 0.75)
        Lpryy = Lpryy + ((P_YY * 1.5) * (PageDataDnt - 1))
        Lpryy = Lpryy + (P_YY * 0.25)

        ' ���v(���o��)
        PR_WK_Renamed.DT = "���v"
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.19  UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(1, XX2(1), XX2(3), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(1, XX2(1), XX2(3), PR_WK_Renamed)
        '2021.08.19  UPGRADE E
        PR_WK_Renamed.Y = Lpryy
        Call PRN_DATA(PR_WK_Renamed)
        ' ���s�\�Z
        '2021.08.11 UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.DT = VB6.Format(KOUMOKU_KEI(7), "#,###,###,##0")
        PR_WK_Renamed.DT = KOUMOKU_KEI(7).ToString("#,###,###,##0")
        '2021.08.11 UPGRADE E
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.19  UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(2, XX2(3), XX2(4), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX2(3), XX2(4), PR_WK_Renamed)
        '2021.08.19  UPGRADE E
        PR_WK_Renamed.Y = Lpryy
        Call PRN_DATA(PR_WK_Renamed)
        ' ���s�\�Z �� ��Ɋz
        '2021.08.11 UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.DT = VB6.Format(KOUMOKU_KEI(1), "#,###,###,##0")
        PR_WK_Renamed.DT = KOUMOKU_KEI(1).ToString("#,###,###,##0")
        '2021.08.11 UPGRADE E
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.19  UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(2, XX2(4), XX2(5), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX2(4), XX2(5), PR_WK_Renamed)
        '2021.08.19  UPGRADE E
        PR_WK_Renamed.Y = Lpryy
        Call PRN_DATA(PR_WK_Renamed)
        '2013/12/10 �ǉ� ---------------------------------------------------------------------------����������
        If PrnModeNo = 1 Then
            '
        Else
            ' �O�񖘎��{���z
            '2021.08.11 UPGRADE S  AIT)dannnl
            'PR_WK_Renamed.DT = VB6.Format(KOUMOKU_KEI(8), "#,###,###,##0")
            PR_WK_Renamed.DT = KOUMOKU_KEI(8).ToString("#,###,###,##0")
            '2021.08.11 UPGRADE E
            PR_WK_Renamed.FS = F_SIZE
            '2021.08.19  UPGRADE S  AIT)dannnl
            'PR_WK_Renamed.X = PRN_XGet(2, XX2(5), XX2(6), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
            PRN_XGet(2, XX2(5), XX2(6), PR_WK_Renamed)
            '2021.08.19  UPGRADE E
            PR_WK_Renamed.Y = Lpryy
            Call PRN_DATA(PR_WK_Renamed)
            ' ������{���z
            '2021.08.11 UPGRADE S  AIT)dannnl
            'PR_WK_Renamed.DT = VB6.Format(KOUMOKU_KEI(9), "#,###,###,##0")
            PR_WK_Renamed.DT = KOUMOKU_KEI(9).ToString("#,###,###,##0")
            '2021.08.11 UPGRADE E
            PR_WK_Renamed.FS = F_SIZE
            '2021.08.19  UPGRADE S  AIT)dannnl
            'PR_WK_Renamed.X = PRN_XGet(2, XX2(6), XX2(7), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
            PRN_XGet(2, XX2(6), XX2(7), PR_WK_Renamed)
            '2021.08.19  UPGRADE E
            PR_WK_Renamed.Y = Lpryy
            Call PRN_DATA(PR_WK_Renamed)
        End If
        '-------------------------------------------------------------------------------------------����������
        ' �݌v���{���z
        '2021.08.11 UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.DT = VB6.Format(KOUMOKU_KEI(2), "#,###,###,##0")
        PR_WK_Renamed.DT = KOUMOKU_KEI(2).ToString("#,###,###,##0")
        '2021.08.11 UPGRADE E
        PR_WK_Renamed.FS = F_SIZE
        '2021.08.19  UPGRADE S  AIT)dannnl
        'PR_WK_Renamed.X = PRN_XGet(2, XX2(7), XX2(8), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
        PRN_XGet(2, XX2(7), XX2(8), PR_WK_Renamed)
        '2021.08.19  UPGRADE E
        PR_WK_Renamed.Y = Lpryy
        Call PRN_DATA(PR_WK_Renamed)
        If PrnModeNo = 1 Then
            ' ���㏊�v����
            '2021.08.11 UPGRADE S  AIT)dannnl
            'PR_WK_Renamed.DT = VB6.Format(KOUMOKU_KEI(3), "#,###,###,##0")
            PR_WK_Renamed.DT = KOUMOKU_KEI(3).ToString("#,###,###,##0")
            '2021.08.11 UPGRADE E
            PR_WK_Renamed.FS = F_SIZE
            '2021.08.19  UPGRADE S  AIT)dannnl
            'PR_WK_Renamed.X = PRN_XGet(2, XX2(8), XX2(9), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
            PRN_XGet(2, XX2(8), XX2(9), PR_WK_Renamed)
            '2021.08.19  UPGRADE E
            PR_WK_Renamed.Y = Lpryy
            Call PRN_DATA(PR_WK_Renamed)
            ' ���{�������z
            '2021.08.11 UPGRADE S  AIT)dannnl
            'PR_WK_Renamed.DT = VB6.Format(KOUMOKU_KEI(4), "#,###,###,##0")
            PR_WK_Renamed.DT = KOUMOKU_KEI(4).ToString("#,###,###,##0")
            '2021.08.11 UPGRADE E
            PR_WK_Renamed.FS = F_SIZE
            '2021.08.19  UPGRADE S  AIT)dannnl
            'PR_WK_Renamed.X = PRN_XGet(2, XX2(9), XX2(10), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
            PRN_XGet(2, XX2(9), XX2(10), PR_WK_Renamed)
            '2021.08.19  UPGRADE E
            PR_WK_Renamed.Y = Lpryy
            Call PRN_DATA(PR_WK_Renamed)
            ' �\�Z�Δ�
            '2021.08.11 UPGRADE S  AIT)dannnl
            'PR_WK_Renamed.DT = VB6.Format(KOUMOKU_KEI(5), "#,###,###,##0")
            PR_WK_Renamed.DT = KOUMOKU_KEI(5).ToString("#,###,###,##0")
            '2021.08.11 UPGRADE E
            PR_WK_Renamed.FS = F_SIZE
            '2021.08.19  UPGRADE S  AIT)dannnl
            'PR_WK_Renamed.X = PRN_XGet(2, XX2(10), XX2(11), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
            PRN_XGet(2, XX2(10), XX2(11), PR_WK_Renamed)
            '2021.08.19  UPGRADE E
            PR_WK_Renamed.Y = Lpryy
            Call PRN_DATA(PR_WK_Renamed)
            ' �ύX����
            '2021.08.11 UPGRADE S  AIT)dannnl
            'PR_WK_Renamed.DT = VB6.Format(KOUMOKU_KEI(6), "#,###,###,##0")
            PR_WK_Renamed.DT = KOUMOKU_KEI(6).ToString("#,###,###,##0")
            '2021.08.11 UPGRADE E
            PR_WK_Renamed.FS = F_SIZE
            '2021.08.19  UPGRADE S  AIT)dannnl
            'PR_WK_Renamed.X = PRN_XGet(2, XX2(11), XX2(12), PR_WK_Renamed.FS, PR_WK_Renamed.DT)
            PRN_XGet(2, XX2(11), XX2(12), PR_WK_Renamed)
            '2021.08.19  UPGRADE E
            PR_WK_Renamed.Y = Lpryy
            Call PRN_DATA(PR_WK_Renamed)
        End If

    End Sub
End Module
