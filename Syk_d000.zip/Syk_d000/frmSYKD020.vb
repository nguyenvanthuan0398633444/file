Option Strict Off
Option Explicit On

Friend Class frmSYKD020
    Inherits System.Windows.Forms.Form
    '=============================================================
    ' ���[�U�[���@  �F  �R�z�H�Ɗ������
    ' �V�X�e�����@  �F  �H���Ǘ��V�X�e��
    ' ���W���[����  �F  ���c��O�����o�ꗗ
    ' ���W���[��ID�@�F  frmSYKD020.frm
    ' �쐬���@ �@�@ �F  ���� 13 �N 06 �� 18 ��
    ' �X�V���@�@  �@�F  ����    �N    ��    ��
    '=============================================================
    '

    '2021.08.03 UPGRADE S  AIT)hieutv
    'Private Const RowHeight As Short = 15
    Private Const RowHeight As Short = 21
    '2021.08.03 UPGRADE E
    '

    '-------------------------------------------------------------------------------
    '   ����   :   �f�[�^�̃N���A
    '   �֐�   :   Sub DispClear()
    '   ����   :   �Ȃ�
    '   �@�\   :   �f�[�^���N���A���܂��B
    '-------------------------------------------------------------------------------
    Private Sub DispClear()

        '----- �H�����
        With KeyKouji
            imText2(0).Text = .KOUJI_NO
            If .EDA_NO = "0000" Then
                imText2(1).Text = ""
            Else
                imText2(1).Text = .EDA_NO
            End If
            imText2(2).Text = .MEISYOU
        End With

        '2021.08.02 UPGRADE S  AIT)hieutv
        'vaSpread1.MaxRows = 0
        'Call SpAllClear(vaSpread2)
        FpSpread1.ActiveSheet.RowCount = 0
        Call SpAllClear(FpSpread2)
        '2021.08.02 UPGRADE E

        '----- �Q�ƃ��[�h
        If INPMODE <> "2" Then
            '2021.08.10 UPGRADE S  AIT)hieutv
			'cmdKey(1).Text = "  F1  ���o�\��"
			'cmdKey(5).Text = "  F5  �@"
			'cmdKey(5).Enabled = False
            cmdKey(1).Text = "F1" & vbCrlf & "���o�\��"
            cmdKey(1).TextAlign = System.Drawing.ContentAlignment.MiddleCenter
            cmdKey(5).Text = "F5"
            cmdKey(5).TextAlign = System.Drawing.ContentAlignment.TopCenter
            cmdKey(5).Enabled = False
            '2021.08.10 UPGRADE E
        End If

    End Sub

    '-------------------------------------------------------------------------------
    '   ����   :   WARIDASI_DATA �ǂݍ��ݏ���
    '   �֐�   :   Function SelectWaridasi()
    '   ����   :   DT()�@   WARIDASI_DATA_DBT
    '   �ߒl   :   �ް���   ����I��
    '   �@�@       -1�@     �ُ�I��
    '   �@�\   :   WARIDASI_DATA SELECT����
    '-------------------------------------------------------------------------------
    Private Function SelectWaridasi(ByRef DT() As WARIDASI_DATA_DBT) As Integer

        Dim SQL As String
        '2021.08.02 UPGRADE S  AIT)hieutv
        'Dim Rs As ADODB.Recordset
        Dim Rs As New DataTable
        '2021.08.02 UPGRADE E
        Dim Cnt As Integer
        Dim OpenFlg As Short

        '2021.07.26 UPGRADE S  AIT)Tool Convert
        'On Error GoTo SelectWaridasi_Err
        Try
            '2021.07.26 UPGRADE E

            '�߂�l�̏�����
            SelectWaridasi = -1

            'SQL/SELECT���g��
            SQL = "SELECT"
            SQL = SQL & " WARIDASI_DATA.KOUSYU_CD      AS KOUSYU_CD," '�H������
            SQL = SQL & " WARIDASI_DATA.KOUSYU_NO      AS KOUSYU_NO," '�H��ԍ�
            SQL = SQL & " MIN(KOUSYU_MAST.MEISYOU)     AS MEISYOU," '�H�햼��
            SQL = SQL & " SUM(WARIDASI_DATA.J_KINGAKU) AS J_KINGAKU," '�\�Z���z
            SQL = SQL & " SUM(WARIDASI_DATA.T_KINGAKU) AS T_KINGAKU," '���c���z
            SQL = SQL & " SUM(WARIDASI_DATA.G_KINGAKU) AS G_KINGAKU" '�O�����z
            SQL = SQL & " FROM (WARIDASI_DATA INNER JOIN KOUSYU_MAST"
            SQL = SQL & "  ON (WARIDASI_DATA.KOUSYU_NO = KOUSYU_MAST.KOUSYU_NO)"
            SQL = SQL & " AND (WARIDASI_DATA.KOUSYU_CD = KOUSYU_MAST.KOUSYU_CD))"
            SQL = SQL & " WHERE WARIDASI_DATA.EDA_NO = '" & KeyKouji.EDA_NO & "'"
            SQL = SQL & " AND WARIDASI_DATA.KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"
            SQL = SQL & " AND KOUSYU_MAST.GYOUSYU_KB = '01'"
            SQL = SQL & " GROUP BY WARIDASI_DATA.KOUSYU_CD, WARIDASI_DATA.KOUSYU_NO"
            SQL = SQL & " ORDER BY WARIDASI_DATA.KOUSYU_CD, WARIDASI_DATA.KOUSYU_NO"

            'SQL�����s
            '2021.08.02 UPGRADE S  AIT)hieutv
            'Rs = SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText)
            Rs = RsOpen(SQL)
            '2021.08.02 UPGRADE E
            OpenFlg = 1

            Cnt = 0
            '2021.08.02 UPGRADE S  AIT)hieutv
      '      Do Until Rs.EOF
			   ' ReDim Preserve DT(Cnt)
			   ' Call DATSET_WARIDASI_DATA(Rs, DT(Cnt))
			   ' Cnt = Cnt + 1
			   ' Rs.MoveNext()
		    'Loop 
		
		    'Rs.Close()
            For Each Row As DataRow In Rs.Rows
                ReDim Preserve DT(Cnt)
                Call DATSET_WARIDASI_DATA(Row, DT(Cnt))
                Cnt = Cnt + 1
            Next

            Rs.Dispose()
            '2021.08.02 UPGRADE E
            Rs = Nothing

            '�߂�l�̃Z�b�g
            SelectWaridasi = Cnt
            Exit Function

            '2021.07.26 UPGRADE S  AIT)Tool Convert
            'SelectWaridasi_Err:
        Catch ex As Exception
            '2021.07.26 UPGRADE E

            If OpenFlg = 1 Then
                '2021.08.02 UPGRADE S  AIT)hieutv
                'Rs.Close()
                Rs.Dispose()
                '2021.08.02 UPGRADE E
            End If
            Rs = Nothing

            '2021.08.02 UPGRADE S  AIT)hieutv
            'Call Sql_Error_Msg("WARIDASI_DATA SELECT")
            Call Sql_Error_Msg(ex, "WARIDASI_DATA SELECT")
            '2021.08.02 UPGRADE E

        End Try     '2021.07.26 UPGRADE ADD AIT)Tool Convert
    End Function

    '-------------------------------------------------------------------------------
    '   ����   :   �H��ʏW�v����
    '   �֐�   :   Function KousyuSyukei()
    '   ����   :   Cnt      �f�[�^����
    '   �@�@       DT()     WARIDASI_DATA_DBT
    '   �ߒl   :   �W�v��f�[�^����
    '   �@�\   :   �H�����ޕʂɋ��z�̏W�v���s��
    '-------------------------------------------------------------------------------
    Private Function KousyuSyukei(ByRef Cnt As Integer, ByRef DT() As WARIDASI_DATA_DBT) As Integer

        Dim lp As Integer
        Dim CmpKey As String
        Dim wkCnt As Integer
        Dim WK() As WARIDASI_DATA_DBT
        Dim wkVal() As Decimal
        Dim wkPos As Integer

        ' �߂�l�̏�����
        KousyuSyukei = 0

        '----- ������
        ReDim wkVal(2)
        ReDim WK(Cnt - 1)
        '2021.07.26 UPGRADE S  AIT)Tool Convert
        'WK = VB6.CopyArray(DT)
        WK = DT.Clone
        '2021.07.26 UPGRADE E
        CmpKey = WK(0).KOUSYU_CD

        '----- �e�H����
        wkCnt = 0 : ReDim DT(wkCnt)
        Call CLEAR_WARIDASI_DATA(DT(wkCnt))
        With DT(wkCnt)
            .KOUJI_NO = WK(0).KOUJI_NO '�H���ԍ�
            .EDA_NO = WK(0).EDA_NO '�H���}��
            .KOUSYU_CD = WK(0).KOUSYU_CD '�H������
            .KOUSYU_NO = "00" '�H��ԍ�
            .MEISYOU = GetNameKousyu(GyosyuID, .KOUSYU_CD) '����
        End With
        wkPos = wkCnt : wkCnt = wkCnt + 1

        For lp = 0 To Cnt - 1
            '----- �H�����ނ̔�r
            If CmpKey <> WK(lp).KOUSYU_CD Then
                '----- ���v���z�̐ݒ�
                DT(wkPos).J_KINGAKU = wkVal(0)
                DT(wkPos).T_KINGAKU = wkVal(1)
                DT(wkPos).G_KINGAKU = wkVal(2)
                '----- �e�H����
                ReDim Preserve DT(wkCnt)
                Call CLEAR_WARIDASI_DATA(DT(wkCnt))
                With DT(wkCnt)
                    .KOUJI_NO = WK(lp).KOUJI_NO '�H���ԍ�
                    .EDA_NO = WK(lp).EDA_NO '�H���}��
                    .KOUSYU_CD = WK(lp).KOUSYU_CD '�H������
                    .KOUSYU_NO = "00" '�H��ԍ�
                    .MEISYOU = GetNameKousyu(GyosyuID, .KOUSYU_CD) '����
                End With
                wkPos = wkCnt : wkCnt = wkCnt + 1
                '----- ������
                CmpKey = WK(lp).KOUSYU_CD
                ReDim wkVal(2)
            End If
            '----- �H��}�ԏ��̃Z�b�g
            ReDim Preserve DT(wkCnt)
            DT(wkCnt) = WK(lp)
            wkCnt = wkCnt + 1
            '----- �W�v
            wkVal(0) = wkVal(0) + WK(lp).J_KINGAKU
            wkVal(1) = wkVal(1) + WK(lp).T_KINGAKU
            wkVal(2) = wkVal(2) + WK(lp).G_KINGAKU
        Next lp

        '----- ���v���z�̐ݒ�
        DT(wkPos).J_KINGAKU = wkVal(0)
        DT(wkPos).T_KINGAKU = wkVal(1)
        DT(wkPos).G_KINGAKU = wkVal(2)

        ' �߂�l�̃Z�b�g
        KousyuSyukei = wkCnt

    End Function

    '-------------------------------------------------------------------------------
    '   ����    :   �f�[�^�̎擾
    '   �֐�    :   Sub ListDataDisp()
    '   ����    :   Mode    0 = MsgBox�\��
    '   �@�\    :   �f�[�^�̎擾���s���܂��B
    '-------------------------------------------------------------------------------
    Public Sub ListDataDisp(Optional ByRef Mode As Short = 0)

        Dim Cnt As Integer
        Dim DT() As WARIDASI_DATA_DBT
        Dim wkBuf As String

        ' �J�[�\���������v��
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
        wkBuf = StatusBar1.Items.Item("Message").Text
        StatusBar1.Items.Item("Message").Text = "�Y���f�[�^�������E�E�E"

        ' �e�[�u���̓Ǎ���
        Cnt = SelectWaridasi(DT)
        If Cnt <= 0 Then
            '2021.08.02 UPGRADE S  AIT)hieutv
            'vaSpread1.MaxRows = 0
            'Call SpAllClear(vaSpread2)
            FpSpread1.ActiveSheet.RowCount = 0
            Call SpAllClear(FpSpread2)
            '2021.08.02 UPGRADE E
            If INPMODE <> "2" Then
                cmdKey(1).Enabled = False
            End If
            StatusBar1.Items.Item("Message").Text = wkBuf
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
            Exit Sub
        End If
        Cnt = KousyuSyukei(Cnt, DT)

        ' �X�v���b�h�ɕ\��
        Call SprdDataSet(Cnt, DT)

        StatusBar1.Items.Item("Message").Text = wkBuf
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default

    End Sub

    '-------------------------------------------------------------------------------
    '   ����    :   �X�v���b�h�\��
    '   �֐�    :   Sub SprdDataSet(DT())
    '   ����    :   Cnt     �f�[�^����
    '   �@�@    :   DT()    WARIDASI_DATA_DBT
    '   �@�\    :   �f�[�^���X�v���b�h�ɕ\�����܂��B
    '-------------------------------------------------------------------------------
    Private Sub SprdDataSet(ByRef Cnt As Integer, ByRef DT() As WARIDASI_DATA_DBT)

        Dim lp As Integer
        Dim Row As Integer
        Dim Col As Integer
        Dim ssText As Object
        'Dim wkCol As Integer�@�@�@�@�@'2021.08.17 UPGRADE DEL  AIT)hieutv
        Dim wkVal() As Decimal
        Dim wkAns As Decimal

        '2021.08.02 UPGRADE S  AIT)hieutv
        'With vaSpread1
        With FpSpread1
            If Me.Visible = True Then
                '.ReDraw = False
                .SuspendLayout()
            End If
            '.MaxRows = Cnt
            '.Col = 1 : .Col2 = .MaxCols
            '.Row = 1 : .Row2 = .MaxRows
            '.BlockMode = True
            '.Action = FPSpread.ActionConstants.ActionClearText
            .ActiveSheet.RowCount = Cnt
            .ActiveSheet.ClearRange(0, 0, .ActiveSheet.RowCount, .ActiveSheet.ColumnCount, True)
            .ForeColor = System.Drawing.Color.Black
            '.BlockMode = False
            '2021.08.02 UPGRADE E
            ReDim wkVal(2)
            For lp = 0 To Cnt - 1
                '2021.08.02 UPGRADE S  AIT)hieutv
                '.set_RowHeight(lp + 1, RowHeight)
                .ActiveSheet.SetRowHeight(lp, RowHeight)
                'Row = lp + 1
                Row = lp
                '2021.08.02 UPGRADE E
                '----- �H�����ށE�H��ԍ�
                ssText = Trim(DT(lp).KOUSYU_CD) & "-" & Trim(DT(lp).KOUSYU_NO)
                If Trim(DT(lp).KOUSYU_NO) = "00" Then Col = 1 Else Col = 2
                '.SetText(Col, Row, ssText)
                .ActiveSheet.SetText(Row, Col - 1, ssText)
                '----- �H�햼
                If Col = 1 Then
                    ssText = ""
                Else
                    ssText = "�@"
                End If
                ssText = ssText & Trim(DT(lp).MEISYOU)
                '2021.08.02 UPGRADE S  AIT)hieutv
                '.SetText(3, Row, ssText)
                .ActiveSheet.SetText(Row, 2, ssText)
                '2021.08.02 UPGRADE E
                '----- �\�Z���z
                '2021.07.26 UPGRADE S  AIT)Tool Convert
                'ssText = VB6.Format(DT(lp).J_KINGAKU, "#,##0")
                ssText = CDec(DT(lp).J_KINGAKU).ToString("#,##0")
                '2021.07.26 UPGRADE E
                '2021.08.02 UPGRADE S  AIT)hieutv
                '.SetText(4, Row, ssText)
                .ActiveSheet.SetText(Row, 3, ssText)
                '2021.08.02 UPGRADE E
                '----- ���c���z
                '2021.07.26 UPGRADE S  AIT)Tool Convert
                'ssText = VB6.Format(DT(lp).T_KINGAKU, "#,##0")
                ssText = CDec(DT(lp).T_KINGAKU).ToString("#,##0")
                '2021.07.26 UPGRADE E
                '2021.08.02 UPGRADE S  AIT)hieutv
                '.SetText(5, Row, ssText)
                .ActiveSheet.SetText(Row, 4, ssText)
                '2021.08.02 UPGRADE E
                '----- �O�����z
                '2021.07.26 UPGRADE S  AIT)Tool Convert
                'ssText = VB6.Format(DT(lp).G_KINGAKU, "#,##0")
                ssText = CDec(DT(lp).G_KINGAKU).ToString("#,##0")
                '2021.07.26 UPGRADE E
                '2021.08.02 UPGRADE S  AIT)hieutv
                '.SetText(6, Row, ssText)
                .ActiveSheet.SetText(Row, 5, ssText)
                '2021.08.02 UPGRADE E
                '----- ���z
                wkAns = DT(lp).J_KINGAKU - (DT(lp).T_KINGAKU + DT(lp).G_KINGAKU)
                '2021.07.26 UPGRADE S  AIT)Tool Convert
                'ssText = VB6.Format(wkAns, "#,##0")
                ssText = CDec(wkAns).ToString("#,##0")
                '2021.07.26 UPGRADE E
                '2021.08.02 UPGRADE S  AIT)hieutv
                '.SetText(7, Row, ssText)
                .ActiveSheet.SetText(Row, 6, ssText)
                '2021.08.02 UPGRADE E
                '----- ���v���z
                If DT(lp).KOUSYU_NO = "00" Then
                    wkVal(0) = wkVal(0) + DT(lp).J_KINGAKU
                    wkVal(1) = wkVal(1) + DT(lp).T_KINGAKU
                    wkVal(2) = wkVal(2) + DT(lp).G_KINGAKU
                End If
            Next lp
            If Me.Visible = True Then
                '2021.08.02 UPGRADE S  AIT)hieutv
                '.CtlRefresh()
                '.ReDraw = True
                .Refresh()
                .ResumeLayout()
                '2021.08.02 UPGRADE E
            End If
        End With

        '----- ���v���z
        With FpSpread2
            '2021.08.02 UPGRADE S  AIT)hieutv
            If Me.Visible = True Then
                '.ReDraw = False
                .SuspendLayout()
            End If
            '.Col = 1 : .Col2 = .MaxCols
            '.Row = 1 : .Row2 = .MaxRows
            '.BlockMode = True
            '.Action = FPSpread.ActionConstants.ActionClearText
            '.ForeColor = System.Drawing.Color.Black
            '.BlockMode = False
            .ActiveSheet.ClearRange(0, 0, .ActiveSheet.RowCount, .ActiveSheet.ColumnCount, True)
            .ForeColor = System.Drawing.Color.Black
            '2021.08.02 UPGRADE E
            '----- �\�Z���z
            '2021.07.26 UPGRADE S  AIT)Tool Convert
            'ssText = VB6.Format(wkVal(0), "#,##0")
            ssText = CDec(wkVal(0)).ToString("#,##0")
            '2021.07.26 UPGRADE E
            '2021.08.02 UPGRADE S  AIT)hieutv
            '.SetText(4, Row, ssText)
            .ActiveSheet.SetText(0, 3, ssText)
            '2021.08.02 UPGRADE E
            '----- ���c���z
            '2021.07.26 UPGRADE S  AIT)Tool Convert
            'ssText = VB6.Format(wkVal(1), "#,##0")
            ssText = CDec(wkVal(1)).ToString("#,##0")
            '2021.07.26 UPGRADE E
            '2021.08.02 UPGRADE S  AIT)hieutv
            '.SetText(5, Row, ssText)
            .ActiveSheet.SetText(0, 4, ssText)
            '2021.08.02 UPGRADE E
            '----- �O�����z
            '2021.07.26 UPGRADE S  AIT)Tool Convert
            'ssText = VB6.Format(wkVal(2), "#,##0")
            ssText = CDec(wkVal(2)).ToString("#,##0")
            '2021.07.26 UPGRADE E
            '2021.08.02 UPGRADE S  AIT)hieutv
            '.SetText(6, Row, ssText)
            .ActiveSheet.SetText(0, 5, ssText)
            '2021.08.02 UPGRADE E
            '----- ���z
            wkAns = wkVal(0) - (wkVal(1) + wkVal(2))
            '2021.07.26 UPGRADE S  AIT)Tool Convert
            'ssText = VB6.Format(wkAns, "#,##0")
            ssText = CDec(wkAns).ToString("#,##0")
            '2021.07.26 UPGRADE E
            '2021.08.02 UPGRADE S  AIT)hieutv
            '.SetText(7, Row, ssText)
            .ActiveSheet.SetText(0, 6, ssText)
            '2021.08.02 UPGRADE E
            If Me.Visible = True Then
                '2021.08.02 UPGRADE S  AIT)hieutv
                '.CtlRefresh()
                '.ReDraw = True
                .Refresh()
                .ResumeLayout()
                '2021.08.02 UPGRADE E
            End If
        End With
        FpSpread1.ActiveSheet.AddSelection(FpSpread1.ActiveSheet.ActiveRowIndex, FpSpread1.ActiveSheet.ActiveColumnIndex, 1, FpSpread1.ActiveSheet.ColumnCount)�@�@�@�@�@'2021.08.06 UPGRADE ADD  AIT)hieutv
    End Sub

    '2021.08.02 UPGRADE S  AIT)hieutv
    'Private Sub cmdKey_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Click
    '	Dim Index As Short = cmdKey.GetIndex(eventSender)
    Private Sub cmdKey_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _cmdKey_1.Click, _cmdKey_2.Click, _cmdKey_3.Click _
        , _cmdKey_4.Click, _cmdKey_5.Click, _cmdKey_6.Click, _cmdKey_7.Click, _cmdKey_8.Click, _cmdKey_9.Click, _cmdKey_10.Click, _cmdKey_11.Click, _cmdKey_12.Click
        Dim Index As Short = cmdKey.IndexOf(eventSender)
        '2021.08.02 UPGRADE E

        '2021.08.02 UPGRADE S  AIT)hieutv
        'Dim ssText As Object
        'Dim wkPath As String
        Dim ssText As Object
        Dim wkPath As String = String.Empty
        '2021.08.02 UPGRADE E
        Dim Cnt As Integer

        Select Case Index
            Case 1 '----- ���o����
                '2021.08.02 UPGRADE S  AIT)hieutv
                'With vaSpread1 '�H�����ނ̎擾

                'If .MaxRows > 0 Then
                '	.GetText(2, .ActiveRow, ssText)
                '	If Trim(ssText) = "" Then
                '		.GetText(2, .ActiveRow + 1, ssText)
                With FpSpread1 '�H�����ނ̎擾
                    If .ActiveSheet.RowCount > 0 Then
                        ssText = .ActiveSheet.GetText(.ActiveSheet.ActiveRowIndex, 1)
                        If Trim(ssText) = "" Then
                            ssText = .ActiveSheet.GetText(.ActiveSheet.ActiveRowIndex + 1, 1)
                            '2021.08.02 UPGRADE E
                        End If
                        frmSYKD030.KousyuID = CStr(ssText).ToString
                    Else
                        frmSYKD030.KousyuID = ""
                    End If
                End With
                System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
                frmSYKD030.ShowDialog()
                '2021.08.02 UPGRADE S  AIT)hieutv
                'vaSpread1.Focus()
                FpSpread1.Focus()
                '2021.08.02 UPGRADE E

            Case 5 '----- �Ǎ���
                '2021.08.02 UPGRADE S  AIT)hieutv
                'With CommonDialog1
                With CommonDialog1Open
                    '2021.08.02 UPGRADE E
                    .Filter = "�e�L�X�g �t�@�C�� (*.csv)|*.csv"
                    .ShowReadOnly = False
                    .CheckFileExists = True
                    .CheckPathExists = True
                    .ShowDialog()
                    wkPath = .FileName
                    If wkPath = "" Then Exit Sub
                End With
                Me.Enabled = False
                With Picture2
                    '2021.08.02 UPGRADE S  AIT)hieutv
                    '.Top = VB6.TwipsToPixelsY((VB6.PixelsToTwipsY(Me.ClientRectangle.Height) - VB6.PixelsToTwipsY(.ClientRectangle.Height)) / 2)
                    .Top = Util.TwipsToPixelsY((Util.PixelsToTwipsY(Me.ClientRectangle.Height, Me) - Util.PixelsToTwipsY(.ClientRectangle.Height, Me)) / 2, Me)
                    '.Left = VB6.TwipsToPixelsX((VB6.PixelsToTwipsX(Me.ClientRectangle.Width) - VB6.PixelsToTwipsX(.ClientRectangle.Width)) / 2)
                    .Left = Util.TwipsToPixelsX((Util.PixelsToTwipsX(Me.ClientRectangle.Width, Me) - Util.PixelsToTwipsX(.ClientRectangle.Width, Me)) / 2, Me)
                    '2021.08.02 UPGRADE E
                    .Visible = True
                End With
                System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
                System.Windows.Forms.Application.DoEvents()

                '----- ��ݻ޸��݂̊J�n
                '2021.07.26 UPGRADE S  AIT)Tool Convert
                'SYKDB.BeginTrans()
                '' TextFile�̓Ǎ���
                BeginTrans()
                ' TextFile�̓Ǎ���
                '2021.07.26 UPGRADE E
                Cnt = WariTextRead(wkPath, Command1)

                Picture2.Visible = False
                Me.Enabled = True
                System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
                System.Windows.Forms.Application.DoEvents()

                ' �Ǎ��ݎ��s
                If Cnt <= 0 Then
                    '2021.08.02 UPGRADE S  AIT)hieutv
                    'SYKDB.RollbackTrans()
                    RollBack()
                    '2021.08.02 UPGRADE E
                    Exit Sub
                End If

                ' �m�F��ʂ̕\��
                frmSYKD025.ShowDialog()
                If frmSYKD025.SelMode = "" Then
                    '----- ��ݻ޸��݂̒��~
                    '2021.08.02 UPGRADE S  AIT)hieutv
                    'SYKDB.RollbackTrans()
                    RollBack()
                    '2021.08.02 UPGRADE E
                Else
                    '----- ��ݻ޸��݂̊m��
                    '2021.07.26 UPGRADE S  AIT)Tool Convert
                    'SYKDB.CommitTrans()
                    '' �ĕ\��
                    CommitTransaction()
                    ' �ĕ\��
                    '2021.07.26 UPGRADE E
                    Call ListDataDisp()
                    '2021.08.02 UPGRADE S  AIT)hieutv
                    'vaSpread1.Focus()
                    FpSpread1.Focus()
                    '2021.08.02 UPGRADE E
                End If

            Case 12 '----- �I��
                frmSYKD010.Show()
                '2021.08.31  UPGRADE S  AIT)hieutv
				'Me.Close()
				Me.Dispose()
				'2021.08.31  UPGRADE E
        End Select

    End Sub

    '2021.08.02 UPGRADE S  AIT)hieutv
    'Private Sub cmdKey_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Enter
    '	Dim Index As Short = cmdKey.GetIndex(eventSender)
    '	Call GotFocus(cmdKey(Index), StatusBar1)
    'End Sub

    'Private Sub cmdKey_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Leave
    '	Dim Index As Short = cmdKey.GetIndex(eventSender)
    '	Call LostFocus(cmdKey(Index), StatusBar1)
    'End Sub
    Private Sub cmdKey_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _cmdKey_1.Enter, _cmdKey_2.Enter, _cmdKey_3.Enter _
        , _cmdKey_4.Enter, _cmdKey_5.Enter, _cmdKey_6.Enter, _cmdKey_7.Enter, _cmdKey_8.Enter, _cmdKey_9.Enter, _cmdKey_10.Enter, _cmdKey_11.Enter, _cmdKey_12.Enter
        Dim Index As Short = cmdKey.IndexOf(eventSender)
        Call MtyTool.GotFocus(cmdKey(Index), StatusBar1)
    End Sub

    Private Sub cmdKey_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles _cmdKey_1.Leave, _cmdKey_2.Leave, _cmdKey_3.Leave _
        , _cmdKey_4.Leave, _cmdKey_5.Leave, _cmdKey_6.Leave, _cmdKey_7.Leave, _cmdKey_8.Leave, _cmdKey_9.Leave, _cmdKey_10.Leave, _cmdKey_11.Leave, _cmdKey_12.Leave
        Dim Index As Short = cmdKey.IndexOf(eventSender)
        Call MtyTool.LostFocus(cmdKey(Index), StatusBar1)
    End Sub
    '2021.08.02 UPGRADE E

    Private Sub frmSYKD020_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown
        Dim KeyCode As Short = eventArgs.KeyCode
        Dim Shift As Short = eventArgs.KeyData \ &H10000
        Select Case KeyCode
            Case System.Windows.Forms.Keys.F1
                If cmdKey(1).Enabled = True Then cmdKey(1).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(1), New System.EventArgs())
            Case System.Windows.Forms.Keys.F2
                If cmdKey(2).Enabled = True Then cmdKey(2).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(2), New System.EventArgs())
            Case System.Windows.Forms.Keys.F3
                If cmdKey(3).Enabled = True Then cmdKey(3).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(3), New System.EventArgs())
            Case System.Windows.Forms.Keys.F4
                If cmdKey(4).Enabled = True Then cmdKey(4).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(4), New System.EventArgs())
            Case System.Windows.Forms.Keys.F5
                If cmdKey(5).Enabled = True Then cmdKey(5).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(5), New System.EventArgs())
            Case System.Windows.Forms.Keys.F6
                If cmdKey(6).Enabled = True Then cmdKey(6).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(6), New System.EventArgs())
            Case System.Windows.Forms.Keys.F7
                If cmdKey(7).Enabled = True Then cmdKey(7).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(7), New System.EventArgs())
            Case System.Windows.Forms.Keys.F8
                If cmdKey(8).Enabled = True Then cmdKey(8).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(8), New System.EventArgs())
            Case System.Windows.Forms.Keys.F9
                If cmdKey(9).Enabled = True Then cmdKey(9).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(9), New System.EventArgs())
            Case System.Windows.Forms.Keys.F10
                If cmdKey(10).Enabled = True Then cmdKey(10).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(10), New System.EventArgs())
            Case System.Windows.Forms.Keys.F11
                If cmdKey(11).Enabled = True Then cmdKey(11).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(11), New System.EventArgs())
            Case System.Windows.Forms.Keys.F12
                If cmdKey(12).Enabled = True Then cmdKey(12).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(12), New System.EventArgs())
        End Select
    End Sub

    Private Sub frmSYKD020_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load

        Call FormDisp(Me)

        ' �����\��
        Call DispClear()
        Call ListDataDisp(1)

    End Sub

    Private Sub frmSYKD020_FormClosing(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Dim Cancel As Boolean = eventArgs.Cancel
        Dim UnloadMode As System.Windows.Forms.CloseReason = eventArgs.CloseReason
        If UnloadMode = System.Windows.Forms.CloseReason.UserClosing Then
            frmSYKD010.Show()
        End If
        eventArgs.Cancel = Cancel
    End Sub

    '2021.08.02 UPGRADE S  AIT)hieutv
    'Private Sub vaSpread1_DblClick(ByVal eventSender As System.Object, ByVal eventArgs As AxFPSpread._DSpreadEvents_DblClickEvent) Handles vaSpread1.DblClick
    '	If eventArgs.Col > 0 And eventArgs.Row > 0 Then
    '		Call cmdKey_Click(cmdKey.Item(1), New System.EventArgs())
    '	End If
    'End Sub
    Private Sub vaSpread1_DblClick(ByVal eventSender As System.Object, ByVal eventArgs As FarPoint.Win.Spread.CellClickEventArgs) Handles FpSpread1.CellDoubleClick
        If eventArgs.Column >= 0 And eventArgs.Row >= 0 AndAlso eventArgs.ColumnHeader = False And eventArgs.RowHeader = False Then
            Call cmdKey_Click(cmdKey.Item(1), New System.EventArgs())
        End If
    End Sub
    '2021.08.02 UPGRADE E

    '2021.08.02 UPGRADE S  AIT)hieutv
    'Private Sub vaSpread1_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles vaSpread1.Enter
    '	Call GotFocus(vaSpread1, StatusBar1)
    'End Sub
    Private Sub vaSpread1_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles FpSpread1.Enter
        Call MtyTool.GotFocus(FpSpread1, StatusBar1)
    End Sub
    '2021.08.02 UPGRADE E

    '2021.08.02 UPGRADE S  AIT)hieutv
    'Private Sub vaSpread1_KeyDownEvent(ByVal eventSender As System.Object, ByVal eventArgs As AxFPSpread.) Handles vaSpread1.KeyDownEvent
    '	If eventArgs.KeyCode = System.Windows.Forms.Keys.Return Then
    '		If vaSpread1.ActiveRow > 0 Then
    '			Call cmdKey_Click(cmdKey.Item(1), New System.EventArgs())
    '		End If
    '	End If
    'End Sub
    Private Sub vaSpread1_KeyDownEvent(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles FpSpread1.KeyDown
        If eventArgs.KeyCode = System.Windows.Forms.Keys.Return Then
            If FpSpread1.ActiveSheet.ActiveRowIndex >= 0 Then
                Call cmdKey_Click(cmdKey.Item(1), New System.EventArgs())
            End If
        End If
    End Sub
    '2021.08.02 UPGRADE E

    '2021.08.02 UPGRADE S  AIT)hieutv
    'Private Sub vaSpread1_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles vaSpread1.Leave
    '	Call LostFocus(vaSpread1, StatusBar1)
    'End Sub
    Private Sub vaSpread1_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles FpSpread1.Leave
        Call MtyTool.LostFocus(FpSpread1, StatusBar1)
        StatusBar1.Items.Item("Message").Text = ""
    End Sub
    '2021.08.02 UPGRADE E
End Class
