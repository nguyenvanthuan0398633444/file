<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class ViewForm
#Region "Windows Form Designer generated code "
    <System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
        MyBase.New()
        'This call is required by the Windows Form Designer.
        InitializeComponent()
    End Sub
    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer
	Public ToolTip1 As System.Windows.Forms.ToolTip
	'Public WithEvents vsPrinter1 As VSPrinter7Lib.VSPrinter
	Public WithEvents picBtn As ArrayList
	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(ViewForm))
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.C1FlexViewer1 = New C1.Win.FlexViewer.C1FlexViewer()
        CType(Me.C1FlexViewer1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'C1FlexViewer1
        '
        Me.C1FlexViewer1.AutoScrollMargin = New System.Drawing.Size(0, 0)
        Me.C1FlexViewer1.AutoScrollMinSize = New System.Drawing.Size(0, 0)
        Me.C1FlexViewer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.C1FlexViewer1.Location = New System.Drawing.Point(0, 0)
        Me.C1FlexViewer1.Name = "C1FlexViewer1"
        Me.C1FlexViewer1.Size = New System.Drawing.Size(460, 475)
        Me.C1FlexViewer1.TabIndex = 0
        '
        'ViewForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(460, 475)
        Me.Controls.Add(Me.C1FlexViewer1)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Location = New System.Drawing.Point(145, 128)
        Me.Name = "ViewForm"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "���"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        CType(Me.C1FlexViewer1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Public WithEvents C1FlexViewer1 As C1.Win.FlexViewer.C1FlexViewer
#End Region
End Class