<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frmSYKD115
#Region "Windows Form Designer generated code "
	<System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
		MyBase.New()
		'This call is required by the Windows Form Designer.
		InitializeComponent()
        cmdKey = New ArrayList()
        cmdKey.Add(Nothing)
        cmdKey.Add(_cmdKey_1)
        cmdKey.Add(Nothing)
        cmdKey.Add(Nothing)
        cmdKey.Add(Nothing)
        cmdKey.Add(Nothing)
        cmdKey.Add(Nothing)
        cmdKey.Add(Nothing)
        cmdKey.Add(Nothing)
        cmdKey.Add(Nothing)
        cmdKey.Add(Nothing)
        cmdKey.Add(Nothing)
        cmdKey.Add(_cmdKey_12)
    End Sub
	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer
	Public ToolTip1 As System.Windows.Forms.ToolTip
    '2021.08.02 UPGRADE S  AIT)hieunv
    'Public WithEvents vaSpread1 As AxFPSpread.AxvaSpread
    Friend WithEvents vaSpread1 As FarPoint.Win.Spread.FpSpread
    Friend WithEvents vaSpread1_Sheet1 As FarPoint.Win.Spread.SheetView
    '2021.08.02 UPGRADE E
    Public WithEvents _cmdKey_1 As System.Windows.Forms.Button
	Public WithEvents _cmdKey_12 As System.Windows.Forms.Button
	Public WithEvents Picture1 As System.Windows.Forms.Panel
	Public WithEvents _StatusBar1_Panel1 As System.Windows.Forms.ToolStripStatusLabel
    Public WithEvents Message As System.Windows.Forms.ToolStripStatusLabel
    Public WithEvents StatusBar1 As System.Windows.Forms.StatusStrip
    Public WithEvents lblTitle As System.Windows.Forms.Label
    Public WithEvents cmdKey As ArrayList
    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim CustomSpdHeader As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim CustomSpdHeader1 As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim CustomSpdHeader2 As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim CustomSpdHeader3 As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim CustomSpdHeader4 As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim CustomSpdHeader5 As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim CustomSpdHeader6 As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim CustomSpdHeader7 As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim CustomSpdHeader8 As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim CustomSpdHeader9 As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim CustomSpdHeader10 As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim CustomSpdHeader11 As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim CustomSpdHeader12 As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim CustomSpdHeader13 As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim CustomSpdHeader14 As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim CustomSpdHeader15 As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim CustomSpdHeader16 As Syk_d000.CustomSpdHeader = New Syk_d000.CustomSpdHeader()
        Dim DefaultFocusIndicatorRenderer1 As FarPoint.Win.Spread.DefaultFocusIndicatorRenderer = New FarPoint.Win.Spread.DefaultFocusIndicatorRenderer()
        Dim DefaultScrollBarRenderer1 As FarPoint.Win.Spread.DefaultScrollBarRenderer = New FarPoint.Win.Spread.DefaultScrollBarRenderer()
        Dim NamedStyle1 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("Color65637636771903017246")
        Dim NamedStyle2 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("Font211637636771903017246")
        Dim NamedStyle3 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("BorderEx637637636771903017246")
        Dim ComplexBorder1 As FarPoint.Win.ComplexBorder = New FarPoint.Win.ComplexBorder(New FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThinLine), New FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThinLine), New FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThinLine), New FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThinLine), New FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.None), False, False)
        Dim NamedStyle4 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("Color659637636771903027218")
        Dim TipAppearance1 As FarPoint.Win.Spread.TipAppearance = New FarPoint.Win.Spread.TipAppearance()
        Dim DefaultScrollBarRenderer2 As FarPoint.Win.Spread.DefaultScrollBarRenderer = New FarPoint.Win.Spread.DefaultScrollBarRenderer()
        Dim vaSpread1_InputMapWhenAncestorOfFocusedNormal As FarPoint.Win.Spread.InputMap
        Dim ComplexBorder2 As FarPoint.Win.ComplexBorder = New FarPoint.Win.ComplexBorder(New FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThinLine))
        Dim CheckBoxCellType1 As FarPoint.Win.Spread.CellType.CheckBoxCellType = New FarPoint.Win.Spread.CellType.CheckBoxCellType()
        Dim TextCellType1 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType()
        Dim TextCellType2 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType()
        Dim TextCellType3 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmSYKD115))
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.Picture1 = New System.Windows.Forms.Panel()
        Me._cmdKey_1 = New System.Windows.Forms.Button()
        Me._cmdKey_12 = New System.Windows.Forms.Button()
        Me.StatusBar1 = New System.Windows.Forms.StatusStrip()
        Me._StatusBar1_Panel1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.Message = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.vaSpread1 = New FarPoint.Win.Spread.FpSpread()
        Me.vaSpread1_Sheet1 = New FarPoint.Win.Spread.SheetView()
        vaSpread1_InputMapWhenAncestorOfFocusedNormal = New FarPoint.Win.Spread.InputMap()
        Me.Picture1.SuspendLayout()
        Me.StatusBar1.SuspendLayout()
        CType(Me.vaSpread1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.vaSpread1_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        CustomSpdHeader.Name = "CustomSpdHeader"
        CustomSpdHeader.PictureZoomEffect = False
        CustomSpdHeader.TextRotationAngle = 0R
        CustomSpdHeader.ZoomFactor = 1.0!
        CustomSpdHeader1.Name = "CustomSpdHeader1"
        CustomSpdHeader1.PictureZoomEffect = False
        CustomSpdHeader1.TextRotationAngle = 0R
        CustomSpdHeader1.ZoomFactor = 1.0!
        CustomSpdHeader2.Name = "CustomSpdHeader2"
        CustomSpdHeader2.PictureZoomEffect = False
        CustomSpdHeader2.TextRotationAngle = 0R
        CustomSpdHeader2.ZoomFactor = 1.0!
        CustomSpdHeader3.Name = "CustomSpdHeader3"
        CustomSpdHeader3.PictureZoomEffect = False
        CustomSpdHeader3.TextRotationAngle = 0R
        CustomSpdHeader3.ZoomFactor = 1.0!
        CustomSpdHeader4.Name = "CustomSpdHeader4"
        CustomSpdHeader4.PictureZoomEffect = False
        CustomSpdHeader4.TextRotationAngle = 0R
        CustomSpdHeader4.ZoomFactor = 1.0!
        CustomSpdHeader5.Name = "CustomSpdHeader5"
        CustomSpdHeader5.PictureZoomEffect = False
        CustomSpdHeader5.TextRotationAngle = 0R
        CustomSpdHeader5.ZoomFactor = 1.0!
        CustomSpdHeader6.Name = "CustomSpdHeader6"
        CustomSpdHeader6.PictureZoomEffect = False
        CustomSpdHeader6.TextRotationAngle = 0R
        CustomSpdHeader6.ZoomFactor = 1.0!
        CustomSpdHeader7.Name = "CustomSpdHeader7"
        CustomSpdHeader7.PictureZoomEffect = False
        CustomSpdHeader7.TextRotationAngle = 0R
        CustomSpdHeader7.ZoomFactor = 1.0!
        CustomSpdHeader8.Name = "CustomSpdHeader8"
        CustomSpdHeader8.PictureZoomEffect = False
        CustomSpdHeader8.TextRotationAngle = 0R
        CustomSpdHeader8.ZoomFactor = 1.0!
        CustomSpdHeader9.Name = "CustomSpdHeader9"
        CustomSpdHeader9.PictureZoomEffect = False
        CustomSpdHeader9.TextRotationAngle = 0R
        CustomSpdHeader9.ZoomFactor = 1.0!
        CustomSpdHeader10.Name = "CustomSpdHeader10"
        CustomSpdHeader10.PictureZoomEffect = False
        CustomSpdHeader10.TextRotationAngle = 0R
        CustomSpdHeader10.ZoomFactor = 1.0!
        CustomSpdHeader11.Name = "CustomSpdHeader11"
        CustomSpdHeader11.PictureZoomEffect = False
        CustomSpdHeader11.TextRotationAngle = 0R
        CustomSpdHeader11.ZoomFactor = 1.0!
        CustomSpdHeader12.Name = "CustomSpdHeader12"
        CustomSpdHeader12.PictureZoomEffect = False
        CustomSpdHeader12.TextRotationAngle = 0R
        CustomSpdHeader12.ZoomFactor = 1.0!
        CustomSpdHeader13.Name = "CustomSpdHeader13"
        CustomSpdHeader13.PictureZoomEffect = False
        CustomSpdHeader13.TextRotationAngle = 0R
        CustomSpdHeader13.ZoomFactor = 1.0!
        CustomSpdHeader14.Name = "CustomSpdHeader14"
        CustomSpdHeader14.PictureZoomEffect = False
        CustomSpdHeader14.TextRotationAngle = 0R
        CustomSpdHeader14.ZoomFactor = 1.0!
        CustomSpdHeader15.Name = "CustomSpdHeader15"
        CustomSpdHeader15.PictureZoomEffect = False
        CustomSpdHeader15.TextRotationAngle = 0R
        CustomSpdHeader15.ZoomFactor = 1.0!
        CustomSpdHeader16.Name = "CustomSpdHeader16"
        CustomSpdHeader16.PictureZoomEffect = False
        CustomSpdHeader16.TextRotationAngle = 0R
        CustomSpdHeader16.ZoomFactor = 1.0!
        '
        'Picture1
        '
        Me.Picture1.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Picture1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Picture1.Controls.Add(Me._cmdKey_1)
        Me.Picture1.Controls.Add(Me._cmdKey_12)
        Me.Picture1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Picture1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Picture1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Picture1.Location = New System.Drawing.Point(0, 292)
        Me.Picture1.Name = "Picture1"
        Me.Picture1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Picture1.Size = New System.Drawing.Size(452, 51)
        Me.Picture1.TabIndex = 3
        '
        '_cmdKey_1
        '
        Me._cmdKey_1.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_1.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_1.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_1.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_1.Location = New System.Drawing.Point(4, 4)
        Me._cmdKey_1.Name = "_cmdKey_1"
        Me._cmdKey_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_1.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_1.TabIndex = 1
        Me._cmdKey_1.Tag = "�O���o�����񍐏���������܂��B"
        Me._cmdKey_1.Text = "F1" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "�� ��"
        Me._cmdKey_1.UseVisualStyleBackColor = False
        '
        '_cmdKey_12
        '
        Me._cmdKey_12.BackColor = System.Drawing.SystemColors.Control
        Me._cmdKey_12.Cursor = System.Windows.Forms.Cursors.Default
        Me._cmdKey_12.Font = New System.Drawing.Font("MS Mincho", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me._cmdKey_12.ForeColor = System.Drawing.SystemColors.ControlText
        Me._cmdKey_12.Location = New System.Drawing.Point(366, 4)
        Me._cmdKey_12.Name = "_cmdKey_12"
        Me._cmdKey_12.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._cmdKey_12.Size = New System.Drawing.Size(77, 39)
        Me._cmdKey_12.TabIndex = 2
        Me._cmdKey_12.Tag = "�I�����܂��B"
        Me._cmdKey_12.Text = "F12" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "�I ��"
        Me._cmdKey_12.UseVisualStyleBackColor = False
        '
        'StatusBar1
        '
        Me.StatusBar1.Font = New System.Drawing.Font("MS Mincho", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.StatusBar1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me._StatusBar1_Panel1, Me.Message})
        Me.StatusBar1.Location = New System.Drawing.Point(0, 343)
        Me.StatusBar1.Name = "StatusBar1"
        Me.StatusBar1.Size = New System.Drawing.Size(452, 23)
        Me.StatusBar1.SizingGrip = False
        Me.StatusBar1.TabIndex = 2
        '
        '_StatusBar1_Panel1
        '
        Me._StatusBar1_Panel1.AutoSize = False
        Me._StatusBar1_Panel1.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me._StatusBar1_Panel1.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter
        Me._StatusBar1_Panel1.Margin = New System.Windows.Forms.Padding(0)
        Me._StatusBar1_Panel1.Name = "_StatusBar1_Panel1"
        Me._StatusBar1_Panel1.Size = New System.Drawing.Size(117, 23)
        '
        'Message
        '
        Me.Message.AutoSize = False
        Me.Message.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me.Message.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter
        Me.Message.Margin = New System.Windows.Forms.Padding(0)
        Me.Message.Name = "Message"
        Me.Message.Size = New System.Drawing.Size(330, 23)
        Me.Message.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblTitle
        '
        Me.lblTitle.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.lblTitle.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTitle.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblTitle.Font = New System.Drawing.Font("MS Mincho", 20.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblTitle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.lblTitle.Location = New System.Drawing.Point(0, 0)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblTitle.Size = New System.Drawing.Size(451, 31)
        Me.lblTitle.TabIndex = 4
        Me.lblTitle.Text = " �O���o�����񍐏����"
        '
        'vaSpread1
        '
        Me.vaSpread1.AccessibleDescription = "vaSpread1, Sheet1, Row 0, Column 0"
        Me.vaSpread1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.vaSpread1.FocusRenderer = DefaultFocusIndicatorRenderer1
        Me.vaSpread1.HorizontalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.vaSpread1.HorizontalScrollBar.Name = ""
        Me.vaSpread1.HorizontalScrollBar.Renderer = DefaultScrollBarRenderer1
        Me.vaSpread1.HorizontalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.Never
        Me.vaSpread1.Location = New System.Drawing.Point(12, 44)
        Me.vaSpread1.Name = "vaSpread1"
        NamedStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        NamedStyle1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        NamedStyle1.Locked = False
        NamedStyle2.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        NamedStyle2.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold)
        NamedStyle2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        NamedStyle2.Locked = False
        NamedStyle3.BackColor = System.Drawing.Color.Empty
        NamedStyle3.Border = ComplexBorder1
        NamedStyle3.ForeColor = System.Drawing.Color.Empty
        NamedStyle4.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        NamedStyle4.Border = ComplexBorder1
        NamedStyle4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.vaSpread1.RowSplitBoxPolicy = FarPoint.Win.Spread.SplitBoxPolicy.Never
        Me.vaSpread1.SelectionBlockOptions = FarPoint.Win.Spread.SelectionBlockOptions.None
        Me.vaSpread1.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.vaSpread1_Sheet1})
        Me.vaSpread1.Size = New System.Drawing.Size(427, 229)
        Me.vaSpread1.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Classic
        Me.vaSpread1.NamedStyles.AddRange(New FarPoint.Win.Spread.NamedStyle() {NamedStyle1, NamedStyle2, NamedStyle3, NamedStyle4})
        Me.vaSpread1.TabIndex = 5
        Me.vaSpread1.Tag = "�f�[�^��I�����ĉ������B"
        TipAppearance1.BackColor = System.Drawing.SystemColors.Info
        TipAppearance1.Font = New System.Drawing.Font("MS PMincho", 9.0!)
        TipAppearance1.ForeColor = System.Drawing.SystemColors.InfoText
        Me.vaSpread1.TextTipAppearance = TipAppearance1
        Me.vaSpread1.VerticalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.vaSpread1.VerticalScrollBar.Name = ""
        Me.vaSpread1.VerticalScrollBar.Renderer = DefaultScrollBarRenderer2
        Me.vaSpread1.VisualStyles = FarPoint.Win.VisualStyles.Off
        vaSpread1_InputMapWhenAncestorOfFocusedNormal.Parent = New FarPoint.Win.Spread.InputMap()
        vaSpread1_InputMapWhenAncestorOfFocusedNormal.Parent.Put(New FarPoint.Win.Spread.Keystroke(System.Windows.Forms.Keys.Up, System.Windows.Forms.Keys.None), FarPoint.Win.Spread.SpreadActions.MoveToPreviousRow)
        vaSpread1_InputMapWhenAncestorOfFocusedNormal.Parent.Put(New FarPoint.Win.Spread.Keystroke(System.Windows.Forms.Keys.Down, System.Windows.Forms.Keys.None), FarPoint.Win.Spread.SpreadActions.MoveToNextRow)
        vaSpread1_InputMapWhenAncestorOfFocusedNormal.Parent.Put(New FarPoint.Win.Spread.Keystroke(System.Windows.Forms.Keys.Left, System.Windows.Forms.Keys.None), FarPoint.Win.Spread.SpreadActions.MoveToPreviousColumnVisual)
        vaSpread1_InputMapWhenAncestorOfFocusedNormal.Parent.Put(New FarPoint.Win.Spread.Keystroke(System.Windows.Forms.Keys.Right, System.Windows.Forms.Keys.None), FarPoint.Win.Spread.SpreadActions.MoveToNextColumnVisual)
        vaSpread1_InputMapWhenAncestorOfFocusedNormal.Parent.Put(New FarPoint.Win.Spread.Keystroke(System.Windows.Forms.Keys.Up, CType((System.Windows.Forms.Keys.Shift Or System.Windows.Forms.Keys.None), System.Windows.Forms.Keys)), FarPoint.Win.Spread.SpreadActions.ExtendToPreviousRow)
        vaSpread1_InputMapWhenAncestorOfFocusedNormal.Parent.Put(New FarPoint.Win.Spread.Keystroke(System.Windows.Forms.Keys.Down, CType((System.Windows.Forms.Keys.Shift Or System.Windows.Forms.Keys.None), System.Windows.Forms.Keys)), FarPoint.Win.Spread.SpreadActions.ExtendToNextRow)
        vaSpread1_InputMapWhenAncestorOfFocusedNormal.Parent.Put(New FarPoint.Win.Spread.Keystroke(System.Windows.Forms.Keys.Left, CType((System.Windows.Forms.Keys.Shift Or System.Windows.Forms.Keys.None), System.Windows.Forms.Keys)), FarPoint.Win.Spread.SpreadActions.ExtendToPreviousColumnVisual)
        vaSpread1_InputMapWhenAncestorOfFocusedNormal.Parent.Put(New FarPoint.Win.Spread.Keystroke(System.Windows.Forms.Keys.Right, CType((System.Windows.Forms.Keys.Shift Or System.Windows.Forms.Keys.None), System.Windows.Forms.Keys)), FarPoint.Win.Spread.SpreadActions.ExtendToNextColumnVisual)
        vaSpread1_InputMapWhenAncestorOfFocusedNormal.Parent.Put(New FarPoint.Win.Spread.Keystroke(System.Windows.Forms.Keys.Up, CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.None), System.Windows.Forms.Keys)), FarPoint.Win.Spread.SpreadActions.MoveToPreviousRow)
        vaSpread1_InputMapWhenAncestorOfFocusedNormal.Parent.Put(New FarPoint.Win.Spread.Keystroke(System.Windows.Forms.Keys.Down, CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.None), System.Windows.Forms.Keys)), FarPoint.Win.Spread.SpreadActions.MoveToNextRow)
        vaSpread1_InputMapWhenAncestorOfFocusedNormal.Parent.Put(New FarPoint.Win.Spread.Keystroke(System.Windows.Forms.Keys.Left, CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.None), System.Windows.Forms.Keys)), FarPoint.Win.Spread.SpreadActions.MoveToPreviousColumnVisual)
        vaSpread1_InputMapWhenAncestorOfFocusedNormal.Parent.Put(New FarPoint.Win.Spread.Keystroke(System.Windows.Forms.Keys.Right, CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.None), System.Windows.Forms.Keys)), FarPoint.Win.Spread.SpreadActions.MoveToNextColumnVisual)
        vaSpread1_InputMapWhenAncestorOfFocusedNormal.Parent.Put(New FarPoint.Win.Spread.Keystroke(System.Windows.Forms.Keys.Up, CType(((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Shift) _
                    Or System.Windows.Forms.Keys.None), System.Windows.Forms.Keys)), FarPoint.Win.Spread.SpreadActions.ExtendToPreviousRow)
        vaSpread1_InputMapWhenAncestorOfFocusedNormal.Parent.Put(New FarPoint.Win.Spread.Keystroke(System.Windows.Forms.Keys.Down, CType(((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Shift) _
                    Or System.Windows.Forms.Keys.None), System.Windows.Forms.Keys)), FarPoint.Win.Spread.SpreadActions.ExtendToNextRow)
        vaSpread1_InputMapWhenAncestorOfFocusedNormal.Parent.Put(New FarPoint.Win.Spread.Keystroke(System.Windows.Forms.Keys.Left, CType(((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Shift) _
                    Or System.Windows.Forms.Keys.None), System.Windows.Forms.Keys)), FarPoint.Win.Spread.SpreadActions.ExtendToPreviousColumnVisual)
        vaSpread1_InputMapWhenAncestorOfFocusedNormal.Parent.Put(New FarPoint.Win.Spread.Keystroke(System.Windows.Forms.Keys.Right, CType(((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Shift) _
                    Or System.Windows.Forms.Keys.None), System.Windows.Forms.Keys)), FarPoint.Win.Spread.SpreadActions.ExtendToNextColumnVisual)
        vaSpread1_InputMapWhenAncestorOfFocusedNormal.Parent.Put(New FarPoint.Win.Spread.Keystroke(System.Windows.Forms.Keys.PageUp, System.Windows.Forms.Keys.None), FarPoint.Win.Spread.SpreadActions.MoveToPreviousPageOfRows)
        vaSpread1_InputMapWhenAncestorOfFocusedNormal.Parent.Put(New FarPoint.Win.Spread.Keystroke(System.Windows.Forms.Keys.[Next], System.Windows.Forms.Keys.None), FarPoint.Win.Spread.SpreadActions.MoveToNextPageOfRows)
        vaSpread1_InputMapWhenAncestorOfFocusedNormal.Parent.Put(New FarPoint.Win.Spread.Keystroke(System.Windows.Forms.Keys.PageUp, CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.None), System.Windows.Forms.Keys)), FarPoint.Win.Spread.SpreadActions.MoveToPreviousPageOfColumns)
        vaSpread1_InputMapWhenAncestorOfFocusedNormal.Parent.Put(New FarPoint.Win.Spread.Keystroke(System.Windows.Forms.Keys.[Next], CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.None), System.Windows.Forms.Keys)), FarPoint.Win.Spread.SpreadActions.MoveToNextPageOfColumns)
        vaSpread1_InputMapWhenAncestorOfFocusedNormal.Parent.Put(New FarPoint.Win.Spread.Keystroke(System.Windows.Forms.Keys.PageUp, CType((System.Windows.Forms.Keys.Shift Or System.Windows.Forms.Keys.None), System.Windows.Forms.Keys)), FarPoint.Win.Spread.SpreadActions.ExtendToPreviousPageOfRows)
        vaSpread1_InputMapWhenAncestorOfFocusedNormal.Parent.Put(New FarPoint.Win.Spread.Keystroke(System.Windows.Forms.Keys.[Next], CType((System.Windows.Forms.Keys.Shift Or System.Windows.Forms.Keys.None), System.Windows.Forms.Keys)), FarPoint.Win.Spread.SpreadActions.ExtendToNextPageOfRows)
        vaSpread1_InputMapWhenAncestorOfFocusedNormal.Parent.Put(New FarPoint.Win.Spread.Keystroke(System.Windows.Forms.Keys.PageUp, CType(((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Shift) _
                    Or System.Windows.Forms.Keys.None), System.Windows.Forms.Keys)), FarPoint.Win.Spread.SpreadActions.ExtendToPreviousPageOfColumns)
        vaSpread1_InputMapWhenAncestorOfFocusedNormal.Parent.Put(New FarPoint.Win.Spread.Keystroke(System.Windows.Forms.Keys.[Next], CType(((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Shift) _
                    Or System.Windows.Forms.Keys.None), System.Windows.Forms.Keys)), FarPoint.Win.Spread.SpreadActions.ExtendToNextPageOfColumns)
        vaSpread1_InputMapWhenAncestorOfFocusedNormal.Parent.Put(New FarPoint.Win.Spread.Keystroke(System.Windows.Forms.Keys.Home, System.Windows.Forms.Keys.None), FarPoint.Win.Spread.SpreadActions.MoveToFirstColumn)
        vaSpread1_InputMapWhenAncestorOfFocusedNormal.Parent.Put(New FarPoint.Win.Spread.Keystroke(System.Windows.Forms.Keys.[End], System.Windows.Forms.Keys.None), FarPoint.Win.Spread.SpreadActions.MoveToLastColumn)
        vaSpread1_InputMapWhenAncestorOfFocusedNormal.Parent.Put(New FarPoint.Win.Spread.Keystroke(System.Windows.Forms.Keys.Home, CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.None), System.Windows.Forms.Keys)), FarPoint.Win.Spread.SpreadActions.MoveToFirstCell)
        vaSpread1_InputMapWhenAncestorOfFocusedNormal.Parent.Put(New FarPoint.Win.Spread.Keystroke(System.Windows.Forms.Keys.[End], CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.None), System.Windows.Forms.Keys)), FarPoint.Win.Spread.SpreadActions.MoveToLastCell)
        vaSpread1_InputMapWhenAncestorOfFocusedNormal.Parent.Put(New FarPoint.Win.Spread.Keystroke(System.Windows.Forms.Keys.Home, CType((System.Windows.Forms.Keys.Shift Or System.Windows.Forms.Keys.None), System.Windows.Forms.Keys)), FarPoint.Win.Spread.SpreadActions.ExtendToFirstColumn)
        vaSpread1_InputMapWhenAncestorOfFocusedNormal.Parent.Put(New FarPoint.Win.Spread.Keystroke(System.Windows.Forms.Keys.[End], CType((System.Windows.Forms.Keys.Shift Or System.Windows.Forms.Keys.None), System.Windows.Forms.Keys)), FarPoint.Win.Spread.SpreadActions.ExtendToLastColumn)
        vaSpread1_InputMapWhenAncestorOfFocusedNormal.Parent.Put(New FarPoint.Win.Spread.Keystroke(System.Windows.Forms.Keys.Home, CType(((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Shift) _
                    Or System.Windows.Forms.Keys.None), System.Windows.Forms.Keys)), FarPoint.Win.Spread.SpreadActions.ExtendToFirstCell)
        vaSpread1_InputMapWhenAncestorOfFocusedNormal.Parent.Put(New FarPoint.Win.Spread.Keystroke(System.Windows.Forms.Keys.[End], CType(((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Shift) _
                    Or System.Windows.Forms.Keys.None), System.Windows.Forms.Keys)), FarPoint.Win.Spread.SpreadActions.ExtendToLastCell)
        vaSpread1_InputMapWhenAncestorOfFocusedNormal.Parent.Put(New FarPoint.Win.Spread.Keystroke(System.Windows.Forms.Keys.Space, CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.None), System.Windows.Forms.Keys)), FarPoint.Win.Spread.SpreadActions.SelectColumn)
        vaSpread1_InputMapWhenAncestorOfFocusedNormal.Parent.Put(New FarPoint.Win.Spread.Keystroke(System.Windows.Forms.Keys.Space, CType(((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Shift) _
                    Or System.Windows.Forms.Keys.None), System.Windows.Forms.Keys)), FarPoint.Win.Spread.SpreadActions.SelectSheet)
        vaSpread1_InputMapWhenAncestorOfFocusedNormal.Parent.Put(New FarPoint.Win.Spread.Keystroke(System.Windows.Forms.Keys.Escape, System.Windows.Forms.Keys.None), FarPoint.Win.Spread.SpreadActions.CancelEditing)
        vaSpread1_InputMapWhenAncestorOfFocusedNormal.Parent.Put(New FarPoint.Win.Spread.Keystroke(System.Windows.Forms.Keys.[Return], System.Windows.Forms.Keys.None), FarPoint.Win.Spread.SpreadActions.StopEditing)
        vaSpread1_InputMapWhenAncestorOfFocusedNormal.Parent.Put(New FarPoint.Win.Spread.Keystroke(System.Windows.Forms.Keys.[Return], CType(((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Shift) _
                    Or System.Windows.Forms.Keys.None), System.Windows.Forms.Keys)), FarPoint.Win.Spread.SpreadActions.CSEStopEditing)
        vaSpread1_InputMapWhenAncestorOfFocusedNormal.Parent.Put(New FarPoint.Win.Spread.Keystroke(System.Windows.Forms.Keys.Tab, System.Windows.Forms.Keys.None), FarPoint.Win.Spread.SpreadActions.MoveToNextColumnWrap)
        vaSpread1_InputMapWhenAncestorOfFocusedNormal.Parent.Put(New FarPoint.Win.Spread.Keystroke(System.Windows.Forms.Keys.Tab, CType((System.Windows.Forms.Keys.Shift Or System.Windows.Forms.Keys.None), System.Windows.Forms.Keys)), FarPoint.Win.Spread.SpreadActions.MoveToPreviousColumnWrap)
        vaSpread1_InputMapWhenAncestorOfFocusedNormal.Parent.Put(New FarPoint.Win.Spread.Keystroke(System.Windows.Forms.Keys.F2, System.Windows.Forms.Keys.None), FarPoint.Win.Spread.SpreadActions.ClearCell)
        vaSpread1_InputMapWhenAncestorOfFocusedNormal.Parent.Put(New FarPoint.Win.Spread.Keystroke(System.Windows.Forms.Keys.OemMinus, CType(((System.Windows.Forms.Keys.Alt Or System.Windows.Forms.Keys.Shift) _
                    Or System.Windows.Forms.Keys.None), System.Windows.Forms.Keys)), FarPoint.Win.Spread.SpreadActions.AutoSum)
        vaSpread1_InputMapWhenAncestorOfFocusedNormal.Parent.Put(New FarPoint.Win.Spread.Keystroke(System.Windows.Forms.Keys.F3, System.Windows.Forms.Keys.None), FarPoint.Win.Spread.SpreadActions.DateTimeNow)
        vaSpread1_InputMapWhenAncestorOfFocusedNormal.Parent.Put(New FarPoint.Win.Spread.Keystroke(System.Windows.Forms.Keys.F4, System.Windows.Forms.Keys.None), FarPoint.Win.Spread.SpreadActions.ShowSubEditor)
        vaSpread1_InputMapWhenAncestorOfFocusedNormal.Parent.Put(New FarPoint.Win.Spread.Keystroke(System.Windows.Forms.Keys.Down, CType((System.Windows.Forms.Keys.Alt Or System.Windows.Forms.Keys.None), System.Windows.Forms.Keys)), FarPoint.Win.Spread.SpreadActions.ComboShowList)
        vaSpread1_InputMapWhenAncestorOfFocusedNormal.Parent.Put(New FarPoint.Win.Spread.Keystroke(System.Windows.Forms.Keys.Up, CType((System.Windows.Forms.Keys.Alt Or System.Windows.Forms.Keys.None), System.Windows.Forms.Keys)), FarPoint.Win.Spread.SpreadActions.ComboShowList)
        Me.vaSpread1.SetInputMap(FarPoint.Win.Spread.InputMapMode.WhenAncestorOfFocused, FarPoint.Win.Spread.OperationMode.Normal, vaSpread1_InputMapWhenAncestorOfFocusedNormal)
        '
        'vaSpread1_Sheet1
        '
        Me.vaSpread1_Sheet1.Reset()
        Me.vaSpread1_Sheet1.SheetName = "Sheet1"
        'Formulas and custom names must be loaded with R1C1 reference style
        Me.vaSpread1_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1
        Me.vaSpread1_Sheet1.ColumnCount = 5
        Me.vaSpread1_Sheet1.RowCount = 20
        Me.vaSpread1_Sheet1.ActiveSkin = FarPoint.Win.Spread.DefaultSkins.Default
        Me.vaSpread1_Sheet1.Cells.Get(0, 0).Value = 0
        Me.vaSpread1_Sheet1.Cells.Get(1, 0).Value = 0
        Me.vaSpread1_Sheet1.Cells.Get(2, 0).Value = 0
        Me.vaSpread1_Sheet1.ColumnFooter.Columns.Default.Resizable = True
        Me.vaSpread1_Sheet1.ColumnFooter.Columns.Default.SortIndicator = FarPoint.Win.Spread.Model.SortIndicator.None
        Me.vaSpread1_Sheet1.ColumnFooter.Columns.Default.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.vaSpread1_Sheet1.ColumnFooter.Columns.Default.Width = 64.0!
        Me.vaSpread1_Sheet1.ColumnFooter.DefaultStyle.BackColor = System.Drawing.Color.Empty
        Me.vaSpread1_Sheet1.ColumnFooter.DefaultStyle.ForeColor = System.Drawing.Color.Empty
        Me.vaSpread1_Sheet1.ColumnFooter.DefaultStyle.Locked = False
        Me.vaSpread1_Sheet1.ColumnFooter.DefaultStyle.Parent = "HeaderDefault"
        Me.vaSpread1_Sheet1.ColumnFooter.DefaultStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.vaSpread1_Sheet1.ColumnFooter.Rows.Default.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.vaSpread1_Sheet1.ColumnFooterSheetCornerStyle.BackColor = System.Drawing.Color.Empty
        Me.vaSpread1_Sheet1.ColumnFooterSheetCornerStyle.ForeColor = System.Drawing.Color.Empty
        Me.vaSpread1_Sheet1.ColumnFooterSheetCornerStyle.Locked = False
        Me.vaSpread1_Sheet1.ColumnFooterSheetCornerStyle.Parent = "RowHeaderDefault"
        Me.vaSpread1_Sheet1.ColumnFooterSheetCornerStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.vaSpread1_Sheet1.ColumnHeader.AutoText = FarPoint.Win.Spread.HeaderAutoText.Blank
        Me.vaSpread1_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = "������"
        Me.vaSpread1_Sheet1.ColumnHeader.Cells.Get(0, 2).Value = "���@�@��"
        Me.vaSpread1_Sheet1.ColumnHeader.Cells.Get(0, 3).Value = "�Ǝк���"
        Me.vaSpread1_Sheet1.ColumnHeader.Cells.Get(0, 4).Value = "�ƎЖ���"
        Me.vaSpread1_Sheet1.ColumnHeader.Columns.Default.Resizable = True
        Me.vaSpread1_Sheet1.ColumnHeader.Columns.Default.SortIndicator = FarPoint.Win.Spread.Model.SortIndicator.None
        Me.vaSpread1_Sheet1.ColumnHeader.Columns.Default.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.vaSpread1_Sheet1.ColumnHeader.DefaultStyle.BackColor = System.Drawing.Color.Empty
        Me.vaSpread1_Sheet1.ColumnHeader.DefaultStyle.Border = ComplexBorder2
        Me.vaSpread1_Sheet1.ColumnHeader.DefaultStyle.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.vaSpread1_Sheet1.ColumnHeader.DefaultStyle.ForeColor = System.Drawing.Color.Empty
        Me.vaSpread1_Sheet1.ColumnHeader.DefaultStyle.Locked = False
        Me.vaSpread1_Sheet1.ColumnHeader.DefaultStyle.Parent = "HeaderDefault"
        Me.vaSpread1_Sheet1.ColumnHeader.DefaultStyle.Renderer = CustomSpdHeader15
        Me.vaSpread1_Sheet1.ColumnHeader.DefaultStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.vaSpread1_Sheet1.ColumnHeader.Rows.Default.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.vaSpread1_Sheet1.ColumnHeader.Rows.Get(0).Height = 27.0!
        Me.vaSpread1_Sheet1.Columns.Default.Resizable = True
        Me.vaSpread1_Sheet1.Columns.Default.SortIndicator = FarPoint.Win.Spread.Model.SortIndicator.None
        Me.vaSpread1_Sheet1.Columns.Default.Width = 64.0!
        Me.vaSpread1_Sheet1.Columns.Get(0).BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.vaSpread1_Sheet1.Columns.Get(0).Border = ComplexBorder1
        CheckBoxCellType1.TextFalse = "0"
        CheckBoxCellType1.TextTrue = "1"
        CheckBoxCellType1.ThreeState = True
        Me.vaSpread1_Sheet1.Columns.Get(0).CellType = CheckBoxCellType1
        Me.vaSpread1_Sheet1.Columns.Get(0).ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.vaSpread1_Sheet1.Columns.Get(0).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.vaSpread1_Sheet1.Columns.Get(0).Resizable = False
        Me.vaSpread1_Sheet1.Columns.Get(0).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.vaSpread1_Sheet1.Columns.Get(0).Width = 21.0!
        TextCellType1.MaxLength = 60
        Me.vaSpread1_Sheet1.Columns.Get(1).CellType = TextCellType1
        Me.vaSpread1_Sheet1.Columns.Get(1).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.vaSpread1_Sheet1.Columns.Get(1).Label = "������"
        Me.vaSpread1_Sheet1.Columns.Get(1).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        TextCellType2.MaxLength = 60
        Me.vaSpread1_Sheet1.Columns.Get(2).CellType = TextCellType2
        Me.vaSpread1_Sheet1.Columns.Get(2).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Left
        Me.vaSpread1_Sheet1.Columns.Get(2).Label = "���@�@��"
        Me.vaSpread1_Sheet1.Columns.Get(2).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.vaSpread1_Sheet1.Columns.Get(2).Width = 288.0!
        Me.vaSpread1_Sheet1.Columns.Get(3).CellType = TextCellType1
        Me.vaSpread1_Sheet1.Columns.Get(3).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.vaSpread1_Sheet1.Columns.Get(3).Label = "�Ǝк���"
        Me.vaSpread1_Sheet1.Columns.Get(3).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.vaSpread1_Sheet1.Columns.Get(3).Visible = False
        Me.vaSpread1_Sheet1.Columns.Get(3).Width = 0!
        Me.vaSpread1_Sheet1.Columns.Get(4).CellType = TextCellType2
        Me.vaSpread1_Sheet1.Columns.Get(4).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Left
        Me.vaSpread1_Sheet1.Columns.Get(4).Label = "�ƎЖ���"
        Me.vaSpread1_Sheet1.Columns.Get(4).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.vaSpread1_Sheet1.Columns.Get(4).Visible = False
        Me.vaSpread1_Sheet1.Columns.Get(4).Width = 0!
        Me.vaSpread1_Sheet1.DefaultStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        TextCellType3.MaxLength = 60
        Me.vaSpread1_Sheet1.DefaultStyle.CellType = TextCellType3
        Me.vaSpread1_Sheet1.DefaultStyle.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold)
        Me.vaSpread1_Sheet1.DefaultStyle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.vaSpread1_Sheet1.DefaultStyle.Locked = False
        Me.vaSpread1_Sheet1.DefaultStyle.Parent = "DataAreaDefault"
        Me.vaSpread1_Sheet1.DefaultStyle.Renderer = TextCellType3
        Me.vaSpread1_Sheet1.FilterBar.DefaultStyle.BackColor = System.Drawing.Color.Empty
        Me.vaSpread1_Sheet1.FilterBar.DefaultStyle.ForeColor = System.Drawing.Color.Empty
        Me.vaSpread1_Sheet1.FilterBar.DefaultStyle.Locked = False
        Me.vaSpread1_Sheet1.FilterBar.DefaultStyle.Parent = "FilterBarDefault"
        Me.vaSpread1_Sheet1.FilterBar.DefaultStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.vaSpread1_Sheet1.FilterBarHeaderStyle.BackColor = System.Drawing.Color.Empty
        Me.vaSpread1_Sheet1.FilterBarHeaderStyle.ForeColor = System.Drawing.Color.Empty
        Me.vaSpread1_Sheet1.FilterBarHeaderStyle.Locked = False
        Me.vaSpread1_Sheet1.FilterBarHeaderStyle.Parent = "RowHeaderDefault"
        Me.vaSpread1_Sheet1.FilterBarHeaderStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.vaSpread1_Sheet1.OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        Me.vaSpread1_Sheet1.Protect = True
        Me.vaSpread1_Sheet1.RowHeader.Columns.Default.Resizable = False
        Me.vaSpread1_Sheet1.RowHeader.Columns.Default.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.vaSpread1_Sheet1.RowHeader.DefaultStyle.BackColor = System.Drawing.Color.Empty
        Me.vaSpread1_Sheet1.RowHeader.DefaultStyle.Border = ComplexBorder2
        Me.vaSpread1_Sheet1.RowHeader.DefaultStyle.Font = New System.Drawing.Font("MS Mincho", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.vaSpread1_Sheet1.RowHeader.DefaultStyle.ForeColor = System.Drawing.Color.Empty
        Me.vaSpread1_Sheet1.RowHeader.DefaultStyle.Locked = False
        Me.vaSpread1_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderDefault"
        Me.vaSpread1_Sheet1.RowHeader.DefaultStyle.Renderer = CustomSpdHeader16
        Me.vaSpread1_Sheet1.RowHeader.DefaultStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.vaSpread1_Sheet1.RowHeader.Rows.Default.Resizable = False
        Me.vaSpread1_Sheet1.RowHeader.Rows.Default.Visible = True
        Me.vaSpread1_Sheet1.RowHeader.Rows.Default.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.vaSpread1_Sheet1.Rows.Default.Resizable = False
        Me.vaSpread1_Sheet1.Rows.Default.Visible = True
        Me.vaSpread1_Sheet1.SelectionUnit = FarPoint.Win.Spread.Model.SelectionUnit.Row
        Me.vaSpread1_Sheet1.SheetCornerStyle.BackColor = System.Drawing.Color.Empty
        Me.vaSpread1_Sheet1.SheetCornerStyle.ForeColor = System.Drawing.Color.Empty
        Me.vaSpread1_Sheet1.SheetCornerStyle.Locked = False
        Me.vaSpread1_Sheet1.SheetCornerStyle.Parent = "RowHeaderDefault"
        Me.vaSpread1_Sheet1.SheetCornerStyle.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.vaSpread1_Sheet1.SheetCornerStyle.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.vaSpread1_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1
        '
        'frmSYKD115
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(452, 366)
        Me.Controls.Add(Me.vaSpread1)
        Me.Controls.Add(Me.Picture1)
        Me.Controls.Add(Me.StatusBar1)
        Me.Controls.Add(Me.lblTitle)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.KeyPreview = True
        Me.Location = New System.Drawing.Point(203, 231)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmSYKD115"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "�H���Ǘ��V�X�e��"
        Me.Picture1.ResumeLayout(False)
        Me.StatusBar1.ResumeLayout(False)
        Me.StatusBar1.PerformLayout()
        CType(Me.vaSpread1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.vaSpread1_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
#End Region
End Class