'UPGRADE_WARNING: The entire project must be compiled once before a form with an ActiveX Control Array can be displayed

Imports System.ComponentModel

<ProvideProperty("Index",GetType(.AximText))> Public Class AximTextArray
	Inherits Microsoft.VisualBasic.Compatibility.VB6.BaseOcxArray
	Implements IExtenderProvider

	Public Sub New()
		MyBase.New()
	End Sub

	Public Sub New(ByVal Container As IContainer)
		MyBase.New(Container)
	End Sub

	Public Shadows Event [Change] (ByVal sender As System.Object, ByVal e As System.EventArgs)
	Public Shadows Event [CloseUp] (ByVal sender As System.Object, ByVal e As .ITextEvents_CloseUpEvent)
	Public Shadows Event [DropOpen] (ByVal sender As System.Object, ByVal e As .ITextEvents_DropOpenEvent)
	Public Shadows Event [DBError] (ByVal sender As System.Object, ByVal e As .ITextEvents_DBErrorEvent)
	Public Shadows Event [EditModeChange] (ByVal sender As System.Object, ByVal e As System.EventArgs)
	Public Shadows Event [InvalidInput] (ByVal sender As System.Object, ByVal e As System.EventArgs)
	Public Shadows Event [Furigana] (ByVal sender As System.Object, ByVal e As .ITextEvents_FuriganaEvent)
	Public Shadows Event [KeyDownEvent] (ByVal sender As System.Object, ByVal e As .ITextEvents_KeyDownEvent)
	Public Shadows Event [KeyPressEvent] (ByVal sender As System.Object, ByVal e As .ITextEvents_KeyPressEvent)
	Public Shadows Event [KeyUpEvent] (ByVal sender As System.Object, ByVal e As .ITextEvents_KeyUpEvent)
	Public Shadows Event [MouseDownEvent] (ByVal sender As System.Object, ByVal e As .ITextEvents_MouseDownEvent)
	Public Shadows Event [MouseUpEvent] (ByVal sender As System.Object, ByVal e As .ITextEvents_MouseUpEvent)
	Public Shadows Event [MouseMoveEvent] (ByVal sender As System.Object, ByVal e As .ITextEvents_MouseMoveEvent)
	Public Shadows Event [ClickEvent] (ByVal sender As System.Object, ByVal e As System.EventArgs)
	Public Shadows Event [DblClick] (ByVal sender As System.Object, ByVal e As System.EventArgs)
	Public Shadows Event [OLECompleteDrag] (ByVal sender As System.Object, ByVal e As .ITextEvents_OLECompleteDragEvent)
	Public Shadows Event [OLEDragDrop] (ByVal sender As System.Object, ByVal e As .ITextEvents_OLEDragDropEvent)
	Public Shadows Event [OLEDragOver] (ByVal sender As System.Object, ByVal e As .ITextEvents_OLEDragOverEvent)
	Public Shadows Event [OLEGiveFeedback] (ByVal sender As System.Object, ByVal e As .ITextEvents_OLEGiveFeedbackEvent)
	Public Shadows Event [OLESetData] (ByVal sender As System.Object, ByVal e As .ITextEvents_OLESetDataEvent)
	Public Shadows Event [OLEStartDrag] (ByVal sender As System.Object, ByVal e As .ITextEvents_OLEStartDragEvent)
	Public Shadows Event [MouseEnterEvent] (ByVal sender As System.Object, ByVal e As System.EventArgs)
	Public Shadows Event [MouseExit] (ByVal sender As System.Object, ByVal e As System.EventArgs)
	Public Shadows Event [KeyExit] (ByVal sender As System.Object, ByVal e As .ITextEvents_KeyExitEvent)

	<System.ComponentModel.EditorBrowsableAttribute(System.ComponentModel.EditorBrowsableState.Never)> Public Function CanExtend(ByVal target As Object) As Boolean Implements IExtenderProvider.CanExtend
		If TypeOf target Is .AximText Then
			Return BaseCanExtend(target)
		End If
	End Function

	Public Function GetIndex(ByVal o As .AximText) As Short
		Return BaseGetIndex(o)
	End Function

	<System.ComponentModel.EditorBrowsableAttribute(System.ComponentModel.EditorBrowsableState.Never)> Public Sub SetIndex(ByVal o As .AximText, ByVal Index As Short)
		BaseSetIndex(o, Index)
	End Sub

	<System.ComponentModel.EditorBrowsableAttribute(System.ComponentModel.EditorBrowsableState.Never)> Public Function ShouldSerializeIndex(ByVal o As .AximText) As Boolean
		Return BaseShouldSerializeIndex(o)
	End Function

	<System.ComponentModel.EditorBrowsableAttribute(System.ComponentModel.EditorBrowsableState.Never)> Public Sub ResetIndex(ByVal o As .AximText)
		BaseResetIndex(o)
	End Sub

	Default Public ReadOnly Property Item(ByVal Index As Short) As .AximText
		Get
			Item = CType(BaseGetItem(Index), .AximText)
		End Get
	End Property

	Protected Overrides Function GetControlInstanceType() As System.Type
		Return GetType(.AximText)
	End Function

	Protected Overrides Sub HookUpControlEvents(ByVal o As Object)
		Dim ctl As .AximText = CType(o, .AximText)
		MyBase.HookUpControlEvents(o)
		If Not ChangeEvent Is Nothing Then
			AddHandler ctl.Change, New System.EventHandler(AddressOf HandleChange)
		End If
		If Not CloseUpEvent Is Nothing Then
			AddHandler ctl.CloseUp, New .ITextEvents_CloseUpEventHandler(AddressOf HandleCloseUp)
		End If
		If Not DropOpenEvent Is Nothing Then
			AddHandler ctl.DropOpen, New .ITextEvents_DropOpenEventHandler(AddressOf HandleDropOpen)
		End If
		If Not DBErrorEvent Is Nothing Then
			AddHandler ctl.DBError, New .ITextEvents_DBErrorEventHandler(AddressOf HandleDBError)
		End If
		If Not EditModeChangeEvent Is Nothing Then
			AddHandler ctl.EditModeChange, New System.EventHandler(AddressOf HandleEditModeChange)
		End If
		If Not InvalidInputEvent Is Nothing Then
			AddHandler ctl.InvalidInput, New System.EventHandler(AddressOf HandleInvalidInput)
		End If
		If Not FuriganaEvent Is Nothing Then
			AddHandler ctl.Furigana, New .ITextEvents_FuriganaEventHandler(AddressOf HandleFurigana)
		End If
		If Not KeyDownEventEvent Is Nothing Then
			AddHandler ctl.KeyDownEvent, New .ITextEvents_KeyDownEventHandler(AddressOf HandleKeyDownEvent)
		End If
		If Not KeyPressEventEvent Is Nothing Then
			AddHandler ctl.KeyPressEvent, New .ITextEvents_KeyPressEventHandler(AddressOf HandleKeyPressEvent)
		End If
		If Not KeyUpEventEvent Is Nothing Then
			AddHandler ctl.KeyUpEvent, New .ITextEvents_KeyUpEventHandler(AddressOf HandleKeyUpEvent)
		End If
		If Not MouseDownEventEvent Is Nothing Then
			AddHandler ctl.MouseDownEvent, New .ITextEvents_MouseDownEventHandler(AddressOf HandleMouseDownEvent)
		End If
		If Not MouseUpEventEvent Is Nothing Then
			AddHandler ctl.MouseUpEvent, New .ITextEvents_MouseUpEventHandler(AddressOf HandleMouseUpEvent)
		End If
		If Not MouseMoveEventEvent Is Nothing Then
			AddHandler ctl.MouseMoveEvent, New .ITextEvents_MouseMoveEventHandler(AddressOf HandleMouseMoveEvent)
		End If
		If Not ClickEventEvent Is Nothing Then
			AddHandler ctl.ClickEvent, New System.EventHandler(AddressOf HandleClickEvent)
		End If
		If Not DblClickEvent Is Nothing Then
			AddHandler ctl.DblClick, New System.EventHandler(AddressOf HandleDblClick)
		End If
		If Not OLECompleteDragEvent Is Nothing Then
			AddHandler ctl.OLECompleteDrag, New .ITextEvents_OLECompleteDragEventHandler(AddressOf HandleOLECompleteDrag)
		End If
		If Not OLEDragDropEvent Is Nothing Then
			AddHandler ctl.OLEDragDrop, New .ITextEvents_OLEDragDropEventHandler(AddressOf HandleOLEDragDrop)
		End If
		If Not OLEDragOverEvent Is Nothing Then
			AddHandler ctl.OLEDragOver, New .ITextEvents_OLEDragOverEventHandler(AddressOf HandleOLEDragOver)
		End If
		If Not OLEGiveFeedbackEvent Is Nothing Then
			AddHandler ctl.OLEGiveFeedback, New .ITextEvents_OLEGiveFeedbackEventHandler(AddressOf HandleOLEGiveFeedback)
		End If
		If Not OLESetDataEvent Is Nothing Then
			AddHandler ctl.OLESetData, New .ITextEvents_OLESetDataEventHandler(AddressOf HandleOLESetData)
		End If
		If Not OLEStartDragEvent Is Nothing Then
			AddHandler ctl.OLEStartDrag, New .ITextEvents_OLEStartDragEventHandler(AddressOf HandleOLEStartDrag)
		End If
		If Not MouseEnterEventEvent Is Nothing Then
			AddHandler ctl.MouseEnterEvent, New System.EventHandler(AddressOf HandleMouseEnterEvent)
		End If
		If Not MouseExitEvent Is Nothing Then
			AddHandler ctl.MouseExit, New System.EventHandler(AddressOf HandleMouseExit)
		End If
		If Not KeyExitEvent Is Nothing Then
			AddHandler ctl.KeyExit, New .ITextEvents_KeyExitEventHandler(AddressOf HandleKeyExit)
		End If
	End Sub

	Private Function HandleChange (ByVal sender As System.Object, ByVal e As System.EventArgs) As Integer
		RaiseEvent [Change] (sender, e)
	End Function

	Private Function HandleCloseUp (ByVal sender As System.Object, ByVal e As .ITextEvents_CloseUpEvent) As Integer
		RaiseEvent [CloseUp] (sender, e)
	End Function

	Private Function HandleDropOpen (ByVal sender As System.Object, ByVal e As .ITextEvents_DropOpenEvent) As Integer
		RaiseEvent [DropOpen] (sender, e)
	End Function

	Private Function HandleDBError (ByVal sender As System.Object, ByVal e As .ITextEvents_DBErrorEvent) As Integer
		RaiseEvent [DBError] (sender, e)
	End Function

	Private Function HandleEditModeChange (ByVal sender As System.Object, ByVal e As System.EventArgs) As Integer
		RaiseEvent [EditModeChange] (sender, e)
	End Function

	Private Function HandleInvalidInput (ByVal sender As System.Object, ByVal e As System.EventArgs) As Integer
		RaiseEvent [InvalidInput] (sender, e)
	End Function

	Private Function HandleFurigana (ByVal sender As System.Object, ByVal e As .ITextEvents_FuriganaEvent) As Integer
		RaiseEvent [Furigana] (sender, e)
	End Function

	Private Sub HandleKeyDownEvent (ByVal sender As System.Object, ByVal e As .ITextEvents_KeyDownEvent) 
		RaiseEvent [KeyDownEvent] (sender, e)
	End Sub

	Private Sub HandleKeyPressEvent (ByVal sender As System.Object, ByVal e As .ITextEvents_KeyPressEvent) 
		RaiseEvent [KeyPressEvent] (sender, e)
	End Sub

	Private Sub HandleKeyUpEvent (ByVal sender As System.Object, ByVal e As .ITextEvents_KeyUpEvent) 
		RaiseEvent [KeyUpEvent] (sender, e)
	End Sub

	Private Sub HandleMouseDownEvent (ByVal sender As System.Object, ByVal e As .ITextEvents_MouseDownEvent) 
		RaiseEvent [MouseDownEvent] (sender, e)
	End Sub

	Private Sub HandleMouseUpEvent (ByVal sender As System.Object, ByVal e As .ITextEvents_MouseUpEvent) 
		RaiseEvent [MouseUpEvent] (sender, e)
	End Sub

	Private Sub HandleMouseMoveEvent (ByVal sender As System.Object, ByVal e As .ITextEvents_MouseMoveEvent) 
		RaiseEvent [MouseMoveEvent] (sender, e)
	End Sub

	Private Sub HandleClickEvent (ByVal sender As System.Object, ByVal e As System.EventArgs) 
		RaiseEvent [ClickEvent] (sender, e)
	End Sub

	Private Sub HandleDblClick (ByVal sender As System.Object, ByVal e As System.EventArgs) 
		RaiseEvent [DblClick] (sender, e)
	End Sub

	Private Sub HandleOLECompleteDrag (ByVal sender As System.Object, ByVal e As .ITextEvents_OLECompleteDragEvent) 
		RaiseEvent [OLECompleteDrag] (sender, e)
	End Sub

	Private Sub HandleOLEDragDrop (ByVal sender As System.Object, ByVal e As .ITextEvents_OLEDragDropEvent) 
		RaiseEvent [OLEDragDrop] (sender, e)
	End Sub

	Private Sub HandleOLEDragOver (ByVal sender As System.Object, ByVal e As .ITextEvents_OLEDragOverEvent) 
		RaiseEvent [OLEDragOver] (sender, e)
	End Sub

	Private Sub HandleOLEGiveFeedback (ByVal sender As System.Object, ByVal e As .ITextEvents_OLEGiveFeedbackEvent) 
		RaiseEvent [OLEGiveFeedback] (sender, e)
	End Sub

	Private Sub HandleOLESetData (ByVal sender As System.Object, ByVal e As .ITextEvents_OLESetDataEvent) 
		RaiseEvent [OLESetData] (sender, e)
	End Sub

	Private Sub HandleOLEStartDrag (ByVal sender As System.Object, ByVal e As .ITextEvents_OLEStartDragEvent) 
		RaiseEvent [OLEStartDrag] (sender, e)
	End Sub

	Private Sub HandleMouseEnterEvent (ByVal sender As System.Object, ByVal e As System.EventArgs) 
		RaiseEvent [MouseEnterEvent] (sender, e)
	End Sub

	Private Sub HandleMouseExit (ByVal sender As System.Object, ByVal e As System.EventArgs) 
		RaiseEvent [MouseExit] (sender, e)
	End Sub

	Private Sub HandleKeyExit (ByVal sender As System.Object, ByVal e As .ITextEvents_KeyExitEvent) 
		RaiseEvent [KeyExit] (sender, e)
	End Sub

End Class

