'UPGRADE_WARNING: The entire project must be compiled once before a form with an ActiveX Control Array can be displayed

Imports System.ComponentModel

<ProvideProperty("Index",GetType(.AximMask))> Public Class AximMaskArray
	Inherits Microsoft.VisualBasic.Compatibility.VB6.BaseOcxArray
	Implements IExtenderProvider

	Public Sub New()
		MyBase.New()
	End Sub

	Public Sub New(ByVal Container As IContainer)
		MyBase.New(Container)
	End Sub

	Public Shadows Event [Change] (ByVal sender As System.Object, ByVal e As System.EventArgs)
	Public Shadows Event [DBError] (ByVal sender As System.Object, ByVal e As .IMaskEvents_DBErrorEvent)
	Public Shadows Event [EditModeChange] (ByVal sender As System.Object, ByVal e As System.EventArgs)
	Public Shadows Event [InvalidInput] (ByVal sender As System.Object, ByVal e As System.EventArgs)
	Public Shadows Event [KeyDownEvent] (ByVal sender As System.Object, ByVal e As .IMaskEvents_KeyDownEvent)
	Public Shadows Event [KeyPressEvent] (ByVal sender As System.Object, ByVal e As .IMaskEvents_KeyPressEvent)
	Public Shadows Event [KeyUpEvent] (ByVal sender As System.Object, ByVal e As .IMaskEvents_KeyUpEvent)
	Public Shadows Event [MouseDownEvent] (ByVal sender As System.Object, ByVal e As .IMaskEvents_MouseDownEvent)
	Public Shadows Event [MouseUpEvent] (ByVal sender As System.Object, ByVal e As .IMaskEvents_MouseUpEvent)
	Public Shadows Event [MouseMoveEvent] (ByVal sender As System.Object, ByVal e As .IMaskEvents_MouseMoveEvent)
	Public Shadows Event [ClickEvent] (ByVal sender As System.Object, ByVal e As System.EventArgs)
	Public Shadows Event [DblClick] (ByVal sender As System.Object, ByVal e As System.EventArgs)
	Public Shadows Event [OLECompleteDrag] (ByVal sender As System.Object, ByVal e As .IMaskEvents_OLECompleteDragEvent)
	Public Shadows Event [OLEDragDrop] (ByVal sender As System.Object, ByVal e As .IMaskEvents_OLEDragDropEvent)
	Public Shadows Event [OLEDragOver] (ByVal sender As System.Object, ByVal e As .IMaskEvents_OLEDragOverEvent)
	Public Shadows Event [OLEGiveFeedback] (ByVal sender As System.Object, ByVal e As .IMaskEvents_OLEGiveFeedbackEvent)
	Public Shadows Event [OLESetData] (ByVal sender As System.Object, ByVal e As .IMaskEvents_OLESetDataEvent)
	Public Shadows Event [OLEStartDrag] (ByVal sender As System.Object, ByVal e As .IMaskEvents_OLEStartDragEvent)
	Public Shadows Event [MouseEnterEvent] (ByVal sender As System.Object, ByVal e As System.EventArgs)
	Public Shadows Event [MouseExit] (ByVal sender As System.Object, ByVal e As System.EventArgs)
	Public Shadows Event [KeyExit] (ByVal sender As System.Object, ByVal e As .IMaskEvents_KeyExitEvent)

	<System.ComponentModel.EditorBrowsableAttribute(System.ComponentModel.EditorBrowsableState.Never)> Public Function CanExtend(ByVal target As Object) As Boolean Implements IExtenderProvider.CanExtend
		If TypeOf target Is .AximMask Then
			Return BaseCanExtend(target)
		End If
	End Function

	Public Function GetIndex(ByVal o As .AximMask) As Short
		Return BaseGetIndex(o)
	End Function

	<System.ComponentModel.EditorBrowsableAttribute(System.ComponentModel.EditorBrowsableState.Never)> Public Sub SetIndex(ByVal o As .AximMask, ByVal Index As Short)
		BaseSetIndex(o, Index)
	End Sub

	<System.ComponentModel.EditorBrowsableAttribute(System.ComponentModel.EditorBrowsableState.Never)> Public Function ShouldSerializeIndex(ByVal o As .AximMask) As Boolean
		Return BaseShouldSerializeIndex(o)
	End Function

	<System.ComponentModel.EditorBrowsableAttribute(System.ComponentModel.EditorBrowsableState.Never)> Public Sub ResetIndex(ByVal o As .AximMask)
		BaseResetIndex(o)
	End Sub

	Default Public ReadOnly Property Item(ByVal Index As Short) As .AximMask
		Get
			Item = CType(BaseGetItem(Index), .AximMask)
		End Get
	End Property

	Protected Overrides Function GetControlInstanceType() As System.Type
		Return GetType(.AximMask)
	End Function

	Protected Overrides Sub HookUpControlEvents(ByVal o As Object)
		Dim ctl As .AximMask = CType(o, .AximMask)
		MyBase.HookUpControlEvents(o)
		If Not ChangeEvent Is Nothing Then
			AddHandler ctl.Change, New System.EventHandler(AddressOf HandleChange)
		End If
		If Not DBErrorEvent Is Nothing Then
			AddHandler ctl.DBError, New .IMaskEvents_DBErrorEventHandler(AddressOf HandleDBError)
		End If
		If Not EditModeChangeEvent Is Nothing Then
			AddHandler ctl.EditModeChange, New System.EventHandler(AddressOf HandleEditModeChange)
		End If
		If Not InvalidInputEvent Is Nothing Then
			AddHandler ctl.InvalidInput, New System.EventHandler(AddressOf HandleInvalidInput)
		End If
		If Not KeyDownEventEvent Is Nothing Then
			AddHandler ctl.KeyDownEvent, New .IMaskEvents_KeyDownEventHandler(AddressOf HandleKeyDownEvent)
		End If
		If Not KeyPressEventEvent Is Nothing Then
			AddHandler ctl.KeyPressEvent, New .IMaskEvents_KeyPressEventHandler(AddressOf HandleKeyPressEvent)
		End If
		If Not KeyUpEventEvent Is Nothing Then
			AddHandler ctl.KeyUpEvent, New .IMaskEvents_KeyUpEventHandler(AddressOf HandleKeyUpEvent)
		End If
		If Not MouseDownEventEvent Is Nothing Then
			AddHandler ctl.MouseDownEvent, New .IMaskEvents_MouseDownEventHandler(AddressOf HandleMouseDownEvent)
		End If
		If Not MouseUpEventEvent Is Nothing Then
			AddHandler ctl.MouseUpEvent, New .IMaskEvents_MouseUpEventHandler(AddressOf HandleMouseUpEvent)
		End If
		If Not MouseMoveEventEvent Is Nothing Then
			AddHandler ctl.MouseMoveEvent, New .IMaskEvents_MouseMoveEventHandler(AddressOf HandleMouseMoveEvent)
		End If
		If Not ClickEventEvent Is Nothing Then
			AddHandler ctl.ClickEvent, New System.EventHandler(AddressOf HandleClickEvent)
		End If
		If Not DblClickEvent Is Nothing Then
			AddHandler ctl.DblClick, New System.EventHandler(AddressOf HandleDblClick)
		End If
		If Not OLECompleteDragEvent Is Nothing Then
			AddHandler ctl.OLECompleteDrag, New .IMaskEvents_OLECompleteDragEventHandler(AddressOf HandleOLECompleteDrag)
		End If
		If Not OLEDragDropEvent Is Nothing Then
			AddHandler ctl.OLEDragDrop, New .IMaskEvents_OLEDragDropEventHandler(AddressOf HandleOLEDragDrop)
		End If
		If Not OLEDragOverEvent Is Nothing Then
			AddHandler ctl.OLEDragOver, New .IMaskEvents_OLEDragOverEventHandler(AddressOf HandleOLEDragOver)
		End If
		If Not OLEGiveFeedbackEvent Is Nothing Then
			AddHandler ctl.OLEGiveFeedback, New .IMaskEvents_OLEGiveFeedbackEventHandler(AddressOf HandleOLEGiveFeedback)
		End If
		If Not OLESetDataEvent Is Nothing Then
			AddHandler ctl.OLESetData, New .IMaskEvents_OLESetDataEventHandler(AddressOf HandleOLESetData)
		End If
		If Not OLEStartDragEvent Is Nothing Then
			AddHandler ctl.OLEStartDrag, New .IMaskEvents_OLEStartDragEventHandler(AddressOf HandleOLEStartDrag)
		End If
		If Not MouseEnterEventEvent Is Nothing Then
			AddHandler ctl.MouseEnterEvent, New System.EventHandler(AddressOf HandleMouseEnterEvent)
		End If
		If Not MouseExitEvent Is Nothing Then
			AddHandler ctl.MouseExit, New System.EventHandler(AddressOf HandleMouseExit)
		End If
		If Not KeyExitEvent Is Nothing Then
			AddHandler ctl.KeyExit, New .IMaskEvents_KeyExitEventHandler(AddressOf HandleKeyExit)
		End If
	End Sub

	Private Function HandleChange (ByVal sender As System.Object, ByVal e As System.EventArgs) As Integer
		RaiseEvent [Change] (sender, e)
	End Function

	Private Function HandleDBError (ByVal sender As System.Object, ByVal e As .IMaskEvents_DBErrorEvent) As Integer
		RaiseEvent [DBError] (sender, e)
	End Function

	Private Function HandleEditModeChange (ByVal sender As System.Object, ByVal e As System.EventArgs) As Integer
		RaiseEvent [EditModeChange] (sender, e)
	End Function

	Private Function HandleInvalidInput (ByVal sender As System.Object, ByVal e As System.EventArgs) As Integer
		RaiseEvent [InvalidInput] (sender, e)
	End Function

	Private Sub HandleKeyDownEvent (ByVal sender As System.Object, ByVal e As .IMaskEvents_KeyDownEvent) 
		RaiseEvent [KeyDownEvent] (sender, e)
	End Sub

	Private Sub HandleKeyPressEvent (ByVal sender As System.Object, ByVal e As .IMaskEvents_KeyPressEvent) 
		RaiseEvent [KeyPressEvent] (sender, e)
	End Sub

	Private Sub HandleKeyUpEvent (ByVal sender As System.Object, ByVal e As .IMaskEvents_KeyUpEvent) 
		RaiseEvent [KeyUpEvent] (sender, e)
	End Sub

	Private Sub HandleMouseDownEvent (ByVal sender As System.Object, ByVal e As .IMaskEvents_MouseDownEvent) 
		RaiseEvent [MouseDownEvent] (sender, e)
	End Sub

	Private Sub HandleMouseUpEvent (ByVal sender As System.Object, ByVal e As .IMaskEvents_MouseUpEvent) 
		RaiseEvent [MouseUpEvent] (sender, e)
	End Sub

	Private Sub HandleMouseMoveEvent (ByVal sender As System.Object, ByVal e As .IMaskEvents_MouseMoveEvent) 
		RaiseEvent [MouseMoveEvent] (sender, e)
	End Sub

	Private Sub HandleClickEvent (ByVal sender As System.Object, ByVal e As System.EventArgs) 
		RaiseEvent [ClickEvent] (sender, e)
	End Sub

	Private Sub HandleDblClick (ByVal sender As System.Object, ByVal e As System.EventArgs) 
		RaiseEvent [DblClick] (sender, e)
	End Sub

	Private Sub HandleOLECompleteDrag (ByVal sender As System.Object, ByVal e As .IMaskEvents_OLECompleteDragEvent) 
		RaiseEvent [OLECompleteDrag] (sender, e)
	End Sub

	Private Sub HandleOLEDragDrop (ByVal sender As System.Object, ByVal e As .IMaskEvents_OLEDragDropEvent) 
		RaiseEvent [OLEDragDrop] (sender, e)
	End Sub

	Private Sub HandleOLEDragOver (ByVal sender As System.Object, ByVal e As .IMaskEvents_OLEDragOverEvent) 
		RaiseEvent [OLEDragOver] (sender, e)
	End Sub

	Private Sub HandleOLEGiveFeedback (ByVal sender As System.Object, ByVal e As .IMaskEvents_OLEGiveFeedbackEvent) 
		RaiseEvent [OLEGiveFeedback] (sender, e)
	End Sub

	Private Sub HandleOLESetData (ByVal sender As System.Object, ByVal e As .IMaskEvents_OLESetDataEvent) 
		RaiseEvent [OLESetData] (sender, e)
	End Sub

	Private Sub HandleOLEStartDrag (ByVal sender As System.Object, ByVal e As .IMaskEvents_OLEStartDragEvent) 
		RaiseEvent [OLEStartDrag] (sender, e)
	End Sub

	Private Sub HandleMouseEnterEvent (ByVal sender As System.Object, ByVal e As System.EventArgs) 
		RaiseEvent [MouseEnterEvent] (sender, e)
	End Sub

	Private Sub HandleMouseExit (ByVal sender As System.Object, ByVal e As System.EventArgs) 
		RaiseEvent [MouseExit] (sender, e)
	End Sub

	Private Sub HandleKeyExit (ByVal sender As System.Object, ByVal e As .IMaskEvents_KeyExitEvent) 
		RaiseEvent [KeyExit] (sender, e)
	End Sub

End Class

