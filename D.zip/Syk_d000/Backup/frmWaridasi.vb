Option Strict Off
Option Explicit On
Friend Class frmWaridasi
	Inherits System.Windows.Forms.Form
	'=============================================================
	' ���[�U�[���@  �F  �Ђ났��L���b�V���T�[�r�X
	' �V�X�e�����@  �F  �Ɩ��V�X�e��
	' ���W���[����  �F  ��񌟍�
	' ���W���[��ID�@�F  frmWaridasi.frm
	' �쐬���@ �@�@ �F  ���� 13 �N 06 �� 29 ��
	' �X�V���@�@  �@�F  ����    �N    ��    ��
	'=============================================================
	'
	
	'��ʕ\���p�\����
	Private Structure DspList
		Dim Mesyo As String
		Dim Bango As String
		Dim Yobi1 As String
		Dim Yobi2 As String
		Dim Yobi3 As String
		Dim Yobi4 As String
	End Structure
	
	Public ZENTEI As String ' �O�񌟍�����
	Public GetNO As String ' �I��ԍ�
	Public GetNM As String ' �I�𖼏�
	
	Private SortMode(1) As Short ' ���� Or �~��
	'
	
	'-------------------------------------------------------------------------------
	'   ����    :   ��ʃN���A
	'   �֐�    :   Sub DispClear()
	'   ����    :   ����
	'   �@�\    :   ��ʂ��N���A���܂��B
	'-------------------------------------------------------------------------------
	Private Sub DispClear()
		SortMode(0) = -1
		SortMode(1) = -1
		vaSpread1.MaxRows = 0
		vaSpread1.set_SortKey(1, 1)
		cmdKey(1).Enabled = False
	End Sub
	
	'-------------------------------------------------------------------------------
	'   ����    :   �������ʕ\��
	'   �֐�    :   Function FormFirstSet()
	'   ����    :   ����
	'   �ߒl    :   True    �f�[�^����
	'   �@�@        False   �f�[�^�Ȃ�
	'   �@�\    :   InfoNo���e�}�X�^�̌������ʂ�\������B
	'-------------------------------------------------------------------------------
	Private Function FormFirstSet() As Boolean
		
		Dim lp As Short
		Dim Cnt As Short
		Dim DT() As DspList
		
		'��ʏ����ݒ�
		vaSpread1.MaxRows = 0
		cmdKey(1).Enabled = False
		
		ReDim DT(0)
		
		'----- ���o���̎擾
		Cnt = GetWaridasi(DT)
		If Cnt <= 0 Then
			If Me.Visible = True Then
				MsgBox("�Y���f�[�^���P��������܂���", MsgBoxStyle.OKOnly, "����")
			End If
			FormFirstSet = False
			Exit Function
		End If
		
		vaSpread1.ReDraw = False
		vaSpread1.MaxRows = Cnt
		cmdKey(1).Enabled = True
		
		'�f�[�^�\��
		With vaSpread1
			For lp = 1 To Cnt
				.Col = 1 : .Col2 = .MaxCols
				.Row = lp : .Row2 = lp
				.set_RowHeight(lp, 15#)
				.BlockMode = True
				.Font = VB6.FontChangeBold(.Font, True)
				.BlockMode = False
				.SetText(1, lp, CObj(DT(lp - 1).Mesyo))
				.SetText(6, lp, CObj(DT(lp - 1).Bango))
				.SetText(2, lp, CObj(VB6.Format(DT(lp - 1).Yobi1, "#,###")))
				.SetText(3, lp, CObj(DT(lp - 1).Yobi2))
				.SetText(4, lp, CObj(VB6.Format(DT(lp - 1).Yobi3, "#,###")))
				.SetText(5, lp, CObj(VB6.Format(DT(lp - 1).Yobi4, "#,##0")))
			Next lp
		End With
		vaSpread1.ReDraw = True
		If vaSpread1.Visible = True Then
			vaSpread1.Focus()
		End If
		
		FormFirstSet = True
		
	End Function
	
	'-------------------------------------------------------------------------------
	'   ����    :   �I���f�[�^�̎擾
	'   �֐�    :   Function GetData()
	'   ����    :   ����
	'   �ߒl    :   ����
	'   �@�\    :   �I�����ꂽ�f�[�^��Public�ϐ���GetCD�^GetNM�ɃZ�b�g���܂��B
	'-------------------------------------------------------------------------------
	Private Sub GetData()
		
		Dim ssText As Object
		
		Call vaSpread1.GetText(1, vaSpread1.ActiveRow, ssText)
		'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
		GetNM = Trim(ssText)
		Call vaSpread1.GetText(6, vaSpread1.ActiveRow, ssText)
		'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
		GetNO = Trim(ssText)
		
	End Sub
	
	'-------------------------------------------------------------------------------
	'   ����    :   ���o��񌟍��f�[�^�̎擾
	'   �֐�    :   Function GetWaridasi()
	'   ����    :   DT()    DspList
	'   �ߒl    :   Cnt     ���o����
	'   �@�@        -1      �ُ�I��
	'   �@�\    :   �����ɊY������R�[�h�^���̂̎擾���s���B
	'-------------------------------------------------------------------------------
	Private Function GetWaridasi(ByRef DT() As DspList) As Integer
		
		Dim SQL As String
		Dim Rs As ADODB.Recordset
		Dim OpenFlg As Short
		Dim Cnt As Integer
		Dim Jouken As String
		
		On Error GoTo GetWaridasi_Err
		
		'�߂�l�̏�����
		GetWaridasi = -1
		
		'----- WHERE���̑g�ݗ���
		Jouken = ""
		If Trim(ZENTEI) <> "" Then
			Jouken = "(" & ZENTEI & ")"
		End If
		
		'----- SQL/SELECT���̑g�ݗ���
		SQL = "SELECT"
		SQL = SQL & " MEISYOU     AS F01,"
		SQL = SQL & " MEISAI_NO   AS F02,"
		SQL = SQL & " T_SUURYOU   AS F03,"
		SQL = SQL & " TANI        AS F04,"
		SQL = SQL & " T_TANKA     AS F05,"
		SQL = SQL & " T_KINGAKU   AS F06"
		SQL = SQL & " FROM WARIDASI_DATA"
		If Jouken <> "" Then
			SQL = SQL & " WHERE " & Jouken
		End If
		SQL = SQL & " ORDER BY MEISAI_NO"
		
		'----- SQL�����s
		Rs = SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText)
		OpenFlg = 1
		
		Cnt = 0
		Do Until Rs.EOF
			ReDim Preserve DT(Cnt)
			'UPGRADE_WARNING: Couldn't resolve default property of object RsNull(). Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			DT(Cnt).Mesyo = RsNull(Rs, "F01")
			'UPGRADE_WARNING: Couldn't resolve default property of object RsNull(). Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			DT(Cnt).Bango = RsNull(Rs, "F02")
			'UPGRADE_WARNING: Couldn't resolve default property of object RsNull(). Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			DT(Cnt).Yobi1 = RsNull(Rs, "F03")
			'UPGRADE_WARNING: Couldn't resolve default property of object RsNull(). Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			DT(Cnt).Yobi2 = RsNull(Rs, "F04")
			'UPGRADE_WARNING: Couldn't resolve default property of object RsNull(). Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			DT(Cnt).Yobi3 = RsNull(Rs, "F05")
			'UPGRADE_WARNING: Couldn't resolve default property of object RsNull(). Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			DT(Cnt).Yobi4 = RsNull(Rs, "F06")
			Cnt = Cnt + 1
			Rs.MoveNext()
		Loop 
		
		Rs.Close()
		'UPGRADE_NOTE: Object Rs may not be destroyed until it is garbage collected. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"'
		Rs = Nothing
		
		'�߂�l�Ɍ������Z�b�g
		GetWaridasi = Cnt
		
		Exit Function
		
GetWaridasi_Err: 
		
		If OpenFlg = 1 Then
			Rs.Close()
		End If
		'UPGRADE_NOTE: Object Rs may not be destroyed until it is garbage collected. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"'
		Rs = Nothing
		
		Call Sql_Error_Msg("WARIDASI_DATA SELECT")
		
	End Function
	
	Private Sub cmdKey_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Click
		Dim Index As Short = cmdKey.GetIndex(eventSender)
		
		Select Case Index
			Case 1 '----- ����
				Call GetData()
				ZENTEI = ""
				Me.Close()
				
			Case 12 '----- �I��
				ZENTEI = ""
				GetNO = ""
				GetNM = ""
				Me.Close()
		End Select
		
	End Sub
	
	Private Sub cmdKey_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Enter
		Dim Index As Short = cmdKey.GetIndex(eventSender)
		Call GotFocus(cmdKey(Index), StatusBar1)
	End Sub
	
	Private Sub cmdKey_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Leave
		Dim Index As Short = cmdKey.GetIndex(eventSender)
		Call LostFocus(cmdKey(Index), StatusBar1)
	End Sub
	
	Private Sub frmWaridasi_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown
		Dim KeyCode As Short = eventArgs.KeyCode
		Dim Shift As Short = eventArgs.KeyData \ &H10000
		Select Case KeyCode
			Case System.Windows.Forms.Keys.F1 '----- ����
				If cmdKey(1).Enabled = True Then cmdKey(1).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(1), New System.EventArgs())
			Case System.Windows.Forms.Keys.F12 '----- �I��
				If cmdKey(12).Enabled = True Then cmdKey(12).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(12), New System.EventArgs())
		End Select
	End Sub
	
	Private Sub frmWaridasi_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
		Call FormDisp(Me)
		GetNO = ""
		GetNM = ""
		'UPGRADE_WARNING: Screen property Screen.MousePointer has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6BA9B8D2-2A32-4B6E-8D36-44949974A5B4"'
		System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
		If FormFirstSet() = False Then
			'
		End If
		'UPGRADE_WARNING: Screen property Screen.MousePointer has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6BA9B8D2-2A32-4B6E-8D36-44949974A5B4"'
		System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
	End Sub
	
	Private Sub frmWaridasi_FormClosing(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
		Dim Cancel As Boolean = eventArgs.Cancel
		Dim UnloadMode As System.Windows.Forms.CloseReason = eventArgs.CloseReason
		If UnloadMode = System.Windows.Forms.CloseReason.UserClosing Then
			'----- �I������
			Call cmdKey_Click(cmdKey.Item(12), New System.EventArgs())
		End If
		eventArgs.Cancel = Cancel
	End Sub
	
	Private Sub vaSpread1_ClickEvent(ByVal eventSender As System.Object, ByVal eventArgs As AxFPSpread._DSpreadEvents_ClickEvent) Handles vaSpread1.ClickEvent
		If eventArgs.Row = 0 And eventArgs.Col = 1 Then
			If vaSpread1.get_SortKey(1) = eventArgs.Col Then
				SortMode(eventArgs.Col - 1) = Not SortMode(eventArgs.Col - 1)
			Else
				SortMode(eventArgs.Col - 1) = -1
			End If
			With vaSpread1
				.eventArgs.Col = 1
				.eventArgs.Row = 1
				.Col2 = .MaxCols
				.Row2 = .MaxRows
				.SortBy = FPSpread.SortByConstants.SortByRow
				.set_SortKey(1, eventArgs.Col)
				.set_SortKeyOrder(1, SortMode(eventArgs.Col - 1) + 2)
				.Action = FPSpread.ActionConstants.ActionSort
			End With
		End If
	End Sub
	
	Private Sub vaSpread1_DblClick(ByVal eventSender As System.Object, ByVal eventArgs As AxFPSpread._DSpreadEvents_DblClickEvent) Handles vaSpread1.DblClick
		If eventArgs.Col > 0 And eventArgs.Row > 0 Then
			Call frmWaridasi_KeyDown(Me, New System.Windows.Forms.KeyEventArgs(System.Windows.Forms.Keys.F1 Or 0 * &H10000))
		End If
	End Sub
	
	Private Sub vaSpread1_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles vaSpread1.Enter
		Call GotFocus(vaSpread1, StatusBar1)
	End Sub
	
	Private Sub vaSpread1_KeyDownEvent(ByVal eventSender As System.Object, ByVal eventArgs As AxFPSpread._DSpreadEvents_KeyDownEvent) Handles vaSpread1.KeyDownEvent
		If eventArgs.KeyCode = System.Windows.Forms.Keys.Return Then
			If vaSpread1.ActiveRow > 0 Then
				Call frmWaridasi_KeyDown(Me, New System.Windows.Forms.KeyEventArgs(System.Windows.Forms.Keys.F1 Or 0 * &H10000))
			End If
		End If
	End Sub
	
	Private Sub vaSpread1_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles vaSpread1.Leave
		Call LostFocus(vaSpread1, StatusBar1)
	End Sub
End Class