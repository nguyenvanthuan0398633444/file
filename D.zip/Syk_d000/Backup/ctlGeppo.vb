Option Strict Off
Option Explicit On
Friend Class ctlGeppo
	Inherits System.Windows.Forms.UserControl
	
	Private EventsObj As New clsEvents
	Private MsgBarObj As Object
	'
	
	'-------------------------------------------------------------------------------
	'   ����    :   �f�[�^�̃N���A
	'   �֐�    :   Sub DispClear()
	'   ����    :   �Ȃ�
	'   �@�\    :   �f�[�^���N���A���܂��B
	'-------------------------------------------------------------------------------
	Public Sub DispClear()
		
		imText2(0).Text = "" '�s�ԍ�
		imText2(0).BackColor = System.Drawing.SystemColors.Control
		imText1(0).Text = "" '���l
		imNumber1(0).Value = "" '�������z
		imNumber1(1).Value = "" '���s�\�Z
		imText2(1).Text = "" '�H�����v
		imText2(2).Text = "" '���v��
		
	End Sub
	
	Private Sub imNumber1_Change(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles imNumber1.Change
		Dim Index As Short = imNumber1.GetIndex(eventSender)
		
		Dim wkVal As Decimal
		
		' �H�����v�̎Z�o
		wkVal = CCur2(imNumber1(0).Value) - CCur2(imNumber1(1).Value)
		imText2(1).Text = VB6.Format(wkVal, "#,###")
		' ���v���̎Z�o
		wkVal = 0
		If CCur2(imNumber1(0).Value) <> 0 Then
			wkVal = CCur2(imText2(1).Text) / CCur2(imNumber1(0).Value)
		End If
		imText2(2).Text = VB6.Format(wkVal * 100, "0.0") & "%"
		If CCur2(imNumber1(0).Value) = 0 And CCur2(imNumber1(1).Value) = 0 Then
			imText2(2).Text = ""
		End If
		
		If Index = 0 Then
			'----- ���z�ύX
			EventsObj.ValueChange(1, CCur2(imNumber1(Index).Text))
		End If
		
	End Sub
	
	Private Sub imNumber1_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles imNumber1.Enter
		Dim Index As Short = imNumber1.GetIndex(eventSender)
		Call GotFocus(Me, Nothing)
	End Sub
	
	Private Sub imNumber1_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles imNumber1.KeyDown
		Dim KeyCode As Short = eventArgs.KeyCode
		Dim Shift As Short = eventArgs.KeyData \ &H10000
		Dim Index As Short = imNumber1.GetIndex(eventSender)
		Select Case KeyCode
			Case System.Windows.Forms.Keys.Return
				Select Case Index
					Case 0 '----- �������z
						imNumber1(1).Focus()
					Case 1 '----- ���s�\�Z
						EventsObj.ValueChange(2, 0)
						EventsObj.ValueChange(0, 0)
				End Select
		End Select
	End Sub
	
	Private Sub imNumber1_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles imNumber1.Leave
		Dim Index As Short = imNumber1.GetIndex(eventSender)
		Call LostFocus(Me, Nothing)
	End Sub
	
	Private Sub imText1_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles imText1.Enter
		Dim Index As Short = imText1.GetIndex(eventSender)
		Call GotFocus(Me, Nothing)
	End Sub
	
	Private Sub imText1_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles imText1.KeyDown
		Dim KeyCode As Short = eventArgs.KeyCode
		Dim Shift As Short = eventArgs.KeyData \ &H10000
		Dim Index As Short = imText1.GetIndex(eventSender)
		Select Case KeyCode
			Case System.Windows.Forms.Keys.Return
				imNumber1(0).Focus()
		End Select
	End Sub
	
	Private Sub imText1_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles imText1.Leave
		Dim Index As Short = imText1.GetIndex(eventSender)
		Call LostFocus(Me, Nothing)
	End Sub
	
	Private Sub ctlGeppo_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Enter
		imText2(0).ForeColor = System.Drawing.Color.Red
	End Sub
	
	Private Sub ctlGeppo_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Leave
		imText2(0).ForeColor = System.Drawing.Color.Black
		'----- ���͏I��
		EventsObj.ValueChange(2, 0)
	End Sub
	
	Private Sub UserControl_Terminate()
		'UPGRADE_NOTE: Object MsgBarObj may not be destroyed until it is garbage collected. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"'
		MsgBarObj = Nothing
		'UPGRADE_NOTE: Object EventsObj may not be destroyed until it is garbage collected. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"'
		EventsObj = Nothing
	End Sub
	
	
	Public Shadows Property Enabled() As Boolean
		Get
			Enabled = Picture1.Enabled
		End Get
		Set(ByVal Value As Boolean)
			Picture1.Enabled = Value
		End Set
	End Property
	
	Public Shadows ReadOnly Property Events() As clsEvents
		Get
			Events = EventsObj
		End Get
	End Property
	
	Public Shadows WriteOnly Property ForeColor() As Integer
		Set(ByVal Value As Integer)
			imText2(0).ForeColor = System.Drawing.ColorTranslator.FromOle(Value)
		End Set
	End Property
	
	Public WriteOnly Property FocusPos() As Short
		Set(ByVal Value As Short)
			Select Case Value
				Case 1 : imText1(0).Focus() ' ���l
				Case 2 : imNumber1(0).Focus() ' �������z
				Case 3 : imNumber1(1).Focus() ' ���s�\�Z
			End Select
		End Set
	End Property
	
	Public WriteOnly Property StatusBar() As Object
		Set(ByVal Value As Object)
			MsgBarObj = Value
		End Set
	End Property
	
	
	Public Property Value(ByVal Mode As Short) As Object
		Get
			Select Case Mode
				Case 0 : Value = Trim(imText2(0).Text) ' �s�ԍ�
				Case 1 : Value = Trim(imText1(0).Text) ' ���l
				Case 2 : Value = CCur2(imNumber1(0).Value) ' �������z
				Case 3 : Value = CCur2(imNumber1(1).Value) ' ���s�\�Z
				Case 4 : Value = CCur2(imText2(1).Text) ' �H�����v
				Case 5 : Value = Trim(imText2(2).Text) ' ���v��
			End Select
		End Get
		Set(ByVal Value As Object)
			Select Case Mode
				Case 0
					'UPGRADE_WARNING: Couldn't resolve default property of object SetVal. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
					imText2(0).Text = Value ' �s�ԍ�
				Case 1
					'UPGRADE_WARNING: Couldn't resolve default property of object SetVal. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
					imText1(0).Text = Value ' ���l
				Case 2
					'UPGRADE_WARNING: Couldn't resolve default property of object SetVal. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
					imNumber1(0).Value = Value ' �������z
				Case 3
					'UPGRADE_WARNING: Couldn't resolve default property of object SetVal. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
					imNumber1(1).Value = Value ' ���s�\�Z
				Case 4
					'UPGRADE_WARNING: Couldn't resolve default property of object SetVal. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
					imText2(1).Text = Value ' �H�����v
				Case 5
					'UPGRADE_WARNING: Couldn't resolve default property of object SetVal. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
					imText2(2).Text = Value ' ���v��
			End Select
		End Set
	End Property
End Class