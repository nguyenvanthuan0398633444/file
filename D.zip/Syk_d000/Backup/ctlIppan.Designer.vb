<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class ctlIppan
#Region "Windows Form Designer generated code "
	<System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
		MyBase.New()
		'This call is required by the Windows Form Designer.
		InitializeComponent()
	End Sub
	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			UserControl_Terminate()
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer
	Public ToolTip1 As System.Windows.Forms.ToolTip
	Friend WithEvents _imText1_0 As imText6.imText
	Friend WithEvents _imText1_4 As imText6.imText
	Friend WithEvents _imText1_2 As imText6.imText
	Friend WithEvents _imText1_5 As imText6.imText
	Friend WithEvents _imNumber1_1 As imNumber6.imNumber
	Friend WithEvents _imText1_1 As imText6.imText
	Friend WithEvents _imText1_3 As imText6.imText
	Friend WithEvents _imNumber1_0 As imNumber6.imNumber
	Friend WithEvents Picture1 As System.Windows.Forms.Panel
	Friend WithEvents imNumber1 As imNumberArray
	Friend WithEvents imText1 As imTextArray
	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(ctlIppan))
		Me.components = New System.ComponentModel.Container()
		Me.ToolTip1 = New System.Windows.Forms.ToolTip(components)
		Me.Picture1 = New System.Windows.Forms.Panel
		Me._imText1_0 = New imText6.imText
		Me._imText1_4 = New imText6.imText
		Me._imText1_2 = New imText6.imText
		Me._imText1_5 = New imText6.imText
		Me._imNumber1_1 = New imNumber6.imNumber
		Me._imText1_1 = New imText6.imText
		Me._imText1_3 = New imText6.imText
		Me._imNumber1_0 = New imNumber6.imNumber
		Me.imNumber1 = New imNumberArray(components)
		Me.imText1 = New imTextArray(components)
		Me.Picture1.SuspendLayout()
		Me.SuspendLayout()
		Me.ToolTip1.Active = True
		CType(Me._imText1_0, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imText1_4, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imText1_2, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imText1_5, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imNumber1_1, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imText1_1, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imText1_3, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imNumber1_0, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.imNumber1, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.imText1, System.ComponentModel.ISupportInitialize).BeginInit()
		Me.ClientSize = New System.Drawing.Size(986, 42)
		MyBase.Location = New System.Drawing.Point(0, 0)
		MyBase.Name = "ctlIppan"
		Me.Picture1.Size = New System.Drawing.Size(971, 31)
		Me.Picture1.Location = New System.Drawing.Point(0, 0)
		Me.Picture1.TabIndex = 8
		Me.Picture1.TabStop = False
		Me.Picture1.Dock = System.Windows.Forms.DockStyle.None
		Me.Picture1.BackColor = System.Drawing.SystemColors.Control
		Me.Picture1.CausesValidation = True
		Me.Picture1.Enabled = True
		Me.Picture1.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Picture1.Cursor = System.Windows.Forms.Cursors.Default
		Me.Picture1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Picture1.Visible = True
		Me.Picture1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.Picture1.Name = "Picture1"
		_imText1_0.OcxState = CType(resources.GetObject("_imText1_0.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imText1_0.Size = New System.Drawing.Size(25, 23)
		Me._imText1_0.Location = New System.Drawing.Point(4, 2)
		Me._imText1_0.TabIndex = 0
		Me._imText1_0.Name = "_imText1_0"
		_imText1_4.OcxState = CType(resources.GetObject("_imText1_4.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imText1_4.Size = New System.Drawing.Size(100, 23)
		Me._imText1_4.Location = New System.Drawing.Point(602, 2)
		Me._imText1_4.TabIndex = 5
		Me._imText1_4.Name = "_imText1_4"
		_imText1_2.OcxState = CType(resources.GetObject("_imText1_2.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imText1_2.Size = New System.Drawing.Size(160, 23)
		Me._imText1_2.Location = New System.Drawing.Point(120, 2)
		Me._imText1_2.TabIndex = 2
		Me._imText1_2.Name = "_imText1_2"
		_imText1_5.OcxState = CType(resources.GetObject("_imText1_5.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imText1_5.Size = New System.Drawing.Size(128, 23)
		Me._imText1_5.Location = New System.Drawing.Point(836, 2)
		Me._imText1_5.TabIndex = 7
		Me._imText1_5.Name = "_imText1_5"
		_imNumber1_1.OcxState = CType(resources.GetObject("_imNumber1_1.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imNumber1_1.Size = New System.Drawing.Size(128, 23)
		Me._imNumber1_1.Location = New System.Drawing.Point(705, 2)
		Me._imNumber1_1.TabIndex = 6
		Me._imNumber1_1.Name = "_imNumber1_1"
		_imText1_1.OcxState = CType(resources.GetObject("_imText1_1.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imText1_1.Size = New System.Drawing.Size(85, 23)
		Me._imText1_1.Location = New System.Drawing.Point(32, 2)
		Me._imText1_1.TabIndex = 1
		Me._imText1_1.Name = "_imText1_1"
		_imText1_3.OcxState = CType(resources.GetObject("_imText1_3.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imText1_3.Size = New System.Drawing.Size(211, 23)
		Me._imText1_3.Location = New System.Drawing.Point(284, 2)
		Me._imText1_3.TabIndex = 3
		Me._imText1_3.Name = "_imText1_3"
		_imNumber1_0.OcxState = CType(resources.GetObject("_imNumber1_0.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imNumber1_0.Size = New System.Drawing.Size(100, 23)
		Me._imNumber1_0.Location = New System.Drawing.Point(499, 2)
		Me._imNumber1_0.TabIndex = 4
		Me._imNumber1_0.Name = "_imNumber1_0"
		Me.Controls.Add(Picture1)
		Me.Picture1.Controls.Add(_imText1_0)
		Me.Picture1.Controls.Add(_imText1_4)
		Me.Picture1.Controls.Add(_imText1_2)
		Me.Picture1.Controls.Add(_imText1_5)
		Me.Picture1.Controls.Add(_imNumber1_1)
		Me.Picture1.Controls.Add(_imText1_1)
		Me.Picture1.Controls.Add(_imText1_3)
		Me.Picture1.Controls.Add(_imNumber1_0)
		Me.imNumber1.SetIndex(_imNumber1_1, CType(1, Short))
		Me.imNumber1.SetIndex(_imNumber1_0, CType(0, Short))
		Me.imText1.SetIndex(_imText1_0, CType(0, Short))
		Me.imText1.SetIndex(_imText1_4, CType(4, Short))
		Me.imText1.SetIndex(_imText1_2, CType(2, Short))
		Me.imText1.SetIndex(_imText1_5, CType(5, Short))
		Me.imText1.SetIndex(_imText1_1, CType(1, Short))
		Me.imText1.SetIndex(_imText1_3, CType(3, Short))
		CType(Me.imText1, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.imNumber1, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imNumber1_0, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imText1_3, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imText1_1, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imNumber1_1, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imText1_5, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imText1_2, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imText1_4, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imText1_0, System.ComponentModel.ISupportInitialize).EndInit()
		Me.Picture1.ResumeLayout(False)
		Me.ResumeLayout(False)
		Me.PerformLayout()
	End Sub
#End Region 
End Class