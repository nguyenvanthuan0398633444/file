Option Strict Off
Option Explicit On
Friend Class frmSYKD020
	Inherits System.Windows.Forms.Form
	'=============================================================
	' ���[�U�[���@  �F  �R�z�H�Ɗ������
	' �V�X�e�����@  �F  �H���Ǘ��V�X�e��
	' ���W���[����  �F  ���c��O�����o�ꗗ
	' ���W���[��ID�@�F  frmSYKD020.frm
	' �쐬���@ �@�@ �F  ���� 13 �N 06 �� 18 ��
	' �X�V���@�@  �@�F  ����    �N    ��    ��
	'=============================================================
	'
	
	Private Const RowHeight As Short = 15
	'
	
	'-------------------------------------------------------------------------------
	'   ����   :   �f�[�^�̃N���A
	'   �֐�   :   Sub DispClear()
	'   ����   :   �Ȃ�
	'   �@�\   :   �f�[�^���N���A���܂��B
	'-------------------------------------------------------------------------------
	Private Sub DispClear()
		
		'----- �H�����
		With KeyKouji
			imText2(0).Text = .KOUJI_NO
			If .EDA_NO = "0000" Then
				imText2(1).Text = ""
			Else
				imText2(1).Text = .EDA_NO
			End If
			imText2(2).Text = .MEISYOU
		End With
		
		vaSpread1.MaxRows = 0
		Call SpAllClear(vaSpread2)
		
		'----- �Q�ƃ��[�h
		If INPMODE <> "2" Then
			cmdKey(1).Text = "  F1  ���o�\��"
			cmdKey(5).Text = "  F5  �@"
			cmdKey(5).Enabled = False
		End If
		
	End Sub
	
	'-------------------------------------------------------------------------------
	'   ����   :   WARIDASI_DATA �ǂݍ��ݏ���
	'   �֐�   :   Function SelectWaridasi()
	'   ����   :   DT()�@   WARIDASI_DATA_DBT
	'   �ߒl   :   �ް���   ����I��
	'   �@�@       -1�@     �ُ�I��
	'   �@�\   :   WARIDASI_DATA SELECT����
	'-------------------------------------------------------------------------------
	Private Function SelectWaridasi(ByRef DT() As WARIDASI_DATA_DBT) As Integer
		
		Dim SQL As String
		Dim Rs As ADODB.Recordset
		Dim Cnt As Integer
		Dim OpenFlg As Short
		
		On Error GoTo SelectWaridasi_Err
		
		'�߂�l�̏�����
		SelectWaridasi = -1
		
		'SQL/SELECT���g��
		SQL = "SELECT"
		SQL = SQL & " WARIDASI_DATA.KOUSYU_CD      AS KOUSYU_CD," '�H������
		SQL = SQL & " WARIDASI_DATA.KOUSYU_NO      AS KOUSYU_NO," '�H��ԍ�
		SQL = SQL & " MIN(KOUSYU_MAST.MEISYOU)     AS MEISYOU," '�H�햼��
		SQL = SQL & " SUM(WARIDASI_DATA.J_KINGAKU) AS J_KINGAKU," '�\�Z���z
		SQL = SQL & " SUM(WARIDASI_DATA.T_KINGAKU) AS T_KINGAKU," '���c���z
		SQL = SQL & " SUM(WARIDASI_DATA.G_KINGAKU) AS G_KINGAKU" '�O�����z
		SQL = SQL & " FROM (WARIDASI_DATA INNER JOIN KOUSYU_MAST"
		SQL = SQL & "  ON (WARIDASI_DATA.KOUSYU_NO = KOUSYU_MAST.KOUSYU_NO)"
		SQL = SQL & " AND (WARIDASI_DATA.KOUSYU_CD = KOUSYU_MAST.KOUSYU_CD))"
		SQL = SQL & " WHERE WARIDASI_DATA.EDA_NO = '" & KeyKouji.EDA_NO & "'"
		SQL = SQL & " AND WARIDASI_DATA.KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"
		SQL = SQL & " AND KOUSYU_MAST.GYOUSYU_KB = '01'"
		SQL = SQL & " GROUP BY WARIDASI_DATA.KOUSYU_CD, WARIDASI_DATA.KOUSYU_NO"
		SQL = SQL & " ORDER BY WARIDASI_DATA.KOUSYU_CD, WARIDASI_DATA.KOUSYU_NO"
		
		'SQL�����s
		Rs = SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText)
		OpenFlg = 1
		
		Cnt = 0
		Do Until Rs.EOF
			ReDim Preserve DT(Cnt)
			Call DATSET_WARIDASI_DATA(Rs, DT(Cnt))
			Cnt = Cnt + 1
			Rs.MoveNext()
		Loop 
		
		Rs.Close()
		'UPGRADE_NOTE: Object Rs may not be destroyed until it is garbage collected. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"'
		Rs = Nothing
		
		'�߂�l�̃Z�b�g
		SelectWaridasi = Cnt
		Exit Function
		
SelectWaridasi_Err: 
		
		If OpenFlg = 1 Then
			Rs.Close()
		End If
		'UPGRADE_NOTE: Object Rs may not be destroyed until it is garbage collected. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"'
		Rs = Nothing
		
		Call Sql_Error_Msg("WARIDASI_DATA SELECT")
		
	End Function
	
	'-------------------------------------------------------------------------------
	'   ����   :   �H��ʏW�v����
	'   �֐�   :   Function KousyuSyukei()
	'   ����   :   Cnt      �f�[�^����
	'   �@�@       DT()     WARIDASI_DATA_DBT
	'   �ߒl   :   �W�v��f�[�^����
	'   �@�\   :   �H�����ޕʂɋ��z�̏W�v���s��
	'-------------------------------------------------------------------------------
	Private Function KousyuSyukei(ByRef Cnt As Integer, ByRef DT() As WARIDASI_DATA_DBT) As Integer
		
		Dim lp As Integer
		Dim CmpKey As String
		Dim wkCnt As Integer
		Dim WK() As WARIDASI_DATA_DBT
		Dim wkVal() As Decimal
		Dim wkPos As Integer
		
		' �߂�l�̏�����
		KousyuSyukei = 0
		
		'----- ������
		ReDim wkVal(2)
		ReDim WK(Cnt - 1)
		WK = VB6.CopyArray(DT)
		CmpKey = WK(0).KOUSYU_CD
		
		'----- �e�H����
		wkCnt = 0 : ReDim DT(wkCnt)
		Call CLEAR_WARIDASI_DATA(DT(wkCnt))
		With DT(wkCnt)
			.KOUJI_NO = WK(0).KOUJI_NO '�H���ԍ�
			.EDA_NO = WK(0).EDA_NO '�H���}��
			.KOUSYU_CD = WK(0).KOUSYU_CD '�H������
			.KOUSYU_NO = "00" '�H��ԍ�
			.MEISYOU = GetNameKousyu(GyosyuID, .KOUSYU_CD) '����
		End With
		wkPos = wkCnt : wkCnt = wkCnt + 1
		
		For lp = 0 To Cnt - 1
			'----- �H�����ނ̔�r
			If CmpKey <> WK(lp).KOUSYU_CD Then
				'----- ���v���z�̐ݒ�
				DT(wkPos).J_KINGAKU = wkVal(0)
				DT(wkPos).T_KINGAKU = wkVal(1)
				DT(wkPos).G_KINGAKU = wkVal(2)
				'----- �e�H����
				ReDim Preserve DT(wkCnt)
				Call CLEAR_WARIDASI_DATA(DT(wkCnt))
				With DT(wkCnt)
					.KOUJI_NO = WK(lp).KOUJI_NO '�H���ԍ�
					.EDA_NO = WK(lp).EDA_NO '�H���}��
					.KOUSYU_CD = WK(lp).KOUSYU_CD '�H������
					.KOUSYU_NO = "00" '�H��ԍ�
					.MEISYOU = GetNameKousyu(GyosyuID, .KOUSYU_CD) '����
				End With
				wkPos = wkCnt : wkCnt = wkCnt + 1
				'----- ������
				CmpKey = WK(lp).KOUSYU_CD
				ReDim wkVal(2)
			End If
			'----- �H��}�ԏ��̃Z�b�g
			ReDim Preserve DT(wkCnt)
			'UPGRADE_WARNING: Couldn't resolve default property of object DT(wkCnt). Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			DT(wkCnt) = WK(lp)
			wkCnt = wkCnt + 1
			'----- �W�v
			wkVal(0) = wkVal(0) + WK(lp).J_KINGAKU
			wkVal(1) = wkVal(1) + WK(lp).T_KINGAKU
			wkVal(2) = wkVal(2) + WK(lp).G_KINGAKU
		Next lp
		
		'----- ���v���z�̐ݒ�
		DT(wkPos).J_KINGAKU = wkVal(0)
		DT(wkPos).T_KINGAKU = wkVal(1)
		DT(wkPos).G_KINGAKU = wkVal(2)
		
		' �߂�l�̃Z�b�g
		KousyuSyukei = wkCnt
		
	End Function
	
	'-------------------------------------------------------------------------------
	'   ����    :   �f�[�^�̎擾
	'   �֐�    :   Sub ListDataDisp()
	'   ����    :   Mode    0 = MsgBox�\��
	'   �@�\    :   �f�[�^�̎擾���s���܂��B
	'-------------------------------------------------------------------------------
	Public Sub ListDataDisp(Optional ByRef Mode As Short = 0)
		
		Dim Cnt As Integer
		Dim DT() As WARIDASI_DATA_DBT
		Dim wkBuf As String
		
		' �J�[�\���������v��
		'UPGRADE_WARNING: Screen property Screen.MousePointer has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6BA9B8D2-2A32-4B6E-8D36-44949974A5B4"'
		System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
		wkBuf = StatusBar1.Items.Item("Message").Text
		StatusBar1.Items.Item("Message").Text = "�Y���f�[�^�������E�E�E"
		
		' �e�[�u���̓Ǎ���
		Cnt = SelectWaridasi(DT)
		If Cnt <= 0 Then
			vaSpread1.MaxRows = 0
			Call SpAllClear(vaSpread2)
			If INPMODE <> "2" Then
				cmdKey(1).Enabled = False
			End If
			StatusBar1.Items.Item("Message").Text = wkBuf
			'UPGRADE_WARNING: Screen property Screen.MousePointer has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6BA9B8D2-2A32-4B6E-8D36-44949974A5B4"'
			System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
			Exit Sub
		End If
		Cnt = KousyuSyukei(Cnt, DT)
		
		' �X�v���b�h�ɕ\��
		Call SprdDataSet(Cnt, DT)
		
		StatusBar1.Items.Item("Message").Text = wkBuf
		'UPGRADE_WARNING: Screen property Screen.MousePointer has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6BA9B8D2-2A32-4B6E-8D36-44949974A5B4"'
		System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
		
	End Sub
	
	'-------------------------------------------------------------------------------
	'   ����    :   �X�v���b�h�\��
	'   �֐�    :   Sub SprdDataSet(DT())
	'   ����    :   Cnt     �f�[�^����
	'   �@�@    :   DT()    WARIDASI_DATA_DBT
	'   �@�\    :   �f�[�^���X�v���b�h�ɕ\�����܂��B
	'-------------------------------------------------------------------------------
	Private Sub SprdDataSet(ByRef Cnt As Integer, ByRef DT() As WARIDASI_DATA_DBT)
		
		Dim lp As Integer
		Dim Row As Integer
		Dim Col As Integer
		Dim ssText As Object
		Dim wkCol As Integer
		Dim wkVal() As Decimal
		Dim wkAns As Decimal
		
		With vaSpread1
			If Me.Visible = True Then
				.ReDraw = False
			End If
			.MaxRows = Cnt
			.Col = 1 : .Col2 = .MaxCols
			.Row = 1 : .Row2 = .MaxRows
			.BlockMode = True
			.Action = FPSpread.ActionConstants.ActionClearText
			.ForeColor = System.Drawing.Color.Black
			.BlockMode = False
			ReDim wkVal(2)
			For lp = 0 To Cnt - 1
				.set_RowHeight(lp + 1, RowHeight)
				Row = lp + 1
				'----- �H�����ށE�H��ԍ�
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				ssText = Trim(DT(lp).KOUSYU_CD) & "-" & Trim(DT(lp).KOUSYU_NO)
				If Trim(DT(lp).KOUSYU_NO) = "00" Then Col = 1 Else Col = 2
				.SetText(Col, Row, ssText)
				'----- �H�햼
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				If Col = 1 Then
					ssText = ""
				Else
					'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
					ssText = "�@"
				End If
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				ssText = ssText & Trim(DT(lp).MEISYOU)
				.SetText(3, Row, ssText)
				'----- �\�Z���z
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				ssText = VB6.Format(DT(lp).J_KINGAKU, "#,##0")
				.SetText(4, Row, ssText)
				'----- ���c���z
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				ssText = VB6.Format(DT(lp).T_KINGAKU, "#,##0")
				.SetText(5, Row, ssText)
				'----- �O�����z
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				ssText = VB6.Format(DT(lp).G_KINGAKU, "#,##0")
				.SetText(6, Row, ssText)
				'----- ���z
				wkAns = DT(lp).J_KINGAKU - (DT(lp).T_KINGAKU + DT(lp).G_KINGAKU)
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				ssText = VB6.Format(wkAns, "#,##0")
				.SetText(7, Row, ssText)
				'----- ���v���z
				If DT(lp).KOUSYU_NO = "00" Then
					wkVal(0) = wkVal(0) + DT(lp).J_KINGAKU
					wkVal(1) = wkVal(1) + DT(lp).T_KINGAKU
					wkVal(2) = wkVal(2) + DT(lp).G_KINGAKU
				End If
			Next lp
			If Me.Visible = True Then
				'UPGRADE_NOTE: Refresh was upgraded to CtlRefresh. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="A9E4979A-37FA-4718-9994-97DD76ED70A7"'
				.CtlRefresh()
				.ReDraw = True
			End If
		End With
		
		'----- ���v���z
		With vaSpread2
			If Me.Visible = True Then
				.ReDraw = False
			End If
			.Col = 1 : .Col2 = .MaxCols
			.Row = 1 : .Row2 = .MaxRows
			.BlockMode = True
			.Action = FPSpread.ActionConstants.ActionClearText
			.ForeColor = System.Drawing.Color.Black
			.BlockMode = False
			'----- �\�Z���z
			'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			ssText = VB6.Format(wkVal(0), "#,##0")
			.SetText(4, Row, ssText)
			'----- ���c���z
			'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			ssText = VB6.Format(wkVal(1), "#,##0")
			.SetText(5, Row, ssText)
			'----- �O�����z
			'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			ssText = VB6.Format(wkVal(2), "#,##0")
			.SetText(6, Row, ssText)
			'----- ���z
			wkAns = wkVal(0) - (wkVal(1) + wkVal(2))
			'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			ssText = VB6.Format(wkAns, "#,##0")
			.SetText(7, Row, ssText)
			If Me.Visible = True Then
				'UPGRADE_NOTE: Refresh was upgraded to CtlRefresh. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="A9E4979A-37FA-4718-9994-97DD76ED70A7"'
				.CtlRefresh()
				.ReDraw = True
			End If
		End With
		
	End Sub
	
	Private Sub cmdKey_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Click
		Dim Index As Short = cmdKey.GetIndex(eventSender)
		
		Dim ssText As Object
		Dim wkPath As String
		Dim Cnt As Integer
		
		Select Case Index
			Case 1 '----- ���o����
				With vaSpread1 '�H�����ނ̎擾
					If .MaxRows > 0 Then
						.GetText(2, .ActiveRow, ssText)
						'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
						If Trim(ssText) = "" Then
							.GetText(2, .ActiveRow + 1, ssText)
						End If
						'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
						frmSYKD030.KousyuID = CStr(ssText)
					Else
						frmSYKD030.KousyuID = ""
					End If
				End With
				'UPGRADE_WARNING: Screen property Screen.MousePointer has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6BA9B8D2-2A32-4B6E-8D36-44949974A5B4"'
				System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
				frmSYKD030.ShowDialog()
				vaSpread1.Focus()
				
			Case 5 '----- �Ǎ���
				'UPGRADE_WARNING: CommonDialog variable was not upgraded Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="671167DC-EA81-475D-B690-7A40C7BF4A23"'
				With CommonDialog1
					'UPGRADE_WARNING: Filter has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="9B7D5ADD-D8FE-4819-A36C-6DEDAF088CC7"'
					.Filter = "�e�L�X�g �t�@�C�� (*.csv)|*.csv"
					'UPGRADE_WARNING: FileOpenConstants constant FileOpenConstants.cdlOFNHideReadOnly was upgraded to OpenFileDialog.ShowReadOnly which has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="DFCDE711-9694-47D7-9C50-45A99CD8E91E"'
					'UPGRADE_WARNING: MSComDlg.CommonDialog property CommonDialog1.Flags was upgraded to CommonDialog1Open.ShowReadOnly which has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="DFCDE711-9694-47D7-9C50-45A99CD8E91E"'
					'UPGRADE_WARNING: FileOpenConstants constant FileOpenConstants.cdlOFNHideReadOnly was upgraded to OpenFileDialog.ShowReadOnly which has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="DFCDE711-9694-47D7-9C50-45A99CD8E91E"'
					.ShowReadOnly = False
					'UPGRADE_WARNING: MSComDlg.CommonDialog property CommonDialog1.Flags was upgraded to CommonDialog1Open.CheckFileExists which has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="DFCDE711-9694-47D7-9C50-45A99CD8E91E"'
					.CheckFileExists = True
					.CheckPathExists = True
					.ShowDialog()
					wkPath = .FileName
					If wkPath = "" Then Exit Sub
				End With
				Me.Enabled = False
				With Picture2
					.Top = VB6.TwipsToPixelsY((VB6.PixelsToTwipsY(Me.ClientRectangle.Height) - VB6.PixelsToTwipsY(.ClientRectangle.Height)) / 2)
					.Left = VB6.TwipsToPixelsX((VB6.PixelsToTwipsX(Me.ClientRectangle.Width) - VB6.PixelsToTwipsX(.ClientRectangle.Width)) / 2)
					.Visible = True
				End With
				'UPGRADE_WARNING: Screen property Screen.MousePointer has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6BA9B8D2-2A32-4B6E-8D36-44949974A5B4"'
				System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
				System.Windows.Forms.Application.DoEvents()
				
				'----- ��ݻ޸��݂̊J�n
				SYKDB.BeginTrans()
				' TextFile�̓Ǎ���
				Cnt = WariTextRead(wkPath, Command1)
				
				Picture2.Visible = False
				Me.Enabled = True
				'UPGRADE_WARNING: Screen property Screen.MousePointer has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6BA9B8D2-2A32-4B6E-8D36-44949974A5B4"'
				System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
				System.Windows.Forms.Application.DoEvents()
				
				' �Ǎ��ݎ��s
				If Cnt <= 0 Then
					SYKDB.RollbackTrans()
					Exit Sub
				End If
				
				' �m�F��ʂ̕\��
				frmSYKD025.ShowDialog()
				If frmSYKD025.SelMode = "" Then
					'----- ��ݻ޸��݂̒��~
					SYKDB.RollbackTrans()
				Else
					'----- ��ݻ޸��݂̊m��
					SYKDB.CommitTrans()
					' �ĕ\��
					Call ListDataDisp()
					vaSpread1.Focus()
				End If
				
			Case 12 '----- �I��
				frmSYKD010.Show()
				Me.Close()
		End Select
		
	End Sub
	
	Private Sub cmdKey_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Enter
		Dim Index As Short = cmdKey.GetIndex(eventSender)
		Call GotFocus(cmdKey(Index), StatusBar1)
	End Sub
	
	Private Sub cmdKey_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Leave
		Dim Index As Short = cmdKey.GetIndex(eventSender)
		Call LostFocus(cmdKey(Index), StatusBar1)
	End Sub
	
	Private Sub frmSYKD020_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown
		Dim KeyCode As Short = eventArgs.KeyCode
		Dim Shift As Short = eventArgs.KeyData \ &H10000
		Select Case KeyCode
			Case System.Windows.Forms.Keys.F1
				If cmdKey(1).Enabled = True Then cmdKey(1).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(1), New System.EventArgs())
			Case System.Windows.Forms.Keys.F2
				If cmdKey(2).Enabled = True Then cmdKey(2).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(2), New System.EventArgs())
			Case System.Windows.Forms.Keys.F3
				If cmdKey(3).Enabled = True Then cmdKey(3).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(3), New System.EventArgs())
			Case System.Windows.Forms.Keys.F4
				If cmdKey(4).Enabled = True Then cmdKey(4).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(4), New System.EventArgs())
			Case System.Windows.Forms.Keys.F5
				If cmdKey(5).Enabled = True Then cmdKey(5).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(5), New System.EventArgs())
			Case System.Windows.Forms.Keys.F6
				If cmdKey(6).Enabled = True Then cmdKey(6).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(6), New System.EventArgs())
			Case System.Windows.Forms.Keys.F7
				If cmdKey(7).Enabled = True Then cmdKey(7).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(7), New System.EventArgs())
			Case System.Windows.Forms.Keys.F8
				If cmdKey(8).Enabled = True Then cmdKey(8).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(8), New System.EventArgs())
			Case System.Windows.Forms.Keys.F9
				If cmdKey(9).Enabled = True Then cmdKey(9).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(9), New System.EventArgs())
			Case System.Windows.Forms.Keys.F10
				If cmdKey(10).Enabled = True Then cmdKey(10).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(10), New System.EventArgs())
			Case System.Windows.Forms.Keys.F11
				If cmdKey(11).Enabled = True Then cmdKey(11).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(11), New System.EventArgs())
			Case System.Windows.Forms.Keys.F12
				If cmdKey(12).Enabled = True Then cmdKey(12).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(12), New System.EventArgs())
		End Select
	End Sub
	
	Private Sub frmSYKD020_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
		
		Call FormDisp(Me)
		
		' �����\��
		Call DispClear()
		Call ListDataDisp(1)
		
	End Sub
	
	Private Sub frmSYKD020_FormClosing(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
		Dim Cancel As Boolean = eventArgs.Cancel
		Dim UnloadMode As System.Windows.Forms.CloseReason = eventArgs.CloseReason
		If UnloadMode = System.Windows.Forms.CloseReason.UserClosing Then
			frmSYKD010.Show()
		End If
		eventArgs.Cancel = Cancel
	End Sub
	
	Private Sub vaSpread1_DblClick(ByVal eventSender As System.Object, ByVal eventArgs As AxFPSpread._DSpreadEvents_DblClickEvent) Handles vaSpread1.DblClick
		If eventArgs.Col > 0 And eventArgs.Row > 0 Then
			Call cmdKey_Click(cmdKey.Item(1), New System.EventArgs())
		End If
	End Sub
	
	Private Sub vaSpread1_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles vaSpread1.Enter
		Call GotFocus(vaSpread1, StatusBar1)
	End Sub
	
	Private Sub vaSpread1_KeyDownEvent(ByVal eventSender As System.Object, ByVal eventArgs As AxFPSpread._DSpreadEvents_KeyDownEvent) Handles vaSpread1.KeyDownEvent
		If eventArgs.KeyCode = System.Windows.Forms.Keys.Return Then
			If vaSpread1.ActiveRow > 0 Then
				Call cmdKey_Click(cmdKey.Item(1), New System.EventArgs())
			End If
		End If
	End Sub
	
	Private Sub vaSpread1_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles vaSpread1.Leave
		Call LostFocus(vaSpread1, StatusBar1)
	End Sub
End Class