Option Strict Off
Option Explicit On
Friend Class clsEvents
	
	Public Event Change(ByVal Mode As Short, ByRef Value As Object)
	'
	
	Public Sub ValueChange(ByVal Mode As Short, ByRef Value As Object)
		RaiseEvent Change(Mode, Value)
	End Sub
End Class