Option Strict Off
Option Explicit On
Imports VB = Microsoft.VisualBasic
Friend Class ctlIppan
	Inherits System.Windows.Forms.UserControl
	
	Private EventsObj As New clsEvents
	Private MsgBarObj As Object
	
	Private ZaikoSuu As Decimal
	Private PreVal As Decimal
	'
	
	'-------------------------------------------------------------------------------
	'   ����    :   �f�[�^�̃N���A
	'   �֐�    :   Sub DispClear()
	'   ����    :   �Ȃ�
	'   �@�\    :   �f�[�^���N���A���܂��B
	'-------------------------------------------------------------------------------
	Public Sub DispClear()
		
		imText1(0).Text = "" '�s�ԍ�
		imText1(0).BackColor = System.Drawing.SystemColors.Control
		imText1(1).Text = "" '�Ǝк���
		imText1(2).Text = "" '�ƎЖ�
		imText1(3).Text = "" '�i����K�i
		imNumber1(0).Value = "" '����
		imText1(4).Text = "" '�݌�
		imNumber1(1).Value = "" '�P��
		imText1(5).Text = "" '���z
		
		Call CtlReadOnly(False) '����
		
	End Sub
	
	'-------------------------------------------------------------------------------
	'   ����    :   �R���g���[���̐���
	'   �֐�    :   Sub CtlReadOnly()
	'   ����    :   SetVal  �����è�l
	'   �@�\    :   �R���g���[����ǎ���p�ɂ��邩�ǂ������䂵�܂��B
	'-------------------------------------------------------------------------------
	Private Sub CtlReadOnly(ByVal SetVal As Boolean)
		
		' 2003/05/14 �C��
		'imNumber1(1).ReadOnly = SetVal          '�P��
		
		If SetVal = True Then
			imNumber1(1).BackColor = System.Drawing.SystemColors.Control
		Else
			imNumber1(1).BackColor = System.Drawing.Color.White
		End If
		
	End Sub
	
	Private Sub imNumber1_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles imNumber1.Enter
		Dim Index As Short = imNumber1.GetIndex(eventSender)
		
		Dim iMode As Short
		
		iMode = 1
		If imNumber1(Index).BackColor.equals(System.Drawing.SystemColors.Control) Then iMode = 2
		
		Call GotFocus(Me, Nothing)
		PreVal = CCur2(imNumber1(Index).Value)
		
	End Sub
	
	Private Sub imNumber1_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles imNumber1.KeyDown
		Dim KeyCode As Short = eventArgs.KeyCode
		Dim Shift As Short = eventArgs.KeyData \ &H10000
		Dim Index As Short = imNumber1.GetIndex(eventSender)
		Dim wkVal As Double
		Select Case KeyCode
			Case System.Windows.Forms.Keys.Return
				Select Case Index
					Case 0 '----- ����
						imNumber1(1).Focus()
					Case 1 '----- �P��
						' ���z�Z�o
						wkVal = CDbl2(imNumber1(0).Value) * CDbl2(imNumber1(1).Value)
						If -999999999999# <= wkVal And wkVal <= 999999999999# Then
							imText1(5).Text = VB6.Format(wkVal, "#,##0")
							If wkVal < 0 Then imText1(5).ForeColor = System.Drawing.Color.Red Else imText1(5).ForeColor = System.Drawing.Color.Black
							' �P�����͌�
							EventsObj.ValueChange(2, 0)
							EventsObj.ValueChange(0, 0)
						Else
							MsgBox("���z�̌������I�[�o�[���܂����B", MsgBoxStyle.Information)
							imNumber1(Index).Value = VB6.Format(PreVal)
							imNumber1(Index).Focus()
						End If
				End Select
		End Select
	End Sub
	
	Private Sub imNumber1_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles imNumber1.Leave
		Dim Index As Short = imNumber1.GetIndex(eventSender)
		
		Dim wkCur As Decimal
		Dim wkVal As Double
		Dim wkstr As String
		Dim iMode As Short
		
		iMode = 1
		If imNumber1(Index).BackColor.equals(System.Drawing.SystemColors.Control) Then iMode = 2
		
		Call LostFocus(Me, Nothing)
		
		' 2003/05/14 �ǉ�
		If Index = 1 Then
			'----- �P���̏ꍇ
			'        If PreVal <> CCur2(imNumber1(Index).Value) And iMode = 2 Then
			'            If MsgBox("�����I�ɒP����ύX���܂����H", vbYesNo + vbDefaultButton2) = vbNo Then
			'                imNumber1(Index).Value = Format$(PreVal)
			'            End If
			'        End If
		End If
		
		'----- ����
		If Index = 0 Then
			wkCur = ZaikoSuu - CCur2(imNumber1(0).Value)
			If wkCur < 0 Then
				imNumber1(0).Text = VB6.Format(ZaikoSuu - CCur2(imText1(4).Text))
				wkCur = ZaikoSuu - CCur2(imNumber1(0).Value)
			End If
			wkstr = VB6.Format(wkCur, "#,##0.##")
			If VB.Right(wkstr, 1) = "." Then wkstr = VB.Left(wkstr, Len(wkstr) - 1)
			If VB.Left(wkstr, 1) = "." Then wkstr = "0" & wkstr
			imText1(4).Text = wkstr
		End If
		' ���z�̎Z�o
		wkVal = CDbl2(imNumber1(0).Value) * CDbl2(imNumber1(1).Value)
		If -999999999999# <= wkVal And wkVal <= 999999999999# Then
			imText1(5).Text = VB6.Format(wkVal, "#,##0")
			If wkVal < 0 Then imText1(5).ForeColor = System.Drawing.Color.Red Else imText1(5).ForeColor = System.Drawing.Color.Black
		Else
			MsgBox("���z�̌������I�[�o�[���܂����B", MsgBoxStyle.Information)
			imNumber1(Index).Value = VB6.Format(PreVal)
			imNumber1(Index).Focus()
		End If
		
	End Sub
	
	Private Sub imText1_Change(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles imText1.Change
		Dim Index As Short = imText1.GetIndex(eventSender)
		Select Case Index
			Case 4 '----- �݌ɕύX
				EventsObj.ValueChange(3, CCur2(imText1(Index).Text))
			Case 5 '----- ���z�ύX
				EventsObj.ValueChange(1, CCur2(imText1(Index).Text))
		End Select
	End Sub
	
	Private Sub ctlIppan_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Enter
		imText1(0).ForeColor = System.Drawing.Color.Red
	End Sub
	
	Private Sub ctlIppan_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Leave
		imText1(0).ForeColor = System.Drawing.Color.Black
		'----- ���͏I��
		EventsObj.ValueChange(2, 0)
	End Sub
	
	Private Sub UserControl_Terminate()
		'UPGRADE_NOTE: Object MsgBarObj may not be destroyed until it is garbage collected. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"'
		MsgBarObj = Nothing
		'UPGRADE_NOTE: Object EventsObj may not be destroyed until it is garbage collected. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"'
		EventsObj = Nothing
	End Sub
	
	
	Public Shadows Property Enabled() As Boolean
		Get
			Enabled = Picture1.Enabled
		End Get
		Set(ByVal Value As Boolean)
			Picture1.Enabled = Value
		End Set
	End Property
	
	Public Shadows ReadOnly Property Events() As clsEvents
		Get
			Events = EventsObj
		End Get
	End Property
	
	Public Shadows WriteOnly Property ForeColor() As Integer
		Set(ByVal Value As Integer)
			imText1(0).ForeColor = System.Drawing.ColorTranslator.FromOle(Value)
		End Set
	End Property
	
	Public WriteOnly Property FocusPos() As Short
		Set(ByVal Value As Short)
			Select Case Value
				Case 4 : imNumber1(0).Focus() ' ����
				Case 6 : imNumber1(1).Focus() ' �P��
			End Select
		End Set
	End Property
	
	Public WriteOnly Property StatusBar() As Object
		Set(ByVal Value As Object)
			MsgBarObj = Value
		End Set
	End Property
	
	
	Public Property Value(ByVal Mode As Short) As Object
		Get
			Select Case Mode
				Case 0 : Value = Trim(imText1(0).Text) ' �s�ԍ�
				Case 4 : Value = CCur2(imNumber1(0).Value) ' ����
				Case 5 : Value = CCur2(imText1(4).Text) ' �݌�
				Case 6 : Value = CCur2(imNumber1(1).Value) ' �P��
				Case 7 : Value = CCur2(imText1(5).Text) ' ���z
			End Select
		End Get
		Set(ByVal Value As Object)
			Select Case Mode
				Case 0
					'UPGRADE_WARNING: Couldn't resolve default property of object SetVal. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
					imText1(0).Text = Value ' �s�ԍ�
				Case 1
					'UPGRADE_WARNING: Couldn't resolve default property of object SetVal. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
					imText1(1).Text = Value ' �Ǝ�����
				Case 2
					'UPGRADE_WARNING: Couldn't resolve default property of object SetVal. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
					imText1(2).Text = Value ' �Ǝ햼
				Case 3
					'UPGRADE_WARNING: Couldn't resolve default property of object SetVal. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
					imText1(3).Text = Value ' �i����K�i
				Case 4
					'UPGRADE_WARNING: Couldn't resolve default property of object SetVal. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
					imNumber1(0).Value = Value ' ����
				Case 5
					'UPGRADE_WARNING: Couldn't resolve default property of object SetVal. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
					imText1(4).Text = Value ' �݌�
				Case 6
					'UPGRADE_WARNING: Couldn't resolve default property of object SetVal. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
					imNumber1(1).Value = Value ' �P��
				Case 7
					'UPGRADE_WARNING: Couldn't resolve default property of object SetVal. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
					imText1(5).Text = Value ' ���z
				Case 8
					'UPGRADE_WARNING: Couldn't resolve default property of object SetVal. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
					ZaikoSuu = Value ' ���� + �݌ɐ�
				Case 9 ' �t���O
					Select Case Value
						Case "1" '----- �d��쐬��
							imText1(0).BackColor = System.Drawing.ColorTranslator.FromOle(&HFFC0FF)
							Call CtlReadOnly(True)
						Case Else '----- ���̑�
							imText1(0).BackColor = System.Drawing.SystemColors.Control
							Call CtlReadOnly(False)
					End Select
			End Select
		End Set
	End Property
End Class