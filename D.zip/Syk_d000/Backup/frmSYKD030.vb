Option Strict Off
Option Explicit On
Imports VB = Microsoft.VisualBasic
Friend Class frmSYKD030
	Inherits System.Windows.Forms.Form
	'=============================================================
	' ���[�U�[���@  �F  �R�z�H�Ɗ������
	' �V�X�e�����@  �F  �H���Ǘ��V�X�e��
	' ���W���[����  �F  ���c��O�����o����
	' ���W���[��ID�@�F  frmSYKD030.frm
	' �쐬���@ �@�@ �F  ���� 13 �N 06 �� 19 ��
	' �X�V���@�@  �@�F  ����    �N    ��    ��
	'=============================================================
	'
	
	Private Const RowHeight As Short = 11
	Private LoadFlg As Short '�N�����t���O
	
	Public KousyuID As String '�H�����ށi Z-99 �j
	Public MeisaiNO As Double '�ݒ薾�הԍ�
	'
	
	'-------------------------------------------------------------------------------
	'   ����    :   �f�[�^�̃N���A
	'   �֐�    :   Sub DispClear()
	'   ����    :   �Ȃ�
	'   �@�\    :   �f�[�^���N���A���܂��B
	'-------------------------------------------------------------------------------
	Private Sub DispClear(Optional ByRef Mode As Short = 0)
		
		If Mode = 1 Then
			'----- �H�����
			With KeyKouji
				imText2(0).Text = .KOUJI_NO
				If .EDA_NO = "0000" Then
					imText2(1).Text = ""
				Else
					imText2(1).Text = .EDA_NO
				End If
				imText2(2).Text = .MEISYOU
			End With
			imMask1(0).Value = "" '�H������
		End If
		
		If LoadFlg = 0 Then KousyuID = ""
		
		imText1(0).Text = "" '�H�햼
		vaSpread1.MaxRows = 0 '�\
		Call SpAllClear(vaSpread2)
		cmdKey(2).Enabled = False '�C���{�^��
		cmdKey(3).Enabled = False '�폜�{�^��
		cmdKey(5).Enabled = False '�}���{�^��
		
		'----- �Q�ƃ��[�h
		If INPMODE <> "2" Then
			cmdKey(1).Enabled = False
			cmdKey(1).Text = "  F1  �@"
			cmdKey(2).Text = "  F2  �� ��"
			cmdKey(2).Tag = "�I���f�[�^�̏ڍׂ�\�����܂��B"
			cmdKey(3).Enabled = False
			cmdKey(3).Text = "  F3  �@"
			cmdKey(5).Enabled = False
			cmdKey(5).Text = "  F5  �@"
		End If
		
	End Sub
	
	'-------------------------------------------------------------------------------
	'   ����    :   �f�[�^�̎擾
	'   �֐�    :   Sub ListDataDisp()
	'   ����    :   Mode    0 = MsgBox�\��
	'   �@�\    :   �f�[�^�̎擾���s���܂��B
	'-------------------------------------------------------------------------------
	Public Sub ListDataDisp(Optional ByRef Mode As Short = 0)
		
		Dim Jouken As String
		Dim Order As String
		Dim Cnt As Integer
		Dim DT() As WARIDASI_DATA_DBT
		Dim wkBuf As String
		
		' �J�[�\���������v��
		'UPGRADE_WARNING: Screen property Screen.MousePointer has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6BA9B8D2-2A32-4B6E-8D36-44949974A5B4"'
		System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
		wkBuf = StatusBar1.Items.Item("Message").Text
		StatusBar1.Items.Item("Message").Text = "�Y���f�[�^�������E�E�E"
		
		' WHERE���̑g�ݗ���
		Jouken = "KOUSYU_NO = '" & Mid(KousyuID, 3, 2) & "'"
		Jouken = Jouken & " AND KOUSYU_CD = '" & Mid(KousyuID, 1, 1) & "'"
		Jouken = Jouken & " AND EDA_NO = '" & KeyKouji.EDA_NO & "'"
		Jouken = Jouken & " AND KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"
		
		' �e�[�u���̓Ǎ���
		Order = "MEISAI_NO"
		Cnt = SELECT_WARIDASI_DATA(Jouken, Order, DT)
		If Cnt <= 0 Then
			vaSpread1.MaxRows = 0
			Call SpAllClear(vaSpread2)
			cmdKey(2).Enabled = False '�C���{�^��
			cmdKey(3).Enabled = False '�폜�{�^��
			cmdKey(5).Enabled = False '�}���{�^��
			StatusBar1.Items.Item("Message").Text = wkBuf
			'UPGRADE_WARNING: Screen property Screen.MousePointer has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6BA9B8D2-2A32-4B6E-8D36-44949974A5B4"'
			System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
			Exit Sub
		End If
		
		' �X�v���b�h�ɕ\��
		Call SprdDataSet(Cnt, DT)
		
		cmdKey(2).Enabled = True '�C���{�^��
		If INPMODE = "2" Then
			cmdKey(3).Enabled = True '�폜�{�^��
			cmdKey(5).Enabled = True '�}���{�^��
		End If
		
		StatusBar1.Items.Item("Message").Text = wkBuf
		'UPGRADE_WARNING: Screen property Screen.MousePointer has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6BA9B8D2-2A32-4B6E-8D36-44949974A5B4"'
		System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
		
	End Sub
	
	'-------------------------------------------------------------------------------
	'   ����    :   �X�v���b�h�\��
	'   �֐�    :   Sub SprdDataSet(DT())
	'   ����    :   Cnt     �f�[�^����
	'   �@�@    :   DT()    WARIDASI_DATA_DBT
	'   �@�\    :   �f�[�^���X�v���b�h�ɕ\�����܂��B
	'-------------------------------------------------------------------------------
	Private Sub SprdDataSet(ByRef Cnt As Integer, ByRef DT() As WARIDASI_DATA_DBT)
		
		Dim lp As Integer
		Dim Row As Integer
		Dim ssText As Object
		Dim wkstr As String
		Dim wkVal() As Decimal
		Dim wkAns As Decimal
		
		'----- �H����
		imMask1(0).Text = KousyuID
		wkstr = Trim(GetNameKousyu(GyosyuID, Mid(KousyuID, 1, 1))) & "�|"
		wkstr = wkstr & Trim(GetNameKousyu(GyosyuID, Mid(KousyuID, 1, 1), Mid(KousyuID, 3, 2)))
		If wkstr = "�|" Then wkstr = ""
		imText1(0).Text = wkstr
		
		With vaSpread1
			If Me.Visible = True Then
				.ReDraw = False
			End If
			.MaxRows = Cnt
			.Col = 1 : .Col2 = .MaxCols
			.Row = 1 : .Row2 = .MaxRows
			.BlockMode = True
			.Font = VB6.FontChangeBold(.Font, False)
			.Action = FPSpread.ActionConstants.ActionClearText
			.BlockMode = False
			ReDim wkVal(2)
			For lp = 0 To Cnt - 1
				.set_RowHeight(lp + 1, RowHeight)
				Row = lp + 1
				'----- ����
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				ssText = Trim(DT(lp).MEISYOU)
				.SetText(1, Row, ssText)
				'----- ����
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				ssText = VB6.Format(DT(lp).J_SUURYOU, "#,###.##")
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				If VB.Right(ssText, 1) = "." Then ssText = VB.Left(ssText, Len(ssText) - 1)
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				If VB.Left(ssText, 1) = "." Then ssText = "0" & ssText
				.SetText(2, Row, ssText)
				'----- �P��
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				ssText = Trim(DT(lp).TANI)
				.SetText(3, Row, ssText)
				'----- �P��
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				ssText = VB6.Format(DT(lp).J_TANKA, "#,###")
				.SetText(4, Row, ssText)
				'----- ���z
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				ssText = VB6.Format(DT(lp).J_KINGAKU, "#,##0")
				.SetText(5, Row, ssText)
				'----- ���c���o��
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				If DT(lp).WARIDASI_KB = "1" Then
					ssText = Trim(DT(lp).WARIDASI_NO)
				Else
					'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
					ssText = ""
				End If
				.SetText(6, Row, ssText)
				'----- ����
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				ssText = VB6.Format(DT(lp).T_SUURYOU, "#,###.##")
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				If VB.Right(ssText, 1) = "." Then ssText = VB.Left(ssText, Len(ssText) - 1)
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				If VB.Left(ssText, 1) = "." Then ssText = "0" & ssText
				.SetText(7, Row, ssText)
				'----- �P��
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				ssText = VB6.Format(DT(lp).T_TANKA, "#,###")
				.SetText(8, Row, ssText)
				'----- ���z
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				ssText = VB6.Format(DT(lp).T_KINGAKU, "#,##0")
				.SetText(9, Row, ssText)
				'----- �O�����o��
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				If DT(lp).WARIDASI_KB = "2" Then
					ssText = Trim(DT(lp).WARIDASI_NO)
				Else
					'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
					ssText = ""
				End If
				.SetText(10, Row, ssText)
				'----- ����
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				ssText = VB6.Format(DT(lp).G_SUURYOU, "#,###.##")
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				If VB.Right(ssText, 1) = "." Then ssText = VB.Left(ssText, Len(ssText) - 1)
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				If VB.Left(ssText, 1) = "." Then ssText = "0" & ssText
				.SetText(11, Row, ssText)
				'----- �P��
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				ssText = VB6.Format(DT(lp).G_TANKA, "#,###")
				.SetText(12, Row, ssText)
				'----- ���z
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				ssText = VB6.Format(DT(lp).G_KINGAKU, "#,##0")
				.SetText(13, Row, ssText)
				'----- ���z
				wkAns = DT(lp).J_KINGAKU - (DT(lp).T_KINGAKU + DT(lp).G_KINGAKU)
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				ssText = VB6.Format(wkAns, "#,##0")
				.SetText(14, Row, ssText)
				'----- ���הԍ�
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				ssText = VB6.Format(DT(lp).MEISAI_NO)
				.SetText(15, Row, ssText)
				'----- ��b�t���O
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				ssText = Trim(DT(lp).KISO_FLG)
				.SetText(16, Row, ssText)
				'----- ���o�敪
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				ssText = Trim(DT(lp).WARIDASI_KB)
				.SetText(17, Row, ssText)
				'----- �W�v
				wkVal(0) = wkVal(0) + DT(lp).J_KINGAKU
				wkVal(1) = wkVal(1) + DT(lp).T_KINGAKU
				wkVal(2) = wkVal(2) + DT(lp).G_KINGAKU
			Next lp
			If Me.Visible = True Then
				'UPGRADE_NOTE: Refresh was upgraded to CtlRefresh. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="A9E4979A-37FA-4718-9994-97DD76ED70A7"'
				.CtlRefresh()
				.ReDraw = True
			End If
		End With
		
		'----- ���v���z
		With vaSpread2
			If Me.Visible = True Then
				.ReDraw = False
			End If
			.Col = 1 : .Col2 = .MaxCols
			.Row = 1 : .Row2 = .MaxRows
			.BlockMode = True
			.Font = VB6.FontChangeBold(.Font, False)
			.Action = FPSpread.ActionConstants.ActionClearText
			.BlockMode = False
			'----- �\�Z���z
			'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			ssText = VB6.Format(wkVal(0), "#,##0")
			.SetText(5, 1, ssText)
			'----- ���c���z
			'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			ssText = VB6.Format(wkVal(1), "#,##0")
			.SetText(9, 1, ssText)
			'----- �O�����z
			'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			ssText = VB6.Format(wkVal(2), "#,##0")
			.SetText(13, 1, ssText)
			'----- ���z
			wkAns = wkVal(0) - (wkVal(1) + wkVal(2))
			'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			ssText = VB6.Format(wkAns, "#,##0")
			.SetText(14, 1, ssText)
			If Me.Visible = True Then
				'UPGRADE_NOTE: Refresh was upgraded to CtlRefresh. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="A9E4979A-37FA-4718-9994-97DD76ED70A7"'
				.CtlRefresh()
				.ReDraw = True
			End If
		End With
		
	End Sub
	
	'-------------------------------------------------------------------------------
	'   ����    :   �I���f�[�^�i�j�d�x�j�̎擾
	'   �֐�    :   Sub SprdDataGet(DT)
	'   ����    :   Row     �w��s
	'   �@�@        DT      WARIDASI_DATA_DBT
	'   �@�\    :   �I���f�[�^���X�v���b�h����擾���܂��B
	'-------------------------------------------------------------------------------
	Private Sub SprdDataGet(ByRef Row As Integer, ByRef DT As WARIDASI_DATA_DBT)
		
		Dim ssText As Object
		
		With vaSpread1
			.GetText(15, Row, ssText) '���הԍ�
			DT.MEISAI_NO = CDbl2(ssText)
			.GetText(16, Row, ssText) '��b�t���O
			'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			DT.KISO_FLG = Trim(ssText)
			.GetText(17, Row, ssText) '���o�敪
			'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			DT.WARIDASI_KB = Trim(ssText)
			Select Case DT.WARIDASI_KB
				Case "1" : .GetText(6, Row, ssText) '���o�ԍ��i���c�j
				Case "2" : .GetText(10, Row, ssText) '���o�ԍ��i�O���j
			End Select
			'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			DT.WARIDASI_NO = Trim(ssText)
		End With
		
	End Sub
	
	'-------------------------------------------------------------------------------
	'   ����   :   �\�������`�F�b�N
	'   �֐�   :   Function JoukenCheck()
	'   ����   :   Mode   0 = MsgBox�\��
	'   �ߒl   :   True   ���͐���
	'   �@�@       False  ���̓G���[
	'   �@�\   :   �H��̃`�F�b�N���s���܂��B
	'-------------------------------------------------------------------------------
	Private Function JoukenCheck(Optional ByRef Mode As Short = 0) As Boolean
		
		Dim Jouken As String
		
		' �߂�l�̏�����
		JoukenCheck = False
		
		'----- ���̓`�F�b�N
		If Trim(imMask1(0).Text) = "-" Then
			If Mode = 0 Then
				MsgBox("�H�킪���͂���Ă��܂���B", MsgBoxStyle.Information)
				imMask1(0).Focus()
			End If
			Exit Function
		End If
		
		'----- ���݃`�F�b�N
		Jouken = "GYOUSYU_KB = '" & GyosyuID & "'"
		Jouken = Jouken & " AND KOUSYU_CD = '" & Mid(imMask1(0).Text, 1, 1) & "'"
		Jouken = Jouken & " AND KOUSYU_NO = '" & Mid(imMask1(0).Text, 3, 2) & "'"
		If CNTGET_KOUSYU_MAST(Jouken) <= 0 Then
			If Mode = 0 Then
				MsgBox("���͂��ꂽ�H�����ނ͓o�^����Ă��܂���B", MsgBoxStyle.Information)
				imMask1(0).Focus()
			End If
			Exit Function
		End If
		
		' ����I��
		JoukenCheck = True
		
	End Function
	
	'-------------------------------------------------------------------------------
	'   ����   :   �폜�\�`�F�b�N
	'   �֐�   :   Function DeleteCheck()
	'   ����   :   DT       WARIDASI_DATA_DBT
	'   �ߒl   :   True     �폜��
	'   �@�@       False    �폜�s��
	'   �@�\   :   �폜�\���ǂ����`�F�b�N���s���܂��B
	'-------------------------------------------------------------------------------
	Private Function DeleteCheck(ByRef DT As WARIDASI_DATA_DBT) As Boolean
		
		Dim Jouken As String
		
		' �߂�l�̏�����
		DeleteCheck = False
		
		'----- ��b�s
		If Trim(DT.KISO_FLG) = "1" Then
			If MsgBox("��b�f�[�^�ł����{���ɍ폜���܂����H", MsgBoxStyle.YesNo + MsgBoxStyle.Information) = MsgBoxResult.No Then
				Exit Function
			End If
		End If
		
		' WHERE���̑g��
		Jouken = "MEISAI_NO = " & VB6.Format(DT.MEISAI_NO)
		Jouken = Jouken & " AND KOUSYU_NO = '" & Mid(KousyuID, 3, 2) & "'"
		Jouken = Jouken & " AND KOUSYU_CD = '" & Mid(KousyuID, 1, 1) & "'"
		Jouken = Jouken & " AND EDA_NO = '" & KeyKouji.EDA_NO & "'"
		Jouken = Jouken & " AND KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"
		
		'----- ��ʕ�
		If CNTGET_IPPAN_DATA(Jouken) > 0 Then
			MsgBox("��ʕ����ɓo�^����Ă���̂ō폜�ł��܂���B", MsgBoxStyle.OKOnly + MsgBoxStyle.Information)
			Exit Function
		End If
		
		'----- ������
		If CNTGET_MIKOMI_DATA(Jouken) > 0 Then
			MsgBox("���c������񂪓o�^����Ă���̂ō폜�ł��܂���B", MsgBoxStyle.OKOnly + MsgBoxStyle.Information)
			Exit Function
		End If
		
		'----- �o����
		If CNTGET_DEKIDAKA_DATA(Jouken) > 0 Then
			MsgBox("�O���o������񂪓o�^����Ă���̂ō폜�ł��܂���B", MsgBoxStyle.OKOnly + MsgBoxStyle.Information)
			Exit Function
		End If
		
		' �폜��
		DeleteCheck = True
		
	End Function
	
	Private Sub cmdKey_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Click
		Dim Index As Short = cmdKey.GetIndex(eventSender)
		
		Dim Jouken As String
		Dim wkJouken As String
		Dim DT As WARIDASI_DATA_DBT
		Dim wkVal() As Double
		Dim Mode As Short
		Dim Keta As Short
		Dim Pos As Short
		Dim wkstr As String
		Dim lp As Short
		Dim OKFlg As Short
		
		' �w��s���̎擾
		Call SprdDataGet((vaSpread1.ActiveRow), DT)
		
		Select Case Index
			Case 1 '----- �ǉ�
				' �H��`�F�b�N
				If JoukenCheck() = False Then
					Exit Sub
				End If
				MeisaiNO = 0
				vaSpread1.Row = -1
				frmSYKD031.ShowDialog()
				vaSpread1.Focus()
				
			Case 2 '----- �C��
				MeisaiNO = DT.MEISAI_NO
				vaSpread1.Row = vaSpread1.ActiveRow
				frmSYKD031.ShowDialog()
				vaSpread1.Focus()
				
			Case 3 '----- �폜
				If DeleteCheck(DT) = False Then
					Exit Sub
				End If
				If MsgBox("�폜���܂��B��낵���ł����H", MsgBoxStyle.YesNo) = MsgBoxResult.No Then
					Exit Sub
				End If
				' WHERE���̑g�ݗ���
				Jouken = "KOUSYU_NO = '" & Mid(KousyuID, 3, 2) & "'"
				Jouken = Jouken & " AND KOUSYU_CD = '" & Mid(KousyuID, 1, 1) & "'"
				Jouken = Jouken & " AND EDA_NO = '" & KeyKouji.EDA_NO & "'"
				Jouken = Jouken & " AND KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"
				'UPGRADE_WARNING: Screen property Screen.MousePointer has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6BA9B8D2-2A32-4B6E-8D36-44949974A5B4"'
				System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
				'----- ��ݻ޸��݂̊J�n
				SYKDB.BeginTrans()
				Do 
					' ���o�f�[�^�̍폜
					wkJouken = "MEISAI_NO = " & DT.MEISAI_NO & " AND " & Jouken
					If DELETE_WARIDASI_DATA(wkJouken) = False Then
						SYKDB.RollbackTrans()
						Exit Do
					End If
					' ����t���O�i�y�؁j
					If DT.WARIDASI_KB > "0" Then
						Mode = Val(DT.WARIDASI_KB)
						If UpdateCtrlFlg(Mode) = False Then
							SYKDB.RollbackTrans()
							Exit Do
						End If
					End If
					' ���o�ύX�t���O
					If DT.WARIDASI_KB > "0" Then
						Jouken = "WARIDASI_NO = '" & Trim(DT.WARIDASI_NO) & "'"
						Jouken = Jouken & " AND EDA_NO = '" & KeyKouji.EDA_NO & "'"
						Jouken = Jouken & " AND KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"
						If UpdateHenkoFlg("WARIDASI_MAST", Jouken, "1") = False Then
							SYKDB.RollbackTrans()
							Exit Do
						End If
					End If
					' �O���ύX�t���O
					If DT.WARIDASI_KB = "2" Then
						Jouken = "SIME_YM = '" & CtlKouji.SYORI_YM & "'"
						Jouken = Jouken & " AND CHUUMON_NO = '" & Trim(DT.WARIDASI_NO) & "'"
						Jouken = Jouken & " AND EDA_NO = '" & KeyKouji.EDA_NO & "'"
						Jouken = Jouken & " AND KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"
						If UpdateHenkoFlg("GAI_KIHON_DATA", Jouken, "1") = False Then
							SYKDB.RollbackTrans()
							Exit Do
						End If
					End If
					'----- ��ݻ޸��݂̊m��
					SYKDB.CommitTrans()
					Exit Do
				Loop 
				'UPGRADE_WARNING: Screen property Screen.MousePointer has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6BA9B8D2-2A32-4B6E-8D36-44949974A5B4"'
				System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
				Call frmSYKD020.ListDataDisp(1)
				Call ListDataDisp()
				If vaSpread1.MaxRows > 0 Then
					vaSpread1.Focus()
				End If
				
			Case 5 '----- �}��
				ReDim wkVal(1)
				wkVal(1) = DT.MEISAI_NO
				If vaSpread1.ActiveRow > 1 Then
					Call SprdDataGet(vaSpread1.ActiveRow - 1, DT)
					wkVal(0) = DT.MEISAI_NO
				Else
					wkVal(0) = 0
				End If
				'2002/04/09 ���הԍ��̎Z�o���@��ύX ---------------------
				'MeisaiNO = (wkVal(0) + wkVal(1)) / 2
				wkstr = VB6.Format(wkVal(0))
				Pos = InStr(wkstr, ".")
				If Pos > 0 Then
					Keta = Len(Mid(wkstr, Pos + 1))
				Else
					Keta = 0
				End If
				OKFlg = 0
				For lp = Keta To 10
					MeisaiNO = wkVal(0) + 10 ^ -(lp)
					'���Ƀf�[�^�����邩���m�F����
					' WHERE���̑g�ݗ���
					Jouken = "KOUSYU_NO = '" & Mid(KousyuID, 3, 2) & "'"
					Jouken = Jouken & " AND KOUSYU_CD = '" & Mid(KousyuID, 1, 1) & "'"
					Jouken = Jouken & " AND EDA_NO = '" & KeyKouji.EDA_NO & "'"
					Jouken = Jouken & " AND KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"
					wkJouken = "MEISAI_NO = " & MeisaiNO & " AND " & Jouken
					If CNTGET_WARIDASI_DATA(wkJouken) = 0 Then
						OKFlg = 1
						Exit For
					End If
				Next lp
				If OKFlg = 0 Then
					MsgBox("����ȏケ�̈ʒu�ɂ͑}���ł��܂���B", MsgBoxStyle.OKOnly + MsgBoxStyle.Information)
					Exit Sub
				End If
				'-------------------------------------------------------
				vaSpread1.Row = -1
				frmSYKD031.ShowDialog()
				vaSpread1.Focus()
				
			Case 12 '----- �I��
				Me.Close()
		End Select
		
	End Sub
	
	Private Sub cmdKey_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Enter
		Dim Index As Short = cmdKey.GetIndex(eventSender)
		Call GotFocus(cmdKey(Index), StatusBar1)
	End Sub
	
	Private Sub cmdKey_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Leave
		Dim Index As Short = cmdKey.GetIndex(eventSender)
		Call LostFocus(cmdKey(Index), StatusBar1)
	End Sub
	
	Private Sub cmdLook_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdLook.Click
		Dim Index As Short = cmdLook.GetIndex(eventSender)
		
		Dim wkstr As String
		
		Select Case Index
			Case 0 ' �H��}�X�^����
				frmSearch.MastNo = 1
				frmSearch.ZENTEI = "GYOUSYU_KB = '" & GyosyuID & "' AND KOUSYU_NO <> '00'"
				frmSearch.ShowDialog()
				imMask1(Index).Focus()
				If frmSearch.GetCD <> "" Then
					imMask1(Index).Text = Trim(frmSearch.GetCD)
					wkstr = Trim(GetNameKousyu(GyosyuID, Mid(frmSearch.GetCD, 1, 1)))
					wkstr = wkstr & "�|" & Trim(frmSearch.GetNM)
					If wkstr = "�|" Then wkstr = ""
					imText1(Index).Text = wkstr
					vaSpread1.Focus()
					Exit Sub
				End If
		End Select
		
	End Sub
	
	'UPGRADE_WARNING: Form event frmSYKD030.Activate has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6BA9B8D2-2A32-4B6E-8D36-44949974A5B4"'
	Private Sub frmSYKD030_Activated(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Activated
		If KousyuID = "" Then
			imMask1(0).Focus()
		End If
	End Sub
	
	Private Sub frmSYKD030_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown
		Dim KeyCode As Short = eventArgs.KeyCode
		Dim Shift As Short = eventArgs.KeyData \ &H10000
		Select Case KeyCode
			Case System.Windows.Forms.Keys.F1
				If cmdKey(1).Enabled = True Then cmdKey(1).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(1), New System.EventArgs())
			Case System.Windows.Forms.Keys.F2
				If cmdKey(2).Enabled = True Then cmdKey(2).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(2), New System.EventArgs())
			Case System.Windows.Forms.Keys.F3
				If cmdKey(3).Enabled = True Then cmdKey(3).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(3), New System.EventArgs())
			Case System.Windows.Forms.Keys.F4
				If cmdKey(4).Enabled = True Then cmdKey(4).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(4), New System.EventArgs())
			Case System.Windows.Forms.Keys.F5
				If cmdKey(5).Enabled = True Then cmdKey(5).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(5), New System.EventArgs())
			Case System.Windows.Forms.Keys.F6
				If cmdKey(6).Enabled = True Then cmdKey(6).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(6), New System.EventArgs())
			Case System.Windows.Forms.Keys.F7
				If cmdKey(7).Enabled = True Then cmdKey(7).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(7), New System.EventArgs())
			Case System.Windows.Forms.Keys.F8
				If cmdKey(8).Enabled = True Then cmdKey(8).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(8), New System.EventArgs())
			Case System.Windows.Forms.Keys.F9
				If cmdKey(9).Enabled = True Then cmdKey(9).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(9), New System.EventArgs())
			Case System.Windows.Forms.Keys.F10
				If cmdKey(10).Enabled = True Then cmdKey(10).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(10), New System.EventArgs())
			Case System.Windows.Forms.Keys.F11
				If cmdKey(11).Enabled = True Then cmdKey(11).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(11), New System.EventArgs())
			Case System.Windows.Forms.Keys.F12
				If cmdKey(12).Enabled = True Then cmdKey(12).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(12), New System.EventArgs())
		End Select
	End Sub
	
	Private Sub frmSYKD030_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
		
		Call FormDisp(Me)
		
		LoadFlg = 1
		
		' �����\��
		Call DispClear(1)
		Call ListDataDisp(1)
		
		LoadFlg = 0
		
	End Sub
	
	Private Sub frmSYKD030_FormClosing(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
		Dim Cancel As Boolean = eventArgs.Cancel
		Dim UnloadMode As System.Windows.Forms.CloseReason = eventArgs.CloseReason
		If UnloadMode = System.Windows.Forms.CloseReason.UserClosing Then
			'
		End If
		eventArgs.Cancel = Cancel
	End Sub
	
	Private Sub imMask1_Change(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles imMask1.Change
		Dim Index As Short = imMask1.GetIndex(eventSender)
		Call DispClear()
	End Sub
	
	Private Sub imMask1_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles imMask1.Enter
		Dim Index As Short = imMask1.GetIndex(eventSender)
		Call GotFocus(imMask1(Index), StatusBar1)
	End Sub
	
	Private Sub imMask1_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles imMask1.KeyDown
		Dim KeyCode As Short = eventArgs.KeyCode
		Dim Shift As Short = eventArgs.KeyData \ &H10000
		Dim Index As Short = imMask1.GetIndex(eventSender)
		Select Case KeyCode
			Case System.Windows.Forms.Keys.Return
				vaSpread1.Focus()
			Case System.Windows.Forms.Keys.Space
				Call cmdLook_Click(cmdLook.Item(Index), New System.EventArgs())
		End Select
	End Sub
	
	Private Sub imMask1_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles imMask1.Leave
		Dim Index As Short = imMask1.GetIndex(eventSender)
		
		Dim wkstr As String
		
		Call LostFocus(imMask1(Index), StatusBar1)
		
		'----- ���̓`�F�b�N
		If JoukenCheck(1) = False Then
			Exit Sub
		End If
		
		If KousyuID <> imMask1(0).Text Then
			'----- �H������
			KousyuID = imMask1(0).Text
			'----- �H�햼��
			wkstr = Trim(GetNameKousyu(GyosyuID, Mid(KousyuID, 1, 1))) & "�|"
			wkstr = wkstr & Trim(GetNameKousyu(GyosyuID, Mid(KousyuID, 1, 1), Mid(KousyuID, 3, 2)))
			If wkstr = "�|" Then wkstr = ""
			imText1(0).Text = wkstr
			'----- �ĕ\��
			Call ListDataDisp()
		End If
		
	End Sub
	
	Private Sub vaSpread1_DblClick(ByVal eventSender As System.Object, ByVal eventArgs As AxFPSpread._DSpreadEvents_DblClickEvent) Handles vaSpread1.DblClick
		' �^�C�g���ȊO
		If eventArgs.Col > 0 And eventArgs.Row > 0 Then
			' �C������
			Call cmdKey_Click(cmdKey.Item(2), New System.EventArgs())
		End If
	End Sub
	
	Private Sub vaSpread1_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles vaSpread1.Enter
		Call GotFocus(vaSpread1, StatusBar1)
	End Sub
	
	Private Sub vaSpread1_KeyDownEvent(ByVal eventSender As System.Object, ByVal eventArgs As AxFPSpread._DSpreadEvents_KeyDownEvent) Handles vaSpread1.KeyDownEvent
		If eventArgs.KeyCode = System.Windows.Forms.Keys.Return Then
			If vaSpread1.ActiveRow > 0 Then
				' �C������
				Call cmdKey_Click(cmdKey.Item(2), New System.EventArgs())
			End If
		End If
	End Sub
	
	Private Sub vaSpread1_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles vaSpread1.Leave
		Call LostFocus(vaSpread1, StatusBar1)
	End Sub
End Class