Option Strict Off
Option Explicit On
Friend Class frmSearch
	Inherits System.Windows.Forms.Form
	'=============================================================
	' ���[�U�[���@  �F  �Ђ났��L���b�V���T�[�r�X
	' �V�X�e�����@  �F  �Ɩ��V�X�e��
	' ���W���[����  �F  �}�X�^����
	' ���W���[��ID�@�F  frmSearch.frm
	' �쐬���@ �@�@ �F  ���� 13 �N 05 �� 08 ��
	' �X�V���@�@  �@�F  ����    �N    ��    ��
	'=============================================================
	'
	
	Public MastNo As Short ' 1:�H��}�X�^
	' 2:�Ј��}�X�^
	' 3:�ƎЃ}�X�^
	' 4:��s�}�X�^
	' 5:���Z�@��
	' 6:����}�X�^
	' 7:�Ȗڃ}�X�^
	' 8:�Ȗڃ}�X�^�i�זڊ܂ށj
	' 9:�H���}�X�^
	'10:�H��ז�
	'11:�������
	'12:���o���
	'13:�H���}�X�^�i�}�ԂȂ��j
	
	'��ʕ\���p�\����
	Private Structure DspList
		Dim Code As String
		'UPGRADE_NOTE: Name was upgraded to Name_Renamed. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="A9E4979A-37FA-4718-9994-97DD76ED70A7"'
		Dim Name_Renamed As String
		Dim Yobi As String
	End Structure
	
	Public ZENTEI As String ' �O�񌟍�����
	Public GetCD As String ' �I���R�[�h
	Public GetNM As String ' �I�𖼏�
	Public GetYB As String ' �\������
	
	Private SortMode(1) As Short ' ���� Or �~��
	'
	
	'-------------------------------------------------------------------------------
	'   ����    :   ��ʃN���A
	'   �֐�    :   Sub DispClear()
	'   ����    :   ����
	'   �@�\    :   ��ʂ��N���A���܂��B
	'-------------------------------------------------------------------------------
	Private Sub DispClear()
		SortMode(0) = -1
		SortMode(1) = -1
		vaSpread1.MaxRows = 0
		vaSpread1.set_SortKey(1, 1)
		imText1(0).Text = ""
		imText1(1).Text = ""
		imText1(2).Text = ""
		cmdKey(1).Enabled = False
	End Sub
	
	'-------------------------------------------------------------------------------
	'   ����    :   �������ʕ\��
	'   �֐�    :   Function FormFirstSet()
	'   ����    :   ����
	'   �ߒl    :   True    �f�[�^����
	'   �@�@        False   �f�[�^�Ȃ�
	'   �@�\    :   MastNo���e�}�X�^�̌������ʂ�\������B
	'-------------------------------------------------------------------------------
	Private Function FormFirstSet() As Boolean
		
		Dim lp As Integer
		Dim Cnt As Integer
		Dim DT() As DspList
		
		'��ʏ����ݒ�
		vaSpread1.MaxRows = 0
		cmdKey(1).Enabled = False
		
		ReDim DT(0)
		
		Select Case MastNo
			Case 1 '----- �H��}�X�^
				Cnt = GetKousyuMast(DT)
			Case 2 '----- �Ј��}�X�^
				Cnt = GetSyainMast(DT)
			Case 3 '----- �ƎЃ}�X�^
				Cnt = GetGyosyaMast(DT)
			Case 4 '----- ��s�}�X�^
				Cnt = GetGinkouMast(DT)
			Case 5 '----- ���Z�@��
				Cnt = GetKinyuMast(DT)
			Case 6 '----- ����}�X�^
				Cnt = GetBumonMast(DT)
			Case 7 '----- �Ȗڃ}�X�^
				Cnt = GetKamokuMast(DT)
			Case 8 '----- �Ȗڃ}�X�^�i�זڊ܂ށj
				Cnt = GetKamokuMast2(DT)
			Case 9 '----- �H���}�X�^
				Cnt = GetKoujiMast(DT)
			Case 10 '----- �H��ז�
				Cnt = GetSaimokuMast(DT)
			Case 11 '----- �������
				Cnt = GetChumonMast(DT)
			Case 12 '----- ���o���
				Cnt = GetWaridasiMast(DT)
			Case 13 '----- �H���}�X�^�i�}�ԂȂ��j
				Cnt = GetKoujiMast2(DT)
		End Select
		
		If Cnt <= 0 Then
			If Me.Visible = True Then
				MsgBox("�Y���f�[�^���P��������܂���", MsgBoxStyle.OKOnly, "����")
			End If
			FormFirstSet = False
			Exit Function
		ElseIf Cnt > 500 Then 
			'MsgBox "�\�������͂T�O�O���܂łƂ��܂��B", vbOKOnly, "����"
			Cnt = 500
		End If
		
		vaSpread1.ReDraw = False
		vaSpread1.MaxRows = Cnt
		cmdKey(1).Enabled = True
		
		'�f�[�^�\��
		With vaSpread1
			For lp = 1 To Cnt
				.Col = 1 : .Col2 = .MaxCols
				.Row = lp : .Row2 = lp
				.set_RowHeight(lp, 15#)
				.BlockMode = True
				.Font = VB6.FontChangeBold(.Font, True)
				.BlockMode = False
				.SetText(1, lp, CObj(DT(lp - 1).Code))
				.SetText(2, lp, CObj(DT(lp - 1).Name_Renamed))
				.SetText(3, lp, CObj(DT(lp - 1).Yobi))
			Next lp
		End With
		vaSpread1.ReDraw = True
		If vaSpread1.Visible = True Then
			vaSpread1.Focus()
		End If
		
		FormFirstSet = True
		
	End Function
	
	'-------------------------------------------------------------------------------
	'   ����    :   �I���f�[�^�̎擾
	'   �֐�    :   Function GetData()
	'   ����    :   ����
	'   �ߒl    :   ����
	'   �@�\    :   �I�����ꂽ�f�[�^��Public�ϐ���GetCD�^GetNM�ɃZ�b�g���܂��B
	'-------------------------------------------------------------------------------
	Private Sub GetData()
		
		Dim ssText As Object
		
		Call vaSpread1.GetText(1, vaSpread1.ActiveRow, ssText)
		'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
		GetCD = Trim(ssText)
		Call vaSpread1.GetText(2, vaSpread1.ActiveRow, ssText)
		'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
		GetNM = Trim(ssText)
		Call vaSpread1.GetText(3, vaSpread1.ActiveRow, ssText)
		'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
		GetYB = Trim(ssText)
		
	End Sub
	
	'-------------------------------------------------------------------------------
	'   ����    :   ��ʏ����ݒ�
	'   �֐�    :   Sub DispFirstSet()
	'   ����    :   ����
	'   �ߒl    :   ����
	'   �@�\    :   MastNo���e�}�X�^�ɊY������ݒ���s���B
	'-------------------------------------------------------------------------------
	Private Sub DispFirstSet()
		
		Dim lp As Short
		
		Select Case MastNo
			Case 1 '----- �H��}�X�^
				Call DispClear()
				lblTitle.Text = " �H��}�X�^����"
				Call vaSpread1.SetText(1, 0, "�H������")
				Call vaSpread1.SetText(2, 0, "�H�@�@��@�@��")
				For lp = 1 To 2
					imText1(lp).MaxLength = 3
					imText1(lp).Format = "A9"
					imText1(lp).FormatMode = 0
				Next lp
			Case 2 '----- �Ј��}�X�^
				Call DispClear()
				lblTitle.Text = " �Ј��}�X�^����"
				Call vaSpread1.SetText(1, 0, "�Ј�����")
				Call vaSpread1.SetText(2, 0, "�Ё@�@���@�@��")
				For lp = 1 To 2
					imText1(lp).MaxLength = 8
					imText1(lp).Format = "9"
					imText1(lp).FormatMode = 0
				Next lp
			Case 3 '----- �ƎЃ}�X�^
				Call DispClear()
				lblTitle.Text = " �ƎЃ}�X�^����"
				Call vaSpread1.SetText(1, 0, "�Ǝк���")
				Call vaSpread1.SetText(2, 0, "�Ɓ@�@�Ё@�@��")
				For lp = 1 To 2
					imText1(lp).MaxLength = 8
					imText1(lp).Format = "9"
					imText1(lp).FormatMode = 0
				Next lp
			Case 4 '----- ��s�}�X�^
				Call DispClear()
				lblTitle.Text = " ��s�}�X�^����"
				Call vaSpread1.SetText(1, 0, "��s����")
				Call vaSpread1.SetText(2, 0, "��@�@�s�@�@��")
				For lp = 1 To 2
					imText1(lp).MaxLength = 4
					imText1(lp).Format = "9"
					imText1(lp).FormatMode = 0
				Next lp
			Case 5 '----- ��s�}�X�^
				Call DispClear()
				lblTitle.Text = " ��s�}�X�^����"
				Call vaSpread1.SetText(1, 0, "��s��x�X����")
				Call vaSpread1.SetText(2, 0, "�� �Z �@ �� ��")
				For lp = 1 To 2
					imText1(lp).MaxLength = 7
					imText1(lp).Format = "9"
					imText1(lp).FormatMode = 0
				Next lp
			Case 6 '----- �H���ԍ��}�X�^
				Call DispClear()
				lblTitle.Text = " ����}�X�^����"
				Call vaSpread1.SetText(1, 0, "���庰��")
				Call vaSpread1.SetText(2, 0, "���@�@��@�@��")
				For lp = 1 To 2
					imText1(lp).MaxLength = 8
					imText1(lp).Format = "9"
					imText1(lp).FormatMode = 0
				Next lp
			Case 7 '----- �Ȗڃ}�X�^
				Call DispClear()
				lblTitle.Text = " �Ȗڃ}�X�^����"
				Call vaSpread1.SetText(1, 0, "�Ȗں���")
				Call vaSpread1.SetText(2, 0, "�ȁ@�@�ځ@�@��")
				For lp = 1 To 2
					imText1(lp).MaxLength = 6
					imText1(lp).Format = "9"
					imText1(lp).FormatMode = 0
				Next lp
			Case 8 '----- �Ȗڃ}�X�^
				Call DispClear()
				lblTitle.Text = " �Ȗڃ}�X�^����"
				Call vaSpread1.SetText(1, 0, "�Ȗ�-�זں���")
				Call vaSpread1.SetText(2, 0, "�ȁ@�@�ځ@�@��")
				For lp = 1 To 2
					imText1(lp).MaxLength = 14
					imText1(lp).Format = "9"
					imText1(lp).FormatMode = 0
				Next lp
			Case 9 '----- �H���ԍ��}�X�^
				Call DispClear()
				lblTitle.Text = " �H����񌟍�"
				Call vaSpread1.SetText(1, 0, "�H���ԍ�-�}��")
				Call vaSpread1.SetText(2, 0, "�H�@�@���@�@��")
				For lp = 1 To 2
					imText1(lp).MaxLength = 12
					imText1(lp).Format = "9"
					imText1(lp).FormatMode = 0
				Next lp
			Case 10 '----- �H��זڃ}�X�^
				Call DispClear()
				lblTitle.Text = " �H��זڃ}�X�^����"
				Call vaSpread1.SetText(1, 0, "�H��זں���")
				Call vaSpread1.SetText(2, 0, "�H �� �� �� ��")
				For lp = 1 To 2
					imText1(lp).MaxLength = 5
					imText1(lp).Format = "A9"
					imText1(lp).FormatMode = 0
				Next lp
			Case 11 '----- �������
				Call DispClear()
				lblTitle.Text = " �������}�X�^����"
				Call vaSpread1.SetText(1, 0, "�����ԍ�")
				Call vaSpread1.SetText(2, 0, "���@�@�@��")
				For lp = 1 To 2
					imText1(lp).MaxLength = 2
					imText1(lp).Format = "A9"
					imText1(lp).FormatMode = 0
				Next lp
			Case 12 '----- ���o���
				Call DispClear()
				lblTitle.Text = " ���o���}�X�^����"
				Call vaSpread1.SetText(1, 0, "���o�ԍ�")
				Call vaSpread1.SetText(2, 0, "���@�@�@��")
				For lp = 1 To 2
					imText1(lp).MaxLength = 2
					imText1(lp).Format = "A9"
					imText1(lp).FormatMode = 0
				Next lp
			Case 13 '----- �H���ԍ��}�X�^�i�}�ԂȂ��j
				Call DispClear()
				lblTitle.Text = " �H����񌟍�"
				Call vaSpread1.SetText(1, 0, "�H���ԍ�")
				Call vaSpread1.SetText(2, 0, "�H�@�@���@�@��")
				For lp = 1 To 2
					imText1(lp).MaxLength = 8
					imText1(lp).Format = "9"
					imText1(lp).FormatMode = 0
				Next lp
		End Select
		
	End Sub
	
	'-------------------------------------------------------------------------------
	'   ����    :   �H�팟���f�[�^�̎擾
	'   �֐�    :   Function GetKousyuMast()
	'   ����    :   DT()    DspList
	'   �ߒl    :   Cnt     ���o����
	'   �@�@        -1      �ُ�I��
	'   �@�\    :   �����ɊY������R�[�h�^���̂̎擾���s���B
	'-------------------------------------------------------------------------------
	Private Function GetKousyuMast(ByRef DT() As DspList) As Integer
		
		Dim SQL As String
		Dim Rs As ADODB.Recordset
		Dim OpenFlg As Short
		Dim Cnt As Integer
		Dim Jouken As String
		Dim wkMei As String
		Dim wkCD1 As String
		Dim wkCD2 As String
		
		On Error GoTo GetKousyuMast_Err
		
		'�߂�l�̏�����
		GetKousyuMast = -1
		
		'----- �ϐ��̏�����
		wkMei = ""
		wkCD1 = ""
		wkCD2 = ""
		
		'----- ���o���̎擾
		wkMei = Trim(imText1(0).Text)
		wkCD1 = Trim(imText1(1).Text)
		wkCD2 = Trim(imText1(2).Text)
		
		'----- WHERE���̑g�ݗ���
		Jouken = ""
		If Trim(ZENTEI) <> "" Then
			Jouken = "(" & ZENTEI & ")"
		End If
		If wkCD1 <> "" Or wkCD2 <> "" Then
			If Jouken <> "" Then Jouken = Jouken & " AND "
			If wkCD1 = wkCD2 Then
				Jouken = Jouken & "KOUSYU_CD + KOUSYU_NO = '" & wkCD1 & "'"
			ElseIf wkCD1 <> "" And wkCD2 = "" Then 
				Jouken = Jouken & "KOUSYU_CD + KOUSYU_NO >= '" & wkCD1 & "'"
			ElseIf wkCD2 <> "" And wkCD1 = "" Then 
				Jouken = Jouken & "KOUSYU_CD + KOUSYU_NO <= '" & wkCD2 & "'"
			Else
				Jouken = Jouken & "KOUSYU_CD + KOUSYU_NO BETWEEN '" & wkCD1 & "' AND '" & wkCD2 & "'"
			End If
		End If
		If wkMei <> "" Then
			If Jouken <> "" Then Jouken = Jouken & " AND "
			Jouken = Jouken & "MEISYOU Like '%" & wkMei & "%'"
		End If
		
		'----- SQL/SELECT���̑g�ݗ���
		SQL = "SELECT"
		SQL = SQL & " KOUSYU_CD AS F01,"
		SQL = SQL & " KOUSYU_NO AS F02,"
		SQL = SQL & " MEISYOU   AS F03"
		SQL = SQL & " FROM KOUSYU_MAST"
		If Jouken <> "" Then
			SQL = SQL & " WHERE " & Jouken
		End If
		SQL = SQL & " ORDER BY KOUSYU_CD, KOUSYU_NO"
		
		'----- SQL�����s
		Rs = SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText)
		OpenFlg = 1
		
		Cnt = 0
		Do Until Rs.EOF
			ReDim Preserve DT(Cnt)
			'UPGRADE_WARNING: Couldn't resolve default property of object RsNull(Rs, F02). Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			'UPGRADE_WARNING: Couldn't resolve default property of object RsNull(). Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			DT(Cnt).Code = RsNull(Rs, "F01") & "-" & RsNull(Rs, "F02")
			'UPGRADE_WARNING: Couldn't resolve default property of object RsNull(). Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			DT(Cnt).Name_Renamed = RsNull(Rs, "F03")
			'UPGRADE_WARNING: Couldn't resolve default property of object RsNull(). Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			DT(Cnt).Yobi = RsNull(Rs, "F02")
			Cnt = Cnt + 1
			Rs.MoveNext()
		Loop 
		
		Rs.Close()
		'UPGRADE_NOTE: Object Rs may not be destroyed until it is garbage collected. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"'
		Rs = Nothing
		
		'�߂�l�Ɍ������Z�b�g
		GetKousyuMast = Cnt
		
		Exit Function
		
GetKousyuMast_Err: 
		
		If OpenFlg = 1 Then
			Rs.Close()
		End If
		'UPGRADE_NOTE: Object Rs may not be destroyed until it is garbage collected. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"'
		Rs = Nothing
		
		Call Sql_Error_Msg("KOUSYU_MAST SELECT")
		
	End Function
	
	'-------------------------------------------------------------------------------
	'   ����    :   �Ј������f�[�^�̎擾
	'   �֐�    :   Function GetSyainMast()
	'   ����    :   DT()    DspList
	'   �ߒl    :   Cnt     ���o����
	'   �@�@        -1      �ُ�I��
	'   �@�\    :   �����ɊY������R�[�h�^���̂̎擾���s���B
	'-------------------------------------------------------------------------------
	Private Function GetSyainMast(ByRef DT() As DspList) As Integer
		
		Dim SQL As String
		Dim Rs As ADODB.Recordset
		Dim OpenFlg As Short
		Dim Cnt As Integer
		Dim Jouken As String
		Dim wkMei As String
		Dim wkCD1 As String
		Dim wkCD2 As String
		
		On Error GoTo GetSyainMast_Err
		
		'�߂�l�̏�����
		GetSyainMast = -1
		
		'----- �ϐ��̏�����
		wkMei = ""
		wkCD1 = ""
		wkCD2 = ""
		
		'----- ���o���̎擾
		wkMei = Trim(imText1(0).Text)
		wkCD1 = Trim(imText1(1).Text)
		wkCD2 = Trim(imText1(2).Text)
		
		'----- WHERE���̑g�ݗ���
		Jouken = ""
		If Trim(ZENTEI) <> "" Then
			Jouken = "(" & ZENTEI & ")"
		End If
		If wkCD1 <> "" Or wkCD2 <> "" Then
			If Jouken <> "" Then Jouken = Jouken & " AND "
			If wkCD1 = wkCD2 Then
				Jouken = Jouken & "SYAIN_CD = '" & wkCD1 & "'"
			ElseIf wkCD1 <> "" And wkCD2 = "" Then 
				Jouken = Jouken & "SYAIN_CD >= '" & wkCD1 & "'"
			ElseIf wkCD2 <> "" And wkCD1 = "" Then 
				Jouken = Jouken & "SYAIN_CD <= '" & wkCD2 & "'"
			Else
				Jouken = Jouken & "SYAIN_CD BETWEEN '" & wkCD1 & "' AND '" & wkCD2 & "'"
			End If
		End If
		If wkMei <> "" Then
			If Jouken <> "" Then Jouken = Jouken & " AND "
			Jouken = Jouken & "MEISYOU Like '%" & wkMei & "%'"
		End If
		
		'----- SQL/SELECT���̑g�ݗ���
		SQL = "SELECT"
		SQL = SQL & " SYAIN_CD AS F01,"
		SQL = SQL & " MEISYOU  AS F02"
		SQL = SQL & " FROM SYAIN_MAST"
		If Jouken <> "" Then
			SQL = SQL & " WHERE " & Jouken
		End If
		SQL = SQL & " ORDER BY SYAIN_CD"
		
		'----- SQL�����s
		Rs = SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText)
		OpenFlg = 1
		
		Cnt = 0
		Do Until Rs.EOF
			ReDim Preserve DT(Cnt)
			'UPGRADE_WARNING: Couldn't resolve default property of object RsNull(). Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			DT(Cnt).Code = RsNull(Rs, "F01")
			'UPGRADE_WARNING: Couldn't resolve default property of object RsNull(). Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			DT(Cnt).Name_Renamed = RsNull(Rs, "F02")
			Cnt = Cnt + 1
			Rs.MoveNext()
		Loop 
		
		Rs.Close()
		'UPGRADE_NOTE: Object Rs may not be destroyed until it is garbage collected. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"'
		Rs = Nothing
		
		'�߂�l�Ɍ������Z�b�g
		GetSyainMast = Cnt
		
		Exit Function
		
GetSyainMast_Err: 
		
		If OpenFlg = 1 Then
			Rs.Close()
		End If
		'UPGRADE_NOTE: Object Rs may not be destroyed until it is garbage collected. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"'
		Rs = Nothing
		
		Call Sql_Error_Msg("SYAIN_MAST SELECT")
		
	End Function
	
	'-------------------------------------------------------------------------------
	'   ����    :   �ƎЌ����f�[�^�̎擾
	'   �֐�    :   Function GetGyosyaMast()
	'   ����    :   DT()    DspList
	'   �ߒl    :   Cnt     ���o����
	'   �@�@        -1      �ُ�I��
	'   �@�\    :   �����ɊY������R�[�h�^���̂̎擾���s���B
	'-------------------------------------------------------------------------------
	Private Function GetGyosyaMast(ByRef DT() As DspList) As Integer
		
		Dim SQL As String
		Dim Rs As ADODB.Recordset
		Dim OpenFlg As Short
		Dim Cnt As Integer
		Dim Jouken As String
		Dim wkMei As String
		Dim wkCD1 As String
		Dim wkCD2 As String
		
		On Error GoTo GetGyosyaMast_Err
		
		'�߂�l�̏�����
		GetGyosyaMast = -1
		
		'----- �ϐ��̏�����
		wkMei = ""
		wkCD1 = ""
		wkCD2 = ""
		
		'----- ���o���̎擾
		wkMei = Trim(imText1(0).Text)
		wkCD1 = Trim(imText1(1).Text)
		wkCD2 = Trim(imText1(2).Text)
		
		'----- WHERE���̑g�ݗ���
		Jouken = ""
		If Trim(ZENTEI) <> "" Then
			Jouken = "(" & ZENTEI & ")"
		End If
		If wkCD1 <> "" Or wkCD2 <> "" Then
			If Jouken <> "" Then Jouken = Jouken & " AND "
			If wkCD1 = wkCD2 Then
				Jouken = Jouken & "GYOUSYA_CD = '" & wkCD1 & "'"
			ElseIf wkCD1 <> "" And wkCD2 = "" Then 
				Jouken = Jouken & "GYOUSYA_CD >= '" & wkCD1 & "'"
			ElseIf wkCD2 <> "" And wkCD1 = "" Then 
				Jouken = Jouken & "GYOUSYA_CD <= '" & wkCD2 & "'"
			Else
				Jouken = Jouken & "GYOUSYA_CD BETWEEN '" & wkCD1 & "' AND '" & wkCD2 & "'"
			End If
		End If
		If wkMei <> "" Then
			If Jouken <> "" Then Jouken = Jouken & " AND "
			Jouken = Jouken & "MEISYOU Like '%" & wkMei & "%'"
		End If
		
		'----- SQL/SELECT���̑g�ݗ���
		SQL = "SELECT"
		SQL = SQL & " GYOUSYA_CD AS F01,"
		SQL = SQL & " MEISYOU    AS F02"
		SQL = SQL & " FROM GYOUSYA_MAST"
		If Jouken <> "" Then
			SQL = SQL & " WHERE " & Jouken
		End If
		SQL = SQL & " ORDER BY GYOUSYA_CD"
		
		'----- SQL�����s
		Rs = SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText)
		OpenFlg = 1
		
		Cnt = 0
		Do Until Rs.EOF
			ReDim Preserve DT(Cnt)
			'UPGRADE_WARNING: Couldn't resolve default property of object RsNull(). Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			DT(Cnt).Code = RsNull(Rs, "F01")
			'UPGRADE_WARNING: Couldn't resolve default property of object RsNull(). Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			DT(Cnt).Name_Renamed = RsNull(Rs, "F02")
			Cnt = Cnt + 1
			Rs.MoveNext()
		Loop 
		
		Rs.Close()
		'UPGRADE_NOTE: Object Rs may not be destroyed until it is garbage collected. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"'
		Rs = Nothing
		
		'�߂�l�Ɍ������Z�b�g
		GetGyosyaMast = Cnt
		
		Exit Function
		
GetGyosyaMast_Err: 
		
		If OpenFlg = 1 Then
			Rs.Close()
		End If
		'UPGRADE_NOTE: Object Rs may not be destroyed until it is garbage collected. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"'
		Rs = Nothing
		
		Call Sql_Error_Msg("GYOUSYA_MAST SELECT")
		
	End Function
	
	'-------------------------------------------------------------------------------
	'   ����    :   ��s�����f�[�^�̎擾
	'   �֐�    :   Function GetGinkouMast()
	'   ����    :   DT()    DspList
	'   �ߒl    :   Cnt     ���o����
	'   �@�@        -1      �ُ�I��
	'   �@�\    :   �����ɊY������R�[�h�^���̂̎擾���s���B
	'-------------------------------------------------------------------------------
	Private Function GetGinkouMast(ByRef DT() As DspList) As Integer
		
		Dim SQL As String
		Dim Rs As ADODB.Recordset
		Dim OpenFlg As Short
		Dim Cnt As Integer
		Dim Jouken As String
		Dim wkMei As String
		Dim wkCD1 As String
		Dim wkCD2 As String
		
		On Error GoTo GetGinkouMast_Err
		
		'�߂�l�̏�����
		GetGinkouMast = -1
		
		'----- �ϐ��̏�����
		wkMei = ""
		wkCD1 = ""
		wkCD2 = ""
		
		'----- ���o���̎擾
		wkMei = Trim(imText1(0).Text)
		wkCD1 = Trim(imText1(1).Text)
		wkCD2 = Trim(imText1(2).Text)
		
		'----- WHERE���̑g�ݗ���
		Jouken = ""
		If Trim(ZENTEI) <> "" Then
			Jouken = "(" & ZENTEI & ")"
		End If
		If wkCD1 <> "" Or wkCD2 <> "" Then
			If Jouken <> "" Then Jouken = Jouken & " AND "
			If wkCD1 = wkCD2 Then
				Jouken = Jouken & "GINKOU_CD = '" & wkCD1 & "'"
			ElseIf wkCD1 <> "" And wkCD2 = "" Then 
				Jouken = Jouken & "GINKOU_CD >= '" & wkCD1 & "'"
			ElseIf wkCD2 <> "" And wkCD1 = "" Then 
				Jouken = Jouken & "GINKOU_CD <= '" & wkCD2 & "'"
			Else
				Jouken = Jouken & "GINKOU_CD BETWEEN '" & wkCD1 & "' AND '" & wkCD2 & "'"
			End If
		End If
		If wkMei <> "" Then
			If Jouken <> "" Then Jouken = Jouken & " AND "
			Jouken = Jouken & "MEISYOU Like '%" & wkMei & "%'"
		End If
		If Jouken <> "" Then Jouken = Jouken & " AND "
		Jouken = Jouken & "SITEN_CD = '000'"
		
		'----- SQL/SELECT���̑g�ݗ���
		SQL = "SELECT"
		SQL = SQL & " GINKOU_CD AS F01,"
		SQL = SQL & " MEISYOU   AS F02"
		SQL = SQL & " FROM GINKOU_MAST"
		If Jouken <> "" Then
			SQL = SQL & " WHERE " & Jouken
		End If
		SQL = SQL & " ORDER BY GINKOU_CD"
		
		'----- SQL�����s
		Rs = SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText)
		OpenFlg = 1
		
		Cnt = 0
		Do Until Rs.EOF
			ReDim Preserve DT(Cnt)
			'UPGRADE_WARNING: Couldn't resolve default property of object RsNull(). Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			DT(Cnt).Code = RsNull(Rs, "F01")
			'UPGRADE_WARNING: Couldn't resolve default property of object RsNull(). Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			DT(Cnt).Name_Renamed = RsNull(Rs, "F02")
			Cnt = Cnt + 1
			Rs.MoveNext()
		Loop 
		
		Rs.Close()
		'UPGRADE_NOTE: Object Rs may not be destroyed until it is garbage collected. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"'
		Rs = Nothing
		
		'�߂�l�Ɍ������Z�b�g
		GetGinkouMast = Cnt
		
		Exit Function
		
GetGinkouMast_Err: 
		
		If OpenFlg = 1 Then
			Rs.Close()
		End If
		'UPGRADE_NOTE: Object Rs may not be destroyed until it is garbage collected. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"'
		Rs = Nothing
		
		Call Sql_Error_Msg("GINKOU_MAST SELECT")
		
	End Function
	
	'-------------------------------------------------------------------------------
	'   ����    :   ���Z�@�֌����f�[�^�̎擾
	'   �֐�    :   Function GetKinyuMast()
	'   ����    :   DT()    DspList
	'   �ߒl    :   Cnt     ���o����
	'   �@�@        -1      �ُ�I��
	'   �@�\    :   �����ɊY������R�[�h�^���̂̎擾���s���B
	'-------------------------------------------------------------------------------
	Private Function GetKinyuMast(ByRef DT() As DspList) As Integer
		
		Dim QRY1 As String
		Dim QRY2 As String
		Dim SQL As String
		Dim Rs As ADODB.Recordset
		Dim OpenFlg As Short
		Dim Cnt As Integer
		Dim Jouken As String
		Dim wkMei As String
		Dim wkCD1 As String
		Dim wkCD2 As String
		
		On Error GoTo GetKinyuMast_Err
		
		'�߂�l�̏�����
		GetKinyuMast = -1
		
		'----- �ϐ��̏�����
		wkMei = ""
		wkCD1 = ""
		wkCD2 = ""
		
		'----- ���o���̎擾
		wkMei = Trim(imText1(0).Text)
		wkCD1 = Trim(imText1(1).Text)
		wkCD2 = Trim(imText1(2).Text)
		
		'----- WHERE���̑g�ݗ���
		Jouken = ""
		If Trim(ZENTEI) <> "" Then
			Jouken = "(" & ZENTEI & ")"
		End If
		If wkCD1 <> "" Or wkCD2 <> "" Then
			If Jouken <> "" Then Jouken = Jouken & " AND "
			If wkCD1 = wkCD2 Then
				If Len(wkCD1) < 5 Then
					Jouken = Jouken & "GIN.GINKOU_CD = '" & wkCD1 & "'"
				Else
					Jouken = Jouken & "SHI.GINKOU_CD + SHI.SITEN_CD = '" & wkCD1 & "'"
				End If
			ElseIf wkCD1 <> "" And wkCD2 = "" Then 
				If Len(wkCD1) < 5 Then
					Jouken = Jouken & "GIN.GINKOU_CD >= '" & wkCD1 & "'"
				Else
					Jouken = Jouken & "SHI.GINKOU_CD + SHI.SITEN_CD >= '" & wkCD1 & "'"
				End If
			ElseIf wkCD2 <> "" And wkCD1 = "" Then 
				If Len(wkCD2) < 5 Then
					Jouken = Jouken & "GIN.GINKOU_CD <= '" & wkCD2 & "'"
				Else
					Jouken = Jouken & "SHI.GINKOU_CD + SHI.SITEN_CD <= '" & wkCD2 & "'"
				End If
			Else
				If Len(wkCD1) < 5 And Len(wkCD2) < 5 Then
					Jouken = Jouken & "GIN.GINKOU_CD BETWEEN '" & wkCD1 & "' AND '" & wkCD2 & "'"
				Else
					Jouken = Jouken & "SHI.GINKOU_CD + SHI.SITEN_CD BETWEEN '" & wkCD1 & "' AND '" & wkCD2 & "'"
				End If
			End If
		End If
		If wkMei <> "" Then
			If Jouken <> "" Then Jouken = Jouken & " AND "
			Jouken = Jouken & "(GIN.MEISYOU Like '%" & wkMei & "%' OR SHI.MEISYOU Like '%" & wkMei & "%')"
		End If
		
		'----- QRY/SELECT���̑g�ݗ���
		QRY1 = "(SELECT GINKOU_MAST.*"
		QRY1 = QRY1 & " FROM GINKOU_MAST"
		QRY1 = QRY1 & " WHERE SITEN_CD = '000') AS GIN"
		QRY2 = "(SELECT GINKOU_MAST.*"
		QRY2 = QRY2 & " FROM GINKOU_MAST"
		QRY2 = QRY2 & " WHERE SITEN_CD <> '000') AS SHI"
		
		'----- SQL/SELECT���̑g�ݗ���
		SQL = "SELECT"
		SQL = SQL & " GIN.GINKOU_CD AS F01,"
		SQL = SQL & " SHI.SITEN_CD  AS F02,"
		SQL = SQL & " GIN.MEISYOU   AS F03,"
		SQL = SQL & " SHI.MEISYOU   AS F04"
		SQL = SQL & " FROM " & QRY1 & " INNER JOIN " & QRY2
		SQL = SQL & " ON GIN.GINKOU_CD = SHI.GINKOU_CD"
		If Jouken <> "" Then
			SQL = SQL & " WHERE " & Jouken
		End If
		SQL = SQL & " ORDER BY GIN.GINKOU_CD, SHI.SITEN_CD"
		
		'----- SQL�����s
		Rs = SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText)
		OpenFlg = 1
		
		Cnt = 0
		Do Until Rs.EOF
			ReDim Preserve DT(Cnt)
			'UPGRADE_WARNING: Couldn't resolve default property of object RsNull(Rs, F02). Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			'UPGRADE_WARNING: Couldn't resolve default property of object RsNull(). Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			DT(Cnt).Code = RsNull(Rs, "F01") & RsNull(Rs, "F02")
			'UPGRADE_WARNING: Couldn't resolve default property of object RsNull(). Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			DT(Cnt).Name_Renamed = Trim(RsNull(Rs, "F03")) & "�@" & Trim(RsNull(Rs, "F04"))
			Cnt = Cnt + 1
			Rs.MoveNext()
		Loop 
		
		Rs.Close()
		'UPGRADE_NOTE: Object Rs may not be destroyed until it is garbage collected. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"'
		Rs = Nothing
		
		'�߂�l�Ɍ������Z�b�g
		GetKinyuMast = Cnt
		
		Exit Function
		
GetKinyuMast_Err: 
		
		If OpenFlg = 1 Then
			Rs.Close()
		End If
		'UPGRADE_NOTE: Object Rs may not be destroyed until it is garbage collected. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"'
		Rs = Nothing
		
		Call Sql_Error_Msg("GINKOU_MAST SELECT")
		
	End Function
	
	'-------------------------------------------------------------------------------
	'   ����    :   ���匟���f�[�^�̎擾
	'   �֐�    :   Function GetBumonMast()
	'   ����    :   DT()    DspList
	'   �ߒl    :   Cnt     ���o����
	'   �@�@        -1      �ُ�I��
	'   �@�\    :   �����ɊY������R�[�h�^���̂̎擾���s���B
	'-------------------------------------------------------------------------------
	Private Function GetBumonMast(ByRef DT() As DspList) As Integer
		
		Dim SQL As String
		Dim Rs As ADODB.Recordset
		Dim OpenFlg As Short
		Dim Cnt As Integer
		Dim Jouken As String
		Dim wkMei As String
		Dim wkCD1 As String
		Dim wkCD2 As String
		
		On Error GoTo GetBumonMast_Err
		
		'�߂�l�̏�����
		GetBumonMast = -1
		
		'----- �ϐ��̏�����
		wkMei = ""
		wkCD1 = ""
		wkCD2 = ""
		
		'----- ���o���̎擾
		wkMei = Trim(imText1(0).Text)
		wkCD1 = Trim(imText1(1).Text)
		wkCD2 = Trim(imText1(2).Text)
		
		'----- WHERE���̑g�ݗ���
		Jouken = ""
		If Trim(ZENTEI) <> "" Then
			Jouken = "(" & ZENTEI & ")"
		End If
		If wkCD1 <> "" Or wkCD2 <> "" Then
			If Jouken <> "" Then Jouken = Jouken & " AND "
			If wkCD1 = wkCD2 Then
				Jouken = Jouken & "KOUJI_NO = '" & wkCD1 & "'"
			ElseIf wkCD1 <> "" And wkCD2 = "" Then 
				Jouken = Jouken & "KOUJI_NO >= '" & wkCD1 & "'"
			ElseIf wkCD2 <> "" And wkCD1 = "" Then 
				Jouken = Jouken & "KOUJI_NO <= '" & wkCD2 & "'"
			Else
				Jouken = Jouken & "KOUJI_NO BETWEEN '" & wkCD1 & "' AND '" & wkCD2 & "'"
			End If
		End If
		If wkMei <> "" Then
			If Jouken <> "" Then Jouken = Jouken & " AND "
			Jouken = Jouken & "MEISYOU Like '%" & wkMei & "%'"
		End If
		If Jouken <> "" Then Jouken = Jouken & " AND "
		Jouken = Jouken & "GYOUSYU_KB = '05'"
		
		'----- SQL/SELECT���̑g�ݗ���
		SQL = "SELECT"
		SQL = SQL & " KOUJI_NO AS F01,"
		SQL = SQL & " MEISYOU  AS F02"
		SQL = SQL & " FROM KOUJI_NO_MAST"
		If Jouken <> "" Then
			SQL = SQL & " WHERE " & Jouken
		End If
		SQL = SQL & " ORDER BY KOUJI_NO"
		
		'----- SQL�����s
		Rs = SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText)
		OpenFlg = 1
		
		Cnt = 0
		Do Until Rs.EOF
			ReDim Preserve DT(Cnt)
			'UPGRADE_WARNING: Couldn't resolve default property of object RsNull(). Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			DT(Cnt).Code = RsNull(Rs, "F01")
			'UPGRADE_WARNING: Couldn't resolve default property of object RsNull(). Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			DT(Cnt).Name_Renamed = RsNull(Rs, "F02")
			Cnt = Cnt + 1
			Rs.MoveNext()
		Loop 
		
		Rs.Close()
		'UPGRADE_NOTE: Object Rs may not be destroyed until it is garbage collected. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"'
		Rs = Nothing
		
		'�߂�l�Ɍ������Z�b�g
		GetBumonMast = Cnt
		
		Exit Function
		
GetBumonMast_Err: 
		
		If OpenFlg = 1 Then
			Rs.Close()
		End If
		'UPGRADE_NOTE: Object Rs may not be destroyed until it is garbage collected. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"'
		Rs = Nothing
		
		Call Sql_Error_Msg("KOUJI_NO_MAST SELECT")
		
	End Function
	
	'-------------------------------------------------------------------------------
	'   ����    :   �Ȗڌ����f�[�^�̎擾
	'   �֐�    :   Function GetKamokuMast()
	'   ����    :   DT()    DspList
	'   �ߒl    :   Cnt     ���o����
	'   �@�@        -1      �ُ�I��
	'   �@�\    :   �����ɊY������R�[�h�^���̂̎擾���s���B
	'-------------------------------------------------------------------------------
	Private Function GetKamokuMast(ByRef DT() As DspList) As Integer
		
		Dim SQL As String
		Dim Rs As ADODB.Recordset
		Dim OpenFlg As Short
		Dim Cnt As Integer
		Dim Jouken As String
		Dim wkMei As String
		Dim wkCD1 As String
		Dim wkCD2 As String
		
		On Error GoTo GetKamokuMast_Err
		
		'�߂�l�̏�����
		GetKamokuMast = -1
		
		'----- �ϐ��̏�����
		wkMei = ""
		wkCD1 = ""
		wkCD2 = ""
		
		'----- ���o���̎擾
		wkMei = Trim(imText1(0).Text)
		wkCD1 = Trim(imText1(1).Text)
		wkCD2 = Trim(imText1(2).Text)
		
		'----- WHERE���̑g�ݗ���
		Jouken = ""
		If Trim(ZENTEI) <> "" Then
			Jouken = "(" & ZENTEI & ")"
		End If
		If wkCD1 <> "" Or wkCD2 <> "" Then
			If Jouken <> "" Then Jouken = Jouken & " AND "
			If wkCD1 = wkCD2 Then
				Jouken = Jouken & "KAMOKU_CD = '" & wkCD1 & "'"
			ElseIf wkCD1 <> "" And wkCD2 = "" Then 
				Jouken = Jouken & "KAMOKU_CD >= '" & wkCD1 & "'"
			ElseIf wkCD2 <> "" And wkCD1 = "" Then 
				Jouken = Jouken & "KAMOKU_CD <= '" & wkCD2 & "'"
			Else
				Jouken = Jouken & "KAMOKU_CD BETWEEN '" & wkCD1 & "' AND '" & wkCD2 & "'"
			End If
		End If
		If wkMei <> "" Then
			If Jouken <> "" Then Jouken = Jouken & " AND "
			Jouken = Jouken & "MEISYOU Like '%" & wkMei & "%'"
		End If
		If Jouken <> "" Then Jouken = Jouken & " AND "
		Jouken = Jouken & "(SAIMOKU_CD Is Null Or SAIMOKU_CD = '')"
		
		'----- SQL/SELECT���̑g�ݗ���
		SQL = "SELECT"
		SQL = SQL & " KAMOKU_CD AS F01,"
		SQL = SQL & " MEISYOU   AS F02"
		SQL = SQL & " FROM KAMOKU_MAST"
		If Jouken <> "" Then
			SQL = SQL & " WHERE " & Jouken
		End If
		SQL = SQL & " ORDER BY KAMOKU_CD"
		
		'----- SQL�����s
		Rs = SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText)
		OpenFlg = 1
		
		Cnt = 0
		Do Until Rs.EOF
			ReDim Preserve DT(Cnt)
			'UPGRADE_WARNING: Couldn't resolve default property of object RsNull(). Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			DT(Cnt).Code = RsNull(Rs, "F01")
			'UPGRADE_WARNING: Couldn't resolve default property of object RsNull(). Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			DT(Cnt).Name_Renamed = RsNull(Rs, "F02")
			Cnt = Cnt + 1
			Rs.MoveNext()
		Loop 
		
		Rs.Close()
		'UPGRADE_NOTE: Object Rs may not be destroyed until it is garbage collected. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"'
		Rs = Nothing
		
		'�߂�l�Ɍ������Z�b�g
		GetKamokuMast = Cnt
		
		Exit Function
		
GetKamokuMast_Err: 
		
		If OpenFlg = 1 Then
			Rs.Close()
		End If
		'UPGRADE_NOTE: Object Rs may not be destroyed until it is garbage collected. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"'
		Rs = Nothing
		
		Call Sql_Error_Msg("KAMOKU_MAST SELECT")
		
	End Function
	
	'-------------------------------------------------------------------------------
	'   ����    :   �Ȗڥ�זڌ����f�[�^�̎擾
	'   �֐�    :   Function GetKamokuMast2()
	'   ����    :   DT()    DspList
	'   �ߒl    :   Cnt     ���o����
	'   �@�@        -1      �ُ�I��
	'   �@�\    :   �����ɊY������R�[�h�^���̂̎擾���s���B
	'-------------------------------------------------------------------------------
	Private Function GetKamokuMast2(ByRef DT() As DspList) As Integer
		
		Dim QRY1 As String
		Dim QRY2 As String
		Dim SQL As String
		Dim Rs As ADODB.Recordset
		Dim OpenFlg As Short
		Dim Cnt As Integer
		Dim Jouken As String
		Dim wkMei As String
		Dim wkCD1 As String
		Dim wkCD2 As String
		
		On Error GoTo GetKamokuMast2_Err
		
		'�߂�l�̏�����
		GetKamokuMast2 = -1
		
		'----- �ϐ��̏�����
		wkMei = ""
		wkCD1 = ""
		wkCD2 = ""
		
		'----- ���o���̎擾
		wkMei = Trim(imText1(0).Text)
		wkCD1 = Trim(imText1(1).Text)
		wkCD2 = Trim(imText1(2).Text)
		
		'----- WHERE���̑g�ݗ���
		Jouken = ""
		If Trim(ZENTEI) <> "" Then
			Jouken = "(" & ZENTEI & ")"
		End If
		If wkCD1 <> "" Or wkCD2 <> "" Then
			If Jouken <> "" Then Jouken = Jouken & " AND "
			If wkCD1 = wkCD2 Then
				If Len(wkCD1) > 6 Then
					Jouken = Jouken & "SAI.KAMOKU_CD + SAI.SAIMOKU_CD = '" & wkCD1 & "'"
				Else
					Jouken = Jouken & "(KAM.KAMOKU_CD + KAM.SAIMOKU_CD = '" & wkCD1 & "'"
					Jouken = Jouken & " OR SAI.KAMOKU_CD + SAI.SAIMOKU_CD = '" & wkCD1 & "')"
				End If
			ElseIf wkCD1 <> "" And wkCD2 = "" Then 
				If Len(wkCD1) > 6 Then
					Jouken = Jouken & "SAI.KAMOKU_CD + SAI.SAIMOKU_CD >= '" & wkCD1 & "'"
				Else
					Jouken = Jouken & "(KAM.KAMOKU_CD + KAM.SAIMOKU_CD >= '" & wkCD1 & "'"
					Jouken = Jouken & " OR SAI.KAMOKU_CD + SAI.SAIMOKU_CD >= '" & wkCD1 & "')"
				End If
			ElseIf wkCD2 <> "" And wkCD1 = "" Then 
				If Len(wkCD2) > 6 Then
					Jouken = Jouken & "SAI.KAMOKU_CD + SAI.SAIMOKU_CD <= '" & wkCD2 & "'"
				Else
					Jouken = Jouken & "(KAM.KAMOKU_CD + KAM.SAIMOKU_CD <= '" & wkCD2 & "'"
					Jouken = Jouken & " OR SAI.KAMOKU_CD + SAI.SAIMOKU_CD <= '" & wkCD2 & "')"
				End If
			Else
				If Len(wkCD1) > 6 And Len(wkCD2) > 6 Then
					Jouken = Jouken & "SAI.KAMOKU_CD + SAI.SAIMOKU_CD BETWEEN '" & wkCD1 & "' AND '" & wkCD2 & "'"
				Else
					Jouken = Jouken & "(KAM.KAMOKU_CD + KAM.SAIMOKU_CD BETWEEN '" & wkCD1 & "' AND '" & wkCD2 & "'"
					Jouken = Jouken & " OR SAI.KAMOKU_CD + SAI.SAIMOKU_CD BETWEEN '" & wkCD1 & "' AND '" & wkCD2 & "')"
				End If
			End If
		End If
		If wkMei <> "" Then
			If Jouken <> "" Then Jouken = Jouken & " AND "
			Jouken = Jouken & "(KAM.MEISYOU Like '%" & wkMei & "%' OR SAI.MEISYOU Like '%" & wkMei & "%')"
		End If
		
		'----- QRY/SELECT���̑g�ݗ���
		QRY1 = "(SELECT KAMOKU_MAST.*"
		QRY1 = QRY1 & " FROM KAMOKU_MAST"
		QRY1 = QRY1 & " WHERE (SAIMOKU_CD Is Null Or SAIMOKU_CD = '')) AS KAM"
		QRY2 = "(SELECT KAMOKU_MAST.*"
		QRY2 = QRY2 & " FROM KAMOKU_MAST"
		QRY2 = QRY2 & " WHERE SAIMOKU_CD <> '') AS SAI"
		
		'----- SQL/SELECT���̑g�ݗ���
		SQL = "SELECT"
		SQL = SQL & " KAM.KAMOKU_CD  AS F01,"
		SQL = SQL & " SAI.SAIMOKU_CD AS F02,"
		SQL = SQL & " KAM.MEISYOU    AS F03,"
		SQL = SQL & " SAI.MEISYOU    AS F04"
		SQL = SQL & " FROM " & QRY1 & " LEFT JOIN " & QRY2
		SQL = SQL & " ON KAM.KAMOKU_CD = SAI.KAMOKU_CD"
		If Jouken <> "" Then
			SQL = SQL & " WHERE " & Jouken
		End If
		SQL = SQL & " ORDER BY KAM.KAMOKU_CD, SAI.SAIMOKU_CD"
		
		'----- SQL�����s
		Rs = SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText)
		OpenFlg = 1
		
		Cnt = 0
		Do Until Rs.EOF
			ReDim Preserve DT(Cnt)
			'UPGRADE_WARNING: Couldn't resolve default property of object RsNull(). Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			If Trim(RsNull(Rs, "F02")) = "" Then
				'UPGRADE_WARNING: Couldn't resolve default property of object RsNull(). Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				DT(Cnt).Code = RsNull(Rs, "F01") & Space(9)
			Else
				'UPGRADE_WARNING: Couldn't resolve default property of object RsNull(Rs, F02). Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				'UPGRADE_WARNING: Couldn't resolve default property of object RsNull(). Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				DT(Cnt).Code = RsNull(Rs, "F01") & "-" & RsNull(Rs, "F02")
			End If
			'UPGRADE_WARNING: Couldn't resolve default property of object RsNull(). Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			DT(Cnt).Name_Renamed = Trim(RsNull(Rs, "F03")) & "�@" & Trim(RsNull(Rs, "F04"))
			'UPGRADE_WARNING: Couldn't resolve default property of object RsNull(). Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			DT(Cnt).Yobi = CStr(Len(Trim(RsNull(Rs, "F03"))))
			Cnt = Cnt + 1
			Rs.MoveNext()
		Loop 
		
		Rs.Close()
		'UPGRADE_NOTE: Object Rs may not be destroyed until it is garbage collected. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"'
		Rs = Nothing
		
		'�߂�l�Ɍ������Z�b�g
		GetKamokuMast2 = Cnt
		
		Exit Function
		
GetKamokuMast2_Err: 
		
		If OpenFlg = 1 Then
			Rs.Close()
		End If
		'UPGRADE_NOTE: Object Rs may not be destroyed until it is garbage collected. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"'
		Rs = Nothing
		
		Call Sql_Error_Msg("KAMOKU_MAST SELECT")
		
	End Function
	
	'-------------------------------------------------------------------------------
	'   ����    :   �H�������f�[�^�̎擾
	'   �֐�    :   Function GetKoujiMast()
	'   ����    :   DT()    DspList
	'   �ߒl    :   Cnt     ���o����
	'   �@�@        -1      �ُ�I��
	'   �@�\    :   �����ɊY������R�[�h�^���̂̎擾���s���B
	'-------------------------------------------------------------------------------
	Private Function GetKoujiMast(ByRef DT() As DspList) As Integer
		
		Dim SQL As String
		Dim Rs As ADODB.Recordset
		Dim OpenFlg As Short
		Dim Cnt As Integer
		Dim Jouken As String
		Dim wkMei As String
		Dim wkCD1 As String
		Dim wkCD2 As String
		
		On Error GoTo GetKoujiMast_Err
		
		'�߂�l�̏�����
		GetKoujiMast = -1
		
		'----- �ϐ��̏�����
		wkMei = ""
		wkCD1 = ""
		wkCD2 = ""
		
		'----- ���o���̎擾
		wkMei = Trim(imText1(0).Text)
		wkCD1 = Trim(imText1(1).Text)
		wkCD2 = Trim(imText1(2).Text)
		
		'----- WHERE���̑g�ݗ���
		Jouken = ""
		If Trim(ZENTEI) <> "" Then
			Jouken = "(" & ZENTEI & ")"
		End If
		If wkCD1 <> "" Or wkCD2 <> "" Then
			If Jouken <> "" Then Jouken = Jouken & " AND "
			If wkCD1 = wkCD2 Then
				Jouken = Jouken & "KOUJI_NO + EDA_NO = '" & wkCD1 & "'"
			ElseIf wkCD1 <> "" And wkCD2 = "" Then 
				Jouken = Jouken & "KOUJI_NO + EDA_NO >= '" & wkCD1 & "'"
			ElseIf wkCD2 <> "" And wkCD1 = "" Then 
				Jouken = Jouken & "KOUJI_NO + EDA_NO <= '" & wkCD2 & "'"
			Else
				Jouken = Jouken & "KOUJI_NO + EDA_NO BETWEEN '" & wkCD1 & "' AND '" & wkCD2 & "'"
			End If
		End If
		If wkMei <> "" Then
			If Jouken <> "" Then Jouken = Jouken & " AND "
			Jouken = Jouken & "MEISYOU Like '%" & wkMei & "%'"
		End If
		
		'----- SQL/SELECT���̑g�ݗ���
		SQL = "SELECT"
		SQL = SQL & " KOUJI_NO   AS F01,"
		SQL = SQL & " EDA_NO     AS F02,"
		SQL = SQL & " MEISYOU    AS F03,"
		SQL = SQL & " GYOUSYU_KB AS F04"
		SQL = SQL & " FROM KOUJI_NO_MAST"
		If Jouken <> "" Then
			SQL = SQL & " WHERE " & Jouken
		End If
		SQL = SQL & " ORDER BY KOUJI_NO, EDA_NO"
		
		'----- SQL�����s
		Rs = SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText)
		OpenFlg = 1
		
		Cnt = 0
		Do Until Rs.EOF
			ReDim Preserve DT(Cnt)
			'UPGRADE_WARNING: Couldn't resolve default property of object RsNull(). Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			If Val(RsNull(Rs, "F02")) = 0 Then
				'UPGRADE_WARNING: Couldn't resolve default property of object RsNull(). Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				DT(Cnt).Code = RsNull(Rs, "F01") & Space(5)
			Else
				'UPGRADE_WARNING: Couldn't resolve default property of object RsNull(Rs, F02). Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				'UPGRADE_WARNING: Couldn't resolve default property of object RsNull(). Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				DT(Cnt).Code = RsNull(Rs, "F01") & "-" & RsNull(Rs, "F02")
			End If
			'UPGRADE_WARNING: Couldn't resolve default property of object RsNull(). Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			DT(Cnt).Name_Renamed = RsNull(Rs, "F03")
			'UPGRADE_WARNING: Couldn't resolve default property of object RsNull(). Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			DT(Cnt).Yobi = RsNull(Rs, "F04")
			Cnt = Cnt + 1
			Rs.MoveNext()
		Loop 
		
		Rs.Close()
		'UPGRADE_NOTE: Object Rs may not be destroyed until it is garbage collected. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"'
		Rs = Nothing
		
		'�߂�l�Ɍ������Z�b�g
		GetKoujiMast = Cnt
		
		Exit Function
		
GetKoujiMast_Err: 
		
		If OpenFlg = 1 Then
			Rs.Close()
		End If
		'UPGRADE_NOTE: Object Rs may not be destroyed until it is garbage collected. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"'
		Rs = Nothing
		
		Call Sql_Error_Msg("KOUJI_NO_MAST SELECT")
		
	End Function
	
	'-------------------------------------------------------------------------------
	'   ����    :   �H��זڌ����f�[�^�̎擾
	'   �֐�    :   Function GetSaimokuMast()
	'   ����    :   DT()    DspList
	'   �ߒl    :   Cnt     ���o����
	'   �@�@        -1      �ُ�I��
	'   �@�\    :   �����ɊY������R�[�h�^���̂̎擾���s���B
	'-------------------------------------------------------------------------------
	Private Function GetSaimokuMast(ByRef DT() As DspList) As Integer
		
		Dim SQL As String
		Dim Rs As ADODB.Recordset
		Dim OpenFlg As Short
		Dim Cnt As Integer
		Dim Jouken As String
		Dim wkMei As String
		Dim wkCD1 As String
		Dim wkCD2 As String
		
		On Error GoTo GetSaimokuMast_Err
		
		'�߂�l�̏�����
		GetSaimokuMast = -1
		
		'----- �ϐ��̏�����
		wkMei = ""
		wkCD1 = ""
		wkCD2 = ""
		
		'----- ���o���̎擾
		wkMei = Trim(imText1(0).Text)
		wkCD1 = Trim(imText1(1).Text)
		wkCD2 = Trim(imText1(2).Text)
		
		'----- WHERE���̑g�ݗ���
		Jouken = ""
		If Trim(ZENTEI) <> "" Then
			Jouken = "(" & ZENTEI & ")"
		End If
		If wkCD1 <> "" Or wkCD2 <> "" Then
			If Jouken <> "" Then Jouken = Jouken & " AND "
			If wkCD1 = wkCD2 Then
				Jouken = Jouken & "SAIMOKU_CD = '" & wkCD1 & "'"
			ElseIf wkCD1 <> "" And wkCD2 = "" Then 
				Jouken = Jouken & "SAIMOKU_CD >= '" & wkCD1 & "'"
			ElseIf wkCD2 <> "" And wkCD1 = "" Then 
				Jouken = Jouken & "SAIMOKU_CD <= '" & wkCD2 & "'"
			Else
				Jouken = Jouken & "SAIMOKU_CD BETWEEN '" & wkCD1 & "' AND '" & wkCD2 & "'"
			End If
		End If
		If wkMei <> "" Then
			If Jouken <> "" Then Jouken = Jouken & " AND "
			Jouken = Jouken & "MEISYOU Like '%" & wkMei & "%'"
		End If
		
		'----- SQL/SELECT���̑g�ݗ���
		SQL = "SELECT"
		SQL = SQL & " SAIMOKU_CD AS F01,"
		SQL = SQL & " MEISYOU    AS F02"
		SQL = SQL & " FROM SAIMOKU_MAST"
		If Jouken <> "" Then
			SQL = SQL & " WHERE " & Jouken
		End If
		SQL = SQL & " ORDER BY SAIMOKU_CD"
		
		'----- SQL�����s
		Rs = SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText)
		OpenFlg = 1
		
		Cnt = 0
		Do Until Rs.EOF
			ReDim Preserve DT(Cnt)
			'UPGRADE_WARNING: Couldn't resolve default property of object RsNull(). Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			DT(Cnt).Code = RsNull(Rs, "F01")
			'UPGRADE_WARNING: Couldn't resolve default property of object RsNull(). Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			DT(Cnt).Name_Renamed = RsNull(Rs, "F02")
			Cnt = Cnt + 1
			Rs.MoveNext()
		Loop 
		
		Rs.Close()
		'UPGRADE_NOTE: Object Rs may not be destroyed until it is garbage collected. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"'
		Rs = Nothing
		
		'�߂�l�Ɍ������Z�b�g
		GetSaimokuMast = Cnt
		
		Exit Function
		
GetSaimokuMast_Err: 
		
		If OpenFlg = 1 Then
			Rs.Close()
		End If
		'UPGRADE_NOTE: Object Rs may not be destroyed until it is garbage collected. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"'
		Rs = Nothing
		
		Call Sql_Error_Msg("SAIMOKU_MAST SELECT")
		
	End Function
	
	'-------------------------------------------------------------------------------
	'   ����    :   ������񌟍��f�[�^�̎擾
	'   �֐�    :   Function GetChumonMast()
	'   ����    :   DT()    DspList
	'   �ߒl    :   Cnt     ���o����
	'   �@�@        -1      �ُ�I��
	'   �@�\    :   �����ɊY������R�[�h�^���̂̎擾���s���B
	'-------------------------------------------------------------------------------
	Private Function GetChumonMast(ByRef DT() As DspList) As Integer
		
		Dim SQL As String
		Dim Rs As ADODB.Recordset
		Dim OpenFlg As Short
		Dim Cnt As Integer
		Dim Jouken As String
		Dim wkMei As String
		Dim wkCD1 As String
		Dim wkCD2 As String
		
		On Error GoTo GetChumonMast_Err
		
		'�߂�l�̏�����
		GetChumonMast = -1
		
		'----- �ϐ��̏�����
		wkMei = ""
		wkCD1 = ""
		wkCD2 = ""
		
		'----- ���o���̎擾
		wkMei = Trim(imText1(0).Text)
		wkCD1 = Trim(imText1(1).Text)
		wkCD2 = Trim(imText1(2).Text)
		
		'----- WHERE���̑g�ݗ���
		Jouken = ""
		If Trim(ZENTEI) <> "" Then
			Jouken = "(" & ZENTEI & ")"
		End If
		If wkCD1 <> "" Or wkCD2 <> "" Then
			If Jouken <> "" Then Jouken = Jouken & " AND "
			If wkCD1 = wkCD2 Then
				Jouken = Jouken & "CHUUMON_NO = '" & wkCD1 & "'"
			ElseIf wkCD1 <> "" And wkCD2 = "" Then 
				Jouken = Jouken & "CHUUMON_NO >= '" & wkCD1 & "'"
			ElseIf wkCD2 <> "" And wkCD1 = "" Then 
				Jouken = Jouken & "CHUUMON_NO <= '" & wkCD2 & "'"
			Else
				Jouken = Jouken & "CHUUMON_NO BETWEEN '" & wkCD1 & "' AND '" & wkCD2 & "'"
			End If
		End If
		If wkMei <> "" Then
			If Jouken <> "" Then Jouken = Jouken & " AND "
			Jouken = Jouken & "MEISYOU Like '%" & wkMei & "%'"
		End If
		
		'----- SQL/SELECT���̑g�ݗ���
		SQL = "SELECT"
		SQL = SQL & " CHUUMON_NO AS F01,"
		SQL = SQL & " MEISYOU    AS F02,"
		SQL = SQL & " HARAI_KB   AS F03"
		SQL = SQL & " FROM CHUUMON_MAST"
		If Jouken <> "" Then
			SQL = SQL & " WHERE " & Jouken
		End If
		SQL = SQL & " ORDER BY CHUUMON_NO"
		
		'----- SQL�����s
		Rs = SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText)
		OpenFlg = 1
		
		Cnt = 0
		Do Until Rs.EOF
			ReDim Preserve DT(Cnt)
			'UPGRADE_WARNING: Couldn't resolve default property of object RsNull(). Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			DT(Cnt).Code = RsNull(Rs, "F01")
			'UPGRADE_WARNING: Couldn't resolve default property of object RsNull(). Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			DT(Cnt).Name_Renamed = RsNull(Rs, "F02")
			'UPGRADE_WARNING: Couldn't resolve default property of object RsNull(). Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			DT(Cnt).Yobi = RsNull(Rs, "F03")
			Cnt = Cnt + 1
			Rs.MoveNext()
		Loop 
		
		Rs.Close()
		'UPGRADE_NOTE: Object Rs may not be destroyed until it is garbage collected. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"'
		Rs = Nothing
		
		'�߂�l�Ɍ������Z�b�g
		GetChumonMast = Cnt
		
		Exit Function
		
GetChumonMast_Err: 
		
		If OpenFlg = 1 Then
			Rs.Close()
		End If
		'UPGRADE_NOTE: Object Rs may not be destroyed until it is garbage collected. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"'
		Rs = Nothing
		
		Call Sql_Error_Msg("CHUUMON_MAST SELECT")
		
	End Function
	
	'-------------------------------------------------------------------------------
	'   ����    :   ���o��񌟍��f�[�^�̎擾
	'   �֐�    :   Function GetWaridasiMast()
	'   ����    :   DT()    DspList
	'   �ߒl    :   Cnt     ���o����
	'   �@�@        -1      �ُ�I��
	'   �@�\    :   �����ɊY������R�[�h�^���̂̎擾���s���B
	'-------------------------------------------------------------------------------
	Private Function GetWaridasiMast(ByRef DT() As DspList) As Integer
		
		Dim SQL As String
		Dim Rs As ADODB.Recordset
		Dim OpenFlg As Short
		Dim Cnt As Integer
		Dim Jouken As String
		Dim wkMei As String
		Dim wkCD1 As String
		Dim wkCD2 As String
		
		On Error GoTo GetWaridasiMast_Err
		
		'�߂�l�̏�����
		GetWaridasiMast = -1
		
		'----- �ϐ��̏�����
		wkMei = ""
		wkCD1 = ""
		wkCD2 = ""
		
		'----- ���o���̎擾
		wkMei = Trim(imText1(0).Text)
		wkCD1 = Trim(imText1(1).Text)
		wkCD2 = Trim(imText1(2).Text)
		
		'----- WHERE���̑g�ݗ���
		Jouken = ""
		If Trim(ZENTEI) <> "" Then
			Jouken = "(" & ZENTEI & ")"
		End If
		If wkCD1 <> "" Or wkCD2 <> "" Then
			If Jouken <> "" Then Jouken = Jouken & " AND "
			If wkCD1 = wkCD2 Then
				Jouken = Jouken & "WARIDASI_NO = '" & wkCD1 & "'"
			ElseIf wkCD1 <> "" And wkCD2 = "" Then 
				Jouken = Jouken & "WARIDASI_NO >= '" & wkCD1 & "'"
			ElseIf wkCD2 <> "" And wkCD1 = "" Then 
				Jouken = Jouken & "WARIDASI_NO <= '" & wkCD2 & "'"
			Else
				Jouken = Jouken & "WARIDASI_NO BETWEEN '" & wkCD1 & "' AND '" & wkCD2 & "'"
			End If
		End If
		If wkMei <> "" Then
			If Jouken <> "" Then Jouken = Jouken & " AND "
			Jouken = Jouken & "MEISYOU Like '%" & wkMei & "%'"
		End If
		
		'----- SQL/SELECT���̑g�ݗ���
		SQL = "SELECT"
		SQL = SQL & " WARIDASI_NO AS F01,"
		SQL = SQL & " MEISYOU     AS F02,"
		SQL = SQL & " CHOKUEI_KB  AS F03"
		SQL = SQL & " FROM WARIDASI_MAST"
		If Jouken <> "" Then
			SQL = SQL & " WHERE " & Jouken
		End If
		SQL = SQL & " ORDER BY WARIDASI_NO"
		
		'----- SQL�����s
		Rs = SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText)
		OpenFlg = 1
		
		Cnt = 0
		Do Until Rs.EOF
			ReDim Preserve DT(Cnt)
			'UPGRADE_WARNING: Couldn't resolve default property of object RsNull(). Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			DT(Cnt).Code = RsNull(Rs, "F01")
			'UPGRADE_WARNING: Couldn't resolve default property of object RsNull(). Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			DT(Cnt).Name_Renamed = RsNull(Rs, "F02")
			'UPGRADE_WARNING: Couldn't resolve default property of object RsNull(). Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			DT(Cnt).Yobi = RsNull(Rs, "F03")
			Cnt = Cnt + 1
			Rs.MoveNext()
		Loop 
		
		Rs.Close()
		'UPGRADE_NOTE: Object Rs may not be destroyed until it is garbage collected. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"'
		Rs = Nothing
		
		'�߂�l�Ɍ������Z�b�g
		GetWaridasiMast = Cnt
		
		Exit Function
		
GetWaridasiMast_Err: 
		
		If OpenFlg = 1 Then
			Rs.Close()
		End If
		'UPGRADE_NOTE: Object Rs may not be destroyed until it is garbage collected. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"'
		Rs = Nothing
		
		Call Sql_Error_Msg("WARIDASI_MAST SELECT")
		
	End Function
	
	'-------------------------------------------------------------------------------
	'   ����    :   �H�������f�[�^�̎擾
	'   �֐�    :   Function GetKoujiMast2()
	'   ����    :   DT()    DspList
	'   �ߒl    :   Cnt     ���o����
	'   �@�@        -1      �ُ�I��
	'   �@�\    :   �����ɊY������R�[�h�^���̂̎擾���s���B
	'-------------------------------------------------------------------------------
	Private Function GetKoujiMast2(ByRef DT() As DspList) As Integer
		
		Dim SQL As String
		Dim Rs As ADODB.Recordset
		Dim OpenFlg As Short
		Dim Cnt As Integer
		Dim Jouken As String
		Dim wkMei As String
		Dim wkCD1 As String
		Dim wkCD2 As String
		
		On Error GoTo GetKoujiMast2_Err
		
		'�߂�l�̏�����
		GetKoujiMast2 = -1
		
		'----- �ϐ��̏�����
		wkMei = ""
		wkCD1 = ""
		wkCD2 = ""
		
		'----- ���o���̎擾
		wkMei = Trim(imText1(0).Text)
		wkCD1 = Trim(imText1(1).Text)
		wkCD2 = Trim(imText1(2).Text)
		
		'----- WHERE���̑g�ݗ���
		Jouken = ""
		If Trim(ZENTEI) <> "" Then
			Jouken = "(" & ZENTEI & ")"
		End If
		If wkCD1 <> "" Or wkCD2 <> "" Then
			If Jouken <> "" Then Jouken = Jouken & " AND "
			If wkCD1 = wkCD2 Then
				Jouken = Jouken & "KOUJI_NO = '" & wkCD1 & "'"
			ElseIf wkCD1 <> "" And wkCD2 = "" Then 
				Jouken = Jouken & "KOUJI_NO >= '" & wkCD1 & "'"
			ElseIf wkCD2 <> "" And wkCD1 = "" Then 
				Jouken = Jouken & "KOUJI_NO <= '" & wkCD2 & "'"
			Else
				Jouken = Jouken & "KOUJI_NO BETWEEN '" & wkCD1 & "' AND '" & wkCD2 & "'"
			End If
		End If
		If wkMei <> "" Then
			If Jouken <> "" Then Jouken = Jouken & " AND "
			Jouken = Jouken & "MEISYOU Like '%" & wkMei & "%'"
		End If
		
		'----- SQL/SELECT���̑g�ݗ���
		SQL = "SELECT"
		SQL = SQL & " KOUJI_NO        AS F01,"
		SQL = SQL & " MIN(MEISYOU)    AS F02,"
		SQL = SQL & " MIN(GYOUSYU_KB) AS F03"
		SQL = SQL & " FROM KOUJI_NO_MAST"
		If Jouken <> "" Then
			SQL = SQL & " WHERE " & Jouken
		End If
		SQL = SQL & " GROUP BY KOUJI_NO"
		SQL = SQL & " ORDER BY KOUJI_NO"
		
		'----- SQL�����s
		Rs = SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText)
		OpenFlg = 1
		
		Cnt = 0
		Do Until Rs.EOF
			ReDim Preserve DT(Cnt)
			'UPGRADE_WARNING: Couldn't resolve default property of object RsNull(). Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			DT(Cnt).Code = RsNull(Rs, "F01")
			'UPGRADE_WARNING: Couldn't resolve default property of object RsNull(). Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			DT(Cnt).Yobi = RsNull(Rs, "F03")
			Select Case DT(Cnt).Yobi
				Case "03" : DT(Cnt).Name_Renamed = "���j���[�A��"
				Case "04" : DT(Cnt).Name_Renamed = "�����x�X"
				Case Else
					'UPGRADE_WARNING: Couldn't resolve default property of object RsNull(). Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
					DT(Cnt).Name_Renamed = RsNull(Rs, "F02")
			End Select
			Cnt = Cnt + 1
			Rs.MoveNext()
		Loop 
		
		Rs.Close()
		'UPGRADE_NOTE: Object Rs may not be destroyed until it is garbage collected. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"'
		Rs = Nothing
		
		'�߂�l�Ɍ������Z�b�g
		GetKoujiMast2 = Cnt
		
		Exit Function
		
GetKoujiMast2_Err: 
		
		If OpenFlg = 1 Then
			Rs.Close()
		End If
		'UPGRADE_NOTE: Object Rs may not be destroyed until it is garbage collected. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"'
		Rs = Nothing
		
		Call Sql_Error_Msg("KOUJI_NO_MAST SELECT")
		
	End Function
	
	Private Sub cmdKey_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Click
		Dim Index As Short = cmdKey.GetIndex(eventSender)
		
		Select Case Index
			Case 1 '----- ����
				Call GetData()
				ZENTEI = ""
				Me.Close()
				
			Case 5 '----- ����
				Call HaniCheck("1", imText1(1), imText1(1), imText1(2), imText1(2))
				'UPGRADE_WARNING: Screen property Screen.MousePointer has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6BA9B8D2-2A32-4B6E-8D36-44949974A5B4"'
				System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
				If FormFirstSet() = False Then
					If imText1(0).Visible = True Then
						imText1(0).Focus()
					End If
				End If
				'UPGRADE_WARNING: Screen property Screen.MousePointer has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6BA9B8D2-2A32-4B6E-8D36-44949974A5B4"'
				System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
				
			Case 12 '----- �I��
				ZENTEI = ""
				GetCD = ""
				GetNM = ""
				GetYB = ""
				Me.Close()
		End Select
		
	End Sub
	
	Private Sub cmdKey_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Enter
		Dim Index As Short = cmdKey.GetIndex(eventSender)
		Call GotFocus(cmdKey(Index), StatusBar1)
	End Sub
	
	Private Sub cmdKey_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Leave
		Dim Index As Short = cmdKey.GetIndex(eventSender)
		Call LostFocus(cmdKey(Index), StatusBar1)
	End Sub
	
	Private Sub frmSearch_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown
		Dim KeyCode As Short = eventArgs.KeyCode
		Dim Shift As Short = eventArgs.KeyData \ &H10000
		Select Case KeyCode
			Case System.Windows.Forms.Keys.F1 '----- ����
				If cmdKey(1).Enabled = True Then cmdKey(1).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(1), New System.EventArgs())
			Case System.Windows.Forms.Keys.F5 '----- ����
				If cmdKey(5).Enabled = True Then cmdKey(5).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(5), New System.EventArgs())
			Case System.Windows.Forms.Keys.F12 '----- �I��
				If cmdKey(12).Enabled = True Then cmdKey(12).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(12), New System.EventArgs())
		End Select
	End Sub
	
	Private Sub frmSearch_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
		Call FormDisp(Me)
		GetCD = ""
		GetNM = ""
		GetYB = ""
		Call DispFirstSet()
		Call cmdKey_Click(cmdKey.Item(5), New System.EventArgs())
	End Sub
	
	Private Sub frmSearch_FormClosing(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
		Dim Cancel As Boolean = eventArgs.Cancel
		Dim UnloadMode As System.Windows.Forms.CloseReason = eventArgs.CloseReason
		If UnloadMode = System.Windows.Forms.CloseReason.UserClosing Then
			'----- �I������
			Call cmdKey_Click(cmdKey.Item(12), New System.EventArgs())
		End If
		eventArgs.Cancel = Cancel
	End Sub
	
	Private Sub imText1_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles imText1.Enter
		Dim Index As Short = imText1.GetIndex(eventSender)
		Call GotFocus(imText1(Index), StatusBar1)
	End Sub
	
	Private Sub imText1_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles imText1.KeyDown
		Dim KeyCode As Short = eventArgs.KeyCode
		Dim Shift As Short = eventArgs.KeyData \ &H10000
		Dim Index As Short = imText1.GetIndex(eventSender)
		If KeyCode = System.Windows.Forms.Keys.Return Then
			Select Case Index
				Case 0, 1
					imText1(Index + 1).Focus()
				Case 2
					cmdKey(5).Focus()
			End Select
		End If
	End Sub
	
	Private Sub imText1_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles imText1.Leave
		Dim Index As Short = imText1.GetIndex(eventSender)
		
		Dim Fmt As String
		
		Call LostFocus(imText1(Index), StatusBar1)
		
		'----- �R�[�h���͂̏ꍇ
		If Index <> 0 Then
			If Trim(imText1(Index).Text) <> "" Then
				If imText1(1).Format = "9" And Not (MastNo = 5 Or MastNo = 8 Or MastNo = 9) Then
					Fmt = New String("0", imText1(Index).MaxLength)
					imText1(Index).Text = VB6.Format(Val(imText1(Index).Text), Fmt)
				End If
			End If
		End If
		
	End Sub
	
	Private Sub vaSpread1_ClickEvent(ByVal eventSender As System.Object, ByVal eventArgs As AxFPSpread._DSpreadEvents_ClickEvent) Handles vaSpread1.ClickEvent
		If eventArgs.Row = 0 Then
			If vaSpread1.get_SortKey(1) = eventArgs.Col Then
				SortMode(eventArgs.Col - 1) = Not SortMode(eventArgs.Col - 1)
			Else
				SortMode(eventArgs.Col - 1) = -1
			End If
			With vaSpread1
				.eventArgs.Col = 1
				.eventArgs.Row = 1
				.Col2 = .MaxCols
				.Row2 = .MaxRows
				.SortBy = FPSpread.SortByConstants.SortByRow
				.set_SortKey(1, eventArgs.Col)
				.set_SortKeyOrder(1, SortMode(eventArgs.Col - 1) + 2)
				.Action = FPSpread.ActionConstants.ActionSort
			End With
		End If
	End Sub
	
	Private Sub vaSpread1_DblClick(ByVal eventSender As System.Object, ByVal eventArgs As AxFPSpread._DSpreadEvents_DblClickEvent) Handles vaSpread1.DblClick
		If eventArgs.Col > 0 And eventArgs.Row > 0 Then
			Call frmSearch_KeyDown(Me, New System.Windows.Forms.KeyEventArgs(System.Windows.Forms.Keys.F1 Or 0 * &H10000))
		End If
	End Sub
	
	Private Sub vaSpread1_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles vaSpread1.Enter
		Call GotFocus(vaSpread1, StatusBar1)
	End Sub
	
	Private Sub vaSpread1_KeyDownEvent(ByVal eventSender As System.Object, ByVal eventArgs As AxFPSpread._DSpreadEvents_KeyDownEvent) Handles vaSpread1.KeyDownEvent
		If eventArgs.KeyCode = System.Windows.Forms.Keys.Return Then
			If vaSpread1.ActiveRow > 0 Then
				Call frmSearch_KeyDown(Me, New System.Windows.Forms.KeyEventArgs(System.Windows.Forms.Keys.F1 Or 0 * &H10000))
			End If
		End If
	End Sub
	
	Private Sub vaSpread1_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles vaSpread1.Leave
		Call LostFocus(vaSpread1, StatusBar1)
	End Sub
End Class