Option Strict Off
Option Explicit On
Module basMain2
	
	'���o�����������̓`�F�b�N���X�g
	'���o����������̓`�F�b�N���X�g
	'���o�����`�[���̓`�F�b�N���X�g
	'���y�؁��O�����̓`�F�b�N���X�g
	'���y�؁���ʕ����̓`�F�b�N���X�g
	'�����z���O�����̓`�F�b�N���X�g
	'�����z����ʕ����̓`�F�b�N���X�g
	Public CHECKLIST01 As String
	Public CHECKLIST02 As String
	Public CHECKLIST03 As String
	Public CHECKLIST04 As String
	Public CHECKLIST05 As String
	'���o�����󒍕񍐏�
	Public J_HOUKOKU01 As String
	Public J_HOUKOKU02 As String
	Public J_HOUKOKU03 As String
	Public J_HOUKOKU04 As String
	Public J_HOUKOKU05 As String
	'���y�؁��o�����񍐏�
	Public D_HOUKOKU01 As String
	Public D_HOUKOKU02 As String
	Public D_HOUKOKU03 As String
	'���y�؁��H������ڍ�
	Public G_SYOUSAI01 As String
	Public G_SYOUSAI02 As String
	Public G_SYOUSAI03 As String
	Public G_SYOUSAI04 As String
	Public G_SYOUSAI05 As String
	'���y�؁��x���ꗗ�i�䗦�v�Z�j
	Public HIRITU01 As String
	Public HIRITU02 As String
	Public HIRITU03 As String
	Public HIRITU04 As String
	Public HIRITU05 As String
	'���y�؁��H������
	'�����z���H������
	Public GEPPOU01 As String
	Public GEPPOU02 As String
	Public GEPPOU03 As String
	Public GEPPOU04 As String
	Public GEPPOU05 As String
	Public GEPPOU06 As String
	Public GEPPOU07 As String
	Public GEPPOU08 As String
	'�����z�����s�\�Z���F�ꗗ
	Public J_YOSAN01 As String
	Public J_YOSAN02 As String
	Public J_YOSAN03 As String
	Public J_YOSAN04 As String
	Public J_YOSAN05 As String
	
	' ����p�C�j�V�����t�@�C����
	Public Const PRN_INI_FILE_NAME As String = "SANPRN.INI"
	
	'-------------------------------------------------------------------------------
	'   ����    :   ����p���̎擾
	'   �֐�    :   Sub PRN_INI_FILE_Read()
	'   ����    :   ����
	'   �ߒl    :   ����
	'   �@�\    :   ����p���̎擾���s���܂��B
	'-------------------------------------------------------------------------------
	Public Sub PRN_INI_FILE_Read()
		
		Dim Def As String '�f�t�H���g������
		Dim SectionName As String
		Dim nSize As Integer
		Dim wkstr As New VB6.FixedLengthString(100) '�擾������
		Dim wkPath As String
		'Dim IniDrv      As String
		Dim SetPath As String
		
		'2013/12/24 �C�� ------------------------------------------------------------------------------����������
		'���s�J�����g�f�B���N�g������擾
		'wkPath = App.Path & "\" & PRN_INI_FILE_NAME
		'If UCase(Dir(wkPath)) <> UCase(PRN_INI_FILE_NAME) Then wkPath = Left(App.Path, 2) & "\Syk_sys\System\" & PRN_INI_FILE_NAME
		'IniDrv = UCase(Left(wkPath, 2))
		'������
		wkPath = PRNPATH
		'----------------------------------------------------------------------------------------------����������
		
		'�V�X�e�����̓ǂݍ���
		SectionName = "System"
		
		'���o�����������̓`�F�b�N���X�g
		'���o����������̓`�F�b�N���X�g
		'���o�����`�[���̓`�F�b�N���X�g
		'���y�؁��O�����̓`�F�b�N���X�g
		'���y�؁���ʕ����̓`�F�b�N���X�g
		'�����z���O�����̓`�F�b�N���X�g
		'�����z����ʕ����̓`�F�b�N���X�g
		wkstr.Value = Space(100) : Def = "����"
		nSize = basMain.GetPrivateProfileString(SectionName, "CHECKLIST01", Def, wkstr.Value, Len(wkstr.Value), wkPath)
		'UPGRADE_ISSUE: Constant vbUnicode was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="55B59875-9A95-4B71-9D6A-7C294BF7139D"'
		'UPGRADE_ISSUE: Constant vbFromUnicode was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="55B59875-9A95-4B71-9D6A-7C294BF7139D"'
		'UPGRADE_ISSUE: MidB function is not supported. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"'
		CHECKLIST01 = StrConv(MidB(StrConv(wkstr.Value, vbFromUnicode), 1, nSize), vbUnicode)
		wkstr.Value = Space(100) : Def = "����"
		nSize = basMain.GetPrivateProfileString(SectionName, "CHECKLIST02", Def, wkstr.Value, Len(wkstr.Value), wkPath)
		'UPGRADE_ISSUE: Constant vbUnicode was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="55B59875-9A95-4B71-9D6A-7C294BF7139D"'
		'UPGRADE_ISSUE: Constant vbFromUnicode was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="55B59875-9A95-4B71-9D6A-7C294BF7139D"'
		'UPGRADE_ISSUE: MidB function is not supported. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"'
		CHECKLIST02 = StrConv(MidB(StrConv(wkstr.Value, vbFromUnicode), 1, nSize), vbUnicode)
		wkstr.Value = Space(100) : Def = "����"
		nSize = basMain.GetPrivateProfileString(SectionName, "CHECKLIST03", Def, wkstr.Value, Len(wkstr.Value), wkPath)
		'UPGRADE_ISSUE: Constant vbUnicode was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="55B59875-9A95-4B71-9D6A-7C294BF7139D"'
		'UPGRADE_ISSUE: Constant vbFromUnicode was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="55B59875-9A95-4B71-9D6A-7C294BF7139D"'
		'UPGRADE_ISSUE: MidB function is not supported. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"'
		CHECKLIST03 = StrConv(MidB(StrConv(wkstr.Value, vbFromUnicode), 1, nSize), vbUnicode)
		wkstr.Value = Space(100) : Def = "����"
		nSize = basMain.GetPrivateProfileString(SectionName, "CHECKLIST04", Def, wkstr.Value, Len(wkstr.Value), wkPath)
		'UPGRADE_ISSUE: Constant vbUnicode was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="55B59875-9A95-4B71-9D6A-7C294BF7139D"'
		'UPGRADE_ISSUE: Constant vbFromUnicode was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="55B59875-9A95-4B71-9D6A-7C294BF7139D"'
		'UPGRADE_ISSUE: MidB function is not supported. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"'
		CHECKLIST04 = StrConv(MidB(StrConv(wkstr.Value, vbFromUnicode), 1, nSize), vbUnicode)
		wkstr.Value = Space(100) : Def = "�S��"
		nSize = basMain.GetPrivateProfileString(SectionName, "CHECKLIST05", Def, wkstr.Value, Len(wkstr.Value), wkPath)
		'UPGRADE_ISSUE: Constant vbUnicode was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="55B59875-9A95-4B71-9D6A-7C294BF7139D"'
		'UPGRADE_ISSUE: Constant vbFromUnicode was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="55B59875-9A95-4B71-9D6A-7C294BF7139D"'
		'UPGRADE_ISSUE: MidB function is not supported. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"'
		CHECKLIST05 = StrConv(MidB(StrConv(wkstr.Value, vbFromUnicode), 1, nSize), vbUnicode)
		
		'���o�����󒍕񍐏�
		wkstr.Value = Space(100) : Def = "����"
		nSize = basMain.GetPrivateProfileString(SectionName, "J_HOUKOKU01", Def, wkstr.Value, Len(wkstr.Value), wkPath)
		'UPGRADE_ISSUE: Constant vbUnicode was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="55B59875-9A95-4B71-9D6A-7C294BF7139D"'
		'UPGRADE_ISSUE: Constant vbFromUnicode was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="55B59875-9A95-4B71-9D6A-7C294BF7139D"'
		'UPGRADE_ISSUE: MidB function is not supported. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"'
		J_HOUKOKU01 = StrConv(MidB(StrConv(wkstr.Value, vbFromUnicode), 1, nSize), vbUnicode)
		wkstr.Value = Space(100) : Def = "����"
		nSize = basMain.GetPrivateProfileString(SectionName, "J_HOUKOKU02", Def, wkstr.Value, Len(wkstr.Value), wkPath)
		'UPGRADE_ISSUE: Constant vbUnicode was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="55B59875-9A95-4B71-9D6A-7C294BF7139D"'
		'UPGRADE_ISSUE: Constant vbFromUnicode was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="55B59875-9A95-4B71-9D6A-7C294BF7139D"'
		'UPGRADE_ISSUE: MidB function is not supported. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"'
		J_HOUKOKU02 = StrConv(MidB(StrConv(wkstr.Value, vbFromUnicode), 1, nSize), vbUnicode)
		wkstr.Value = Space(100) : Def = "����"
		nSize = basMain.GetPrivateProfileString(SectionName, "J_HOUKOKU03", Def, wkstr.Value, Len(wkstr.Value), wkPath)
		'UPGRADE_ISSUE: Constant vbUnicode was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="55B59875-9A95-4B71-9D6A-7C294BF7139D"'
		'UPGRADE_ISSUE: Constant vbFromUnicode was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="55B59875-9A95-4B71-9D6A-7C294BF7139D"'
		'UPGRADE_ISSUE: MidB function is not supported. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"'
		J_HOUKOKU03 = StrConv(MidB(StrConv(wkstr.Value, vbFromUnicode), 1, nSize), vbUnicode)
		wkstr.Value = Space(100) : Def = "����"
		nSize = basMain.GetPrivateProfileString(SectionName, "J_HOUKOKU04", Def, wkstr.Value, Len(wkstr.Value), wkPath)
		'UPGRADE_ISSUE: Constant vbUnicode was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="55B59875-9A95-4B71-9D6A-7C294BF7139D"'
		'UPGRADE_ISSUE: Constant vbFromUnicode was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="55B59875-9A95-4B71-9D6A-7C294BF7139D"'
		'UPGRADE_ISSUE: MidB function is not supported. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"'
		J_HOUKOKU04 = StrConv(MidB(StrConv(wkstr.Value, vbFromUnicode), 1, nSize), vbUnicode)
		wkstr.Value = Space(100) : Def = "�S��"
		nSize = basMain.GetPrivateProfileString(SectionName, "J_HOUKOKU05", Def, wkstr.Value, Len(wkstr.Value), wkPath)
		'UPGRADE_ISSUE: Constant vbUnicode was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="55B59875-9A95-4B71-9D6A-7C294BF7139D"'
		'UPGRADE_ISSUE: Constant vbFromUnicode was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="55B59875-9A95-4B71-9D6A-7C294BF7139D"'
		'UPGRADE_ISSUE: MidB function is not supported. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"'
		J_HOUKOKU05 = StrConv(MidB(StrConv(wkstr.Value, vbFromUnicode), 1, nSize), vbUnicode)
		
		'���y�؁��o�����񍐏�
		wkstr.Value = Space(100) : Def = "�{����"
		nSize = basMain.GetPrivateProfileString(SectionName, "D_HOUKOKU01", Def, wkstr.Value, Len(wkstr.Value), wkPath)
		'UPGRADE_ISSUE: Constant vbUnicode was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="55B59875-9A95-4B71-9D6A-7C294BF7139D"'
		'UPGRADE_ISSUE: Constant vbFromUnicode was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="55B59875-9A95-4B71-9D6A-7C294BF7139D"'
		'UPGRADE_ISSUE: MidB function is not supported. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"'
		D_HOUKOKU01 = StrConv(MidB(StrConv(wkstr.Value, vbFromUnicode), 1, nSize), vbUnicode)
		wkstr.Value = Space(100) : Def = "�S����"
		nSize = basMain.GetPrivateProfileString(SectionName, "D_HOUKOKU02", Def, wkstr.Value, Len(wkstr.Value), wkPath)
		'UPGRADE_ISSUE: Constant vbUnicode was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="55B59875-9A95-4B71-9D6A-7C294BF7139D"'
		'UPGRADE_ISSUE: Constant vbFromUnicode was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="55B59875-9A95-4B71-9D6A-7C294BF7139D"'
		'UPGRADE_ISSUE: MidB function is not supported. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"'
		D_HOUKOKU02 = StrConv(MidB(StrConv(wkstr.Value, vbFromUnicode), 1, nSize), vbUnicode)
		wkstr.Value = Space(100) : Def = "�S����"
		nSize = basMain.GetPrivateProfileString(SectionName, "D_HOUKOKU03", Def, wkstr.Value, Len(wkstr.Value), wkPath)
		'UPGRADE_ISSUE: Constant vbUnicode was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="55B59875-9A95-4B71-9D6A-7C294BF7139D"'
		'UPGRADE_ISSUE: Constant vbFromUnicode was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="55B59875-9A95-4B71-9D6A-7C294BF7139D"'
		'UPGRADE_ISSUE: MidB function is not supported. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"'
		D_HOUKOKU03 = StrConv(MidB(StrConv(wkstr.Value, vbFromUnicode), 1, nSize), vbUnicode)
		
		'���y�؁��H������ڍ�
		wkstr.Value = Space(100) : Def = "����"
		nSize = basMain.GetPrivateProfileString(SectionName, "G_SYOUSAI01", Def, wkstr.Value, Len(wkstr.Value), wkPath)
		'UPGRADE_ISSUE: Constant vbUnicode was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="55B59875-9A95-4B71-9D6A-7C294BF7139D"'
		'UPGRADE_ISSUE: Constant vbFromUnicode was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="55B59875-9A95-4B71-9D6A-7C294BF7139D"'
		'UPGRADE_ISSUE: MidB function is not supported. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"'
		G_SYOUSAI01 = StrConv(MidB(StrConv(wkstr.Value, vbFromUnicode), 1, nSize), vbUnicode)
		wkstr.Value = Space(100) : Def = "����"
		nSize = basMain.GetPrivateProfileString(SectionName, "G_SYOUSAI02", Def, wkstr.Value, Len(wkstr.Value), wkPath)
		'UPGRADE_ISSUE: Constant vbUnicode was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="55B59875-9A95-4B71-9D6A-7C294BF7139D"'
		'UPGRADE_ISSUE: Constant vbFromUnicode was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="55B59875-9A95-4B71-9D6A-7C294BF7139D"'
		'UPGRADE_ISSUE: MidB function is not supported. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"'
		G_SYOUSAI02 = StrConv(MidB(StrConv(wkstr.Value, vbFromUnicode), 1, nSize), vbUnicode)
		wkstr.Value = Space(100) : Def = "����"
		nSize = basMain.GetPrivateProfileString(SectionName, "G_SYOUSAI03", Def, wkstr.Value, Len(wkstr.Value), wkPath)
		'UPGRADE_ISSUE: Constant vbUnicode was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="55B59875-9A95-4B71-9D6A-7C294BF7139D"'
		'UPGRADE_ISSUE: Constant vbFromUnicode was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="55B59875-9A95-4B71-9D6A-7C294BF7139D"'
		'UPGRADE_ISSUE: MidB function is not supported. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"'
		G_SYOUSAI03 = StrConv(MidB(StrConv(wkstr.Value, vbFromUnicode), 1, nSize), vbUnicode)
		wkstr.Value = Space(100) : Def = "����"
		nSize = basMain.GetPrivateProfileString(SectionName, "G_SYOUSAI04", Def, wkstr.Value, Len(wkstr.Value), wkPath)
		'UPGRADE_ISSUE: Constant vbUnicode was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="55B59875-9A95-4B71-9D6A-7C294BF7139D"'
		'UPGRADE_ISSUE: Constant vbFromUnicode was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="55B59875-9A95-4B71-9D6A-7C294BF7139D"'
		'UPGRADE_ISSUE: MidB function is not supported. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"'
		G_SYOUSAI04 = StrConv(MidB(StrConv(wkstr.Value, vbFromUnicode), 1, nSize), vbUnicode)
		wkstr.Value = Space(100) : Def = "�S��"
		nSize = basMain.GetPrivateProfileString(SectionName, "G_SYOUSAI05", Def, wkstr.Value, Len(wkstr.Value), wkPath)
		'UPGRADE_ISSUE: Constant vbUnicode was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="55B59875-9A95-4B71-9D6A-7C294BF7139D"'
		'UPGRADE_ISSUE: Constant vbFromUnicode was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="55B59875-9A95-4B71-9D6A-7C294BF7139D"'
		'UPGRADE_ISSUE: MidB function is not supported. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"'
		G_SYOUSAI05 = StrConv(MidB(StrConv(wkstr.Value, vbFromUnicode), 1, nSize), vbUnicode)
		
		'���y�؁��x���ꗗ�i�䗦�v�Z�j
		wkstr.Value = Space(100) : Def = "����"
		nSize = basMain.GetPrivateProfileString(SectionName, "HIRITU01", Def, wkstr.Value, Len(wkstr.Value), wkPath)
		'UPGRADE_ISSUE: Constant vbUnicode was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="55B59875-9A95-4B71-9D6A-7C294BF7139D"'
		'UPGRADE_ISSUE: Constant vbFromUnicode was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="55B59875-9A95-4B71-9D6A-7C294BF7139D"'
		'UPGRADE_ISSUE: MidB function is not supported. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"'
		HIRITU01 = StrConv(MidB(StrConv(wkstr.Value, vbFromUnicode), 1, nSize), vbUnicode)
		wkstr.Value = Space(100) : Def = "����"
		nSize = basMain.GetPrivateProfileString(SectionName, "HIRITU02", Def, wkstr.Value, Len(wkstr.Value), wkPath)
		'UPGRADE_ISSUE: Constant vbUnicode was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="55B59875-9A95-4B71-9D6A-7C294BF7139D"'
		'UPGRADE_ISSUE: Constant vbFromUnicode was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="55B59875-9A95-4B71-9D6A-7C294BF7139D"'
		'UPGRADE_ISSUE: MidB function is not supported. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"'
		HIRITU02 = StrConv(MidB(StrConv(wkstr.Value, vbFromUnicode), 1, nSize), vbUnicode)
		wkstr.Value = Space(100) : Def = "����"
		nSize = basMain.GetPrivateProfileString(SectionName, "HIRITU03", Def, wkstr.Value, Len(wkstr.Value), wkPath)
		'UPGRADE_ISSUE: Constant vbUnicode was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="55B59875-9A95-4B71-9D6A-7C294BF7139D"'
		'UPGRADE_ISSUE: Constant vbFromUnicode was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="55B59875-9A95-4B71-9D6A-7C294BF7139D"'
		'UPGRADE_ISSUE: MidB function is not supported. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"'
		HIRITU03 = StrConv(MidB(StrConv(wkstr.Value, vbFromUnicode), 1, nSize), vbUnicode)
		wkstr.Value = Space(100) : Def = "����"
		nSize = basMain.GetPrivateProfileString(SectionName, "HIRITU04", Def, wkstr.Value, Len(wkstr.Value), wkPath)
		'UPGRADE_ISSUE: Constant vbUnicode was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="55B59875-9A95-4B71-9D6A-7C294BF7139D"'
		'UPGRADE_ISSUE: Constant vbFromUnicode was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="55B59875-9A95-4B71-9D6A-7C294BF7139D"'
		'UPGRADE_ISSUE: MidB function is not supported. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"'
		HIRITU04 = StrConv(MidB(StrConv(wkstr.Value, vbFromUnicode), 1, nSize), vbUnicode)
		wkstr.Value = Space(100) : Def = "�S��"
		nSize = basMain.GetPrivateProfileString(SectionName, "HIRITU05", Def, wkstr.Value, Len(wkstr.Value), wkPath)
		'UPGRADE_ISSUE: Constant vbUnicode was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="55B59875-9A95-4B71-9D6A-7C294BF7139D"'
		'UPGRADE_ISSUE: Constant vbFromUnicode was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="55B59875-9A95-4B71-9D6A-7C294BF7139D"'
		'UPGRADE_ISSUE: MidB function is not supported. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"'
		HIRITU05 = StrConv(MidB(StrConv(wkstr.Value, vbFromUnicode), 1, nSize), vbUnicode)
		
		'���y�؁��H������
		'�����z���H������
		wkstr.Value = Space(100) : Def = "�Ё@��"
		nSize = basMain.GetPrivateProfileString(SectionName, "GEPPOU01", Def, wkstr.Value, Len(wkstr.Value), wkPath)
		'UPGRADE_ISSUE: Constant vbUnicode was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="55B59875-9A95-4B71-9D6A-7C294BF7139D"'
		'UPGRADE_ISSUE: Constant vbFromUnicode was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="55B59875-9A95-4B71-9D6A-7C294BF7139D"'
		'UPGRADE_ISSUE: MidB function is not supported. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"'
		GEPPOU01 = StrConv(MidB(StrConv(wkstr.Value, vbFromUnicode), 1, nSize), vbUnicode)
		wkstr.Value = Space(100) : Def = "�{����"
		nSize = basMain.GetPrivateProfileString(SectionName, "GEPPOU02", Def, wkstr.Value, Len(wkstr.Value), wkPath)
		'UPGRADE_ISSUE: Constant vbUnicode was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="55B59875-9A95-4B71-9D6A-7C294BF7139D"'
		'UPGRADE_ISSUE: Constant vbFromUnicode was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="55B59875-9A95-4B71-9D6A-7C294BF7139D"'
		'UPGRADE_ISSUE: MidB function is not supported. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"'
		GEPPOU02 = StrConv(MidB(StrConv(wkstr.Value, vbFromUnicode), 1, nSize), vbUnicode)
		wkstr.Value = Space(100) : Def = "���@��"
		nSize = basMain.GetPrivateProfileString(SectionName, "GEPPOU03", Def, wkstr.Value, Len(wkstr.Value), wkPath)
		'UPGRADE_ISSUE: Constant vbUnicode was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="55B59875-9A95-4B71-9D6A-7C294BF7139D"'
		'UPGRADE_ISSUE: Constant vbFromUnicode was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="55B59875-9A95-4B71-9D6A-7C294BF7139D"'
		'UPGRADE_ISSUE: MidB function is not supported. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"'
		GEPPOU03 = StrConv(MidB(StrConv(wkstr.Value, vbFromUnicode), 1, nSize), vbUnicode)
		wkstr.Value = Space(100) : Def = "���@��"
		nSize = basMain.GetPrivateProfileString(SectionName, "GEPPOU04", Def, wkstr.Value, Len(wkstr.Value), wkPath)
		'UPGRADE_ISSUE: Constant vbUnicode was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="55B59875-9A95-4B71-9D6A-7C294BF7139D"'
		'UPGRADE_ISSUE: Constant vbFromUnicode was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="55B59875-9A95-4B71-9D6A-7C294BF7139D"'
		'UPGRADE_ISSUE: MidB function is not supported. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"'
		GEPPOU04 = StrConv(MidB(StrConv(wkstr.Value, vbFromUnicode), 1, nSize), vbUnicode)
		wkstr.Value = Space(100) : Def = "���@��"
		nSize = basMain.GetPrivateProfileString(SectionName, "GEPPOU05", Def, wkstr.Value, Len(wkstr.Value), wkPath)
		'UPGRADE_ISSUE: Constant vbUnicode was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="55B59875-9A95-4B71-9D6A-7C294BF7139D"'
		'UPGRADE_ISSUE: Constant vbFromUnicode was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="55B59875-9A95-4B71-9D6A-7C294BF7139D"'
		'UPGRADE_ISSUE: MidB function is not supported. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"'
		GEPPOU05 = StrConv(MidB(StrConv(wkstr.Value, vbFromUnicode), 1, nSize), vbUnicode)
		wkstr.Value = Space(100) : Def = "���@��"
		nSize = basMain.GetPrivateProfileString(SectionName, "GEPPOU06", Def, wkstr.Value, Len(wkstr.Value), wkPath)
		'UPGRADE_ISSUE: Constant vbUnicode was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="55B59875-9A95-4B71-9D6A-7C294BF7139D"'
		'UPGRADE_ISSUE: Constant vbFromUnicode was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="55B59875-9A95-4B71-9D6A-7C294BF7139D"'
		'UPGRADE_ISSUE: MidB function is not supported. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"'
		GEPPOU06 = StrConv(MidB(StrConv(wkstr.Value, vbFromUnicode), 1, nSize), vbUnicode)
		wkstr.Value = Space(100) : Def = "���@��"
		nSize = basMain.GetPrivateProfileString(SectionName, "GEPPOU07", Def, wkstr.Value, Len(wkstr.Value), wkPath)
		'UPGRADE_ISSUE: Constant vbUnicode was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="55B59875-9A95-4B71-9D6A-7C294BF7139D"'
		'UPGRADE_ISSUE: Constant vbFromUnicode was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="55B59875-9A95-4B71-9D6A-7C294BF7139D"'
		'UPGRADE_ISSUE: MidB function is not supported. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"'
		GEPPOU07 = StrConv(MidB(StrConv(wkstr.Value, vbFromUnicode), 1, nSize), vbUnicode)
		wkstr.Value = Space(100) : Def = "�S�@��"
		nSize = basMain.GetPrivateProfileString(SectionName, "GEPPOU08", Def, wkstr.Value, Len(wkstr.Value), wkPath)
		'UPGRADE_ISSUE: Constant vbUnicode was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="55B59875-9A95-4B71-9D6A-7C294BF7139D"'
		'UPGRADE_ISSUE: Constant vbFromUnicode was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="55B59875-9A95-4B71-9D6A-7C294BF7139D"'
		'UPGRADE_ISSUE: MidB function is not supported. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"'
		GEPPOU08 = StrConv(MidB(StrConv(wkstr.Value, vbFromUnicode), 1, nSize), vbUnicode)
		
		'�����z�����s�\�Z���F�ꗗ
		wkstr.Value = Space(100) : Def = "����"
		nSize = basMain.GetPrivateProfileString(SectionName, "J_YOSAN01", Def, wkstr.Value, Len(wkstr.Value), wkPath)
		'UPGRADE_ISSUE: Constant vbUnicode was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="55B59875-9A95-4B71-9D6A-7C294BF7139D"'
		'UPGRADE_ISSUE: Constant vbFromUnicode was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="55B59875-9A95-4B71-9D6A-7C294BF7139D"'
		'UPGRADE_ISSUE: MidB function is not supported. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"'
		J_YOSAN01 = StrConv(MidB(StrConv(wkstr.Value, vbFromUnicode), 1, nSize), vbUnicode)
		wkstr.Value = Space(100) : Def = "����"
		nSize = basMain.GetPrivateProfileString(SectionName, "J_YOSAN02", Def, wkstr.Value, Len(wkstr.Value), wkPath)
		'UPGRADE_ISSUE: Constant vbUnicode was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="55B59875-9A95-4B71-9D6A-7C294BF7139D"'
		'UPGRADE_ISSUE: Constant vbFromUnicode was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="55B59875-9A95-4B71-9D6A-7C294BF7139D"'
		'UPGRADE_ISSUE: MidB function is not supported. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"'
		J_YOSAN02 = StrConv(MidB(StrConv(wkstr.Value, vbFromUnicode), 1, nSize), vbUnicode)
		wkstr.Value = Space(100) : Def = "����"
		nSize = basMain.GetPrivateProfileString(SectionName, "J_YOSAN03", Def, wkstr.Value, Len(wkstr.Value), wkPath)
		'UPGRADE_ISSUE: Constant vbUnicode was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="55B59875-9A95-4B71-9D6A-7C294BF7139D"'
		'UPGRADE_ISSUE: Constant vbFromUnicode was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="55B59875-9A95-4B71-9D6A-7C294BF7139D"'
		'UPGRADE_ISSUE: MidB function is not supported. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"'
		J_YOSAN03 = StrConv(MidB(StrConv(wkstr.Value, vbFromUnicode), 1, nSize), vbUnicode)
		wkstr.Value = Space(100) : Def = "����"
		nSize = basMain.GetPrivateProfileString(SectionName, "J_YOSAN04", Def, wkstr.Value, Len(wkstr.Value), wkPath)
		'UPGRADE_ISSUE: Constant vbUnicode was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="55B59875-9A95-4B71-9D6A-7C294BF7139D"'
		'UPGRADE_ISSUE: Constant vbFromUnicode was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="55B59875-9A95-4B71-9D6A-7C294BF7139D"'
		'UPGRADE_ISSUE: MidB function is not supported. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"'
		J_YOSAN04 = StrConv(MidB(StrConv(wkstr.Value, vbFromUnicode), 1, nSize), vbUnicode)
		wkstr.Value = Space(100) : Def = "�S��"
		nSize = basMain.GetPrivateProfileString(SectionName, "J_YOSAN05", Def, wkstr.Value, Len(wkstr.Value), wkPath)
		'UPGRADE_ISSUE: Constant vbUnicode was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="55B59875-9A95-4B71-9D6A-7C294BF7139D"'
		'UPGRADE_ISSUE: Constant vbFromUnicode was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="55B59875-9A95-4B71-9D6A-7C294BF7139D"'
		'UPGRADE_ISSUE: MidB function is not supported. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"'
		J_YOSAN05 = StrConv(MidB(StrConv(wkstr.Value, vbFromUnicode), 1, nSize), vbUnicode)
		
		'����p�C�j�V�����t�@�C���������ꍇ���l�����ăt�@�C�����쐬����
		wkstr.Value = Space(100) : SetPath = CHECKLIST01
		nSize = basMain.WritePrivateProfileString(SectionName, "CHECKLIST01", SetPath, wkPath)
		wkstr.Value = Space(100) : SetPath = CHECKLIST02
		nSize = basMain.WritePrivateProfileString(SectionName, "CHECKLIST02", SetPath, wkPath)
		wkstr.Value = Space(100) : SetPath = CHECKLIST03
		nSize = basMain.WritePrivateProfileString(SectionName, "CHECKLIST03", SetPath, wkPath)
		wkstr.Value = Space(100) : SetPath = CHECKLIST04
		nSize = basMain.WritePrivateProfileString(SectionName, "CHECKLIST04", SetPath, wkPath)
		wkstr.Value = Space(100) : SetPath = CHECKLIST05
		nSize = basMain.WritePrivateProfileString(SectionName, "CHECKLIST05", SetPath, wkPath)
		wkstr.Value = Space(100) : SetPath = J_HOUKOKU01
		nSize = basMain.WritePrivateProfileString(SectionName, "J_HOUKOKU01", SetPath, wkPath)
		wkstr.Value = Space(100) : SetPath = J_HOUKOKU02
		nSize = basMain.WritePrivateProfileString(SectionName, "J_HOUKOKU02", SetPath, wkPath)
		wkstr.Value = Space(100) : SetPath = J_HOUKOKU03
		nSize = basMain.WritePrivateProfileString(SectionName, "J_HOUKOKU03", SetPath, wkPath)
		wkstr.Value = Space(100) : SetPath = J_HOUKOKU04
		nSize = basMain.WritePrivateProfileString(SectionName, "J_HOUKOKU04", SetPath, wkPath)
		wkstr.Value = Space(100) : SetPath = J_HOUKOKU05
		nSize = basMain.WritePrivateProfileString(SectionName, "J_HOUKOKU05", SetPath, wkPath)
		wkstr.Value = Space(100) : SetPath = D_HOUKOKU01
		nSize = basMain.WritePrivateProfileString(SectionName, "D_HOUKOKU01", SetPath, wkPath)
		wkstr.Value = Space(100) : SetPath = D_HOUKOKU02
		nSize = basMain.WritePrivateProfileString(SectionName, "D_HOUKOKU02", SetPath, wkPath)
		wkstr.Value = Space(100) : SetPath = D_HOUKOKU03
		nSize = basMain.WritePrivateProfileString(SectionName, "D_HOUKOKU03", SetPath, wkPath)
		wkstr.Value = Space(100) : SetPath = G_SYOUSAI01
		nSize = basMain.WritePrivateProfileString(SectionName, "G_SYOUSAI01", SetPath, wkPath)
		wkstr.Value = Space(100) : SetPath = G_SYOUSAI02
		nSize = basMain.WritePrivateProfileString(SectionName, "G_SYOUSAI02", SetPath, wkPath)
		wkstr.Value = Space(100) : SetPath = G_SYOUSAI03
		nSize = basMain.WritePrivateProfileString(SectionName, "G_SYOUSAI03", SetPath, wkPath)
		wkstr.Value = Space(100) : SetPath = G_SYOUSAI04
		nSize = basMain.WritePrivateProfileString(SectionName, "G_SYOUSAI04", SetPath, wkPath)
		wkstr.Value = Space(100) : SetPath = G_SYOUSAI05
		nSize = basMain.WritePrivateProfileString(SectionName, "G_SYOUSAI05", SetPath, wkPath)
		wkstr.Value = Space(100) : SetPath = HIRITU01
		nSize = basMain.WritePrivateProfileString(SectionName, "HIRITU01", SetPath, wkPath)
		wkstr.Value = Space(100) : SetPath = HIRITU02
		nSize = basMain.WritePrivateProfileString(SectionName, "HIRITU02", SetPath, wkPath)
		wkstr.Value = Space(100) : SetPath = HIRITU03
		nSize = basMain.WritePrivateProfileString(SectionName, "HIRITU03", SetPath, wkPath)
		wkstr.Value = Space(100) : SetPath = HIRITU04
		nSize = basMain.WritePrivateProfileString(SectionName, "HIRITU04", SetPath, wkPath)
		wkstr.Value = Space(100) : SetPath = HIRITU05
		nSize = basMain.WritePrivateProfileString(SectionName, "HIRITU05", SetPath, wkPath)
		wkstr.Value = Space(100) : SetPath = GEPPOU01
		nSize = basMain.WritePrivateProfileString(SectionName, "GEPPOU01", SetPath, wkPath)
		wkstr.Value = Space(100) : SetPath = GEPPOU02
		nSize = basMain.WritePrivateProfileString(SectionName, "GEPPOU02", SetPath, wkPath)
		wkstr.Value = Space(100) : SetPath = GEPPOU03
		nSize = basMain.WritePrivateProfileString(SectionName, "GEPPOU03", SetPath, wkPath)
		wkstr.Value = Space(100) : SetPath = GEPPOU04
		nSize = basMain.WritePrivateProfileString(SectionName, "GEPPOU04", SetPath, wkPath)
		wkstr.Value = Space(100) : SetPath = GEPPOU05
		nSize = basMain.WritePrivateProfileString(SectionName, "GEPPOU05", SetPath, wkPath)
		wkstr.Value = Space(100) : SetPath = GEPPOU06
		nSize = basMain.WritePrivateProfileString(SectionName, "GEPPOU06", SetPath, wkPath)
		wkstr.Value = Space(100) : SetPath = GEPPOU07
		nSize = basMain.WritePrivateProfileString(SectionName, "GEPPOU07", SetPath, wkPath)
		wkstr.Value = Space(100) : SetPath = GEPPOU08
		nSize = basMain.WritePrivateProfileString(SectionName, "GEPPOU08", SetPath, wkPath)
		wkstr.Value = Space(100) : SetPath = J_YOSAN01
		nSize = basMain.WritePrivateProfileString(SectionName, "J_YOSAN01", SetPath, wkPath)
		wkstr.Value = Space(100) : SetPath = J_YOSAN02
		nSize = basMain.WritePrivateProfileString(SectionName, "J_YOSAN02", SetPath, wkPath)
		wkstr.Value = Space(100) : SetPath = J_YOSAN03
		nSize = basMain.WritePrivateProfileString(SectionName, "J_YOSAN03", SetPath, wkPath)
		wkstr.Value = Space(100) : SetPath = J_YOSAN04
		nSize = basMain.WritePrivateProfileString(SectionName, "J_YOSAN04", SetPath, wkPath)
		wkstr.Value = Space(100) : SetPath = J_YOSAN05
		nSize = basMain.WritePrivateProfileString(SectionName, "J_YOSAN05", SetPath, wkPath)
		
	End Sub
End Module