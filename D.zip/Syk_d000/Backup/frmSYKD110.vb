Option Strict Off
Option Explicit On
Imports VB = Microsoft.VisualBasic
Friend Class frmSYKD110
	Inherits System.Windows.Forms.Form
	'=============================================================
	' ���[�U�[���@  �F  �R�z�H�Ɗ������
	' �V�X�e�����@  �F  �H���Ǘ��V�X�e��
	' ���W���[����  �F  �O���o��������
	' ���W���[��ID�@�F  frmSYKD110.frm
	' �쐬���@ �@�@ �F  ���� 13 �N 07 �� 19 ��
	' �X�V���@�@  �@�F  ����    �N    ��    ��
	'=============================================================
	'
	
	Private Const RowHeight As Short = 11
	
	Public ChumonID As String '�����ԍ�
	Public GyosyaID As String '�Ǝк���
	Public HenkouFG As String '�ύX�׸�
	
	Public UpdateFG As String '�X�V�׸�
	'
	
	'-------------------------------------------------------------------------------
	'   ����    :   �f�[�^�̃N���A
	'   �֐�    :   Sub DispClear()
	'   ����    :   �Ȃ�
	'   �@�\    :   �f�[�^���N���A���܂��B
	'-------------------------------------------------------------------------------
	Private Sub DispClear(Optional ByRef Mode As Short = 0)
		
		If Mode = 1 Then
			With KeyKouji
				'----- �H�����
				imText2(0).Text = .KOUJI_NO
				If .EDA_NO = "0000" Then
					imText2(1).Text = ""
				Else
					imText2(1).Text = .EDA_NO
				End If
				imText2(2).Text = .MEISYOU
				'----- ���N��
				imText1(0).Text = VB6.Format(CtlKouji.SYORI_YM, "0000/00")
				'----- �����ԍ�
				imText1(1).Text = Trim(ChumonID)
				imText1(2).Text = GetNameWaridasi(.KOUJI_NO, .EDA_NO, ChumonID)
				'----- �Ǝ�
				imText1(3).Text = GyosyaID
				imText1(4).Text = GetNameGyousya(GyosyaID)
			End With
		End If
		
		vaSpread1.MaxRows = 0 '�\
		Call SpAllClear(vaSpread2)
		
		'----- �Q�ƃ��[�h
		If INPMODE <> "2" Then
			cmdKey(2).Text = "  F2  �� ��"
			cmdKey(2).Tag = "�I���f�[�^�̏ڍׂ�\�����܂��B"
		End If
		
	End Sub
	
	'-------------------------------------------------------------------------------
	'   ����   :   DEKIDAKA_DATA �ǂݍ��ݏ���
	'   �֐�   :   Function SelectDekidaka()
	'   ����   :   WA()�@   WARIDASI_DATA_DBT
	'   �@�@       DE()�@   DEKIDAKA_DATA_DBT
	'   �ߒl   :   �ް���   ����I��
	'   �@�@       -1�@     �ُ�I��
	'   �@�\   :   DEKIDAKA_DATA SELECT����
	'-------------------------------------------------------------------------------
	Private Function SelectDekidaka(ByRef WA() As WARIDASI_DATA_DBT, ByRef DE() As DEKIDAKA_DATA_DBT) As Integer
		
		Dim QRY1 As String
		Dim QRY2 As String
		Dim SQL As String
		Dim Rs As ADODB.Recordset
		Dim Fld As ADODB.Field
		Dim Cnt As Integer
		Dim OpenFlg As Short
		
		On Error GoTo SelectDekidaka_Err
		
		'�߂�l�̏�����
		SelectDekidaka = -1
		
		'QRY/SELECT���g��
		QRY1 = "(SELECT * FROM WARIDASI_DATA"
		QRY1 = QRY1 & " WHERE EDA_NO = '" & KeyKouji.EDA_NO & "'"
		QRY1 = QRY1 & " AND KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"
		QRY1 = QRY1 & " AND WARIDASI_NO = '" & Trim(ChumonID) & "'"
		QRY1 = QRY1 & ") AS WARIDASI"
		
		'QRY/SELECT���g��
		QRY2 = "(SELECT * FROM DEKIDAKA_DATA"
		QRY2 = QRY2 & " WHERE EDA_NO = '" & KeyKouji.EDA_NO & "'"
		QRY2 = QRY2 & " AND KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"
		QRY2 = QRY2 & " AND SIME_YM = '" & CtlKouji.SYORI_YM & "'"
		QRY2 = QRY2 & ") AS DEKIDAKA"
		
		'SQL/SELECT���g��
		SQL = "SELECT"
		SQL = SQL & " WARIDASI.KOUSYU_CD    AS F01," '�H������
		SQL = SQL & " WARIDASI.KOUSYU_NO    AS F02," '�H��ԍ�
		SQL = SQL & " WARIDASI.MEISAI_NO    AS F03," '���הԍ�
		SQL = SQL & " WARIDASI.MEISYOU      AS F04," '����
		SQL = SQL & " WARIDASI.TANI         AS F05," '�P��
		SQL = SQL & " WARIDASI.G_SUURYOU    AS F06," '���ʁi�O���j
		SQL = SQL & " WARIDASI.G_TANKA      AS F07," '�P���i�O���j
		SQL = SQL & " WARIDASI.G_KINGAKU    AS F08," '���z�i�O���j
		SQL = SQL & " DEKIDAKA.*"
		SQL = SQL & " FROM " & QRY1 & " LEFT JOIN " & QRY2
		SQL = SQL & " ON  (WARIDASI.MEISAI_NO = DEKIDAKA.MEISAI_NO)"
		SQL = SQL & " AND (WARIDASI.KOUSYU_NO = DEKIDAKA.KOUSYU_NO)"
		SQL = SQL & " AND (WARIDASI.KOUSYU_CD = DEKIDAKA.KOUSYU_CD)"
		SQL = SQL & " AND (WARIDASI.EDA_NO    = DEKIDAKA.EDA_NO)"
		SQL = SQL & " AND (WARIDASI.KOUJI_NO  = DEKIDAKA.KOUJI_NO)"
		SQL = SQL & " ORDER BY WARIDASI.KOUSYU_CD, WARIDASI.KOUSYU_NO, WARIDASI.MEISAI_NO"
		
		'SQL�����s
		Rs = SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText)
		OpenFlg = 1
		
		Cnt = 0
		Do Until Rs.EOF
			ReDim Preserve WA(Cnt)
			Call CLEAR_WARIDASI_DATA(WA(Cnt))
			With WA(Cnt)
				.KOUJI_NO = KeyKouji.KOUJI_NO '�H���ԍ�
				.EDA_NO = KeyKouji.EDA_NO '�H���}��
				'UPGRADE_WARNING: Couldn't resolve default property of object RsNull(). Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				.KOUSYU_CD = RsNull(Rs, "F01") '�H������
				'UPGRADE_WARNING: Couldn't resolve default property of object RsNull(). Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				.KOUSYU_NO = RsNull(Rs, "F02") '�H��ԍ�
				.MEISAI_NO = CDbl2(RsNull(Rs, "F03")) '���הԍ�
				'UPGRADE_WARNING: Couldn't resolve default property of object RsNull(). Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				.MEISYOU = RsNull(Rs, "F04") '����
				'UPGRADE_WARNING: Couldn't resolve default property of object RsNull(). Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				.TANI = RsNull(Rs, "F05") '�P��
				.WARIDASI_NO = Trim(ChumonID) '���o�ԍ�
				.G_SUURYOU = CCur2(RsNull(Rs, "F06")) '���ʁi�O���j
				.G_TANKA = CCur2(RsNull(Rs, "F07")) '�P���i�O���j
				.G_KINGAKU = CCur2(RsNull(Rs, "F08")) '���z�i�O���j
			End With
			ReDim Preserve DE(Cnt)
			Call DATSET_DEKIDAKA_DATA(Rs, DE(Cnt))
			'----- �o�����f�[�^���Ȃ��ꍇ
			If Trim(DE(Cnt).KOUJI_NO) = "" Then
				With DE(Cnt)
					.KOUJI_NO = WA(Cnt).KOUJI_NO '�H���ԍ�
					.EDA_NO = WA(Cnt).EDA_NO '�H���}��
					.KOUSYU_CD = WA(Cnt).KOUSYU_CD '�H������
					.KOUSYU_NO = WA(Cnt).KOUSYU_NO '�H��ԍ�
					.SIME_YM = CtlKouji.SYORI_YM '���N��
					.MEISAI_NO = WA(Cnt).MEISAI_NO '���הԍ�
					.HENKOU_SUU = WA(Cnt).G_SUURYOU '�ύX�㐔��
					.ZOUGEN_GAKU = WA(Cnt).G_KINGAKU '�ύX���� 2003/04/21 �ǉ�
				End With
				'----- �ύX����̏ꍇ
				If HenkouFG = "1" Then
					' �o�����f�[�^�̒ǉ�
					If INSERT_DEKIDAKA_DATA(DE(Cnt)) = False Then
						Rs.Close()
						'UPGRADE_NOTE: Object Rs may not be destroyed until it is garbage collected. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"'
						Rs = Nothing
						Exit Function
					End If
				End If
			End If
			Cnt = Cnt + 1
			Rs.MoveNext()
		Loop 
		
		Rs.Close()
		'UPGRADE_NOTE: Object Rs may not be destroyed until it is garbage collected. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"'
		Rs = Nothing
		
		'�߂�l�̃Z�b�g
		SelectDekidaka = Cnt
		Exit Function
		
SelectDekidaka_Err: 
		
		If OpenFlg = 1 Then
			Rs.Close()
		End If
		'UPGRADE_NOTE: Object Rs may not be destroyed until it is garbage collected. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"'
		Rs = Nothing
		
		Call Sql_Error_Msg("DEKIDAKA_DATA SELECT")
		
	End Function
	
	'-------------------------------------------------------------------------------
	'   ����   :   �������̍폜
	'   �֐�   :   Function DeleteMikomi()
	'   ����   :   Cnt      �f�[�^����
	'   �@�@       DT()     DEKIDAKA_DATA_DBT
	'   �ߒl   :   True     ����I��
	'   �@�@       False    �ُ�I��
	'   �@�\   :   �������̍폜���s���܂��B
	'-------------------------------------------------------------------------------
	Private Function DeleteMikomi(ByRef Cnt As Integer, ByRef DT() As DEKIDAKA_DATA_DBT) As Boolean
		
		Dim lp As Integer
		Dim Jouken As String
		
		' �߂�l�̏�����
		DeleteMikomi = False
		
		For lp = 0 To Cnt - 1
			'----- WHERE���̑g��
			With DT(lp)
				Jouken = "MEISAI_NO = " & VB6.Format(.MEISAI_NO)
				Jouken = Jouken & " AND KOUSYU_NO = '" & .KOUSYU_NO & "'"
				Jouken = Jouken & " AND KOUSYU_CD = '" & .KOUSYU_CD & "'"
				Jouken = Jouken & " AND SIME_YM = '" & .SIME_YM & "'"
				Jouken = Jouken & " AND EDA_NO = '" & .EDA_NO & "'"
				Jouken = Jouken & " AND KOUJI_NO = '" & .KOUJI_NO & "'"
			End With
			'----- �폜����
			If DELETE_MIKOMI_DATA(Jouken) = False Then
				Exit Function
			End If
		Next lp
		
		' ����I��
		DeleteMikomi = True
		
	End Function
	
	'-------------------------------------------------------------------------------
	'   ����    :   �f�[�^�̎擾
	'   �֐�    :   Sub ListDataDisp()
	'   ����    :   Mode    0 = MsgBox�\��
	'   �@�\    :   �f�[�^�̎擾���s���܂��B
	'-------------------------------------------------------------------------------
	Public Sub ListDataDisp(Optional ByRef Mode As Short = 0)
		
		Dim Cnt As Integer
		Dim WA() As WARIDASI_DATA_DBT
		Dim DE() As DEKIDAKA_DATA_DBT
		Dim wkBuf As String
		
		' �J�[�\���������v��
		'UPGRADE_WARNING: Screen property Screen.MousePointer has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6BA9B8D2-2A32-4B6E-8D36-44949974A5B4"'
		System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
		wkBuf = StatusBar1.Items.Item("Message").Text
		StatusBar1.Items.Item("Message").Text = "�Y���f�[�^�������E�E�E"
		
		' �e�[�u���̓Ǎ���
		Cnt = SelectDekidaka(WA, DE)
		If Cnt <= 0 Then
			vaSpread1.MaxRows = 0
			If Cnt = 0 Then UpdateFG = "1" '�X�V�t���O
			cmdKey(2).Enabled = False '�C���{�^��
			StatusBar1.Items.Item("Message").Text = wkBuf
			'UPGRADE_WARNING: Screen property Screen.MousePointer has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6BA9B8D2-2A32-4B6E-8D36-44949974A5B4"'
			System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
			Exit Sub
		End If
		'----- �ύX����̏ꍇ
		If HenkouFG = "1" Then
			' �����f�[�^�̍폜
			If DeleteMikomi(Cnt, DE) = False Then
				vaSpread1.MaxRows = 0
				cmdKey(2).Enabled = False '�C���{�^��
				StatusBar1.Items.Item("Message").Text = wkBuf
				'UPGRADE_WARNING: Screen property Screen.MousePointer has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6BA9B8D2-2A32-4B6E-8D36-44949974A5B4"'
				System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
				Exit Sub
			End If
		End If
		
		' �X�v���b�h�ɕ\��
		Call SprdDataSet(Cnt, WA, DE)
		
		StatusBar1.Items.Item("Message").Text = wkBuf
		'UPGRADE_WARNING: Screen property Screen.MousePointer has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6BA9B8D2-2A32-4B6E-8D36-44949974A5B4"'
		System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
		
	End Sub
	
	'-------------------------------------------------------------------------------
	'   ����    :   �X�v���b�h�\��
	'   �֐�    :   Sub SprdDataSet(DT())
	'   ����    :   Cnt     �f�[�^����
	'   �@�@        WA()    WARIDASI_DATA_DBT
	'   �@�@        DE()    DEKIDAKA_DATA_DBT
	'   �@�\    :   �f�[�^���X�v���b�h�ɕ\�����܂��B
	'-------------------------------------------------------------------------------
	Private Sub SprdDataSet(ByRef Cnt As Integer, ByRef WA() As WARIDASI_DATA_DBT, ByRef DE() As DEKIDAKA_DATA_DBT)
		
		Dim lp As Integer
		Dim Row As Integer
		Dim ssText As Object
		Dim wkVal() As Decimal
		
		With vaSpread1
			If Me.Visible = True Then
				.ReDraw = False
			End If
			.MaxRows = Cnt
			.Col = 1 : .Col2 = .MaxCols
			.Row = 1 : .Row2 = .MaxRows
			.BlockMode = True
			.Font = VB6.FontChangeBold(.Font, False)
			.Action = FPSpread.ActionConstants.ActionClearText
			.BlockMode = False
			ReDim wkVal(6)
			For lp = 0 To Cnt - 1
				.set_RowHeight(lp + 1, RowHeight)
				Row = lp + 1
				'----- �H��
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				ssText = Trim(WA(lp).KOUSYU_CD) & "-" & Trim(WA(lp).KOUSYU_NO)
				.SetText(1, Row, ssText)
				'----- ����
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				ssText = Trim(WA(lp).MEISYOU)
				.SetText(2, Row, ssText)
				'----- ����
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				ssText = VB6.Format(WA(lp).G_SUURYOU, "#,###.##")
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				If VB.Right(ssText, 1) = "." Then ssText = VB.Left(ssText, Len(ssText) - 1)
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				If VB.Left(ssText, 1) = "." Then ssText = "0" & ssText
				.SetText(3, Row, ssText)
				'----- �P��
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				ssText = Trim(WA(lp).TANI)
				.SetText(4, Row, ssText)
				'----- �P��
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				ssText = VB6.Format(WA(lp).G_TANKA, "#,###")
				.SetText(5, Row, ssText)
				'----- ���z
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				ssText = VB6.Format(WA(lp).G_KINGAKU, "#,##0")
				.SetText(6, Row, ssText)
				'----- �ύX�㐔��
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				ssText = VB6.Format(DE(lp).HENKOU_SUU, "#,###.##")
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				If VB.Right(ssText, 1) = "." Then ssText = VB.Left(ssText, Len(ssText) - 1)
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				If VB.Left(ssText, 1) = "." Then ssText = "0" & ssText
				.SetText(7, Row, ssText)
				'----- ���ѐ���
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				ssText = VB6.Format(DE(lp).JITU_SUU, "#,###.##")
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				If VB.Right(ssText, 1) = "." Then ssText = VB.Left(ssText, Len(ssText) - 1)
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				If VB.Left(ssText, 1) = "." Then ssText = "0" & ssText
				.SetText(8, Row, ssText)
				'----- ���ы��z
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				ssText = VB6.Format(DE(lp).JITU_GAKU, "#,##0")
				.SetText(9, Row, ssText)
				'----- �ݐϐ���
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				ssText = VB6.Format(DE(lp).JITU_SUU + DE(lp).RUI_SUU, "#,###.##")
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				If VB.Right(ssText, 1) = "." Then ssText = VB.Left(ssText, Len(ssText) - 1)
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				If VB.Left(ssText, 1) = "." Then ssText = "0" & ssText
				.SetText(10, Row, ssText)
				'----- �ݐϋ��z
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				ssText = VB6.Format(DE(lp).JITU_GAKU + DE(lp).RUI_GAKU, "#,##0")
				.SetText(11, Row, ssText)
				'----- ���㏊�v��������
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				ssText = VB6.Format(DE(lp).KONGO_SUU, "#,###.##")
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				If VB.Right(ssText, 1) = "." Then ssText = VB.Left(ssText, Len(ssText) - 1)
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				If VB.Left(ssText, 1) = "." Then ssText = "0" & ssText
				.SetText(12, Row, ssText)
				'----- ���㏊�v�������z
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				ssText = VB6.Format(DE(lp).KONGO_GAKU, "#,##0")
				.SetText(13, Row, ssText)
				'----- ���{��������
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				ssText = VB6.Format(DE(lp).JISSI_SUU, "#,###.##")
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				If VB.Right(ssText, 1) = "." Then ssText = VB.Left(ssText, Len(ssText) - 1)
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				If VB.Left(ssText, 1) = "." Then ssText = "0" & ssText
				.SetText(14, Row, ssText)
				'----- ���{�������z
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				ssText = VB6.Format(DE(lp).JISSI_GAKU, "#,##0")
				.SetText(15, Row, ssText)
				'----- �\�Z�Δ�
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				ssText = VB6.Format(DE(lp).TAIHI_GAKU, "#,##0")
				.SetText(16, Row, ssText)
				'----- �ύX����
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				ssText = VB6.Format(DE(lp).ZOUGEN_GAKU, "#,##0")
				.SetText(17, Row, ssText)
				'----- ���הԍ�
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				ssText = VB6.Format(WA(lp).MEISAI_NO)
				.SetText(18, Row, ssText)
				'----- �W�v
				wkVal(0) = wkVal(0) + WA(lp).G_KINGAKU
				wkVal(1) = wkVal(1) + DE(lp).JITU_GAKU
				wkVal(2) = wkVal(2) + DE(lp).JITU_GAKU + DE(lp).RUI_GAKU
				wkVal(3) = wkVal(3) + DE(lp).KONGO_GAKU
				wkVal(4) = wkVal(4) + DE(lp).JISSI_GAKU
				wkVal(5) = wkVal(5) + DE(lp).TAIHI_GAKU
				wkVal(6) = wkVal(6) + DE(lp).ZOUGEN_GAKU
			Next lp
			If Me.Visible = True Then
				'UPGRADE_NOTE: Refresh was upgraded to CtlRefresh. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="A9E4979A-37FA-4718-9994-97DD76ED70A7"'
				.CtlRefresh()
				.ReDraw = True
			End If
		End With
		
		'----- ���v���z
		With vaSpread2
			If Me.Visible = True Then
				.ReDraw = False
			End If
			.Col = 1 : .Col2 = .MaxCols
			.Row = 1 : .Row2 = .MaxRows
			.BlockMode = True
			.Font = VB6.FontChangeBold(.Font, False)
			.Action = FPSpread.ActionConstants.ActionClearText
			.BlockMode = False
			'----- �\�Z���z
			'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			ssText = VB6.Format(wkVal(0), "#,##0")
			.SetText(6, 1, ssText)
			'----- ���ы��z
			'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			ssText = VB6.Format(wkVal(1), "#,##0")
			.SetText(9, 1, ssText)
			'----- �ݐϋ��z
			'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			ssText = VB6.Format(wkVal(2), "#,##0")
			.SetText(11, 1, ssText)
			'----- ���㏊�v�������z
			'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			ssText = VB6.Format(wkVal(3), "#,##0")
			.SetText(13, 1, ssText)
			'----- ���{�������z
			'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			ssText = VB6.Format(wkVal(4), "#,##0")
			.SetText(15, 1, ssText)
			'----- �\�Z�Δ�
			'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			ssText = VB6.Format(wkVal(5), "#,##0")
			.SetText(16, 1, ssText)
			'----- �ύX����
			'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			ssText = VB6.Format(wkVal(6), "#,##0")
			.SetText(17, 1, ssText)
			If Me.Visible = True Then
				'UPGRADE_NOTE: Refresh was upgraded to CtlRefresh. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="A9E4979A-37FA-4718-9994-97DD76ED70A7"'
				.CtlRefresh()
				.ReDraw = True
			End If
		End With
		
	End Sub
	
	'-------------------------------------------------------------------------------
	'   ����    :   ����t���O�̍X�V
	'   �֐�    :   Function FlagUpdate()
	'   ����    :   �Ȃ�
	'   �ߒl    :   True    ����I��
	'   �@�@        False   �ُ�I��
	'   �@�\    :   ����t���O�̍X�V���s���܂��B
	'-------------------------------------------------------------------------------
	Private Function FlagUpdate() As Boolean
		
		Dim Jouken As String
		
		' �߂�l�̏�����
		FlagUpdate = False
		
		' �X�V����
		'UPGRADE_WARNING: Screen property Screen.MousePointer has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6BA9B8D2-2A32-4B6E-8D36-44949974A5B4"'
		System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
		'----- ��ݻ޸��݂̊J�n
		SYKDB.BeginTrans()
		Do 
			' ����t���O�i�y�؁j
			If UpdateCtrlFlg(8) = False Then
				SYKDB.RollbackTrans()
				Exit Do
			End If
			' ���o�ύX�t���O
			Jouken = "WARIDASI_NO = '" & Trim(ChumonID) & "'"
			Jouken = Jouken & " AND EDA_NO = '" & KeyKouji.EDA_NO & "'"
			Jouken = Jouken & " AND KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"
			If UpdateHenkoFlg("WARIDASI_MAST", Jouken, "0") = False Then
				SYKDB.RollbackTrans()
				Exit Do
			End If
			' �O���ύX�t���O
			Jouken = "SIME_YM = '" & CtlKouji.SYORI_YM & "'"
			Jouken = Jouken & " AND CHUUMON_NO = '" & Trim(ChumonID) & "'"
			Jouken = Jouken & " AND EDA_NO = '" & KeyKouji.EDA_NO & "'"
			Jouken = Jouken & " AND KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"
			If UpdateHenkoFlg("GAI_KIHON_DATA", Jouken, "1") = False Then
				SYKDB.RollbackTrans()
				Exit Do
			End If
			'----- ��ݻ޸��݂̊m��
			SYKDB.CommitTrans()
			' ����I��
			FlagUpdate = True
			Exit Do
		Loop 
		'UPGRADE_WARNING: Screen property Screen.MousePointer has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6BA9B8D2-2A32-4B6E-8D36-44949974A5B4"'
		System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
		
	End Function
	
	Private Sub cmdKey_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Click
		Dim Index As Short = cmdKey.GetIndex(eventSender)
		
		Dim ssText As Object
		
		Select Case Index
			Case 2 '----- �C��
				frmSYKD120.ShowDialog()
				vaSpread1.Focus()
				
			Case 12 '----- �I��
				If UpdateFG = "1" Then
					' ����t���O�̍X�V
					If FlagUpdate() = False Then
						'
					End If
					UpdateFG = "0"
					' �ĕ\��
					Call frmSYKD080.ListDataDisp(1)
				End If
				Me.Close()
		End Select
		
	End Sub
	
	Private Sub cmdKey_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Enter
		Dim Index As Short = cmdKey.GetIndex(eventSender)
		Call GotFocus(cmdKey(Index), StatusBar1)
	End Sub
	
	Private Sub cmdKey_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Leave
		Dim Index As Short = cmdKey.GetIndex(eventSender)
		Call LostFocus(cmdKey(Index), StatusBar1)
	End Sub
	
	Private Sub frmSYKD110_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown
		Dim KeyCode As Short = eventArgs.KeyCode
		Dim Shift As Short = eventArgs.KeyData \ &H10000
		Select Case KeyCode
			Case System.Windows.Forms.Keys.F1
				If cmdKey(1).Enabled = True Then cmdKey(1).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(1), New System.EventArgs())
			Case System.Windows.Forms.Keys.F2
				If cmdKey(2).Enabled = True Then cmdKey(2).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(2), New System.EventArgs())
			Case System.Windows.Forms.Keys.F3
				If cmdKey(3).Enabled = True Then cmdKey(3).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(3), New System.EventArgs())
			Case System.Windows.Forms.Keys.F4
				If cmdKey(4).Enabled = True Then cmdKey(4).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(4), New System.EventArgs())
			Case System.Windows.Forms.Keys.F5
				If cmdKey(5).Enabled = True Then cmdKey(5).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(5), New System.EventArgs())
			Case System.Windows.Forms.Keys.F6
				If cmdKey(6).Enabled = True Then cmdKey(6).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(6), New System.EventArgs())
			Case System.Windows.Forms.Keys.F7
				If cmdKey(7).Enabled = True Then cmdKey(7).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(7), New System.EventArgs())
			Case System.Windows.Forms.Keys.F8
				If cmdKey(8).Enabled = True Then cmdKey(8).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(8), New System.EventArgs())
			Case System.Windows.Forms.Keys.F9
				If cmdKey(9).Enabled = True Then cmdKey(9).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(9), New System.EventArgs())
			Case System.Windows.Forms.Keys.F10
				If cmdKey(10).Enabled = True Then cmdKey(10).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(10), New System.EventArgs())
			Case System.Windows.Forms.Keys.F11
				If cmdKey(11).Enabled = True Then cmdKey(11).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(11), New System.EventArgs())
			Case System.Windows.Forms.Keys.F12
				If cmdKey(12).Enabled = True Then cmdKey(12).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(12), New System.EventArgs())
		End Select
	End Sub
	
	Private Sub frmSYKD110_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
		
		Call FormDisp(Me)
		
		' ������
		UpdateFG = "0"
		
		' �����\��
		Call DispClear(1)
		Call ListDataDisp(1)
		
	End Sub
	
	Private Sub frmSYKD110_FormClosing(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
		Dim Cancel As Boolean = eventArgs.Cancel
		Dim UnloadMode As System.Windows.Forms.CloseReason = eventArgs.CloseReason
		If UnloadMode = System.Windows.Forms.CloseReason.UserClosing Then
			If UpdateFG = "1" Then
				' ����t���O�̍X�V
				If FlagUpdate() = False Then
					'
				End If
				UpdateFG = "0"
				' �ĕ\��
				Call frmSYKD080.ListDataDisp(1)
			End If
		End If
		eventArgs.Cancel = Cancel
	End Sub
	
	Private Sub vaSpread1_DblClick(ByVal eventSender As System.Object, ByVal eventArgs As AxFPSpread._DSpreadEvents_DblClickEvent) Handles vaSpread1.DblClick
		' �^�C�g���ȊO
		If eventArgs.Col > 0 And eventArgs.Row > 0 Then
			' �C������
			Call cmdKey_Click(cmdKey.Item(2), New System.EventArgs())
		End If
	End Sub
	
	Private Sub vaSpread1_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles vaSpread1.Enter
		Call GotFocus(vaSpread1, StatusBar1)
	End Sub
	
	Private Sub vaSpread1_KeyDownEvent(ByVal eventSender As System.Object, ByVal eventArgs As AxFPSpread._DSpreadEvents_KeyDownEvent) Handles vaSpread1.KeyDownEvent
		If eventArgs.KeyCode = System.Windows.Forms.Keys.Return Then
			If vaSpread1.ActiveRow > 0 Then
				' �C������
				Call cmdKey_Click(cmdKey.Item(2), New System.EventArgs())
			End If
		End If
	End Sub
	
	Private Sub vaSpread1_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles vaSpread1.Leave
		Call LostFocus(vaSpread1, StatusBar1)
	End Sub
	
	Private Sub vaSpread1_TopLeftChange(ByVal eventSender As System.Object, ByVal eventArgs As AxFPSpread._DSpreadEvents_TopLeftChangeEvent) Handles vaSpread1.TopLeftChange
		vaSpread2.LeftCol = eventArgs.NewLeft
	End Sub
	
	Private Sub vaSpread2_TopLeftChange(ByVal eventSender As System.Object, ByVal eventArgs As AxFPSpread._DSpreadEvents_TopLeftChangeEvent) Handles vaSpread2.TopLeftChange
		vaSpread1.LeftCol = eventArgs.NewLeft
	End Sub
End Class