Option Strict Off
Option Explicit On
Friend Class frmSYKD140
	Inherits System.Windows.Forms.Form
	'=============================================================
	' ���[�U�[���@  �F  �R�z�H�Ɗ������
	' �V�X�e�����@  �F  �H���Ǘ��V�X�e��
	' ���W���[����  �F  �O���ꗗ
	' ���W���[��ID�@�F  frmSYKD140.frm
	' �쐬���@ �@�@ �F  ���� 13 �N 07 �� 10 ��
	' �X�V���@�@  �@�F  ����    �N    ��    ��
	'=============================================================
	'
	
	Private Const RowHeight As Short = 15
	
	'�O����{�f�[�^
	Private Structure KIHON_DATA_QRY
		'UPGRADE_WARNING: Fixed-length string size must fit in the buffer. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="3C1E4426-0B80-443E-B943-0627CD55D48B"'
		<VBFixedString(2),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=2)> Public CHUUMON_NO() As Char '�����ԍ�
		'UPGRADE_WARNING: Fixed-length string size must fit in the buffer. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="3C1E4426-0B80-443E-B943-0627CD55D48B"'
		<VBFixedString(40),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=40)> Public C_MEISYOU() As Char '��������
		'UPGRADE_WARNING: Fixed-length string size must fit in the buffer. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="3C1E4426-0B80-443E-B943-0627CD55D48B"'
		<VBFixedString(8),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=8)> Public GYOUSYA_CD() As Char '�Ǝк���
		'UPGRADE_WARNING: Fixed-length string size must fit in the buffer. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="3C1E4426-0B80-443E-B943-0627CD55D48B"'
		<VBFixedString(40),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=40)> Public G_MEISYOU() As Char '�ƎЖ���
		Dim KINGAKU As Decimal '���z
		'UPGRADE_WARNING: Fixed-length string size must fit in the buffer. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="3C1E4426-0B80-443E-B943-0627CD55D48B"'
		<VBFixedString(1),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=1)> Public HENKOU_FLG() As Char '�ύX�t���O
		'UPGRADE_WARNING: Fixed-length string size must fit in the buffer. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="3C1E4426-0B80-443E-B943-0627CD55D48B"'
		<VBFixedString(1),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=1)> Public SEISAN_FLG() As Char '���Z�t���O
	End Structure
	'
	
	'-------------------------------------------------------------------------------
	'   ����   :   �O���ꗗ�ύX�t���O�̎擾
	'   �֐�   :   Function GetGaichuFlg()
	'   ����   :   �Ȃ�
	'   �ߒl   :   �ύX�t���O
	'   �@�\   :   �O���ꗗ�̕ύX�t���O���擾���܂��B
	'-------------------------------------------------------------------------------
	Private Function GetGaichuFlg() As String
		
		Dim lp As Integer
		Dim ssText As Object
		Dim wkVal As Short
		
		' ������
		wkVal = 0
		
		For lp = 1 To vaSpread1.MaxRows
			vaSpread1.GetText(6, lp, ssText)
			'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			If Trim(ssText) <> "" Then
				wkVal = wkVal + 1
				Exit For
			End If
		Next lp
		
		' �߂�l�ɃZ�b�g
		GetGaichuFlg = VB6.Format(wkVal, "0")
		
	End Function
	
	'-------------------------------------------------------------------------------
	'   ����   :   �f�[�^�̃N���A
	'   �֐�   :   Sub DispClear()
	'   ����   :   �Ȃ�
	'   �@�\   :   �f�[�^���N���A���܂��B
	'-------------------------------------------------------------------------------
	Private Sub DispClear()
		
		'----- �H�����
		With KeyKouji
			imText2(0).Text = .KOUJI_NO
			If .EDA_NO = "0000" Then
				imText2(1).Text = ""
			Else
				imText2(1).Text = .EDA_NO
			End If
			imText2(2).Text = .MEISYOU
		End With
		
		'----- ���N��
		imText1(0).Text = VB6.Format(CtlKouji.SYORI_YM, "0000/00")
		
		vaSpread1.MaxRows = 0
		imText1(1).Text = "0"
		
		'----- �Q�ƃ��[�h
		If INPMODE <> "2" Then
			cmdKey(1).Text = "  F1  �\ ��"
		End If
		
	End Sub
	
	'-------------------------------------------------------------------------------
	'   ����   :   GAI_KIHON_DATA �ǂݍ��ݏ���
	'   �֐�   :   Function SelectGaiKihon()
	'   ����   :   DT()�@   KIHON_DATA_QRY
	'   �ߒl   :   �ް���   ����I��
	'   �@�@       -1�@     �ُ�I��
	'   �@�\   :   GAI_KIHON_DATA SELECT����
	'-------------------------------------------------------------------------------
	Private Function SelectGaiKihon(ByRef DT() As KIHON_DATA_QRY) As Integer
		
		Dim SQL As String
		Dim Rs As ADODB.Recordset
		Dim Fld As ADODB.Field
		Dim Cnt As Integer
		Dim OpenFlg As Short
		
		On Error GoTo SelectGaiKihon_Err
		
		'�߂�l�̏�����
		SelectGaiKihon = -1
		
		'SQL/SELECT���g��
		SQL = "SELECT"
		SQL = SQL & " GAI_KIHON_DATA.CHUUMON_NO  AS CHUUMON_NO," '�����ԍ�
		SQL = SQL & " WARIDASI_MAST.MEISYOU      AS C_MEISYOU," '��������
		SQL = SQL & " WARIDASI_MAST.GYOUSYA_CD   AS GYOUSYA_CD," '�Ǝк���
		SQL = SQL & " GYOUSYA_MAST.MEISYOU       AS G_MEISYOU," '�ƎЖ���
		SQL = SQL & " GAI_KIHON_DATA.KON_SI_GAKU AS KINGAKU," '���z
		SQL = SQL & " GAI_KIHON_DATA.HENKOU_FLG  AS HENKOU_FLG," '�ύX�t���O
		SQL = SQL & " GAI_KIHON_DATA.SEISAN_FLG  AS SEISAN_FLG" '���Z�t���O
		SQL = SQL & " FROM GAI_KIHON_DATA INNER JOIN"
		SQL = SQL & " (WARIDASI_MAST INNER JOIN GYOUSYA_MAST"
		SQL = SQL & " ON WARIDASI_MAST.GYOUSYA_CD = GYOUSYA_MAST.GYOUSYA_CD)"
		SQL = SQL & " ON  (GAI_KIHON_DATA.CHUUMON_NO = WARIDASI_MAST.WARIDASI_NO)"
		SQL = SQL & " AND (GAI_KIHON_DATA.EDA_NO     = WARIDASI_MAST.EDA_NO)"
		SQL = SQL & " AND (GAI_KIHON_DATA.KOUJI_NO   = WARIDASI_MAST.KOUJI_NO)"
		SQL = SQL & " WHERE GAI_KIHON_DATA.EDA_NO = '" & KeyKouji.EDA_NO & "'"
		SQL = SQL & " AND GAI_KIHON_DATA.KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"
		SQL = SQL & " AND GAI_KIHON_DATA.SIME_YM  = '" & CtlKouji.SYORI_YM & "'"
		SQL = SQL & " ORDER BY GAI_KIHON_DATA.CHUUMON_NO"
		
		'SQL�����s
		Rs = SYKDB.Execute(SQL,  , ADODB.CommandTypeEnum.adCmdText)
		OpenFlg = 1
		
		Cnt = 0
		Do Until Rs.EOF
			ReDim Preserve DT(Cnt)
			With DT(Cnt)
				'----- ������
				.CHUUMON_NO = "" '�����ԍ�
				.C_MEISYOU = "" '��������
				.GYOUSYA_CD = "" '�Ǝк���
				.G_MEISYOU = "" '�ƎЖ���
				.KINGAKU = 0 '���z
				.HENKOU_FLG = "" '�ύX�t���O
				.SEISAN_FLG = "" '���Z�t���O
				'----- �\���̂�
				For	Each Fld In Rs.Fields
					'UPGRADE_WARNING: Use of Null/IsNull() detected. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="2EED02CB-5C0E-4DC1-AE94-4FAA3A30F51A"'
					If IsDbNull(Fld.Name) = False And IsDbNull(Fld.Value) = False Then
						Select Case UCase(Fld.Name)
							Case "CHUUMON_NO" : .CHUUMON_NO = Fld.Value '�����ԍ�
							Case "C_MEISYOU" : .C_MEISYOU = Fld.Value '��������
							Case "GYOUSYA_CD" : .GYOUSYA_CD = Fld.Value '�Ǝк���
							Case "G_MEISYOU" : .G_MEISYOU = Fld.Value '�ƎЖ���
							Case "KINGAKU" : .KINGAKU = Fld.Value '���z
							Case "HENKOU_FLG" : .HENKOU_FLG = Fld.Value '�ύX�t���O
							Case "SEISAN_FLG" : .SEISAN_FLG = Fld.Value '���Z�t���O
						End Select
					End If
				Next Fld
			End With
			Cnt = Cnt + 1
			Rs.MoveNext()
		Loop 
		
		Rs.Close()
		'UPGRADE_NOTE: Object Rs may not be destroyed until it is garbage collected. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"'
		Rs = Nothing
		
		'�߂�l�̃Z�b�g
		SelectGaiKihon = Cnt
		Exit Function
		
SelectGaiKihon_Err: 
		
		If OpenFlg = 1 Then
			Rs.Close()
		End If
		'UPGRADE_NOTE: Object Rs may not be destroyed until it is garbage collected. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"'
		Rs = Nothing
		
		Call Sql_Error_Msg("GAI_KIHON_DATA SELECT")
		
	End Function
	
	'-------------------------------------------------------------------------------
	'   ����    :   �f�[�^�̎擾
	'   �֐�    :   Sub ListDataDisp()
	'   ����    :   Mode    0 = MsgBox�\��
	'   �@�\    :   �f�[�^�̎擾���s���܂��B
	'-------------------------------------------------------------------------------
	Public Sub ListDataDisp(Optional ByRef Mode As Short = 0)
		
		Dim Cnt As Integer
		Dim DT() As KIHON_DATA_QRY
		Dim wkBuf As String
		
		' �J�[�\���������v��
		'UPGRADE_WARNING: Screen property Screen.MousePointer has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6BA9B8D2-2A32-4B6E-8D36-44949974A5B4"'
		System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
		wkBuf = StatusBar1.Items.Item("Message").Text
		StatusBar1.Items.Item("Message").Text = "�Y���f�[�^�������E�E�E"
		
		' �e�[�u���̓Ǎ���
		Cnt = SelectGaiKihon(DT)
		If Cnt <= 0 Then
			vaSpread1.MaxRows = 0
			cmdKey(1).Enabled = False
			StatusBar1.Items.Item("Message").Text = wkBuf
			'UPGRADE_WARNING: Screen property Screen.MousePointer has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6BA9B8D2-2A32-4B6E-8D36-44949974A5B4"'
			System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
			Exit Sub
		End If
		
		' �X�v���b�h�ɕ\��
		Call SprdDataSet(Cnt, DT)
		
		StatusBar1.Items.Item("Message").Text = wkBuf
		'UPGRADE_WARNING: Screen property Screen.MousePointer has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6BA9B8D2-2A32-4B6E-8D36-44949974A5B4"'
		System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
		
	End Sub
	
	'-------------------------------------------------------------------------------
	'   ����    :   �X�v���b�h�\��
	'   �֐�    :   Sub SprdDataSet(DT())
	'   ����    :   Cnt     �f�[�^����
	'   �@�@    :   DT()    KIHON_DATA_QRY
	'   �@�\    :   �f�[�^���X�v���b�h�ɕ\�����܂��B
	'-------------------------------------------------------------------------------
	Private Sub SprdDataSet(ByRef Cnt As Integer, ByRef DT() As KIHON_DATA_QRY)
		
		Dim lp As Integer
		Dim Row As Integer
		Dim ssText As Object
		Dim wkVal As Decimal
		
		With vaSpread1
			If Me.Visible = True Then
				.ReDraw = False
			End If
			.MaxRows = Cnt
			.Col = 1 : .Col2 = .MaxCols
			.Row = 1 : .Row2 = .MaxRows
			.BlockMode = True
			.Action = FPSpread.ActionConstants.ActionClearText
			.ForeColor = System.Drawing.Color.Black
			.BlockMode = False
			wkVal = 0
			For lp = 0 To Cnt - 1
				.set_RowHeight(lp + 1, RowHeight)
				Row = lp + 1
				'----- ������
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				ssText = Trim(DT(lp).CHUUMON_NO)
				.SetText(1, Row, ssText)
				'----- ����
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				ssText = Trim(DT(lp).C_MEISYOU)
				.SetText(2, Row, ssText)
				'----- �Ǝк���
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				ssText = Trim(DT(lp).GYOUSYA_CD)
				.SetText(3, Row, ssText)
				'----- �ƎЖ�
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				ssText = Trim(DT(lp).G_MEISYOU)
				.SetText(4, Row, ssText)
				'----- ���z
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				ssText = VB6.Format(DT(lp).KINGAKU, "#,##0")
				.SetText(5, Row, ssText)
				'----- �ύX�t���O
				Select Case DT(lp).HENKOU_FLG
					Case "1"
						'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
						ssText = "�ύX����"
						.Col = 1 : .Col2 = .MaxCols
						.Row = Row : .Row2 = Row
						.BlockMode = True
						.ForeColor = System.Drawing.Color.Red
						.BlockMode = False
					Case Else
						'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
						ssText = ""
				End Select
				.SetText(6, Row, ssText)
				'----- ���Z�t���O
				Select Case DT(lp).SEISAN_FLG
					Case "1"
						'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
						ssText = "��"
					Case Else
						'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
						ssText = ""
				End Select
				.SetText(7, Row, ssText)
				'----- �W�v
				wkVal = wkVal + DT(lp).KINGAKU
			Next lp
			If Me.Visible = True Then
				'UPGRADE_NOTE: Refresh was upgraded to CtlRefresh. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="A9E4979A-37FA-4718-9994-97DD76ED70A7"'
				.CtlRefresh()
				.ReDraw = True
			End If
		End With
		
		'----- ���v���z
		imText1(1).Text = VB6.Format(wkVal, "#,##0")
		
	End Sub
	
	Private Sub cmdKey_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Click
		Dim Index As Short = cmdKey.GetIndex(eventSender)
		
		Dim ssText As Object
		
		Select Case Index
			Case 1 '----- ����
				With vaSpread1
					.GetText(1, .ActiveRow, ssText) '�����ԍ�
					'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
					frmSYKD150.ChumonID = CStr(ssText)
				End With
				'UPGRADE_WARNING: Screen property Screen.MousePointer has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6BA9B8D2-2A32-4B6E-8D36-44949974A5B4"'
				System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
				frmSYKD150.ShowDialog()
				vaSpread1.Focus()
				
			Case 12 '----- �I��
				' �ύX�`�F�b�N
				If GetGaichuFlg() = "0" Then
					' ����t���O�i�y�؁j
					If UpdateCtrlFlg(9) = False Then
						Exit Sub
					End If
				End If
				frmSYKD010.Show()
				Me.Close()
		End Select
		
	End Sub
	
	Private Sub cmdKey_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Enter
		Dim Index As Short = cmdKey.GetIndex(eventSender)
		Call GotFocus(cmdKey(Index), StatusBar1)
	End Sub
	
	Private Sub cmdKey_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Leave
		Dim Index As Short = cmdKey.GetIndex(eventSender)
		Call LostFocus(cmdKey(Index), StatusBar1)
	End Sub
	
	Private Sub frmSYKD140_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown
		Dim KeyCode As Short = eventArgs.KeyCode
		Dim Shift As Short = eventArgs.KeyData \ &H10000
		Select Case KeyCode
			Case System.Windows.Forms.Keys.F1
				If cmdKey(1).Enabled = True Then cmdKey(1).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(1), New System.EventArgs())
			Case System.Windows.Forms.Keys.F2
				If cmdKey(2).Enabled = True Then cmdKey(2).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(2), New System.EventArgs())
			Case System.Windows.Forms.Keys.F3
				If cmdKey(3).Enabled = True Then cmdKey(3).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(3), New System.EventArgs())
			Case System.Windows.Forms.Keys.F4
				If cmdKey(4).Enabled = True Then cmdKey(4).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(4), New System.EventArgs())
			Case System.Windows.Forms.Keys.F5
				If cmdKey(5).Enabled = True Then cmdKey(5).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(5), New System.EventArgs())
			Case System.Windows.Forms.Keys.F6
				If cmdKey(6).Enabled = True Then cmdKey(6).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(6), New System.EventArgs())
			Case System.Windows.Forms.Keys.F7
				If cmdKey(7).Enabled = True Then cmdKey(7).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(7), New System.EventArgs())
			Case System.Windows.Forms.Keys.F8
				If cmdKey(8).Enabled = True Then cmdKey(8).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(8), New System.EventArgs())
			Case System.Windows.Forms.Keys.F9
				If cmdKey(9).Enabled = True Then cmdKey(9).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(9), New System.EventArgs())
			Case System.Windows.Forms.Keys.F10
				If cmdKey(10).Enabled = True Then cmdKey(10).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(10), New System.EventArgs())
			Case System.Windows.Forms.Keys.F11
				If cmdKey(11).Enabled = True Then cmdKey(11).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(11), New System.EventArgs())
			Case System.Windows.Forms.Keys.F12
				If cmdKey(12).Enabled = True Then cmdKey(12).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(12), New System.EventArgs())
		End Select
	End Sub
	
	Private Sub frmSYKD140_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
		
		Call FormDisp(Me)
		
		' �����\��
		Call DispClear()
		Call ListDataDisp(1)
		
	End Sub
	
	Private Sub frmSYKD140_FormClosing(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
		Dim Cancel As Boolean = eventArgs.Cancel
		Dim UnloadMode As System.Windows.Forms.CloseReason = eventArgs.CloseReason
		If UnloadMode = System.Windows.Forms.CloseReason.UserClosing Then
			' �ύX�`�F�b�N
			If GetGaichuFlg() = "0" Then
				' ����t���O�i�y�؁j
				If UpdateCtrlFlg(9) = False Then
					Cancel = True
					Exit Sub
				End If
			End If
			frmSYKD010.Show()
		End If
		eventArgs.Cancel = Cancel
	End Sub
	
	Private Sub vaSpread1_DblClick(ByVal eventSender As System.Object, ByVal eventArgs As AxFPSpread._DSpreadEvents_DblClickEvent) Handles vaSpread1.DblClick
		If eventArgs.Col > 0 And eventArgs.Row > 0 Then
			Call cmdKey_Click(cmdKey.Item(1), New System.EventArgs())
		End If
	End Sub
	
	Private Sub vaSpread1_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles vaSpread1.Enter
		Call GotFocus(vaSpread1, StatusBar1)
	End Sub
	
	Private Sub vaSpread1_KeyDownEvent(ByVal eventSender As System.Object, ByVal eventArgs As AxFPSpread._DSpreadEvents_KeyDownEvent) Handles vaSpread1.KeyDownEvent
		If eventArgs.KeyCode = System.Windows.Forms.Keys.Return Then
			If vaSpread1.ActiveRow > 0 Then
				Call cmdKey_Click(cmdKey.Item(1), New System.EventArgs())
			End If
		End If
	End Sub
	
	Private Sub vaSpread1_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles vaSpread1.Leave
		Call LostFocus(vaSpread1, StatusBar1)
	End Sub
End Class