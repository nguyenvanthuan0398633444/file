Option Strict Off
Option Explicit On
Friend Class ctlKeiyaku
	Inherits System.Windows.Forms.UserControl
	
	Private EventsObj As New clsEvents
	Private MsgBarObj As Object
	'
	
	'-------------------------------------------------------------------------------
	'   ����    :   �f�[�^�̃N���A
	'   �֐�    :   Sub DispClear()
	'   ����    :   �Ȃ�
	'   �@�\    :   �f�[�^���N���A���܂��B
	'-------------------------------------------------------------------------------
	Public Sub DispClear()
		
		imText1(0).Text = "" '�s�ԍ�
		imText1(0).BackColor = System.Drawing.SystemColors.Control
		imText1(1).Text = "" '�H������
		imText1(2).Text = "" '�H�햼
		imNumber1(0).Value = "" '�_�񌈒�z
		imText1(3).Text = "" '����o����
		imText1(4).Text = "" '�o�����݌v
		imNumber1(1).Value = "" '����x���z
		
	End Sub
	
	Private Sub imNumber1_Change(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles imNumber1.Change
		Dim Index As Short = imNumber1.GetIndex(eventSender)
		'----- ���z�ύX
		EventsObj.ValueChange(Index + 1, CCur2(imNumber1(Index).Value))
	End Sub
	
	Private Sub imNumber1_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles imNumber1.Enter
		Dim Index As Short = imNumber1.GetIndex(eventSender)
		Call GotFocus(Me, Nothing)
	End Sub
	
	Private Sub imNumber1_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles imNumber1.KeyDown
		Dim KeyCode As Short = eventArgs.KeyCode
		Dim Shift As Short = eventArgs.KeyData \ &H10000
		Dim Index As Short = imNumber1.GetIndex(eventSender)
		Select Case KeyCode
			Case System.Windows.Forms.Keys.Return
				Select Case Index
					Case 0 '----- �_�񌈒�z
						imNumber1(1).Focus()
					Case 1 '----- ����x���z
						EventsObj.ValueChange(3, 0)
						EventsObj.ValueChange(0, 0)
				End Select
		End Select
	End Sub
	
	Private Sub imNumber1_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles imNumber1.Leave
		Dim Index As Short = imNumber1.GetIndex(eventSender)
		Call LostFocus(Me, Nothing)
	End Sub
	
	Private Sub ctlKeiyaku_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Enter
		imText1(0).ForeColor = System.Drawing.Color.Red
	End Sub
	
	Private Sub ctlKeiyaku_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Leave
		imText1(0).ForeColor = System.Drawing.Color.Black
		'----- ���͏I��
		EventsObj.ValueChange(3, 0)
	End Sub
	
	Private Sub UserControl_Terminate()
		'UPGRADE_NOTE: Object MsgBarObj may not be destroyed until it is garbage collected. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"'
		MsgBarObj = Nothing
		'UPGRADE_NOTE: Object EventsObj may not be destroyed until it is garbage collected. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"'
		EventsObj = Nothing
	End Sub
	
	
	Public Shadows Property Enabled() As Boolean
		Get
			Enabled = Picture1.Enabled
		End Get
		Set(ByVal Value As Boolean)
			Picture1.Enabled = Value
		End Set
	End Property
	
	Public Shadows ReadOnly Property Events() As clsEvents
		Get
			Events = EventsObj
		End Get
	End Property
	
	Public Shadows WriteOnly Property ForeColor() As Integer
		Set(ByVal Value As Integer)
			imText1(0).ForeColor = System.Drawing.ColorTranslator.FromOle(Value)
		End Set
	End Property
	
	Public WriteOnly Property FocusPos() As Short
		Set(ByVal Value As Short)
			Select Case Value
				Case 3 : imNumber1(0).Focus() ' �_�񌈒�z
				Case 6 : imNumber1(1).Focus() ' ����x���z
			End Select
		End Set
	End Property
	
	Public WriteOnly Property StatusBar() As Object
		Set(ByVal Value As Object)
			MsgBarObj = Value
		End Set
	End Property
	
	
	Public Property Value(ByVal Mode As Short) As Object
		Get
			Select Case Mode
				Case 0 : Value = Trim(imText1(0).Text) ' �s�ԍ�
				Case 3 : Value = CCur2(imNumber1(0).Value) ' �_�񌈒�z
				Case 6 : Value = CCur2(imNumber1(1).Value) ' ����x���z
			End Select
		End Get
		Set(ByVal Value As Object)
			Select Case Mode
				Case 0
					'UPGRADE_WARNING: Couldn't resolve default property of object SetVal. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
					imText1(0).Text = Value ' �s�ԍ�
				Case 1
					'UPGRADE_WARNING: Couldn't resolve default property of object SetVal. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
					imText1(1).Text = Value ' �H������
				Case 2
					'UPGRADE_WARNING: Couldn't resolve default property of object SetVal. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
					imText1(2).Text = Value ' �H�햼
				Case 3
					'UPGRADE_WARNING: Couldn't resolve default property of object SetVal. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
					imNumber1(0).Value = Value ' �_�񌈒�z
				Case 4
					'UPGRADE_WARNING: Couldn't resolve default property of object SetVal. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
					imText1(3).Text = Value ' ����o����
				Case 5
					'UPGRADE_WARNING: Couldn't resolve default property of object SetVal. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
					imText1(4).Text = Value ' �o�����݌v
				Case 6
					'UPGRADE_WARNING: Couldn't resolve default property of object SetVal. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
					imNumber1(1).Value = Value ' ����x���z
			End Select
		End Set
	End Property
End Class