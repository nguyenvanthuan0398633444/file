<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frmWaridasi
#Region "Windows Form Designer generated code "
	<System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
		MyBase.New()
		'This call is required by the Windows Form Designer.
		InitializeComponent()
	End Sub
	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer
	Public ToolTip1 As System.Windows.Forms.ToolTip
	Public WithEvents vaSpread1 As AxFPSpread.AxvaSpread
	Public WithEvents _cmdKey_1 As System.Windows.Forms.Button
	Public WithEvents _cmdKey_12 As System.Windows.Forms.Button
	Public WithEvents Picture1 As System.Windows.Forms.Panel
	Public WithEvents _StatusBar1_Panel1 As System.Windows.Forms.ToolStripStatusLabel
	Public WithEvents _StatusBar1_Panel2 As System.Windows.Forms.ToolStripStatusLabel
	Public WithEvents StatusBar1 As System.Windows.Forms.StatusStrip
	Public WithEvents lblTitle As System.Windows.Forms.Label
	Public WithEvents cmdKey As Microsoft.VisualBasic.Compatibility.VB6.ButtonArray
	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmWaridasi))
		Me.components = New System.ComponentModel.Container()
		Me.ToolTip1 = New System.Windows.Forms.ToolTip(components)
		Me.vaSpread1 = New AxFPSpread.AxvaSpread
		Me.Picture1 = New System.Windows.Forms.Panel
		Me._cmdKey_1 = New System.Windows.Forms.Button
		Me._cmdKey_12 = New System.Windows.Forms.Button
		Me.StatusBar1 = New System.Windows.Forms.StatusStrip
		Me._StatusBar1_Panel1 = New System.Windows.Forms.ToolStripStatusLabel
		Me._StatusBar1_Panel2 = New System.Windows.Forms.ToolStripStatusLabel
		Me.lblTitle = New System.Windows.Forms.Label
		Me.cmdKey = New Microsoft.VisualBasic.Compatibility.VB6.ButtonArray(components)
		Me.Picture1.SuspendLayout()
		Me.StatusBar1.SuspendLayout()
		Me.SuspendLayout()
		Me.ToolTip1.Active = True
		CType(Me.vaSpread1, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.cmdKey, System.ComponentModel.ISupportInitialize).BeginInit()
		Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
		Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
		Me.Text = "�������"
		Me.ClientSize = New System.Drawing.Size(804, 568)
		Me.Location = New System.Drawing.Point(113, 127)
		Me.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me.Icon = CType(resources.GetObject("frmWaridasi.Icon"), System.Drawing.Icon)
		Me.KeyPreview = True
		Me.MaximizeBox = False
		Me.MinimizeBox = False
		Me.ShowInTaskbar = False
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.BackColor = System.Drawing.SystemColors.Control
		Me.ControlBox = True
		Me.Enabled = True
		Me.Cursor = System.Windows.Forms.Cursors.Default
		Me.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.HelpButton = False
		Me.WindowState = System.Windows.Forms.FormWindowState.Normal
		Me.Name = "frmWaridasi"
		vaSpread1.OcxState = CType(resources.GetObject("vaSpread1.OcxState"), System.Windows.Forms.AxHost.State)
		Me.vaSpread1.Size = New System.Drawing.Size(787, 445)
		Me.vaSpread1.Location = New System.Drawing.Point(8, 40)
		Me.vaSpread1.TabIndex = 0
		Me.vaSpread1.Name = "vaSpread1"
		Me.Picture1.Dock = System.Windows.Forms.DockStyle.Bottom
		Me.Picture1.BackColor = System.Drawing.Color.FromARGB(128, 128, 128)
		Me.Picture1.Font = New System.Drawing.Font("�l�r �o�S�V�b�N", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me.Picture1.Size = New System.Drawing.Size(804, 51)
		Me.Picture1.Location = New System.Drawing.Point(0, 494)
		Me.Picture1.TabIndex = 5
		Me.Picture1.TabStop = False
		Me.Picture1.CausesValidation = True
		Me.Picture1.Enabled = True
		Me.Picture1.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Picture1.Cursor = System.Windows.Forms.Cursors.Default
		Me.Picture1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Picture1.Visible = True
		Me.Picture1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.Picture1.Name = "Picture1"
		Me._cmdKey_1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me._cmdKey_1.Text = "  F1  �� ��"
		Me._cmdKey_1.Font = New System.Drawing.Font("�l�r ����", 11.25!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._cmdKey_1.Size = New System.Drawing.Size(77, 39)
		Me._cmdKey_1.Location = New System.Drawing.Point(4, 4)
		Me._cmdKey_1.TabIndex = 1
		Me._cmdKey_1.Tag = "�I���f�[�^�����肵�܂��B"
		Me._cmdKey_1.BackColor = System.Drawing.SystemColors.Control
		Me._cmdKey_1.CausesValidation = True
		Me._cmdKey_1.Enabled = True
		Me._cmdKey_1.ForeColor = System.Drawing.SystemColors.ControlText
		Me._cmdKey_1.Cursor = System.Windows.Forms.Cursors.Default
		Me._cmdKey_1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._cmdKey_1.TabStop = True
		Me._cmdKey_1.Name = "_cmdKey_1"
		Me._cmdKey_12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me._cmdKey_12.Text = "  F12  �I ��"
		Me._cmdKey_12.Font = New System.Drawing.Font("�l�r ����", 11.25!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._cmdKey_12.Size = New System.Drawing.Size(77, 39)
		Me._cmdKey_12.Location = New System.Drawing.Point(718, 4)
		Me._cmdKey_12.TabIndex = 2
		Me._cmdKey_12.Tag = "������ʂ��I�����܂��B"
		Me._cmdKey_12.BackColor = System.Drawing.SystemColors.Control
		Me._cmdKey_12.CausesValidation = True
		Me._cmdKey_12.Enabled = True
		Me._cmdKey_12.ForeColor = System.Drawing.SystemColors.ControlText
		Me._cmdKey_12.Cursor = System.Windows.Forms.Cursors.Default
		Me._cmdKey_12.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._cmdKey_12.TabStop = True
		Me._cmdKey_12.Name = "_cmdKey_12"
		Me.StatusBar1.Dock = System.Windows.Forms.DockStyle.Bottom
		Me.StatusBar1.Size = New System.Drawing.Size(804, 23)
		Me.StatusBar1.Location = New System.Drawing.Point(0, 545)
		Me.StatusBar1.TabIndex = 4
		Me.StatusBar1.Font = New System.Drawing.Font("�l�r �S�V�b�N", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me.StatusBar1.Name = "StatusBar1"
		Me._StatusBar1_Panel1.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter
		Me._StatusBar1_Panel1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
		Me._StatusBar1_Panel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me._StatusBar1_Panel1.Size = New System.Drawing.Size(117, 23)
		Me._StatusBar1_Panel1.BorderSides = CType(System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom, System.Windows.Forms.ToolStripStatusLabelBorderSides)
		Me._StatusBar1_Panel1.Margin = New System.Windows.Forms.Padding(0)
		Me._StatusBar1_Panel1.AutoSize = False
		Me._StatusBar1_Panel2.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter
		Me._StatusBar1_Panel2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
		Me._StatusBar1_Panel2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._StatusBar1_Panel2.Size = New System.Drawing.Size(735, 23)
		Me._StatusBar1_Panel2.BorderSides = CType(System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom, System.Windows.Forms.ToolStripStatusLabelBorderSides)
		Me._StatusBar1_Panel2.Margin = New System.Windows.Forms.Padding(0)
		Me._StatusBar1_Panel2.AutoSize = False
		Me.lblTitle.BackColor = System.Drawing.Color.FromARGB(192, 192, 255)
		Me.lblTitle.Text = " ���o��񌟍�"
		Me.lblTitle.Font = New System.Drawing.Font("�l�r ����", 20.25!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me.lblTitle.ForeColor = System.Drawing.Color.FromARGB(0, 0, 128)
		Me.lblTitle.Size = New System.Drawing.Size(803, 31)
		Me.lblTitle.Location = New System.Drawing.Point(0, 0)
		Me.lblTitle.TabIndex = 3
		Me.lblTitle.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.lblTitle.Enabled = True
		Me.lblTitle.Cursor = System.Windows.Forms.Cursors.Default
		Me.lblTitle.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.lblTitle.UseMnemonic = True
		Me.lblTitle.Visible = True
		Me.lblTitle.AutoSize = False
		Me.lblTitle.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.lblTitle.Name = "lblTitle"
		Me.Controls.Add(vaSpread1)
		Me.Controls.Add(Picture1)
		Me.Controls.Add(StatusBar1)
		Me.Controls.Add(lblTitle)
		Me.Picture1.Controls.Add(_cmdKey_1)
		Me.Picture1.Controls.Add(_cmdKey_12)
		Me.StatusBar1.Items.AddRange(New System.Windows.Forms.ToolStripItem(){Me._StatusBar1_Panel1})
		Me.StatusBar1.Items.AddRange(New System.Windows.Forms.ToolStripItem(){Me._StatusBar1_Panel2})
		Me.cmdKey.SetIndex(_cmdKey_1, CType(1, Short))
		Me.cmdKey.SetIndex(_cmdKey_12, CType(12, Short))
		CType(Me.cmdKey, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.vaSpread1, System.ComponentModel.ISupportInitialize).EndInit()
		Me.Picture1.ResumeLayout(False)
		Me.StatusBar1.ResumeLayout(False)
		Me.ResumeLayout(False)
		Me.PerformLayout()
	End Sub
#End Region 
End Class