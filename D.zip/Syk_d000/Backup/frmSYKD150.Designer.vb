<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frmSYKD150
#Region "Windows Form Designer generated code "
	<System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
		MyBase.New()
		'This call is required by the Windows Form Designer.
		InitializeComponent()
	End Sub
	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer
	Public ToolTip1 As System.Windows.Forms.ToolTip
	Public WithEvents _imText3_4 As imText6.imText
	Public WithEvents _imText3_5 As imText6.imText
	Public WithEvents _imText3_6 As imText6.imText
	Public WithEvents _imNumber2_5 As imNumber6.imNumber
	Public WithEvents _imNumber2_6 As imNumber6.imNumber
	Public WithEvents Picture2 As System.Windows.Forms.Panel
	Public WithEvents _ctlMeisai2_0 As ctlIppan
	Public WithEvents VScroll2 As System.Windows.Forms.VScrollBar
	Public WithEvents _ctlMeisai2_1 As ctlIppan
	Public WithEvents _ctlMeisai2_2 As ctlIppan
	Public WithEvents _ctlMeisai2_3 As ctlIppan
	Public WithEvents _imText3_7 As imText6.imText
	Public WithEvents _imText3_8 As imText6.imText
	Public WithEvents _Label1_44 As System.Windows.Forms.Label
	Public WithEvents _Label1_43 As System.Windows.Forms.Label
	Public WithEvents _Label1_39 As System.Windows.Forms.Label
	Public WithEvents _Label1_38 As System.Windows.Forms.Label
	Public WithEvents _Label1_37 As System.Windows.Forms.Label
	Public WithEvents _Label1_36 As System.Windows.Forms.Label
	Public WithEvents _Label1_35 As System.Windows.Forms.Label
	Public WithEvents _Label1_30 As System.Windows.Forms.Label
	Public WithEvents _Label1_33 As System.Windows.Forms.Label
	Public WithEvents _Label1_34 As System.Windows.Forms.Label
	Public WithEvents _Label1_27 As System.Windows.Forms.Label
	Public WithEvents _Label1_28 As System.Windows.Forms.Label
	Public WithEvents _Label1_29 As System.Windows.Forms.Label
	Public WithEvents _Label1_32 As System.Windows.Forms.Label
	Public WithEvents _Label1_31 As System.Windows.Forms.Label
	Public WithEvents _Frame1_4 As System.Windows.Forms.GroupBox
	Public WithEvents _imText4_0 As imText6.imText
	Public WithEvents _imNumber2_0 As imNumber6.imNumber
	Public WithEvents _imText4_2 As imText6.imText
	Public WithEvents _imText4_3 As imText6.imText
	Public WithEvents _imNumber2_1 As imNumber6.imNumber
	Public WithEvents _imText4_4 As imText6.imText
	Public WithEvents _imText4_5 As imText6.imText
	Public WithEvents _imText4_6 As imText6.imText
	Public WithEvents _imNumber2_3 As imNumber6.imNumber
	Public WithEvents _imText4_7 As imText6.imText
	Public WithEvents _imNumber2_4 As imNumber6.imNumber
	Public WithEvents _imNumber2_2 As imNumber6.imNumber
	Public WithEvents _imNumber2_7 As imNumber6.imNumber
	Public WithEvents _imNumber2_8 As imNumber6.imNumber
	Public WithEvents _Label1_46 As System.Windows.Forms.Label
	Public WithEvents _Label1_45 As System.Windows.Forms.Label
	Public WithEvents _Label1_3 As System.Windows.Forms.Label
	Public WithEvents _Label1_25 As System.Windows.Forms.Label
	Public WithEvents _Label1_26 As System.Windows.Forms.Label
	Public WithEvents _Label1_24 As System.Windows.Forms.Label
	Public WithEvents _Label1_23 As System.Windows.Forms.Label
	Public WithEvents _Label1_21 As System.Windows.Forms.Label
	Public WithEvents _Label1_22 As System.Windows.Forms.Label
	Public WithEvents Label2 As System.Windows.Forms.Label
	Public WithEvents _Label1_20 As System.Windows.Forms.Label
	Public WithEvents _Label1_19 As System.Windows.Forms.Label
	Public WithEvents _Label1_18 As System.Windows.Forms.Label
	Public WithEvents _Label1_17 As System.Windows.Forms.Label
	Public WithEvents _Label1_16 As System.Windows.Forms.Label
	Public WithEvents _Label1_15 As System.Windows.Forms.Label
	Public WithEvents _Frame1_3 As System.Windows.Forms.GroupBox
	Public WithEvents VScroll1 As System.Windows.Forms.VScrollBar
	Public WithEvents _ctlMeisai1_0 As ctlKeiyaku
	Public WithEvents _imText3_0 As imText6.imText
	Public WithEvents _ctlMeisai1_1 As ctlKeiyaku
	Public WithEvents _ctlMeisai1_2 As ctlKeiyaku
	Public WithEvents _imText3_1 As imText6.imText
	Public WithEvents _imText3_2 As imText6.imText
	Public WithEvents _imText3_3 As imText6.imText
	Public WithEvents _Label1_10 As System.Windows.Forms.Label
	Public WithEvents _Label1_11 As System.Windows.Forms.Label
	Public WithEvents _Label1_14 As System.Windows.Forms.Label
	Public WithEvents _Label1_9 As System.Windows.Forms.Label
	Public WithEvents _Label1_8 As System.Windows.Forms.Label
	Public WithEvents _Label1_7 As System.Windows.Forms.Label
	Public WithEvents _Label1_13 As System.Windows.Forms.Label
	Public WithEvents _Label1_12 As System.Windows.Forms.Label
	Public WithEvents _Frame1_2 As System.Windows.Forms.GroupBox
	Public WithEvents _imNumber1_0 As imNumber6.imNumber
	Public WithEvents _imNumber1_1 As imNumber6.imNumber
	Public WithEvents _imNumber1_2 As imNumber6.imNumber
	Public WithEvents _Label1_42 As System.Windows.Forms.Label
	Public WithEvents _Label1_41 As System.Windows.Forms.Label
	Public WithEvents _Label1_40 As System.Windows.Forms.Label
	Public WithEvents _Label1_6 As System.Windows.Forms.Label
	Public WithEvents _Label1_5 As System.Windows.Forms.Label
	Public WithEvents _Label1_4 As System.Windows.Forms.Label
	Public WithEvents _Frame1_1 As System.Windows.Forms.GroupBox
	Public WithEvents Check1 As System.Windows.Forms.CheckBox
	Public WithEvents _imText1_0 As imText6.imText
	Public WithEvents _imText1_3 As imText6.imText
	Public WithEvents _imText1_2 As imText6.imText
	Public WithEvents _imText1_1 As imText6.imText
	Public WithEvents _Label1_1 As System.Windows.Forms.Label
	Public WithEvents _Label1_0 As System.Windows.Forms.Label
	Public WithEvents _Label1_2 As System.Windows.Forms.Label
	Public WithEvents _Frame1_0 As System.Windows.Forms.GroupBox
	Public WithEvents _cmdKey_3 As System.Windows.Forms.Button
	Public WithEvents _cmdKey_12 As System.Windows.Forms.Button
	Public WithEvents _cmdKey_4 As System.Windows.Forms.Button
	Public WithEvents _cmdKey_10 As System.Windows.Forms.Button
	Public WithEvents _cmdKey_6 As System.Windows.Forms.Button
	Public WithEvents _cmdKey_7 As System.Windows.Forms.Button
	Public WithEvents _cmdKey_8 As System.Windows.Forms.Button
	Public WithEvents _cmdKey_9 As System.Windows.Forms.Button
	Public WithEvents _cmdKey_1 As System.Windows.Forms.Button
	Public WithEvents _cmdKey_11 As System.Windows.Forms.Button
	Public WithEvents _cmdKey_2 As System.Windows.Forms.Button
	Public WithEvents _cmdKey_5 As System.Windows.Forms.Button
	Public WithEvents Picture1 As System.Windows.Forms.Panel
	Public WithEvents _StatusBar1_Panel1 As System.Windows.Forms.ToolStripStatusLabel
	Public WithEvents _StatusBar1_Panel2 As System.Windows.Forms.ToolStripStatusLabel
	Public WithEvents StatusBar1 As System.Windows.Forms.StatusStrip
	Public WithEvents _imText2_2 As imText6.imText
	Public WithEvents _imText2_0 As imText6.imText
	Public WithEvents _imText2_1 As imText6.imText
	Public WithEvents lblTitle As System.Windows.Forms.Label
	Public WithEvents Frame1 As Microsoft.VisualBasic.Compatibility.VB6.GroupBoxArray
	Public WithEvents Label1 As Microsoft.VisualBasic.Compatibility.VB6.LabelArray
	Public WithEvents cmdKey As Microsoft.VisualBasic.Compatibility.VB6.ButtonArray
	Public WithEvents ctlMeisai1 As ctlKeiyakuArray
	Public WithEvents ctlMeisai2 As ctlIppanArray
	Public WithEvents imNumber1 As imNumberArray
	Public WithEvents imNumber2 As imNumberArray
	Public WithEvents imText1 As imTextArray
	Public WithEvents imText2 As imTextArray
	Public WithEvents imText3 As imTextArray
	Public WithEvents imText4 As imTextArray
	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmSYKD150))
		Me.components = New System.ComponentModel.Container()
		Me.ToolTip1 = New System.Windows.Forms.ToolTip(components)
		Me._Frame1_4 = New System.Windows.Forms.GroupBox
		Me.Picture2 = New System.Windows.Forms.Panel
		Me._imText3_4 = New imText6.imText
		Me._imText3_5 = New imText6.imText
		Me._imText3_6 = New imText6.imText
		Me._imNumber2_5 = New imNumber6.imNumber
		Me._imNumber2_6 = New imNumber6.imNumber
		Me._ctlMeisai2_0 = New ctlIppan
		Me.VScroll2 = New System.Windows.Forms.VScrollBar
		Me._ctlMeisai2_1 = New ctlIppan
		Me._ctlMeisai2_2 = New ctlIppan
		Me._ctlMeisai2_3 = New ctlIppan
		Me._imText3_7 = New imText6.imText
		Me._imText3_8 = New imText6.imText
		Me._Label1_44 = New System.Windows.Forms.Label
		Me._Label1_43 = New System.Windows.Forms.Label
		Me._Label1_39 = New System.Windows.Forms.Label
		Me._Label1_38 = New System.Windows.Forms.Label
		Me._Label1_37 = New System.Windows.Forms.Label
		Me._Label1_36 = New System.Windows.Forms.Label
		Me._Label1_35 = New System.Windows.Forms.Label
		Me._Label1_30 = New System.Windows.Forms.Label
		Me._Label1_33 = New System.Windows.Forms.Label
		Me._Label1_34 = New System.Windows.Forms.Label
		Me._Label1_27 = New System.Windows.Forms.Label
		Me._Label1_28 = New System.Windows.Forms.Label
		Me._Label1_29 = New System.Windows.Forms.Label
		Me._Label1_32 = New System.Windows.Forms.Label
		Me._Label1_31 = New System.Windows.Forms.Label
		Me._Frame1_3 = New System.Windows.Forms.GroupBox
		Me._imText4_0 = New imText6.imText
		Me._imNumber2_0 = New imNumber6.imNumber
		Me._imText4_2 = New imText6.imText
		Me._imText4_3 = New imText6.imText
		Me._imNumber2_1 = New imNumber6.imNumber
		Me._imText4_4 = New imText6.imText
		Me._imText4_5 = New imText6.imText
		Me._imText4_6 = New imText6.imText
		Me._imNumber2_3 = New imNumber6.imNumber
		Me._imText4_7 = New imText6.imText
		Me._imNumber2_4 = New imNumber6.imNumber
		Me._imNumber2_2 = New imNumber6.imNumber
		Me._imNumber2_7 = New imNumber6.imNumber
		Me._imNumber2_8 = New imNumber6.imNumber
		Me._Label1_46 = New System.Windows.Forms.Label
		Me._Label1_45 = New System.Windows.Forms.Label
		Me._Label1_3 = New System.Windows.Forms.Label
		Me._Label1_25 = New System.Windows.Forms.Label
		Me._Label1_26 = New System.Windows.Forms.Label
		Me._Label1_24 = New System.Windows.Forms.Label
		Me._Label1_23 = New System.Windows.Forms.Label
		Me._Label1_21 = New System.Windows.Forms.Label
		Me._Label1_22 = New System.Windows.Forms.Label
		Me.Label2 = New System.Windows.Forms.Label
		Me._Label1_20 = New System.Windows.Forms.Label
		Me._Label1_19 = New System.Windows.Forms.Label
		Me._Label1_18 = New System.Windows.Forms.Label
		Me._Label1_17 = New System.Windows.Forms.Label
		Me._Label1_16 = New System.Windows.Forms.Label
		Me._Label1_15 = New System.Windows.Forms.Label
		Me._Frame1_2 = New System.Windows.Forms.GroupBox
		Me.VScroll1 = New System.Windows.Forms.VScrollBar
		Me._ctlMeisai1_0 = New ctlKeiyaku
		Me._imText3_0 = New imText6.imText
		Me._ctlMeisai1_1 = New ctlKeiyaku
		Me._ctlMeisai1_2 = New ctlKeiyaku
		Me._imText3_1 = New imText6.imText
		Me._imText3_2 = New imText6.imText
		Me._imText3_3 = New imText6.imText
		Me._Label1_10 = New System.Windows.Forms.Label
		Me._Label1_11 = New System.Windows.Forms.Label
		Me._Label1_14 = New System.Windows.Forms.Label
		Me._Label1_9 = New System.Windows.Forms.Label
		Me._Label1_8 = New System.Windows.Forms.Label
		Me._Label1_7 = New System.Windows.Forms.Label
		Me._Label1_13 = New System.Windows.Forms.Label
		Me._Label1_12 = New System.Windows.Forms.Label
		Me._Frame1_1 = New System.Windows.Forms.GroupBox
		Me._imNumber1_0 = New imNumber6.imNumber
		Me._imNumber1_1 = New imNumber6.imNumber
		Me._imNumber1_2 = New imNumber6.imNumber
		Me._Label1_42 = New System.Windows.Forms.Label
		Me._Label1_41 = New System.Windows.Forms.Label
		Me._Label1_40 = New System.Windows.Forms.Label
		Me._Label1_6 = New System.Windows.Forms.Label
		Me._Label1_5 = New System.Windows.Forms.Label
		Me._Label1_4 = New System.Windows.Forms.Label
		Me._Frame1_0 = New System.Windows.Forms.GroupBox
		Me.Check1 = New System.Windows.Forms.CheckBox
		Me._imText1_0 = New imText6.imText
		Me._imText1_3 = New imText6.imText
		Me._imText1_2 = New imText6.imText
		Me._imText1_1 = New imText6.imText
		Me._Label1_1 = New System.Windows.Forms.Label
		Me._Label1_0 = New System.Windows.Forms.Label
		Me._Label1_2 = New System.Windows.Forms.Label
		Me.Picture1 = New System.Windows.Forms.Panel
		Me._cmdKey_3 = New System.Windows.Forms.Button
		Me._cmdKey_12 = New System.Windows.Forms.Button
		Me._cmdKey_4 = New System.Windows.Forms.Button
		Me._cmdKey_10 = New System.Windows.Forms.Button
		Me._cmdKey_6 = New System.Windows.Forms.Button
		Me._cmdKey_7 = New System.Windows.Forms.Button
		Me._cmdKey_8 = New System.Windows.Forms.Button
		Me._cmdKey_9 = New System.Windows.Forms.Button
		Me._cmdKey_1 = New System.Windows.Forms.Button
		Me._cmdKey_11 = New System.Windows.Forms.Button
		Me._cmdKey_2 = New System.Windows.Forms.Button
		Me._cmdKey_5 = New System.Windows.Forms.Button
		Me.StatusBar1 = New System.Windows.Forms.StatusStrip
		Me._StatusBar1_Panel1 = New System.Windows.Forms.ToolStripStatusLabel
		Me._StatusBar1_Panel2 = New System.Windows.Forms.ToolStripStatusLabel
		Me._imText2_2 = New imText6.imText
		Me._imText2_0 = New imText6.imText
		Me._imText2_1 = New imText6.imText
		Me.lblTitle = New System.Windows.Forms.Label
		Me.Frame1 = New Microsoft.VisualBasic.Compatibility.VB6.GroupBoxArray(components)
		Me.Label1 = New Microsoft.VisualBasic.Compatibility.VB6.LabelArray(components)
		Me.cmdKey = New Microsoft.VisualBasic.Compatibility.VB6.ButtonArray(components)
		Me.ctlMeisai1 = New ctlKeiyakuArray(components)
		Me.ctlMeisai2 = New ctlIppanArray(components)
		Me.imNumber1 = New imNumberArray(components)
		Me.imNumber2 = New imNumberArray(components)
		Me.imText1 = New imTextArray(components)
		Me.imText2 = New imTextArray(components)
		Me.imText3 = New imTextArray(components)
		Me.imText4 = New imTextArray(components)
		Me._Frame1_4.SuspendLayout()
		Me.Picture2.SuspendLayout()
		Me._Frame1_3.SuspendLayout()
		Me._Frame1_2.SuspendLayout()
		Me._Frame1_1.SuspendLayout()
		Me._Frame1_0.SuspendLayout()
		Me.Picture1.SuspendLayout()
		Me.StatusBar1.SuspendLayout()
		Me.SuspendLayout()
		Me.ToolTip1.Active = True
		CType(Me._imText3_4, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imText3_5, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imText3_6, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imNumber2_5, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imNumber2_6, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imText3_7, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imText3_8, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imText4_0, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imNumber2_0, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imText4_2, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imText4_3, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imNumber2_1, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imText4_4, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imText4_5, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imText4_6, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imNumber2_3, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imText4_7, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imNumber2_4, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imNumber2_2, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imNumber2_7, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imNumber2_8, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imText3_0, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imText3_1, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imText3_2, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imText3_3, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imNumber1_0, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imNumber1_1, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imNumber1_2, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imText1_0, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imText1_3, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imText1_2, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imText1_1, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imText2_2, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imText2_0, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imText2_1, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.Frame1, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.Label1, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.cmdKey, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.ctlMeisai1, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.ctlMeisai2, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.imNumber1, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.imNumber2, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.imText1, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.imText2, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.imText3, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.imText4, System.ComponentModel.ISupportInitialize).BeginInit()
		Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
		Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
		Me.Text = "�H���Ǘ��V�X�e��"
		Me.ClientSize = New System.Drawing.Size(1016, 742)
		Me.Location = New System.Drawing.Point(4, 23)
		Me.Icon = CType(resources.GetObject("frmSYKD150.Icon"), System.Drawing.Icon)
		Me.KeyPreview = True
		Me.MaximizeBox = False
		Me.MinimizeBox = False
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.BackColor = System.Drawing.SystemColors.Control
		Me.ControlBox = True
		Me.Enabled = True
		Me.Cursor = System.Windows.Forms.Cursors.Default
		Me.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.ShowInTaskbar = True
		Me.HelpButton = False
		Me.WindowState = System.Windows.Forms.FormWindowState.Normal
		Me.Name = "frmSYKD150"
		Me._Frame1_4.Size = New System.Drawing.Size(1005, 237)
		Me._Frame1_4.Location = New System.Drawing.Point(4, 424)
		Me._Frame1_4.TabIndex = 89
		Me._Frame1_4.BackColor = System.Drawing.SystemColors.Control
		Me._Frame1_4.Enabled = True
		Me._Frame1_4.ForeColor = System.Drawing.SystemColors.ControlText
		Me._Frame1_4.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Frame1_4.Visible = True
		Me._Frame1_4.Padding = New System.Windows.Forms.Padding(0)
		Me._Frame1_4.Name = "_Frame1_4"
		Me.Picture2.Size = New System.Drawing.Size(661, 27)
		Me.Picture2.Location = New System.Drawing.Point(319, 204)
		Me.Picture2.TabIndex = 107
		Me.Picture2.TabStop = False
		Me.Picture2.Dock = System.Windows.Forms.DockStyle.None
		Me.Picture2.BackColor = System.Drawing.SystemColors.Control
		Me.Picture2.CausesValidation = True
		Me.Picture2.Enabled = True
		Me.Picture2.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Picture2.Cursor = System.Windows.Forms.Cursors.Default
		Me.Picture2.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Picture2.Visible = True
		Me.Picture2.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Picture2.Name = "Picture2"
		_imText3_4.OcxState = CType(resources.GetObject("_imText3_4.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imText3_4.Size = New System.Drawing.Size(128, 23)
		Me._imText3_4.Location = New System.Drawing.Point(0, 0)
		Me._imText3_4.TabIndex = 27
		Me._imText3_4.Name = "_imText3_4"
		_imText3_5.OcxState = CType(resources.GetObject("_imText3_5.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imText3_5.Size = New System.Drawing.Size(128, 23)
		Me._imText3_5.Location = New System.Drawing.Point(264, 0)
		Me._imText3_5.TabIndex = 29
		Me._imText3_5.Name = "_imText3_5"
		_imText3_6.OcxState = CType(resources.GetObject("_imText3_6.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imText3_6.Size = New System.Drawing.Size(128, 23)
		Me._imText3_6.Location = New System.Drawing.Point(526, 0)
		Me._imText3_6.TabIndex = 31
		Me._imText3_6.Name = "_imText3_6"
		_imNumber2_5.OcxState = CType(resources.GetObject("_imNumber2_5.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imNumber2_5.Size = New System.Drawing.Size(128, 23)
		Me._imNumber2_5.Location = New System.Drawing.Point(132, 0)
		Me._imNumber2_5.TabIndex = 28
		Me._imNumber2_5.Name = "_imNumber2_5"
		_imNumber2_6.OcxState = CType(resources.GetObject("_imNumber2_6.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imNumber2_6.Size = New System.Drawing.Size(128, 23)
		Me._imNumber2_6.Location = New System.Drawing.Point(395, 0)
		Me._imNumber2_6.TabIndex = 30
		Me._imNumber2_6.Name = "_imNumber2_6"
		Me._ctlMeisai2_0.Size = New System.Drawing.Size(973, 34)
		Me._ctlMeisai2_0.Location = New System.Drawing.Point(8, 40)
		Me._ctlMeisai2_0.TabIndex = 22
		Me._ctlMeisai2_0.Name = "_ctlMeisai2_0"
		Me.VScroll2.Size = New System.Drawing.Size(17, 135)
		Me.VScroll2.LargeChange = 4
		Me.VScroll2.Location = New System.Drawing.Point(981, 40)
		Me.VScroll2.TabIndex = 26
		Me.VScroll2.CausesValidation = True
		Me.VScroll2.Enabled = True
		Me.VScroll2.Maximum = 32770
		Me.VScroll2.Minimum = 0
		Me.VScroll2.Cursor = System.Windows.Forms.Cursors.Default
		Me.VScroll2.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.VScroll2.SmallChange = 1
		Me.VScroll2.TabStop = True
		Me.VScroll2.Value = 0
		Me.VScroll2.Visible = True
		Me.VScroll2.Name = "VScroll2"
		Me._ctlMeisai2_1.Size = New System.Drawing.Size(973, 34)
		Me._ctlMeisai2_1.Location = New System.Drawing.Point(8, 74)
		Me._ctlMeisai2_1.TabIndex = 23
		Me._ctlMeisai2_1.Name = "_ctlMeisai2_1"
		Me._ctlMeisai2_2.Size = New System.Drawing.Size(973, 34)
		Me._ctlMeisai2_2.Location = New System.Drawing.Point(8, 108)
		Me._ctlMeisai2_2.TabIndex = 24
		Me._ctlMeisai2_2.Name = "_ctlMeisai2_2"
		Me._ctlMeisai2_3.Size = New System.Drawing.Size(973, 36)
		Me._ctlMeisai2_3.Location = New System.Drawing.Point(8, 142)
		Me._ctlMeisai2_3.TabIndex = 25
		Me._ctlMeisai2_3.Name = "_ctlMeisai2_3"
		_imText3_7.OcxState = CType(resources.GetObject("_imText3_7.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imText3_7.Size = New System.Drawing.Size(128, 23)
		Me._imText3_7.Location = New System.Drawing.Point(182, 204)
		Me._imText3_7.TabIndex = 109
		Me._imText3_7.Visible = False
		Me._imText3_7.Name = "_imText3_7"
		_imText3_8.OcxState = CType(resources.GetObject("_imText3_8.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imText3_8.Size = New System.Drawing.Size(128, 23)
		Me._imText3_8.Location = New System.Drawing.Point(50, 204)
		Me._imText3_8.TabIndex = 110
		Me._imText3_8.Visible = False
		Me._imText3_8.Name = "_imText3_8"
		Me._Label1_44.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_44.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_44.Text = "�݌ɍ��v"
		Me._Label1_44.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_44.ForeColor = System.Drawing.Color.White
		Me._Label1_44.Size = New System.Drawing.Size(128, 23)
		Me._Label1_44.Location = New System.Drawing.Point(50, 180)
		Me._Label1_44.TabIndex = 111
		Me._Label1_44.Visible = False
		Me._Label1_44.Enabled = True
		Me._Label1_44.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_44.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_44.UseMnemonic = True
		Me._Label1_44.AutoSize = False
		Me._Label1_44.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_44.Name = "_Label1_44"
		Me._Label1_43.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_43.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_43.Text = "���v���z"
		Me._Label1_43.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_43.ForeColor = System.Drawing.Color.White
		Me._Label1_43.Size = New System.Drawing.Size(128, 23)
		Me._Label1_43.Location = New System.Drawing.Point(182, 180)
		Me._Label1_43.TabIndex = 108
		Me._Label1_43.Visible = False
		Me._Label1_43.Enabled = True
		Me._Label1_43.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_43.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_43.UseMnemonic = True
		Me._Label1_43.AutoSize = False
		Me._Label1_43.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_43.Name = "_Label1_43"
		Me._Label1_39.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_39.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_39.Text = "���������"
		Me._Label1_39.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_39.ForeColor = System.Drawing.Color.White
		Me._Label1_39.Size = New System.Drawing.Size(128, 23)
		Me._Label1_39.Location = New System.Drawing.Point(845, 180)
		Me._Label1_39.TabIndex = 102
		Me._Label1_39.Enabled = True
		Me._Label1_39.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_39.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_39.UseMnemonic = True
		Me._Label1_39.Visible = True
		Me._Label1_39.AutoSize = False
		Me._Label1_39.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_39.Name = "_Label1_39"
		Me._Label1_38.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_38.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_38.Text = "���S������"
		Me._Label1_38.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_38.ForeColor = System.Drawing.Color.White
		Me._Label1_38.Size = New System.Drawing.Size(128, 23)
		Me._Label1_38.Location = New System.Drawing.Point(714, 180)
		Me._Label1_38.TabIndex = 101
		Me._Label1_38.Enabled = True
		Me._Label1_38.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_38.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_38.UseMnemonic = True
		Me._Label1_38.Visible = True
		Me._Label1_38.AutoSize = False
		Me._Label1_38.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_38.Name = "_Label1_38"
		Me._Label1_37.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_37.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_37.Text = "���S������݌v"
		Me._Label1_37.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_37.ForeColor = System.Drawing.Color.White
		Me._Label1_37.Size = New System.Drawing.Size(128, 23)
		Me._Label1_37.Location = New System.Drawing.Point(583, 180)
		Me._Label1_37.TabIndex = 100
		Me._Label1_37.Enabled = True
		Me._Label1_37.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_37.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_37.UseMnemonic = True
		Me._Label1_37.Visible = True
		Me._Label1_37.AutoSize = False
		Me._Label1_37.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_37.Name = "_Label1_37"
		Me._Label1_36.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_36.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_36.Text = "��s������"
		Me._Label1_36.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_36.ForeColor = System.Drawing.Color.White
		Me._Label1_36.Size = New System.Drawing.Size(128, 23)
		Me._Label1_36.Location = New System.Drawing.Point(451, 180)
		Me._Label1_36.TabIndex = 99
		Me._Label1_36.Enabled = True
		Me._Label1_36.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_36.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_36.UseMnemonic = True
		Me._Label1_36.Visible = True
		Me._Label1_36.AutoSize = False
		Me._Label1_36.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_36.Name = "_Label1_36"
		Me._Label1_35.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_35.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_35.Text = "��s�����c�z"
		Me._Label1_35.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_35.ForeColor = System.Drawing.Color.White
		Me._Label1_35.Size = New System.Drawing.Size(128, 23)
		Me._Label1_35.Location = New System.Drawing.Point(319, 180)
		Me._Label1_35.TabIndex = 98
		Me._Label1_35.Enabled = True
		Me._Label1_35.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_35.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_35.UseMnemonic = True
		Me._Label1_35.Visible = True
		Me._Label1_35.AutoSize = False
		Me._Label1_35.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_35.Name = "_Label1_35"
		Me._Label1_30.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_30.Text = " �i���E�K�i"
		Me._Label1_30.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_30.ForeColor = System.Drawing.Color.White
		Me._Label1_30.Size = New System.Drawing.Size(211, 23)
		Me._Label1_30.Location = New System.Drawing.Point(294, 14)
		Me._Label1_30.TabIndex = 97
		Me._Label1_30.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me._Label1_30.Enabled = True
		Me._Label1_30.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_30.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_30.UseMnemonic = True
		Me._Label1_30.Visible = True
		Me._Label1_30.AutoSize = False
		Me._Label1_30.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_30.Name = "_Label1_30"
		Me._Label1_33.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_33.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_33.Text = "�P�@��"
		Me._Label1_33.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_33.ForeColor = System.Drawing.Color.White
		Me._Label1_33.Size = New System.Drawing.Size(128, 23)
		Me._Label1_33.Location = New System.Drawing.Point(715, 14)
		Me._Label1_33.TabIndex = 96
		Me._Label1_33.Enabled = True
		Me._Label1_33.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_33.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_33.UseMnemonic = True
		Me._Label1_33.Visible = True
		Me._Label1_33.AutoSize = False
		Me._Label1_33.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_33.Name = "_Label1_33"
		Me._Label1_34.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_34.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_34.Text = "���@�z"
		Me._Label1_34.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_34.ForeColor = System.Drawing.Color.White
		Me._Label1_34.Size = New System.Drawing.Size(128, 23)
		Me._Label1_34.Location = New System.Drawing.Point(846, 14)
		Me._Label1_34.TabIndex = 95
		Me._Label1_34.Enabled = True
		Me._Label1_34.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_34.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_34.UseMnemonic = True
		Me._Label1_34.Visible = True
		Me._Label1_34.AutoSize = False
		Me._Label1_34.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_34.Name = "_Label1_34"
		Me._Label1_27.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_27.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_27.Text = "��"
		Me._Label1_27.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_27.ForeColor = System.Drawing.Color.White
		Me._Label1_27.Size = New System.Drawing.Size(27, 23)
		Me._Label1_27.Location = New System.Drawing.Point(11, 14)
		Me._Label1_27.TabIndex = 94
		Me._Label1_27.Enabled = True
		Me._Label1_27.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_27.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_27.UseMnemonic = True
		Me._Label1_27.Visible = True
		Me._Label1_27.AutoSize = False
		Me._Label1_27.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_27.Name = "_Label1_27"
		Me._Label1_28.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_28.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_28.Text = "�Ǝк���"
		Me._Label1_28.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_28.ForeColor = System.Drawing.Color.White
		Me._Label1_28.Size = New System.Drawing.Size(86, 23)
		Me._Label1_28.Location = New System.Drawing.Point(42, 14)
		Me._Label1_28.TabIndex = 93
		Me._Label1_28.Enabled = True
		Me._Label1_28.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_28.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_28.UseMnemonic = True
		Me._Label1_28.Visible = True
		Me._Label1_28.AutoSize = False
		Me._Label1_28.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_28.Name = "_Label1_28"
		Me._Label1_29.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_29.Text = " �ƎЖ�"
		Me._Label1_29.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_29.ForeColor = System.Drawing.Color.White
		Me._Label1_29.Size = New System.Drawing.Size(160, 23)
		Me._Label1_29.Location = New System.Drawing.Point(130, 14)
		Me._Label1_29.TabIndex = 92
		Me._Label1_29.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me._Label1_29.Enabled = True
		Me._Label1_29.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_29.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_29.UseMnemonic = True
		Me._Label1_29.Visible = True
		Me._Label1_29.AutoSize = False
		Me._Label1_29.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_29.Name = "_Label1_29"
		Me._Label1_32.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_32.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_32.Text = "�� ��"
		Me._Label1_32.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_32.ForeColor = System.Drawing.Color.White
		Me._Label1_32.Size = New System.Drawing.Size(100, 23)
		Me._Label1_32.Location = New System.Drawing.Point(612, 14)
		Me._Label1_32.TabIndex = 91
		Me._Label1_32.Enabled = True
		Me._Label1_32.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_32.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_32.UseMnemonic = True
		Me._Label1_32.Visible = True
		Me._Label1_32.AutoSize = False
		Me._Label1_32.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_32.Name = "_Label1_32"
		Me._Label1_31.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_31.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_31.Text = "�� ��"
		Me._Label1_31.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_31.ForeColor = System.Drawing.Color.White
		Me._Label1_31.Size = New System.Drawing.Size(100, 23)
		Me._Label1_31.Location = New System.Drawing.Point(509, 14)
		Me._Label1_31.TabIndex = 90
		Me._Label1_31.Enabled = True
		Me._Label1_31.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_31.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_31.UseMnemonic = True
		Me._Label1_31.Visible = True
		Me._Label1_31.AutoSize = False
		Me._Label1_31.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_31.Name = "_Label1_31"
		Me._Frame1_3.Size = New System.Drawing.Size(1005, 147)
		Me._Frame1_3.Location = New System.Drawing.Point(4, 276)
		Me._Frame1_3.TabIndex = 75
		Me._Frame1_3.BackColor = System.Drawing.SystemColors.Control
		Me._Frame1_3.Enabled = True
		Me._Frame1_3.ForeColor = System.Drawing.SystemColors.ControlText
		Me._Frame1_3.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Frame1_3.Visible = True
		Me._Frame1_3.Padding = New System.Windows.Forms.Padding(0)
		Me._Frame1_3.Name = "_Frame1_3"
		_imText4_0.OcxState = CType(resources.GetObject("_imText4_0.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imText4_0.Size = New System.Drawing.Size(128, 23)
		Me._imText4_0.Location = New System.Drawing.Point(16, 106)
		Me._imText4_0.TabIndex = 9
		Me._imText4_0.Name = "_imText4_0"
		_imNumber2_0.OcxState = CType(resources.GetObject("_imNumber2_0.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imNumber2_0.Size = New System.Drawing.Size(128, 23)
		Me._imNumber2_0.Location = New System.Drawing.Point(16, 48)
		Me._imNumber2_0.TabIndex = 8
		Me._imNumber2_0.Name = "_imNumber2_0"
		_imText4_2.OcxState = CType(resources.GetObject("_imText4_2.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imText4_2.Size = New System.Drawing.Size(128, 23)
		Me._imText4_2.Location = New System.Drawing.Point(160, 106)
		Me._imText4_2.TabIndex = 11
		Me._imText4_2.Name = "_imText4_2"
		_imText4_3.OcxState = CType(resources.GetObject("_imText4_3.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imText4_3.Size = New System.Drawing.Size(128, 23)
		Me._imText4_3.Location = New System.Drawing.Point(306, 48)
		Me._imText4_3.TabIndex = 12
		Me._imText4_3.Name = "_imText4_3"
		_imNumber2_1.OcxState = CType(resources.GetObject("_imNumber2_1.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imNumber2_1.Size = New System.Drawing.Size(40, 23)
		Me._imNumber2_1.Location = New System.Drawing.Point(306, 106)
		Me._imNumber2_1.TabIndex = 13
		Me._imNumber2_1.Name = "_imNumber2_1"
		_imText4_4.OcxState = CType(resources.GetObject("_imText4_4.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imText4_4.Size = New System.Drawing.Size(128, 23)
		Me._imText4_4.Location = New System.Drawing.Point(374, 106)
		Me._imText4_4.TabIndex = 14
		Me._imText4_4.Name = "_imText4_4"
		_imText4_5.OcxState = CType(resources.GetObject("_imText4_5.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imText4_5.Size = New System.Drawing.Size(128, 23)
		Me._imText4_5.Location = New System.Drawing.Point(518, 48)
		Me._imText4_5.TabIndex = 15
		Me._imText4_5.Name = "_imText4_5"
		_imText4_6.OcxState = CType(resources.GetObject("_imText4_6.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imText4_6.Size = New System.Drawing.Size(128, 23)
		Me._imText4_6.Location = New System.Drawing.Point(660, 48)
		Me._imText4_6.TabIndex = 17
		Me._imText4_6.Name = "_imText4_6"
		_imNumber2_3.OcxState = CType(resources.GetObject("_imNumber2_3.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imNumber2_3.Size = New System.Drawing.Size(128, 23)
		Me._imNumber2_3.Location = New System.Drawing.Point(660, 106)
		Me._imNumber2_3.TabIndex = 18
		Me._imNumber2_3.Name = "_imNumber2_3"
		_imText4_7.OcxState = CType(resources.GetObject("_imText4_7.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imText4_7.Size = New System.Drawing.Size(128, 23)
		Me._imText4_7.Location = New System.Drawing.Point(860, 106)
		Me._imText4_7.TabIndex = 21
		Me._imText4_7.Name = "_imText4_7"
		_imNumber2_4.OcxState = CType(resources.GetObject("_imNumber2_4.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imNumber2_4.Size = New System.Drawing.Size(128, 23)
		Me._imNumber2_4.Location = New System.Drawing.Point(860, 48)
		Me._imNumber2_4.TabIndex = 20
		Me._imNumber2_4.Name = "_imNumber2_4"
		_imNumber2_2.OcxState = CType(resources.GetObject("_imNumber2_2.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imNumber2_2.Size = New System.Drawing.Size(128, 23)
		Me._imNumber2_2.Location = New System.Drawing.Point(518, 106)
		Me._imNumber2_2.TabIndex = 16
		Me._imNumber2_2.Name = "_imNumber2_2"
		_imNumber2_7.OcxState = CType(resources.GetObject("_imNumber2_7.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imNumber2_7.Size = New System.Drawing.Size(128, 23)
		Me._imNumber2_7.Location = New System.Drawing.Point(160, 48)
		Me._imNumber2_7.TabIndex = 10
		Me._imNumber2_7.Name = "_imNumber2_7"
		_imNumber2_8.OcxState = CType(resources.GetObject("_imNumber2_8.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imNumber2_8.Size = New System.Drawing.Size(30, 23)
		Me._imNumber2_8.Location = New System.Drawing.Point(798, 106)
		Me._imNumber2_8.TabIndex = 19
		Me._imNumber2_8.Name = "_imNumber2_8"
		Me._Label1_46.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_46.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_46.Text = "�ŗ�"
		Me._Label1_46.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_46.ForeColor = System.Drawing.Color.White
		Me._Label1_46.Size = New System.Drawing.Size(52, 23)
		Me._Label1_46.Location = New System.Drawing.Point(798, 82)
		Me._Label1_46.TabIndex = 113
		Me._Label1_46.Enabled = True
		Me._Label1_46.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_46.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_46.UseMnemonic = True
		Me._Label1_46.Visible = True
		Me._Label1_46.AutoSize = False
		Me._Label1_46.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_46.Name = "_Label1_46"
		Me._Label1_45.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_45.BackColor = System.Drawing.Color.Transparent
		Me._Label1_45.Text = "��"
		Me._Label1_45.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_45.ForeColor = System.Drawing.Color.Black
		Me._Label1_45.Size = New System.Drawing.Size(18, 16)
		Me._Label1_45.Location = New System.Drawing.Point(829, 109)
		Me._Label1_45.TabIndex = 112
		Me._Label1_45.Enabled = True
		Me._Label1_45.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_45.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_45.UseMnemonic = True
		Me._Label1_45.Visible = True
		Me._Label1_45.AutoSize = True
		Me._Label1_45.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._Label1_45.Name = "_Label1_45"
		Me._Label1_3.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_3.BackColor = System.Drawing.Color.Transparent
		Me._Label1_3.Text = "��"
		Me._Label1_3.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_3.ForeColor = System.Drawing.Color.Black
		Me._Label1_3.Size = New System.Drawing.Size(18, 16)
		Me._Label1_3.Location = New System.Drawing.Point(350, 110)
		Me._Label1_3.TabIndex = 103
		Me._Label1_3.Enabled = True
		Me._Label1_3.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_3.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_3.UseMnemonic = True
		Me._Label1_3.Visible = True
		Me._Label1_3.AutoSize = True
		Me._Label1_3.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._Label1_3.Name = "_Label1_3"
		Me._Label1_25.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_25.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_25.Text = "���񐿋��z"
		Me._Label1_25.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_25.ForeColor = System.Drawing.Color.White
		Me._Label1_25.Size = New System.Drawing.Size(128, 23)
		Me._Label1_25.Location = New System.Drawing.Point(860, 24)
		Me._Label1_25.TabIndex = 88
		Me._Label1_25.Enabled = True
		Me._Label1_25.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_25.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_25.UseMnemonic = True
		Me._Label1_25.Visible = True
		Me._Label1_25.AutoSize = False
		Me._Label1_25.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_25.Name = "_Label1_25"
		Me._Label1_26.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_26.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_26.Text = "�x���c�z"
		Me._Label1_26.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_26.ForeColor = System.Drawing.Color.White
		Me._Label1_26.Size = New System.Drawing.Size(128, 23)
		Me._Label1_26.Location = New System.Drawing.Point(860, 82)
		Me._Label1_26.TabIndex = 87
		Me._Label1_26.Enabled = True
		Me._Label1_26.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_26.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_26.UseMnemonic = True
		Me._Label1_26.Visible = True
		Me._Label1_26.AutoSize = False
		Me._Label1_26.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_26.Name = "_Label1_26"
		Me._Label1_24.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_24.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_24.Text = "����x���z"
		Me._Label1_24.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_24.ForeColor = System.Drawing.Color.White
		Me._Label1_24.Size = New System.Drawing.Size(128, 23)
		Me._Label1_24.Location = New System.Drawing.Point(660, 82)
		Me._Label1_24.TabIndex = 86
		Me._Label1_24.Enabled = True
		Me._Label1_24.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_24.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_24.UseMnemonic = True
		Me._Label1_24.Visible = True
		Me._Label1_24.AutoSize = False
		Me._Label1_24.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_24.Name = "_Label1_24"
		Me._Label1_23.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_23.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_23.Text = "�x���\�z"
		Me._Label1_23.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_23.ForeColor = System.Drawing.Color.White
		Me._Label1_23.Size = New System.Drawing.Size(128, 23)
		Me._Label1_23.Location = New System.Drawing.Point(660, 24)
		Me._Label1_23.TabIndex = 85
		Me._Label1_23.Enabled = True
		Me._Label1_23.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_23.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_23.UseMnemonic = True
		Me._Label1_23.Visible = True
		Me._Label1_23.AutoSize = False
		Me._Label1_23.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_23.Name = "_Label1_23"
		Me._Label1_21.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_21.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_21.Text = "�O�񖘎x���z"
		Me._Label1_21.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_21.ForeColor = System.Drawing.Color.White
		Me._Label1_21.Size = New System.Drawing.Size(128, 23)
		Me._Label1_21.Location = New System.Drawing.Point(518, 24)
		Me._Label1_21.TabIndex = 84
		Me._Label1_21.Enabled = True
		Me._Label1_21.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_21.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_21.UseMnemonic = True
		Me._Label1_21.Visible = True
		Me._Label1_21.AutoSize = False
		Me._Label1_21.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_21.Name = "_Label1_21"
		Me._Label1_22.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_22.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_22.Text = "�x�������z"
		Me._Label1_22.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_22.ForeColor = System.Drawing.Color.White
		Me._Label1_22.Size = New System.Drawing.Size(128, 23)
		Me._Label1_22.Location = New System.Drawing.Point(518, 82)
		Me._Label1_22.TabIndex = 83
		Me._Label1_22.Enabled = True
		Me._Label1_22.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_22.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_22.UseMnemonic = True
		Me._Label1_22.Visible = True
		Me._Label1_22.AutoSize = False
		Me._Label1_22.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_22.Name = "_Label1_22"
		Me.Label2.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me.Label2.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me.Label2.Text = "�����v100��"
		Me.Label2.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me.Label2.ForeColor = System.Drawing.Color.White
		Me.Label2.Size = New System.Drawing.Size(128, 23)
		Me.Label2.Location = New System.Drawing.Point(374, 82)
		Me.Label2.TabIndex = 82
		Me.Label2.Enabled = True
		Me.Label2.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label2.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label2.UseMnemonic = True
		Me.Label2.Visible = True
		Me.Label2.AutoSize = False
		Me.Label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.Label2.Name = "Label2"
		Me._Label1_20.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_20.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_20.Text = "��"
		Me._Label1_20.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_20.ForeColor = System.Drawing.Color.White
		Me._Label1_20.Size = New System.Drawing.Size(66, 23)
		Me._Label1_20.Location = New System.Drawing.Point(306, 82)
		Me._Label1_20.TabIndex = 81
		Me._Label1_20.Enabled = True
		Me._Label1_20.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_20.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_20.UseMnemonic = True
		Me._Label1_20.Visible = True
		Me._Label1_20.AutoSize = False
		Me._Label1_20.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_20.Name = "_Label1_20"
		Me._Label1_19.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_19.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_19.Text = "�� �� �v"
		Me._Label1_19.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_19.ForeColor = System.Drawing.Color.White
		Me._Label1_19.Size = New System.Drawing.Size(128, 23)
		Me._Label1_19.Location = New System.Drawing.Point(306, 24)
		Me._Label1_19.TabIndex = 80
		Me._Label1_19.Enabled = True
		Me._Label1_19.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_19.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_19.UseMnemonic = True
		Me._Label1_19.Visible = True
		Me._Label1_19.AutoSize = False
		Me._Label1_19.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_19.Name = "_Label1_19"
		Me._Label1_18.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_18.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_18.Text = "���������"
		Me._Label1_18.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_18.ForeColor = System.Drawing.Color.White
		Me._Label1_18.Size = New System.Drawing.Size(128, 23)
		Me._Label1_18.Location = New System.Drawing.Point(160, 82)
		Me._Label1_18.TabIndex = 79
		Me._Label1_18.Enabled = True
		Me._Label1_18.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_18.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_18.UseMnemonic = True
		Me._Label1_18.Visible = True
		Me._Label1_18.AutoSize = False
		Me._Label1_18.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_18.Name = "_Label1_18"
		Me._Label1_17.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_17.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_17.Text = "�O�񖘈�����"
		Me._Label1_17.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_17.ForeColor = System.Drawing.Color.White
		Me._Label1_17.Size = New System.Drawing.Size(128, 23)
		Me._Label1_17.Location = New System.Drawing.Point(160, 24)
		Me._Label1_17.TabIndex = 78
		Me._Label1_17.Enabled = True
		Me._Label1_17.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_17.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_17.UseMnemonic = True
		Me._Label1_17.Visible = True
		Me._Label1_17.AutoSize = False
		Me._Label1_17.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_17.Name = "_Label1_17"
		Me._Label1_16.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_16.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_16.Text = "���o����"
		Me._Label1_16.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_16.ForeColor = System.Drawing.Color.White
		Me._Label1_16.Size = New System.Drawing.Size(128, 23)
		Me._Label1_16.Location = New System.Drawing.Point(16, 82)
		Me._Label1_16.TabIndex = 77
		Me._Label1_16.Enabled = True
		Me._Label1_16.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_16.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_16.UseMnemonic = True
		Me._Label1_16.Visible = True
		Me._Label1_16.AutoSize = False
		Me._Label1_16.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_16.Name = "_Label1_16"
		Me._Label1_15.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_15.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_15.Text = "�_����z"
		Me._Label1_15.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_15.ForeColor = System.Drawing.Color.White
		Me._Label1_15.Size = New System.Drawing.Size(128, 23)
		Me._Label1_15.Location = New System.Drawing.Point(16, 24)
		Me._Label1_15.TabIndex = 76
		Me._Label1_15.Enabled = True
		Me._Label1_15.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_15.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_15.UseMnemonic = True
		Me._Label1_15.Visible = True
		Me._Label1_15.AutoSize = False
		Me._Label1_15.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_15.Name = "_Label1_15"
		Me._Frame1_2.Size = New System.Drawing.Size(1005, 169)
		Me._Frame1_2.Location = New System.Drawing.Point(4, 106)
		Me._Frame1_2.TabIndex = 65
		Me._Frame1_2.BackColor = System.Drawing.SystemColors.Control
		Me._Frame1_2.Enabled = True
		Me._Frame1_2.ForeColor = System.Drawing.SystemColors.ControlText
		Me._Frame1_2.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Frame1_2.Visible = True
		Me._Frame1_2.Padding = New System.Windows.Forms.Padding(0)
		Me._Frame1_2.Name = "_Frame1_2"
		Me.VScroll1.Size = New System.Drawing.Size(17, 97)
		Me.VScroll1.LargeChange = 3
		Me.VScroll1.Location = New System.Drawing.Point(875, 40)
		Me.VScroll1.TabIndex = 3
		Me.VScroll1.CausesValidation = True
		Me.VScroll1.Enabled = True
		Me.VScroll1.Maximum = 32769
		Me.VScroll1.Minimum = 0
		Me.VScroll1.Cursor = System.Windows.Forms.Cursors.Default
		Me.VScroll1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.VScroll1.SmallChange = 1
		Me.VScroll1.TabStop = True
		Me.VScroll1.Value = 0
		Me.VScroll1.Visible = True
		Me.VScroll1.Name = "VScroll1"
		Me._ctlMeisai1_0.Size = New System.Drawing.Size(875, 33)
		Me._ctlMeisai1_0.Location = New System.Drawing.Point(8, 40)
		Me._ctlMeisai1_0.TabIndex = 0
		Me._ctlMeisai1_0.Name = "_ctlMeisai1_0"
		_imText3_0.OcxState = CType(resources.GetObject("_imText3_0.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imText3_0.Size = New System.Drawing.Size(128, 23)
		Me._imText3_0.Location = New System.Drawing.Point(347, 138)
		Me._imText3_0.TabIndex = 4
		Me._imText3_0.Name = "_imText3_0"
		Me._ctlMeisai1_1.Size = New System.Drawing.Size(875, 33)
		Me._ctlMeisai1_1.Location = New System.Drawing.Point(8, 72)
		Me._ctlMeisai1_1.TabIndex = 1
		Me._ctlMeisai1_1.Name = "_ctlMeisai1_1"
		Me._ctlMeisai1_2.Size = New System.Drawing.Size(875, 33)
		Me._ctlMeisai1_2.Location = New System.Drawing.Point(8, 104)
		Me._ctlMeisai1_2.TabIndex = 2
		Me._ctlMeisai1_2.Name = "_ctlMeisai1_2"
		_imText3_1.OcxState = CType(resources.GetObject("_imText3_1.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imText3_1.Size = New System.Drawing.Size(128, 23)
		Me._imText3_1.Location = New System.Drawing.Point(478, 138)
		Me._imText3_1.TabIndex = 5
		Me._imText3_1.Name = "_imText3_1"
		_imText3_2.OcxState = CType(resources.GetObject("_imText3_2.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imText3_2.Size = New System.Drawing.Size(128, 23)
		Me._imText3_2.Location = New System.Drawing.Point(609, 138)
		Me._imText3_2.TabIndex = 6
		Me._imText3_2.Name = "_imText3_2"
		_imText3_3.OcxState = CType(resources.GetObject("_imText3_3.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imText3_3.Size = New System.Drawing.Size(128, 23)
		Me._imText3_3.Location = New System.Drawing.Point(740, 138)
		Me._imText3_3.TabIndex = 7
		Me._imText3_3.Name = "_imText3_3"
		Me._Label1_10.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_10.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_10.Text = "�_�񌈒�z"
		Me._Label1_10.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_10.ForeColor = System.Drawing.Color.White
		Me._Label1_10.Size = New System.Drawing.Size(128, 23)
		Me._Label1_10.Location = New System.Drawing.Point(347, 14)
		Me._Label1_10.TabIndex = 74
		Me._Label1_10.Enabled = True
		Me._Label1_10.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_10.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_10.UseMnemonic = True
		Me._Label1_10.Visible = True
		Me._Label1_10.AutoSize = False
		Me._Label1_10.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_10.Name = "_Label1_10"
		Me._Label1_11.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_11.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_11.Text = "����o����"
		Me._Label1_11.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_11.ForeColor = System.Drawing.Color.White
		Me._Label1_11.Size = New System.Drawing.Size(128, 23)
		Me._Label1_11.Location = New System.Drawing.Point(478, 14)
		Me._Label1_11.TabIndex = 73
		Me._Label1_11.Enabled = True
		Me._Label1_11.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_11.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_11.UseMnemonic = True
		Me._Label1_11.Visible = True
		Me._Label1_11.AutoSize = False
		Me._Label1_11.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_11.Name = "_Label1_11"
		Me._Label1_14.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_14.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_14.Text = "���@�v"
		Me._Label1_14.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_14.ForeColor = System.Drawing.Color.White
		Me._Label1_14.Size = New System.Drawing.Size(128, 23)
		Me._Label1_14.Location = New System.Drawing.Point(215, 138)
		Me._Label1_14.TabIndex = 72
		Me._Label1_14.Enabled = True
		Me._Label1_14.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_14.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_14.UseMnemonic = True
		Me._Label1_14.Visible = True
		Me._Label1_14.AutoSize = False
		Me._Label1_14.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_14.Name = "_Label1_14"
		Me._Label1_9.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_9.Text = " �H�햼"
		Me._Label1_9.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_9.ForeColor = System.Drawing.Color.White
		Me._Label1_9.Size = New System.Drawing.Size(250, 23)
		Me._Label1_9.Location = New System.Drawing.Point(94, 14)
		Me._Label1_9.TabIndex = 71
		Me._Label1_9.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me._Label1_9.Enabled = True
		Me._Label1_9.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_9.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_9.UseMnemonic = True
		Me._Label1_9.Visible = True
		Me._Label1_9.AutoSize = False
		Me._Label1_9.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_9.Name = "_Label1_9"
		Me._Label1_8.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_8.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_8.Text = "�H��"
		Me._Label1_8.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_8.ForeColor = System.Drawing.Color.White
		Me._Label1_8.Size = New System.Drawing.Size(50, 23)
		Me._Label1_8.Location = New System.Drawing.Point(42, 14)
		Me._Label1_8.TabIndex = 70
		Me._Label1_8.Enabled = True
		Me._Label1_8.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_8.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_8.UseMnemonic = True
		Me._Label1_8.Visible = True
		Me._Label1_8.AutoSize = False
		Me._Label1_8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_8.Name = "_Label1_8"
		Me._Label1_7.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_7.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_7.Text = "��"
		Me._Label1_7.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_7.ForeColor = System.Drawing.Color.White
		Me._Label1_7.Size = New System.Drawing.Size(27, 23)
		Me._Label1_7.Location = New System.Drawing.Point(11, 14)
		Me._Label1_7.TabIndex = 69
		Me._Label1_7.Enabled = True
		Me._Label1_7.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_7.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_7.UseMnemonic = True
		Me._Label1_7.Visible = True
		Me._Label1_7.AutoSize = False
		Me._Label1_7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_7.Name = "_Label1_7"
		Me._Label1_13.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_13.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_13.Text = "����x���z"
		Me._Label1_13.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_13.ForeColor = System.Drawing.Color.White
		Me._Label1_13.Size = New System.Drawing.Size(128, 23)
		Me._Label1_13.Location = New System.Drawing.Point(740, 14)
		Me._Label1_13.TabIndex = 68
		Me._Label1_13.Enabled = True
		Me._Label1_13.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_13.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_13.UseMnemonic = True
		Me._Label1_13.Visible = True
		Me._Label1_13.AutoSize = False
		Me._Label1_13.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_13.Name = "_Label1_13"
		Me._Label1_12.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_12.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_12.Text = "�o�����݌v"
		Me._Label1_12.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_12.ForeColor = System.Drawing.Color.White
		Me._Label1_12.Size = New System.Drawing.Size(128, 23)
		Me._Label1_12.Location = New System.Drawing.Point(609, 14)
		Me._Label1_12.TabIndex = 67
		Me._Label1_12.Enabled = True
		Me._Label1_12.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_12.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_12.UseMnemonic = True
		Me._Label1_12.Visible = True
		Me._Label1_12.AutoSize = False
		Me._Label1_12.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_12.Name = "_Label1_12"
		Me._Frame1_1.Text = "�x���䗦"
		Me._Frame1_1.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Frame1_1.ForeColor = System.Drawing.Color.FromARGB(0, 0, 192)
		Me._Frame1_1.Size = New System.Drawing.Size(437, 59)
		Me._Frame1_1.Location = New System.Drawing.Point(572, 46)
		Me._Frame1_1.TabIndex = 61
		Me._Frame1_1.BackColor = System.Drawing.SystemColors.Control
		Me._Frame1_1.Enabled = True
		Me._Frame1_1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Frame1_1.Visible = True
		Me._Frame1_1.Padding = New System.Windows.Forms.Padding(0)
		Me._Frame1_1.Name = "_Frame1_1"
		_imNumber1_0.OcxState = CType(resources.GetObject("_imNumber1_0.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imNumber1_0.Size = New System.Drawing.Size(39, 23)
		Me._imNumber1_0.Location = New System.Drawing.Point(86, 22)
		Me._imNumber1_0.TabIndex = 49
		Me._imNumber1_0.Name = "_imNumber1_0"
		_imNumber1_1.OcxState = CType(resources.GetObject("_imNumber1_1.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imNumber1_1.Size = New System.Drawing.Size(39, 23)
		Me._imNumber1_1.Location = New System.Drawing.Point(224, 22)
		Me._imNumber1_1.TabIndex = 50
		Me._imNumber1_1.Name = "_imNumber1_1"
		_imNumber1_2.OcxState = CType(resources.GetObject("_imNumber1_2.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imNumber1_2.Size = New System.Drawing.Size(39, 23)
		Me._imNumber1_2.Location = New System.Drawing.Point(362, 22)
		Me._imNumber1_2.TabIndex = 51
		Me._imNumber1_2.Name = "_imNumber1_2"
		Me._Label1_42.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_42.BackColor = System.Drawing.Color.Transparent
		Me._Label1_42.Text = "��"
		Me._Label1_42.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_42.ForeColor = System.Drawing.Color.Black
		Me._Label1_42.Size = New System.Drawing.Size(18, 16)
		Me._Label1_42.Location = New System.Drawing.Point(404, 26)
		Me._Label1_42.TabIndex = 106
		Me._Label1_42.Enabled = True
		Me._Label1_42.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_42.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_42.UseMnemonic = True
		Me._Label1_42.Visible = True
		Me._Label1_42.AutoSize = True
		Me._Label1_42.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._Label1_42.Name = "_Label1_42"
		Me._Label1_41.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_41.BackColor = System.Drawing.Color.Transparent
		Me._Label1_41.Text = "��"
		Me._Label1_41.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_41.ForeColor = System.Drawing.Color.Black
		Me._Label1_41.Size = New System.Drawing.Size(18, 16)
		Me._Label1_41.Location = New System.Drawing.Point(266, 26)
		Me._Label1_41.TabIndex = 105
		Me._Label1_41.Enabled = True
		Me._Label1_41.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_41.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_41.UseMnemonic = True
		Me._Label1_41.Visible = True
		Me._Label1_41.AutoSize = True
		Me._Label1_41.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._Label1_41.Name = "_Label1_41"
		Me._Label1_40.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_40.BackColor = System.Drawing.Color.Transparent
		Me._Label1_40.Text = "��"
		Me._Label1_40.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_40.ForeColor = System.Drawing.Color.Black
		Me._Label1_40.Size = New System.Drawing.Size(18, 16)
		Me._Label1_40.Location = New System.Drawing.Point(128, 26)
		Me._Label1_40.TabIndex = 104
		Me._Label1_40.Enabled = True
		Me._Label1_40.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_40.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_40.UseMnemonic = True
		Me._Label1_40.Visible = True
		Me._Label1_40.AutoSize = True
		Me._Label1_40.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._Label1_40.Name = "_Label1_40"
		Me._Label1_6.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_6.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_6.Text = "��`"
		Me._Label1_6.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_6.ForeColor = System.Drawing.Color.White
		Me._Label1_6.Size = New System.Drawing.Size(67, 23)
		Me._Label1_6.Location = New System.Drawing.Point(292, 22)
		Me._Label1_6.TabIndex = 64
		Me._Label1_6.Enabled = True
		Me._Label1_6.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_6.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_6.UseMnemonic = True
		Me._Label1_6.Visible = True
		Me._Label1_6.AutoSize = False
		Me._Label1_6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_6.Name = "_Label1_6"
		Me._Label1_5.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_5.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_5.Text = "����"
		Me._Label1_5.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_5.ForeColor = System.Drawing.Color.White
		Me._Label1_5.Size = New System.Drawing.Size(67, 23)
		Me._Label1_5.Location = New System.Drawing.Point(154, 22)
		Me._Label1_5.TabIndex = 63
		Me._Label1_5.Enabled = True
		Me._Label1_5.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_5.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_5.UseMnemonic = True
		Me._Label1_5.Visible = True
		Me._Label1_5.AutoSize = False
		Me._Label1_5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_5.Name = "_Label1_5"
		Me._Label1_4.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_4.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_4.Text = "�U��"
		Me._Label1_4.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_4.ForeColor = System.Drawing.Color.White
		Me._Label1_4.Size = New System.Drawing.Size(67, 23)
		Me._Label1_4.Location = New System.Drawing.Point(16, 22)
		Me._Label1_4.TabIndex = 62
		Me._Label1_4.Enabled = True
		Me._Label1_4.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_4.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_4.UseMnemonic = True
		Me._Label1_4.Visible = True
		Me._Label1_4.AutoSize = False
		Me._Label1_4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_4.Name = "_Label1_4"
		Me._Frame1_0.Size = New System.Drawing.Size(559, 71)
		Me._Frame1_0.Location = New System.Drawing.Point(4, 34)
		Me._Frame1_0.TabIndex = 58
		Me._Frame1_0.BackColor = System.Drawing.SystemColors.Control
		Me._Frame1_0.Enabled = True
		Me._Frame1_0.ForeColor = System.Drawing.SystemColors.ControlText
		Me._Frame1_0.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Frame1_0.Visible = True
		Me._Frame1_0.Padding = New System.Windows.Forms.Padding(0)
		Me._Frame1_0.Name = "_Frame1_0"
		Me.Check1.Text = "���Z"
		Me.Check1.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me.Check1.Size = New System.Drawing.Size(59, 23)
		Me.Check1.Location = New System.Drawing.Point(494, 14)
		Me.Check1.TabIndex = 48
		Me.Check1.Tag = "���Z�ς̏ꍇ�̓`�F�b�N���ĉ������B"
		Me.Check1.CheckAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me.Check1.FlatStyle = System.Windows.Forms.FlatStyle.Standard
		Me.Check1.BackColor = System.Drawing.SystemColors.Control
		Me.Check1.CausesValidation = True
		Me.Check1.Enabled = True
		Me.Check1.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Check1.Cursor = System.Windows.Forms.Cursors.Default
		Me.Check1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Check1.Appearance = System.Windows.Forms.Appearance.Normal
		Me.Check1.TabStop = True
		Me.Check1.CheckState = System.Windows.Forms.CheckState.Unchecked
		Me.Check1.Visible = True
		Me.Check1.Name = "Check1"
		_imText1_0.OcxState = CType(resources.GetObject("_imText1_0.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imText1_0.CausesValidation = False
		Me._imText1_0.Size = New System.Drawing.Size(73, 23)
		Me._imText1_0.Location = New System.Drawing.Point(112, 14)
		Me._imText1_0.TabIndex = 44
		Me._imText1_0.Name = "_imText1_0"
		_imText1_3.OcxState = CType(resources.GetObject("_imText1_3.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imText1_3.CausesValidation = False
		Me._imText1_3.Size = New System.Drawing.Size(353, 23)
		Me._imText1_3.Location = New System.Drawing.Point(198, 40)
		Me._imText1_3.TabIndex = 47
		Me._imText1_3.Name = "_imText1_3"
		_imText1_2.OcxState = CType(resources.GetObject("_imText1_2.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imText1_2.Size = New System.Drawing.Size(83, 23)
		Me._imText1_2.Location = New System.Drawing.Point(112, 40)
		Me._imText1_2.TabIndex = 46
		Me._imText1_2.Name = "_imText1_2"
		_imText1_1.OcxState = CType(resources.GetObject("_imText1_1.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imText1_1.CausesValidation = False
		Me._imText1_1.Size = New System.Drawing.Size(33, 23)
		Me._imText1_1.Location = New System.Drawing.Point(302, 14)
		Me._imText1_1.TabIndex = 45
		Me._imText1_1.Name = "_imText1_1"
		Me._Label1_1.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_1.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_1.Text = "������"
		Me._Label1_1.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_1.ForeColor = System.Drawing.Color.White
		Me._Label1_1.Size = New System.Drawing.Size(100, 23)
		Me._Label1_1.Location = New System.Drawing.Point(198, 14)
		Me._Label1_1.TabIndex = 66
		Me._Label1_1.Enabled = True
		Me._Label1_1.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_1.UseMnemonic = True
		Me._Label1_1.Visible = True
		Me._Label1_1.AutoSize = False
		Me._Label1_1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_1.Name = "_Label1_1"
		Me._Label1_0.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_0.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_0.Text = "���N��"
		Me._Label1_0.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_0.ForeColor = System.Drawing.Color.White
		Me._Label1_0.Size = New System.Drawing.Size(100, 23)
		Me._Label1_0.Location = New System.Drawing.Point(8, 14)
		Me._Label1_0.TabIndex = 60
		Me._Label1_0.Enabled = True
		Me._Label1_0.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_0.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_0.UseMnemonic = True
		Me._Label1_0.Visible = True
		Me._Label1_0.AutoSize = False
		Me._Label1_0.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_0.Name = "_Label1_0"
		Me._Label1_2.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_2.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_2.Text = "�Ɓ@��"
		Me._Label1_2.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_2.ForeColor = System.Drawing.Color.White
		Me._Label1_2.Size = New System.Drawing.Size(100, 23)
		Me._Label1_2.Location = New System.Drawing.Point(8, 40)
		Me._Label1_2.TabIndex = 59
		Me._Label1_2.Enabled = True
		Me._Label1_2.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_2.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_2.UseMnemonic = True
		Me._Label1_2.Visible = True
		Me._Label1_2.AutoSize = False
		Me._Label1_2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_2.Name = "_Label1_2"
		Me.Picture1.Dock = System.Windows.Forms.DockStyle.Bottom
		Me.Picture1.BackColor = System.Drawing.Color.FromARGB(128, 128, 128)
		Me.Picture1.Size = New System.Drawing.Size(1016, 51)
		Me.Picture1.Location = New System.Drawing.Point(0, 668)
		Me.Picture1.TabIndex = 57
		Me.Picture1.TabStop = False
		Me.Picture1.CausesValidation = True
		Me.Picture1.Enabled = True
		Me.Picture1.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Picture1.Cursor = System.Windows.Forms.Cursors.Default
		Me.Picture1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Picture1.Visible = True
		Me.Picture1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.Picture1.Name = "Picture1"
		Me._cmdKey_3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me._cmdKey_3.Text = "  F3  �@"
		Me._cmdKey_3.Enabled = False
		Me._cmdKey_3.Font = New System.Drawing.Font("�l�r ����", 11.25!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._cmdKey_3.Size = New System.Drawing.Size(77, 39)
		Me._cmdKey_3.Location = New System.Drawing.Point(166, 4)
		Me._cmdKey_3.TabIndex = 34
		Me._cmdKey_3.BackColor = System.Drawing.SystemColors.Control
		Me._cmdKey_3.CausesValidation = True
		Me._cmdKey_3.ForeColor = System.Drawing.SystemColors.ControlText
		Me._cmdKey_3.Cursor = System.Windows.Forms.Cursors.Default
		Me._cmdKey_3.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._cmdKey_3.TabStop = True
		Me._cmdKey_3.Name = "_cmdKey_3"
		Me._cmdKey_12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me._cmdKey_12.Text = "  F12  �I ��"
		Me._cmdKey_12.CausesValidation = False
		Me._cmdKey_12.Font = New System.Drawing.Font("�l�r ����", 11.25!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._cmdKey_12.Size = New System.Drawing.Size(77, 39)
		Me._cmdKey_12.Location = New System.Drawing.Point(929, 4)
		Me._cmdKey_12.TabIndex = 43
		Me._cmdKey_12.Tag = "�������I�����܂��B"
		Me._cmdKey_12.BackColor = System.Drawing.SystemColors.Control
		Me._cmdKey_12.Enabled = True
		Me._cmdKey_12.ForeColor = System.Drawing.SystemColors.ControlText
		Me._cmdKey_12.Cursor = System.Windows.Forms.Cursors.Default
		Me._cmdKey_12.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._cmdKey_12.TabStop = True
		Me._cmdKey_12.Name = "_cmdKey_12"
		Me._cmdKey_4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me._cmdKey_4.Text = "  F4  �@"
		Me._cmdKey_4.Enabled = False
		Me._cmdKey_4.Font = New System.Drawing.Font("�l�r ����", 11.25!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._cmdKey_4.Size = New System.Drawing.Size(77, 39)
		Me._cmdKey_4.Location = New System.Drawing.Point(246, 4)
		Me._cmdKey_4.TabIndex = 35
		Me._cmdKey_4.BackColor = System.Drawing.SystemColors.Control
		Me._cmdKey_4.CausesValidation = True
		Me._cmdKey_4.ForeColor = System.Drawing.SystemColors.ControlText
		Me._cmdKey_4.Cursor = System.Windows.Forms.Cursors.Default
		Me._cmdKey_4.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._cmdKey_4.TabStop = True
		Me._cmdKey_4.Name = "_cmdKey_4"
		Me._cmdKey_10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me._cmdKey_10.Text = "  F10  �@"
		Me._cmdKey_10.Enabled = False
		Me._cmdKey_10.Font = New System.Drawing.Font("�l�r ����", 11.25!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._cmdKey_10.Size = New System.Drawing.Size(77, 39)
		Me._cmdKey_10.Location = New System.Drawing.Point(769, 4)
		Me._cmdKey_10.TabIndex = 41
		Me._cmdKey_10.BackColor = System.Drawing.SystemColors.Control
		Me._cmdKey_10.CausesValidation = True
		Me._cmdKey_10.ForeColor = System.Drawing.SystemColors.ControlText
		Me._cmdKey_10.Cursor = System.Windows.Forms.Cursors.Default
		Me._cmdKey_10.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._cmdKey_10.TabStop = True
		Me._cmdKey_10.Name = "_cmdKey_10"
		Me._cmdKey_6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me._cmdKey_6.Text = "  F6  �@"
		Me._cmdKey_6.Enabled = False
		Me._cmdKey_6.Font = New System.Drawing.Font("�l�r ����", 11.25!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._cmdKey_6.Size = New System.Drawing.Size(77, 39)
		Me._cmdKey_6.Location = New System.Drawing.Point(428, 4)
		Me._cmdKey_6.TabIndex = 37
		Me._cmdKey_6.BackColor = System.Drawing.SystemColors.Control
		Me._cmdKey_6.CausesValidation = True
		Me._cmdKey_6.ForeColor = System.Drawing.SystemColors.ControlText
		Me._cmdKey_6.Cursor = System.Windows.Forms.Cursors.Default
		Me._cmdKey_6.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._cmdKey_6.TabStop = True
		Me._cmdKey_6.Name = "_cmdKey_6"
		Me._cmdKey_7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me._cmdKey_7.Text = "  F7  �@"
		Me._cmdKey_7.Enabled = False
		Me._cmdKey_7.Font = New System.Drawing.Font("�l�r ����", 11.25!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._cmdKey_7.Size = New System.Drawing.Size(77, 39)
		Me._cmdKey_7.Location = New System.Drawing.Point(508, 4)
		Me._cmdKey_7.TabIndex = 38
		Me._cmdKey_7.BackColor = System.Drawing.SystemColors.Control
		Me._cmdKey_7.CausesValidation = True
		Me._cmdKey_7.ForeColor = System.Drawing.SystemColors.ControlText
		Me._cmdKey_7.Cursor = System.Windows.Forms.Cursors.Default
		Me._cmdKey_7.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._cmdKey_7.TabStop = True
		Me._cmdKey_7.Name = "_cmdKey_7"
		Me._cmdKey_8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me._cmdKey_8.Text = "  F8  �@"
		Me._cmdKey_8.Enabled = False
		Me._cmdKey_8.Font = New System.Drawing.Font("�l�r ����", 11.25!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._cmdKey_8.Size = New System.Drawing.Size(77, 39)
		Me._cmdKey_8.Location = New System.Drawing.Point(588, 4)
		Me._cmdKey_8.TabIndex = 39
		Me._cmdKey_8.BackColor = System.Drawing.SystemColors.Control
		Me._cmdKey_8.CausesValidation = True
		Me._cmdKey_8.ForeColor = System.Drawing.SystemColors.ControlText
		Me._cmdKey_8.Cursor = System.Windows.Forms.Cursors.Default
		Me._cmdKey_8.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._cmdKey_8.TabStop = True
		Me._cmdKey_8.Name = "_cmdKey_8"
		Me._cmdKey_9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me._cmdKey_9.Text = "  F9  �@"
		Me._cmdKey_9.Enabled = False
		Me._cmdKey_9.Font = New System.Drawing.Font("�l�r ����", 11.25!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._cmdKey_9.Size = New System.Drawing.Size(77, 39)
		Me._cmdKey_9.Location = New System.Drawing.Point(689, 4)
		Me._cmdKey_9.TabIndex = 40
		Me._cmdKey_9.BackColor = System.Drawing.SystemColors.Control
		Me._cmdKey_9.CausesValidation = True
		Me._cmdKey_9.ForeColor = System.Drawing.SystemColors.ControlText
		Me._cmdKey_9.Cursor = System.Windows.Forms.Cursors.Default
		Me._cmdKey_9.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._cmdKey_9.TabStop = True
		Me._cmdKey_9.Name = "_cmdKey_9"
		Me._cmdKey_1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me._cmdKey_1.Text = "  F1  �o �^"
		Me._cmdKey_1.Font = New System.Drawing.Font("�l�r ����", 11.25!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._cmdKey_1.Size = New System.Drawing.Size(77, 39)
		Me._cmdKey_1.Location = New System.Drawing.Point(6, 4)
		Me._cmdKey_1.TabIndex = 32
		Me._cmdKey_1.Tag = "���̓f�[�^��o�^���܂��B"
		Me._cmdKey_1.BackColor = System.Drawing.SystemColors.Control
		Me._cmdKey_1.CausesValidation = True
		Me._cmdKey_1.Enabled = True
		Me._cmdKey_1.ForeColor = System.Drawing.SystemColors.ControlText
		Me._cmdKey_1.Cursor = System.Windows.Forms.Cursors.Default
		Me._cmdKey_1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._cmdKey_1.TabStop = True
		Me._cmdKey_1.Name = "_cmdKey_1"
		Me._cmdKey_11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me._cmdKey_11.Text = "  F11  �@"
		Me._cmdKey_11.Enabled = False
		Me._cmdKey_11.Font = New System.Drawing.Font("�l�r ����", 11.25!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._cmdKey_11.Size = New System.Drawing.Size(77, 39)
		Me._cmdKey_11.Location = New System.Drawing.Point(849, 4)
		Me._cmdKey_11.TabIndex = 42
		Me._cmdKey_11.BackColor = System.Drawing.SystemColors.Control
		Me._cmdKey_11.CausesValidation = True
		Me._cmdKey_11.ForeColor = System.Drawing.SystemColors.ControlText
		Me._cmdKey_11.Cursor = System.Windows.Forms.Cursors.Default
		Me._cmdKey_11.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._cmdKey_11.TabStop = True
		Me._cmdKey_11.Name = "_cmdKey_11"
		Me._cmdKey_2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me._cmdKey_2.Text = "  F2  �@"
		Me._cmdKey_2.Enabled = False
		Me._cmdKey_2.Font = New System.Drawing.Font("�l�r ����", 11.25!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._cmdKey_2.Size = New System.Drawing.Size(77, 39)
		Me._cmdKey_2.Location = New System.Drawing.Point(86, 4)
		Me._cmdKey_2.TabIndex = 33
		Me._cmdKey_2.BackColor = System.Drawing.SystemColors.Control
		Me._cmdKey_2.CausesValidation = True
		Me._cmdKey_2.ForeColor = System.Drawing.SystemColors.ControlText
		Me._cmdKey_2.Cursor = System.Windows.Forms.Cursors.Default
		Me._cmdKey_2.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._cmdKey_2.TabStop = True
		Me._cmdKey_2.Name = "_cmdKey_2"
		Me._cmdKey_5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me._cmdKey_5.Text = "  F5  �@"
		Me._cmdKey_5.Enabled = False
		Me._cmdKey_5.Font = New System.Drawing.Font("�l�r ����", 11.25!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._cmdKey_5.Size = New System.Drawing.Size(77, 39)
		Me._cmdKey_5.Location = New System.Drawing.Point(348, 4)
		Me._cmdKey_5.TabIndex = 36
		Me._cmdKey_5.BackColor = System.Drawing.SystemColors.Control
		Me._cmdKey_5.CausesValidation = True
		Me._cmdKey_5.ForeColor = System.Drawing.SystemColors.ControlText
		Me._cmdKey_5.Cursor = System.Windows.Forms.Cursors.Default
		Me._cmdKey_5.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._cmdKey_5.TabStop = True
		Me._cmdKey_5.Name = "_cmdKey_5"
		Me.StatusBar1.Dock = System.Windows.Forms.DockStyle.Bottom
		Me.StatusBar1.Size = New System.Drawing.Size(1016, 23)
		Me.StatusBar1.Location = New System.Drawing.Point(0, 719)
		Me.StatusBar1.TabIndex = 52
		Me.StatusBar1.Font = New System.Drawing.Font("�l�r �S�V�b�N", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me.StatusBar1.Name = "StatusBar1"
		Me._StatusBar1_Panel1.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter
		Me._StatusBar1_Panel1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
		Me._StatusBar1_Panel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me._StatusBar1_Panel1.Size = New System.Drawing.Size(117, 23)
		Me._StatusBar1_Panel1.BorderSides = CType(System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom, System.Windows.Forms.ToolStripStatusLabelBorderSides)
		Me._StatusBar1_Panel1.Margin = New System.Windows.Forms.Padding(0)
		Me._StatusBar1_Panel1.AutoSize = False
		Me._StatusBar1_Panel2.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter
		Me._StatusBar1_Panel2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
		Me._StatusBar1_Panel2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._StatusBar1_Panel2.Size = New System.Drawing.Size(902, 23)
		Me._StatusBar1_Panel2.BorderSides = CType(System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom, System.Windows.Forms.ToolStripStatusLabelBorderSides)
		Me._StatusBar1_Panel2.Margin = New System.Windows.Forms.Padding(0)
		Me._StatusBar1_Panel2.AutoSize = False
		_imText2_2.OcxState = CType(resources.GetObject("_imText2_2.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imText2_2.Size = New System.Drawing.Size(433, 23)
		Me._imText2_2.Location = New System.Drawing.Point(576, 6)
		Me._imText2_2.TabIndex = 54
		Me._imText2_2.Name = "_imText2_2"
		_imText2_0.OcxState = CType(resources.GetObject("_imText2_0.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imText2_0.Size = New System.Drawing.Size(83, 23)
		Me._imText2_0.Location = New System.Drawing.Point(440, 6)
		Me._imText2_0.TabIndex = 55
		Me._imText2_0.Name = "_imText2_0"
		_imText2_1.OcxState = CType(resources.GetObject("_imText2_1.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imText2_1.Size = New System.Drawing.Size(45, 23)
		Me._imText2_1.Location = New System.Drawing.Point(527, 6)
		Me._imText2_1.TabIndex = 56
		Me._imText2_1.Name = "_imText2_1"
		Me.lblTitle.BackColor = System.Drawing.Color.FromARGB(192, 255, 192)
		Me.lblTitle.Text = " �O�����́i�y�؁j"
		Me.lblTitle.Font = New System.Drawing.Font("�l�r ����", 20.25!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me.lblTitle.ForeColor = System.Drawing.Color.FromARGB(0, 0, 128)
		Me.lblTitle.Size = New System.Drawing.Size(1015, 34)
		Me.lblTitle.Location = New System.Drawing.Point(0, 0)
		Me.lblTitle.TabIndex = 53
		Me.lblTitle.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.lblTitle.Enabled = True
		Me.lblTitle.Cursor = System.Windows.Forms.Cursors.Default
		Me.lblTitle.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.lblTitle.UseMnemonic = True
		Me.lblTitle.Visible = True
		Me.lblTitle.AutoSize = False
		Me.lblTitle.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.lblTitle.Name = "lblTitle"
		Me.Controls.Add(_Frame1_4)
		Me.Controls.Add(_Frame1_3)
		Me.Controls.Add(_Frame1_2)
		Me.Controls.Add(_Frame1_1)
		Me.Controls.Add(_Frame1_0)
		Me.Controls.Add(Picture1)
		Me.Controls.Add(StatusBar1)
		Me.Controls.Add(_imText2_2)
		Me.Controls.Add(_imText2_0)
		Me.Controls.Add(_imText2_1)
		Me.Controls.Add(lblTitle)
		Me._Frame1_4.Controls.Add(Picture2)
		Me._Frame1_4.Controls.Add(_ctlMeisai2_0)
		Me._Frame1_4.Controls.Add(VScroll2)
		Me._Frame1_4.Controls.Add(_ctlMeisai2_1)
		Me._Frame1_4.Controls.Add(_ctlMeisai2_2)
		Me._Frame1_4.Controls.Add(_ctlMeisai2_3)
		Me._Frame1_4.Controls.Add(_imText3_7)
		Me._Frame1_4.Controls.Add(_imText3_8)
		Me._Frame1_4.Controls.Add(_Label1_44)
		Me._Frame1_4.Controls.Add(_Label1_43)
		Me._Frame1_4.Controls.Add(_Label1_39)
		Me._Frame1_4.Controls.Add(_Label1_38)
		Me._Frame1_4.Controls.Add(_Label1_37)
		Me._Frame1_4.Controls.Add(_Label1_36)
		Me._Frame1_4.Controls.Add(_Label1_35)
		Me._Frame1_4.Controls.Add(_Label1_30)
		Me._Frame1_4.Controls.Add(_Label1_33)
		Me._Frame1_4.Controls.Add(_Label1_34)
		Me._Frame1_4.Controls.Add(_Label1_27)
		Me._Frame1_4.Controls.Add(_Label1_28)
		Me._Frame1_4.Controls.Add(_Label1_29)
		Me._Frame1_4.Controls.Add(_Label1_32)
		Me._Frame1_4.Controls.Add(_Label1_31)
		Me.Picture2.Controls.Add(_imText3_4)
		Me.Picture2.Controls.Add(_imText3_5)
		Me.Picture2.Controls.Add(_imText3_6)
		Me.Picture2.Controls.Add(_imNumber2_5)
		Me.Picture2.Controls.Add(_imNumber2_6)
		Me._Frame1_3.Controls.Add(_imText4_0)
		Me._Frame1_3.Controls.Add(_imNumber2_0)
		Me._Frame1_3.Controls.Add(_imText4_2)
		Me._Frame1_3.Controls.Add(_imText4_3)
		Me._Frame1_3.Controls.Add(_imNumber2_1)
		Me._Frame1_3.Controls.Add(_imText4_4)
		Me._Frame1_3.Controls.Add(_imText4_5)
		Me._Frame1_3.Controls.Add(_imText4_6)
		Me._Frame1_3.Controls.Add(_imNumber2_3)
		Me._Frame1_3.Controls.Add(_imText4_7)
		Me._Frame1_3.Controls.Add(_imNumber2_4)
		Me._Frame1_3.Controls.Add(_imNumber2_2)
		Me._Frame1_3.Controls.Add(_imNumber2_7)
		Me._Frame1_3.Controls.Add(_imNumber2_8)
		Me._Frame1_3.Controls.Add(_Label1_46)
		Me._Frame1_3.Controls.Add(_Label1_45)
		Me._Frame1_3.Controls.Add(_Label1_3)
		Me._Frame1_3.Controls.Add(_Label1_25)
		Me._Frame1_3.Controls.Add(_Label1_26)
		Me._Frame1_3.Controls.Add(_Label1_24)
		Me._Frame1_3.Controls.Add(_Label1_23)
		Me._Frame1_3.Controls.Add(_Label1_21)
		Me._Frame1_3.Controls.Add(_Label1_22)
		Me._Frame1_3.Controls.Add(Label2)
		Me._Frame1_3.Controls.Add(_Label1_20)
		Me._Frame1_3.Controls.Add(_Label1_19)
		Me._Frame1_3.Controls.Add(_Label1_18)
		Me._Frame1_3.Controls.Add(_Label1_17)
		Me._Frame1_3.Controls.Add(_Label1_16)
		Me._Frame1_3.Controls.Add(_Label1_15)
		Me._Frame1_2.Controls.Add(VScroll1)
		Me._Frame1_2.Controls.Add(_ctlMeisai1_0)
		Me._Frame1_2.Controls.Add(_imText3_0)
		Me._Frame1_2.Controls.Add(_ctlMeisai1_1)
		Me._Frame1_2.Controls.Add(_ctlMeisai1_2)
		Me._Frame1_2.Controls.Add(_imText3_1)
		Me._Frame1_2.Controls.Add(_imText3_2)
		Me._Frame1_2.Controls.Add(_imText3_3)
		Me._Frame1_2.Controls.Add(_Label1_10)
		Me._Frame1_2.Controls.Add(_Label1_11)
		Me._Frame1_2.Controls.Add(_Label1_14)
		Me._Frame1_2.Controls.Add(_Label1_9)
		Me._Frame1_2.Controls.Add(_Label1_8)
		Me._Frame1_2.Controls.Add(_Label1_7)
		Me._Frame1_2.Controls.Add(_Label1_13)
		Me._Frame1_2.Controls.Add(_Label1_12)
		Me._Frame1_1.Controls.Add(_imNumber1_0)
		Me._Frame1_1.Controls.Add(_imNumber1_1)
		Me._Frame1_1.Controls.Add(_imNumber1_2)
		Me._Frame1_1.Controls.Add(_Label1_42)
		Me._Frame1_1.Controls.Add(_Label1_41)
		Me._Frame1_1.Controls.Add(_Label1_40)
		Me._Frame1_1.Controls.Add(_Label1_6)
		Me._Frame1_1.Controls.Add(_Label1_5)
		Me._Frame1_1.Controls.Add(_Label1_4)
		Me._Frame1_0.Controls.Add(Check1)
		Me._Frame1_0.Controls.Add(_imText1_0)
		Me._Frame1_0.Controls.Add(_imText1_3)
		Me._Frame1_0.Controls.Add(_imText1_2)
		Me._Frame1_0.Controls.Add(_imText1_1)
		Me._Frame1_0.Controls.Add(_Label1_1)
		Me._Frame1_0.Controls.Add(_Label1_0)
		Me._Frame1_0.Controls.Add(_Label1_2)
		Me.Picture1.Controls.Add(_cmdKey_3)
		Me.Picture1.Controls.Add(_cmdKey_12)
		Me.Picture1.Controls.Add(_cmdKey_4)
		Me.Picture1.Controls.Add(_cmdKey_10)
		Me.Picture1.Controls.Add(_cmdKey_6)
		Me.Picture1.Controls.Add(_cmdKey_7)
		Me.Picture1.Controls.Add(_cmdKey_8)
		Me.Picture1.Controls.Add(_cmdKey_9)
		Me.Picture1.Controls.Add(_cmdKey_1)
		Me.Picture1.Controls.Add(_cmdKey_11)
		Me.Picture1.Controls.Add(_cmdKey_2)
		Me.Picture1.Controls.Add(_cmdKey_5)
		Me.StatusBar1.Items.AddRange(New System.Windows.Forms.ToolStripItem(){Me._StatusBar1_Panel1})
		Me.StatusBar1.Items.AddRange(New System.Windows.Forms.ToolStripItem(){Me._StatusBar1_Panel2})
		Me.Frame1.SetIndex(_Frame1_4, CType(4, Short))
		Me.Frame1.SetIndex(_Frame1_3, CType(3, Short))
		Me.Frame1.SetIndex(_Frame1_2, CType(2, Short))
		Me.Frame1.SetIndex(_Frame1_1, CType(1, Short))
		Me.Frame1.SetIndex(_Frame1_0, CType(0, Short))
		Me.Label1.SetIndex(_Label1_44, CType(44, Short))
		Me.Label1.SetIndex(_Label1_43, CType(43, Short))
		Me.Label1.SetIndex(_Label1_39, CType(39, Short))
		Me.Label1.SetIndex(_Label1_38, CType(38, Short))
		Me.Label1.SetIndex(_Label1_37, CType(37, Short))
		Me.Label1.SetIndex(_Label1_36, CType(36, Short))
		Me.Label1.SetIndex(_Label1_35, CType(35, Short))
		Me.Label1.SetIndex(_Label1_30, CType(30, Short))
		Me.Label1.SetIndex(_Label1_33, CType(33, Short))
		Me.Label1.SetIndex(_Label1_34, CType(34, Short))
		Me.Label1.SetIndex(_Label1_27, CType(27, Short))
		Me.Label1.SetIndex(_Label1_28, CType(28, Short))
		Me.Label1.SetIndex(_Label1_29, CType(29, Short))
		Me.Label1.SetIndex(_Label1_32, CType(32, Short))
		Me.Label1.SetIndex(_Label1_31, CType(31, Short))
		Me.Label1.SetIndex(_Label1_46, CType(46, Short))
		Me.Label1.SetIndex(_Label1_45, CType(45, Short))
		Me.Label1.SetIndex(_Label1_3, CType(3, Short))
		Me.Label1.SetIndex(_Label1_25, CType(25, Short))
		Me.Label1.SetIndex(_Label1_26, CType(26, Short))
		Me.Label1.SetIndex(_Label1_24, CType(24, Short))
		Me.Label1.SetIndex(_Label1_23, CType(23, Short))
		Me.Label1.SetIndex(_Label1_21, CType(21, Short))
		Me.Label1.SetIndex(_Label1_22, CType(22, Short))
		Me.Label1.SetIndex(_Label1_20, CType(20, Short))
		Me.Label1.SetIndex(_Label1_19, CType(19, Short))
		Me.Label1.SetIndex(_Label1_18, CType(18, Short))
		Me.Label1.SetIndex(_Label1_17, CType(17, Short))
		Me.Label1.SetIndex(_Label1_16, CType(16, Short))
		Me.Label1.SetIndex(_Label1_15, CType(15, Short))
		Me.Label1.SetIndex(_Label1_10, CType(10, Short))
		Me.Label1.SetIndex(_Label1_11, CType(11, Short))
		Me.Label1.SetIndex(_Label1_14, CType(14, Short))
		Me.Label1.SetIndex(_Label1_9, CType(9, Short))
		Me.Label1.SetIndex(_Label1_8, CType(8, Short))
		Me.Label1.SetIndex(_Label1_7, CType(7, Short))
		Me.Label1.SetIndex(_Label1_13, CType(13, Short))
		Me.Label1.SetIndex(_Label1_12, CType(12, Short))
		Me.Label1.SetIndex(_Label1_42, CType(42, Short))
		Me.Label1.SetIndex(_Label1_41, CType(41, Short))
		Me.Label1.SetIndex(_Label1_40, CType(40, Short))
		Me.Label1.SetIndex(_Label1_6, CType(6, Short))
		Me.Label1.SetIndex(_Label1_5, CType(5, Short))
		Me.Label1.SetIndex(_Label1_4, CType(4, Short))
		Me.Label1.SetIndex(_Label1_1, CType(1, Short))
		Me.Label1.SetIndex(_Label1_0, CType(0, Short))
		Me.Label1.SetIndex(_Label1_2, CType(2, Short))
		Me.cmdKey.SetIndex(_cmdKey_3, CType(3, Short))
		Me.cmdKey.SetIndex(_cmdKey_12, CType(12, Short))
		Me.cmdKey.SetIndex(_cmdKey_4, CType(4, Short))
		Me.cmdKey.SetIndex(_cmdKey_10, CType(10, Short))
		Me.cmdKey.SetIndex(_cmdKey_6, CType(6, Short))
		Me.cmdKey.SetIndex(_cmdKey_7, CType(7, Short))
		Me.cmdKey.SetIndex(_cmdKey_8, CType(8, Short))
		Me.cmdKey.SetIndex(_cmdKey_9, CType(9, Short))
		Me.cmdKey.SetIndex(_cmdKey_1, CType(1, Short))
		Me.cmdKey.SetIndex(_cmdKey_11, CType(11, Short))
		Me.cmdKey.SetIndex(_cmdKey_2, CType(2, Short))
		Me.cmdKey.SetIndex(_cmdKey_5, CType(5, Short))
		Me.ctlMeisai1.SetIndex(_ctlMeisai1_0, CType(0, Short))
		Me.ctlMeisai1.SetIndex(_ctlMeisai1_1, CType(1, Short))
		Me.ctlMeisai1.SetIndex(_ctlMeisai1_2, CType(2, Short))
		Me.ctlMeisai2.SetIndex(_ctlMeisai2_0, CType(0, Short))
		Me.ctlMeisai2.SetIndex(_ctlMeisai2_1, CType(1, Short))
		Me.ctlMeisai2.SetIndex(_ctlMeisai2_2, CType(2, Short))
		Me.ctlMeisai2.SetIndex(_ctlMeisai2_3, CType(3, Short))
		Me.imNumber1.SetIndex(_imNumber1_0, CType(0, Short))
		Me.imNumber1.SetIndex(_imNumber1_1, CType(1, Short))
		Me.imNumber1.SetIndex(_imNumber1_2, CType(2, Short))
		Me.imNumber2.SetIndex(_imNumber2_5, CType(5, Short))
		Me.imNumber2.SetIndex(_imNumber2_6, CType(6, Short))
		Me.imNumber2.SetIndex(_imNumber2_0, CType(0, Short))
		Me.imNumber2.SetIndex(_imNumber2_1, CType(1, Short))
		Me.imNumber2.SetIndex(_imNumber2_3, CType(3, Short))
		Me.imNumber2.SetIndex(_imNumber2_4, CType(4, Short))
		Me.imNumber2.SetIndex(_imNumber2_2, CType(2, Short))
		Me.imNumber2.SetIndex(_imNumber2_7, CType(7, Short))
		Me.imNumber2.SetIndex(_imNumber2_8, CType(8, Short))
		Me.imText1.SetIndex(_imText1_0, CType(0, Short))
		Me.imText1.SetIndex(_imText1_3, CType(3, Short))
		Me.imText1.SetIndex(_imText1_2, CType(2, Short))
		Me.imText1.SetIndex(_imText1_1, CType(1, Short))
		Me.imText2.SetIndex(_imText2_2, CType(2, Short))
		Me.imText2.SetIndex(_imText2_0, CType(0, Short))
		Me.imText2.SetIndex(_imText2_1, CType(1, Short))
		Me.imText3.SetIndex(_imText3_4, CType(4, Short))
		Me.imText3.SetIndex(_imText3_5, CType(5, Short))
		Me.imText3.SetIndex(_imText3_6, CType(6, Short))
		Me.imText3.SetIndex(_imText3_7, CType(7, Short))
		Me.imText3.SetIndex(_imText3_8, CType(8, Short))
		Me.imText3.SetIndex(_imText3_0, CType(0, Short))
		Me.imText3.SetIndex(_imText3_1, CType(1, Short))
		Me.imText3.SetIndex(_imText3_2, CType(2, Short))
		Me.imText3.SetIndex(_imText3_3, CType(3, Short))
		Me.imText4.SetIndex(_imText4_0, CType(0, Short))
		Me.imText4.SetIndex(_imText4_2, CType(2, Short))
		Me.imText4.SetIndex(_imText4_3, CType(3, Short))
		Me.imText4.SetIndex(_imText4_4, CType(4, Short))
		Me.imText4.SetIndex(_imText4_5, CType(5, Short))
		Me.imText4.SetIndex(_imText4_6, CType(6, Short))
		Me.imText4.SetIndex(_imText4_7, CType(7, Short))
		CType(Me.imText4, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.imText3, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.imText2, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.imText1, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.imNumber2, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.imNumber1, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.ctlMeisai2, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.ctlMeisai1, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.cmdKey, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.Label1, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.Frame1, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imText2_1, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imText2_0, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imText2_2, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imText1_1, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imText1_2, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imText1_3, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imText1_0, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imNumber1_2, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imNumber1_1, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imNumber1_0, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imText3_3, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imText3_2, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imText3_1, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imText3_0, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imNumber2_8, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imNumber2_7, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imNumber2_2, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imNumber2_4, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imText4_7, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imNumber2_3, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imText4_6, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imText4_5, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imText4_4, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imNumber2_1, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imText4_3, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imText4_2, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imNumber2_0, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imText4_0, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imText3_8, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imText3_7, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imNumber2_6, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imNumber2_5, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imText3_6, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imText3_5, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imText3_4, System.ComponentModel.ISupportInitialize).EndInit()
		Me._Frame1_4.ResumeLayout(False)
		Me.Picture2.ResumeLayout(False)
		Me._Frame1_3.ResumeLayout(False)
		Me._Frame1_2.ResumeLayout(False)
		Me._Frame1_1.ResumeLayout(False)
		Me._Frame1_0.ResumeLayout(False)
		Me.Picture1.ResumeLayout(False)
		Me.StatusBar1.ResumeLayout(False)
		Me.ResumeLayout(False)
		Me.PerformLayout()
	End Sub
#End Region 
End Class