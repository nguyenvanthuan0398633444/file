Option Strict Off
Option Explicit On
Friend Class frmSYKD290
	Inherits System.Windows.Forms.Form
	'=============================================================
	' ���[�U�[���@  �F  �R�z�H�Ɗ������
	' �V�X�e�����@  �F  �H���Ǘ��V�X�e��
	' ���W���[����  �F  ���M�f�[�^�ꗗ
	' ���W���[��ID�@�F  frmSYKD290.frm
	' �쐬���@ �@�@ �F  ���� 13 �N 07 �� 05 ��
	' �X�V���@�@  �@�F  ����    �N    ��    ��
	'=============================================================
	'
	
	Private Const RowHeight As Short = 15
	Private himc As Integer
	'
	
	'-------------------------------------------------------------------------------
	'   ����    :   �f�[�^�̃N���A
	'   �֐�    :   Sub DispClear()
	'   ����    :   �Ȃ�
	'   �@�\    :   �f�[�^���N���A���܂��B
	'-------------------------------------------------------------------------------
	Private Sub DispClear()
		
		vaSpread1.MaxRows = 0
		
		'----- �Q�ƃ��[�h
		If INPMODE <> "2" Then
			cmdKey(8).Enabled = False
			cmdKey(8).Text = "  F8  �@"
		End If
		
	End Sub
	
	'-------------------------------------------------------------------------------
	'   ����    :   �e�L�X�g���̎擾
	'   �֐�    :   Function GetTextFile()
	'   ����    :   �Ȃ�
	'   �ߒl    :   True    ����I��
	'   �@�@    :   False   �ُ�I��
	'   �@�\    :   �e�L�X�g�t�@�C���̏����擾���܂��B
	'-------------------------------------------------------------------------------
	Private Function GetTextFile() As Boolean
		
		Dim wkPath As String
		Dim wkFile As String
		Dim lp As Integer
		Dim Cnt As Integer
		Dim DT() As KOUJI_NO_MAST_DBT
		
		On Error GoTo FileErrD290
		
		' �߂�l�̏�����
		GetTextFile = False
		
		' �����e�L�X�g�t�@�C�����̎擾
		wkPath = SENDPATH & "SYK_G*.LZH"
		
		' �t�@�C�������擾
		Cnt = 0
		'UPGRADE_WARNING: Dir has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="9B7D5ADD-D8FE-4819-A36C-6DEDAF088CC7"'
		wkFile = Dir(wkPath, FileAttribute.Normal)
		Do While Len(wkFile)
			ReDim Preserve DT(Cnt)
			Call CLEAR_KOUJI_NO_MAST(DT(Cnt))
			With DT(Cnt)
				.KOUJI_NO = Mid(wkFile, 6, 8) '�H���ԍ�
				.EDA_NO = Mid(wkFile, 14, 4) '�H���}��
				.MEISYOU = GetNameKouji(.KOUJI_NO, .EDA_NO) '�H������
				.GYOUSYU_KB = UCase(Mid(wkFile, 5, 1)) '���
			End With
			Cnt = Cnt + 1
			'UPGRADE_WARNING: Dir has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="9B7D5ADD-D8FE-4819-A36C-6DEDAF088CC7"'
			wkFile = Dir()
		Loop 
		
		' �f�[�^�\��
		Call SprdDataSet(Cnt, DT)
		
		' ����I��
		GetTextFile = True
		Exit Function
		
FileErrD290: 
		
		'----- �G���[����
		Call FileErrors()
		
	End Function
	
	'-------------------------------------------------------------------------------
	'   ����    :   �X�v���b�h�\��
	'   �֐�    :   Sub SprdDataSet(DT())
	'   ����    :   Cnt     �f�[�^����
	'   �@�@    :   DT()    KOUJI_NO_MAST_DBT
	'   �@�\    :   �f�[�^���X�v���b�h�ɕ\�����܂��B
	'-------------------------------------------------------------------------------
	Private Sub SprdDataSet(ByRef Cnt As Integer, ByRef DT() As KOUJI_NO_MAST_DBT)
		
		Dim lp As Integer
		Dim Row As Integer
		Dim ssText As Object
		
		With vaSpread1
			If Me.Visible = True Then
				.ReDraw = False
			End If
			.MaxRows = Cnt
			.Row = 1
			.Col = 1
			.Col2 = .MaxCols
			.Row2 = .MaxRows
			.BlockMode = True
			.Action = FPSpread.ActionConstants.ActionClearText
			.BlockMode = False
			For lp = 0 To Cnt - 1
				.set_RowHeight(lp + 1, RowHeight)
				Row = lp + 1
				'----- CheckBox
				.SetText(1, Row, "0")
				'----- �H���ԍ�
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				ssText = Trim(DT(lp).KOUJI_NO)
				.SetText(2, Row, ssText)
				'----- �}��
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				ssText = Trim(DT(lp).EDA_NO)
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				If ssText <> "0000" Then
					.SetText(3, Row, ssText)
				End If
				'----- ����
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				ssText = Trim(DT(lp).MEISYOU)
				.SetText(4, Row, ssText)
				'----- �H���敪
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				ssText = GetNameGyosyu(DT(lp).KOUJI_NO, DT(lp).EDA_NO)
				.SetText(5, Row, ssText)
				'----- �m��
				Select Case Trim(DT(lp).GYOUSYU_KB)
					Case "K"
						'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
						ssText = "�m��"
					Case Else
						'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
						ssText = ""
				End Select
				.SetText(6, Row, ssText)
			Next lp
			.Row = 1 : .Row2 = .MaxRows
			.Col = 1 : .Col2 = .MaxCols
			.BlockMode = True
			.SortBy = FPSpread.SortByConstants.SortByRow
			.set_SortKey(1, 2)
			.set_SortKeyOrder(1, FPSpread.SortKeyOrderConstants.SortKeyOrderAscending)
			.set_SortKey(2, 3)
			.set_SortKeyOrder(2, FPSpread.SortKeyOrderConstants.SortKeyOrderAscending)
			.Action = FPSpread.ActionConstants.ActionSort
			.BlockMode = False
			If Me.Visible = True Then
				'UPGRADE_NOTE: Refresh was upgraded to CtlRefresh. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="A9E4979A-37FA-4718-9994-97DD76ED70A7"'
				.CtlRefresh()
				.ReDraw = True
			End If
		End With
		
	End Sub
	
	'-------------------------------------------------------------------------------
	'   ����    :   �I���f�[�^�i�j�d�x�j�̎擾
	'   �֐�    :   Sub SprdDataGet(DT)
	'   ����    :   DT  KOUJI_NO_MAST_DBT
	'   �@�\    :   �I���f�[�^���X�v���b�h����擾���܂��B
	'-------------------------------------------------------------------------------
	Private Sub SprdDataGet(ByRef DT As KOUJI_NO_MAST_DBT)
		
		Dim ssText As Object
		
		With vaSpread1
			.GetText(2, .ActiveRow, ssText) '�H���ԍ�
			'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			DT.KOUJI_NO = Trim(ssText)
			.GetText(3, .ActiveRow, ssText) '�}��
			'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			If Trim(ssText) = "" Then ssText = "0000"
			'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			DT.EDA_NO = Trim(ssText)
			.GetText(6, .ActiveRow, ssText) '�m��敪
			'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			DT.MEISYOU = Trim(ssText)
		End With
		
	End Sub
	
	Private Sub cmdKey_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Click
		Dim Index As Short = cmdKey.GetIndex(eventSender)
		
		Dim ChkFlg As Short
		Dim lp As Integer
		Dim ssText As Object
		Dim fName As String
		
		Select Case Index
			Case 8 '----- �e�c�o��
				' �o�͐��I������
				With vaSpread1
					ChkFlg = 0
					For lp = 1 To .MaxRows
						.GetText(1, lp, ssText) ' CheckBox
						'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
						If ssText = "1" Then
							.GetText(4, lp, ssText) ' �H������
							'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
							fName = ssText
							ChkFlg = 1
							Exit For
						End If
					Next lp
				End With
				If ChkFlg = 0 Then
					MsgBox("�o�͂���H������I�����ĉ������B")
				Else
					frmSYKD291.imText1(0).Text = fName
					frmSYKD291.ShowDialog()
					' �����\��
					Call DispClear()
					Call GetTextFile()
				End If
				
			Case 12 '----- �I��
				frmSYKD010.Show()
				Me.Close()
		End Select
		
	End Sub
	
	Private Sub cmdKey_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Enter
		Dim Index As Short = cmdKey.GetIndex(eventSender)
		Call GotFocus(cmdKey(Index), StatusBar1)
	End Sub
	
	Private Sub cmdKey_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Leave
		Dim Index As Short = cmdKey.GetIndex(eventSender)
		Call LostFocus(cmdKey(Index), StatusBar1)
	End Sub
	
	Private Sub frmSYKD290_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown
		Dim KeyCode As Short = eventArgs.KeyCode
		Dim Shift As Short = eventArgs.KeyData \ &H10000
		Select Case KeyCode
			Case System.Windows.Forms.Keys.F1
				If cmdKey(1).Enabled = True Then cmdKey(1).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(1), New System.EventArgs())
			Case System.Windows.Forms.Keys.F2
				If cmdKey(2).Enabled = True Then cmdKey(2).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(2), New System.EventArgs())
			Case System.Windows.Forms.Keys.F3
				If cmdKey(3).Enabled = True Then cmdKey(3).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(3), New System.EventArgs())
			Case System.Windows.Forms.Keys.F4
				If cmdKey(4).Enabled = True Then cmdKey(4).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(4), New System.EventArgs())
			Case System.Windows.Forms.Keys.F5
				If cmdKey(5).Enabled = True Then cmdKey(5).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(5), New System.EventArgs())
			Case System.Windows.Forms.Keys.F6
				If cmdKey(6).Enabled = True Then cmdKey(6).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(6), New System.EventArgs())
			Case System.Windows.Forms.Keys.F7
				If cmdKey(7).Enabled = True Then cmdKey(7).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(7), New System.EventArgs())
			Case System.Windows.Forms.Keys.F8
				If cmdKey(8).Enabled = True Then cmdKey(8).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(8), New System.EventArgs())
			Case System.Windows.Forms.Keys.F9
				If cmdKey(9).Enabled = True Then cmdKey(9).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(9), New System.EventArgs())
			Case System.Windows.Forms.Keys.F10
				If cmdKey(10).Enabled = True Then cmdKey(10).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(10), New System.EventArgs())
			Case System.Windows.Forms.Keys.F11
				If cmdKey(11).Enabled = True Then cmdKey(11).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(11), New System.EventArgs())
			Case System.Windows.Forms.Keys.F12
				If cmdKey(12).Enabled = True Then cmdKey(12).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(12), New System.EventArgs())
		End Select
	End Sub
	
	Private Sub frmSYKD290_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
		
		Call FormDisp(Me)
		
		'�X�v���b�h��IME�N���n�e�e
		himc = ImmGetContext(vaSpread1.hWnd)
		
		' �����\��
		Call DispClear()
		Call GetTextFile()
		
	End Sub
	
	Private Sub frmSYKD290_FormClosing(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
		Dim Cancel As Boolean = eventArgs.Cancel
		Dim UnloadMode As System.Windows.Forms.CloseReason = eventArgs.CloseReason
		If UnloadMode = System.Windows.Forms.CloseReason.UserClosing Then
			frmSYKD010.Show()
		End If
		eventArgs.Cancel = Cancel
	End Sub
	
	Private Sub vaSpread1_ClickEvent(ByVal eventSender As System.Object, ByVal eventArgs As AxFPSpread._DSpreadEvents_ClickEvent) Handles vaSpread1.ClickEvent
		
		Dim lp As Integer
		Dim ssText As Object
		
		If eventArgs.Col = 1 Then
			With vaSpread1
				If eventArgs.Row = 0 Then
					' �S�I��
					For lp = 1 To .MaxRows
						.GetText(1, lp, ssText)
						'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
						If ssText = "1" Then Exit For
					Next lp
					'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
					If ssText = "1" Then
						ssText = "0"
					Else
						'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
						ssText = "1"
					End If
					For lp = 1 To .MaxRows
						.eventArgs.Col = eventArgs.Col : .eventArgs.Row = lp
						'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
						.Text = ssText
					Next lp
				Else
					.eventArgs.Col = eventArgs.Col : .eventArgs.Row = eventArgs.Row
					If .Text = "0" Then .Text = "1" Else .Text = "0"
				End If
			End With
		End If
	End Sub
	
	Private Sub vaSpread1_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles vaSpread1.Enter
		Call GotFocus(vaSpread1, StatusBar1)
		ImmSetOpenStatus(himc, False)
	End Sub
	
	Private Sub vaSpread1_KeyDownEvent(ByVal eventSender As System.Object, ByVal eventArgs As AxFPSpread._DSpreadEvents_KeyDownEvent) Handles vaSpread1.KeyDownEvent
		If eventArgs.KeyCode = System.Windows.Forms.Keys.Space Then
			Call vaSpread1_ClickEvent(vaSpread1, New AxFPSpread._DSpreadEvents_ClickEvent(1, vaSpread1.ActiveRow))
		End If
	End Sub
	
	Private Sub vaSpread1_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles vaSpread1.Leave
		Call LostFocus(vaSpread1, StatusBar1)
	End Sub
End Class