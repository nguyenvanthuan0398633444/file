Option Strict Off
Option Explicit On
Friend Class frmSYKD185
	Inherits System.Windows.Forms.Form
	'
	
	Private Sub Check1_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles Check1.Enter
		Dim Index As Short = Check1.GetIndex(eventSender)
		Call GotFocus(Check1(Index), StatusBar1)
	End Sub
	
	Private Sub Check1_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles Check1.Leave
		Dim Index As Short = Check1.GetIndex(eventSender)
		Call LostFocus(Check1(Index), StatusBar1)
	End Sub
	
	Private Sub cmdKey_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Click
		Dim Index As Short = cmdKey.GetIndex(eventSender)
		
		Dim Jouken As String
		Dim Msg As String
		
		Select Case Index
			Case 1 '----- �������
				If Check1(0).CheckState = CDbl("1") Or Check1(1).CheckState = CDbl("1") Then
					If MsgBox("�H������(�y��)��������܂��B��낵���ł����H", MsgBoxStyle.YesNo) = MsgBoxResult.No Then
						Exit Sub
					End If
					
					If Check1(0).CheckState = 1 Then
						System.Windows.Forms.Application.DoEvents()
						'UPGRADE_WARNING: Screen property Screen.MousePointer has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6BA9B8D2-2A32-4B6E-8D36-44949974A5B4"'
						System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
						StatusBar1.Items.Item("Message").Text = "����f�[�^�i����j�쐬���E�E�E"
						System.Windows.Forms.Application.DoEvents()
						'UPGRADE_WARNING: Couldn't resolve default property of object PrnMainD185(). Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
						If PrnMainD185() = True Then
							'2001/01/21 �ҏW�̏ꍇ�̂ݍX�V����
							If INPMODE = "2" Then '�ҏW��
								' �H�����i����j�y�؂̍X�V
								CtlKouji.P_FLG_GEPPOU = "1" '���FLG �H������
								Jouken = "KOUJI_NO = '" & CtlKouji.KOUJI_NO & "' AND EDA_NO = '" & CtlKouji.EDA_NO & "'"
								If UPDATE_KOUJI_CTRL_D(Jouken, CtlKouji) = False Then
									Msg = "�H�����i����j�y�؂̍X�V�Ɏ��s���܂����B"
									MsgBox(Msg, MsgBoxStyle.OKOnly)
									Exit Sub
								End If
							End If
						End If
					End If
					If Check1(1).CheckState = 1 Then
						System.Windows.Forms.Application.DoEvents()
						'UPGRADE_WARNING: Screen property Screen.MousePointer has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6BA9B8D2-2A32-4B6E-8D36-44949974A5B4"'
						System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
						StatusBar1.Items.Item("Message").Text = "����f�[�^�i�ڍׁj�쐬���E�E�E"
						System.Windows.Forms.Application.DoEvents()
						'UPGRADE_WARNING: Couldn't resolve default property of object PrnMainD186(). Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
						If PrnMainD186() = True Then
							'2001/01/21 �ҏW�̏ꍇ�̂ݍX�V����
							If INPMODE = "2" Then '�ҏW��
								' �H�����i����j�y�؂̍X�V
								CtlKouji.P_FLG_GEPPOU = "1" '���FLG �H������
								Jouken = "KOUJI_NO = '" & CtlKouji.KOUJI_NO & "' AND EDA_NO = '" & CtlKouji.EDA_NO & "'"
								If UPDATE_KOUJI_CTRL_D(Jouken, CtlKouji) = False Then
									Msg = "�H�����i����j�y�؂̍X�V�Ɏ��s���܂����B"
									MsgBox(Msg, MsgBoxStyle.OKOnly)
									Exit Sub
								End If
							End If
						End If
					End If
				Else
					Exit Sub
				End If
				System.Windows.Forms.Application.DoEvents()
				StatusBar1.Items.Item("Message").Text = ""
				'UPGRADE_WARNING: Screen property Screen.MousePointer has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6BA9B8D2-2A32-4B6E-8D36-44949974A5B4"'
				System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
				System.Windows.Forms.Application.DoEvents()
				
			Case 12 '----- �����I��
				Me.Close()
		End Select
		
	End Sub
	
	Private Sub cmdKey_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Enter
		Dim Index As Short = cmdKey.GetIndex(eventSender)
		Call GotFocus(cmdKey(Index), StatusBar1)
	End Sub
	
	Private Sub cmdKey_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Leave
		Dim Index As Short = cmdKey.GetIndex(eventSender)
		Call LostFocus(cmdKey(Index), StatusBar1)
	End Sub
	
	Private Sub frmSYKD185_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown
		Dim KeyCode As Short = eventArgs.KeyCode
		Dim Shift As Short = eventArgs.KeyData \ &H10000
		Select Case KeyCode
			Case System.Windows.Forms.Keys.Return
				'UPGRADE_ISSUE: Control TabIndex could not be resolved because it was within the generic namespace ActiveControl. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="084D22AD-ECB1-400F-B4C7-418ECEC5E36E"'
				Call NextCntlGet(Me, Me.ActiveControl.TabIndex)
			Case System.Windows.Forms.Keys.F1
				If cmdKey(1).Enabled = True Then cmdKey(1).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(1), New System.EventArgs())
			Case System.Windows.Forms.Keys.F12
				If cmdKey(12).Enabled = True Then cmdKey(12).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(12), New System.EventArgs())
		End Select
	End Sub
	
	Private Sub frmSYKD185_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
		Call FormDisp(Me)
	End Sub
End Class