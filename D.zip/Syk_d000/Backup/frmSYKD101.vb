Option Strict Off
Option Explicit On
Friend Class frmSYKD101
	Inherits System.Windows.Forms.Form
	'=============================================================
	' ���[�U�[���@  �F  �R�z�H�Ɗ������
	' �V�X�e�����@  �F  �H���Ǘ��V�X�e��
	' ���W���[����  �F  ���c�������́i��ʕ��ڍׁj
	' ���W���[��ID�@�F  frmSYKD101.frm
	' �쐬���@ �@�@ �F  ���� 13 �N 07 �� 24 ��
	' �X�V���@�@  �@�F  ����    �N    ��    ��
	'=============================================================
	'
	
	Private Const RowHeight As Short = 15
	'
	
	'-------------------------------------------------------------------------------
	'   ����    :   �f�[�^�̎擾
	'   �֐�    :   Sub ListDataDisp()
	'   ����    :   �Ȃ�
	'   �@�\    :   �f�[�^�̎擾���s���܂��B
	'-------------------------------------------------------------------------------
	Public Sub ListDataDisp()
		
		Dim Cnt As Integer
		Dim Jouken As String
		Dim Order As String
		Dim DT() As IPPAN_DATA_DBT
		Dim wkBuf As String
		Dim ssText As Object
		Dim KousyuID As String
		Dim wkMeisyo As String
		Dim MeisaiNO As Double
		Dim wkstr As String
		
		' �J�[�\���������v��
		'UPGRADE_WARNING: Screen property Screen.MousePointer has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6BA9B8D2-2A32-4B6E-8D36-44949974A5B4"'
		System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
		wkBuf = StatusBar1.Items.Item("Message").Text
		StatusBar1.Items.Item("Message").Text = "�Y���f�[�^�������E�E�E"
		
		'----- �I���j�d�x���̎擾
		With frmSYKD090.vaSpread1
			.GetText(1, .ActiveRow, ssText) '�H��
			'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			KousyuID = CStr(ssText)
			.GetText(2, .ActiveRow, ssText) '����
			'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			wkMeisyo = CStr(ssText)
			.GetText(13, .ActiveRow, ssText) '���הԍ�
			MeisaiNO = CDbl2(ssText)
		End With
		
		'----- �w�b�_���̕\��
		imText1(0).Text = KousyuID
		wkstr = Trim(GetNameKousyu(GyosyuID, Mid(KousyuID, 1, 1))) & "�|"
		wkstr = wkstr & Trim(GetNameKousyu(GyosyuID, Mid(KousyuID, 1, 1), Mid(KousyuID, 3, 2)))
		If Trim(wkstr) = "�|" Then wkstr = ""
		imText1(1).Text = wkstr
		imText1(2).Text = wkMeisyo
		
		' �e�[�u���̓Ǎ���
		Jouken = "S_FLG_GENKA = '1'"
		Jouken = Jouken & " AND CHUUMON_NO = '" & Trim(frmSYKD090.ChumonID) & "'"
		Jouken = Jouken & " AND MEISAI_NO = " & VB6.Format(MeisaiNO)
		Jouken = Jouken & " AND KOUSYU_NO = '" & Mid(KousyuID, 3, 2) & "'"
		Jouken = Jouken & " AND KOUSYU_CD = '" & Mid(KousyuID, 1, 1) & "'"
		Jouken = Jouken & " AND EDA_NO = '" & KeyKouji.EDA_NO & "'"
		Jouken = Jouken & " AND KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"
		Order = "SIME_YM, DENPYOU_KB, GYOUSYA_CD"
		Cnt = SELECT_IPPAN_DATA(Jouken, Order, DT)
		If Cnt <= 0 Then
			vaSpread1.MaxRows = 0
			StatusBar1.Items.Item("Message").Text = wkBuf
			'UPGRADE_WARNING: Screen property Screen.MousePointer has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6BA9B8D2-2A32-4B6E-8D36-44949974A5B4"'
			System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
			Exit Sub
		End If
		
		' �X�v���b�h�ɕ\��
		Call SprdDataSet(Cnt, DT)
		
		StatusBar1.Items.Item("Message").Text = wkBuf
		'UPGRADE_WARNING: Screen property Screen.MousePointer has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6BA9B8D2-2A32-4B6E-8D36-44949974A5B4"'
		System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
		
	End Sub
	
	'-------------------------------------------------------------------------------
	'   ����    :   �X�v���b�h�\��
	'   �֐�    :   Sub SprdDataSet(DT())
	'   ����    :   Cnt     �f�[�^����
	'   �@�@        DT()    DTRIDASI_DATA_DBT
	'   �@�\    :   �f�[�^���X�v���b�h�ɕ\�����܂��B
	'-------------------------------------------------------------------------------
	Private Sub SprdDataSet(ByRef Cnt As Integer, ByRef DT() As IPPAN_DATA_DBT)
		
		Dim lp As Integer
		Dim Row As Integer
		Dim ssText As Object
		Dim wkVal As Decimal
		
		With vaSpread1
			If Me.Visible = True Then
				.ReDraw = False
			End If
			.MaxRows = Cnt
			.Col = 1 : .Col2 = .MaxCols
			.Row = 1 : .Row2 = .MaxRows
			.BlockMode = True
			.Action = FPSpread.ActionConstants.ActionClearText
			.BlockMode = False
			wkVal = 0
			For lp = 0 To Cnt - 1
				.set_RowHeight(lp + 1, RowHeight)
				Row = lp + 1
				'----- ���N��
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				ssText = VB6.Format(DT(lp).SIME_YM, "0000/00")
				.SetText(1, Row, ssText)
				'----- �x���敪
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				ssText = GetNameSiharai(DT(lp).DENPYOU_KB)
				.SetText(2, Row, ssText)
				'----- �ƎЖ�
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				ssText = GetNameGyousya(DT(lp).GYOUSYA_CD)
				.SetText(3, Row, ssText)
				'----- �i����K�i
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				ssText = DT(lp).BIKOU
				.SetText(4, Row, ssText)
				'----- ���z
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				ssText = VB6.Format(DT(lp).KINGAKU, "#,##0")
				.SetText(5, Row, ssText)
				'----- �݌v
				wkVal = wkVal + DT(lp).KINGAKU
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				ssText = VB6.Format(wkVal, "#,##0")
				.SetText(6, Row, ssText)
			Next lp
			If Me.Visible = True Then
				'UPGRADE_NOTE: Refresh was upgraded to CtlRefresh. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="A9E4979A-37FA-4718-9994-97DD76ED70A7"'
				.CtlRefresh()
				.ReDraw = True
			End If
		End With
		
	End Sub
	
	Private Sub cmdKey_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Click
		Dim Index As Short = cmdKey.GetIndex(eventSender)
		Select Case Index
			Case 12 '----- �I��
				Me.Close()
		End Select
	End Sub
	
	Private Sub cmdKey_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Enter
		Dim Index As Short = cmdKey.GetIndex(eventSender)
		Call GotFocus(cmdKey(Index), StatusBar1)
	End Sub
	
	Private Sub cmdKey_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Leave
		Dim Index As Short = cmdKey.GetIndex(eventSender)
		Call LostFocus(cmdKey(Index), StatusBar1)
	End Sub
	
	Private Sub frmSYKD101_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown
		Dim KeyCode As Short = eventArgs.KeyCode
		Dim Shift As Short = eventArgs.KeyData \ &H10000
		Select Case KeyCode
			Case System.Windows.Forms.Keys.F12
				If cmdKey(12).Enabled = True Then cmdKey(12).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(12), New System.EventArgs())
		End Select
	End Sub
	
	Private Sub frmSYKD101_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
		Call FormDisp(Me)
		Call ListDataDisp()
	End Sub
	
	Private Sub frmSYKD101_FormClosing(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
		Dim Cancel As Boolean = eventArgs.Cancel
		Dim UnloadMode As System.Windows.Forms.CloseReason = eventArgs.CloseReason
		If UnloadMode = System.Windows.Forms.CloseReason.UserClosing Then
			'
		End If
		eventArgs.Cancel = Cancel
	End Sub
End Class