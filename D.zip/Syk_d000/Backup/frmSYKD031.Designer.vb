<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frmSYKD031
#Region "Windows Form Designer generated code "
	<System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
		MyBase.New()
		'This call is required by the Windows Form Designer.
		InitializeComponent()
	End Sub
	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer
	Public ToolTip1 As System.Windows.Forms.ToolTip
	Public WithEvents _imNumber3_0 As imNumber6.imNumber
	Public WithEvents _imNumber3_1 As imNumber6.imNumber
	Public WithEvents _imNumber3_2 As imNumber6.imNumber
	Public WithEvents _Label1_11 As System.Windows.Forms.Label
	Public WithEvents _Label1_12 As System.Windows.Forms.Label
	Public WithEvents _Label1_14 As System.Windows.Forms.Label
	Public WithEvents _Frame1_4 As System.Windows.Forms.GroupBox
	Public WithEvents _imNumber2_0 As imNumber6.imNumber
	Public WithEvents _imNumber2_1 As imNumber6.imNumber
	Public WithEvents _imNumber2_2 As imNumber6.imNumber
	Public WithEvents _Label1_8 As System.Windows.Forms.Label
	Public WithEvents _Label1_9 As System.Windows.Forms.Label
	Public WithEvents _Label1_10 As System.Windows.Forms.Label
	Public WithEvents _Frame1_3 As System.Windows.Forms.GroupBox
	Public WithEvents _cmdLook_5 As System.Windows.Forms.Button
	Public WithEvents _imText1_5 As imText6.imText
	Public WithEvents _imText4_5 As imText6.imText
	Public WithEvents _imText2_5 As imText6.imText
	Public WithEvents _imText2_6 As imText6.imText
	Public WithEvents _imText1_0 As imText6.imText
	Public WithEvents _Label1_3 As System.Windows.Forms.Label
	Public WithEvents _Label1_2 As System.Windows.Forms.Label
	Public WithEvents _Frame1_1 As System.Windows.Forms.GroupBox
	Public WithEvents _imText1_3 As imText6.imText
	Public WithEvents _imNumber1_0 As imNumber6.imNumber
	Public WithEvents _imNumber1_1 As imNumber6.imNumber
	Public WithEvents _imNumber1_2 As imNumber6.imNumber
	Public WithEvents _Label1_7 As System.Windows.Forms.Label
	Public WithEvents _Label1_6 As System.Windows.Forms.Label
	Public WithEvents _Label1_5 As System.Windows.Forms.Label
	Public WithEvents _Label1_4 As System.Windows.Forms.Label
	Public WithEvents _Frame1_2 As System.Windows.Forms.GroupBox
	Public WithEvents _imText4_0 As imText6.imText
	Public WithEvents _imText3_2 As imText6.imText
	Public WithEvents _imText3_0 As imText6.imText
	Public WithEvents _imText3_1 As imText6.imText
	Public WithEvents _imText3_4 As imText6.imText
	Public WithEvents _imText3_3 As imText6.imText
	Public WithEvents _imText4_1 As imText6.imText
	Public WithEvents _Label1_1 As System.Windows.Forms.Label
	Public WithEvents _Label1_0 As System.Windows.Forms.Label
	Public WithEvents _Frame1_0 As System.Windows.Forms.GroupBox
	Public WithEvents Picture2 As System.Windows.Forms.Panel
	Public WithEvents _cmdKey_12 As System.Windows.Forms.Button
	Public WithEvents _cmdKey_1 As System.Windows.Forms.Button
	Public WithEvents Picture1 As System.Windows.Forms.Panel
	Public WithEvents _StatusBar1_Panel1 As System.Windows.Forms.ToolStripStatusLabel
	Public WithEvents _StatusBar1_Panel2 As System.Windows.Forms.ToolStripStatusLabel
	Public WithEvents StatusBar1 As System.Windows.Forms.StatusStrip
	Public WithEvents lblTitle As System.Windows.Forms.Label
	Public WithEvents Frame1 As Microsoft.VisualBasic.Compatibility.VB6.GroupBoxArray
	Public WithEvents Label1 As Microsoft.VisualBasic.Compatibility.VB6.LabelArray
	Public WithEvents cmdKey As Microsoft.VisualBasic.Compatibility.VB6.ButtonArray
	Public WithEvents cmdLook As Microsoft.VisualBasic.Compatibility.VB6.ButtonArray
	Public WithEvents imNumber1 As imNumberArray
	Public WithEvents imNumber2 As imNumberArray
	Public WithEvents imNumber3 As imNumberArray
	Public WithEvents imText1 As imTextArray
	Public WithEvents imText2 As imTextArray
	Public WithEvents imText3 As imTextArray
	Public WithEvents imText4 As imTextArray
	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmSYKD031))
		Me.components = New System.ComponentModel.Container()
		Me.ToolTip1 = New System.Windows.Forms.ToolTip(components)
		Me.Picture2 = New System.Windows.Forms.Panel
		Me._Frame1_4 = New System.Windows.Forms.GroupBox
		Me._imNumber3_0 = New imNumber6.imNumber
		Me._imNumber3_1 = New imNumber6.imNumber
		Me._imNumber3_2 = New imNumber6.imNumber
		Me._Label1_11 = New System.Windows.Forms.Label
		Me._Label1_12 = New System.Windows.Forms.Label
		Me._Label1_14 = New System.Windows.Forms.Label
		Me._Frame1_3 = New System.Windows.Forms.GroupBox
		Me._imNumber2_0 = New imNumber6.imNumber
		Me._imNumber2_1 = New imNumber6.imNumber
		Me._imNumber2_2 = New imNumber6.imNumber
		Me._Label1_8 = New System.Windows.Forms.Label
		Me._Label1_9 = New System.Windows.Forms.Label
		Me._Label1_10 = New System.Windows.Forms.Label
		Me._Frame1_1 = New System.Windows.Forms.GroupBox
		Me._cmdLook_5 = New System.Windows.Forms.Button
		Me._imText1_5 = New imText6.imText
		Me._imText4_5 = New imText6.imText
		Me._imText2_5 = New imText6.imText
		Me._imText2_6 = New imText6.imText
		Me._imText1_0 = New imText6.imText
		Me._Label1_3 = New System.Windows.Forms.Label
		Me._Label1_2 = New System.Windows.Forms.Label
		Me._Frame1_2 = New System.Windows.Forms.GroupBox
		Me._imText1_3 = New imText6.imText
		Me._imNumber1_0 = New imNumber6.imNumber
		Me._imNumber1_1 = New imNumber6.imNumber
		Me._imNumber1_2 = New imNumber6.imNumber
		Me._Label1_7 = New System.Windows.Forms.Label
		Me._Label1_6 = New System.Windows.Forms.Label
		Me._Label1_5 = New System.Windows.Forms.Label
		Me._Label1_4 = New System.Windows.Forms.Label
		Me._Frame1_0 = New System.Windows.Forms.GroupBox
		Me._imText4_0 = New imText6.imText
		Me._imText3_2 = New imText6.imText
		Me._imText3_0 = New imText6.imText
		Me._imText3_1 = New imText6.imText
		Me._imText3_4 = New imText6.imText
		Me._imText3_3 = New imText6.imText
		Me._imText4_1 = New imText6.imText
		Me._Label1_1 = New System.Windows.Forms.Label
		Me._Label1_0 = New System.Windows.Forms.Label
		Me.Picture1 = New System.Windows.Forms.Panel
		Me._cmdKey_12 = New System.Windows.Forms.Button
		Me._cmdKey_1 = New System.Windows.Forms.Button
		Me.StatusBar1 = New System.Windows.Forms.StatusStrip
		Me._StatusBar1_Panel1 = New System.Windows.Forms.ToolStripStatusLabel
		Me._StatusBar1_Panel2 = New System.Windows.Forms.ToolStripStatusLabel
		Me.lblTitle = New System.Windows.Forms.Label
		Me.Frame1 = New Microsoft.VisualBasic.Compatibility.VB6.GroupBoxArray(components)
		Me.Label1 = New Microsoft.VisualBasic.Compatibility.VB6.LabelArray(components)
		Me.cmdKey = New Microsoft.VisualBasic.Compatibility.VB6.ButtonArray(components)
		Me.cmdLook = New Microsoft.VisualBasic.Compatibility.VB6.ButtonArray(components)
		Me.imNumber1 = New imNumberArray(components)
		Me.imNumber2 = New imNumberArray(components)
		Me.imNumber3 = New imNumberArray(components)
		Me.imText1 = New imTextArray(components)
		Me.imText2 = New imTextArray(components)
		Me.imText3 = New imTextArray(components)
		Me.imText4 = New imTextArray(components)
		Me.Picture2.SuspendLayout()
		Me._Frame1_4.SuspendLayout()
		Me._Frame1_3.SuspendLayout()
		Me._Frame1_1.SuspendLayout()
		Me._Frame1_2.SuspendLayout()
		Me._Frame1_0.SuspendLayout()
		Me.Picture1.SuspendLayout()
		Me.StatusBar1.SuspendLayout()
		Me.SuspendLayout()
		Me.ToolTip1.Active = True
		CType(Me._imNumber3_0, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imNumber3_1, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imNumber3_2, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imNumber2_0, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imNumber2_1, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imNumber2_2, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imText1_5, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imText4_5, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imText2_5, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imText2_6, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imText1_0, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imText1_3, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imNumber1_0, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imNumber1_1, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imNumber1_2, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imText4_0, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imText3_2, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imText3_0, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imText3_1, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imText3_4, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imText3_3, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imText4_1, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.Frame1, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.Label1, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.cmdKey, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.cmdLook, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.imNumber1, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.imNumber2, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.imNumber3, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.imText1, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.imText2, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.imText3, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.imText4, System.ComponentModel.ISupportInitialize).BeginInit()
		Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
		Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
		Me.Text = "�H���Ǘ��V�X�e��"
		Me.ClientSize = New System.Drawing.Size(620, 513)
		Me.Location = New System.Drawing.Point(212, 180)
		Me.Icon = CType(resources.GetObject("frmSYKD031.Icon"), System.Drawing.Icon)
		Me.KeyPreview = True
		Me.MaximizeBox = False
		Me.MinimizeBox = False
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.BackColor = System.Drawing.SystemColors.Control
		Me.ControlBox = True
		Me.Enabled = True
		Me.Cursor = System.Windows.Forms.Cursors.Default
		Me.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.ShowInTaskbar = True
		Me.HelpButton = False
		Me.WindowState = System.Windows.Forms.FormWindowState.Normal
		Me.Name = "frmSYKD031"
		Me.Picture2.Size = New System.Drawing.Size(607, 403)
		Me.Picture2.Location = New System.Drawing.Point(6, 32)
		Me.Picture2.TabIndex = 17
		Me.Picture2.TabStop = False
		Me.Picture2.Dock = System.Windows.Forms.DockStyle.None
		Me.Picture2.BackColor = System.Drawing.SystemColors.Control
		Me.Picture2.CausesValidation = True
		Me.Picture2.Enabled = True
		Me.Picture2.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Picture2.Cursor = System.Windows.Forms.Cursors.Default
		Me.Picture2.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Picture2.Visible = True
		Me.Picture2.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Picture2.Name = "Picture2"
		Me._Frame1_4.Text = " ���s�\�Z"
		Me._Frame1_4.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Frame1_4.ForeColor = System.Drawing.Color.FromARGB(0, 0, 192)
		Me._Frame1_4.Size = New System.Drawing.Size(607, 85)
		Me._Frame1_4.Location = New System.Drawing.Point(0, 172)
		Me._Frame1_4.TabIndex = 44
		Me._Frame1_4.BackColor = System.Drawing.SystemColors.Control
		Me._Frame1_4.Enabled = True
		Me._Frame1_4.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Frame1_4.Visible = True
		Me._Frame1_4.Padding = New System.Windows.Forms.Padding(0)
		Me._Frame1_4.Name = "_Frame1_4"
		_imNumber3_0.OcxState = CType(resources.GetObject("_imNumber3_0.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imNumber3_0.Size = New System.Drawing.Size(126, 23)
		Me._imNumber3_0.Location = New System.Drawing.Point(12, 48)
		Me._imNumber3_0.TabIndex = 2
		Me._imNumber3_0.Name = "_imNumber3_0"
		_imNumber3_1.OcxState = CType(resources.GetObject("_imNumber3_1.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imNumber3_1.Size = New System.Drawing.Size(126, 23)
		Me._imNumber3_1.Location = New System.Drawing.Point(142, 48)
		Me._imNumber3_1.TabIndex = 3
		Me._imNumber3_1.Name = "_imNumber3_1"
		_imNumber3_2.OcxState = CType(resources.GetObject("_imNumber3_2.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imNumber3_2.Size = New System.Drawing.Size(126, 23)
		Me._imNumber3_2.Location = New System.Drawing.Point(272, 48)
		Me._imNumber3_2.TabIndex = 4
		Me._imNumber3_2.Name = "_imNumber3_2"
		Me._Label1_11.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_11.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_11.Text = "���@�z"
		Me._Label1_11.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_11.ForeColor = System.Drawing.Color.White
		Me._Label1_11.Size = New System.Drawing.Size(126, 23)
		Me._Label1_11.Location = New System.Drawing.Point(272, 24)
		Me._Label1_11.TabIndex = 47
		Me._Label1_11.Enabled = True
		Me._Label1_11.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_11.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_11.UseMnemonic = True
		Me._Label1_11.Visible = True
		Me._Label1_11.AutoSize = False
		Me._Label1_11.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_11.Name = "_Label1_11"
		Me._Label1_12.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_12.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_12.Text = "�P�@��"
		Me._Label1_12.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_12.ForeColor = System.Drawing.Color.White
		Me._Label1_12.Size = New System.Drawing.Size(126, 23)
		Me._Label1_12.Location = New System.Drawing.Point(142, 24)
		Me._Label1_12.TabIndex = 46
		Me._Label1_12.Enabled = True
		Me._Label1_12.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_12.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_12.UseMnemonic = True
		Me._Label1_12.Visible = True
		Me._Label1_12.AutoSize = False
		Me._Label1_12.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_12.Name = "_Label1_12"
		Me._Label1_14.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_14.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_14.Text = "���@��"
		Me._Label1_14.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_14.ForeColor = System.Drawing.Color.White
		Me._Label1_14.Size = New System.Drawing.Size(126, 23)
		Me._Label1_14.Location = New System.Drawing.Point(12, 24)
		Me._Label1_14.TabIndex = 45
		Me._Label1_14.Enabled = True
		Me._Label1_14.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_14.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_14.UseMnemonic = True
		Me._Label1_14.Visible = True
		Me._Label1_14.AutoSize = False
		Me._Label1_14.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_14.Name = "_Label1_14"
		Me._Frame1_3.Text = " ���c��O�� "
		Me._Frame1_3.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Frame1_3.ForeColor = System.Drawing.Color.FromARGB(0, 0, 192)
		Me._Frame1_3.Size = New System.Drawing.Size(299, 133)
		Me._Frame1_3.Location = New System.Drawing.Point(308, 264)
		Me._Frame1_3.TabIndex = 40
		Me._Frame1_3.BackColor = System.Drawing.SystemColors.Control
		Me._Frame1_3.Enabled = True
		Me._Frame1_3.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Frame1_3.Visible = True
		Me._Frame1_3.Padding = New System.Windows.Forms.Padding(0)
		Me._Frame1_3.Name = "_Frame1_3"
		_imNumber2_0.OcxState = CType(resources.GetObject("_imNumber2_0.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imNumber2_0.Size = New System.Drawing.Size(119, 23)
		Me._imNumber2_0.Location = New System.Drawing.Point(142, 20)
		Me._imNumber2_0.TabIndex = 9
		Me._imNumber2_0.Name = "_imNumber2_0"
		_imNumber2_1.OcxState = CType(resources.GetObject("_imNumber2_1.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imNumber2_1.Size = New System.Drawing.Size(119, 23)
		Me._imNumber2_1.Location = New System.Drawing.Point(142, 72)
		Me._imNumber2_1.TabIndex = 10
		Me._imNumber2_1.Name = "_imNumber2_1"
		_imNumber2_2.OcxState = CType(resources.GetObject("_imNumber2_2.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imNumber2_2.Size = New System.Drawing.Size(119, 23)
		Me._imNumber2_2.Location = New System.Drawing.Point(142, 98)
		Me._imNumber2_2.TabIndex = 11
		Me._imNumber2_2.Name = "_imNumber2_2"
		Me._Label1_8.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_8.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_8.Text = "���@��"
		Me._Label1_8.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_8.ForeColor = System.Drawing.Color.White
		Me._Label1_8.Size = New System.Drawing.Size(126, 23)
		Me._Label1_8.Location = New System.Drawing.Point(12, 20)
		Me._Label1_8.TabIndex = 43
		Me._Label1_8.Enabled = True
		Me._Label1_8.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_8.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_8.UseMnemonic = True
		Me._Label1_8.Visible = True
		Me._Label1_8.AutoSize = False
		Me._Label1_8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_8.Name = "_Label1_8"
		Me._Label1_9.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_9.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_9.Text = "�P�@��"
		Me._Label1_9.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_9.ForeColor = System.Drawing.Color.White
		Me._Label1_9.Size = New System.Drawing.Size(126, 23)
		Me._Label1_9.Location = New System.Drawing.Point(12, 72)
		Me._Label1_9.TabIndex = 42
		Me._Label1_9.Enabled = True
		Me._Label1_9.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_9.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_9.UseMnemonic = True
		Me._Label1_9.Visible = True
		Me._Label1_9.AutoSize = False
		Me._Label1_9.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_9.Name = "_Label1_9"
		Me._Label1_10.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_10.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_10.Text = "���@�z"
		Me._Label1_10.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_10.ForeColor = System.Drawing.Color.White
		Me._Label1_10.Size = New System.Drawing.Size(126, 23)
		Me._Label1_10.Location = New System.Drawing.Point(12, 98)
		Me._Label1_10.TabIndex = 41
		Me._Label1_10.Enabled = True
		Me._Label1_10.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_10.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_10.UseMnemonic = True
		Me._Label1_10.Visible = True
		Me._Label1_10.AutoSize = False
		Me._Label1_10.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_10.Name = "_Label1_10"
		Me._Frame1_1.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Frame1_1.ForeColor = System.Drawing.Color.FromARGB(0, 0, 192)
		Me._Frame1_1.Size = New System.Drawing.Size(607, 83)
		Me._Frame1_1.Location = New System.Drawing.Point(0, 82)
		Me._Frame1_1.TabIndex = 20
		Me._Frame1_1.BackColor = System.Drawing.SystemColors.Control
		Me._Frame1_1.Enabled = True
		Me._Frame1_1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Frame1_1.Visible = True
		Me._Frame1_1.Padding = New System.Windows.Forms.Padding(0)
		Me._Frame1_1.Name = "_Frame1_1"
		Me._cmdLook_5.TextAlign = System.Drawing.ContentAlignment.BottomCenter
		Me._cmdLook_5.Font = New System.Drawing.Font("�l�r �o�S�V�b�N", 9.75!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._cmdLook_5.Size = New System.Drawing.Size(25, 23)
		Me._cmdLook_5.Location = New System.Drawing.Point(172, 20)
		Me._cmdLook_5.Image = CType(resources.GetObject("_cmdLook_5.Image"), System.Drawing.Image)
		Me._cmdLook_5.TabIndex = 36
		Me._cmdLook_5.TabStop = False
		Me._cmdLook_5.BackColor = System.Drawing.SystemColors.Control
		Me._cmdLook_5.CausesValidation = True
		Me._cmdLook_5.Enabled = True
		Me._cmdLook_5.ForeColor = System.Drawing.SystemColors.ControlText
		Me._cmdLook_5.Cursor = System.Windows.Forms.Cursors.Default
		Me._cmdLook_5.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._cmdLook_5.Name = "_cmdLook_5"
		_imText1_5.OcxState = CType(resources.GetObject("_imText1_5.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imText1_5.Size = New System.Drawing.Size(29, 23)
		Me._imText1_5.Location = New System.Drawing.Point(142, 20)
		Me._imText1_5.TabIndex = 0
		Me._imText1_5.Name = "_imText1_5"
		_imText4_5.OcxState = CType(resources.GetObject("_imText4_5.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imText4_5.Size = New System.Drawing.Size(23, 23)
		Me._imText4_5.Location = New System.Drawing.Point(552, 20)
		Me._imText4_5.TabIndex = 35
		Me._imText4_5.Visible = False
		Me._imText4_5.Name = "_imText4_5"
		_imText2_5.OcxState = CType(resources.GetObject("_imText2_5.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imText2_5.Size = New System.Drawing.Size(281, 23)
		Me._imText2_5.Location = New System.Drawing.Point(198, 20)
		Me._imText2_5.TabIndex = 37
		Me._imText2_5.Name = "_imText2_5"
		_imText2_6.OcxState = CType(resources.GetObject("_imText2_6.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imText2_6.Size = New System.Drawing.Size(63, 23)
		Me._imText2_6.Location = New System.Drawing.Point(484, 20)
		Me._imText2_6.TabIndex = 38
		Me._imText2_6.Name = "_imText2_6"
		_imText1_0.OcxState = CType(resources.GetObject("_imText1_0.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imText1_0.Size = New System.Drawing.Size(371, 23)
		Me._imText1_0.Location = New System.Drawing.Point(142, 48)
		Me._imText1_0.TabIndex = 1
		Me._imText1_0.Name = "_imText1_0"
		Me._Label1_3.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_3.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_3.Text = "���@��"
		Me._Label1_3.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_3.ForeColor = System.Drawing.Color.White
		Me._Label1_3.Size = New System.Drawing.Size(126, 23)
		Me._Label1_3.Location = New System.Drawing.Point(12, 48)
		Me._Label1_3.TabIndex = 39
		Me._Label1_3.Enabled = True
		Me._Label1_3.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_3.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_3.UseMnemonic = True
		Me._Label1_3.Visible = True
		Me._Label1_3.AutoSize = False
		Me._Label1_3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_3.Name = "_Label1_3"
		Me._Label1_2.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_2.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_2.Text = "���o�ԍ�"
		Me._Label1_2.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_2.ForeColor = System.Drawing.Color.White
		Me._Label1_2.Size = New System.Drawing.Size(126, 23)
		Me._Label1_2.Location = New System.Drawing.Point(12, 20)
		Me._Label1_2.TabIndex = 31
		Me._Label1_2.Enabled = True
		Me._Label1_2.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_2.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_2.UseMnemonic = True
		Me._Label1_2.Visible = True
		Me._Label1_2.AutoSize = False
		Me._Label1_2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_2.Name = "_Label1_2"
		Me._Frame1_2.Text = " ��� ���� ��ɗ\�� "
		Me._Frame1_2.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Frame1_2.ForeColor = System.Drawing.Color.FromARGB(0, 0, 192)
		Me._Frame1_2.Size = New System.Drawing.Size(299, 133)
		Me._Frame1_2.Location = New System.Drawing.Point(0, 264)
		Me._Frame1_2.TabIndex = 19
		Me._Frame1_2.BackColor = System.Drawing.SystemColors.Control
		Me._Frame1_2.Enabled = True
		Me._Frame1_2.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Frame1_2.Visible = True
		Me._Frame1_2.Padding = New System.Windows.Forms.Padding(0)
		Me._Frame1_2.Name = "_Frame1_2"
		_imText1_3.OcxState = CType(resources.GetObject("_imText1_3.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imText1_3.Size = New System.Drawing.Size(47, 23)
		Me._imText1_3.Location = New System.Drawing.Point(142, 46)
		Me._imText1_3.TabIndex = 6
		Me._imText1_3.Name = "_imText1_3"
		_imNumber1_0.OcxState = CType(resources.GetObject("_imNumber1_0.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imNumber1_0.Size = New System.Drawing.Size(119, 23)
		Me._imNumber1_0.Location = New System.Drawing.Point(142, 20)
		Me._imNumber1_0.TabIndex = 5
		Me._imNumber1_0.Name = "_imNumber1_0"
		_imNumber1_1.OcxState = CType(resources.GetObject("_imNumber1_1.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imNumber1_1.Size = New System.Drawing.Size(119, 23)
		Me._imNumber1_1.Location = New System.Drawing.Point(142, 72)
		Me._imNumber1_1.TabIndex = 7
		Me._imNumber1_1.Name = "_imNumber1_1"
		_imNumber1_2.OcxState = CType(resources.GetObject("_imNumber1_2.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imNumber1_2.Size = New System.Drawing.Size(119, 23)
		Me._imNumber1_2.Location = New System.Drawing.Point(142, 98)
		Me._imNumber1_2.TabIndex = 8
		Me._imNumber1_2.Name = "_imNumber1_2"
		Me._Label1_7.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_7.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_7.Text = "���@�z"
		Me._Label1_7.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_7.ForeColor = System.Drawing.Color.White
		Me._Label1_7.Size = New System.Drawing.Size(126, 23)
		Me._Label1_7.Location = New System.Drawing.Point(12, 98)
		Me._Label1_7.TabIndex = 30
		Me._Label1_7.Enabled = True
		Me._Label1_7.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_7.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_7.UseMnemonic = True
		Me._Label1_7.Visible = True
		Me._Label1_7.AutoSize = False
		Me._Label1_7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_7.Name = "_Label1_7"
		Me._Label1_6.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_6.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_6.Text = "�P�@��"
		Me._Label1_6.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_6.ForeColor = System.Drawing.Color.White
		Me._Label1_6.Size = New System.Drawing.Size(126, 23)
		Me._Label1_6.Location = New System.Drawing.Point(12, 72)
		Me._Label1_6.TabIndex = 29
		Me._Label1_6.Enabled = True
		Me._Label1_6.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_6.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_6.UseMnemonic = True
		Me._Label1_6.Visible = True
		Me._Label1_6.AutoSize = False
		Me._Label1_6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_6.Name = "_Label1_6"
		Me._Label1_5.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_5.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_5.Text = "�P�@��"
		Me._Label1_5.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_5.ForeColor = System.Drawing.Color.White
		Me._Label1_5.Size = New System.Drawing.Size(126, 23)
		Me._Label1_5.Location = New System.Drawing.Point(12, 46)
		Me._Label1_5.TabIndex = 28
		Me._Label1_5.Enabled = True
		Me._Label1_5.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_5.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_5.UseMnemonic = True
		Me._Label1_5.Visible = True
		Me._Label1_5.AutoSize = False
		Me._Label1_5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_5.Name = "_Label1_5"
		Me._Label1_4.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_4.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_4.Text = "���@��"
		Me._Label1_4.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_4.ForeColor = System.Drawing.Color.White
		Me._Label1_4.Size = New System.Drawing.Size(126, 23)
		Me._Label1_4.Location = New System.Drawing.Point(12, 20)
		Me._Label1_4.TabIndex = 27
		Me._Label1_4.Enabled = True
		Me._Label1_4.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_4.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_4.UseMnemonic = True
		Me._Label1_4.Visible = True
		Me._Label1_4.AutoSize = False
		Me._Label1_4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_4.Name = "_Label1_4"
		Me._Frame1_0.Enabled = False
		Me._Frame1_0.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Frame1_0.Size = New System.Drawing.Size(607, 81)
		Me._Frame1_0.Location = New System.Drawing.Point(0, 0)
		Me._Frame1_0.TabIndex = 18
		Me._Frame1_0.BackColor = System.Drawing.SystemColors.Control
		Me._Frame1_0.ForeColor = System.Drawing.SystemColors.ControlText
		Me._Frame1_0.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Frame1_0.Visible = True
		Me._Frame1_0.Padding = New System.Windows.Forms.Padding(0)
		Me._Frame1_0.Name = "_Frame1_0"
		_imText4_0.OcxState = CType(resources.GetObject("_imText4_0.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imText4_0.Size = New System.Drawing.Size(83, 23)
		Me._imText4_0.Location = New System.Drawing.Point(464, 46)
		Me._imText4_0.TabIndex = 21
		Me._imText4_0.Visible = False
		Me._imText4_0.Name = "_imText4_0"
		_imText3_2.OcxState = CType(resources.GetObject("_imText3_2.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imText3_2.Size = New System.Drawing.Size(269, 23)
		Me._imText3_2.Location = New System.Drawing.Point(278, 18)
		Me._imText3_2.TabIndex = 22
		Me._imText3_2.Name = "_imText3_2"
		_imText3_0.OcxState = CType(resources.GetObject("_imText3_0.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imText3_0.Size = New System.Drawing.Size(83, 23)
		Me._imText3_0.Location = New System.Drawing.Point(142, 18)
		Me._imText3_0.TabIndex = 23
		Me._imText3_0.Name = "_imText3_0"
		_imText3_1.OcxState = CType(resources.GetObject("_imText3_1.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imText3_1.Size = New System.Drawing.Size(45, 23)
		Me._imText3_1.Location = New System.Drawing.Point(229, 18)
		Me._imText3_1.TabIndex = 24
		Me._imText3_1.Name = "_imText3_1"
		_imText3_4.OcxState = CType(resources.GetObject("_imText3_4.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imText3_4.Size = New System.Drawing.Size(269, 23)
		Me._imText3_4.Location = New System.Drawing.Point(191, 46)
		Me._imText3_4.TabIndex = 25
		Me._imText3_4.Name = "_imText3_4"
		_imText3_3.OcxState = CType(resources.GetObject("_imText3_3.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imText3_3.Size = New System.Drawing.Size(45, 23)
		Me._imText3_3.Location = New System.Drawing.Point(142, 46)
		Me._imText3_3.TabIndex = 26
		Me._imText3_3.Name = "_imText3_3"
		_imText4_1.OcxState = CType(resources.GetObject("_imText4_1.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imText4_1.Size = New System.Drawing.Size(23, 23)
		Me._imText4_1.Location = New System.Drawing.Point(552, 46)
		Me._imText4_1.TabIndex = 34
		Me._imText4_1.Visible = False
		Me._imText4_1.Name = "_imText4_1"
		Me._Label1_1.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_1.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_1.Text = "�H�@��"
		Me._Label1_1.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_1.ForeColor = System.Drawing.Color.White
		Me._Label1_1.Size = New System.Drawing.Size(126, 23)
		Me._Label1_1.Location = New System.Drawing.Point(12, 46)
		Me._Label1_1.TabIndex = 33
		Me._Label1_1.Enabled = True
		Me._Label1_1.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_1.UseMnemonic = True
		Me._Label1_1.Visible = True
		Me._Label1_1.AutoSize = False
		Me._Label1_1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_1.Name = "_Label1_1"
		Me._Label1_0.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_0.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_0.Text = "�H�@��"
		Me._Label1_0.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_0.ForeColor = System.Drawing.Color.White
		Me._Label1_0.Size = New System.Drawing.Size(126, 23)
		Me._Label1_0.Location = New System.Drawing.Point(12, 18)
		Me._Label1_0.TabIndex = 32
		Me._Label1_0.Enabled = True
		Me._Label1_0.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_0.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_0.UseMnemonic = True
		Me._Label1_0.Visible = True
		Me._Label1_0.AutoSize = False
		Me._Label1_0.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_0.Name = "_Label1_0"
		Me.Picture1.Dock = System.Windows.Forms.DockStyle.Bottom
		Me.Picture1.BackColor = System.Drawing.Color.FromARGB(128, 128, 128)
		Me.Picture1.Size = New System.Drawing.Size(620, 51)
		Me.Picture1.Location = New System.Drawing.Point(0, 439)
		Me.Picture1.TabIndex = 15
		Me.Picture1.TabStop = False
		Me.Picture1.CausesValidation = True
		Me.Picture1.Enabled = True
		Me.Picture1.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Picture1.Cursor = System.Windows.Forms.Cursors.Default
		Me.Picture1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Picture1.Visible = True
		Me.Picture1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.Picture1.Name = "Picture1"
		Me._cmdKey_12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me._cmdKey_12.Text = "  F12  �I ��"
		Me._cmdKey_12.Font = New System.Drawing.Font("�l�r ����", 11.25!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._cmdKey_12.Size = New System.Drawing.Size(77, 39)
		Me._cmdKey_12.Location = New System.Drawing.Point(533, 4)
		Me._cmdKey_12.TabIndex = 13
		Me._cmdKey_12.Tag = "�I�����܂��B"
		Me._cmdKey_12.BackColor = System.Drawing.SystemColors.Control
		Me._cmdKey_12.CausesValidation = True
		Me._cmdKey_12.Enabled = True
		Me._cmdKey_12.ForeColor = System.Drawing.SystemColors.ControlText
		Me._cmdKey_12.Cursor = System.Windows.Forms.Cursors.Default
		Me._cmdKey_12.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._cmdKey_12.TabStop = True
		Me._cmdKey_12.Name = "_cmdKey_12"
		Me._cmdKey_1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me._cmdKey_1.Text = "  F1  �o �^"
		Me._cmdKey_1.Font = New System.Drawing.Font("�l�r ����", 11.25!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._cmdKey_1.Size = New System.Drawing.Size(77, 39)
		Me._cmdKey_1.Location = New System.Drawing.Point(6, 4)
		Me._cmdKey_1.TabIndex = 12
		Me._cmdKey_1.Tag = "���̓f�[�^��o�^���܂��B"
		Me._cmdKey_1.BackColor = System.Drawing.SystemColors.Control
		Me._cmdKey_1.CausesValidation = True
		Me._cmdKey_1.Enabled = True
		Me._cmdKey_1.ForeColor = System.Drawing.SystemColors.ControlText
		Me._cmdKey_1.Cursor = System.Windows.Forms.Cursors.Default
		Me._cmdKey_1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._cmdKey_1.TabStop = True
		Me._cmdKey_1.Name = "_cmdKey_1"
		Me.StatusBar1.Dock = System.Windows.Forms.DockStyle.Bottom
		Me.StatusBar1.Size = New System.Drawing.Size(620, 23)
		Me.StatusBar1.Location = New System.Drawing.Point(0, 490)
		Me.StatusBar1.TabIndex = 14
		Me.StatusBar1.Font = New System.Drawing.Font("�l�r �S�V�b�N", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me.StatusBar1.Name = "StatusBar1"
		Me._StatusBar1_Panel1.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter
		Me._StatusBar1_Panel1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
		Me._StatusBar1_Panel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me._StatusBar1_Panel1.Size = New System.Drawing.Size(117, 23)
		Me._StatusBar1_Panel1.BorderSides = CType(System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom, System.Windows.Forms.ToolStripStatusLabelBorderSides)
		Me._StatusBar1_Panel1.Margin = New System.Windows.Forms.Padding(0)
		Me._StatusBar1_Panel1.AutoSize = False
		Me._StatusBar1_Panel2.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter
		Me._StatusBar1_Panel2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
		Me._StatusBar1_Panel2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._StatusBar1_Panel2.Size = New System.Drawing.Size(902, 23)
		Me._StatusBar1_Panel2.BorderSides = CType(System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom, System.Windows.Forms.ToolStripStatusLabelBorderSides)
		Me._StatusBar1_Panel2.Margin = New System.Windows.Forms.Padding(0)
		Me._StatusBar1_Panel2.AutoSize = False
		Me.lblTitle.BackColor = System.Drawing.Color.FromARGB(192, 255, 255)
		Me.lblTitle.Text = " �ǉ�"
		Me.lblTitle.Font = New System.Drawing.Font("�l�r ����", 20.25!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me.lblTitle.ForeColor = System.Drawing.Color.FromARGB(0, 0, 128)
		Me.lblTitle.Size = New System.Drawing.Size(619, 31)
		Me.lblTitle.Location = New System.Drawing.Point(0, 0)
		Me.lblTitle.TabIndex = 16
		Me.lblTitle.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.lblTitle.Enabled = True
		Me.lblTitle.Cursor = System.Windows.Forms.Cursors.Default
		Me.lblTitle.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.lblTitle.UseMnemonic = True
		Me.lblTitle.Visible = True
		Me.lblTitle.AutoSize = False
		Me.lblTitle.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.lblTitle.Name = "lblTitle"
		Me.Controls.Add(Picture2)
		Me.Controls.Add(Picture1)
		Me.Controls.Add(StatusBar1)
		Me.Controls.Add(lblTitle)
		Me.Picture2.Controls.Add(_Frame1_4)
		Me.Picture2.Controls.Add(_Frame1_3)
		Me.Picture2.Controls.Add(_Frame1_1)
		Me.Picture2.Controls.Add(_Frame1_2)
		Me.Picture2.Controls.Add(_Frame1_0)
		Me._Frame1_4.Controls.Add(_imNumber3_0)
		Me._Frame1_4.Controls.Add(_imNumber3_1)
		Me._Frame1_4.Controls.Add(_imNumber3_2)
		Me._Frame1_4.Controls.Add(_Label1_11)
		Me._Frame1_4.Controls.Add(_Label1_12)
		Me._Frame1_4.Controls.Add(_Label1_14)
		Me._Frame1_3.Controls.Add(_imNumber2_0)
		Me._Frame1_3.Controls.Add(_imNumber2_1)
		Me._Frame1_3.Controls.Add(_imNumber2_2)
		Me._Frame1_3.Controls.Add(_Label1_8)
		Me._Frame1_3.Controls.Add(_Label1_9)
		Me._Frame1_3.Controls.Add(_Label1_10)
		Me._Frame1_1.Controls.Add(_cmdLook_5)
		Me._Frame1_1.Controls.Add(_imText1_5)
		Me._Frame1_1.Controls.Add(_imText4_5)
		Me._Frame1_1.Controls.Add(_imText2_5)
		Me._Frame1_1.Controls.Add(_imText2_6)
		Me._Frame1_1.Controls.Add(_imText1_0)
		Me._Frame1_1.Controls.Add(_Label1_3)
		Me._Frame1_1.Controls.Add(_Label1_2)
		Me._Frame1_2.Controls.Add(_imText1_3)
		Me._Frame1_2.Controls.Add(_imNumber1_0)
		Me._Frame1_2.Controls.Add(_imNumber1_1)
		Me._Frame1_2.Controls.Add(_imNumber1_2)
		Me._Frame1_2.Controls.Add(_Label1_7)
		Me._Frame1_2.Controls.Add(_Label1_6)
		Me._Frame1_2.Controls.Add(_Label1_5)
		Me._Frame1_2.Controls.Add(_Label1_4)
		Me._Frame1_0.Controls.Add(_imText4_0)
		Me._Frame1_0.Controls.Add(_imText3_2)
		Me._Frame1_0.Controls.Add(_imText3_0)
		Me._Frame1_0.Controls.Add(_imText3_1)
		Me._Frame1_0.Controls.Add(_imText3_4)
		Me._Frame1_0.Controls.Add(_imText3_3)
		Me._Frame1_0.Controls.Add(_imText4_1)
		Me._Frame1_0.Controls.Add(_Label1_1)
		Me._Frame1_0.Controls.Add(_Label1_0)
		Me.Picture1.Controls.Add(_cmdKey_12)
		Me.Picture1.Controls.Add(_cmdKey_1)
		Me.StatusBar1.Items.AddRange(New System.Windows.Forms.ToolStripItem(){Me._StatusBar1_Panel1})
		Me.StatusBar1.Items.AddRange(New System.Windows.Forms.ToolStripItem(){Me._StatusBar1_Panel2})
		Me.Frame1.SetIndex(_Frame1_4, CType(4, Short))
		Me.Frame1.SetIndex(_Frame1_3, CType(3, Short))
		Me.Frame1.SetIndex(_Frame1_1, CType(1, Short))
		Me.Frame1.SetIndex(_Frame1_2, CType(2, Short))
		Me.Frame1.SetIndex(_Frame1_0, CType(0, Short))
		Me.Label1.SetIndex(_Label1_11, CType(11, Short))
		Me.Label1.SetIndex(_Label1_12, CType(12, Short))
		Me.Label1.SetIndex(_Label1_14, CType(14, Short))
		Me.Label1.SetIndex(_Label1_8, CType(8, Short))
		Me.Label1.SetIndex(_Label1_9, CType(9, Short))
		Me.Label1.SetIndex(_Label1_10, CType(10, Short))
		Me.Label1.SetIndex(_Label1_3, CType(3, Short))
		Me.Label1.SetIndex(_Label1_2, CType(2, Short))
		Me.Label1.SetIndex(_Label1_7, CType(7, Short))
		Me.Label1.SetIndex(_Label1_6, CType(6, Short))
		Me.Label1.SetIndex(_Label1_5, CType(5, Short))
		Me.Label1.SetIndex(_Label1_4, CType(4, Short))
		Me.Label1.SetIndex(_Label1_1, CType(1, Short))
		Me.Label1.SetIndex(_Label1_0, CType(0, Short))
		Me.cmdKey.SetIndex(_cmdKey_12, CType(12, Short))
		Me.cmdKey.SetIndex(_cmdKey_1, CType(1, Short))
		Me.cmdLook.SetIndex(_cmdLook_5, CType(5, Short))
		Me.imNumber1.SetIndex(_imNumber1_0, CType(0, Short))
		Me.imNumber1.SetIndex(_imNumber1_1, CType(1, Short))
		Me.imNumber1.SetIndex(_imNumber1_2, CType(2, Short))
		Me.imNumber2.SetIndex(_imNumber2_0, CType(0, Short))
		Me.imNumber2.SetIndex(_imNumber2_1, CType(1, Short))
		Me.imNumber2.SetIndex(_imNumber2_2, CType(2, Short))
		Me.imNumber3.SetIndex(_imNumber3_0, CType(0, Short))
		Me.imNumber3.SetIndex(_imNumber3_1, CType(1, Short))
		Me.imNumber3.SetIndex(_imNumber3_2, CType(2, Short))
		Me.imText1.SetIndex(_imText1_5, CType(5, Short))
		Me.imText1.SetIndex(_imText1_0, CType(0, Short))
		Me.imText1.SetIndex(_imText1_3, CType(3, Short))
		Me.imText2.SetIndex(_imText2_5, CType(5, Short))
		Me.imText2.SetIndex(_imText2_6, CType(6, Short))
		Me.imText3.SetIndex(_imText3_2, CType(2, Short))
		Me.imText3.SetIndex(_imText3_0, CType(0, Short))
		Me.imText3.SetIndex(_imText3_1, CType(1, Short))
		Me.imText3.SetIndex(_imText3_4, CType(4, Short))
		Me.imText3.SetIndex(_imText3_3, CType(3, Short))
		Me.imText4.SetIndex(_imText4_5, CType(5, Short))
		Me.imText4.SetIndex(_imText4_0, CType(0, Short))
		Me.imText4.SetIndex(_imText4_1, CType(1, Short))
		CType(Me.imText4, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.imText3, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.imText2, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.imText1, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.imNumber3, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.imNumber2, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.imNumber1, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.cmdLook, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.cmdKey, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.Label1, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.Frame1, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imText4_1, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imText3_3, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imText3_4, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imText3_1, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imText3_0, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imText3_2, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imText4_0, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imNumber1_2, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imNumber1_1, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imNumber1_0, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imText1_3, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imText1_0, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imText2_6, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imText2_5, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imText4_5, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imText1_5, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imNumber2_2, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imNumber2_1, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imNumber2_0, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imNumber3_2, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imNumber3_1, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imNumber3_0, System.ComponentModel.ISupportInitialize).EndInit()
		Me.Picture2.ResumeLayout(False)
		Me._Frame1_4.ResumeLayout(False)
		Me._Frame1_3.ResumeLayout(False)
		Me._Frame1_1.ResumeLayout(False)
		Me._Frame1_2.ResumeLayout(False)
		Me._Frame1_0.ResumeLayout(False)
		Me.Picture1.ResumeLayout(False)
		Me.StatusBar1.ResumeLayout(False)
		Me.ResumeLayout(False)
		Me.PerformLayout()
	End Sub
#End Region 
End Class