<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frmSYKD075
#Region "Windows Form Designer generated code "
	<System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
		MyBase.New()
		'This call is required by the Windows Form Designer.
		InitializeComponent()
	End Sub
	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer
	Public ToolTip1 As System.Windows.Forms.ToolTip
	Public WithEvents _Check1_2 As System.Windows.Forms.CheckBox
	Public WithEvents _Check1_1 As System.Windows.Forms.CheckBox
	Public WithEvents _Check1_0 As System.Windows.Forms.CheckBox
	Public WithEvents Frame1 As System.Windows.Forms.GroupBox
	Public WithEvents _cmdKey_12 As System.Windows.Forms.Button
	Public WithEvents _cmdKey_1 As System.Windows.Forms.Button
	Public WithEvents Picture1 As System.Windows.Forms.Panel
	Public WithEvents _StatusBar1_Panel1 As System.Windows.Forms.ToolStripStatusLabel
	Public WithEvents _StatusBar1_Panel2 As System.Windows.Forms.ToolStripStatusLabel
	Public WithEvents StatusBar1 As System.Windows.Forms.StatusStrip
	Public WithEvents lblTitle As System.Windows.Forms.Label
	Public WithEvents Check1 As Microsoft.VisualBasic.Compatibility.VB6.CheckBoxArray
	Public WithEvents cmdKey As Microsoft.VisualBasic.Compatibility.VB6.ButtonArray
	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmSYKD075))
		Me.components = New System.ComponentModel.Container()
		Me.ToolTip1 = New System.Windows.Forms.ToolTip(components)
		Me.Frame1 = New System.Windows.Forms.GroupBox
		Me._Check1_2 = New System.Windows.Forms.CheckBox
		Me._Check1_1 = New System.Windows.Forms.CheckBox
		Me._Check1_0 = New System.Windows.Forms.CheckBox
		Me.Picture1 = New System.Windows.Forms.Panel
		Me._cmdKey_12 = New System.Windows.Forms.Button
		Me._cmdKey_1 = New System.Windows.Forms.Button
		Me.StatusBar1 = New System.Windows.Forms.StatusStrip
		Me._StatusBar1_Panel1 = New System.Windows.Forms.ToolStripStatusLabel
		Me._StatusBar1_Panel2 = New System.Windows.Forms.ToolStripStatusLabel
		Me.lblTitle = New System.Windows.Forms.Label
		Me.Check1 = New Microsoft.VisualBasic.Compatibility.VB6.CheckBoxArray(components)
		Me.cmdKey = New Microsoft.VisualBasic.Compatibility.VB6.ButtonArray(components)
		Me.Frame1.SuspendLayout()
		Me.Picture1.SuspendLayout()
		Me.StatusBar1.SuspendLayout()
		Me.SuspendLayout()
		Me.ToolTip1.Active = True
		CType(Me.Check1, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.cmdKey, System.ComponentModel.ISupportInitialize).BeginInit()
		Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
		Me.Text = "�H���Ǘ��V�X�e��"
		Me.ClientSize = New System.Drawing.Size(457, 260)
		Me.Location = New System.Drawing.Point(249, 291)
		Me.Icon = CType(resources.GetObject("frmSYKD075.Icon"), System.Drawing.Icon)
		Me.KeyPreview = True
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.BackColor = System.Drawing.SystemColors.Control
		Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Sizable
		Me.ControlBox = True
		Me.Enabled = True
		Me.MaximizeBox = True
		Me.MinimizeBox = True
		Me.Cursor = System.Windows.Forms.Cursors.Default
		Me.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.ShowInTaskbar = True
		Me.HelpButton = False
		Me.WindowState = System.Windows.Forms.FormWindowState.Normal
		Me.Name = "frmSYKD075"
		Me.Frame1.Size = New System.Drawing.Size(449, 139)
		Me.Frame1.Location = New System.Drawing.Point(4, 38)
		Me.Frame1.TabIndex = 8
		Me.Frame1.BackColor = System.Drawing.SystemColors.Control
		Me.Frame1.Enabled = True
		Me.Frame1.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Frame1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Frame1.Visible = True
		Me.Frame1.Padding = New System.Windows.Forms.Padding(0)
		Me.Frame1.Name = "Frame1"
		Me._Check1_2.Text = "�x���ꗗ�i�䗦�v�Z�j"
		Me._Check1_2.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Check1_2.Size = New System.Drawing.Size(263, 25)
		Me._Check1_2.Location = New System.Drawing.Point(108, 94)
		Me._Check1_2.TabIndex = 4
		Me._Check1_2.CheckState = System.Windows.Forms.CheckState.Checked
		Me._Check1_2.CheckAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._Check1_2.FlatStyle = System.Windows.Forms.FlatStyle.Standard
		Me._Check1_2.BackColor = System.Drawing.SystemColors.Control
		Me._Check1_2.CausesValidation = True
		Me._Check1_2.Enabled = True
		Me._Check1_2.ForeColor = System.Drawing.SystemColors.ControlText
		Me._Check1_2.Cursor = System.Windows.Forms.Cursors.Default
		Me._Check1_2.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Check1_2.Appearance = System.Windows.Forms.Appearance.Normal
		Me._Check1_2.TabStop = True
		Me._Check1_2.Visible = True
		Me._Check1_2.Name = "_Check1_2"
		Me._Check1_1.Text = "�O�����̓`�F�b�N���X�g"
		Me._Check1_1.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Check1_1.Size = New System.Drawing.Size(263, 25)
		Me._Check1_1.Location = New System.Drawing.Point(108, 60)
		Me._Check1_1.TabIndex = 3
		Me._Check1_1.CheckState = System.Windows.Forms.CheckState.Checked
		Me._Check1_1.CheckAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._Check1_1.FlatStyle = System.Windows.Forms.FlatStyle.Standard
		Me._Check1_1.BackColor = System.Drawing.SystemColors.Control
		Me._Check1_1.CausesValidation = True
		Me._Check1_1.Enabled = True
		Me._Check1_1.ForeColor = System.Drawing.SystemColors.ControlText
		Me._Check1_1.Cursor = System.Windows.Forms.Cursors.Default
		Me._Check1_1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Check1_1.Appearance = System.Windows.Forms.Appearance.Normal
		Me._Check1_1.TabStop = True
		Me._Check1_1.Visible = True
		Me._Check1_1.Name = "_Check1_1"
		Me._Check1_0.Text = "��ʕ����̓`�F�b�N���X�g"
		Me._Check1_0.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Check1_0.Size = New System.Drawing.Size(263, 25)
		Me._Check1_0.Location = New System.Drawing.Point(108, 26)
		Me._Check1_0.TabIndex = 2
		Me._Check1_0.CheckState = System.Windows.Forms.CheckState.Checked
		Me._Check1_0.CheckAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._Check1_0.FlatStyle = System.Windows.Forms.FlatStyle.Standard
		Me._Check1_0.BackColor = System.Drawing.SystemColors.Control
		Me._Check1_0.CausesValidation = True
		Me._Check1_0.Enabled = True
		Me._Check1_0.ForeColor = System.Drawing.SystemColors.ControlText
		Me._Check1_0.Cursor = System.Windows.Forms.Cursors.Default
		Me._Check1_0.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Check1_0.Appearance = System.Windows.Forms.Appearance.Normal
		Me._Check1_0.TabStop = True
		Me._Check1_0.Visible = True
		Me._Check1_0.Name = "_Check1_0"
		Me.Picture1.Dock = System.Windows.Forms.DockStyle.Bottom
		Me.Picture1.BackColor = System.Drawing.Color.FromARGB(128, 128, 128)
		Me.Picture1.Size = New System.Drawing.Size(457, 51)
		Me.Picture1.Location = New System.Drawing.Point(0, 186)
		Me.Picture1.TabIndex = 7
		Me.Picture1.TabStop = False
		Me.Picture1.CausesValidation = True
		Me.Picture1.Enabled = True
		Me.Picture1.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Picture1.Cursor = System.Windows.Forms.Cursors.Default
		Me.Picture1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Picture1.Visible = True
		Me.Picture1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.Picture1.Name = "Picture1"
		Me._cmdKey_12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me._cmdKey_12.Text = "  F12  �I ��"
		Me._cmdKey_12.Font = New System.Drawing.Font("�l�r ����", 11.25!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._cmdKey_12.Size = New System.Drawing.Size(77, 39)
		Me._cmdKey_12.Location = New System.Drawing.Point(370, 4)
		Me._cmdKey_12.TabIndex = 1
		Me._cmdKey_12.Tag = "�I�����܂��B"
		Me._cmdKey_12.BackColor = System.Drawing.SystemColors.Control
		Me._cmdKey_12.CausesValidation = True
		Me._cmdKey_12.Enabled = True
		Me._cmdKey_12.ForeColor = System.Drawing.SystemColors.ControlText
		Me._cmdKey_12.Cursor = System.Windows.Forms.Cursors.Default
		Me._cmdKey_12.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._cmdKey_12.TabStop = True
		Me._cmdKey_12.Name = "_cmdKey_12"
		Me._cmdKey_1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me._cmdKey_1.Text = "  F1  �� ��"
		Me._cmdKey_1.Font = New System.Drawing.Font("�l�r ����", 11.25!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._cmdKey_1.Size = New System.Drawing.Size(77, 39)
		Me._cmdKey_1.Location = New System.Drawing.Point(6, 4)
		Me._cmdKey_1.TabIndex = 0
		Me._cmdKey_1.Tag = "���̓`�F�b�N���X�g��������܂��B"
		Me._cmdKey_1.BackColor = System.Drawing.SystemColors.Control
		Me._cmdKey_1.CausesValidation = True
		Me._cmdKey_1.Enabled = True
		Me._cmdKey_1.ForeColor = System.Drawing.SystemColors.ControlText
		Me._cmdKey_1.Cursor = System.Windows.Forms.Cursors.Default
		Me._cmdKey_1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._cmdKey_1.TabStop = True
		Me._cmdKey_1.Name = "_cmdKey_1"
		Me.StatusBar1.Dock = System.Windows.Forms.DockStyle.Bottom
		Me.StatusBar1.Size = New System.Drawing.Size(457, 23)
		Me.StatusBar1.Location = New System.Drawing.Point(0, 237)
		Me.StatusBar1.TabIndex = 6
		Me.StatusBar1.Font = New System.Drawing.Font("�l�r �S�V�b�N", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me.StatusBar1.Name = "StatusBar1"
		Me._StatusBar1_Panel1.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter
		Me._StatusBar1_Panel1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
		Me._StatusBar1_Panel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me._StatusBar1_Panel1.Size = New System.Drawing.Size(117, 23)
		Me._StatusBar1_Panel1.BorderSides = CType(System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom, System.Windows.Forms.ToolStripStatusLabelBorderSides)
		Me._StatusBar1_Panel1.Margin = New System.Windows.Forms.Padding(0)
		Me._StatusBar1_Panel1.AutoSize = False
		Me._StatusBar1_Panel2.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter
		Me._StatusBar1_Panel2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
		Me._StatusBar1_Panel2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._StatusBar1_Panel2.Size = New System.Drawing.Size(902, 23)
		Me._StatusBar1_Panel2.BorderSides = CType(System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom, System.Windows.Forms.ToolStripStatusLabelBorderSides)
		Me._StatusBar1_Panel2.Margin = New System.Windows.Forms.Padding(0)
		Me._StatusBar1_Panel2.AutoSize = False
		Me.lblTitle.BackColor = System.Drawing.Color.FromARGB(192, 255, 255)
		Me.lblTitle.Text = " �x���ꗗ���"
		Me.lblTitle.Font = New System.Drawing.Font("�l�r ����", 20.25!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me.lblTitle.ForeColor = System.Drawing.Color.FromARGB(0, 0, 128)
		Me.lblTitle.Size = New System.Drawing.Size(457, 31)
		Me.lblTitle.Location = New System.Drawing.Point(0, 0)
		Me.lblTitle.TabIndex = 5
		Me.lblTitle.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.lblTitle.Enabled = True
		Me.lblTitle.Cursor = System.Windows.Forms.Cursors.Default
		Me.lblTitle.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.lblTitle.UseMnemonic = True
		Me.lblTitle.Visible = True
		Me.lblTitle.AutoSize = False
		Me.lblTitle.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.lblTitle.Name = "lblTitle"
		Me.Controls.Add(Frame1)
		Me.Controls.Add(Picture1)
		Me.Controls.Add(StatusBar1)
		Me.Controls.Add(lblTitle)
		Me.Frame1.Controls.Add(_Check1_2)
		Me.Frame1.Controls.Add(_Check1_1)
		Me.Frame1.Controls.Add(_Check1_0)
		Me.Picture1.Controls.Add(_cmdKey_12)
		Me.Picture1.Controls.Add(_cmdKey_1)
		Me.StatusBar1.Items.AddRange(New System.Windows.Forms.ToolStripItem(){Me._StatusBar1_Panel1})
		Me.StatusBar1.Items.AddRange(New System.Windows.Forms.ToolStripItem(){Me._StatusBar1_Panel2})
		Me.Check1.SetIndex(_Check1_2, CType(2, Short))
		Me.Check1.SetIndex(_Check1_1, CType(1, Short))
		Me.Check1.SetIndex(_Check1_0, CType(0, Short))
		Me.cmdKey.SetIndex(_cmdKey_12, CType(12, Short))
		Me.cmdKey.SetIndex(_cmdKey_1, CType(1, Short))
		CType(Me.cmdKey, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.Check1, System.ComponentModel.ISupportInitialize).EndInit()
		Me.Frame1.ResumeLayout(False)
		Me.Picture1.ResumeLayout(False)
		Me.StatusBar1.ResumeLayout(False)
		Me.ResumeLayout(False)
		Me.PerformLayout()
	End Sub
#End Region 
End Class