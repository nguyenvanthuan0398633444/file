Option Strict Off
Option Explicit On
Friend Class frmSYKD115
	Inherits System.Windows.Forms.Form
	'=============================================================
	' ���[�U�[���@  �F  �R�z�H�Ɗ������
	' �V�X�e�����@  �F  �H���Ǘ��V�X�e��
	' ���W���[����  �F  �O���o�����񍐏�������j���[���
	' ���W���[��ID�@�F  frmSYKD115.frm
	' �쐬���@ �@�@ �F  ���� 13 �N 07 �� 24 ��
	' �X�V���@�@  �@�F  ����    �N    ��    ��
	'=============================================================
	'
	
	Private Const RowHeight As Short = 15
	Private himc As Integer
	'
	
	'-------------------------------------------------------------------------------
	'   ����    :   �f�[�^�̎擾
	'   �֐�    :   Sub ListDataDisp()
	'   ����    :   Mode    0 = MsgBox�\��
	'   �@�\    :   �f�[�^�̎擾���s���܂��B
	'-------------------------------------------------------------------------------
	Public Sub ListDataDisp(Optional ByRef Mode As Short = 0)
		
		Dim Cnt As Integer
		Dim Jouken As String
		Dim Order As String
		Dim DT() As WARIDASI_MAST_DBT
		Dim wkBuf As String
		
		' �J�[�\���������v��
		'UPGRADE_WARNING: Screen property Screen.MousePointer has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6BA9B8D2-2A32-4B6E-8D36-44949974A5B4"'
		System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
		wkBuf = StatusBar1.Items.Item("Message").Text
		StatusBar1.Items.Item("Message").Text = "�Y���f�[�^�������E�E�E"
		
		' �e�[�u���̓Ǎ���
		Jouken = "EDA_NO = '" & KeyKouji.EDA_NO & "'"
		Jouken = Jouken & " AND KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"
		Jouken = Jouken & " AND CHOKUEI_KB = '2'"
		Order = "WARIDASI_NO"
		Cnt = SELECT_WARIDASI_MAST(Jouken, Order, DT)
		
		If Cnt <= 0 Then
			vaSpread1.MaxRows = 0
			cmdKey(1).Enabled = False
			StatusBar1.Items.Item("Message").Text = wkBuf
			'UPGRADE_WARNING: Screen property Screen.MousePointer has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6BA9B8D2-2A32-4B6E-8D36-44949974A5B4"'
			System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
			Exit Sub
		End If
		
		' �X�v���b�h�ɕ\��
		Call SprdDataSet(Cnt, DT)
		
		StatusBar1.Items.Item("Message").Text = wkBuf
		'UPGRADE_WARNING: Screen property Screen.MousePointer has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6BA9B8D2-2A32-4B6E-8D36-44949974A5B4"'
		System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
		
	End Sub
	
	'-------------------------------------------------------------------------------
	'   ����    :   �X�v���b�h�\��
	'   �֐�    :   Sub SprdDataSet(DT())
	'   ����    :   Cnt     �f�[�^����
	'   �@�@    :   DT()    WARIDASI_MAST_DBT
	'   �@�\    :   �f�[�^���X�v���b�h�ɕ\�����܂��B
	'-------------------------------------------------------------------------------
	Private Sub SprdDataSet(ByRef Cnt As Integer, ByRef DT() As WARIDASI_MAST_DBT)
		
		Dim lp As Integer
		Dim Row As Integer
		Dim ssText As Object
		
		With vaSpread1
			If Me.Visible = True Then
				.ReDraw = False
			End If
			.MaxRows = Cnt
			.Col = 1 : .Col2 = .MaxCols
			.Row = 1 : .Row2 = .MaxRows
			.BlockMode = True
			.Action = FPSpread.ActionConstants.ActionClearText
			.ForeColor = System.Drawing.Color.Black
			.BlockMode = False
			For lp = 0 To Cnt - 1
				.set_RowHeight(lp + 1, RowHeight)
				Row = lp + 1
				'----- CheckBox
				.SetText(1, Row, "1")
				'----- ������
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				ssText = Trim(DT(lp).WARIDASI_NO)
				.SetText(2, Row, ssText)
				'----- ����
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				ssText = Trim(DT(lp).MEISYOU)
				.SetText(3, Row, ssText)
				'----- �Ǝк���
				'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				ssText = Trim(DT(lp).GYOUSYA_CD)
				.SetText(4, Row, ssText)
				'----- �ƎЖ�
				If Trim(DT(lp).GYOUSYA_CD) <> "" Then
					'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
					ssText = Trim(GetNameGyousya(DT(lp).GYOUSYA_CD))
					.SetText(5, Row, ssText)
				End If
			Next lp
			If Me.Visible = True Then
				'UPGRADE_NOTE: Refresh was upgraded to CtlRefresh. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="A9E4979A-37FA-4718-9994-97DD76ED70A7"'
				.CtlRefresh()
				.ReDraw = True
			End If
		End With
		
	End Sub
	
	Private Sub cmdKey_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Click
		Dim Index As Short = cmdKey.GetIndex(eventSender)
		
		Dim lp As Integer
		Dim CDT() As String
		Dim Jouken As String
		Dim Msg As String
		Dim Col As Integer
		Dim Row As Integer
		
		Select Case Index
			Case 1 '----- ���
				If MsgBox("�񍐏���������܂��B��낵���ł����H", MsgBoxStyle.YesNo) = MsgBoxResult.No Then
					Exit Sub
				End If
				With vaSpread1
					ReDim Preserve CDT(.MaxRows)
					For lp = 1 To .MaxRows
						.Col = 1 : .Row = lp
						If .Text = "1" Then
							.Col = 2 : .Row = lp
							CDT(lp) = .Text
						End If
					Next lp
				End With
				System.Windows.Forms.Application.DoEvents()
				'UPGRADE_WARNING: Screen property Screen.MousePointer has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6BA9B8D2-2A32-4B6E-8D36-44949974A5B4"'
				System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
				StatusBar1.Items.Item("Message").Text = "����f�[�^�쐬���E�E�E"
				System.Windows.Forms.Application.DoEvents()
				'UPGRADE_WARNING: Couldn't resolve default property of object PrnMainD115(CDT()). Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				If PrnMainD115(CDT) = True Then
					'2001/01/21 �ҏW�̏ꍇ�̂ݍX�V����
					If INPMODE = "2" Then '�ҏW��
						' �H�����i����j�y�؂̍X�V
						CtlKouji.P_FLG_DEKIDAKA = "1" '���FLG �O���o�����񍐏�
						Jouken = "KOUJI_NO = '" & CtlKouji.KOUJI_NO & "' AND EDA_NO = '" & CtlKouji.EDA_NO & "'"
						If UPDATE_KOUJI_CTRL_D(Jouken, CtlKouji) = False Then
							Msg = "�H�����i����j�y�؂̍X�V�Ɏ��s���܂����B"
							MsgBox(Msg, MsgBoxStyle.OKOnly)
							Exit Sub
						End If
					End If
				End If
				System.Windows.Forms.Application.DoEvents()
				StatusBar1.Items.Item("Message").Text = ""
				'UPGRADE_WARNING: Screen property Screen.MousePointer has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6BA9B8D2-2A32-4B6E-8D36-44949974A5B4"'
				System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
				System.Windows.Forms.Application.DoEvents()
			Case 12 '----- �I��
				Me.Close()
		End Select
		
	End Sub
	
	Private Sub cmdKey_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Enter
		Dim Index As Short = cmdKey.GetIndex(eventSender)
		Call GotFocus(cmdKey(Index), StatusBar1)
	End Sub
	
	Private Sub cmdKey_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdKey.Leave
		Dim Index As Short = cmdKey.GetIndex(eventSender)
		Call LostFocus(cmdKey(Index), StatusBar1)
	End Sub
	
	Private Sub frmSYKD115_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown
		Dim KeyCode As Short = eventArgs.KeyCode
		Dim Shift As Short = eventArgs.KeyData \ &H10000
		Select Case KeyCode
			Case System.Windows.Forms.Keys.Return
				'UPGRADE_ISSUE: Control TabIndex could not be resolved because it was within the generic namespace ActiveControl. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="084D22AD-ECB1-400F-B4C7-418ECEC5E36E"'
				Call NextCntlGet(Me, Me.ActiveControl.TabIndex)
			Case System.Windows.Forms.Keys.F1
				If cmdKey(1).Enabled = True Then cmdKey(1).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(1), New System.EventArgs())
			Case System.Windows.Forms.Keys.F12
				If cmdKey(12).Enabled = True Then cmdKey(12).Focus() : System.Windows.Forms.Application.DoEvents() : Call cmdKey_Click(cmdKey.Item(12), New System.EventArgs())
		End Select
	End Sub
	
	Private Sub frmSYKD115_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
		
		Call FormDisp(Me)
		
		'�X�v���b�h��IME�N���n�e�e
		himc = ImmGetContext(vaSpread1.hWnd)
		
		Call ListDataDisp(1)
		
	End Sub
	
	Private Sub frmSYKD115_FormClosing(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
		Dim Cancel As Boolean = eventArgs.Cancel
		Dim UnloadMode As System.Windows.Forms.CloseReason = eventArgs.CloseReason
		If UnloadMode = System.Windows.Forms.CloseReason.UserClosing Then
			'
		End If
		eventArgs.Cancel = Cancel
	End Sub
	
	Private Sub vaSpread1_ClickEvent(ByVal eventSender As System.Object, ByVal eventArgs As AxFPSpread._DSpreadEvents_ClickEvent) Handles vaSpread1.ClickEvent
		
		Dim lp As Integer
		Dim ssText As Object
		
		If eventArgs.Col = 1 Then
			With vaSpread1
				If eventArgs.Row = 0 Then
					' �S�I��
					For lp = 1 To .MaxRows
						.GetText(1, lp, ssText)
						'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
						If ssText = "1" Then Exit For
					Next lp
					'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
					If ssText = "1" Then
						ssText = "0"
					Else
						'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
						ssText = "1"
					End If
					For lp = 1 To .MaxRows
						.eventArgs.Col = eventArgs.Col : .eventArgs.Row = lp
						'UPGRADE_WARNING: Couldn't resolve default property of object ssText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
						.Text = ssText
					Next lp
				Else
					.eventArgs.Col = eventArgs.Col : .eventArgs.Row = eventArgs.Row
					If .Text = "0" Then .Text = "1" Else .Text = "0"
				End If
			End With
		End If
		
	End Sub
	
	Private Sub vaSpread1_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles vaSpread1.Enter
		Call GotFocus(vaSpread1, StatusBar1)
		ImmSetOpenStatus(himc, False)
	End Sub
	
	Private Sub vaSpread1_KeyDownEvent(ByVal eventSender As System.Object, ByVal eventArgs As AxFPSpread._DSpreadEvents_KeyDownEvent) Handles vaSpread1.KeyDownEvent
		If eventArgs.KeyCode = System.Windows.Forms.Keys.Space Then
			Call vaSpread1_ClickEvent(vaSpread1, New AxFPSpread._DSpreadEvents_ClickEvent(1, vaSpread1.ActiveRow))
		End If
	End Sub
	
	Private Sub vaSpread1_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles vaSpread1.Leave
		Call LostFocus(vaSpread1, StatusBar1)
	End Sub
End Class