<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frmSYKD180
#Region "Windows Form Designer generated code "
	<System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
		MyBase.New()
		'This call is required by the Windows Form Designer.
		InitializeComponent()
	End Sub
	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer
	Public ToolTip1 As System.Windows.Forms.ToolTip
	Public WithEvents Check1 As System.Windows.Forms.CheckBox
	Public WithEvents _Label1_20 As System.Windows.Forms.Label
	Public WithEvents Picture3 As System.Windows.Forms.Panel
	Public WithEvents _imText6_0 As imText6.imText
	Public WithEvents _imText7_0 As imText6.imText
	Public WithEvents _imText6_1 As imText6.imText
	Public WithEvents _imText6_2 As imText6.imText
	Public WithEvents _imText6_4 As imText6.imText
	Public WithEvents _imText6_5 As imText6.imText
	Public WithEvents _imText7_1 As imText6.imText
	Public WithEvents _imNumber2_0 As imNumber6.imNumber
	Public WithEvents _imNumber2_1 As imNumber6.imNumber
	Public WithEvents _imNumber2_2 As imNumber6.imNumber
	Public WithEvents _imNumber2_3 As imNumber6.imNumber
	Public WithEvents _Label1_15 As System.Windows.Forms.Label
	Public WithEvents _Label1_13 As System.Windows.Forms.Label
	Public WithEvents _Label1_14 As System.Windows.Forms.Label
	Public WithEvents _Label1_12 As System.Windows.Forms.Label
	Public WithEvents _Label1_10 As System.Windows.Forms.Label
	Public WithEvents _Label1_11 As System.Windows.Forms.Label
	Public WithEvents _Label1_9 As System.Windows.Forms.Label
	Public WithEvents _Label1_8 As System.Windows.Forms.Label
	Public WithEvents _Label1_7 As System.Windows.Forms.Label
	Public WithEvents _Frame1_2 As System.Windows.Forms.GroupBox
	Public WithEvents VScroll1 As System.Windows.Forms.VScrollBar
	Public WithEvents _imText3_2 As imText6.imText
	Public WithEvents _imText5_2 As imText6.imText
	Public WithEvents _imText5_3 As imText6.imText
	Public WithEvents _imText5_0 As imText6.imText
	Public WithEvents _imText5_1 As imText6.imText
	Public WithEvents _Picture2_1 As System.Windows.Forms.Panel
	Public WithEvents _imText3_1 As imText6.imText
	Public WithEvents _imText4_2 As imText6.imText
	Public WithEvents _imNumber1_0 As imNumber6.imNumber
	Public WithEvents _imNumber1_1 As imNumber6.imNumber
	Public WithEvents _imText4_3 As imText6.imText
	Public WithEvents _Picture2_0 As System.Windows.Forms.Panel
	Public WithEvents _ctlGeppo1_0 As ctlGeppo
	Public WithEvents _ctlGeppo1_1 As ctlGeppo
	Public WithEvents _ctlGeppo1_2 As ctlGeppo
	Public WithEvents _Label1_6 As System.Windows.Forms.Label
	Public WithEvents _Label1_5 As System.Windows.Forms.Label
	Public WithEvents _Label1_4 As System.Windows.Forms.Label
	Public WithEvents _Label1_1 As System.Windows.Forms.Label
	Public WithEvents _Label1_3 As System.Windows.Forms.Label
	Public WithEvents _Label1_2 As System.Windows.Forms.Label
	Public WithEvents _Frame1_0 As System.Windows.Forms.GroupBox
	Public WithEvents _cmdKey_3 As System.Windows.Forms.Button
	Public WithEvents _cmdKey_12 As System.Windows.Forms.Button
	Public WithEvents _cmdKey_4 As System.Windows.Forms.Button
	Public WithEvents _cmdKey_10 As System.Windows.Forms.Button
	Public WithEvents _cmdKey_6 As System.Windows.Forms.Button
	Public WithEvents _cmdKey_7 As System.Windows.Forms.Button
	Public WithEvents _cmdKey_8 As System.Windows.Forms.Button
	Public WithEvents _cmdKey_9 As System.Windows.Forms.Button
	Public WithEvents _cmdKey_1 As System.Windows.Forms.Button
	Public WithEvents _cmdKey_11 As System.Windows.Forms.Button
	Public WithEvents _cmdKey_2 As System.Windows.Forms.Button
	Public WithEvents _cmdKey_5 As System.Windows.Forms.Button
	Public WithEvents Picture1 As System.Windows.Forms.Panel
	Public WithEvents _StatusBar1_Panel1 As System.Windows.Forms.ToolStripStatusLabel
	Public WithEvents _StatusBar1_Panel2 As System.Windows.Forms.ToolStripStatusLabel
	Public WithEvents StatusBar1 As System.Windows.Forms.StatusStrip
	Public WithEvents _imText2_2 As imText6.imText
	Public WithEvents _imText2_0 As imText6.imText
	Public WithEvents _imText2_1 As imText6.imText
	Public WithEvents vaSpread1 As AxFPSpread.AxvaSpread
	Public WithEvents vaSpread2 As AxFPSpread.AxvaSpread
	Public WithEvents _imText3_0 As imText6.imText
	Public WithEvents _imText1_0 As imText6.imText
	Public WithEvents _imDate1_0 As imDate6.imDate
	Public WithEvents _imDate1_1 As imDate6.imDate
	Public WithEvents _imDate1_2 As imDate6.imDate
	Public WithEvents _imText1_1 As imText6.imText
	Public WithEvents _Label1_19 As System.Windows.Forms.Label
	Public WithEvents _Label1_17 As System.Windows.Forms.Label
	Public WithEvents _Label1_16 As System.Windows.Forms.Label
	Public WithEvents _Label1_18 As System.Windows.Forms.Label
	Public WithEvents _Frame1_1 As System.Windows.Forms.GroupBox
	Public WithEvents _Label1_0 As System.Windows.Forms.Label
	Public WithEvents lblTitle As System.Windows.Forms.Label
	Public WithEvents Frame1 As Microsoft.VisualBasic.Compatibility.VB6.GroupBoxArray
	Public WithEvents Label1 As Microsoft.VisualBasic.Compatibility.VB6.LabelArray
	Public WithEvents Picture2 As Microsoft.VisualBasic.Compatibility.VB6.PanelArray
	Public WithEvents cmdKey As Microsoft.VisualBasic.Compatibility.VB6.ButtonArray
	Public WithEvents ctlGeppo1 As ctlGeppoArray
	Public WithEvents imDate1 As imDateArray
	Public WithEvents imNumber1 As imNumberArray
	Public WithEvents imNumber2 As imNumberArray
	Public WithEvents imText1 As imTextArray
	Public WithEvents imText2 As imTextArray
	Public WithEvents imText3 As imTextArray
	Public WithEvents imText4 As imTextArray
	Public WithEvents imText5 As imTextArray
	Public WithEvents imText6 As imTextArray
	Public WithEvents imText7 As imTextArray
	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmSYKD180))
		Me.components = New System.ComponentModel.Container()
		Me.ToolTip1 = New System.Windows.Forms.ToolTip(components)
		Me.Check1 = New System.Windows.Forms.CheckBox
		Me.Picture3 = New System.Windows.Forms.Panel
		Me._Label1_20 = New System.Windows.Forms.Label
		Me._Frame1_2 = New System.Windows.Forms.GroupBox
		Me._imText6_0 = New imText6.imText
		Me._imText7_0 = New imText6.imText
		Me._imText6_1 = New imText6.imText
		Me._imText6_2 = New imText6.imText
		Me._imText6_4 = New imText6.imText
		Me._imText6_5 = New imText6.imText
		Me._imText7_1 = New imText6.imText
		Me._imNumber2_0 = New imNumber6.imNumber
		Me._imNumber2_1 = New imNumber6.imNumber
		Me._imNumber2_2 = New imNumber6.imNumber
		Me._imNumber2_3 = New imNumber6.imNumber
		Me._Label1_15 = New System.Windows.Forms.Label
		Me._Label1_13 = New System.Windows.Forms.Label
		Me._Label1_14 = New System.Windows.Forms.Label
		Me._Label1_12 = New System.Windows.Forms.Label
		Me._Label1_10 = New System.Windows.Forms.Label
		Me._Label1_11 = New System.Windows.Forms.Label
		Me._Label1_9 = New System.Windows.Forms.Label
		Me._Label1_8 = New System.Windows.Forms.Label
		Me._Label1_7 = New System.Windows.Forms.Label
		Me._Frame1_0 = New System.Windows.Forms.GroupBox
		Me.VScroll1 = New System.Windows.Forms.VScrollBar
		Me._Picture2_1 = New System.Windows.Forms.Panel
		Me._imText3_2 = New imText6.imText
		Me._imText5_2 = New imText6.imText
		Me._imText5_3 = New imText6.imText
		Me._imText5_0 = New imText6.imText
		Me._imText5_1 = New imText6.imText
		Me._Picture2_0 = New System.Windows.Forms.Panel
		Me._imText3_1 = New imText6.imText
		Me._imText4_2 = New imText6.imText
		Me._imNumber1_0 = New imNumber6.imNumber
		Me._imNumber1_1 = New imNumber6.imNumber
		Me._imText4_3 = New imText6.imText
		Me._ctlGeppo1_0 = New ctlGeppo
		Me._ctlGeppo1_1 = New ctlGeppo
		Me._ctlGeppo1_2 = New ctlGeppo
		Me._Label1_6 = New System.Windows.Forms.Label
		Me._Label1_5 = New System.Windows.Forms.Label
		Me._Label1_4 = New System.Windows.Forms.Label
		Me._Label1_1 = New System.Windows.Forms.Label
		Me._Label1_3 = New System.Windows.Forms.Label
		Me._Label1_2 = New System.Windows.Forms.Label
		Me.Picture1 = New System.Windows.Forms.Panel
		Me._cmdKey_3 = New System.Windows.Forms.Button
		Me._cmdKey_12 = New System.Windows.Forms.Button
		Me._cmdKey_4 = New System.Windows.Forms.Button
		Me._cmdKey_10 = New System.Windows.Forms.Button
		Me._cmdKey_6 = New System.Windows.Forms.Button
		Me._cmdKey_7 = New System.Windows.Forms.Button
		Me._cmdKey_8 = New System.Windows.Forms.Button
		Me._cmdKey_9 = New System.Windows.Forms.Button
		Me._cmdKey_1 = New System.Windows.Forms.Button
		Me._cmdKey_11 = New System.Windows.Forms.Button
		Me._cmdKey_2 = New System.Windows.Forms.Button
		Me._cmdKey_5 = New System.Windows.Forms.Button
		Me.StatusBar1 = New System.Windows.Forms.StatusStrip
		Me._StatusBar1_Panel1 = New System.Windows.Forms.ToolStripStatusLabel
		Me._StatusBar1_Panel2 = New System.Windows.Forms.ToolStripStatusLabel
		Me._imText2_2 = New imText6.imText
		Me._imText2_0 = New imText6.imText
		Me._imText2_1 = New imText6.imText
		Me.vaSpread1 = New AxFPSpread.AxvaSpread
		Me.vaSpread2 = New AxFPSpread.AxvaSpread
		Me._imText3_0 = New imText6.imText
		Me._Frame1_1 = New System.Windows.Forms.GroupBox
		Me._imText1_0 = New imText6.imText
		Me._imDate1_0 = New imDate6.imDate
		Me._imDate1_1 = New imDate6.imDate
		Me._imDate1_2 = New imDate6.imDate
		Me._imText1_1 = New imText6.imText
		Me._Label1_19 = New System.Windows.Forms.Label
		Me._Label1_17 = New System.Windows.Forms.Label
		Me._Label1_16 = New System.Windows.Forms.Label
		Me._Label1_18 = New System.Windows.Forms.Label
		Me._Label1_0 = New System.Windows.Forms.Label
		Me.lblTitle = New System.Windows.Forms.Label
		Me.Frame1 = New Microsoft.VisualBasic.Compatibility.VB6.GroupBoxArray(components)
		Me.Label1 = New Microsoft.VisualBasic.Compatibility.VB6.LabelArray(components)
		Me.Picture2 = New Microsoft.VisualBasic.Compatibility.VB6.PanelArray(components)
		Me.cmdKey = New Microsoft.VisualBasic.Compatibility.VB6.ButtonArray(components)
		Me.ctlGeppo1 = New ctlGeppoArray(components)
		Me.imDate1 = New imDateArray(components)
		Me.imNumber1 = New imNumberArray(components)
		Me.imNumber2 = New imNumberArray(components)
		Me.imText1 = New imTextArray(components)
		Me.imText2 = New imTextArray(components)
		Me.imText3 = New imTextArray(components)
		Me.imText4 = New imTextArray(components)
		Me.imText5 = New imTextArray(components)
		Me.imText6 = New imTextArray(components)
		Me.imText7 = New imTextArray(components)
		Me.Picture3.SuspendLayout()
		Me._Frame1_2.SuspendLayout()
		Me._Frame1_0.SuspendLayout()
		Me._Picture2_1.SuspendLayout()
		Me._Picture2_0.SuspendLayout()
		Me.Picture1.SuspendLayout()
		Me.StatusBar1.SuspendLayout()
		Me._Frame1_1.SuspendLayout()
		Me.SuspendLayout()
		Me.ToolTip1.Active = True
		CType(Me._imText6_0, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imText7_0, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imText6_1, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imText6_2, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imText6_4, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imText6_5, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imText7_1, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imNumber2_0, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imNumber2_1, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imNumber2_2, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imNumber2_3, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imText3_2, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imText5_2, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imText5_3, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imText5_0, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imText5_1, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imText3_1, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imText4_2, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imNumber1_0, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imNumber1_1, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imText4_3, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imText2_2, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imText2_0, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imText2_1, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.vaSpread1, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.vaSpread2, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imText3_0, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imText1_0, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imDate1_0, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imDate1_1, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imDate1_2, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me._imText1_1, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.Frame1, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.Label1, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.Picture2, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.cmdKey, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.ctlGeppo1, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.imDate1, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.imNumber1, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.imNumber2, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.imText1, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.imText2, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.imText3, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.imText4, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.imText5, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.imText6, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.imText7, System.ComponentModel.ISupportInitialize).BeginInit()
		Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
		Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
		Me.Text = "�H���Ǘ��V�X�e��"
		Me.ClientSize = New System.Drawing.Size(1016, 742)
		Me.Location = New System.Drawing.Point(5, 23)
		Me.Icon = CType(resources.GetObject("frmSYKD180.Icon"), System.Drawing.Icon)
		Me.KeyPreview = True
		Me.MaximizeBox = False
		Me.MinimizeBox = False
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.BackColor = System.Drawing.SystemColors.Control
		Me.ControlBox = True
		Me.Enabled = True
		Me.Cursor = System.Windows.Forms.Cursors.Default
		Me.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.ShowInTaskbar = True
		Me.HelpButton = False
		Me.WindowState = System.Windows.Forms.FormWindowState.Normal
		Me.Name = "frmSYKD180"
		Me.Check1.Text = "���F"
		Me.Check1.Font = New System.Drawing.Font("�l�r ����", 9!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me.Check1.Size = New System.Drawing.Size(55, 17)
		Me.Check1.Location = New System.Drawing.Point(248, 392)
		Me.Check1.TabIndex = 30
		Me.Check1.Tag = "���F����ꍇ���������ĉ������B"
		Me.Check1.CheckAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me.Check1.FlatStyle = System.Windows.Forms.FlatStyle.Standard
		Me.Check1.BackColor = System.Drawing.SystemColors.Control
		Me.Check1.CausesValidation = True
		Me.Check1.Enabled = True
		Me.Check1.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Check1.Cursor = System.Windows.Forms.Cursors.Default
		Me.Check1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Check1.Appearance = System.Windows.Forms.Appearance.Normal
		Me.Check1.TabStop = True
		Me.Check1.CheckState = System.Windows.Forms.CheckState.Unchecked
		Me.Check1.Visible = True
		Me.Check1.Name = "Check1"
		Me.Picture3.Enabled = False
		Me.Picture3.Size = New System.Drawing.Size(109, 26)
		Me.Picture3.Location = New System.Drawing.Point(250, 378)
		Me.Picture3.TabIndex = 76
		Me.Picture3.TabStop = False
		Me.Picture3.Dock = System.Windows.Forms.DockStyle.None
		Me.Picture3.BackColor = System.Drawing.SystemColors.Control
		Me.Picture3.CausesValidation = True
		Me.Picture3.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Picture3.Cursor = System.Windows.Forms.Cursors.Default
		Me.Picture3.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Picture3.Visible = True
		Me.Picture3.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Picture3.Name = "Picture3"
		Me._Label1_20.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_20.BackColor = System.Drawing.Color.Transparent
		Me._Label1_20.Text = "��Ɋz���͎�Ɂ@�@�@�@�@�@�\��z"
		Me._Label1_20.Font = New System.Drawing.Font("�l�r ����", 9!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_20.ForeColor = System.Drawing.Color.Black
		Me._Label1_20.Size = New System.Drawing.Size(109, 26)
		Me._Label1_20.Location = New System.Drawing.Point(0, 0)
		Me._Label1_20.TabIndex = 77
		Me._Label1_20.Enabled = True
		Me._Label1_20.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_20.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_20.UseMnemonic = True
		Me._Label1_20.Visible = True
		Me._Label1_20.AutoSize = False
		Me._Label1_20.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._Label1_20.Name = "_Label1_20"
		Me._Frame1_2.Size = New System.Drawing.Size(349, 307)
		Me._Frame1_2.Location = New System.Drawing.Point(658, 60)
		Me._Frame1_2.TabIndex = 66
		Me._Frame1_2.BackColor = System.Drawing.SystemColors.Control
		Me._Frame1_2.Enabled = True
		Me._Frame1_2.ForeColor = System.Drawing.SystemColors.ControlText
		Me._Frame1_2.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Frame1_2.Visible = True
		Me._Frame1_2.Padding = New System.Windows.Forms.Padding(0)
		Me._Frame1_2.Name = "_Frame1_2"
		_imText6_0.OcxState = CType(resources.GetObject("_imText6_0.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imText6_0.Size = New System.Drawing.Size(127, 23)
		Me._imText6_0.Location = New System.Drawing.Point(148, 14)
		Me._imText6_0.TabIndex = 20
		Me._imText6_0.Name = "_imText6_0"
		_imText7_0.OcxState = CType(resources.GetObject("_imText7_0.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imText7_0.Size = New System.Drawing.Size(63, 23)
		Me._imText7_0.Location = New System.Drawing.Point(278, 14)
		Me._imText7_0.TabIndex = 21
		Me._imText7_0.Name = "_imText7_0"
		_imText6_1.OcxState = CType(resources.GetObject("_imText6_1.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imText6_1.Size = New System.Drawing.Size(127, 23)
		Me._imText6_1.Location = New System.Drawing.Point(148, 40)
		Me._imText6_1.TabIndex = 22
		Me._imText6_1.Name = "_imText6_1"
		_imText6_2.OcxState = CType(resources.GetObject("_imText6_2.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imText6_2.Size = New System.Drawing.Size(127, 23)
		Me._imText6_2.Location = New System.Drawing.Point(148, 66)
		Me._imText6_2.TabIndex = 23
		Me._imText6_2.Name = "_imText6_2"
		_imText6_4.OcxState = CType(resources.GetObject("_imText6_4.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imText6_4.Size = New System.Drawing.Size(127, 23)
		Me._imText6_4.Location = New System.Drawing.Point(148, 144)
		Me._imText6_4.TabIndex = 26
		Me._imText6_4.Name = "_imText6_4"
		_imText6_5.OcxState = CType(resources.GetObject("_imText6_5.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imText6_5.Size = New System.Drawing.Size(127, 23)
		Me._imText6_5.Location = New System.Drawing.Point(148, 222)
		Me._imText6_5.TabIndex = 29
		Me._imText6_5.Name = "_imText6_5"
		_imText7_1.OcxState = CType(resources.GetObject("_imText7_1.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imText7_1.Size = New System.Drawing.Size(63, 23)
		Me._imText7_1.Location = New System.Drawing.Point(278, 92)
		Me._imText7_1.TabIndex = 25
		Me._imText7_1.Name = "_imText7_1"
		_imNumber2_0.OcxState = CType(resources.GetObject("_imNumber2_0.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imNumber2_0.Size = New System.Drawing.Size(127, 23)
		Me._imNumber2_0.Location = New System.Drawing.Point(148, 92)
		Me._imNumber2_0.TabIndex = 24
		Me._imNumber2_0.Name = "_imNumber2_0"
		_imNumber2_1.OcxState = CType(resources.GetObject("_imNumber2_1.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imNumber2_1.Size = New System.Drawing.Size(127, 23)
		Me._imNumber2_1.Location = New System.Drawing.Point(148, 170)
		Me._imNumber2_1.TabIndex = 27
		Me._imNumber2_1.Name = "_imNumber2_1"
		_imNumber2_2.OcxState = CType(resources.GetObject("_imNumber2_2.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imNumber2_2.Size = New System.Drawing.Size(127, 23)
		Me._imNumber2_2.Location = New System.Drawing.Point(148, 196)
		Me._imNumber2_2.TabIndex = 28
		Me._imNumber2_2.Name = "_imNumber2_2"
		_imNumber2_3.OcxState = CType(resources.GetObject("_imNumber2_3.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imNumber2_3.Size = New System.Drawing.Size(127, 23)
		Me._imNumber2_3.Location = New System.Drawing.Point(148, 118)
		Me._imNumber2_3.TabIndex = 78
		Me._imNumber2_3.Name = "_imNumber2_3"
		Me._Label1_15.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_15.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_15.Text = "�扺�c��"
		Me._Label1_15.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_15.ForeColor = System.Drawing.Color.White
		Me._Label1_15.Size = New System.Drawing.Size(137, 23)
		Me._Label1_15.Location = New System.Drawing.Point(8, 222)
		Me._Label1_15.TabIndex = 75
		Me._Label1_15.Enabled = True
		Me._Label1_15.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_15.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_15.UseMnemonic = True
		Me._Label1_15.Visible = True
		Me._Label1_15.AutoSize = False
		Me._Label1_15.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_15.Name = "_Label1_15"
		Me._Label1_13.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_13.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_13.Text = "�����w�͖ڕW"
		Me._Label1_13.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_13.ForeColor = System.Drawing.Color.White
		Me._Label1_13.Size = New System.Drawing.Size(137, 23)
		Me._Label1_13.Location = New System.Drawing.Point(8, 170)
		Me._Label1_13.TabIndex = 74
		Me._Label1_13.Enabled = True
		Me._Label1_13.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_13.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_13.UseMnemonic = True
		Me._Label1_13.Visible = True
		Me._Label1_13.AutoSize = False
		Me._Label1_13.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_13.Name = "_Label1_13"
		Me._Label1_14.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_14.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_14.Text = "�� �� �z"
		Me._Label1_14.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_14.ForeColor = System.Drawing.Color.White
		Me._Label1_14.Size = New System.Drawing.Size(137, 23)
		Me._Label1_14.Location = New System.Drawing.Point(8, 196)
		Me._Label1_14.TabIndex = 73
		Me._Label1_14.Enabled = True
		Me._Label1_14.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_14.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_14.UseMnemonic = True
		Me._Label1_14.Visible = True
		Me._Label1_14.AutoSize = False
		Me._Label1_14.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_14.Name = "_Label1_14"
		Me._Label1_12.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_12.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_12.Text = "���񐿕��o����"
		Me._Label1_12.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_12.ForeColor = System.Drawing.Color.White
		Me._Label1_12.Size = New System.Drawing.Size(137, 23)
		Me._Label1_12.Location = New System.Drawing.Point(8, 144)
		Me._Label1_12.TabIndex = 72
		Me._Label1_12.Enabled = True
		Me._Label1_12.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_12.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_12.UseMnemonic = True
		Me._Label1_12.Visible = True
		Me._Label1_12.AutoSize = False
		Me._Label1_12.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_12.Name = "_Label1_12"
		Me._Label1_10.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_10.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_10.Text = "�������o����"
		Me._Label1_10.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_10.ForeColor = System.Drawing.Color.White
		Me._Label1_10.Size = New System.Drawing.Size(137, 23)
		Me._Label1_10.Location = New System.Drawing.Point(8, 92)
		Me._Label1_10.TabIndex = 71
		Me._Label1_10.Enabled = True
		Me._Label1_10.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_10.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_10.UseMnemonic = True
		Me._Label1_10.Visible = True
		Me._Label1_10.AutoSize = False
		Me._Label1_10.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_10.Name = "_Label1_10"
		Me._Label1_11.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_11.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_11.Text = "�O�񐿕��o����"
		Me._Label1_11.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_11.ForeColor = System.Drawing.Color.White
		Me._Label1_11.Size = New System.Drawing.Size(137, 23)
		Me._Label1_11.Location = New System.Drawing.Point(8, 118)
		Me._Label1_11.TabIndex = 70
		Me._Label1_11.Enabled = True
		Me._Label1_11.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_11.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_11.UseMnemonic = True
		Me._Label1_11.Visible = True
		Me._Label1_11.AutoSize = False
		Me._Label1_11.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_11.Name = "_Label1_11"
		Me._Label1_9.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_9.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_9.Text = "������{���z"
		Me._Label1_9.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_9.ForeColor = System.Drawing.Color.White
		Me._Label1_9.Size = New System.Drawing.Size(137, 23)
		Me._Label1_9.Location = New System.Drawing.Point(8, 66)
		Me._Label1_9.TabIndex = 69
		Me._Label1_9.Enabled = True
		Me._Label1_9.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_9.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_9.UseMnemonic = True
		Me._Label1_9.Visible = True
		Me._Label1_9.AutoSize = False
		Me._Label1_9.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_9.Name = "_Label1_9"
		Me._Label1_8.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_8.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_8.Text = "�O�񖘎��{���z"
		Me._Label1_8.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_8.ForeColor = System.Drawing.Color.White
		Me._Label1_8.Size = New System.Drawing.Size(137, 23)
		Me._Label1_8.Location = New System.Drawing.Point(8, 40)
		Me._Label1_8.TabIndex = 68
		Me._Label1_8.Enabled = True
		Me._Label1_8.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_8.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_8.UseMnemonic = True
		Me._Label1_8.Visible = True
		Me._Label1_8.AutoSize = False
		Me._Label1_8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_8.Name = "_Label1_8"
		Me._Label1_7.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_7.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_7.Text = "�݌v���{���z"
		Me._Label1_7.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_7.ForeColor = System.Drawing.Color.White
		Me._Label1_7.Size = New System.Drawing.Size(137, 23)
		Me._Label1_7.Location = New System.Drawing.Point(8, 14)
		Me._Label1_7.TabIndex = 67
		Me._Label1_7.Enabled = True
		Me._Label1_7.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_7.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_7.UseMnemonic = True
		Me._Label1_7.Visible = True
		Me._Label1_7.AutoSize = False
		Me._Label1_7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_7.Name = "_Label1_7"
		Me._Frame1_0.Size = New System.Drawing.Size(648, 209)
		Me._Frame1_0.Location = New System.Drawing.Point(6, 60)
		Me._Frame1_0.TabIndex = 52
		Me._Frame1_0.BackColor = System.Drawing.SystemColors.Control
		Me._Frame1_0.Enabled = True
		Me._Frame1_0.ForeColor = System.Drawing.SystemColors.ControlText
		Me._Frame1_0.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Frame1_0.Visible = True
		Me._Frame1_0.Padding = New System.Windows.Forms.Padding(0)
		Me._Frame1_0.Name = "_Frame1_0"
		Me.VScroll1.Size = New System.Drawing.Size(17, 96)
		Me.VScroll1.LargeChange = 3
		Me.VScroll1.Location = New System.Drawing.Point(622, 72)
		Me.VScroll1.Maximum = 4
		Me.VScroll1.TabIndex = 9
		Me.VScroll1.CausesValidation = True
		Me.VScroll1.Enabled = True
		Me.VScroll1.Minimum = 0
		Me.VScroll1.Cursor = System.Windows.Forms.Cursors.Default
		Me.VScroll1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.VScroll1.SmallChange = 1
		Me.VScroll1.TabStop = True
		Me.VScroll1.Value = 0
		Me.VScroll1.Visible = True
		Me.VScroll1.Name = "VScroll1"
		Me._Picture2_1.Enabled = False
		Me._Picture2_1.Size = New System.Drawing.Size(613, 31)
		Me._Picture2_1.Location = New System.Drawing.Point(8, 170)
		Me._Picture2_1.TabIndex = 57
		Me._Picture2_1.TabStop = False
		Me._Picture2_1.Dock = System.Windows.Forms.DockStyle.None
		Me._Picture2_1.BackColor = System.Drawing.SystemColors.Control
		Me._Picture2_1.CausesValidation = True
		Me._Picture2_1.ForeColor = System.Drawing.SystemColors.ControlText
		Me._Picture2_1.Cursor = System.Windows.Forms.Cursors.Default
		Me._Picture2_1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Picture2_1.Visible = True
		Me._Picture2_1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Picture2_1.Name = "_Picture2_1"
		_imText3_2.OcxState = CType(resources.GetObject("_imText3_2.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imText3_2.Size = New System.Drawing.Size(148, 23)
		Me._imText3_2.Location = New System.Drawing.Point(3, 2)
		Me._imText3_2.TabIndex = 10
		Me._imText3_2.Name = "_imText3_2"
		_imText5_2.OcxState = CType(resources.GetObject("_imText5_2.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imText5_2.Size = New System.Drawing.Size(127, 23)
		Me._imText5_2.Location = New System.Drawing.Point(414, 2)
		Me._imText5_2.TabIndex = 13
		Me._imText5_2.Name = "_imText5_2"
		_imText5_3.OcxState = CType(resources.GetObject("_imText5_3.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imText5_3.Size = New System.Drawing.Size(63, 23)
		Me._imText5_3.Location = New System.Drawing.Point(544, 2)
		Me._imText5_3.TabIndex = 14
		Me._imText5_3.Name = "_imText5_3"
		_imText5_0.OcxState = CType(resources.GetObject("_imText5_0.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imText5_0.Size = New System.Drawing.Size(127, 23)
		Me._imText5_0.Location = New System.Drawing.Point(154, 2)
		Me._imText5_0.TabIndex = 11
		Me._imText5_0.Name = "_imText5_0"
		_imText5_1.OcxState = CType(resources.GetObject("_imText5_1.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imText5_1.Size = New System.Drawing.Size(127, 23)
		Me._imText5_1.Location = New System.Drawing.Point(284, 2)
		Me._imText5_1.TabIndex = 12
		Me._imText5_1.Name = "_imText5_1"
		Me._Picture2_0.Size = New System.Drawing.Size(613, 31)
		Me._Picture2_0.Location = New System.Drawing.Point(8, 40)
		Me._Picture2_0.TabIndex = 56
		Me._Picture2_0.TabStop = False
		Me._Picture2_0.Dock = System.Windows.Forms.DockStyle.None
		Me._Picture2_0.BackColor = System.Drawing.SystemColors.Control
		Me._Picture2_0.CausesValidation = True
		Me._Picture2_0.Enabled = True
		Me._Picture2_0.ForeColor = System.Drawing.SystemColors.ControlText
		Me._Picture2_0.Cursor = System.Windows.Forms.Cursors.Default
		Me._Picture2_0.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Picture2_0.Visible = True
		Me._Picture2_0.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Picture2_0.Name = "_Picture2_0"
		_imText3_1.OcxState = CType(resources.GetObject("_imText3_1.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imText3_1.Size = New System.Drawing.Size(148, 23)
		Me._imText3_1.Location = New System.Drawing.Point(3, 2)
		Me._imText3_1.TabIndex = 1
		Me._imText3_1.Name = "_imText3_1"
		_imText4_2.OcxState = CType(resources.GetObject("_imText4_2.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imText4_2.Size = New System.Drawing.Size(127, 23)
		Me._imText4_2.Location = New System.Drawing.Point(414, 2)
		Me._imText4_2.TabIndex = 4
		Me._imText4_2.Name = "_imText4_2"
		_imNumber1_0.OcxState = CType(resources.GetObject("_imNumber1_0.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imNumber1_0.Size = New System.Drawing.Size(127, 23)
		Me._imNumber1_0.Location = New System.Drawing.Point(154, 2)
		Me._imNumber1_0.TabIndex = 2
		Me._imNumber1_0.Name = "_imNumber1_0"
		_imNumber1_1.OcxState = CType(resources.GetObject("_imNumber1_1.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imNumber1_1.Size = New System.Drawing.Size(127, 23)
		Me._imNumber1_1.Location = New System.Drawing.Point(284, 2)
		Me._imNumber1_1.TabIndex = 3
		Me._imNumber1_1.Name = "_imNumber1_1"
		_imText4_3.OcxState = CType(resources.GetObject("_imText4_3.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imText4_3.Size = New System.Drawing.Size(63, 23)
		Me._imText4_3.Location = New System.Drawing.Point(544, 2)
		Me._imText4_3.TabIndex = 5
		Me._imText4_3.Name = "_imText4_3"
		Me._ctlGeppo1_0.Size = New System.Drawing.Size(615, 33)
		Me._ctlGeppo1_0.Location = New System.Drawing.Point(8, 74)
		Me._ctlGeppo1_0.TabIndex = 6
		Me._ctlGeppo1_0.Name = "_ctlGeppo1_0"
		Me._ctlGeppo1_1.Size = New System.Drawing.Size(615, 33)
		Me._ctlGeppo1_1.Location = New System.Drawing.Point(8, 106)
		Me._ctlGeppo1_1.TabIndex = 7
		Me._ctlGeppo1_1.Name = "_ctlGeppo1_1"
		Me._ctlGeppo1_2.Size = New System.Drawing.Size(615, 33)
		Me._ctlGeppo1_2.Location = New System.Drawing.Point(8, 138)
		Me._ctlGeppo1_2.TabIndex = 8
		Me._ctlGeppo1_2.Name = "_ctlGeppo1_2"
		Me._Label1_6.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_6.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_6.Text = "���v��"
		Me._Label1_6.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_6.ForeColor = System.Drawing.Color.White
		Me._Label1_6.Size = New System.Drawing.Size(65, 23)
		Me._Label1_6.Location = New System.Drawing.Point(554, 14)
		Me._Label1_6.TabIndex = 60
		Me._Label1_6.Enabled = True
		Me._Label1_6.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_6.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_6.UseMnemonic = True
		Me._Label1_6.Visible = True
		Me._Label1_6.AutoSize = False
		Me._Label1_6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_6.Name = "_Label1_6"
		Me._Label1_5.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_5.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_5.Text = "�H�����v"
		Me._Label1_5.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_5.ForeColor = System.Drawing.Color.White
		Me._Label1_5.Size = New System.Drawing.Size(127, 23)
		Me._Label1_5.Location = New System.Drawing.Point(424, 14)
		Me._Label1_5.TabIndex = 59
		Me._Label1_5.Enabled = True
		Me._Label1_5.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_5.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_5.UseMnemonic = True
		Me._Label1_5.Visible = True
		Me._Label1_5.AutoSize = False
		Me._Label1_5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_5.Name = "_Label1_5"
		Me._Label1_4.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_4.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_4.Text = "���s�\�Z�z"
		Me._Label1_4.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_4.ForeColor = System.Drawing.Color.White
		Me._Label1_4.Size = New System.Drawing.Size(127, 23)
		Me._Label1_4.Location = New System.Drawing.Point(294, 14)
		Me._Label1_4.TabIndex = 58
		Me._Label1_4.Enabled = True
		Me._Label1_4.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_4.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_4.UseMnemonic = True
		Me._Label1_4.Visible = True
		Me._Label1_4.AutoSize = False
		Me._Label1_4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_4.Name = "_Label1_4"
		Me._Label1_1.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_1.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_1.Text = "��"
		Me._Label1_1.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_1.ForeColor = System.Drawing.Color.White
		Me._Label1_1.Size = New System.Drawing.Size(27, 23)
		Me._Label1_1.Location = New System.Drawing.Point(12, 14)
		Me._Label1_1.TabIndex = 55
		Me._Label1_1.Enabled = True
		Me._Label1_1.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_1.UseMnemonic = True
		Me._Label1_1.Visible = True
		Me._Label1_1.AutoSize = False
		Me._Label1_1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_1.Name = "_Label1_1"
		Me._Label1_3.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_3.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_3.Text = "�������z"
		Me._Label1_3.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_3.ForeColor = System.Drawing.Color.White
		Me._Label1_3.Size = New System.Drawing.Size(127, 23)
		Me._Label1_3.Location = New System.Drawing.Point(164, 14)
		Me._Label1_3.TabIndex = 54
		Me._Label1_3.Enabled = True
		Me._Label1_3.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_3.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_3.UseMnemonic = True
		Me._Label1_3.Visible = True
		Me._Label1_3.AutoSize = False
		Me._Label1_3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_3.Name = "_Label1_3"
		Me._Label1_2.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_2.Text = " ���l"
		Me._Label1_2.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_2.ForeColor = System.Drawing.Color.White
		Me._Label1_2.Size = New System.Drawing.Size(119, 23)
		Me._Label1_2.Location = New System.Drawing.Point(42, 14)
		Me._Label1_2.TabIndex = 53
		Me._Label1_2.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me._Label1_2.Enabled = True
		Me._Label1_2.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_2.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_2.UseMnemonic = True
		Me._Label1_2.Visible = True
		Me._Label1_2.AutoSize = False
		Me._Label1_2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_2.Name = "_Label1_2"
		Me.Picture1.Dock = System.Windows.Forms.DockStyle.Bottom
		Me.Picture1.BackColor = System.Drawing.Color.FromARGB(128, 128, 128)
		Me.Picture1.Size = New System.Drawing.Size(1016, 51)
		Me.Picture1.Location = New System.Drawing.Point(0, 668)
		Me.Picture1.TabIndex = 46
		Me.Picture1.TabStop = False
		Me.Picture1.CausesValidation = True
		Me.Picture1.Enabled = True
		Me.Picture1.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Picture1.Cursor = System.Windows.Forms.Cursors.Default
		Me.Picture1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Picture1.Visible = True
		Me.Picture1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.Picture1.Name = "Picture1"
		Me._cmdKey_3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me._cmdKey_3.Text = "  F3  �@"
		Me._cmdKey_3.Enabled = False
		Me._cmdKey_3.Font = New System.Drawing.Font("�l�r ����", 11.25!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._cmdKey_3.Size = New System.Drawing.Size(77, 39)
		Me._cmdKey_3.Location = New System.Drawing.Point(166, 4)
		Me._cmdKey_3.TabIndex = 35
		Me._cmdKey_3.BackColor = System.Drawing.SystemColors.Control
		Me._cmdKey_3.CausesValidation = True
		Me._cmdKey_3.ForeColor = System.Drawing.SystemColors.ControlText
		Me._cmdKey_3.Cursor = System.Windows.Forms.Cursors.Default
		Me._cmdKey_3.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._cmdKey_3.TabStop = True
		Me._cmdKey_3.Name = "_cmdKey_3"
		Me._cmdKey_12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me._cmdKey_12.Text = "  F12  �I ��"
		Me._cmdKey_12.Font = New System.Drawing.Font("�l�r ����", 11.25!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._cmdKey_12.Size = New System.Drawing.Size(77, 39)
		Me._cmdKey_12.Location = New System.Drawing.Point(929, 4)
		Me._cmdKey_12.TabIndex = 44
		Me._cmdKey_12.Tag = "�I�����܂��B"
		Me._cmdKey_12.BackColor = System.Drawing.SystemColors.Control
		Me._cmdKey_12.CausesValidation = True
		Me._cmdKey_12.Enabled = True
		Me._cmdKey_12.ForeColor = System.Drawing.SystemColors.ControlText
		Me._cmdKey_12.Cursor = System.Windows.Forms.Cursors.Default
		Me._cmdKey_12.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._cmdKey_12.TabStop = True
		Me._cmdKey_12.Name = "_cmdKey_12"
		Me._cmdKey_4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me._cmdKey_4.Text = "  F4  �@"
		Me._cmdKey_4.Enabled = False
		Me._cmdKey_4.Font = New System.Drawing.Font("�l�r ����", 11.25!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._cmdKey_4.Size = New System.Drawing.Size(77, 39)
		Me._cmdKey_4.Location = New System.Drawing.Point(246, 4)
		Me._cmdKey_4.TabIndex = 36
		Me._cmdKey_4.BackColor = System.Drawing.SystemColors.Control
		Me._cmdKey_4.CausesValidation = True
		Me._cmdKey_4.ForeColor = System.Drawing.SystemColors.ControlText
		Me._cmdKey_4.Cursor = System.Windows.Forms.Cursors.Default
		Me._cmdKey_4.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._cmdKey_4.TabStop = True
		Me._cmdKey_4.Name = "_cmdKey_4"
		Me._cmdKey_10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me._cmdKey_10.Text = "  F10  �@"
		Me._cmdKey_10.Enabled = False
		Me._cmdKey_10.Font = New System.Drawing.Font("�l�r ����", 11.25!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._cmdKey_10.Size = New System.Drawing.Size(77, 39)
		Me._cmdKey_10.Location = New System.Drawing.Point(769, 4)
		Me._cmdKey_10.TabIndex = 42
		Me._cmdKey_10.BackColor = System.Drawing.SystemColors.Control
		Me._cmdKey_10.CausesValidation = True
		Me._cmdKey_10.ForeColor = System.Drawing.SystemColors.ControlText
		Me._cmdKey_10.Cursor = System.Windows.Forms.Cursors.Default
		Me._cmdKey_10.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._cmdKey_10.TabStop = True
		Me._cmdKey_10.Name = "_cmdKey_10"
		Me._cmdKey_6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me._cmdKey_6.Text = "  F6  �@"
		Me._cmdKey_6.Enabled = False
		Me._cmdKey_6.Font = New System.Drawing.Font("�l�r ����", 11.25!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._cmdKey_6.Size = New System.Drawing.Size(77, 39)
		Me._cmdKey_6.Location = New System.Drawing.Point(428, 4)
		Me._cmdKey_6.TabIndex = 38
		Me._cmdKey_6.BackColor = System.Drawing.SystemColors.Control
		Me._cmdKey_6.CausesValidation = True
		Me._cmdKey_6.ForeColor = System.Drawing.SystemColors.ControlText
		Me._cmdKey_6.Cursor = System.Windows.Forms.Cursors.Default
		Me._cmdKey_6.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._cmdKey_6.TabStop = True
		Me._cmdKey_6.Name = "_cmdKey_6"
		Me._cmdKey_7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me._cmdKey_7.Text = "  F7  �@"
		Me._cmdKey_7.Enabled = False
		Me._cmdKey_7.Font = New System.Drawing.Font("�l�r ����", 11.25!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._cmdKey_7.Size = New System.Drawing.Size(77, 39)
		Me._cmdKey_7.Location = New System.Drawing.Point(508, 4)
		Me._cmdKey_7.TabIndex = 39
		Me._cmdKey_7.BackColor = System.Drawing.SystemColors.Control
		Me._cmdKey_7.CausesValidation = True
		Me._cmdKey_7.ForeColor = System.Drawing.SystemColors.ControlText
		Me._cmdKey_7.Cursor = System.Windows.Forms.Cursors.Default
		Me._cmdKey_7.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._cmdKey_7.TabStop = True
		Me._cmdKey_7.Name = "_cmdKey_7"
		Me._cmdKey_8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me._cmdKey_8.Text = "  F8  �@"
		Me._cmdKey_8.Enabled = False
		Me._cmdKey_8.Font = New System.Drawing.Font("�l�r ����", 11.25!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._cmdKey_8.Size = New System.Drawing.Size(77, 39)
		Me._cmdKey_8.Location = New System.Drawing.Point(588, 4)
		Me._cmdKey_8.TabIndex = 40
		Me._cmdKey_8.BackColor = System.Drawing.SystemColors.Control
		Me._cmdKey_8.CausesValidation = True
		Me._cmdKey_8.ForeColor = System.Drawing.SystemColors.ControlText
		Me._cmdKey_8.Cursor = System.Windows.Forms.Cursors.Default
		Me._cmdKey_8.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._cmdKey_8.TabStop = True
		Me._cmdKey_8.Name = "_cmdKey_8"
		Me._cmdKey_9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me._cmdKey_9.Text = "  F9  �@"
		Me._cmdKey_9.Enabled = False
		Me._cmdKey_9.Font = New System.Drawing.Font("�l�r ����", 11.25!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._cmdKey_9.Size = New System.Drawing.Size(77, 39)
		Me._cmdKey_9.Location = New System.Drawing.Point(689, 4)
		Me._cmdKey_9.TabIndex = 41
		Me._cmdKey_9.BackColor = System.Drawing.SystemColors.Control
		Me._cmdKey_9.CausesValidation = True
		Me._cmdKey_9.ForeColor = System.Drawing.SystemColors.ControlText
		Me._cmdKey_9.Cursor = System.Windows.Forms.Cursors.Default
		Me._cmdKey_9.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._cmdKey_9.TabStop = True
		Me._cmdKey_9.Name = "_cmdKey_9"
		Me._cmdKey_1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me._cmdKey_1.Text = "  F1  �o �^"
		Me._cmdKey_1.Font = New System.Drawing.Font("�l�r ����", 11.25!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._cmdKey_1.Size = New System.Drawing.Size(77, 39)
		Me._cmdKey_1.Location = New System.Drawing.Point(6, 4)
		Me._cmdKey_1.TabIndex = 33
		Me._cmdKey_1.Tag = "���̓f�[�^��o�^���܂��B"
		Me._cmdKey_1.BackColor = System.Drawing.SystemColors.Control
		Me._cmdKey_1.CausesValidation = True
		Me._cmdKey_1.Enabled = True
		Me._cmdKey_1.ForeColor = System.Drawing.SystemColors.ControlText
		Me._cmdKey_1.Cursor = System.Windows.Forms.Cursors.Default
		Me._cmdKey_1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._cmdKey_1.TabStop = True
		Me._cmdKey_1.Name = "_cmdKey_1"
		Me._cmdKey_11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me._cmdKey_11.Text = "  F11  �@"
		Me._cmdKey_11.Enabled = False
		Me._cmdKey_11.Font = New System.Drawing.Font("�l�r ����", 11.25!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._cmdKey_11.Size = New System.Drawing.Size(77, 39)
		Me._cmdKey_11.Location = New System.Drawing.Point(849, 4)
		Me._cmdKey_11.TabIndex = 43
		Me._cmdKey_11.BackColor = System.Drawing.SystemColors.Control
		Me._cmdKey_11.CausesValidation = True
		Me._cmdKey_11.ForeColor = System.Drawing.SystemColors.ControlText
		Me._cmdKey_11.Cursor = System.Windows.Forms.Cursors.Default
		Me._cmdKey_11.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._cmdKey_11.TabStop = True
		Me._cmdKey_11.Name = "_cmdKey_11"
		Me._cmdKey_2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me._cmdKey_2.Text = "  F2  �@"
		Me._cmdKey_2.Enabled = False
		Me._cmdKey_2.Font = New System.Drawing.Font("�l�r ����", 11.25!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._cmdKey_2.Size = New System.Drawing.Size(77, 39)
		Me._cmdKey_2.Location = New System.Drawing.Point(86, 4)
		Me._cmdKey_2.TabIndex = 34
		Me._cmdKey_2.BackColor = System.Drawing.SystemColors.Control
		Me._cmdKey_2.CausesValidation = True
		Me._cmdKey_2.ForeColor = System.Drawing.SystemColors.ControlText
		Me._cmdKey_2.Cursor = System.Windows.Forms.Cursors.Default
		Me._cmdKey_2.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._cmdKey_2.TabStop = True
		Me._cmdKey_2.Name = "_cmdKey_2"
		Me._cmdKey_5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me._cmdKey_5.Text = "  F5  �@"
		Me._cmdKey_5.Enabled = False
		Me._cmdKey_5.Font = New System.Drawing.Font("�l�r ����", 11.25!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._cmdKey_5.Size = New System.Drawing.Size(77, 39)
		Me._cmdKey_5.Location = New System.Drawing.Point(348, 4)
		Me._cmdKey_5.TabIndex = 37
		Me._cmdKey_5.BackColor = System.Drawing.SystemColors.Control
		Me._cmdKey_5.CausesValidation = True
		Me._cmdKey_5.ForeColor = System.Drawing.SystemColors.ControlText
		Me._cmdKey_5.Cursor = System.Windows.Forms.Cursors.Default
		Me._cmdKey_5.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._cmdKey_5.TabStop = True
		Me._cmdKey_5.Name = "_cmdKey_5"
		Me.StatusBar1.Dock = System.Windows.Forms.DockStyle.Bottom
		Me.StatusBar1.Size = New System.Drawing.Size(1016, 23)
		Me.StatusBar1.Location = New System.Drawing.Point(0, 719)
		Me.StatusBar1.TabIndex = 45
		Me.StatusBar1.Font = New System.Drawing.Font("�l�r �S�V�b�N", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me.StatusBar1.Name = "StatusBar1"
		Me._StatusBar1_Panel1.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter
		Me._StatusBar1_Panel1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
		Me._StatusBar1_Panel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me._StatusBar1_Panel1.Size = New System.Drawing.Size(117, 23)
		Me._StatusBar1_Panel1.BorderSides = CType(System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom, System.Windows.Forms.ToolStripStatusLabelBorderSides)
		Me._StatusBar1_Panel1.Margin = New System.Windows.Forms.Padding(0)
		Me._StatusBar1_Panel1.AutoSize = False
		Me._StatusBar1_Panel2.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter
		Me._StatusBar1_Panel2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
		Me._StatusBar1_Panel2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._StatusBar1_Panel2.Size = New System.Drawing.Size(902, 23)
		Me._StatusBar1_Panel2.BorderSides = CType(System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom, System.Windows.Forms.ToolStripStatusLabelBorderSides)
		Me._StatusBar1_Panel2.Margin = New System.Windows.Forms.Padding(0)
		Me._StatusBar1_Panel2.AutoSize = False
		_imText2_2.OcxState = CType(resources.GetObject("_imText2_2.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imText2_2.Size = New System.Drawing.Size(433, 23)
		Me._imText2_2.Location = New System.Drawing.Point(578, 4)
		Me._imText2_2.TabIndex = 48
		Me._imText2_2.Name = "_imText2_2"
		_imText2_0.OcxState = CType(resources.GetObject("_imText2_0.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imText2_0.Size = New System.Drawing.Size(83, 23)
		Me._imText2_0.Location = New System.Drawing.Point(442, 4)
		Me._imText2_0.TabIndex = 49
		Me._imText2_0.Name = "_imText2_0"
		_imText2_1.OcxState = CType(resources.GetObject("_imText2_1.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imText2_1.Size = New System.Drawing.Size(45, 23)
		Me._imText2_1.Location = New System.Drawing.Point(529, 4)
		Me._imText2_1.TabIndex = 50
		Me._imText2_1.Name = "_imText2_1"
		vaSpread1.OcxState = CType(resources.GetObject("vaSpread1.OcxState"), System.Windows.Forms.AxHost.State)
		Me.vaSpread1.Size = New System.Drawing.Size(1002, 273)
		Me.vaSpread1.Location = New System.Drawing.Point(6, 372)
		Me.vaSpread1.TabIndex = 31
		Me.vaSpread1.Name = "vaSpread1"
		vaSpread2.OcxState = CType(resources.GetObject("vaSpread2.OcxState"), System.Windows.Forms.AxHost.State)
		Me.vaSpread2.Size = New System.Drawing.Size(1002, 19)
		Me.vaSpread2.Location = New System.Drawing.Point(6, 644)
		Me.vaSpread2.TabIndex = 32
		Me.vaSpread2.Name = "vaSpread2"
		_imText3_0.OcxState = CType(resources.GetObject("_imText3_0.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imText3_0.CausesValidation = False
		Me._imText3_0.Size = New System.Drawing.Size(73, 23)
		Me._imText3_0.Location = New System.Drawing.Point(118, 36)
		Me._imText3_0.TabIndex = 0
		Me._imText3_0.Name = "_imText3_0"
		Me._Frame1_1.Size = New System.Drawing.Size(648, 97)
		Me._Frame1_1.Location = New System.Drawing.Point(6, 270)
		Me._Frame1_1.TabIndex = 61
		Me._Frame1_1.BackColor = System.Drawing.SystemColors.Control
		Me._Frame1_1.Enabled = True
		Me._Frame1_1.ForeColor = System.Drawing.SystemColors.ControlText
		Me._Frame1_1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Frame1_1.Visible = True
		Me._Frame1_1.Padding = New System.Windows.Forms.Padding(0)
		Me._Frame1_1.Name = "_Frame1_1"
		_imText1_0.OcxState = CType(resources.GetObject("_imText1_0.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imText1_0.Size = New System.Drawing.Size(281, 23)
		Me._imText1_0.Location = New System.Drawing.Point(256, 40)
		Me._imText1_0.TabIndex = 18
		Me._imText1_0.Name = "_imText1_0"
		_imDate1_0.OcxState = CType(resources.GetObject("_imDate1_0.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imDate1_0.Size = New System.Drawing.Size(117, 23)
		Me._imDate1_0.Location = New System.Drawing.Point(112, 14)
		Me._imDate1_0.TabIndex = 15
		Me._imDate1_0.Name = "_imDate1_0"
		_imDate1_1.OcxState = CType(resources.GetObject("_imDate1_1.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imDate1_1.Size = New System.Drawing.Size(117, 23)
		Me._imDate1_1.Location = New System.Drawing.Point(112, 40)
		Me._imDate1_1.TabIndex = 16
		Me._imDate1_1.Name = "_imDate1_1"
		_imDate1_2.OcxState = CType(resources.GetObject("_imDate1_2.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imDate1_2.Size = New System.Drawing.Size(117, 23)
		Me._imDate1_2.Location = New System.Drawing.Point(112, 66)
		Me._imDate1_2.TabIndex = 17
		Me._imDate1_2.Name = "_imDate1_2"
		_imText1_1.OcxState = CType(resources.GetObject("_imText1_1.OcxState"), System.Windows.Forms.AxHost.State)
		Me._imText1_1.Size = New System.Drawing.Size(281, 23)
		Me._imText1_1.Location = New System.Drawing.Point(256, 66)
		Me._imText1_1.TabIndex = 19
		Me._imText1_1.Name = "_imText1_1"
		Me._Label1_19.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_19.Text = " ���̑�"
		Me._Label1_19.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_19.ForeColor = System.Drawing.Color.White
		Me._Label1_19.Size = New System.Drawing.Size(282, 23)
		Me._Label1_19.Location = New System.Drawing.Point(256, 14)
		Me._Label1_19.TabIndex = 65
		Me._Label1_19.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me._Label1_19.Enabled = True
		Me._Label1_19.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_19.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_19.UseMnemonic = True
		Me._Label1_19.Visible = True
		Me._Label1_19.AutoSize = False
		Me._Label1_19.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_19.Name = "_Label1_19"
		Me._Label1_17.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_17.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_17.Text = "�v �H"
		Me._Label1_17.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_17.ForeColor = System.Drawing.Color.White
		Me._Label1_17.Size = New System.Drawing.Size(100, 23)
		Me._Label1_17.Location = New System.Drawing.Point(8, 40)
		Me._Label1_17.TabIndex = 64
		Me._Label1_17.Enabled = True
		Me._Label1_17.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_17.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_17.UseMnemonic = True
		Me._Label1_17.Visible = True
		Me._Label1_17.AutoSize = False
		Me._Label1_17.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_17.Name = "_Label1_17"
		Me._Label1_16.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_16.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_16.Text = "�� �H"
		Me._Label1_16.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_16.ForeColor = System.Drawing.Color.White
		Me._Label1_16.Size = New System.Drawing.Size(100, 23)
		Me._Label1_16.Location = New System.Drawing.Point(8, 14)
		Me._Label1_16.TabIndex = 63
		Me._Label1_16.Enabled = True
		Me._Label1_16.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_16.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_16.UseMnemonic = True
		Me._Label1_16.Visible = True
		Me._Label1_16.AutoSize = False
		Me._Label1_16.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_16.Name = "_Label1_16"
		Me._Label1_18.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_18.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_18.Text = "�� ��"
		Me._Label1_18.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_18.ForeColor = System.Drawing.Color.White
		Me._Label1_18.Size = New System.Drawing.Size(100, 23)
		Me._Label1_18.Location = New System.Drawing.Point(8, 66)
		Me._Label1_18.TabIndex = 62
		Me._Label1_18.Enabled = True
		Me._Label1_18.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_18.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_18.UseMnemonic = True
		Me._Label1_18.Visible = True
		Me._Label1_18.AutoSize = False
		Me._Label1_18.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_18.Name = "_Label1_18"
		Me._Label1_0.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_0.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_0.Text = "���N��"
		Me._Label1_0.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_0.ForeColor = System.Drawing.Color.White
		Me._Label1_0.Size = New System.Drawing.Size(100, 23)
		Me._Label1_0.Location = New System.Drawing.Point(14, 36)
		Me._Label1_0.TabIndex = 51
		Me._Label1_0.Enabled = True
		Me._Label1_0.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_0.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_0.UseMnemonic = True
		Me._Label1_0.Visible = True
		Me._Label1_0.AutoSize = False
		Me._Label1_0.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_0.Name = "_Label1_0"
		Me.lblTitle.BackColor = System.Drawing.Color.FromARGB(192, 255, 192)
		Me.lblTitle.Text = " �H������ꗗ�i�y�؁j"
		Me.lblTitle.Font = New System.Drawing.Font("�l�r ����", 20.25!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me.lblTitle.ForeColor = System.Drawing.Color.FromARGB(0, 0, 128)
		Me.lblTitle.Size = New System.Drawing.Size(1015, 31)
		Me.lblTitle.Location = New System.Drawing.Point(0, 0)
		Me.lblTitle.TabIndex = 47
		Me.lblTitle.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.lblTitle.Enabled = True
		Me.lblTitle.Cursor = System.Windows.Forms.Cursors.Default
		Me.lblTitle.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.lblTitle.UseMnemonic = True
		Me.lblTitle.Visible = True
		Me.lblTitle.AutoSize = False
		Me.lblTitle.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.lblTitle.Name = "lblTitle"
		Me.Controls.Add(Check1)
		Me.Controls.Add(Picture3)
		Me.Controls.Add(_Frame1_2)
		Me.Controls.Add(_Frame1_0)
		Me.Controls.Add(Picture1)
		Me.Controls.Add(StatusBar1)
		Me.Controls.Add(_imText2_2)
		Me.Controls.Add(_imText2_0)
		Me.Controls.Add(_imText2_1)
		Me.Controls.Add(vaSpread1)
		Me.Controls.Add(vaSpread2)
		Me.Controls.Add(_imText3_0)
		Me.Controls.Add(_Frame1_1)
		Me.Controls.Add(_Label1_0)
		Me.Controls.Add(lblTitle)
		Me.Picture3.Controls.Add(_Label1_20)
		Me._Frame1_2.Controls.Add(_imText6_0)
		Me._Frame1_2.Controls.Add(_imText7_0)
		Me._Frame1_2.Controls.Add(_imText6_1)
		Me._Frame1_2.Controls.Add(_imText6_2)
		Me._Frame1_2.Controls.Add(_imText6_4)
		Me._Frame1_2.Controls.Add(_imText6_5)
		Me._Frame1_2.Controls.Add(_imText7_1)
		Me._Frame1_2.Controls.Add(_imNumber2_0)
		Me._Frame1_2.Controls.Add(_imNumber2_1)
		Me._Frame1_2.Controls.Add(_imNumber2_2)
		Me._Frame1_2.Controls.Add(_imNumber2_3)
		Me._Frame1_2.Controls.Add(_Label1_15)
		Me._Frame1_2.Controls.Add(_Label1_13)
		Me._Frame1_2.Controls.Add(_Label1_14)
		Me._Frame1_2.Controls.Add(_Label1_12)
		Me._Frame1_2.Controls.Add(_Label1_10)
		Me._Frame1_2.Controls.Add(_Label1_11)
		Me._Frame1_2.Controls.Add(_Label1_9)
		Me._Frame1_2.Controls.Add(_Label1_8)
		Me._Frame1_2.Controls.Add(_Label1_7)
		Me._Frame1_0.Controls.Add(VScroll1)
		Me._Frame1_0.Controls.Add(_Picture2_1)
		Me._Frame1_0.Controls.Add(_Picture2_0)
		Me._Frame1_0.Controls.Add(_ctlGeppo1_0)
		Me._Frame1_0.Controls.Add(_ctlGeppo1_1)
		Me._Frame1_0.Controls.Add(_ctlGeppo1_2)
		Me._Frame1_0.Controls.Add(_Label1_6)
		Me._Frame1_0.Controls.Add(_Label1_5)
		Me._Frame1_0.Controls.Add(_Label1_4)
		Me._Frame1_0.Controls.Add(_Label1_1)
		Me._Frame1_0.Controls.Add(_Label1_3)
		Me._Frame1_0.Controls.Add(_Label1_2)
		Me._Picture2_1.Controls.Add(_imText3_2)
		Me._Picture2_1.Controls.Add(_imText5_2)
		Me._Picture2_1.Controls.Add(_imText5_3)
		Me._Picture2_1.Controls.Add(_imText5_0)
		Me._Picture2_1.Controls.Add(_imText5_1)
		Me._Picture2_0.Controls.Add(_imText3_1)
		Me._Picture2_0.Controls.Add(_imText4_2)
		Me._Picture2_0.Controls.Add(_imNumber1_0)
		Me._Picture2_0.Controls.Add(_imNumber1_1)
		Me._Picture2_0.Controls.Add(_imText4_3)
		Me.Picture1.Controls.Add(_cmdKey_3)
		Me.Picture1.Controls.Add(_cmdKey_12)
		Me.Picture1.Controls.Add(_cmdKey_4)
		Me.Picture1.Controls.Add(_cmdKey_10)
		Me.Picture1.Controls.Add(_cmdKey_6)
		Me.Picture1.Controls.Add(_cmdKey_7)
		Me.Picture1.Controls.Add(_cmdKey_8)
		Me.Picture1.Controls.Add(_cmdKey_9)
		Me.Picture1.Controls.Add(_cmdKey_1)
		Me.Picture1.Controls.Add(_cmdKey_11)
		Me.Picture1.Controls.Add(_cmdKey_2)
		Me.Picture1.Controls.Add(_cmdKey_5)
		Me.StatusBar1.Items.AddRange(New System.Windows.Forms.ToolStripItem(){Me._StatusBar1_Panel1})
		Me.StatusBar1.Items.AddRange(New System.Windows.Forms.ToolStripItem(){Me._StatusBar1_Panel2})
		Me._Frame1_1.Controls.Add(_imText1_0)
		Me._Frame1_1.Controls.Add(_imDate1_0)
		Me._Frame1_1.Controls.Add(_imDate1_1)
		Me._Frame1_1.Controls.Add(_imDate1_2)
		Me._Frame1_1.Controls.Add(_imText1_1)
		Me._Frame1_1.Controls.Add(_Label1_19)
		Me._Frame1_1.Controls.Add(_Label1_17)
		Me._Frame1_1.Controls.Add(_Label1_16)
		Me._Frame1_1.Controls.Add(_Label1_18)
		Me.Frame1.SetIndex(_Frame1_2, CType(2, Short))
		Me.Frame1.SetIndex(_Frame1_0, CType(0, Short))
		Me.Frame1.SetIndex(_Frame1_1, CType(1, Short))
		Me.Label1.SetIndex(_Label1_20, CType(20, Short))
		Me.Label1.SetIndex(_Label1_15, CType(15, Short))
		Me.Label1.SetIndex(_Label1_13, CType(13, Short))
		Me.Label1.SetIndex(_Label1_14, CType(14, Short))
		Me.Label1.SetIndex(_Label1_12, CType(12, Short))
		Me.Label1.SetIndex(_Label1_10, CType(10, Short))
		Me.Label1.SetIndex(_Label1_11, CType(11, Short))
		Me.Label1.SetIndex(_Label1_9, CType(9, Short))
		Me.Label1.SetIndex(_Label1_8, CType(8, Short))
		Me.Label1.SetIndex(_Label1_7, CType(7, Short))
		Me.Label1.SetIndex(_Label1_6, CType(6, Short))
		Me.Label1.SetIndex(_Label1_5, CType(5, Short))
		Me.Label1.SetIndex(_Label1_4, CType(4, Short))
		Me.Label1.SetIndex(_Label1_1, CType(1, Short))
		Me.Label1.SetIndex(_Label1_3, CType(3, Short))
		Me.Label1.SetIndex(_Label1_2, CType(2, Short))
		Me.Label1.SetIndex(_Label1_19, CType(19, Short))
		Me.Label1.SetIndex(_Label1_17, CType(17, Short))
		Me.Label1.SetIndex(_Label1_16, CType(16, Short))
		Me.Label1.SetIndex(_Label1_18, CType(18, Short))
		Me.Label1.SetIndex(_Label1_0, CType(0, Short))
		Me.Picture2.SetIndex(_Picture2_1, CType(1, Short))
		Me.Picture2.SetIndex(_Picture2_0, CType(0, Short))
		Me.cmdKey.SetIndex(_cmdKey_3, CType(3, Short))
		Me.cmdKey.SetIndex(_cmdKey_12, CType(12, Short))
		Me.cmdKey.SetIndex(_cmdKey_4, CType(4, Short))
		Me.cmdKey.SetIndex(_cmdKey_10, CType(10, Short))
		Me.cmdKey.SetIndex(_cmdKey_6, CType(6, Short))
		Me.cmdKey.SetIndex(_cmdKey_7, CType(7, Short))
		Me.cmdKey.SetIndex(_cmdKey_8, CType(8, Short))
		Me.cmdKey.SetIndex(_cmdKey_9, CType(9, Short))
		Me.cmdKey.SetIndex(_cmdKey_1, CType(1, Short))
		Me.cmdKey.SetIndex(_cmdKey_11, CType(11, Short))
		Me.cmdKey.SetIndex(_cmdKey_2, CType(2, Short))
		Me.cmdKey.SetIndex(_cmdKey_5, CType(5, Short))
		Me.ctlGeppo1.SetIndex(_ctlGeppo1_0, CType(0, Short))
		Me.ctlGeppo1.SetIndex(_ctlGeppo1_1, CType(1, Short))
		Me.ctlGeppo1.SetIndex(_ctlGeppo1_2, CType(2, Short))
		Me.imDate1.SetIndex(_imDate1_0, CType(0, Short))
		Me.imDate1.SetIndex(_imDate1_1, CType(1, Short))
		Me.imDate1.SetIndex(_imDate1_2, CType(2, Short))
		Me.imNumber1.SetIndex(_imNumber1_0, CType(0, Short))
		Me.imNumber1.SetIndex(_imNumber1_1, CType(1, Short))
		Me.imNumber2.SetIndex(_imNumber2_0, CType(0, Short))
		Me.imNumber2.SetIndex(_imNumber2_1, CType(1, Short))
		Me.imNumber2.SetIndex(_imNumber2_2, CType(2, Short))
		Me.imNumber2.SetIndex(_imNumber2_3, CType(3, Short))
		Me.imText1.SetIndex(_imText1_0, CType(0, Short))
		Me.imText1.SetIndex(_imText1_1, CType(1, Short))
		Me.imText2.SetIndex(_imText2_2, CType(2, Short))
		Me.imText2.SetIndex(_imText2_0, CType(0, Short))
		Me.imText2.SetIndex(_imText2_1, CType(1, Short))
		Me.imText3.SetIndex(_imText3_2, CType(2, Short))
		Me.imText3.SetIndex(_imText3_1, CType(1, Short))
		Me.imText3.SetIndex(_imText3_0, CType(0, Short))
		Me.imText4.SetIndex(_imText4_2, CType(2, Short))
		Me.imText4.SetIndex(_imText4_3, CType(3, Short))
		Me.imText5.SetIndex(_imText5_2, CType(2, Short))
		Me.imText5.SetIndex(_imText5_3, CType(3, Short))
		Me.imText5.SetIndex(_imText5_0, CType(0, Short))
		Me.imText5.SetIndex(_imText5_1, CType(1, Short))
		Me.imText6.SetIndex(_imText6_0, CType(0, Short))
		Me.imText6.SetIndex(_imText6_1, CType(1, Short))
		Me.imText6.SetIndex(_imText6_2, CType(2, Short))
		Me.imText6.SetIndex(_imText6_4, CType(4, Short))
		Me.imText6.SetIndex(_imText6_5, CType(5, Short))
		Me.imText7.SetIndex(_imText7_0, CType(0, Short))
		Me.imText7.SetIndex(_imText7_1, CType(1, Short))
		CType(Me.imText7, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.imText6, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.imText5, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.imText4, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.imText3, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.imText2, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.imText1, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.imNumber2, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.imNumber1, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.imDate1, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.ctlGeppo1, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.cmdKey, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.Picture2, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.Label1, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.Frame1, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imText1_1, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imDate1_2, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imDate1_1, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imDate1_0, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imText1_0, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imText3_0, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.vaSpread2, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.vaSpread1, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imText2_1, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imText2_0, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imText2_2, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imText4_3, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imNumber1_1, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imNumber1_0, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imText4_2, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imText3_1, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imText5_1, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imText5_0, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imText5_3, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imText5_2, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imText3_2, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imNumber2_3, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imNumber2_2, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imNumber2_1, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imNumber2_0, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imText7_1, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imText6_5, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imText6_4, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imText6_2, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imText6_1, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imText7_0, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me._imText6_0, System.ComponentModel.ISupportInitialize).EndInit()
		Me.Picture3.ResumeLayout(False)
		Me._Frame1_2.ResumeLayout(False)
		Me._Frame1_0.ResumeLayout(False)
		Me._Picture2_1.ResumeLayout(False)
		Me._Picture2_0.ResumeLayout(False)
		Me.Picture1.ResumeLayout(False)
		Me.StatusBar1.ResumeLayout(False)
		Me._Frame1_1.ResumeLayout(False)
		Me.ResumeLayout(False)
		Me.PerformLayout()
	End Sub
#End Region 
End Class