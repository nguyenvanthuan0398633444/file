<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frmSYKD011
#Region "Windows Form Designer generated code "
	<System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
		MyBase.New()
		'This call is required by the Windows Form Designer.
		InitializeComponent()
	End Sub
	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer
	Public ToolTip1 As System.Windows.Forms.ToolTip
	Public WithEvents _Command1_0 As System.Windows.Forms.Button
	Public WithEvents _Command1_1 As System.Windows.Forms.Button
	Public WithEvents _Command1_2 As System.Windows.Forms.Button
	Public WithEvents _Command1_3 As System.Windows.Forms.Button
	Public WithEvents _Command1_4 As System.Windows.Forms.Button
	Public WithEvents Picture2 As System.Windows.Forms.Panel
	Public WithEvents imDate1 As imDate6.imDate
	Public WithEvents _Label1_0 As System.Windows.Forms.Label
	Public WithEvents _Frame1_0 As System.Windows.Forms.GroupBox
	Public WithEvents _cmdKey_3 As System.Windows.Forms.Button
	Public WithEvents _cmdKey_8 As System.Windows.Forms.Button
	Public WithEvents _cmdKey_1 As System.Windows.Forms.Button
	Public WithEvents _cmdKey_12 As System.Windows.Forms.Button
	Public WithEvents Picture1 As System.Windows.Forms.Panel
	Public WithEvents _StatusBar1_Panel1 As System.Windows.Forms.ToolStripStatusLabel
	Public WithEvents _StatusBar1_Panel2 As System.Windows.Forms.ToolStripStatusLabel
	Public WithEvents StatusBar1 As System.Windows.Forms.StatusStrip
	Public WithEvents vaSpread1 As AxFPSpread.AxvaSpread
	Public WithEvents lblTitle As System.Windows.Forms.Label
	Public WithEvents Command1 As Microsoft.VisualBasic.Compatibility.VB6.ButtonArray
	Public WithEvents Frame1 As Microsoft.VisualBasic.Compatibility.VB6.GroupBoxArray
	Public WithEvents Label1 As Microsoft.VisualBasic.Compatibility.VB6.LabelArray
	Public WithEvents cmdKey As Microsoft.VisualBasic.Compatibility.VB6.ButtonArray
	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmSYKD011))
		Me.components = New System.ComponentModel.Container()
		Me.ToolTip1 = New System.Windows.Forms.ToolTip(components)
		Me.Picture2 = New System.Windows.Forms.Panel
		Me._Command1_0 = New System.Windows.Forms.Button
		Me._Command1_1 = New System.Windows.Forms.Button
		Me._Command1_2 = New System.Windows.Forms.Button
		Me._Command1_3 = New System.Windows.Forms.Button
		Me._Command1_4 = New System.Windows.Forms.Button
		Me._Frame1_0 = New System.Windows.Forms.GroupBox
		Me.imDate1 = New imDate6.imDate
		Me._Label1_0 = New System.Windows.Forms.Label
		Me.Picture1 = New System.Windows.Forms.Panel
		Me._cmdKey_3 = New System.Windows.Forms.Button
		Me._cmdKey_8 = New System.Windows.Forms.Button
		Me._cmdKey_1 = New System.Windows.Forms.Button
		Me._cmdKey_12 = New System.Windows.Forms.Button
		Me.StatusBar1 = New System.Windows.Forms.StatusStrip
		Me._StatusBar1_Panel1 = New System.Windows.Forms.ToolStripStatusLabel
		Me._StatusBar1_Panel2 = New System.Windows.Forms.ToolStripStatusLabel
		Me.vaSpread1 = New AxFPSpread.AxvaSpread
		Me.lblTitle = New System.Windows.Forms.Label
		Me.Command1 = New Microsoft.VisualBasic.Compatibility.VB6.ButtonArray(components)
		Me.Frame1 = New Microsoft.VisualBasic.Compatibility.VB6.GroupBoxArray(components)
		Me.Label1 = New Microsoft.VisualBasic.Compatibility.VB6.LabelArray(components)
		Me.cmdKey = New Microsoft.VisualBasic.Compatibility.VB6.ButtonArray(components)
		Me.Picture2.SuspendLayout()
		Me._Frame1_0.SuspendLayout()
		Me.Picture1.SuspendLayout()
		Me.StatusBar1.SuspendLayout()
		Me.SuspendLayout()
		Me.ToolTip1.Active = True
		CType(Me.imDate1, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.vaSpread1, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.Command1, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.Frame1, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.Label1, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.cmdKey, System.ComponentModel.ISupportInitialize).BeginInit()
		Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
		Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
		Me.Text = "�H���Ǘ��V�X�e��"
		Me.ClientSize = New System.Drawing.Size(790, 424)
		Me.Location = New System.Drawing.Point(114, 188)
		Me.Icon = CType(resources.GetObject("frmSYKD011.Icon"), System.Drawing.Icon)
		Me.KeyPreview = True
		Me.MaximizeBox = False
		Me.MinimizeBox = False
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.BackColor = System.Drawing.SystemColors.Control
		Me.ControlBox = True
		Me.Enabled = True
		Me.Cursor = System.Windows.Forms.Cursors.Default
		Me.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.ShowInTaskbar = True
		Me.HelpButton = False
		Me.WindowState = System.Windows.Forms.FormWindowState.Normal
		Me.Name = "frmSYKD011"
		Me.Picture2.BackColor = System.Drawing.SystemColors.Window
		Me.Picture2.Enabled = False
		Me.Picture2.ForeColor = System.Drawing.SystemColors.WindowText
		Me.Picture2.Size = New System.Drawing.Size(715, 28)
		Me.Picture2.Location = New System.Drawing.Point(53, 40)
		Me.Picture2.TabIndex = 11
		Me.Picture2.Dock = System.Windows.Forms.DockStyle.None
		Me.Picture2.CausesValidation = True
		Me.Picture2.Cursor = System.Windows.Forms.Cursors.Default
		Me.Picture2.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Picture2.TabStop = True
		Me.Picture2.Visible = True
		Me.Picture2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
		Me.Picture2.Name = "Picture2"
		Me._Command1_0.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me._Command1_0.BackColor = System.Drawing.SystemColors.Control
		Me._Command1_0.Text = "�H���ԍ�"
		Me._Command1_0.Font = New System.Drawing.Font("�l�r �o����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Command1_0.Size = New System.Drawing.Size(83, 26)
		Me._Command1_0.Location = New System.Drawing.Point(0, 0)
		Me._Command1_0.TabIndex = 16
		Me._Command1_0.CausesValidation = True
		Me._Command1_0.Enabled = True
		Me._Command1_0.ForeColor = System.Drawing.SystemColors.ControlText
		Me._Command1_0.Cursor = System.Windows.Forms.Cursors.Default
		Me._Command1_0.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Command1_0.TabStop = True
		Me._Command1_0.Name = "_Command1_0"
		Me._Command1_1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me._Command1_1.BackColor = System.Drawing.SystemColors.Control
		Me._Command1_1.Text = "�H �� �� ��"
		Me._Command1_1.Font = New System.Drawing.Font("�l�r �o����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Command1_1.Size = New System.Drawing.Size(142, 26)
		Me._Command1_1.Location = New System.Drawing.Point(572, 0)
		Me._Command1_1.TabIndex = 15
		Me._Command1_1.CausesValidation = True
		Me._Command1_1.Enabled = True
		Me._Command1_1.ForeColor = System.Drawing.SystemColors.ControlText
		Me._Command1_1.Cursor = System.Windows.Forms.Cursors.Default
		Me._Command1_1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Command1_1.TabStop = True
		Me._Command1_1.Name = "_Command1_1"
		Me._Command1_2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me._Command1_2.BackColor = System.Drawing.SystemColors.Control
		Me._Command1_2.Text = "�H�@���@���i���́j"
		Me._Command1_2.Font = New System.Drawing.Font("�l�r �o����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Command1_2.Size = New System.Drawing.Size(369, 26)
		Me._Command1_2.Location = New System.Drawing.Point(132, 0)
		Me._Command1_2.TabIndex = 14
		Me._Command1_2.CausesValidation = True
		Me._Command1_2.Enabled = True
		Me._Command1_2.ForeColor = System.Drawing.SystemColors.ControlText
		Me._Command1_2.Cursor = System.Windows.Forms.Cursors.Default
		Me._Command1_2.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Command1_2.TabStop = True
		Me._Command1_2.Name = "_Command1_2"
		Me._Command1_3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me._Command1_3.BackColor = System.Drawing.SystemColors.Control
		Me._Command1_3.Font = New System.Drawing.Font("�l�r �o����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Command1_3.Size = New System.Drawing.Size(49, 26)
		Me._Command1_3.Location = New System.Drawing.Point(83, 0)
		Me._Command1_3.TabIndex = 13
		Me._Command1_3.CausesValidation = True
		Me._Command1_3.Enabled = True
		Me._Command1_3.ForeColor = System.Drawing.SystemColors.ControlText
		Me._Command1_3.Cursor = System.Windows.Forms.Cursors.Default
		Me._Command1_3.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Command1_3.TabStop = True
		Me._Command1_3.Name = "_Command1_3"
		Me._Command1_4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me._Command1_4.BackColor = System.Drawing.SystemColors.Control
		Me._Command1_4.Text = "����"
		Me._Command1_4.Font = New System.Drawing.Font("�l�r �o����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Command1_4.Size = New System.Drawing.Size(71, 26)
		Me._Command1_4.Location = New System.Drawing.Point(501, 0)
		Me._Command1_4.TabIndex = 12
		Me._Command1_4.CausesValidation = True
		Me._Command1_4.Enabled = True
		Me._Command1_4.ForeColor = System.Drawing.SystemColors.ControlText
		Me._Command1_4.Cursor = System.Windows.Forms.Cursors.Default
		Me._Command1_4.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Command1_4.TabStop = True
		Me._Command1_4.Name = "_Command1_4"
		Me._Frame1_0.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Frame1_0.Size = New System.Drawing.Size(776, 59)
		Me._Frame1_0.Location = New System.Drawing.Point(8, 282)
		Me._Frame1_0.TabIndex = 9
		Me._Frame1_0.BackColor = System.Drawing.SystemColors.Control
		Me._Frame1_0.Enabled = True
		Me._Frame1_0.ForeColor = System.Drawing.SystemColors.ControlText
		Me._Frame1_0.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Frame1_0.Visible = True
		Me._Frame1_0.Padding = New System.Windows.Forms.Padding(0)
		Me._Frame1_0.Name = "_Frame1_0"
		imDate1.OcxState = CType(resources.GetObject("imDate1.OcxState"), System.Windows.Forms.AxHost.State)
		Me.imDate1.CausesValidation = False
		Me.imDate1.Size = New System.Drawing.Size(89, 23)
		Me.imDate1.Location = New System.Drawing.Point(134, 22)
		Me.imDate1.TabIndex = 1
		Me.imDate1.Name = "imDate1"
		Me._Label1_0.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me._Label1_0.BackColor = System.Drawing.Color.FromARGB(0, 128, 128)
		Me._Label1_0.Text = "�����N��"
		Me._Label1_0.Font = New System.Drawing.Font("�l�r ����", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._Label1_0.ForeColor = System.Drawing.Color.White
		Me._Label1_0.Size = New System.Drawing.Size(114, 23)
		Me._Label1_0.Location = New System.Drawing.Point(14, 22)
		Me._Label1_0.TabIndex = 10
		Me._Label1_0.Enabled = True
		Me._Label1_0.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_0.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_0.UseMnemonic = True
		Me._Label1_0.Visible = True
		Me._Label1_0.AutoSize = False
		Me._Label1_0.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._Label1_0.Name = "_Label1_0"
		Me.Picture1.Dock = System.Windows.Forms.DockStyle.Bottom
		Me.Picture1.BackColor = System.Drawing.Color.FromARGB(128, 128, 128)
		Me.Picture1.Size = New System.Drawing.Size(790, 51)
		Me.Picture1.Location = New System.Drawing.Point(0, 350)
		Me.Picture1.TabIndex = 7
		Me.Picture1.TabStop = False
		Me.Picture1.CausesValidation = True
		Me.Picture1.Enabled = True
		Me.Picture1.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Picture1.Cursor = System.Windows.Forms.Cursors.Default
		Me.Picture1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Picture1.Visible = True
		Me.Picture1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.Picture1.Name = "Picture1"
		Me._cmdKey_3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me._cmdKey_3.Text = "  F3  �� ��"
		Me._cmdKey_3.Font = New System.Drawing.Font("�l�r ����", 11.25!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._cmdKey_3.Size = New System.Drawing.Size(77, 39)
		Me._cmdKey_3.Location = New System.Drawing.Point(156, 4)
		Me._cmdKey_3.TabIndex = 3
		Me._cmdKey_3.Tag = "�H�������폜���܂��B"
		Me._cmdKey_3.BackColor = System.Drawing.SystemColors.Control
		Me._cmdKey_3.CausesValidation = True
		Me._cmdKey_3.Enabled = True
		Me._cmdKey_3.ForeColor = System.Drawing.SystemColors.ControlText
		Me._cmdKey_3.Cursor = System.Windows.Forms.Cursors.Default
		Me._cmdKey_3.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._cmdKey_3.TabStop = True
		Me._cmdKey_3.Name = "_cmdKey_3"
		Me._cmdKey_8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me._cmdKey_8.Text = "  F8  ��M�ꗗ"
		Me._cmdKey_8.Font = New System.Drawing.Font("�l�r ����", 11.25!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._cmdKey_8.Size = New System.Drawing.Size(77, 39)
		Me._cmdKey_8.Location = New System.Drawing.Point(474, 4)
		Me._cmdKey_8.TabIndex = 4
		Me._cmdKey_8.Tag = "��M�ꗗ��ʂɈڍs���܂��B"
		Me._cmdKey_8.BackColor = System.Drawing.SystemColors.Control
		Me._cmdKey_8.CausesValidation = True
		Me._cmdKey_8.Enabled = True
		Me._cmdKey_8.ForeColor = System.Drawing.SystemColors.ControlText
		Me._cmdKey_8.Cursor = System.Windows.Forms.Cursors.Default
		Me._cmdKey_8.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._cmdKey_8.TabStop = True
		Me._cmdKey_8.Name = "_cmdKey_8"
		Me._cmdKey_1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me._cmdKey_1.Text = "  F1  �� ��"
		Me._cmdKey_1.Font = New System.Drawing.Font("�l�r ����", 11.25!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._cmdKey_1.Size = New System.Drawing.Size(77, 39)
		Me._cmdKey_1.Location = New System.Drawing.Point(4, 4)
		Me._cmdKey_1.TabIndex = 2
		Me._cmdKey_1.Tag = "�H�������肵�܂��B"
		Me._cmdKey_1.BackColor = System.Drawing.SystemColors.Control
		Me._cmdKey_1.CausesValidation = True
		Me._cmdKey_1.Enabled = True
		Me._cmdKey_1.ForeColor = System.Drawing.SystemColors.ControlText
		Me._cmdKey_1.Cursor = System.Windows.Forms.Cursors.Default
		Me._cmdKey_1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._cmdKey_1.TabStop = True
		Me._cmdKey_1.Name = "_cmdKey_1"
		Me._cmdKey_12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me._cmdKey_12.Text = "  F12  �I ��"
		Me._cmdKey_12.Font = New System.Drawing.Font("�l�r ����", 11.25!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._cmdKey_12.Size = New System.Drawing.Size(77, 39)
		Me._cmdKey_12.Location = New System.Drawing.Point(704, 4)
		Me._cmdKey_12.TabIndex = 5
		Me._cmdKey_12.Tag = "�I�����܂��B"
		Me._cmdKey_12.BackColor = System.Drawing.SystemColors.Control
		Me._cmdKey_12.CausesValidation = True
		Me._cmdKey_12.Enabled = True
		Me._cmdKey_12.ForeColor = System.Drawing.SystemColors.ControlText
		Me._cmdKey_12.Cursor = System.Windows.Forms.Cursors.Default
		Me._cmdKey_12.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._cmdKey_12.TabStop = True
		Me._cmdKey_12.Name = "_cmdKey_12"
		Me.StatusBar1.Dock = System.Windows.Forms.DockStyle.Bottom
		Me.StatusBar1.Size = New System.Drawing.Size(790, 23)
		Me.StatusBar1.Location = New System.Drawing.Point(0, 401)
		Me.StatusBar1.TabIndex = 6
		Me.StatusBar1.Font = New System.Drawing.Font("�l�r �S�V�b�N", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me.StatusBar1.Name = "StatusBar1"
		Me._StatusBar1_Panel1.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter
		Me._StatusBar1_Panel1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
		Me._StatusBar1_Panel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me._StatusBar1_Panel1.Size = New System.Drawing.Size(117, 23)
		Me._StatusBar1_Panel1.BorderSides = CType(System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom, System.Windows.Forms.ToolStripStatusLabelBorderSides)
		Me._StatusBar1_Panel1.Margin = New System.Windows.Forms.Padding(0)
		Me._StatusBar1_Panel1.AutoSize = False
		Me._StatusBar1_Panel2.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter
		Me._StatusBar1_Panel2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
		Me._StatusBar1_Panel2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._StatusBar1_Panel2.Size = New System.Drawing.Size(902, 23)
		Me._StatusBar1_Panel2.BorderSides = CType(System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom, System.Windows.Forms.ToolStripStatusLabelBorderSides)
		Me._StatusBar1_Panel2.Margin = New System.Windows.Forms.Padding(0)
		Me._StatusBar1_Panel2.AutoSize = False
		vaSpread1.OcxState = CType(resources.GetObject("vaSpread1.OcxState"), System.Windows.Forms.AxHost.State)
		Me.vaSpread1.Size = New System.Drawing.Size(776, 237)
		Me.vaSpread1.Location = New System.Drawing.Point(8, 40)
		Me.vaSpread1.TabIndex = 0
		Me.vaSpread1.Name = "vaSpread1"
		Me.lblTitle.BackColor = System.Drawing.Color.FromARGB(192, 255, 255)
		Me.lblTitle.Text = " �H���I��"
		Me.lblTitle.Font = New System.Drawing.Font("�l�r ����", 20.25!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me.lblTitle.ForeColor = System.Drawing.Color.FromARGB(0, 0, 128)
		Me.lblTitle.Size = New System.Drawing.Size(789, 31)
		Me.lblTitle.Location = New System.Drawing.Point(0, 0)
		Me.lblTitle.TabIndex = 8
		Me.lblTitle.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.lblTitle.Enabled = True
		Me.lblTitle.Cursor = System.Windows.Forms.Cursors.Default
		Me.lblTitle.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.lblTitle.UseMnemonic = True
		Me.lblTitle.Visible = True
		Me.lblTitle.AutoSize = False
		Me.lblTitle.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.lblTitle.Name = "lblTitle"
		Me.Controls.Add(Picture2)
		Me.Controls.Add(_Frame1_0)
		Me.Controls.Add(Picture1)
		Me.Controls.Add(StatusBar1)
		Me.Controls.Add(vaSpread1)
		Me.Controls.Add(lblTitle)
		Me.Picture2.Controls.Add(_Command1_0)
		Me.Picture2.Controls.Add(_Command1_1)
		Me.Picture2.Controls.Add(_Command1_2)
		Me.Picture2.Controls.Add(_Command1_3)
		Me.Picture2.Controls.Add(_Command1_4)
		Me._Frame1_0.Controls.Add(imDate1)
		Me._Frame1_0.Controls.Add(_Label1_0)
		Me.Picture1.Controls.Add(_cmdKey_3)
		Me.Picture1.Controls.Add(_cmdKey_8)
		Me.Picture1.Controls.Add(_cmdKey_1)
		Me.Picture1.Controls.Add(_cmdKey_12)
		Me.StatusBar1.Items.AddRange(New System.Windows.Forms.ToolStripItem(){Me._StatusBar1_Panel1})
		Me.StatusBar1.Items.AddRange(New System.Windows.Forms.ToolStripItem(){Me._StatusBar1_Panel2})
		Me.Command1.SetIndex(_Command1_0, CType(0, Short))
		Me.Command1.SetIndex(_Command1_1, CType(1, Short))
		Me.Command1.SetIndex(_Command1_2, CType(2, Short))
		Me.Command1.SetIndex(_Command1_3, CType(3, Short))
		Me.Command1.SetIndex(_Command1_4, CType(4, Short))
		Me.Frame1.SetIndex(_Frame1_0, CType(0, Short))
		Me.Label1.SetIndex(_Label1_0, CType(0, Short))
		Me.cmdKey.SetIndex(_cmdKey_3, CType(3, Short))
		Me.cmdKey.SetIndex(_cmdKey_8, CType(8, Short))
		Me.cmdKey.SetIndex(_cmdKey_1, CType(1, Short))
		Me.cmdKey.SetIndex(_cmdKey_12, CType(12, Short))
		CType(Me.cmdKey, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.Label1, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.Frame1, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.Command1, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.vaSpread1, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.imDate1, System.ComponentModel.ISupportInitialize).EndInit()
		Me.Picture2.ResumeLayout(False)
		Me._Frame1_0.ResumeLayout(False)
		Me.Picture1.ResumeLayout(False)
		Me.StatusBar1.ResumeLayout(False)
		Me.ResumeLayout(False)
		Me.PerformLayout()
	End Sub
#End Region 
End Class