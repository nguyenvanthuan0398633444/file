Option Strict Off
Option Explicit On
Friend Class ctlMeisai
	Inherits System.Windows.Forms.UserControl
	
	Private EventsObj As New clsEvents
	Private MsgBarObj As Object
	Private FocusID As Short
	Private InputID As String
	Private PreVal As Decimal
	'
	
	'-------------------------------------------------------------------------------
	'   ����    :   �f�[�^�̃N���A
	'   �֐�    :   Sub DispClear()
	'   ����    :   �Ȃ�
	'   �@�\    :   �f�[�^���N���A���܂��B
	'-------------------------------------------------------------------------------
	Public Sub DispClear()
		
		imText2(3).Text = "" '�s�ԍ�
		imText2(3).BackColor = System.Drawing.SystemColors.Control
		Combo1.SelectedIndex = 0 '�敪
		imText1(1).Text = "" '���o�ԍ�
		imMask1(0).Value = "" '�H������
		imText2(0).Text = ""
		imText1(2).Text = "" '���הԍ�
		imText2(2).Text = ""
		imText1(3).Text = "" '�i����K�i
		imNumber1(0).Value = "" '�x���䗦�i�U���j
		imNumber1(1).Value = "" '�x���䗦�i�����j
		imNumber1(2).Value = "" '�x���䗦�i��`�j
		Check1.CheckState = System.Windows.Forms.CheckState.Unchecked '���E
		imNumber2(0).Value = "" '�P��
		imNumber2(1).Value = "" '����
		imText2(4).Text = "" '���z
		
		Call CtlReadOnly(False) '����
		
	End Sub
	
	'-------------------------------------------------------------------------------
	'   ����    :   �R���g���[���̐���
	'   �֐�    :   Sub CtlReadOnly()
	'   ����    :   SetVal  �����è�l
	'   �@�\    :   �R���g���[����ǎ���p�ɂ��邩�ǂ������䂵�܂��B
	'-------------------------------------------------------------------------------
	Private Sub CtlReadOnly(ByVal SetVal As Boolean)
		
		imText1(3).ReadOnly = SetVal '�i����K�i
		imNumber1(0).ReadOnly = SetVal '�x���䗦�i�U���j
		imNumber1(1).ReadOnly = SetVal '�x���䗦�i�����j
		imNumber1(2).ReadOnly = SetVal '�x���䗦�i��`�j
		imNumber2(0).ReadOnly = SetVal '�P��
		imNumber2(1).ReadOnly = SetVal '����
		Picture2.Enabled = Not SetVal '���E
		
	End Sub
	
	'-------------------------------------------------------------------------------
	'   ����    :   �w�i�F�̐ݒ�
	'   �֐�    :   Sub SetBackColor()
	'   ����    :   �Ȃ�
	'   �@�\    :   �w�i�F�̐ݒ���N���A���܂��B
	'-------------------------------------------------------------------------------
	Public Sub SetBackColor()
		
		Dim lp As Short
		
		Select Case FocusID
			Case 1 '----- �敪
				If Combo1.Enabled = False Then FocusID = 0 : Exit Sub
				'UPGRADE_ISSUE: ComboBox property Combo1.Locked was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="CC4C7EC0-C903-48FC-ACCC-81861D12DA4A"'
				If Combo1.Locked = True Then Combo1.BackColor = System.Drawing.ColorTranslator.FromOle(IN_READCOL) Else Combo1.BackColor = MtyTool.IN_BACKCOL
			Case 2, 4 '----- �����ԍ���i���K�i
				lp = FocusID - 1
				If imText1(lp).Enabled = False Then FocusID = 0 : Exit Sub
				If imText1(lp).ReadOnly = True Then imText1(lp).BackColor = System.Drawing.ColorTranslator.FromOle(IN_READCOL) Else imText1(lp).BackColor = MtyTool.IN_BACKCOL
			Case 5 '----- �H������
				If imMask1(0).Enabled = False Then FocusID = 0 : Exit Sub
				If imMask1(0).ReadOnly = True Then imMask1(0).BackColor = System.Drawing.ColorTranslator.FromOle(IN_READCOL) Else imMask1(0).BackColor = MtyTool.IN_BACKCOL
			Case 6 To 8 '----- �x���䗦
				lp = FocusID - 6
				If imNumber1(lp).Enabled = False Then FocusID = 0 : Exit Sub
				If imNumber1(lp).ReadOnly = True Then imNumber1(lp).BackColor = System.Drawing.ColorTranslator.FromOle(IN_READCOL) Else imNumber1(lp).BackColor = MtyTool.IN_BACKCOL
			Case 9, 10 '----- �P�������
				lp = FocusID - 9
				If imNumber2(lp).Enabled = False Then FocusID = 0 : Exit Sub
				If imNumber2(lp).ReadOnly = True Then imNumber2(lp).BackColor = System.Drawing.ColorTranslator.FromOle(IN_READCOL) Else imNumber2(lp).BackColor = MtyTool.IN_BACKCOL
		End Select
		
	End Sub
	
	Private Sub Check1_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles Check1.Enter
		Call GotFocus(Me, Nothing)
		FocusID = 0
	End Sub
	
	Private Sub Check1_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles Check1.KeyDown
		Dim KeyCode As Short = eventArgs.KeyCode
		Dim Shift As Short = eventArgs.KeyData \ &H10000
		Select Case KeyCode
			Case System.Windows.Forms.Keys.Return
				imText1(3).Focus()
		End Select
	End Sub
	
	Private Sub Check1_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles Check1.Leave
		Call LostFocus(Me, Nothing)
	End Sub
	
	Private Sub cmdLook_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdLook.Click
		Dim Index As Short = cmdLook.GetIndex(eventSender)
		
		Dim wkstr As String
		Dim wksql As String
		
		Select Case Index
			Case 0 ' �H��}�X�^����
				frmSearch.MastNo = 1
				If Trim(imText1(1).Text) = "" Then
					wksql = "SELECT DISTINCT (KOUSYU_CD + KOUSYU_NO) FROM WARIDASI_DATA"
					wksql = wksql & " WHERE WARIDASI_KB = '1'"
					wksql = wksql & " AND EDA_NO = '" & KeyKouji.EDA_NO & "'"
					wksql = wksql & " AND KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"
					wkstr = "GYOUSYU_KB = '" & GyosyuID & "' AND KOUSYU_NO <> '00'"
					wkstr = wkstr & " AND KOUSYU_CD + KOUSYU_NO IN (" & wksql & ")"
				Else
					wksql = "SELECT DISTINCT (KOUSYU_CD + KOUSYU_NO) FROM WARIDASI_DATA"
					wksql = wksql & " WHERE WARIDASI_NO = '" & Trim(imText1(1).Text) & "'"
					wksql = wksql & " AND EDA_NO = '" & KeyKouji.EDA_NO & "'"
					wksql = wksql & " AND KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"
					wkstr = "GYOUSYU_KB = '" & GyosyuID & "'"
					wkstr = wkstr & " AND KOUSYU_CD + KOUSYU_NO IN (" & wksql & ")"
				End If
				frmSearch.ZENTEI = wkstr
				frmSearch.ShowDialog()
				If frmSearch.GetCD <> "" Then
					imMask1(Index).Text = Trim(frmSearch.GetCD)
					wkstr = Trim(GetNameKousyu(GyosyuID, Mid(frmSearch.GetCD, 1, 1)))
					wkstr = wkstr & "�|" & Trim(frmSearch.GetNM)
					If wkstr = "�|" Then wkstr = ""
					imText2(Index).Text = wkstr
					imText2(2).Focus()
					Exit Sub
				End If
				imMask1(Index).Focus()
				
			Case 1 ' ���o���}�X�^����
				frmSearch.MastNo = 12
				wkstr = "KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"
				wkstr = wkstr & " AND EDA_NO = '" & KeyKouji.EDA_NO & "'"
				Select Case Mid(Combo1.Text, 1, 1)
					Case "1" '----- �x����
						wkstr = wkstr & " AND CHOKUEI_KB = '1'"
					Case "2" '----- �O������
						wkstr = wkstr & " AND CHOKUEI_KB = '2'"
				End Select
				frmSearch.ZENTEI = wkstr
				frmSearch.ShowDialog()
				If frmSearch.GetCD <> "" Then
					imText1(Index).Text = Trim(frmSearch.GetCD)
					If imMask1(0).Enabled = True Then imMask1(0).Focus() Else imNumber1(0).Focus()
					Exit Sub
				End If
				imText1(Index).Focus()
				
			Case 2 ' ���o���׌���
				wkstr = "WARIDASI_KB = '1'"
				wkstr = wkstr & " AND EDA_NO = '" & KeyKouji.EDA_NO & "'"
				wkstr = wkstr & " AND KOUJI_NO = '" & KeyKouji.KOUJI_NO & "'"
				If Trim(imText1(1).Text) <> "" Then
					wkstr = wkstr & " AND WARIDASI_NO = '" & Trim(imText1(1).Text) & "'"
				End If
				If Trim(imMask1(0).Value) <> "" Then
					wkstr = wkstr & " AND KOUSYU_NO = '" & Mid(imMask1(0).Text, 3, 2) & "'"
					wkstr = wkstr & " AND KOUSYU_CD = '" & Mid(imMask1(0).Text, 1, 1) & "'"
				End If
				frmWaridasi.ZENTEI = wkstr
				frmWaridasi.ShowDialog()
				If frmWaridasi.GetNO <> "" Then
					imText1(Index).Text = Trim(frmWaridasi.GetNO)
					imText2(Index).Text = Trim(frmWaridasi.GetNM)
					imNumber1(0).Focus()
					Exit Sub
				End If
				imText2(Index).Focus()
		End Select
		
	End Sub
	
	Private Sub cmdLook_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdLook.Enter
		Dim Index As Short = cmdLook.GetIndex(eventSender)
		FocusID = 0
	End Sub
	
	'UPGRADE_WARNING: Event Combo1.SelectedIndexChanged may fire when form is initialized. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"'
	Private Sub Combo1_SelectedIndexChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles Combo1.SelectedIndexChanged
		
		Select Case Mid(Combo1.Text, 1, 1)
			Case "1" '----- �x����
				imText1(1).BackColor = System.Drawing.Color.White
				imText1(1).Enabled = True
				If imText1(1).ReadOnly = False Then cmdLook(1).Enabled = True Else cmdLook(1).Enabled = False
				imMask1(0).BackColor = System.Drawing.Color.White
				imMask1(0).Enabled = True
				If imMask1(0).ReadOnly = False Then cmdLook(0).Enabled = True Else cmdLook(0).Enabled = False
				imText1(2).BackColor = System.Drawing.Color.White
				imText1(2).Enabled = True
				If imText1(2).ReadOnly = False Then cmdLook(2).Enabled = True Else cmdLook(2).Enabled = False
				Check1.Enabled = True
				
			Case "2" '----- �O������
				imText1(1).BackColor = System.Drawing.Color.White
				imText1(1).Enabled = True
				If imText1(1).ReadOnly = False Then cmdLook(1).Enabled = True Else cmdLook(1).Enabled = False
				imMask1(0).Value = ""
				imMask1(0).BackColor = System.Drawing.SystemColors.Control
				imMask1(0).Enabled = False
				cmdLook(0).Enabled = False
				imText1(2).Text = ""
				imText1(2).BackColor = System.Drawing.SystemColors.Control
				imText1(2).Enabled = False
				cmdLook(2).Enabled = False
				Check1.CheckState = CShort("0")
				Check1.Enabled = False
				
			Case Else '----- ���I��
				imText1(1).Text = ""
				imText1(1).BackColor = System.Drawing.Color.White
				imText1(1).Enabled = True
				If imText1(1).ReadOnly = False Then cmdLook(1).Enabled = True Else cmdLook(1).Enabled = False
				imMask1(0).Value = ""
				imMask1(0).BackColor = System.Drawing.Color.White
				imMask1(0).Enabled = True
				If imMask1(0).ReadOnly = False Then cmdLook(0).Enabled = True Else cmdLook(0).Enabled = False
				imText1(2).Text = ""
				imText1(2).BackColor = System.Drawing.Color.White
				imText1(2).Enabled = True
				If imText1(2).ReadOnly = False Then cmdLook(2).Enabled = True Else cmdLook(2).Enabled = False
				Check1.Enabled = True
		End Select
		
		Select Case Mid(Combo1.Text, 1, 1)
			Case "1", "2"
				'----- �x������
				If InputID = GyosyuID Then
					Select Case frmSYKD070.HaraiKBN
						Case "1", "2", "3" ' 20�������E27�������E���̑�
							If Check1.CheckState = CDbl("0") Then
								If CCur2(imNumber1(0).Value) = 0 And CCur2(imNumber1(1).Value) = 0 And CCur2(imNumber1(2).Value) = 0 Then
									With frmSYKD070
										imNumber1(0).Value = Trim(Mid(.HirituID, 1, 3))
										imNumber1(1).Value = Trim(Mid(.HirituID, 4, 3))
										imNumber1(2).Value = Trim(Mid(.HirituID, 7, 3))
									End With
								End If
							Else
								imNumber1(0).Value = "0"
								imNumber1(1).Value = "0"
								imNumber1(2).Value = "0"
							End If
						Case Else
							imNumber1(0).Value = "0"
							imNumber1(1).Value = "0"
							imNumber1(2).Value = "0"
					End Select
				End If
		End Select
		
	End Sub
	
	Private Sub Combo1_DropDown(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles Combo1.DropDown
		Call GotFocus(Me, Nothing)
	End Sub
	
	Private Sub Combo1_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles Combo1.Enter
		Call GotFocus(Me, Nothing)
		FocusID = 1
	End Sub
	
	Private Sub Combo1_KeyPress(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyPressEventArgs) Handles Combo1.KeyPress
		Dim KeyAscii As Short = Asc(eventArgs.KeyChar)
		Select Case KeyAscii
			Case System.Windows.Forms.Keys.Return
				If imText1(1).Enabled = True Then
					imText1(1).Focus()
				Else
					imMask1(0).Focus()
				End If
		End Select
		eventArgs.KeyChar = Chr(KeyAscii)
		If KeyAscii = 0 Then
			eventArgs.Handled = True
		End If
	End Sub
	
	Private Sub Combo1_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles Combo1.Leave
		Call LostFocus(Me, Nothing)
	End Sub
	
	Private Sub imMask1_Change(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles imMask1.Change
		Dim Index As Short = imMask1.GetIndex(eventSender)
		imText2(0).Text = ""
		imText1(2).Text = "0"
		imText2(2).Text = ""
	End Sub
	
	Private Sub imMask1_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles imMask1.Enter
		Dim Index As Short = imMask1.GetIndex(eventSender)
		Call GotFocus(Me, Nothing)
		FocusID = 5
	End Sub
	
	Private Sub imMask1_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles imMask1.KeyDown
		Dim KeyCode As Short = eventArgs.KeyCode
		Dim Shift As Short = eventArgs.KeyData \ &H10000
		Dim Index As Short = imMask1.GetIndex(eventSender)
		Select Case KeyCode
			Case System.Windows.Forms.Keys.Return
				imText2(2).Focus()
			Case System.Windows.Forms.Keys.Space
				Call cmdLook_Click(cmdLook.Item(Index), New System.EventArgs())
		End Select
	End Sub
	
	Private Sub imMask1_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles imMask1.Leave
		Dim Index As Short = imMask1.GetIndex(eventSender)
		Dim wkstr As String
		Dim wkCode As String
		Call LostFocus(Me, Nothing)
		Select Case Index
			Case 0 '----- �H������
				wkCode = imMask1(Index).Text
				wkstr = Trim(GetNameKousyu(GyosyuID, Mid(wkCode, 1, 1))) & "�|"
				wkstr = wkstr & Trim(GetNameKousyu(GyosyuID, Mid(wkCode, 1, 1), Mid(wkCode, 3, 2)))
				If wkstr = "�|" Then wkstr = ""
				imText2(Index).Text = wkstr
		End Select
	End Sub
	
	Private Sub imNumber1_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles imNumber1.Enter
		Dim Index As Short = imNumber1.GetIndex(eventSender)
		Call GotFocus(Me, Nothing)
		FocusID = Index + 6
	End Sub
	
	Private Sub imNumber1_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles imNumber1.KeyDown
		Dim KeyCode As Short = eventArgs.KeyCode
		Dim Shift As Short = eventArgs.KeyData \ &H10000
		Dim Index As Short = imNumber1.GetIndex(eventSender)
		Select Case KeyCode
			Case System.Windows.Forms.Keys.Return
				Select Case Index
					Case 0 : imNumber1(1).Focus()
					Case 1 : imNumber1(2).Focus()
					Case 2 : If Check1.Enabled = True Then Check1.Focus() Else imText1(3).Focus()
				End Select
		End Select
	End Sub
	
	Private Sub imNumber1_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles imNumber1.Leave
		Dim Index As Short = imNumber1.GetIndex(eventSender)
		Call LostFocus(Me, Nothing)
	End Sub
	
	Private Sub imNumber2_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles imNumber2.Enter
		Dim Index As Short = imNumber2.GetIndex(eventSender)
		Call GotFocus(Me, Nothing)
		PreVal = CCur2(imNumber2(Index).Value)
		FocusID = Index + 9
	End Sub
	
	Private Sub imNumber2_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles imNumber2.KeyDown
		Dim KeyCode As Short = eventArgs.KeyCode
		Dim Shift As Short = eventArgs.KeyData \ &H10000
		Dim Index As Short = imNumber2.GetIndex(eventSender)
		Dim wkVal As Double
		Select Case KeyCode
			Case System.Windows.Forms.Keys.Return
				Select Case Index
					Case 0 '----- �P��
						imNumber2(1).Focus()
					Case 1 '----- ����
						' ���z�Z�o
						wkVal = CDbl2(imNumber2(0).Value) * CDbl2(imNumber2(1).Value)
						If -999999999999# <= wkVal And wkVal <= 999999999999# Then
							imText2(4).Text = VB6.Format(wkVal, "#,###")
							If wkVal < 0 Then imText2(4).ForeColor = System.Drawing.Color.Red Else imText2(4).ForeColor = System.Drawing.Color.Black
							' ���ʓ��͌�
							EventsObj.ValueChange(2, 0)
							EventsObj.ValueChange(0, 0)
						Else
							MsgBox("���z�̌������I�[�o�[���܂����B", MsgBoxStyle.Information)
							imNumber2(Index).Value = VB6.Format(PreVal)
							imNumber2(Index).Focus()
						End If
				End Select
		End Select
	End Sub
	
	Private Sub imNumber2_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles imNumber2.Leave
		Dim Index As Short = imNumber2.GetIndex(eventSender)
		Dim wkVal As Double
		Call LostFocus(Me, Nothing)
		Select Case Index
			Case 0, 1 '----- �P���E����
				wkVal = CDbl2(imNumber2(0).Value) * CDbl2(imNumber2(1).Value)
				If -999999999999# <= wkVal And wkVal <= 999999999999# Then
					imText2(4).Text = VB6.Format(wkVal, "#,###")
					If wkVal < 0 Then imText2(4).ForeColor = System.Drawing.Color.Red Else imText2(4).ForeColor = System.Drawing.Color.Black
				Else
					MsgBox("���z�̌������I�[�o�[���܂����B", MsgBoxStyle.Information)
					imNumber2(Index).Value = VB6.Format(PreVal)
					imNumber2(Index).Focus()
				End If
		End Select
	End Sub
	
	Private Sub imText1_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles imText1.Enter
		Dim Index As Short = imText1.GetIndex(eventSender)
		Call GotFocus(Me, Nothing)
		FocusID = Index + 1
	End Sub
	
	Private Sub imText1_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles imText1.KeyDown
		Dim KeyCode As Short = eventArgs.KeyCode
		Dim Shift As Short = eventArgs.KeyData \ &H10000
		Dim Index As Short = imText1.GetIndex(eventSender)
		Select Case KeyCode
			Case System.Windows.Forms.Keys.Return
				Select Case Index
					Case 1 '----- ���o��
						If imMask1(0).Enabled = True Then
							imMask1(0).Focus()
						Else
							imNumber1(0).Focus()
						End If
					Case 3 '----- �i����K�i
						imNumber2(0).Focus()
				End Select
			Case System.Windows.Forms.Keys.Space
				Call cmdLook_Click(cmdLook.Item(Index), New System.EventArgs())
		End Select
	End Sub
	
	Private Sub imText1_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles imText1.Leave
		Dim Index As Short = imText1.GetIndex(eventSender)
		Call LostFocus(Me, Nothing)
	End Sub
	
	Private Sub imText2_Change(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles imText2.Change
		Dim Index As Short = imText2.GetIndex(eventSender)
		Select Case Index
			Case 4 '----- ���z�ύX
				EventsObj.ValueChange(1, CCur2(imText2(Index).Text))
		End Select
	End Sub
	
	Private Sub imText2_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles imText2.Enter
		Dim Index As Short = imText2.GetIndex(eventSender)
		If Index = 2 Then
			'UPGRADE_WARNING: Couldn't resolve default property of object MsgBarObj.Panels. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			MsgBarObj.Panels("Message").Text = imText2(Index).Tag
		End If
		FocusID = 0
	End Sub
	
	Private Sub imText2_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles imText2.KeyDown
		Dim KeyCode As Short = eventArgs.KeyCode
		Dim Shift As Short = eventArgs.KeyData \ &H10000
		Dim Index As Short = imText2.GetIndex(eventSender)
		Select Case KeyCode
			Case System.Windows.Forms.Keys.Return
				Select Case Index
					Case 2 '----- ����
						imNumber1(0).Focus()
				End Select
			Case System.Windows.Forms.Keys.Space
				Call cmdLook_Click(cmdLook.Item(Index), New System.EventArgs())
		End Select
	End Sub
	
	Private Sub imText2_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles imText2.Leave
		Dim Index As Short = imText2.GetIndex(eventSender)
		If Index = 2 Then
			'UPGRADE_WARNING: Couldn't resolve default property of object MsgBarObj.Panels. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			MsgBarObj.Panels("Message").Text = ""
		End If
	End Sub
	
	'UPGRADE_ISSUE: PictureBox event Picture1.GotFocus was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="ABD9AF39-7E24-4AFF-AD8D-3675C1AA3054"'
	Private Sub Picture1_GotFocus()
		FocusID = 0
	End Sub
	
	'UPGRADE_ISSUE: PictureBox event Picture2.GotFocus was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="ABD9AF39-7E24-4AFF-AD8D-3675C1AA3054"'
	Private Sub Picture2_GotFocus()
		FocusID = 0
	End Sub
	
	Private Sub ctlMeisai_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Enter
		imText2(3).ForeColor = System.Drawing.Color.Red
		FocusID = 0
	End Sub
	
	Private Sub ctlMeisai_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Leave
		imText2(3).ForeColor = System.Drawing.Color.Black
		'----- ���͏I��
		EventsObj.ValueChange(2, 0)
		FocusID = 0
	End Sub
	
	Private Sub UserControl_Initialize()
		'----- �敪
		With Combo1
			.Items.Clear()
			.Items.Add("")
			.Items.Add("1:�x����")
			.Items.Add("2:�O������")
		End With
	End Sub
	
	Private Sub UserControl_Terminate()
		'UPGRADE_NOTE: Object MsgBarObj may not be destroyed until it is garbage collected. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"'
		MsgBarObj = Nothing
		'UPGRADE_NOTE: Object EventsObj may not be destroyed until it is garbage collected. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"'
		EventsObj = Nothing
	End Sub
	
	
	Public Shadows Property Enabled() As Boolean
		Get
			Enabled = Picture1.Enabled
		End Get
		Set(ByVal Value As Boolean)
			Picture1.Enabled = Value
		End Set
	End Property
	
	Public Shadows ReadOnly Property Events() As clsEvents
		Get
			Events = EventsObj
		End Get
	End Property
	
	Public Shadows WriteOnly Property ForeColor() As Integer
		Set(ByVal Value As Integer)
			imText2(3).ForeColor = System.Drawing.ColorTranslator.FromOle(Value)
		End Set
	End Property
	
	Public WriteOnly Property FocusPos() As Short
		Set(ByVal Value As Short)
			Select Case Value
				Case 1 : Combo1.Focus() ' �敪
				Case 2 : imText1(1).Focus() ' ���o��
				Case 3 : imMask1(0).Focus() ' �H������
				Case 5 : imText2(2).Focus() ' ���ז���
				Case 7 : imNumber1(0).Focus() ' �x�������i�U���j
				Case 8 : imNumber1(1).Focus() ' �x�������i�����j
				Case 9 : imNumber1(2).Focus() ' �x�������i��`�j
				Case 10 : Check1.Focus() ' ���E
				Case 11 : imText1(3).Focus() ' �i����K�i
				Case 12 : imNumber2(0).Focus() ' �P��
				Case 13 : imNumber2(1).Focus() ' ����
			End Select
		End Set
	End Property
	
	Public WriteOnly Property StatusBar() As Object
		Set(ByVal Value As Object)
			MsgBarObj = Value
		End Set
	End Property
	
	
	Public Property Value(ByVal Mode As Short) As Object
		Get
			Select Case Mode
				Case 0 : Value = Trim(imText2(3).Text) ' �s�ԍ�
				Case 1 : Value = Mid(Combo1.Text, 1, 1) ' �敪
				Case 2 : Value = Trim(imText1(1).Text) ' ���o��
				Case 3
					'UPGRADE_WARNING: Couldn't resolve default property of object Value. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
					Value = imMask1(0).Text ' �H������
				Case 4 : Value = Trim(imText2(0).Text) ' �H�햼
				Case 5 : Value = CDbl2(imText1(2).Text) ' ���הԍ�
				Case 6 : Value = Trim(imText2(2).Text) ' ���ז���
				Case 7 : Value = CInt2(imNumber1(0).Value) ' �x�������i�U���j
				Case 8 : Value = CInt2(imNumber1(1).Value) ' �x�������i�����j
				Case 9 : Value = CInt2(imNumber1(2).Value) ' �x�������i��`�j
				Case 10
					'UPGRADE_WARNING: Couldn't resolve default property of object Value. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
					Value = Check1.CheckState ' ���E
				Case 11 : Value = Trim(imText1(3).Text) ' �i����K�i
				Case 12 : Value = CCur2(imNumber2(0).Value) ' �P��
				Case 13 : Value = CCur2(imNumber2(1).Value) ' ����
				Case 14 : Value = CCur2(imText2(4).Text) ' ���z
			End Select
		End Get
		Set(ByVal Value As Object)
			Select Case Mode
				Case 0
					'UPGRADE_WARNING: Couldn't resolve default property of object SetVal. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
					imText2(3).Text = Value ' �s�ԍ�
				Case 1
					'UPGRADE_WARNING: Couldn't resolve default property of object SetVal. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
					Combo1.SelectedIndex = Value ' �敪
				Case 2
					'UPGRADE_WARNING: Couldn't resolve default property of object SetVal. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
					imText1(1).Text = Value ' ���o��
				Case 3
					'UPGRADE_WARNING: Couldn't resolve default property of object SetVal. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
					imMask1(0).Text = Value ' �H������
				Case 4
					'UPGRADE_WARNING: Couldn't resolve default property of object SetVal. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
					imText2(0).Text = Value ' �H�햼
				Case 5
					'UPGRADE_WARNING: Couldn't resolve default property of object SetVal. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
					imText1(2).Text = Value ' ���הԍ�
				Case 6
					'UPGRADE_WARNING: Couldn't resolve default property of object SetVal. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
					imText2(2).Text = Value ' ���ז���
				Case 7
					'UPGRADE_WARNING: Couldn't resolve default property of object SetVal. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
					imNumber1(0).Value = Value ' �x�������i�U���j
				Case 8
					'UPGRADE_WARNING: Couldn't resolve default property of object SetVal. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
					imNumber1(1).Value = Value ' �x�������i�����j
				Case 9
					'UPGRADE_WARNING: Couldn't resolve default property of object SetVal. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
					imNumber1(2).Value = Value ' �x�������i��`�j
				Case 10 ' ���E
					'UPGRADE_WARNING: Couldn't resolve default property of object SetVal. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
					Check1.CheckState = Value
					'UPGRADE_WARNING: Couldn't resolve default property of object SetVal. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
					If Picture2.Enabled = False And Value = "1" Then
						' �T�[�o�[���d��쐬�� AND ���E �̏ꍇ
						'UPGRADE_ISSUE: ComboBox property Combo1.Locked was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="CC4C7EC0-C903-48FC-ACCC-81861D12DA4A"'
						Combo1.Locked = True
					Else
						'UPGRADE_ISSUE: ComboBox property Combo1.Locked was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="CC4C7EC0-C903-48FC-ACCC-81861D12DA4A"'
						Combo1.Locked = False
					End If
				Case 11
					'UPGRADE_WARNING: Couldn't resolve default property of object SetVal. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
					imText1(3).Text = Value ' �i����K�i
				Case 12
					'UPGRADE_WARNING: Couldn't resolve default property of object SetVal. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
					imNumber2(0).Value = Value ' �P��
				Case 13
					'UPGRADE_WARNING: Couldn't resolve default property of object SetVal. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
					imNumber2(1).Value = Value ' ����
				Case 14
					'UPGRADE_WARNING: Couldn't resolve default property of object SetVal. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
					imText2(4).Text = Value ' ���z
				Case 15 '----- ���͒[��
					'UPGRADE_WARNING: Couldn't resolve default property of object SetVal. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
					InputID = Value
					Select Case InputID
						Case "03" '----- �T�[�o�[
							imText2(3).BackColor = System.Drawing.ColorTranslator.FromOle(&HFFC0FF)
							Call CtlReadOnly(True)
						Case "99" '----- �d��쐬��
							imText2(3).BackColor = System.Drawing.ColorTranslator.FromOle(&HC0E0FF)
							Call CtlReadOnly(True)
						Case Else '----- ���̑�
							imText2(3).BackColor = System.Drawing.SystemColors.Control
							Call CtlReadOnly(False)
					End Select
			End Select
		End Set
	End Property
End Class