<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frmSYKD300
#Region "Windows Form Designer generated code "
	<System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
		MyBase.New()
		'This call is required by the Windows Form Designer.
		InitializeComponent()
	End Sub
	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer
	Public ToolTip1 As System.Windows.Forms.ToolTip
	Public WithEvents Command1 As System.Windows.Forms.Button
	Public WithEvents Picture2 As System.Windows.Forms.Panel
	Public WithEvents _cmdKey_5 As System.Windows.Forms.Button
	Public WithEvents _cmdKey_2 As System.Windows.Forms.Button
	Public WithEvents _cmdKey_11 As System.Windows.Forms.Button
	Public WithEvents _cmdKey_1 As System.Windows.Forms.Button
	Public WithEvents _cmdKey_9 As System.Windows.Forms.Button
	Public WithEvents _cmdKey_8 As System.Windows.Forms.Button
	Public WithEvents _cmdKey_7 As System.Windows.Forms.Button
	Public WithEvents _cmdKey_6 As System.Windows.Forms.Button
	Public WithEvents _cmdKey_10 As System.Windows.Forms.Button
	Public WithEvents _cmdKey_4 As System.Windows.Forms.Button
	Public WithEvents _cmdKey_12 As System.Windows.Forms.Button
	Public WithEvents _cmdKey_3 As System.Windows.Forms.Button
	Public WithEvents Picture1 As System.Windows.Forms.Panel
	Public WithEvents _StatusBar1_Panel1 As System.Windows.Forms.ToolStripStatusLabel
	Public WithEvents _StatusBar1_Panel2 As System.Windows.Forms.ToolStripStatusLabel
	Public WithEvents StatusBar1 As System.Windows.Forms.StatusStrip
	Public WithEvents vaSpread1 As AxFPSpread.AxvaSpread
	Public WithEvents lblTitle As System.Windows.Forms.Label
	Public WithEvents cmdKey As Microsoft.VisualBasic.Compatibility.VB6.ButtonArray
	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmSYKD300))
		Me.components = New System.ComponentModel.Container()
		Me.ToolTip1 = New System.Windows.Forms.ToolTip(components)
		Me.Picture2 = New System.Windows.Forms.Panel
		Me.Command1 = New System.Windows.Forms.Button
		Me.Picture1 = New System.Windows.Forms.Panel
		Me._cmdKey_5 = New System.Windows.Forms.Button
		Me._cmdKey_2 = New System.Windows.Forms.Button
		Me._cmdKey_11 = New System.Windows.Forms.Button
		Me._cmdKey_1 = New System.Windows.Forms.Button
		Me._cmdKey_9 = New System.Windows.Forms.Button
		Me._cmdKey_8 = New System.Windows.Forms.Button
		Me._cmdKey_7 = New System.Windows.Forms.Button
		Me._cmdKey_6 = New System.Windows.Forms.Button
		Me._cmdKey_10 = New System.Windows.Forms.Button
		Me._cmdKey_4 = New System.Windows.Forms.Button
		Me._cmdKey_12 = New System.Windows.Forms.Button
		Me._cmdKey_3 = New System.Windows.Forms.Button
		Me.StatusBar1 = New System.Windows.Forms.StatusStrip
		Me._StatusBar1_Panel1 = New System.Windows.Forms.ToolStripStatusLabel
		Me._StatusBar1_Panel2 = New System.Windows.Forms.ToolStripStatusLabel
		Me.vaSpread1 = New AxFPSpread.AxvaSpread
		Me.lblTitle = New System.Windows.Forms.Label
		Me.cmdKey = New Microsoft.VisualBasic.Compatibility.VB6.ButtonArray(components)
		Me.Picture2.SuspendLayout()
		Me.Picture1.SuspendLayout()
		Me.StatusBar1.SuspendLayout()
		Me.SuspendLayout()
		Me.ToolTip1.Active = True
		CType(Me.vaSpread1, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.cmdKey, System.ComponentModel.ISupportInitialize).BeginInit()
		Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
		Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
		Me.Text = "�H���Ǘ��V�X�e��"
		Me.ClientSize = New System.Drawing.Size(1016, 742)
		Me.Location = New System.Drawing.Point(4, 23)
		Me.Icon = CType(resources.GetObject("frmSYKD300.Icon"), System.Drawing.Icon)
		Me.KeyPreview = True
		Me.MaximizeBox = False
		Me.MinimizeBox = False
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.BackColor = System.Drawing.SystemColors.Control
		Me.ControlBox = True
		Me.Enabled = True
		Me.Cursor = System.Windows.Forms.Cursors.Default
		Me.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.ShowInTaskbar = True
		Me.HelpButton = False
		Me.WindowState = System.Windows.Forms.FormWindowState.Normal
		Me.Name = "frmSYKD300"
		Me.Picture2.Enabled = False
		Me.Picture2.ForeColor = System.Drawing.SystemColors.WindowText
		Me.Picture2.Size = New System.Drawing.Size(371, 53)
		Me.Picture2.Location = New System.Drawing.Point(642, 36)
		Me.Picture2.TabIndex = 16
		Me.Picture2.TabStop = False
		Me.Picture2.Visible = False
		Me.Picture2.Dock = System.Windows.Forms.DockStyle.None
		Me.Picture2.BackColor = System.Drawing.SystemColors.Control
		Me.Picture2.CausesValidation = True
		Me.Picture2.Cursor = System.Windows.Forms.Cursors.Default
		Me.Picture2.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Picture2.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Picture2.Name = "Picture2"
		Me.Command1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.Command1.BackColor = System.Drawing.Color.FromARGB(255, 192, 255)
		Me.Command1.Text = "�f�[�^�̓]�������     "
		Me.Command1.Font = New System.Drawing.Font("�l�r ����", 14.25!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me.Command1.Size = New System.Drawing.Size(371, 53)
		Me.Command1.Location = New System.Drawing.Point(0, 0)
		Me.Command1.TabIndex = 17
		Me.Command1.TabStop = False
		Me.Command1.CausesValidation = True
		Me.Command1.Enabled = True
		Me.Command1.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Command1.Cursor = System.Windows.Forms.Cursors.Default
		Me.Command1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Command1.Name = "Command1"
		Me.Picture1.Dock = System.Windows.Forms.DockStyle.Bottom
		Me.Picture1.BackColor = System.Drawing.Color.FromARGB(128, 128, 128)
		Me.Picture1.Size = New System.Drawing.Size(1016, 51)
		Me.Picture1.Location = New System.Drawing.Point(0, 668)
		Me.Picture1.TabIndex = 13
		Me.Picture1.TabStop = False
		Me.Picture1.CausesValidation = True
		Me.Picture1.Enabled = True
		Me.Picture1.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Picture1.Cursor = System.Windows.Forms.Cursors.Default
		Me.Picture1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Picture1.Visible = True
		Me.Picture1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.Picture1.Name = "Picture1"
		Me._cmdKey_5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me._cmdKey_5.Text = "  F5  �� ��"
		Me._cmdKey_5.Font = New System.Drawing.Font("�l�r ����", 11.25!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._cmdKey_5.Size = New System.Drawing.Size(77, 39)
		Me._cmdKey_5.Location = New System.Drawing.Point(348, 4)
		Me._cmdKey_5.TabIndex = 4
		Me._cmdKey_5.Tag = "�f�[�^���󂯎��܂��B"
		Me._cmdKey_5.BackColor = System.Drawing.SystemColors.Control
		Me._cmdKey_5.CausesValidation = True
		Me._cmdKey_5.Enabled = True
		Me._cmdKey_5.ForeColor = System.Drawing.SystemColors.ControlText
		Me._cmdKey_5.Cursor = System.Windows.Forms.Cursors.Default
		Me._cmdKey_5.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._cmdKey_5.TabStop = True
		Me._cmdKey_5.Name = "_cmdKey_5"
		Me._cmdKey_2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me._cmdKey_2.Text = "  F2  �@"
		Me._cmdKey_2.Enabled = False
		Me._cmdKey_2.Font = New System.Drawing.Font("�l�r ����", 11.25!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._cmdKey_2.Size = New System.Drawing.Size(77, 39)
		Me._cmdKey_2.Location = New System.Drawing.Point(86, 4)
		Me._cmdKey_2.TabIndex = 1
		Me._cmdKey_2.BackColor = System.Drawing.SystemColors.Control
		Me._cmdKey_2.CausesValidation = True
		Me._cmdKey_2.ForeColor = System.Drawing.SystemColors.ControlText
		Me._cmdKey_2.Cursor = System.Windows.Forms.Cursors.Default
		Me._cmdKey_2.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._cmdKey_2.TabStop = True
		Me._cmdKey_2.Name = "_cmdKey_2"
		Me._cmdKey_11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me._cmdKey_11.Text = "  F11  �@"
		Me._cmdKey_11.Enabled = False
		Me._cmdKey_11.Font = New System.Drawing.Font("�l�r ����", 11.25!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._cmdKey_11.Size = New System.Drawing.Size(77, 39)
		Me._cmdKey_11.Location = New System.Drawing.Point(849, 4)
		Me._cmdKey_11.TabIndex = 10
		Me._cmdKey_11.BackColor = System.Drawing.SystemColors.Control
		Me._cmdKey_11.CausesValidation = True
		Me._cmdKey_11.ForeColor = System.Drawing.SystemColors.ControlText
		Me._cmdKey_11.Cursor = System.Windows.Forms.Cursors.Default
		Me._cmdKey_11.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._cmdKey_11.TabStop = True
		Me._cmdKey_11.Name = "_cmdKey_11"
		Me._cmdKey_1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me._cmdKey_1.Text = "  F1  �@"
		Me._cmdKey_1.Enabled = False
		Me._cmdKey_1.Font = New System.Drawing.Font("�l�r ����", 11.25!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._cmdKey_1.Size = New System.Drawing.Size(77, 39)
		Me._cmdKey_1.Location = New System.Drawing.Point(6, 4)
		Me._cmdKey_1.TabIndex = 0
		Me._cmdKey_1.BackColor = System.Drawing.SystemColors.Control
		Me._cmdKey_1.CausesValidation = True
		Me._cmdKey_1.ForeColor = System.Drawing.SystemColors.ControlText
		Me._cmdKey_1.Cursor = System.Windows.Forms.Cursors.Default
		Me._cmdKey_1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._cmdKey_1.TabStop = True
		Me._cmdKey_1.Name = "_cmdKey_1"
		Me._cmdKey_9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me._cmdKey_9.Text = "  F9  �@"
		Me._cmdKey_9.Enabled = False
		Me._cmdKey_9.Font = New System.Drawing.Font("�l�r ����", 11.25!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._cmdKey_9.Size = New System.Drawing.Size(77, 39)
		Me._cmdKey_9.Location = New System.Drawing.Point(689, 4)
		Me._cmdKey_9.TabIndex = 8
		Me._cmdKey_9.BackColor = System.Drawing.SystemColors.Control
		Me._cmdKey_9.CausesValidation = True
		Me._cmdKey_9.ForeColor = System.Drawing.SystemColors.ControlText
		Me._cmdKey_9.Cursor = System.Windows.Forms.Cursors.Default
		Me._cmdKey_9.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._cmdKey_9.TabStop = True
		Me._cmdKey_9.Name = "_cmdKey_9"
		Me._cmdKey_8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me._cmdKey_8.Text = "  F8  �e�c����"
		Me._cmdKey_8.Font = New System.Drawing.Font("�l�r ����", 11.25!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._cmdKey_8.Size = New System.Drawing.Size(77, 39)
		Me._cmdKey_8.Location = New System.Drawing.Point(588, 4)
		Me._cmdKey_8.TabIndex = 7
		Me._cmdKey_8.Tag = "�e�c������͂��܂��B"
		Me._cmdKey_8.BackColor = System.Drawing.SystemColors.Control
		Me._cmdKey_8.CausesValidation = True
		Me._cmdKey_8.Enabled = True
		Me._cmdKey_8.ForeColor = System.Drawing.SystemColors.ControlText
		Me._cmdKey_8.Cursor = System.Windows.Forms.Cursors.Default
		Me._cmdKey_8.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._cmdKey_8.TabStop = True
		Me._cmdKey_8.Name = "_cmdKey_8"
		Me._cmdKey_7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me._cmdKey_7.Text = "  F7  �@"
		Me._cmdKey_7.Enabled = False
		Me._cmdKey_7.Font = New System.Drawing.Font("�l�r ����", 11.25!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._cmdKey_7.Size = New System.Drawing.Size(77, 39)
		Me._cmdKey_7.Location = New System.Drawing.Point(508, 4)
		Me._cmdKey_7.TabIndex = 6
		Me._cmdKey_7.BackColor = System.Drawing.SystemColors.Control
		Me._cmdKey_7.CausesValidation = True
		Me._cmdKey_7.ForeColor = System.Drawing.SystemColors.ControlText
		Me._cmdKey_7.Cursor = System.Windows.Forms.Cursors.Default
		Me._cmdKey_7.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._cmdKey_7.TabStop = True
		Me._cmdKey_7.Name = "_cmdKey_7"
		Me._cmdKey_6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me._cmdKey_6.Text = "  F6  �@"
		Me._cmdKey_6.Enabled = False
		Me._cmdKey_6.Font = New System.Drawing.Font("�l�r ����", 11.25!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._cmdKey_6.Size = New System.Drawing.Size(77, 39)
		Me._cmdKey_6.Location = New System.Drawing.Point(428, 4)
		Me._cmdKey_6.TabIndex = 5
		Me._cmdKey_6.BackColor = System.Drawing.SystemColors.Control
		Me._cmdKey_6.CausesValidation = True
		Me._cmdKey_6.ForeColor = System.Drawing.SystemColors.ControlText
		Me._cmdKey_6.Cursor = System.Windows.Forms.Cursors.Default
		Me._cmdKey_6.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._cmdKey_6.TabStop = True
		Me._cmdKey_6.Name = "_cmdKey_6"
		Me._cmdKey_10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me._cmdKey_10.Text = "  F10  �@"
		Me._cmdKey_10.Enabled = False
		Me._cmdKey_10.Font = New System.Drawing.Font("�l�r ����", 11.25!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._cmdKey_10.Size = New System.Drawing.Size(77, 39)
		Me._cmdKey_10.Location = New System.Drawing.Point(769, 4)
		Me._cmdKey_10.TabIndex = 9
		Me._cmdKey_10.BackColor = System.Drawing.SystemColors.Control
		Me._cmdKey_10.CausesValidation = True
		Me._cmdKey_10.ForeColor = System.Drawing.SystemColors.ControlText
		Me._cmdKey_10.Cursor = System.Windows.Forms.Cursors.Default
		Me._cmdKey_10.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._cmdKey_10.TabStop = True
		Me._cmdKey_10.Name = "_cmdKey_10"
		Me._cmdKey_4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me._cmdKey_4.Text = "  F4  �@"
		Me._cmdKey_4.Enabled = False
		Me._cmdKey_4.Font = New System.Drawing.Font("�l�r ����", 11.25!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._cmdKey_4.Size = New System.Drawing.Size(77, 39)
		Me._cmdKey_4.Location = New System.Drawing.Point(246, 4)
		Me._cmdKey_4.TabIndex = 3
		Me._cmdKey_4.BackColor = System.Drawing.SystemColors.Control
		Me._cmdKey_4.CausesValidation = True
		Me._cmdKey_4.ForeColor = System.Drawing.SystemColors.ControlText
		Me._cmdKey_4.Cursor = System.Windows.Forms.Cursors.Default
		Me._cmdKey_4.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._cmdKey_4.TabStop = True
		Me._cmdKey_4.Name = "_cmdKey_4"
		Me._cmdKey_12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me._cmdKey_12.Text = "  F12  �I ��"
		Me._cmdKey_12.Font = New System.Drawing.Font("�l�r ����", 11.25!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._cmdKey_12.Size = New System.Drawing.Size(77, 39)
		Me._cmdKey_12.Location = New System.Drawing.Point(929, 4)
		Me._cmdKey_12.TabIndex = 11
		Me._cmdKey_12.Tag = "�������I�����܂��B"
		Me._cmdKey_12.BackColor = System.Drawing.SystemColors.Control
		Me._cmdKey_12.CausesValidation = True
		Me._cmdKey_12.Enabled = True
		Me._cmdKey_12.ForeColor = System.Drawing.SystemColors.ControlText
		Me._cmdKey_12.Cursor = System.Windows.Forms.Cursors.Default
		Me._cmdKey_12.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._cmdKey_12.TabStop = True
		Me._cmdKey_12.Name = "_cmdKey_12"
		Me._cmdKey_3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me._cmdKey_3.Text = "  F3  �@"
		Me._cmdKey_3.Enabled = False
		Me._cmdKey_3.Font = New System.Drawing.Font("�l�r ����", 11.25!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me._cmdKey_3.Size = New System.Drawing.Size(77, 39)
		Me._cmdKey_3.Location = New System.Drawing.Point(166, 4)
		Me._cmdKey_3.TabIndex = 2
		Me._cmdKey_3.BackColor = System.Drawing.SystemColors.Control
		Me._cmdKey_3.CausesValidation = True
		Me._cmdKey_3.ForeColor = System.Drawing.SystemColors.ControlText
		Me._cmdKey_3.Cursor = System.Windows.Forms.Cursors.Default
		Me._cmdKey_3.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._cmdKey_3.TabStop = True
		Me._cmdKey_3.Name = "_cmdKey_3"
		Me.StatusBar1.Dock = System.Windows.Forms.DockStyle.Bottom
		Me.StatusBar1.Size = New System.Drawing.Size(1016, 23)
		Me.StatusBar1.Location = New System.Drawing.Point(0, 719)
		Me.StatusBar1.TabIndex = 12
		Me.StatusBar1.Font = New System.Drawing.Font("�l�r �S�V�b�N", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me.StatusBar1.Name = "StatusBar1"
		Me._StatusBar1_Panel1.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter
		Me._StatusBar1_Panel1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
		Me._StatusBar1_Panel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me._StatusBar1_Panel1.Size = New System.Drawing.Size(117, 23)
		Me._StatusBar1_Panel1.BorderSides = CType(System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom, System.Windows.Forms.ToolStripStatusLabelBorderSides)
		Me._StatusBar1_Panel1.Margin = New System.Windows.Forms.Padding(0)
		Me._StatusBar1_Panel1.AutoSize = False
		Me._StatusBar1_Panel2.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter
		Me._StatusBar1_Panel2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
		Me._StatusBar1_Panel2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._StatusBar1_Panel2.Size = New System.Drawing.Size(902, 23)
		Me._StatusBar1_Panel2.BorderSides = CType(System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom, System.Windows.Forms.ToolStripStatusLabelBorderSides)
		Me._StatusBar1_Panel2.Margin = New System.Windows.Forms.Padding(0)
		Me._StatusBar1_Panel2.AutoSize = False
		vaSpread1.OcxState = CType(resources.GetObject("vaSpread1.OcxState"), System.Windows.Forms.AxHost.State)
		Me.vaSpread1.Size = New System.Drawing.Size(733, 552)
		Me.vaSpread1.Location = New System.Drawing.Point(62, 78)
		Me.vaSpread1.TabIndex = 15
		Me.vaSpread1.Name = "vaSpread1"
		Me.lblTitle.BackColor = System.Drawing.Color.FromARGB(192, 255, 192)
		Me.lblTitle.Text = " ��M�f�[�^�ꗗ"
		Me.lblTitle.Font = New System.Drawing.Font("�l�r ����", 20.25!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me.lblTitle.ForeColor = System.Drawing.Color.FromARGB(0, 0, 128)
		Me.lblTitle.Size = New System.Drawing.Size(1015, 33)
		Me.lblTitle.Location = New System.Drawing.Point(0, 0)
		Me.lblTitle.TabIndex = 14
		Me.lblTitle.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.lblTitle.Enabled = True
		Me.lblTitle.Cursor = System.Windows.Forms.Cursors.Default
		Me.lblTitle.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.lblTitle.UseMnemonic = True
		Me.lblTitle.Visible = True
		Me.lblTitle.AutoSize = False
		Me.lblTitle.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.lblTitle.Name = "lblTitle"
		Me.Controls.Add(Picture2)
		Me.Controls.Add(Picture1)
		Me.Controls.Add(StatusBar1)
		Me.Controls.Add(vaSpread1)
		Me.Controls.Add(lblTitle)
		Me.Picture2.Controls.Add(Command1)
		Me.Picture1.Controls.Add(_cmdKey_5)
		Me.Picture1.Controls.Add(_cmdKey_2)
		Me.Picture1.Controls.Add(_cmdKey_11)
		Me.Picture1.Controls.Add(_cmdKey_1)
		Me.Picture1.Controls.Add(_cmdKey_9)
		Me.Picture1.Controls.Add(_cmdKey_8)
		Me.Picture1.Controls.Add(_cmdKey_7)
		Me.Picture1.Controls.Add(_cmdKey_6)
		Me.Picture1.Controls.Add(_cmdKey_10)
		Me.Picture1.Controls.Add(_cmdKey_4)
		Me.Picture1.Controls.Add(_cmdKey_12)
		Me.Picture1.Controls.Add(_cmdKey_3)
		Me.StatusBar1.Items.AddRange(New System.Windows.Forms.ToolStripItem(){Me._StatusBar1_Panel1})
		Me.StatusBar1.Items.AddRange(New System.Windows.Forms.ToolStripItem(){Me._StatusBar1_Panel2})
		Me.cmdKey.SetIndex(_cmdKey_5, CType(5, Short))
		Me.cmdKey.SetIndex(_cmdKey_2, CType(2, Short))
		Me.cmdKey.SetIndex(_cmdKey_11, CType(11, Short))
		Me.cmdKey.SetIndex(_cmdKey_1, CType(1, Short))
		Me.cmdKey.SetIndex(_cmdKey_9, CType(9, Short))
		Me.cmdKey.SetIndex(_cmdKey_8, CType(8, Short))
		Me.cmdKey.SetIndex(_cmdKey_7, CType(7, Short))
		Me.cmdKey.SetIndex(_cmdKey_6, CType(6, Short))
		Me.cmdKey.SetIndex(_cmdKey_10, CType(10, Short))
		Me.cmdKey.SetIndex(_cmdKey_4, CType(4, Short))
		Me.cmdKey.SetIndex(_cmdKey_12, CType(12, Short))
		Me.cmdKey.SetIndex(_cmdKey_3, CType(3, Short))
		CType(Me.cmdKey, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.vaSpread1, System.ComponentModel.ISupportInitialize).EndInit()
		Me.Picture2.ResumeLayout(False)
		Me.Picture1.ResumeLayout(False)
		Me.StatusBar1.ResumeLayout(False)
		Me.ResumeLayout(False)
		Me.PerformLayout()
	End Sub
#End Region 
End Class