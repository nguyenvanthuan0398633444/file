import { Component, OnInit } from '@angular/core';
import { Student } from '../Models/Student';
import { ServerHttpService } from '../Services/server-http.service';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonService } from '../Services/common.service';
import { Subject,Observable,of } from 'rxjs';
import { debounceTime,distinctUntilChanged,switchMap } from 'rxjs/operators';

@Component({
  selector: 'app-student',
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.css']
})

export class StudentComponent implements OnInit {
  
  private searchSubject = new Subject<string>();
  public students: Student[] = [];
  constructor(
    private serverHttp: ServerHttpService,
    private router: Router,
    private route: ActivatedRoute,
    public common : CommonService
    ) { }

  ngOnInit(): void {
    this.serverHttp.getStudents().subscribe((data) => {
      this.students = data;
    });
   
  }

   search(searchKey: string): void{
    console.log('search ', searchKey);
    this.serverHttp.Search(searchKey).subscribe((data)=>{
      console.log('thuan',data)
    })
    this.searchSubject.next(searchKey);
  }

  private loadData() {
    this.serverHttp.getStudents().subscribe((data) => {
      console.log('getStudents', data);
      this.students = data;
      this.common.setTotalStudents(data.length);
      
    });
    
  }
  public deleteStudent(studentId : any) {
    this.serverHttp.deleteStudent(studentId).subscribe((data) => {
      console.log('delete', data);
      this.loadData();
    });
  }
  public AddStudent(){
    this.router.navigate(['AddStudent',0])
  }
  public EditStudent(id:any){
    this.router.navigate(['AddStusent',id])
  }
}
