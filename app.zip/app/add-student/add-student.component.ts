import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Student } from '../Models/Student';
import { ServerHttpService } from '../Services/server-http.service';
import { Router, ActivatedRoute } from '@angular/router';
import { CommonService } from '../Services/common.service';

@Component({
  selector: 'app-add-student',
  templateUrl: './add-student.component.html',
  styleUrls: ['./add-student.component.css']
})
export class AddStudentComponent implements OnInit {

  public id: any = 0;
  public studentForm = new FormGroup({
    code: new FormControl(''),
    gender: new FormControl(''),
    Name: new FormControl(''),
    Bithday: new FormControl(''),
    email: new FormControl(''),
    phone: new FormControl(''),
    picture: new FormControl(''),
  });

  constructor(
    private serverHttp: ServerHttpService,
    private router: Router,
    private commom: CommonService,
    private route: ActivatedRoute
  ) { }

  ngOnInit(): void {
    this.id = this.route.snapshot.paramMap.get('id');
    if (this.id > 0) {
      this.loadData(this.id);
    }
  }
  // hàm này đưa dữ liệu vào một biến student
  private createNewData() {
    const newStudent: any = {};
    for (const controlName in this.studentForm.controls) {
      if (controlName) {
        newStudent[controlName] = this.studentForm.controls[controlName].value;
      }
    }
    return newStudent as Student;
  }

  private loadData(id: any) {
    this.serverHttp.getStudent(id).subscribe((data) => {
      console.log('getStudent', data);
      for (const controlName in this.studentForm.controls) {
        if (controlName) {
          this.studentForm.controls[controlName].setValue(data[controlName]);
        }
      }
    });
  }
  //lưu và về trang chủ
  public SaveGoTo() {
    if (this.id > 0) {
      this.serverHttp.EditStudent(this.id,this.createNewData()).subscribe(data => {
        this.router.navigate(['students']);
      });
    } else {
      this.serverHttp.addStudent(this.createNewData()).subscribe(data => {
        this.commom.increamentStudent();
        this.router.navigate(['students']);
      });
    }
  }
  //lưu và ở lại 
  public save() {
    if (this.id > 0) {
      this.serverHttp.EditStudent(this.id,this.createNewData()).subscribe(data => {
        this.id=0;
        this.studentForm.reset();
      });
    } else {
      this.serverHttp.addStudent(this.createNewData()).subscribe(data => {
        this.commom.increamentStudent();
        this.studentForm.reset();
      });
    }
  }
}
