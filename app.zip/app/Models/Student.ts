export interface Student {
    id: string;
    code: string;
    Name: string;
    gender: string;
    Bithday?: Date;
    email?: string;
    phone?: string;
    picture?: string;
  }