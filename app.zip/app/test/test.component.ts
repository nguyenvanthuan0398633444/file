import { Component, OnInit } from '@angular/core';
import { Student } from '../Models/Student';
import { ServerHttpService } from '../Services/server-http.service';

@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.css']
})
export class TestComponent implements OnInit {
  public students: Student[] = [];  
  constructor(
    private serverHttp: ServerHttpService
  ) { }

  ngOnInit(): void {
    this.serverHttp.getStudents().subscribe((data) => {
      this.students = data;
    });
  }
  public selecs: any;
  on(movie:any): void{
    this.selecs=movie;
    console.log(this.selecs);
  }
 }
    
  


