﻿namespace AIT.Convert.Const
{
    public static class Constant
    {
        public const string VbDesignerFilePattern = @"^([\w])*\.Designer.*\.vb";

        public const string ObjectDeclaration = @"^(\s*)Dim\s+(.*)\s+As\s+Object";
        public const string MultipleQuoteCommentPattern = @"\'\'\'";
        public const string CommentUpgradeNotePattern = @"UPGRADE_NOTE|UPGRADE_WARNING|UPGRADE_ISSUE";
        public const string FunctionPattern = @"(\w*)\s+(Function)(.*)\s+As.*|^\s*(\w*)\s+Function(.*)\s+As.*";
        public const string SubPattern = @"(\w*)\s+(Sub)\s+(.*)|^\s*(Sub)\s+(.*)";
        public const string EndFunctionPattern = @"End\s*(Function)";
        public const string EndSubPattern = @"End\s*(Sub)";
        public const string StructurePattern = @"(\w*)\s+Structure+(.*)(\w)+";
        public const string EndStructurePattern = @"^\s*End\s*(Structure)";

        public static string OracleDataRow = $"Dim DTRow As DataRow";

        public const string TodoMsgId = "T_001";
        public const string OracleFieldWarningID = "O_W001";
        public const string ErrorMsgID= "E_001";

        public const string VSViewTextWidth = @"(.*)([ |	])([\s\S]*)\.TextWidth\(([\s\S]*)\)";
        public const string VSViewTextHeight = @"(.*)([ |	])([\s\S]*)\.TextHeight\(([\s\S]*)\)";
        public const string VSViewFontSize = @"([\s\S]*)\.Font\.Size = ([\s\S]*)";

        public const string SQLServerDbConnection = @"Public\s(\w*)\sAs\sADODB\.Connection";
        public const string OracleDbConnection = @"Public\s(\w*)\sAs\sOracleInProcServer.OraDatabase";
		public const string DoUntil = @"Do\sUntil\s(\w*)\.EOF";
       

        public const string NOT_REPLACE = "NOT_REPLACE";
        public const string DELETE = "DELETE";

        public struct ConvertVsView
        {
            public const string VIEWTOOL = "viewtool.vb";
            public const string DRAW_PATTERN = @"([ |	])(\w*)\.DrawPicture\((.*)\,(.*)\,(.*)\,(.*)\,(.*)\)";
        }
        public struct ConvertDesign
        {
            public const string PROP_CTRS = @"Public\sWithEvents\s";
            public const string LAYOUT_CTRS = @"Public\sSub\sNew";
            public const string LAYOUT_CTRS_END = @"End\sSub";
        }

        public struct FilePath
        {
            public const string VB_RULES = "..\\..\\Rules\\VBRules.txt";
            public const string SPREAD_RULES = "..\\..\\Rules\\SpreadRules.txt";
            public const string ORACLE_RULES = "..\\..\\Rules\\OracleRules.txt";
            public const string SQLSV_RULES = "..\\..\\Rules\\SQLServerRules.txt";
            public const string VSVIEW_RULES = "..\\..\\Rules\\VSViewRules.txt";
            public const string VIEWTOOL_RULES = "..\\..\\Rules\\ViewToolRules.txt";
            public const string SUB_RULES = "..\\..\\Rules\\SubRules.txt";
            public const string MESSAGES = "..\\..\\Messages\\Message.txt";
            public const string DESIGN_RULES = "..\\..\\Rules\\DesignRules.txt";
            public const string INPUTMAN_RULES = "..\\..\\Rules\\InputManRules.txt";
        }
    }
}
