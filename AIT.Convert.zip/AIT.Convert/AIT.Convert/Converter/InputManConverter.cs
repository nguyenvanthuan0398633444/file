﻿using AIT.Convert.Const;
using AIT.Convert.Model;
using AIT.Convert.Utils;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;

namespace AIT.Convert.Converter
{
    public static class InputManConverter
    {
        public static List<RuleModel> InputManRules = new List<RuleModel>();

        /// <summary>
        /// Convert Syntax của các dòng lẻ không nằm trong Function Block
        /// </summary>
        /// <param name="convertLine"></param>
        public static void ConvertSingleLine(ConvertResult convertLine)
        {
            foreach (RuleModel rule in InputManRules)
            {
                if (rule.SubRuleIdList.Any()) continue;

                if (Regex.IsMatch(convertLine.After, rule.Find, RegexOptions.IgnoreCase))
                {
                    if (!string.IsNullOrEmpty(rule.WarningMsgId)) Common.AddMessageID(convertLine, rule.WarningMsgId);

                    if (rule.TodoFlg)
                    {
                        convertLine.MessageIDs.Add(Constant.TodoMsgId);
                        continue;
                    }

                    if (!rule.Replace.Equals(Constant.NOT_REPLACE, StringComparison.OrdinalIgnoreCase))
                    {
                        //Remove phần comment đi
                        string commentPart = string.Empty;
                        string targetStringRemovedComment = string.Empty;
                        bool isSuccess = true;
                        Common.SplitStringByCommand(convertLine.After, rule.Find, ref commentPart, ref targetStringRemovedComment, ref isSuccess);
                        //trong trường hợp sau khi remove phần comment đi và không còn thõa mãn pattern nữa thì return;
                        if (!isSuccess) continue;

                        convertLine.After = $"{Regex.Replace(targetStringRemovedComment, rule.Find, rule.Replace, RegexOptions.IgnoreCase)}\t{commentPart}";
                        convertLine.Result = true;
                    }
                }
            }
        }
        /// <summary>
        /// Convert Vb của dòng thuộc functionBlock
        /// </summary>
        /// <param name="convertLine"></param>
        /// <param name="functionBlock"></param>
        public static void ConvertBlockFuncVb(ConvertResult convertLine, List<ConvertResult> functionBlock)
        {
            foreach (RuleModel rule in InputManRules)
            {
                Regex regex = new Regex(rule.Find, RegexOptions.IgnoreCase);
                if (regex.IsMatch(convertLine.After))
                {
                    if (string.IsNullOrEmpty(rule.WarningMsgId)) Common.AddMessageID(convertLine, rule.WarningMsgId);

                    if (rule.TodoFlg)
                    {
                        Common.AddMessageID(convertLine, Constant.TodoMsgId);
                        continue;
                    }

                    if (rule.SubRuleIdList.Any()) SubRuleConverter.ConvertSubRule(rule, convertLine, functionBlock);

                    if (!rule.Replace.Equals(Constant.NOT_REPLACE, StringComparison.OrdinalIgnoreCase))
                    {
                        //Remove phần comment đi
                        string commentPart = string.Empty;
                        string targetStringRemovedComment = string.Empty;
                        bool isSuccess = true;
                        Common.SplitStringByCommand(convertLine.After, rule.Find, ref commentPart, ref targetStringRemovedComment, ref isSuccess);
                        //trong trường hợp sau khi remove phần comment đi và không còn thõa mãn pattern nữa thì return;
                        if (!isSuccess) continue;

                        convertLine.After = $"{Regex.Replace(targetStringRemovedComment, rule.Find, rule.Replace, RegexOptions.IgnoreCase)}\t{commentPart}";
                        convertLine.Result = true;
                    }
                }
            }
        }
        /// <summary>
        ///  Convert function handles event name
        ///  Thay vì sự kiện cho mỗi group control sẽ thực hiện convert cho từng control chứa trong group đó
        /// </summary>
        /// <param name="convertLine"></param>
        public static void ConvertHandlesEventFunction(ConvertResult convertLine)
        {
            
            // check function is handles event function and not mybase
            Regex handlesEventFunctionRegex = new Regex(@"(.*)\sHandles\s(((?!MyBase).)*)\.(\w*)", RegexOptions.IgnoreCase);
            Match match = handlesEventFunctionRegex.Match(convertLine.After);
            if (match.Success)
            {
                string functionName = match.Groups[1].Value;
                string controlGroupName = match.Groups[2].Value;
                string eventName = match.Groups[4].Value;
                // if event is change and control is GcTextBox else GcNumber
                if (eventName.Equals("Change"))
                {
                    if (controlGroupName.Contains("Text"))
                    {
                        eventName = "TextChanged";
                    } else {
                        eventName = "ValueChanged";
                    }
                } 
                string replaceEvent = "";
                foreach (DesignConvertModel groupControl in DesignConverter.ArrayConvert)
                {
                    if (groupControl.Key.Equals(controlGroupName))
                    {
                        foreach(DesignArr control in groupControl.Arrs)
                        {
                            replaceEvent += control.Name + "." + eventName + ",";
                        }
                        break;
                    }
                    replaceEvent = replaceEvent.Remove(replaceEvent.Length - 1); // remove last character in string ","
                    string replace = functionName + " Handles " + replaceEvent;
                    convertLine.After = handlesEventFunctionRegex.Replace(convertLine.After, $"{replace}");
                    convertLine.Result = true;
                }
                convertLine.Result = false;
            }

        }
    }
}
