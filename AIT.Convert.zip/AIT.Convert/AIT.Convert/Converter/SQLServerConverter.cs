﻿using AIT.Convert.Const;
using AIT.Convert.Model;
using AIT.Convert.Utils;
using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace AIT.Convert.Converter
{
    public class SQLServerConverter
    {
        public static List<RuleModel> DBRules = new List<RuleModel>();
        public static bool isDbConnection = false;

        private static bool isDoUntil = false;
        private static bool isForInDoUntil = false;
        private const string END_SUB = "\tEnd Sub";
        private const string END_FUNC = "\tEnd Function";
        /// <summary>
        /// Convert Syntax của các dòng lẻ không nằm trong Function Block
        /// </summary>
        /// <param name="convertLine"></param>
        public static void ConvertSingleLineSQlServeRules(ConvertResult convertLine)
        {
            foreach (RuleModel rule in DBRules)
            {
                if (Regex.IsMatch(convertLine.After, rule.Find, RegexOptions.IgnoreCase))
                {
                    if (!string.IsNullOrEmpty(rule.WarningMsgId)) Common.AddMessageID(convertLine, rule.WarningMsgId);

                    if (rule.TodoFlg)
                    {
                        convertLine.MessageIDs.Add(Constant.TodoMsgId);
                        continue;
                    }
                    //Remove phần comment đi
                    string commentPart = String.Empty;
                    string targetStringRemovedComment = convertLine.After;
                    if (Regex.IsMatch(convertLine.After, @"\s+'.*"))
                    {
                        commentPart = Regex.Match(targetStringRemovedComment, @"\s+'.*").Value;
                        targetStringRemovedComment = Regex.Replace(targetStringRemovedComment, @"\s+'.*", "");
                        Match match = Regex.Match(targetStringRemovedComment, rule.Find, RegexOptions.IgnoreCase);
                        //trong trường hợp sau khi remove phần comment đi và không còn thõa mãn pattern nữa thì return;
                        if (!match.Success)
                        {
                            continue;
                        }
                    }
                    if (rule.Find.Equals(Constant.SQLServerDbConnection))
                    {
                        isDbConnection = true;
                    }
                    convertLine.After = $"{Regex.Replace(targetStringRemovedComment, rule.Find, rule.Replace, RegexOptions.IgnoreCase)}\t{commentPart}";
                    // Replace các dòng breakline, tab
                    convertLine.After = convertLine.After.Replace("\\n", "\n").Replace("\\t", "\t");
                    convertLine.Result = true;
                }
            }
        }

        /// <summary>
        /// Convert Syntax của dòng thuộc functionBlock
        /// </summary>
        /// <param name="convertLine"></param>
        /// <param name="functionBlock"></param>
        public static void ConvertBlockFuncVb(ConvertResult convertLine, List<ConvertResult> functionBlock)
        {
            foreach (RuleModel rule in DBRules)
            {
                Regex regex = new Regex(rule.Find, RegexOptions.IgnoreCase);
                if (regex.IsMatch(convertLine.After))
                {
                    if (!string.IsNullOrEmpty(rule.WarningMsgId)) Common.AddMessageID(convertLine, rule.WarningMsgId);

                    if (rule.TodoFlg)
                    {
                        Common.AddMessageID(convertLine, Constant.TodoMsgId);
                        continue;
                    }
                    // add warning message
                    if (!String.IsNullOrEmpty(rule.WarningMsgId))
                    {
                        Common.AddMessageID(convertLine, rule.WarningMsgId);
                    }

                    if (!rule.Replace.Equals(Constant.NOT_REPLACE, StringComparison.OrdinalIgnoreCase))
                    {
                        string commentPart = string.Empty;
                        string targetStringRemovedComment = string.Empty;
                        bool isSuccess = true;
                        Common.SplitStringByCommand(convertLine.After, rule.Find, ref commentPart, ref targetStringRemovedComment, ref isSuccess);
                        // Nếu có lỗi thì continue;
                        if (!isSuccess) continue;

                        if (rule.Find.Equals(Constant.DoUntil))
                        {
                            // Enable is do until flag
                            isDoUntil = true;
                        }
                        //if Do Until then Convert to For each and loop to Next
                        if (rule.Find.Equals(@"Loop"))
                        {
                            if (isDoUntil)
                            {
                                isDoUntil = false;
                                isForInDoUntil = false;
                            }
                            else
                            {
                                continue;
                            }
                        }
                        String ruleReplace = rule.Replace;
                        // PATTERN
                        if (isDoUntil && rule.ID == 10)
                        {
                            isForInDoUntil = true;
                            ruleReplace = "For Each $1 In Row.Table.Columns";
                        }
                        // PATTERN For\sEach\s(\w*)\sIn\s(\w*)\.Fields
                        if (isForInDoUntil && rule.ID == 15)
                        {
                            ruleReplace = "Row(Fld.ColumnName)";
                        }
                        // PATTERN (\w*)\.Fields\(("(\w*)")\)\.Value
                        if (isDoUntil && rule.ID == 35)
                        {
                            ruleReplace = "Row($2)";
                        }
                        convertLine.After = $"{Regex.Replace(targetStringRemovedComment, rule.Find, ruleReplace, RegexOptions.IgnoreCase)}\t{commentPart}";
                        // Replace các dòng breakline, tab
                        convertLine.After = convertLine.After.Replace("\\n", "\n").Replace("\\t", "\t");
                        convertLine.Result = true;
                    }
                    
                }
            }
        }

        /// <summary>
        /// Thêm các function liên quan db vào file db_tool
        /// </summary>
        /// <param name="fileContent"></param>
        public static void CreateContent(ref List<string> fileContent)
        {
            
            if (isDbConnection)
            {
                // list string for add new content
                var listAdd = new List<string>();
                listAdd = new List<string>()
                {
                    Common.getADDComment(string.Empty),
                    "Imports System.Data.Common",
                    Common.getCommentEnd(string.Empty)
                };
                //Add import Imports System.Data.Common
                fileContent.InsertRange(2, listAdd);
 
                //find CLOSEDB function and add content
                int index = fileContent.FindIndex(a => a.Contains("Public Sub CLOSEDB"));
                listAdd = new List<string>()
                {
                    Common.getADDComment("\t\t"),
                   "\t\tSYKTranaction = Nothing",
                   "\t\tSYKCommand = Nothing",
                    Common.getCommentEnd("\t\t")
                };
                if (index != -1)
                {
                    fileContent.InsertRange(index + 4, listAdd);
                }
                
                //find ODBC_Check Function and update 
                index = fileContent.FindIndex(a => a.Contains("Public Function ODBC_Check"));
                listAdd = new List<string>()
                {
                    Common.getADDComment("\t\t"),
                    "\t\tIf CheckDsn(Microsoft.Win32.Registry.CurrentUser, DNSName) OrElse CheckDsn(Microsoft.Win32.Registry.LocalMachine, DNSName) Then",
                    "\t\t\tODBC_Check = True",
                    "\t\t\tExit Function",
                    "\t\tEnd If",
                    "\t\tODBC_Check = False",
                    Common.getCommentEnd("\t\t")
                };
                if (index != -1)
                {
                    for (int i = index + 1; i <= fileContent.Count - 1; i++)
                    {
                        //if line is end function then add check Dsn
                        if (fileContent[i].Replace("\t", string.Empty).Equals("End Function"))
                        {
                            fileContent.InsertRange(i - 1, listAdd);
                            break;
                        }
                        // Comment line in function if not empty line
                        if (!String.IsNullOrEmpty(fileContent[i].Replace("\t", string.Empty)))
                        {
                            fileContent[i] = "'" + fileContent[i];
                        }
                    }
                }
                
                string endContent = fileContent[fileContent.Count - 1];
                fileContent.RemoveAt(fileContent.Count - 1);

                fileContent.Add(Common.getADDComment());
                fileContent.Add(String.Empty);
                // Add function Rsopen
                fileContent.Add("\t'**********************************************************************");
                fileContent.Add("\t' サブルーチン名               RsOpen");
                fileContent.Add("\t'-------------------------------------------------------------------------------");
                fileContent.Add("\t' 用途   リモートＤＢレコードセット取得ＳＱＬ発効                                 ");
                fileContent.Add("\t' 説明   モジュールグローバルなDatabaseオブジェクト変数にセットされている          ");
                fileContent.Add("\t' 　　   データベースにＳＱＬ文を発効しその結果のレコードセットを返す          ");
                fileContent.Add("\t' 引数   :sSql,I,String,実行するＳＱＬ文                                   ");
                fileContent.Add("\t' 戻値   レコードセット                                                    ");
                fileContent.Add("\t'**********************************************************************");
                fileContent.Add("\tPublic Function RsOpen(ByVal sSQL As String) As DataTable");
                fileContent.Add("\t\tDim dt As New DataTable");
                fileContent.Add("\t\tIf SYKDB.State = ConnectionState.Closed Then SYKDB.Open()");
                fileContent.Add("\t\tSYKCommand.CommandText = sSQL");
                fileContent.Add("\t\tdt.Load(SYKCommand.ExecuteReader())");
                fileContent.Add("\t\tRsOpen = dt");
                fileContent.Add(String.Empty);
                fileContent.Add(END_FUNC);
                // Add Sub ExecSQL
                fileContent.Add("\t'**********************************************************************");
                fileContent.Add("\t' サブルーチン名               ExecSQL");
                fileContent.Add("\t'-------------------------------------------------------------------------------");
                fileContent.Add("\t' 用途   リモートＤＢデータ操作ＳＱＬ発効                                 ");
                fileContent.Add("\t' 説明   モジュールグローバルなDatabaseオブジェクト変数にセットされている         ");
                fileContent.Add("\t' 　　   データベースにＳＱＬ文を発効する         ");
                fileContent.Add("\t' 引数   :sSql,I,String,実行するＳＱＬ文                                              ");
                fileContent.Add("\t'**********************************************************************");
                fileContent.Add("\tPublic Sub ExecSQL(ByVal sSQL As String)");
                fileContent.Add("\t\tIf SYKDB.State = ConnectionState.Closed Then SYKDB.Open()");
                fileContent.Add("\t\tSYKCommand.CommandText = sSQL");
                fileContent.Add("\t\tSYKCommand.ExecuteNonQuery()");
                fileContent.Add(String.Empty);
                fileContent.Add(END_SUB);
                // Add Sub BeginTrans
                fileContent.Add("\t'トランザクション開始                                              ");
                fileContent.Add("\tPublic Sub BeginTrans()");
                fileContent.Add("\t\tIf SYKDB.State = ConnectionState.Closed Then SYKDB.Open()");
                fileContent.Add("\t\t\tSYKTranaction = SYKDB.BeginTransaction()");
                fileContent.Add("\t\tSYKCommand.Transaction = SYKTranaction");
                fileContent.Add(String.Empty);
                fileContent.Add(END_SUB);
                // Add Sub RollBack
                fileContent.Add("\t'ロールバック                                             ");
                fileContent.Add("\t'**********************************************************************");
                fileContent.Add("\tPublic Sub RollBack()");
                fileContent.Add("\t\tIf SYKTranaction IsNot Nothing Then");
                fileContent.Add("\t\tSYKTranaction.Rollback()");
                fileContent.Add("\t\tEnd If");
                fileContent.Add("\t\tSYKDB.Close()");
                fileContent.Add(String.Empty);
                fileContent.Add(END_SUB);
                // Add Sub CommitTransaction
                fileContent.Add("\t'コミット                                            ");
                fileContent.Add("\tPublic Sub CommitTransaction()");
                fileContent.Add("\t\tSYKTranaction.Commit()");
                fileContent.Add("\t\tSYKDB.Close()");
                fileContent.Add(String.Empty);
                fileContent.Add(END_SUB);
                // Add Function Check Dsn
                fileContent.Add("\t'Check Dsn");
                fileContent.Add("\tPrivate Function CheckDsn(ByVal rootKey As Microsoft.Win32.RegistryKey, ByVal DNSName As String) As Boolean");
                fileContent.Add("\t\tDim regKey As Microsoft.Win32.RegistryKey = rootKey.OpenSubKey(\"Software\\ODBC\\ODBC.INI\\ODBC Data Sources\") 'TODO: Please check this path");
                fileContent.Add(String.Empty);
                fileContent.Add("\t\tIf regKey IsNot Nothing Then");
                fileContent.Add(String.Empty);
                fileContent.Add("\t\t\tFor Each name As String In regKey.GetValueNames()");
                fileContent.Add("\t\t\t\tDim value As String = regKey.GetValue(name,\"\").ToString()");
                fileContent.Add("\t\t\t\tIf Trim(name) = Trim(DNSName) Then");
                fileContent.Add("\t\t\t\t\tCheckDsn = True");
                fileContent.Add("\t\t\t\t\tExit Function");
                fileContent.Add("\t\t\t\tEnd If");
                fileContent.Add("\t\t\tNext");
                fileContent.Add("\t\tEnd If");
                fileContent.Add("\t\tCheckDsn = False");
                fileContent.Add(END_FUNC);

                fileContent.Add(Common.getCommentEnd());
                fileContent.Add(endContent);
                isDbConnection = false; 
            }
        }
    }
}
