﻿using AIT.Convert.Const;
using AIT.Convert.Model;
using AIT.Convert.Utils;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace AIT.Convert.Converter
{
    public static class DesignConverter
    {
        public static List<RuleModel> DesignRules = new List<RuleModel>();
        public static List<DesignConvertModel> ArrayConvert = new List<DesignConvertModel>();
        private static bool IsImportGrape = false;
        private static List<string> ListPropertiesComment = new List<string>();
        private const int ID_SETINDEX = 9999;
        /// <summary>
        /// Convert file design
        /// </summary>
        /// <param name="file"></param>
        /// <returns></returns>
        internal static List<ConvertResult> ConvertFile(FileInfo file)
        {
            ArrayConvert = new List<DesignConvertModel>();
            ResetProperties();
            try
            {
                List<ConvertResult> convertedContent = new List<ConvertResult>();
                using (StreamReader sr = new StreamReader(file.FullName, Encoding.GetEncoding(932)))
                {
                    string line = string.Empty;
                    while ((line = sr.ReadLine()) != null)
                    {
                        ConvertResult convertLine = new ConvertResult(line);
                        foreach (RuleModel rule in DesignRules)
                        {
                            Regex regex = new Regex(rule.Find, RegexOptions.IgnoreCase);
                            if (regex.IsMatch(convertLine.After))
                            {
                                if (string.IsNullOrEmpty(rule.WarningMsgId)) Common.AddMessageID(convertLine, rule.WarningMsgId);

                                if (rule.TodoFlg)
                                {
                                    Common.AddMessageID(convertLine, Constant.TodoMsgId);
                                    continue;
                                }

                                if (!rule.Replace.Equals(Constant.NOT_REPLACE, StringComparison.OrdinalIgnoreCase))
                                {
                                    //Remove phần comment đi
                                    string commentPart = string.Empty;
                                    string targetStringRemovedComment = string.Empty;
                                    bool isSuccess = true;
                                    Common.SplitStringByCommand(convertLine.After, rule.Find, ref commentPart, ref targetStringRemovedComment, ref isSuccess);
                                    //trong trường hợp sau khi remove phần comment đi và không còn thõa mãn pattern nữa thì return;
                                    if (!isSuccess) continue;

                                    convertLine.After = $"{Regex.Replace(targetStringRemovedComment, rule.Find, rule.Replace, RegexOptions.IgnoreCase)}\t{commentPart}";
                                    convertLine.Result = true;
                                    if(rule.ID <= 50) // Áp dụng cho các rule có Id < 50 (các rule convert Array)
                                    {
                                        var arrayTemp = convertLine.Before.Split(' ');
                                        if(arrayTemp.Length >= 4)
                                        {
                                            ArrayConvert.Add(new DesignConvertModel(arrayTemp[2]));
                                        }
                                    }

                                    if (rule.ID >= 20) IsImportGrape = true;
                                } else
                                {
                                    if (rule.ID == ID_SETINDEX) // Xử lý cho trường hợp SetIndex của Array
                                    {
                                        var arrayTemp = convertLine.After.Split('.');
                                        if(arrayTemp.Length >= 3)
                                        {
                                            if (ArrayConvert.Any(a => a.Key == arrayTemp[1]))
                                            {
                                                var inforArr = arrayTemp[2].Remove(arrayTemp[2].Length - 1).Remove(0, 9).Split(',');
                                                DesignArr DesignArr = new DesignArr();
                                                if (inforArr.Length >2)
                                                {
                                                    DesignArr.Name = inforArr[0].Trim();
                                                    DesignArr.Index = inforArr[1].Trim().Remove(0,6);
                                                } 
                                                else if(inforArr.Length == 2)
                                                {
                                                    DesignArr.Name = inforArr[0].Trim();
                                                    DesignArr.Index = inforArr[1].Trim();
                                                } 
                                                else
                                                {
                                                    continue;
                                                }
                                                ArrayConvert.Where(a => a.Key == arrayTemp[1]).FirstOrDefault().Arrs.Add(DesignArr);

                                                // Comment hàng
                                                convertLine.After = Common.InsertBlockDELComment(convertLine.Before);
                                                convertLine.Before = convertLine.After;
                                                convertLine.Result = false;
                                            }
                                        }
                                    } 
                                    else
                                    {
                                        if (rule.ID < 55)
                                        {
                                            var addProp = convertLine.After.Trim().Split(' ')[2];
                                            if (!ListPropertiesComment.Contains(addProp))
                                                ListPropertiesComment.Add(addProp);
                                        }
                                        // Comment hàng
                                        convertLine.After = Common.InsertBlockDELComment(convertLine.Before);
                                        convertLine.Before = convertLine.After;
                                        convertLine.Result = false;
                                    }
                                }
                            }
                        }
                        
                        if(ListPropertiesComment.Any(a => convertLine.After.Contains(a)) && !Common.IsComment(convertLine.After))
                        {
                            // Comment hàng
                            convertLine.After = Common.InsertBlockDELComment(convertLine.Before);
                            convertLine.Before = convertLine.After;
                            convertLine.Result = false;
                        }
                        
                        convertedContent.Add(convertLine);
                    }
                }
                return convertedContent;
            }
            catch
            {
                return new List<ConvertResult>();
            }
        }
        /// <summary>
        /// Chỉnh sửa nội dung thông qua các properties đã được gán ở function ConvertFile
        /// </summary>
        /// <param name="fileContent"></param>
        internal static void CreateContent(ref List<string> fileContent)
        {
            if (ArrayConvert.Count == 0) return;

            var listContentAdd = new List<string>
            {
                Common.getADDComment("\t\t")
            };
            // Xử lý chuyển đổi từ .SetIndex thành Insert bằng ArrayList
            foreach (DesignConvertModel item in ArrayConvert)
            {
                if(item.Arrs.Count > 0)
                {
                    // Lấy tên của phần tử đầu, sau đó đem tìm kiếm kiểu dữ liệu mà phần tử đó được khai báo
                    var itemNameFirst = item.Arrs.FirstOrDefault().Name;
                    var maxIndex = item.Arrs.Max(a => Int32.Parse(a.Index));
                    var itemTemp = fileContent.Where(a => Regex.IsMatch(a, Constant.ConvertDesign.PROP_CTRS + itemNameFirst) && !Common.IsComment(a)).FirstOrDefault();
                    if (string.IsNullOrEmpty(itemTemp)) 
                        continue;

                    var typeItem = itemTemp.Split(' ');
                    if(typeItem.Length >= 5) // Nếu xác định được kiểu dữ liệu của biến thì tạo arraylist theo kiểu dữ liệu đó
                    {
                        listContentAdd.Add("\t\t" + item.Key + $" = New ArrayList(New " + typeItem[4] + "(" + maxIndex + ") {})");
                    }
                    else // Ngược lại thì tạo arraylist theo kiểu dữ liệu chung là Object
                    {
                        listContentAdd.Add("\t\t" + item.Key + $" = New ArrayList(New Object(" + maxIndex + ") {})");
                    }
                    
                    foreach (DesignArr element in item.Arrs)
                    {
                        listContentAdd.Add("\t\t" + item.Key + $"({element.Index}) = {element.Name}");
                    }
                    listContentAdd.Add(string.Empty);
                }
                else // Trường hợp không có đối tượng con
                {
                    listContentAdd.Add("\t\t" + item.Key + " = New ArrayList())");
                    listContentAdd.Add(string.Empty);
                }
            }

            listContentAdd.Add(Common.getCommentEnd("\t\t"));
            var fileCount = fileContent.Count();
            var functionNew = fileContent.Where(a => Regex.IsMatch(a, Constant.ConvertDesign.LAYOUT_CTRS)).FirstOrDefault();
            if (string.IsNullOrEmpty(functionNew)) return;
            // Add thêm import nếu có đối tượng thuộc Grape InputMan
            if (IsImportGrape) fileContent.InsertRange(0, new List<string> { Common.getADDComment(string.Empty), "Imports GrapeCity.Win.Editors", Common.getCommentEnd(string.Empty) });

            var indexFunctionNew = fileContent.IndexOf(functionNew);
            // Xử lý add nội dung đã chuyển đổi từ .SetIndex thành Insert bằng ArrayList
            for (var i = indexFunctionNew; i <= fileCount; i++)
            {
                if(Regex.IsMatch(fileContent.ElementAt(i), Constant.ConvertDesign.LAYOUT_CTRS_END))
                {
                    fileContent.InsertRange(i, listContentAdd);
                    break;
                }
            }
            
        }

        private static void ResetProperties()
        {
            IsImportGrape = false;
            ListPropertiesComment = new List<string>();
        }
    }
}
