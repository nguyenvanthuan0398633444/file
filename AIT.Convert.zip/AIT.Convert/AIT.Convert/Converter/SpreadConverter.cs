﻿using AIT.Convert.Const;
using AIT.Convert.Model;
using AIT.Convert.Utils;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;

namespace AIT.Convert.Converter
{
    public static class SpreadConverter
    {
        public static List<RuleModel> SpreadRules = new List<RuleModel>();
        public static List<FileInfo> DesignFiles = new List<FileInfo>();

        /// <summary>
        /// Kiểm tra nếu File Designer tương ứng có phát hiện sử dụng Spread
        /// </summary>
        /// <param name="fileName"></param>
        /// <returns></returns>
        public static bool CheckHasSpread(FileInfo designFile)
        {
                Regex spreadConfirmPattern = new Regex(@"(\w*)\s=\sNew\sFarPoint\.Win\.Spread\.*$");
                Regex spreadConfirmPattern2 = new Regex(@"(\w*)\s=\sNew\sAxFPSpread\.AxvaSpread\.*$");
                using (StreamReader sr = designFile.OpenText())
                {
                    string dline = "";
                    while ((dline = sr.ReadLine()) != null)
                    {
                        if (spreadConfirmPattern.IsMatch(dline) || spreadConfirmPattern2.IsMatch(dline))
                        {
                            return true;
                        }
                    }
                }
            return false;
        }

        /// <summary>
        /// Thực hiện convert Spread
        /// </summary>
        /// <param name="convertLine"></param>
        public static void ConvertSpread(ConvertResult convertLine)
        {
            foreach (RuleModel rule in SpreadRules)
            {
                //  Regex spreadRuleRegex = new Regex($@"\.{rule.Find}", RegexOptions.IgnoreCase);
                Regex spreadRuleRegex = new Regex(rule.Find, RegexOptions.IgnoreCase);
                if (spreadRuleRegex.IsMatch(convertLine.After))
                {
                    if (!string.IsNullOrEmpty(rule.WarningMsgId)) Common.AddMessageID(convertLine, rule.WarningMsgId);

                    if (rule.TodoFlg)
                    {
                        Common.AddMessageID(convertLine, Constant.TodoMsgId);
                        continue;
                    }

                    if (!rule.Replace.Contains(Constant.NOT_REPLACE))
                    {
                        convertLine.After = spreadRuleRegex.Replace(convertLine.After, rule.Replace);
                        convertLine.Result = true;
                    }

                    if (rule.Replace.Contains(Constant.DELETE))
                    {
                        convertLine.Before = Delete(convertLine.After);
                        convertLine.After = convertLine.Before;
                        convertLine.Result = true;
                    }
                    convertLine.After = convertLine.After.Replace("\\n", "\n").Replace("\\t", "\t");
                }
            }
        }
        /// <summary>
        /// xóa các dòng
        /// </summary>
        /// <param name="fileContent"></param>
        public static string Delete(string line)
        {
            string tabIndent = Regex.Match(line, @"^\s*").Value;
            return $"{tabIndent}'{line.Trim()}";

        }
        /// <summary>
        /// Thêm các function phục vụ cho Spread
        /// </summary>
        /// <param name="fileContent"></param>
        public static void CreateContent(ref List<string> fileContent)
        {
            var listImport = new List<string>();
            for (int i = 0; i < fileContent.Count - 1; i++)
            {

            }
        }
        /// <summary>
        /// Reset properties of SpreadConverter
        /// </summary>
    }
}
