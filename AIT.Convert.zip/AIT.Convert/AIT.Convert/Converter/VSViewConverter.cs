﻿using System;
using AIT.Convert.Const;
using AIT.Convert.Model;
using AIT.Convert.Utils;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using AIT.Convert.Content;

namespace AIT.Convert.Converter
{
    public static class VSViewConverter
    {
        public static List<RuleModel> VSViewRules = new List<RuleModel>();
        public static List<RuleModel> ViewToolRules = new List<RuleModel>();

        private static bool isHasFncPrint_First = false;
        private static bool isHasFncPRN_XGet = false;
        private static bool isHasFncPRN_XGet_mm = false;
        private static bool isHasFncPRN_END = false;
        private static bool isHasPR_WK_Structure = false;

        private static bool isPaperKind = false;
        private static bool isDashStyle = false;
        private static bool isOrientationEnum = false;

        private static string vsPrinterName = string.Empty;
        private static string afterGoSub = string.Empty;
        /// <summary>
        /// Convert Syntax của các dòng lẻ không nằm trong Function Block
        /// </summary>
        /// <param name="convertLine"></param>
        public static void ConvertSingleLineVsViewRules(ConvertResult convertLine)
        {
            foreach (RuleModel rule in VSViewRules)
            {
                if (Regex.IsMatch(convertLine.After, rule.Find, RegexOptions.IgnoreCase))
                {
                    if (!string.IsNullOrEmpty(rule.WarningMsgId)) Common.AddMessageID(convertLine, rule.WarningMsgId);

                    if (rule.TodoFlg)
                    {
                        convertLine.MessageIDs.Add(Constant.TodoMsgId);
                        continue;
                    }
                    //Tách phần comment và phần code(nội dung) ra. Phân cách = dấu \'
                    string commentPart = string.Empty;
                    string targetStringRemovedComment = string.Empty;
                    bool isSuccess = true;
                    Common.SplitStringByCommand(convertLine.After, rule.Find, ref commentPart, ref targetStringRemovedComment, ref isSuccess);
                    //trong trường hợp sau khi remove phần comment đi và không còn thõa mãn pattern nữa thì return;
                    if (!isSuccess) continue;

                    convertLine.After = $"{Regex.Replace(targetStringRemovedComment, rule.Find, rule.Replace, RegexOptions.IgnoreCase)}\t{commentPart}";
                    // Lấy tên của máy Printer được khai báo
                    if(rule.ID == 6)
                    {
                        vsPrinterName = targetStringRemovedComment.Split(' ')[1];
                    }
                    convertLine.After = convertLine.After.Replace("\\n", "\n").Replace("\\t", "\t");
                    convertLine.Result = true;
                }
            }
        }

        /// <summary>
        /// Convert Syntax của dòng thuộc functionBlock
        /// </summary>
        /// <param name="convertLine"></param>
        /// <param name="functionBlock"></param>
        public static void ConvertBlockFuncVb(ConvertResult convertLine, List<ConvertResult> functionBlock)
        {
            foreach (RuleModel rule in VSViewRules)
            {
                if (Regex.IsMatch(convertLine.After, rule.Find, RegexOptions.IgnoreCase))
                {
                    if (!string.IsNullOrEmpty(rule.WarningMsgId)) Common.AddMessageID(convertLine, rule.WarningMsgId);

                    if (rule.TodoFlg)
                    {
                        Common.AddMessageID(convertLine, Constant.TodoMsgId);
                        continue;
                    }

                    if (rule.SubRuleIdList.Any()) SubRuleConverter.ConvertSubRule(rule, convertLine, functionBlock);

                    if (!rule.Replace.Equals(Constant.NOT_REPLACE, StringComparison.OrdinalIgnoreCase))
                    {
                        //Tách phần comment và phần code(nội dung) ra. Phân cách = dấu \'
                        string commentPart = string.Empty;
                        string targetStringRemovedComment = string.Empty;
                        bool isSuccess = true;
                        Common.SplitStringByCommand(convertLine.After, rule.Find, ref commentPart, ref targetStringRemovedComment, ref isSuccess);
                        // Nếu có lỗi thì continue;
                        if (!isSuccess) continue;

                        convertLine.After = $"{Regex.Replace(targetStringRemovedComment, rule.Find, rule.Replace, RegexOptions.IgnoreCase)}\t{commentPart}";
                        convertLine.Result = true;
                    }

                    if (rule.ID == 20 || rule.ID == 16) isPaperKind = true;
                    if (rule.ID == 19 || rule.ID == 1 || rule.ID == 12 || rule.ID == 13) isDashStyle = true;
                    if (rule.ID == 4 || rule.ID == 18) isOrientationEnum = true;
                    if (rule.ID == 27)
                    {
                        string[] GoSub = convertLine.After.Split(' ');
                        afterGoSub = GoSub[GoSub.Length - 1];
                    }
                    convertLine.After = convertLine.After.Replace("\\n", "\n").Replace("\\t", "\t");
                }
            }
        }

        /// <summary>
        /// Kiểm tra các function trong file ViewTool
        /// </summary>
        /// <param name="convertLine"></param>
        /// <param name="functionBlock"></param>
        /// <param name="filename"></param>
        public static void CheckViewToolFunction(ConvertResult convertLine, List<ConvertResult> functionBlock, string filename)
        {
            if (filename.ToLower() == Constant.ConvertVsView.VIEWTOOL)
            {
                var ruleFncViewTool = ViewToolRules.Where(a => a.ID < 100).ToList();
                foreach (RuleModel rule in ruleFncViewTool)
                {
                    if (Regex.IsMatch(convertLine.After, rule.Find, RegexOptions.IgnoreCase))
                    {
                        ConvertBlockFuncViewTool(functionBlock, rule);
                        return;
                    }
                }
            }
                
        }

        /// <summary>
        /// Xử lý convert viewtool.vb
        /// </summary>
        /// <param name="convertLine"></param>
        /// <param name="functionBlock"></param>
        /// <param name="rule"></param>
        private static void ConvertBlockFuncViewTool(List<ConvertResult> functionBlock, RuleModel rule)
        {
            var ruleChanges = ViewToolRules.Where(a => a.ID >= 100).ToList();
            string commentPart = string.Empty;
            string targetStringRemovedComment = string.Empty;
            bool isSuccess = true;
            var printNameTemp = string.IsNullOrEmpty(vsPrinterName) ? "PRN" : vsPrinterName;
            switch (rule.ID) {
                case 1: // Xử lý hàm Print_Set
                    // Lấy tên của Printer được khai báo
                    var printerName = functionBlock.Where(a => a.Before.Contains(" As New Printer")).FirstOrDefault().After.Split(' ')[1];
                    Regex regex = new Regex("For(.*)To(.*).Count", RegexOptions.IgnoreCase);
                    var lineFor = functionBlock.Where(a => regex.IsMatch(a.Before)).FirstOrDefault();
                    var varFor = lineFor.After.Split(' ')[1];
                    // Xử lý vòng lặp for của hàm
                    if (Regex.IsMatch(lineFor.After, "For(.*)To(.*).Count", RegexOptions.IgnoreCase))
                    {
                        commentPart = Regex.Match(lineFor.After, @"\s+'.*").Value;
                        targetStringRemovedComment = Regex.Replace(lineFor.After, @"\s+'.*", "");
                        if (Regex.Match(targetStringRemovedComment, "For(.*)To(.*).Count", RegexOptions.IgnoreCase).Success)
                        {
                            lineFor.After = $"{Regex.Replace(targetStringRemovedComment, "For(.*)To(.*).Count", "For $1 To " +printerName+".Count", RegexOptions.IgnoreCase)}\t{commentPart}";
                            lineFor.Result = true;
                        }
                    }
                    var convertPrinter = functionBlock.Where(a => a.Before.Contains($"Printers({varFor}).DeviceName")).ToList();
                    foreach (var cvPrinter in convertPrinter)
                    {
                        cvPrinter.After = cvPrinter.After.Replace($"Printers({varFor}).DeviceName", $"{printerName}.Item({varFor})");
                        cvPrinter.Result = true;
                    }

                    var convertPrinterName = functionBlock.Where(a => a.Before.Contains($"{printerName} = Printers({varFor})")).ToList();
                    foreach (var cvPrinter in convertPrinterName)
                    {   
                        // Xác nhận lại tên của FlexViewer trong file viewform
                        if(Regex.IsMatch(cvPrinter.After, $"{printerName} =", RegexOptions.IgnoreCase))
                        {
                            cvPrinter.After = cvPrinter.After.Replace($"{printerName} =", $"ViewForm.C1FlexViewer1.PageSettings.PrinterSettings.PrinterName =")
                            .Replace($"Printers({varFor})", $"{printerName}.Item({varFor})");
                            cvPrinter.After = $"\t\t\'\\\\ TODO: Confirm name \"C1FlexViewer1\" of ViewForm \n{cvPrinter.After}";
                            cvPrinter.Result = true;
                        }
                    }

                    var indexIsWindownsNT = functionBlock.IndexOf(functionBlock.Where(a => a.Before.Contains("isWindowsNT")).FirstOrDefault());
                    // Comment lại phần check isWindowsNT
                    do
                    {
                        functionBlock.ElementAt(indexIsWindownsNT).After = "'" + functionBlock.ElementAt(indexIsWindownsNT).After;
                        functionBlock.ElementAt(indexIsWindownsNT).Result = true;
                    } while (!functionBlock.ElementAt(indexIsWindownsNT++).After.Contains("End If"));

                    var contentComment = functionBlock.Where(a => Regex.IsMatch(a.After,@"ViewForm\.([\w\d]*)\.Device", RegexOptions.IgnoreCase)).ToList();
                    foreach (var cvPrinter in contentComment)
                    {
                        cvPrinter.After = "'" + cvPrinter.After.Trim();
                        cvPrinter.Result = true;
                    }
                    break;
                case 2:  // Xử lý hàm  PRN_FontGet_mm ,PRN_FontGet, PRN_FontGetHeight và PRN_FontGetHeight_mm
                    var convertFontsize = functionBlock.Where(a => a.Before.Contains($"{printNameTemp}.FontSize")).ToList();
                    foreach (var cvFontsize in convertFontsize)
                    {
                        cvFontsize.After = cvFontsize.After.Replace($"{printNameTemp}.FontSize", $"{printNameTemp}.Font.Size");
                        cvFontsize.Result = true;
                    }
                    break;
                case 3: // Xử lý hàm  PRN_XGet
                case 4: // Xử lý hàm  PRN_XGet_mm
                case 5: // Xử lý hàm  PRN_First
                case 6: // Xử lý hàm  PRN_END
                    if(isHasPR_WK_Structure || rule.ID >= 5) { 
                        foreach (var convert in functionBlock)
                        {
                            string tabIndent = Common.GetTabIndex(convert.Before);
                            convert.After = $"{ tabIndent}'{convert.Before.Trim()}";
                            convert.Before = convert.After;
                            convert.Result = false;
                        }
                    }
                    if (rule.ID == 3 && isHasPR_WK_Structure)
                    {
                        isHasFncPRN_XGet = true;
                    }
                    else if (rule.ID == 4 && isHasPR_WK_Structure)
                    {
                        isHasFncPRN_XGet_mm = true;
                    }
                    else if (rule.ID == 5)
                    {
                        isHasFncPrint_First = true;
                    }
                    else if (rule.ID == 6)
                    {
                        isHasFncPRN_END = true;
                    }

                    break;
                case 7:
                    isHasPR_WK_Structure = true;
                    break;
                case 8: // Xử lý hàm PRN_LINE
                case 9: // Xử lý hàm PRN_LINE_mm
                case 10:// Xử lý hàm PRN_DATA
                case 11:// Xử lý hàm PRN_DATA_mm
                    var firstLine = functionBlock.ElementAt(1);
                    var shapeName = string.Empty;
                    var shapeObj = string.Empty;
                    // nếu PRN_DATA thì khai báo textField
                    if (rule.ID >= 10)
                    {
                        shapeName = "textField";
                        shapeObj = "TextField";
                    }
                    else // nếu PRN_LINE thì khai báo shapeField
                    {
                        shapeName = "shapeField";
                        shapeObj = "ShapeField";
                    }
                    // Khai báo đối tượng
                    if (string.IsNullOrEmpty(firstLine.After.Trim())) {
                        firstLine.After = Common.InsertBlockADDComment($"\t\tDim {shapeName} As New {shapeObj}()");
                    } else
                    {
                        firstLine.After = Common.InsertBlockADDComment($"\t\tDim {shapeName} As New {shapeObj}()") + $"\n{firstLine.Before}";
                    }
                    firstLine.Before = firstLine.After;
                    firstLine.Result = false;
                    foreach (ConvertResult convertLine in functionBlock)
                    {
                        if (convertLine.Equals(functionBlock.First())) continue;
                        if (convertLine.IsNotCode) continue;

                        if (Regex.IsMatch(convertLine.After,@"\s"+printNameTemp+ @"\.\w*", RegexOptions.IgnoreCase))
                        {
                            //Remove phần comment đi
                            Common.SplitStringByCommand(convertLine.After, $"{printNameTemp}.", ref commentPart, ref targetStringRemovedComment, ref isSuccess);
                            //trong trường hợp sau khi remove phần comment đi và không còn thõa mãn pattern nữa thì return;
                            if (!isSuccess) continue;

                            convertLine.After = $"{Regex.Replace(targetStringRemovedComment, $"{printNameTemp}.", $"{shapeName}.", RegexOptions.IgnoreCase)}\t{commentPart}";
                            convertLine.Result = true;
                        }

                        // Xử lý theo rule ViewTool với ID > 100
                        foreach (RuleModel ruleChange in ruleChanges)
                        {
                            if (Regex.IsMatch(convertLine.After, ruleChange.Find,  RegexOptions.IgnoreCase))
                            {
                                if (!string.IsNullOrEmpty(ruleChange.WarningMsgId)) Common.AddMessageID(convertLine, ruleChange.WarningMsgId);

                                if (ruleChange.TodoFlg)
                                {
                                    Common.AddMessageID(convertLine, Constant.TodoMsgId);
                                    continue;
                                }
                                
                                //Remove phần comment đi
                                Common.SplitStringByCommand(convertLine.After, ruleChange.Find, ref commentPart, ref targetStringRemovedComment, ref isSuccess);
                                //trong trường hợp sau khi remove phần comment đi và không còn thõa mãn pattern nữa thì return;
                                if (!isSuccess) continue;
                                // Nếu rule.Replace không chứa NOT_REPLACE thì xử lý lặp như bình thường
                                if (!ruleChange.Replace.Contains(Constant.NOT_REPLACE))
                                {
                                    convertLine.After = $"{Regex.Replace(targetStringRemovedComment, ruleChange.Find, ruleChange.Replace, RegexOptions.IgnoreCase)}\t{commentPart}";
                                    convertLine.Result = true;
                                }
                                // Nếu rule.Replace chứa NOT_REPLACE thì xử lý lặp theo điều kiện của rule.Replace ( "NOT_REPLACE abcxyz" với abcxyz là điều kiện lặp cần xử lý đặc biệt)
                                else
                                {   
                                    if(ruleChange.Replace.Length > 11)
                                    {   // xử lý xóa NOT_REPLACE ở đầu chuỗi
                                        var replace = ruleChange.Replace.Remove(0, 11).Replace("$0", shapeName);
                                        convertLine.After = $"{Regex.Replace(targetStringRemovedComment, ruleChange.Find, replace, RegexOptions.IgnoreCase)}\t{commentPart}";
                                        convertLine.Result = true;
                                    } else {
                                        // Trường hợp không có thì comment lại
                                        convertLine.Before = Common.InsertBlockDELComment(convertLine.After);
                                        convertLine.After = convertLine.Before;
                                        convertLine.Result = false;
                                    }
                                }
                            }
                        }
                        if (Regex.IsMatch(convertLine.After, @"\sEnd\sSub", RegexOptions.IgnoreCase))
                        {
                            convertLine.After = $"\t\tsDetail.Fields.Add({shapeName}) {Common.getADDComment(string.Empty)}"  + $"\n{convertLine.After}";
                            convertLine.Before = convertLine.After;
                            convertLine.Result = false;
                        }
                    }
                    break;
                case 12: // Xử lý hàm PRN_BarCode
                    var nameBarCode = "barCodeField";
                    var hasDraw = functionBlock.Any(a => Regex.IsMatch(a.After, Constant.ConvertVsView.DRAW_PATTERN, RegexOptions.IgnoreCase));
                    foreach (var convertLine in functionBlock)
                    {
                        if (convertLine.IsNotCode) continue;
                        if (convertLine.Equals(functionBlock.First())) continue;

                        if (Regex.IsMatch(convertLine.After, Constant.ConvertVsView.DRAW_PATTERN, RegexOptions.IgnoreCase))
                        {
                            // Xử lý khai báo biến
                            var firstLineFnc = functionBlock.ElementAt(1);
                            if (string.IsNullOrEmpty(firstLineFnc.After.Trim()))
                            {
                                firstLineFnc.After = Common.InsertBlockADDComment($"\t\tDim {nameBarCode} As New BarCodeField()");
                            }
                            else
                            {
                                firstLineFnc.After = Common.InsertBlockADDComment($"\t\tDim {nameBarCode} As New BarCodeField()") + $"\n\t\t{firstLineFnc.Before}";
                            }
                            firstLineFnc.Before = firstLineFnc.After;
                            firstLineFnc.Result = false;
                            // Tìm vị trí của hàm DrawPicture (vẽ hình barcode)
                            var indexFunction = convertLine.After.IndexOf("DrawPicture");
                            var tempStr = convertLine.After.Remove(0, indexFunction + 12);
                            tempStr = tempStr.Remove(tempStr.Length - 1);
                            var agruments = tempStr.Split(',');
                            if (agruments.Length != 5)
                                return;
                            // Lấy giá trị được gán
                            var left = agruments[1].Trim();
                            var top = agruments[2].Trim();
                            var width = agruments[3].Trim();
                            var height = agruments[4].Trim();
                            convertLine.After = $"\t\t{nameBarCode}.Left = {left}\n\t\t{nameBarCode}.Top = {top}\n\t\t{nameBarCode}.Width = Math.Abs({width})\n\t\t{nameBarCode}.Height = Math.Abs({width})";
                            convertLine.Result = true;
                        }
                        else if (Regex.IsMatch(convertLine.After, $".Type = ", RegexOptions.IgnoreCase) && hasDraw)
                        {
                            // Lấy giá trị được gán
                            var valueBarcodeEnum = convertLine.After.Split('=')[1].Trim();
                            convertLine.After = $"\t\t{nameBarCode}.BarCode = {valueBarcodeEnum}";
                            convertLine.Result = true;
                        }
                        else if (Regex.IsMatch(convertLine.After, $".Value = ", RegexOptions.IgnoreCase) && hasDraw)
                        {
                            // Lấy giá trị được gán
                            var valueBar = convertLine.After.Split('=')[1].Trim();
                            convertLine.After = $"\t\t{nameBarCode}.Text = {valueBar}";
                            convertLine.Result = true;
                        }
                        else
                        {
                            var ruleBarcode = ruleChanges.Where(a => a.SubRuleIdList.Contains(12)).ToList();
                            foreach (RuleModel ruleChange in ruleBarcode)
                            {
                                if (Regex.IsMatch(convertLine.After, ruleChange.Find, RegexOptions.IgnoreCase))
                                {
                                    if (!string.IsNullOrEmpty(ruleChange.WarningMsgId)) Common.AddMessageID(convertLine, ruleChange.WarningMsgId);

                                    if (ruleChange.TodoFlg)
                                    {
                                        Common.AddMessageID(convertLine, Constant.TodoMsgId);
                                        continue;
                                    }

                                    //Remove phần comment đi
                                    Common.SplitStringByCommand(convertLine.After, ruleChange.Find, ref commentPart, ref targetStringRemovedComment, ref isSuccess);
                                    //trong trường hợp sau khi remove phần comment đi và không còn thõa mãn pattern nữa thì return;
                                    if (!isSuccess) continue;
                                    // Nếu rule.Replace không chứa NOT_REPLACE thì xử lý lặp như bình thường
                                    if (!ruleChange.Replace.Contains(Constant.NOT_REPLACE))
                                    {
                                        convertLine.After = $"{Regex.Replace(targetStringRemovedComment, ruleChange.Find, ruleChange.Replace, RegexOptions.IgnoreCase)}\t{commentPart}";
                                        convertLine.Result = true;
                                    }
                                    else // Comment lại
                                    {
                                        if (ruleChange.Replace.Length > 11 && ruleChange.SubRuleIdList.Any(a => a.Equals(12)))
                                        {   // xử lý xóa NOT_REPLACE ở đầu chuỗi
                                            var replace = ruleChange.Replace.Remove(0, 11).Replace("$0", nameBarCode);
                                            convertLine.After = $"{Regex.Replace(targetStringRemovedComment, ruleChange.Find, replace, RegexOptions.IgnoreCase)}\t{commentPart}";
                                            convertLine.Result = true;
                                        }
                                    }
                                }
                            }
                        }
                        // Add biến được xử lý phía trên cho sDetail
                        if (hasDraw && Regex.IsMatch(convertLine.After, @"\sEnd\sSub", RegexOptions.IgnoreCase))
                        {
                            convertLine.After =$"\t\tsDetail.Fields.Add({nameBarCode}) {Common.getADDComment(string.Empty)}" + $"\n{convertLine.After}";
                            convertLine.Before = convertLine.After;
                            convertLine.Result = false;
                        }
                    }
                    break;
                case 13: // Xử lý hàm PRN_Picture
                    var nameImage = "imgField";
                    var hasDrawImg = functionBlock.Any(a => Regex.IsMatch(a.After, Constant.ConvertVsView.DRAW_PATTERN, RegexOptions.IgnoreCase));
                    foreach (var convertLine in functionBlock)
                    {
                        if (convertLine.IsNotCode) continue;
                        if (convertLine.Equals(functionBlock.First())) continue;

                        if (Regex.IsMatch(convertLine.After, Constant.ConvertVsView.DRAW_PATTERN, RegexOptions.IgnoreCase))
                        {
                            var firstLineFnc = functionBlock.ElementAt(1);
                            if (string.IsNullOrEmpty(firstLineFnc.After.Trim()))
                            {
                                firstLineFnc.After = Common.InsertBlockADDComment($"\t\tDim {nameImage} As New ImageField()\n\t\t{nameImage}.PictureScale = PictureScaleEnum.Scale");
                            }
                            else
                            {
                                firstLineFnc.After = Common.InsertBlockADDComment($"\t\tDim {nameImage} As New ImageField()") + $"\n\t\t{firstLineFnc.Before}";
                            }
                            firstLineFnc.Before = firstLineFnc.After;
                            firstLineFnc.Result = false;
                            // Lấy vị trí của DrawPicture
                            var indexFunction = convertLine.After.IndexOf("DrawPicture");
                            var tempStr = convertLine.After.Remove(0, indexFunction + 12);
                            tempStr = tempStr.Remove(tempStr.Length - 1);
                            var agruments = tempStr.Split(',');
                            if (agruments.Length != 5)
                                return;
                            var imgData = agruments[0].Trim();
                            var left = agruments[1].Trim();
                            var top = agruments[2].Trim();
                            var width = agruments[3].Trim();
                            var height = agruments[4].Trim();
                            convertLine.After = $"\t\t{nameImage}.Picture = {imgData}\n\t\t{nameImage}.Left = {left}\n\t\t{nameImage}.Top = {top}\n\t\t{nameImage}.Width = Math.Abs({width})\n\t\t{nameImage}.Height = Math.Abs({width})";
                            convertLine.Result = true;
                        }
                        else
                        {
                            var rulePicture = ruleChanges.Where(a => a.SubRuleIdList.Contains(13)).ToList();
                            foreach (RuleModel ruleChange in rulePicture)
                            {
                                if (Regex.IsMatch(convertLine.After, ruleChange.Find, RegexOptions.IgnoreCase))
                                {
                                    if (!string.IsNullOrEmpty(ruleChange.WarningMsgId)) Common.AddMessageID(convertLine, ruleChange.WarningMsgId);

                                    if (ruleChange.TodoFlg)
                                    {
                                        Common.AddMessageID(convertLine, Constant.TodoMsgId);
                                        continue;
                                    }

                                    //Remove phần comment đi
                                    Common.SplitStringByCommand(convertLine.After, ruleChange.Find, ref commentPart, ref targetStringRemovedComment, ref isSuccess);
                                    //trong trường hợp sau khi remove phần comment đi và không còn thõa mãn pattern nữa thì return;
                                    if (!isSuccess) continue;
                                    // Nếu rule.Replace không chứa NOT_REPLACE thì xử lý lặp như bình thường
                                    if (!ruleChange.Replace.Contains(Constant.NOT_REPLACE))
                                    {
                                        convertLine.After = $"{Regex.Replace(targetStringRemovedComment, ruleChange.Find, ruleChange.Replace, RegexOptions.IgnoreCase)}\t{commentPart}";
                                        convertLine.Result = true;
                                    }
                                    else // Comment lại
                                    {
                                        if (ruleChange.Replace.Length > 11 && ruleChange.SubRuleIdList.Any(a => a.Equals(13)))
                                        {   // xử lý xóa NOT_REPLACE ở đầu chuỗi
                                            var replace = ruleChange.Replace.Remove(0, 11).Replace("$0", nameImage);
                                            convertLine.After = $"{Regex.Replace(targetStringRemovedComment, ruleChange.Find, replace, RegexOptions.IgnoreCase)}\t{commentPart}";
                                            convertLine.Result = true;
                                        }
                                    }
                                }
                            }
                        }
                        // Add biến được xử lý phía trên cho sDetail
                        if (hasDrawImg && Regex.IsMatch(convertLine.After, @"\sEnd\sSub", RegexOptions.IgnoreCase))
                        {
                            convertLine.After = $"\t\tsDetail.Fields.Add({nameImage}) {Common.getADDComment(string.Empty)}" + $"\n{convertLine.After}";
                            convertLine.Before = convertLine.After;
                            convertLine.Result = false;
                        }
                    }
                    break;
                default: // Các trường hợp khác
                    foreach (var convertLine in functionBlock)
                    {
                        if (convertLine.IsNotCode) continue;

                        foreach (RuleModel ruleChange in ruleChanges)
                        {
                            Regex reg = new Regex(ruleChange.Find, RegexOptions.IgnoreCase);
                            if (reg.IsMatch(convertLine.After))
                            {
                                if (!string.IsNullOrEmpty(ruleChange.WarningMsgId)) Common.AddMessageID(convertLine, ruleChange.WarningMsgId);

                                if (ruleChange.TodoFlg)
                                {
                                    Common.AddMessageID(convertLine, Constant.TodoMsgId);
                                    continue;
                                }

                                //Remove phần comment đi
                                Common.SplitStringByCommand(convertLine.After, ruleChange.Find, ref commentPart, ref targetStringRemovedComment, ref isSuccess);
                                //trong trường hợp sau khi remove phần comment đi và không còn thõa mãn pattern nữa thì return;
                                if (!isSuccess) continue;
                                // Nếu rule.Replace không chứa NOT_REPLACE thì xử lý lặp như bình thường
                                if (!ruleChange.Replace.Contains(Constant.NOT_REPLACE))
                                {
                                    convertLine.After = $"{Regex.Replace(targetStringRemovedComment, rule.Find, rule.Replace, RegexOptions.IgnoreCase)}\t{commentPart}";
                                    convertLine.Result = true;
                                }
                            }
                        }
                    }
                    break;
            }
        }

        /// <summary>
        /// Convert Syntax của các dòng lẻ nằm trong Block thuộc file ViewTool.vb
        /// </summary>
        /// <param name="convertLine"></param>
        public static void ConvertSingleLineViewToolRules(ConvertResult convertLine)
        {
            foreach (RuleModel rule in ViewToolRules)
            {
                if (Regex.IsMatch(convertLine.After, rule.Find, RegexOptions.IgnoreCase))
                {
                    if (!string.IsNullOrEmpty(rule.WarningMsgId)) Common.AddMessageID(convertLine, rule.WarningMsgId);

                    if (rule.TodoFlg)
                    {
                        convertLine.MessageIDs.Add(Constant.TodoMsgId);
                        continue;
                    }
                    //Remove phần comment đi
                    string commentPart = string.Empty;
                    string targetStringRemovedComment = string.Empty;
                    bool isSuccess = true;
                    Common.SplitStringByCommand(convertLine.After, rule.Find, ref commentPart, ref targetStringRemovedComment, ref isSuccess);
                    //trong trường hợp sau khi remove phần comment đi và không còn thõa mãn pattern nữa thì return;
                    if (!isSuccess) continue;

                    convertLine.After = $"{Regex.Replace(targetStringRemovedComment, rule.Find, rule.Replace, RegexOptions.IgnoreCase)}\t{commentPart}";
                    if (rule.ID == 6)
                    {
                        vsPrinterName = targetStringRemovedComment.Split(' ')[1];
                    }
                    convertLine.After = convertLine.After.Replace("\\n", "\n").Replace("\\t", "\t");
                    convertLine.Result = true;
                }
            }
        }

        /// <summary>
        /// Thêm các function phục vụ cho print view
        /// </summary>
        /// <param name="fileContent"></param>
        public static void CreateContent(ref List<string> fileContent, string fileName = "")
        {
            var listImport = new List<string>();

            if (fileName.ToLower() == Constant.ConvertVsView.VIEWTOOL)
            {
                listImport = new List<string>()
                {
                    Common.getADDComment(string.Empty),
                    "Imports System.Text",
                    "Imports System.Drawing.Printing",
                    "Imports System.Drawing.Printing.PrinterSettings",
                    "Imports C1.Win.C1Document",
                    "Imports C1.Win.FlexReport",
                    "Imports C1.Win.FlexViewer",
                };
            } else
            {
                listImport = new List<string>()
                {
                    Common.getADDComment(string.Empty),
                };
                if (isPaperKind) listImport.Add("Imports System.Drawing.Printing");
                if (isDashStyle) listImport.Add("Imports C1.Win.C1Document");
                if (isOrientationEnum) listImport.Add("Imports C1.Win.FlexReport");
            }

            if (!String.IsNullOrEmpty(afterGoSub))
            {
                var pr_WKindex = fileContent.IndexOf(fileContent.First(a => a.Contains(afterGoSub+":")));
                var insertWK = "'\\\\TODO: Please move this function to Private Sub";              
                fileContent.Insert(pr_WKindex, insertWK);
                afterGoSub = string.Empty;
            }

            listImport.Add(Common.getCommentEnd(string.Empty));
            if (listImport.Count > 2)
            {
                fileContent.InsertRange(2, listImport);
            }

            var listContentAdd = new List<string>();
            listContentAdd.Add(string.Empty);
            listContentAdd.Add(Common.getADDComment());
            if (isHasPR_WK_Structure)
            {
                var pr_WKindex = fileContent.IndexOf(fileContent.First(a => a.Contains("Structure PR_WK")));
                var listInsertWK = new List<string>()
                {
                    Common.getADDComment("\t\t"),
                    "\t\tDim AL As FieldAlignEnum",
                    "\t\tDim WID As Single",
                    Common.getCommentEnd("\t\t")
                };
                fileContent.InsertRange(pr_WKindex + 1, listInsertWK);
            }
            if (fileName.ToLower() == Constant.ConvertVsView.VIEWTOOL)
            {
                if (isHasFncPrint_First)
                {
                    listContentAdd.AddRange(ViewToolContent.ModifyFncPRN_First(vsPrinterName));
                    listContentAdd.AddRange(ViewToolContent.AddFncIsPaperSize());
                }
                if (isHasFncPRN_XGet && isHasPR_WK_Structure) listContentAdd.AddRange(ViewToolContent.ModifyFncPRN_XGET());
                if (isHasFncPRN_XGet_mm && isHasPR_WK_Structure) listContentAdd.AddRange(ViewToolContent.ModifyFncPRN_XGET_mm());

                listContentAdd.Add("\tPublic pDlg As PrintDialog");
                listContentAdd.Add("\tPublic CustomPaperName As String");
                if (!fileContent.Any(a => a.Contains("P_DevName As String")))
                    listContentAdd.Add("\tPublic P_DevName As String");
                listContentAdd.Add(string.Empty);
                listContentAdd.AddRange(ViewToolContent.AddFncOpenDialogPrint());
                if (isHasFncPRN_END)
                {
                    listContentAdd.AddRange(ViewToolContent.ModifyFncPRN_END(vsPrinterName));
                    listContentAdd.AddRange(ViewToolContent.AddFncCustomPrint(vsPrinterName));
                }
                listContentAdd.AddRange(ViewToolContent.AddFncTextWidthToTwips(vsPrinterName));
                listContentAdd.AddRange(ViewToolContent.AddFncTextHeightToTwips(vsPrinterName));
                listContentAdd.AddRange(ViewToolContent.AddFncRoundFontSize());
            }
            listContentAdd.Add(Common.getCommentEnd());
            if (listContentAdd.Count > 3) {
                fileContent.InsertRange(fileContent.Count - 1,listContentAdd);
            }
            ResetProperties();
        }
        /// <summary>
        /// Reset giá trị properties
        /// </summary>
        private static void ResetProperties()
        {
            isHasFncPrint_First = false;
            isHasFncPRN_XGet = false;
            isHasFncPRN_XGet_mm = false;
            isHasFncPRN_END = false;
            isHasPR_WK_Structure = false;
            isPaperKind = false;
            isDashStyle = false;
            isOrientationEnum = false;
        }
    }
}
