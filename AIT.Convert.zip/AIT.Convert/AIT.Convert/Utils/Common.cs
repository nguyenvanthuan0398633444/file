﻿using AIT.Convert.Messages;
using AIT.Convert.Model;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;

namespace AIT.Convert.Utils
{
    public static class Common
    {
        private static FileInfo ConvertingFile1;
        public static List<ConvertMessage> MessagesList = new List<ConvertMessage>();

        public static FileInfo ConvertingFile { get => ConvertingFile1; set => ConvertingFile1 = value; }

        public static string TabIndent;

        /// <summary>
        /// Get Message
        /// Get Message by messageID
        /// </summary>
        /// <param name="messageID">Message ID</param>
        /// <returns>Return Message String</returns>
        public static string GetMessage(string messageID)
        {
            string message = String.Empty;
            if (messageID == null)
            {
                return message;
            }
            ConvertMessage convertMessage = MessagesList.Where(
                   m => m.ID.Equals(messageID, StringComparison.OrdinalIgnoreCase)).FirstOrDefault();
            message += $"\t'{convertMessage.Value}";
            return message;
        }

        /// <summary>
        /// Get Messages
        /// Get Message by List of messageID
        /// </summary>
        /// <param name="messageID">Message ID</param>
        /// <returns>Return Message String</returns>
        public static string GetMessage(List<string> messageID)
        {
            string message = String.Empty;
            if (!messageID.Any())
            {
                return message;
            }
            foreach (string id in messageID)
            {
                ConvertMessage convertMessage = MessagesList.Where(
                    m => m.ID.Equals(id, StringComparison.OrdinalIgnoreCase)).FirstOrDefault();
                if (convertMessage != null)
                {
                    message += $"\t'{convertMessage.Value}{Environment.NewLine}";
                }
            }
            return message;
        }

        /// <summary>
        /// Add Message
        /// Add Message to Convert Object
        /// </summary>
        /// <param name="messageID">Message ID</param>
        /// <param name="convertObject">Convert Object</param>
        public static void AddMessageID(ConvertResult convertObject, string messageId)
        {
            if (!convertObject.MessageIDs.Contains(messageId))
            {
                convertObject.MessageIDs.Add(messageId);
            }
        }

        /// <summary>
        /// Get Messages
        /// Get Message by List of messageID
        /// </summary>
        /// <param name="messageID">Message ID</param>
        /// <param name="convertObject">Convert Object</param>
        public static bool IsDirectoryEmpty(string path)
        {
            return !Directory.EnumerateFileSystemEntries(path).Any();
        }

        /// <summary>
        /// Check line comment
        /// </summary>
        /// <param name="line"></param>
        /// <returns>Result of Is Comment</returns>
        public static bool IsComment(string line)
        {
            //if (Line.StartsWith("'"))
            if(Regex.IsMatch(line,@"^\s*\'.*") || line.TrimStart().StartsWith("'"))
            {
                return true;
            }
            return false;
        }

        public static string getCommentStart(string tabIndent = "\t", string converterName = "Tool Convert")
        {
            return $"{tabIndent}'{ DateTime.Now:yyyy.MM.dd} UPGRADE S  AIT){converterName}";
        }
        public static string getCommentEnd(string tabIndent = "\t", string converterName = "Tool Convert")
        {
            return $"{tabIndent}'{ DateTime.Now:yyyy.MM.dd} UPGRADE E";
        }

        public static string getADDComment(string tabIndent = "\t", string converterName = "Tool Convert")
        {
            return $"{tabIndent}'{ DateTime.Now:yyyy.MM.dd} UPGRADE ADD AIT){converterName}";
        }

        public static string getDELComment(string tabIndent = "\t", string converterName = "Tool Convert")
        {
            return $"{tabIndent}'{ DateTime.Now:yyyy.MM.dd} UPGRADE DEL AIT){converterName}";
        }

        /// <summary>
        /// Tách chuỗi convertLine thành commentPart và codePart
        /// </summary>
        /// <param name="convertLine">dòng cần tách</param>
        /// <param name="ruleFind"></param>
        /// <param name="commentPart"></param>
        /// <param name="codePart"></param>
        /// <param name="isSucces"></param>
        public static void SplitStringByCommand(string convertLine,string ruleFind, ref string commentPart, ref string codePart, ref bool isSucces)
        {
            codePart = convertLine;
            commentPart = string.Empty;
            if (Regex.IsMatch(convertLine, @"\s+'.*"))
            {
                commentPart = Regex.Match(convertLine, @"\s+'.*").Value;
                codePart = Regex.Replace(convertLine, @"\s+'.*", "");
                Match match = Regex.Match(codePart, ruleFind, RegexOptions.IgnoreCase);
                // Nếu không lỗi thì là True
                isSucces = match.Success;
            }
        }
        /// <summary>
        /// Lấy tabindex của 1 hàng
        /// </summary>
        /// <param name="line"></param>
        /// <returns></returns>
        public static string GetTabIndex(string line)
        {
            return Regex.Match(line, @"^\s*").Value;
        }
        /// <summary>
        /// Thêm block add comment cho 1 line
        /// </summary>
        /// <param name="line"></param>
        /// <returns></returns>
        public static string InsertBlockADDComment(string line)
        {
            var tabIndex = GetTabIndex(line);
            return $"{getADDComment(tabIndex)}\n{line}\n{getCommentEnd(tabIndex)}";
        }
        /// <summary>
        /// Thêm block Del comment cho 1 line cần xóa
        /// </summary>
        /// <param name="line"></param>
        /// <returns></returns>
        public static string InsertBlockDELComment(string line)
        {
            string tabIndent = Common.GetTabIndex(line);
            return  $"{Common.getDELComment(tabIndent)}\n{tabIndent}'{line.Trim()}\n{Common.getCommentEnd(tabIndent)}";
        }
    }
}
