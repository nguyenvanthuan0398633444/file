﻿namespace AIT.Convert.Utils
{
    public static class ConfigUtil
    {
        public enum CONFIG_KEYS
        {
            GENERATE_COMMENT_DOC_DIR,
            GENERATE_COMMENT_OUT_DIR,
            GENERATE_COMMENT_OUT_FILE,
            CONFIG_FOLDER_PATH,
            CONFIG_INPUT_FOLDER_PATH,
            CONFIG_OUTPUT_FOLDER_PATH
        }
    }
}
