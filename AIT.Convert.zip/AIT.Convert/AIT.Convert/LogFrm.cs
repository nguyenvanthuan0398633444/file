﻿using AIT.Convert.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace AIT.Convert
{
    public partial class LogFrm : Form
    {
        public List<Log> Log { get; set; }

        private string OutputPath;

        /// <summary>
        /// Log Form
        /// </summary>
        public LogFrm()
        {
            InitializeComponent();
        }
        /// <summary>
        /// Get Log
        /// Parse Log File line by line to List of Log
        /// </summary>
        /// <param name="txtDestination">Output Path</param>
        /// <returns> Return list of Log </returns>
        public void GetLog(string txtDestination)
        {
            Log = new List<Log>();
            OutputPath = txtDestination;
            if (!File.Exists($"{txtDestination}\\ConvertLog.log"))
            {
                return;
            }
            StreamReader file = new StreamReader($"{txtDestination}\\ConvertLog.log");
            List<string> logs = file.ReadToEnd().Split(new string[] { "-------------------------------" }
                , StringSplitOptions.None).ToList();
            file.Close();
            int index = 0;
            foreach (var log in logs)
            {
                String[] logColumn = log.Split(new string[] { " || ", "\r\n" }, StringSplitOptions.None);
                logColumn = logColumn.Where(x => !string.IsNullOrEmpty(x)).ToArray();
                if (logColumn.Length >= 5)
                {
                    Log.Add(new Log()
                    {
                        Index = index++,
                        Date = logColumn[0] == null ? "" : logColumn[0].Replace("Log Entry : ", ""),
                        FileName = logColumn[1] == null ? "" : logColumn[1],
                        Line = logColumn[2] == null ? "" : logColumn[2],
                        Source = logColumn[3] == null ? "" : logColumn[3].Replace("  ", ""),
                        AfterChange = logColumn[4] == null ? "" : logColumn[4].Replace("  ", ""),
                    }); ;
                }
            }
            return;
        }

        /// <summary>
        /// Load Log Form
        /// </summary>
        private void LogFrm_Load(object sender, EventArgs e)
        {
                dataGridView1.DataSource = this.Log;
                dataGridView1.Columns[0].Width = 60;
                dataGridView1.Columns[1].Width = 250;
                dataGridView1.Columns[2].Width = 120;
                dataGridView1.Columns[3].Width = 80;
                if (dataGridView1.Columns["view"] == null)
                {
                    DataGridViewLinkColumn viewSourceLinkColumn = new DataGridViewLinkColumn();
                    viewSourceLinkColumn.Name = "view";
                    viewSourceLinkColumn.UseColumnTextForLinkValue = true;
                    viewSourceLinkColumn.Text = "View Source";
                    int columnIndex = 6;
                    dataGridView1.Columns.Insert(columnIndex, viewSourceLinkColumn);
                    //dataGridView1.Columns[6].Width = 120;
                }
                dataGridView1.EnableHeadersVisualStyles = false;
                dataGridView1.ColumnHeadersDefaultCellStyle.BackColor = Color.Gray;
        }

        /// <summary>
        /// Show Log
        /// </summary>
        /// <param name="line">Line</param>
        /// <param name="fileName">FileName</param>
        private void ShowLog(int line, string fileName)
        {
            DirectoryInfo DI = new DirectoryInfo(OutputPath);
            //Get files
            List<FileInfo> files = DI.GetFiles($"{fileName}", SearchOption.AllDirectories).ToList();
            var nppReadmePath = Path.Combine(files[0].FullName);
            try
            {
                var sb = new StringBuilder();
                sb.AppendFormat("\"{0}\" -n{1}", nppReadmePath, line);
                Process.Start("Notepad++", sb.ToString());
            }
            catch (Exception)
            {
                MessageBox.Show("Can't Start Notepad++, are you sure you have it installed on you computer ?"
                    , "ERROR!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Process.Start("notepad.exe", nppReadmePath);
            }
        }

        /// <summary>
        /// Handle Show Log Click
        /// </summary>
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex != -1 && e.ColumnIndex == dataGridView1.Columns["view"].Index)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                int line = int.Parse(row.Cells[3].Value.ToString());
                string fileName = row.Cells[2].Value.ToString();
                ShowLog(line, fileName);
            }
        }
    }
}
