﻿using System;

namespace AIT.Convert.Model
{
    public class Log
    {
        public int Index { get; set; }
        public String Date { get; set; }
        public String FileName { get; set; }
        public String Line { get; set; }
        public String Source { get; set; }
        public String AfterChange { get; set; }
    }
}
