﻿namespace AIT.Convert.Model
{
    public class ConvertCondition
    {
        public ConvertCondition(bool hasSpread = false, TypeConvertDB? typeConvertDB = null, TypeConvertRpt? typeConvertRpt = null, TypeConvertDesign? typeConvertDesign = null)
        {
            HasSpread = hasSpread;
            TypeConvertDB = typeConvertDB;
            TypeConvertRpt = typeConvertRpt;
            TypeConvertDesign = typeConvertDesign;
        }

        public bool HasSpread { get; set; }
        public TypeConvertDB? TypeConvertDB { get; set; }
        public TypeConvertRpt? TypeConvertRpt { get; set; }
        public TypeConvertDesign? TypeConvertDesign { get; set; }
    }

    public enum TypeConvertDB
    {
        Oracle,
        SQLServer,
    }
    public enum TypeConvertRpt
    {
        VSPrintToFlexReport,
    }
    public enum TypeConvertDesign
    {
        InputMan,
    }
}
