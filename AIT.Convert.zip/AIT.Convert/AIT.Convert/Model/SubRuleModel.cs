﻿using System;
using System.Collections.Generic;

namespace AIT.Convert.Model
{
    public class SubRuleModel
    {
        public int ID { get; set; }
        public string Pattern { get; set; }
        public bool TodoFlg { get; set; }
        public string WarningMsgId { get; set; }
        public bool HasExtraCondition { get; set; }
        public string ExtraConditionPattern { get; set; }
        public string SubtitutionPattern { get; set; }
        public bool FuncBlockSearchFlag { get; set; }
        public List<string> FuncBlockSearchReplacePattern { get; set; }
       
        public SubRuleModel(string subRuleString)
        {
            string[] subs = subRuleString.Split(new string[] { "##" }, StringSplitOptions.None);
            ID = Int32.Parse(subs[0]);
            Pattern = subs[1];
            TodoFlg = bool.Parse(subs[2]);
            WarningMsgId = subs[3];
            HasExtraCondition = bool.Parse(subs[4]);
            ExtraConditionPattern = subs[5];
            SubtitutionPattern = subs[6];
            FuncBlockSearchFlag = bool.Parse(subs[7]);
            FuncBlockSearchReplacePattern = new List<string>();
            if (FuncBlockSearchFlag && subs.Length > 7)
            {
                for (int i = 7; i < subs.Length; i++)
                {
                    FuncBlockSearchReplacePattern.Add(subs[i]);
                }
            }
        }
    }
}
