﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace AIT.Convert.Model
{
    public class RuleModel
    {
        public int ID { get; set; }
        public bool IsSpread { get; set; }
        public bool TodoFlg { get; set; }
        public string WarningMsgId { get; set; }
        public string Find { get; set; }
        public string Replace { get; set; }
        public List<int> SubRuleIdList { get; set; }
        public RuleModel()
        {
            
        }
        public RuleModel(string ruleString)
        {
            string[] subs = ruleString.Split(new string[] { "##" }, StringSplitOptions.None);
            ID = int.Parse(subs[0]);
            IsSpread = bool.Parse(subs[1]);
            TodoFlg = bool.Parse(subs[2]);
            WarningMsgId = subs[3] == "null"? string.Empty : subs[3];
            Find = subs[4];
            Replace = subs[5];
            List<string> subRuleIds = subs[6].Split(',').ToList();
            SubRuleIdList = new List<int>();
            foreach (string id in subRuleIds)
            {
                if(id != "0") SubRuleIdList.Add(int.Parse(id));
            }
        }
    }
}
