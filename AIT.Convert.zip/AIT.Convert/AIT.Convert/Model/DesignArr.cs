﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AIT.Convert.Model
{
    public class DesignConvertModel
    {
        public DesignConvertModel()
        {
        }

        public DesignConvertModel(string key)
        {
            Key = key;
            Arrs = new List<DesignArr>();
        }

        public string Key { get; set; }
        public List<DesignArr> Arrs { get; set; }
        
    }

    public class DesignArr
    {
        public DesignArr()
        {
        }

        public DesignArr(string name, string index)
        {
            Index = index;
            Name = name;
        }
        public string Index { get; set; }
        public string Name { get; set; }
    }
}
