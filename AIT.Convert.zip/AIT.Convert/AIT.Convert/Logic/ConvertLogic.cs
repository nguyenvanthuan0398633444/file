﻿using AIT.Convert.Const;
using AIT.Convert.Converter;
using AIT.Convert.Model;
using AIT.Convert.Utils;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace AIT.Convert.Logic
{
    public class ConvertLogic
    {
        private ConvertCondition ConvertCondition;
        private bool InFunctionBlock = false;
        private List<ConvertResult> FunctionBlock;

        public ConvertLogic()
        {
            ConvertCondition = new ConvertCondition();
        }

        /// <summary>
        /// Convert file
        /// Convert file from VB6 To VB.Net
        /// </summary>
        /// <param name="file">File</param>
        /// <returns> Return List String of converted Content </returns>
        public bool ConvertFile(FileInfo file, ConvertCondition convertCondition, string inputPath, string outputPath, out string errorReason)
        {
            ConvertCondition = convertCondition;
            try
            {
                FileInfo designFile = SpreadConverter.DesignFiles.Where(a => a.Name.Contains(file.Name.Split('.')[0])).FirstOrDefault();
                ConvertCondition.HasSpread = false;
                if (designFile != null)
                {
                    ConvertCondition.HasSpread = SpreadConverter.CheckHasSpread(designFile);
                    if (convertCondition.TypeConvertDesign != null) 
                        if (!ConvertDesignFile(designFile, inputPath, outputPath)) errorReason = "Fail to convert design file";
                } 

                List<ConvertResult> convertedContent = new List<ConvertResult>();
                using (StreamReader sr = new StreamReader(file.FullName, Encoding.GetEncoding(932)))
                {
                    string line = "";
                    FunctionBlock = new List<ConvertResult>();
                    while ((line = sr.ReadLine()) != null)
                    {
                        ConvertResult convertLine = new ConvertResult(line);
                        ConvertCommentOrEmtpy(convertLine);

                        if (InFunctionBlock)
                        {
                            FunctionBlock.Add(convertLine);
                            if (Regex.IsMatch(convertLine.After, Constant.EndFunctionPattern, RegexOptions.IgnoreCase)
                                || Regex.IsMatch(convertLine.After, Constant.EndSubPattern, RegexOptions.IgnoreCase)
                                || Regex.IsMatch(convertLine.After, Constant.EndStructurePattern, RegexOptions.IgnoreCase))
                            {
                                ConvertBlockOfFunc(convertedContent, file.Name);
                                InFunctionBlock = false;
                            }
                            continue;
                        }

                        if ((Regex.IsMatch(convertLine.After, Constant.FunctionPattern, RegexOptions.IgnoreCase)
                            || Regex.IsMatch(convertLine.After, Constant.SubPattern, RegexOptions.IgnoreCase)
                            || Regex.IsMatch(convertLine.After, Constant.StructurePattern, RegexOptions.IgnoreCase)) && !convertLine.After.Trim().StartsWith("'"))
                        {
                            if (!Regex.IsMatch(line, @"\s+Declare\s+", RegexOptions.IgnoreCase))
                            {
                                FunctionBlock = new List<ConvertResult>();
                                FunctionBlock.Add(convertLine);
                                InFunctionBlock = true;
                                continue;
                            }
                        }

                        if (convertLine.IsNotCode)
                        {
                            convertedContent.Add(convertLine);
                            continue;
                        }

                        ConvertSingleLine(convertLine);
                        convertedContent.Add(convertLine);
                    }
                }

                List<string> fileContent = CreateFileContent(convertedContent, outputPath, file);

                if (ConvertCondition.TypeConvertRpt == TypeConvertRpt.VSPrintToFlexReport)
                {
                    VSViewConverter.CreateContent(ref fileContent, file.Name);
                }
                //add or import content if is database tool file
                if (ConvertCondition.TypeConvertDB == TypeConvertDB.SQLServer)
                {
                    SQLServerConverter.CreateContent(ref fileContent);
                }
                //add or import content if is database tool file
                if (ConvertCondition.TypeConvertDB == TypeConvertDB.Oracle)
                {
                    OracleConverter.CreateContent(ref fileContent);
                }

                WriteFileContent(file, inputPath, outputPath, fileContent);
                errorReason = null;
                return true;
            }
            catch (Exception ex)
            {
                errorReason = string.Format(ex.Message);
                return false;
            }
        }

        private bool ConvertDesignFile(FileInfo file,string inputPath,string outputPath)
        {
            List<ConvertResult> convertedContent = DesignConverter.ConvertFile(file);
            if (convertedContent != null || convertedContent.Count > 0)
            {
                List<string> fileContent = CreateFileContent(convertedContent, outputPath, file);
                DesignConverter.CreateContent(ref fileContent);
                WriteFileContent(file, inputPath, outputPath, fileContent);
                return true;
            }
            return false;
        }

        /// <summary>
        /// Chuyển List string các dòng của file thành string rồi viết file mới vào thư mục
        /// </summary>
        /// <param name="file"></param>
        /// <param name="inputPath"></param>
        /// <param name="outputPath"></param>
        /// <param name="fileContent"></param>
        private void WriteFileContent(FileInfo file, string inputPath, string outputPath, List<string> fileContent)
        {
            StringBuilder content = new StringBuilder();
            foreach (string item in fileContent)
            {
                content.AppendLine(item);
            }
            FileUtils.WriteFile(inputPath, outputPath, file, content.ToString());
        }

        /// <summary>
        /// Chuyển List các convertResult(các dòng sau khi được convert) thành list string chứa các dòng của file mới
        /// </summary>
        /// <param name="convertedContent"></param>
        /// <param name="outputPath"></param>
        /// <param name="file"></param>
        /// <returns></returns>
        private List<string> CreateFileContent(List<ConvertResult> convertedContent, string outputPath, FileInfo file)
        {
            List<string> fileContent = new List<string>();
            List<ConvertResult> convertBlock = new List<ConvertResult>();
            bool lastItemResult = false;
            foreach (ConvertResult item in convertedContent)
            {
                string upgradeMessage = Common.GetMessage(item.MessageIDs);//Lấy message từ list các Id message có trong ConvertResult
                if (item.DelFlg)
                {
                    continue;
                }
                if (lastItemResult)
                {
                    if (item.IsNotCode)
                    {
                        convertBlock.Add(item);
                        continue;
                    }
                    if (item.Result)
                    {
                        convertBlock.Add(item);
                        continue;
                    }
                    else
                    {
                        lastItemResult = false;
                        WrapConvertBlock(convertBlock, fileContent, outputPath, file);
                        convertBlock.Clear();

                        if (!String.IsNullOrEmpty(upgradeMessage))
                        {
                            AddLineToContent(upgradeMessage, fileContent);
                        }
                        AddLineToContent(item.Before, fileContent);
                        continue;
                    }
                }
                else
                {
                    if (item.Result)
                    {
                        lastItemResult = true;
                        convertBlock.Add(item);
                        continue;
                    }
                    else
                    {
                        if (!String.IsNullOrEmpty(upgradeMessage))
                        {
                            AddLineToContent(upgradeMessage, fileContent);
                        }
                        AddLineToContent(item.Before, fileContent);
                        continue;
                    }
                }
            }
            return fileContent;
        }

        /// <summary>
        /// bọc block những dòng được convert có result là true trong block comment start và end
        /// </summary>
        /// <param name="convertBlock"></param>
        /// <param name="fileContent"></param>
        /// <param name="outputPath"></param>
        /// <param name="file"></param>
        private void WrapConvertBlock(List<ConvertResult> convertBlock, List<string> fileContent, string outputPath, FileInfo file)
        {
            if (!convertBlock.Any())
            {
                return;
            }
            // Viết các dòng cũ
            AddLineToContent($"{Common.getCommentStart(Common.GetTabIndex(convertBlock.First().Before))}", fileContent);
            foreach (ConvertResult convertLine in convertBlock)
            {
                string tabIndent = Common.GetTabIndex(convertLine.Before);
                if (convertLine.CommentOut)
                {
                    AddLineToContent($"'{convertLine.Before} {Common.getDELComment()}", fileContent);
                    continue;
                }
                if(!convertLine.Before.Equals(convertLine.After))
                    AddLineToContent($"{tabIndent}'{ convertLine.Before.Trim()}", fileContent);
            }
            //Viết các dòng mới
            foreach (ConvertResult convertLine in convertBlock)
            {
                if (convertLine.CommentOut) continue;

                if (convertLine.AddFlg)
                {
                    AddLineToContent($"{convertLine.After} {Common.getADDComment()}", fileContent);
                    continue;
                }
                //Viết các dòng Message
                string upgradeMessage = Common.GetMessage(convertLine.MessageIDs);//Lấy message từ list các Id message có trong ConvertResult
                if (!String.IsNullOrEmpty(upgradeMessage))
                {
                    AddLineToContent($"{upgradeMessage}", fileContent);
                }
                AddLineToContent($"{convertLine.After}", fileContent);
                //Viết Log
                LogWriter log = new LogWriter($"{file.Name} || {fileContent.Count} " +
              $"|| {convertLine.Before.Replace("\t", "")} || {convertLine.After.Replace("\t", "")}", outputPath);
            }
            AddLineToContent($"{Common.getCommentEnd(Common.GetTabIndex(convertBlock.First().Before))}", fileContent);
        }

        private void AddLineToContent(string line, List<string> fileContent)
        {
            string tabIndent = Common.GetTabIndex(line);
            string[] stringSeparators = new string[] { "\r\n" };
            //string messages = Common.GetMessage(convertLine.MessageID);
            string[] lines = line.Trim().Split(stringSeparators, StringSplitOptions.None);
            foreach (string item in lines)
            {
                fileContent.Add(tabIndent + item.Trim());
            }
        }

        /// <summary>
        /// Phát hiện dòng được đưa vào là dòng trống hoặc dòng comment và convert comment về đúng format
        /// </summary>
        /// <param name="convertLine"></param>
        private void ConvertCommentOrEmtpy(ConvertResult convertLine)
        {
            if (String.IsNullOrEmpty(convertLine.After.Trim()))
            {
                convertLine.IsNotCode = true;
                return;
            }
            if (Common.IsComment(convertLine.After.Trim()))
            {
                convertLine.IsNotCode = true;
                if (Regex.IsMatch(convertLine.After, Constant.CommentUpgradeNotePattern, RegexOptions.IgnoreCase))
                {
                    convertLine.DelFlg = true;
                    return;
                }
                if (Regex.IsMatch(convertLine.After.Trim(), Constant.MultipleQuoteCommentPattern))
                {
                    convertLine.Before = convertLine.After = Regex.Replace(convertLine.Before, Constant.MultipleQuoteCommentPattern, "'");
                }
            }
        }

        /// <summary>
        /// Convert Một Block Function 
        /// </summary>
        /// <param name="convertedContent"></param>
        private void ConvertBlockOfFunc(List<ConvertResult> convertedContent, string filename = "")
        {
            //Convert Các Syntax của Oracle
            if (ConvertCondition.TypeConvertDB == TypeConvertDB.Oracle)
            {
                OracleConverter.CheckAndConvertOracle(FunctionBlock);
            }
            // Không thực hiện convert try catch cho file database connection của oracle
            if (!OracleConverter.isDbConnection)
            {
                //Convert Các ErrorHandler cũ thành Dạng Try catch
                VbConverter.ConvertTryCatch(FunctionBlock);
            }
           
            foreach (ConvertResult convertLine in FunctionBlock)
            {
                if (convertLine.IsNotCode) continue;
                
                try
                {
                    if (convertLine.Equals(FunctionBlock.First()))
                    {
                        VSViewConverter.CheckViewToolFunction(convertLine, FunctionBlock, filename);
                        // Convert function param
                        OracleConverter.ConvertBlockFuncVb(convertLine, FunctionBlock);
                        SQLServerConverter.ConvertBlockFuncVb(convertLine, FunctionBlock);
                        InputManConverter.ConvertHandlesEventFunction(FunctionBlock.First());
                    }

                    if (convertLine.Equals(FunctionBlock.First()) || convertLine.Equals(FunctionBlock.Last()))  continue;
                    
                    //Convert dòng code có định dạng Declaration (dạng khai báo biến)
                    if (DeclareConverter.CheckDeclaration(convertLine.After))
                    {
                        DeclareConverter.ConvertDeclaration(convertLine);
                        DeclareConverter.CheckAndConvertLUBound(convertLine, FunctionBlock); //Trường hợp Đặc biệt 1 : chuyển Object thành Long
                        DeclareConverter.CheckAndConvertVbFixedString(convertLine, FunctionBlock); //Trường hợp Đặc biệt 2 : chuyển FixedLengthString thành String
                        DeclareConverter.CheckAndConvertVbFixedArr(convertLine, FunctionBlock);
                    }

                    VbConverter.ConvertBlockFuncVb(convertLine, FunctionBlock);
                    // Convert VSView to Flex report
                    if (ConvertCondition.TypeConvertRpt == TypeConvertRpt.VSPrintToFlexReport)
                    {
                        VSViewConverter.ConvertBlockFuncVb(convertLine, FunctionBlock);
                    }
                    // Convert spread
                    if (ConvertCondition.HasSpread)
                    {
                        SpreadConverter.ConvertSpread(convertLine);
                    }
                    // Convert SQl server
                    if (ConvertCondition.TypeConvertDB == TypeConvertDB.SQLServer)
                    {
                        SQLServerConverter.ConvertBlockFuncVb(convertLine, FunctionBlock);
                    }
                    // Convert oracle 
                    if (ConvertCondition.TypeConvertDB == TypeConvertDB.Oracle)
                    {
                        OracleConverter.ConvertBlockFuncVb(convertLine, FunctionBlock);
                    }
                    // Convert input man 
                    if (ConvertCondition.TypeConvertDesign == TypeConvertDesign.InputMan)
                    {
                        InputManConverter.ConvertBlockFuncVb(convertLine, FunctionBlock);
                    }
                }
                catch
                {
                    convertLine.Result = false;
                    convertLine.After = convertLine.Before;
                    Common.AddMessageID(convertLine, Constant.ErrorMsgID);
                }
            }
            AddConvertedBlockToContent(convertedContent);
        }

        /// <summary>
        /// Copy dữ liệu từ block fucntion đã được convert vào content của file
        /// </summary>
        /// <param name="convertedContent"></param>
        private void AddConvertedBlockToContent(List<ConvertResult> convertedContent)
        {
            foreach (ConvertResult convertLine in FunctionBlock)
            {
                convertedContent.Add(convertLine);
            }
            FunctionBlock.Clear();
        }

        /// <summary>
        /// Convert những dòng lẻ (thường thì chỉ có định dạng là khai báo hoặc thay đổi một vài syntax của Vb.)
        /// </summary>
        /// <param name="convertLine"></param>
        private void ConvertSingleLine(ConvertResult convertLine)
        {
            if (DeclareConverter.CheckDeclaration(convertLine.After))
            {
                DeclareConverter.ConvertDeclaration(convertLine);
            }
            VbConverter.ConvertSingleLineVbRules(convertLine);
            // Convert VSView to Flex report
            if (ConvertCondition.TypeConvertRpt == TypeConvertRpt.VSPrintToFlexReport)
            {
                VSViewConverter.ConvertSingleLineVsViewRules(convertLine);
            }
            // Convert SQl server
            if (ConvertCondition.TypeConvertDB == TypeConvertDB.SQLServer)
            {
                SQLServerConverter.ConvertSingleLineSQlServeRules(convertLine);
            }
            // Convert Oracle
            if (ConvertCondition.TypeConvertDB == TypeConvertDB.Oracle)
            {
                OracleConverter.ConvertSingleLineOracleRules(convertLine);
            }
            // Convert input man
            if (ConvertCondition.TypeConvertDesign == TypeConvertDesign.InputMan)
            {
                InputManConverter.ConvertSingleLine(convertLine);
            }
        }
    }
}
