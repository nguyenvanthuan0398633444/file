﻿using System;

namespace AIT.Convert.Messages
{
    public class ConvertMessage
    {
        public string ID { get; set; }
        public string Value { get; set; }

        public ConvertMessage(string messageString)
        {
            string[] subs = messageString.Split(new string[] { "##" }, StringSplitOptions.None);
            ID = subs[0];
            Value = subs[1];
        }
    }
}
