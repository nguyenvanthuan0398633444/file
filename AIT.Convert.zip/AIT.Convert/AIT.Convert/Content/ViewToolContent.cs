﻿using System.Collections.Generic;

namespace AIT.Convert.Content
{
    public static class ViewToolContent
    {
        public static List<string> ModifyFncPRN_First(string vsPrinterName)
        {
            var name = string.IsNullOrEmpty(vsPrinterName) ? "PRN" : vsPrinterName;
            var fileContent = new List<string>
            {
				string.Empty,
                "\tPublic sDetail As Section",
                "\tPublic P_COUNT As Integer 'PAGE COUNT ",
                "\t",
                "\t'-------------------------------------------------------------------------------",
                "\t'   処理    :   印刷処理初期設定",
                "\t'   関数    :   Function     PRN_First(ViewFrm,PhysFlg)",
                "\t'   引数    :   ViewFrm      Object      プレビューフォーム",
                "\t'   　　        PhysFlg      Boolean     ページサイズ（物理的 = True）",
                "\t'   　　        SHeight      Single      用紙高さ",
                "\t'   　　        SWidth       Single      用紙幅",
                "\t'   　　        PrnBin       Integer     用紙トレー",
                "\t'   戻値    :   True         正常終了",
                "\t'   　　        False        異常終了",
                "\t'   機能    :   印刷処理の初期設定を行う。",
                "\t'-------------------------------------------------------------------------------",
                "\tPublic Function PRN_First(ByRef ViewFrm As Object, Optional ByVal PhysFlg As Boolean = False, Optional ByVal sHeight As Single = 0, Optional ByVal sWidth As Single = 0, Optional ByVal iDuplex As Duplex = Printing.Duplex.Default) As Boolean",
                "\t\tDim printSt = PrinterSettings.InstalledPrinters",
                "\t\tDim flxViewer As C1FlexViewer = ViewFrm.C1FlexViewer1",
                "",
                "\t\tOn Error Resume Next",
                "\t\t'戻り値の初期化",
                "\t\tPRN_First = False",
                "",
                "\t\t'中断フラグの初期化",
                "\t\tPrnCancel = 0",
                string.IsNullOrEmpty(vsPrinterName) ?"\t\t'\\\\TODO: Confirm property name of \"PRN\"" : "",
                $"\t\t{name} = New C1FlexReport()",
                "\t\tP_COUNT = 0",
                $"\t\t{name}.Layout.MarginTop = 0",
                $"\t\t{name}.Layout.MarginBottom = 0",
                $"\t\t{name}.Layout.MarginLeft = 0",
                $"\t\t{name}.Layout.MarginRight = 0",
                $"\t\tsDetail = {name}.Sections(SectionTypeEnum.Detail)",
                "\t\tsDetail.AutoHeight = AutoSizeBehavior.GrowAndShrink  'default : CanGrow",
                "\t\tsDetail.Visible = True",
                "",
                $"\t\tWith {name}",
                "\t\t\t.ReportName = DocName",
                "\t\t\tflxViewer.StatusText = DocName",
                "\t\t\t.Font.Name = FNT_MSM",
                "\t\t\t.Font.Size = F_Size",
                "\t\t\tflxViewer.PageSettings.PrinterSettings.PrinterName = P_DevName",
                "\t\t\tDim paperSourceCollection = flxViewer.PageSettings.PrinterSettings.PaperSizes",
                "",
                "\t\t\tIf IsPaperSize(paperSourceCollection, P_SIZE) Then",
                "\t\t\t\tIf P_SIZE <> 0 Then",
                $"\t\t\t\t\t{name}.Layout.PaperSize = P_SIZE",
                "\t\t\t\t\tflxViewer.ZoomFactor = 1",
                "\t\t\t\tEnd If",
                "\t\t\tElse",
                "\t\t\t\tMsgBox(\"用紙サイズを設定できませんでした。\", MsgBoxStyle.Exclamation, Application.OpenForms(0).Text)",
                "\t\t\t\tCall PRN_ErrEnd()",
                "\t\t\t\tExit Function",
                "\t\t\tEnd If",
                "",
                "\t\t.Layout.Orientation = P_ORIENT",
                "\t\tIf.Layout.Orientation<> P_ORIENT Then",
                "\t\t\tMsgBox(\"用紙方向を設定できませんでした。\", MsgBoxStyle.Exclamation, Application.OpenForms(0).Text)",
                "\t\t\tCall PRN_ErrEnd()",
                "\t\t\tExit Function",
                "\t\tEnd If",
                "",
                "\t\t\tflxViewer.PageSettings.Landscape = If(P_ORIENT = OrientationEnum.Landscape, True, False)",
                "\t\t\tflxViewer.PageSettings.PrinterSettings.Duplex = iDuplex",
                "\t\t\tP_XX = TextWidthToTwips(\"M\")",
                "\t\t\tP_YY = TextHeightToTwips(\"M\")",
                "\t\t\tP_HEIGHT = .PageSettings.Height.Value '高さ",
                "\t\t\tP_WIDTH = .PageSettings.Width.Value '幅",
                "\t\tEnd With",
                "",
                "\t\tIf ViewFlg = True Then",
                "\t\t\tViewFrm.Text = DocName & \"を出力中...\"",
                "\t\t\t'2021.08.12 UPGRADE E",
                "\t\tElse",
                "\t\t\tViewFrm.Hide()",
                "\t\tEnd If",
                "\t\t'正常終了",
                "\t\tPRN_First = True",
                "\tEnd Function"
            };
            return fileContent;
        }

        public static List<string> ModifyFncPRN_XGET()
        {
            var fileContent = new List<string>();
            fileContent.Add(string.Empty);
            fileContent.Add("\t'-------------------------------------------------------------------------------");
            fileContent.Add("\t'   処理    :   印刷開始位置取得処理");
            fileContent.Add("\t'   関数    :   Function    PRN_XGet(FG,XX1,XX2,FSIZE,DT)");
            fileContent.Add("\t'   引数    :   FG          Integer     印刷位置    0:左詰め  1:中央揃え  2:右詰め");
            fileContent.Add("\t'   　　        XX1         Single      印刷開始位置");
            fileContent.Add("\t'   　　        XX2         Single      印刷終了位置");
            fileContent.Add("\t'   　　        FSIZE       Single      現設定フォントサイズ");
            fileContent.Add("\t'   　　        DT          String      印刷データ");
            fileContent.Add("\t'   戻値    :   印刷開始位置");
            fileContent.Add("\t'   機能    :   印刷データを指定位置に印刷する為のポイントを取得する。");
            fileContent.Add("\t'-------------------------------------------------------------------------------");
            fileContent.Add("\tPublic Sub PRN_XGet(ByVal FG As Short, ByVal XX1 As Single, ByVal XX2 As Single, ByRef PR_WK_Renamed As PR_WK)");
            fileContent.Add("\t\tDim psiP_XX = TextWidthToTwips(\"M\", PR_WK_Renamed.FS)");
            fileContent.Add("\t\tPR_WK_Renamed.X = XX1 + psiP_XX / 2");
            fileContent.Add("\t\tSelect Case FG");
            fileContent.Add("\t\t\t'左詰め");
            fileContent.Add("\t\t\tCase 0");
            fileContent.Add("\t\t\t\tPR_WK_Renamed.AL = FieldAlignEnum.LeftMiddle");
            fileContent.Add("\t\t\t'中央揃え");
            fileContent.Add("\t\t\tCase 1");
            fileContent.Add("\t\t\t\tPR_WK_Renamed.AL = FieldAlignEnum.CenterMiddle");
            fileContent.Add("\t\t\t'右詰め");
            fileContent.Add("\t\t\tCase 2");
            fileContent.Add("\t\t\t\tPR_WK_Renamed.AL = FieldAlignEnum.RightMiddle");
            fileContent.Add("\t\tEnd Select");
            fileContent.Add("\t\tPR_WK_Renamed.WID = XX2 - XX1 - psiP_XX");
            fileContent.Add("\tEnd Sub");
            return fileContent;
        }
        public static List<string> ModifyFncPRN_XGET_mm()
        {
            var fileContent = new List<string>();
            fileContent.Add(string.Empty);
            fileContent.Add("\t'-------------------------------------------------------------------------------");
            fileContent.Add("\t'   処理    :   印刷開始位置取得処理（ミリメートル指定）");
            fileContent.Add("\t'   関数    :   Function    PRN_XGet(FG,XX1,XX2,FSIZE,DT)");
            fileContent.Add("\t'   引数    :   FG          Integer     印刷位置    0:左詰め  1:中央揃え  2:右詰め");
            fileContent.Add("\t'   　　        XX1         Single      印刷開始位置");
            fileContent.Add("\t'   　　        XX2         Single      印刷終了位置");
            fileContent.Add("\t'   　　        DT          String      印刷データ");
            fileContent.Add("\t'   戻値    :   印刷開始位置");
            fileContent.Add("\t'   機能    :   印刷データを指定位置に印刷する為のポイントを取得する。");
            fileContent.Add("\t'-------------------------------------------------------------------------------");
            fileContent.Add("\tPublic Function PRN_XGet_mm(ByRef FG As Short, ByRef XX1 As Single, ByRef XX2 As Single, ByRef PR_WK_Renamed As PR_WK) As Single");
            fileContent.Add("\t\tDim psiP_XX = TextWidthToTwips(\"M\")");
            fileContent.Add("\t\tPR_WK_Renamed.X = ((XX1 * 56.7) + psiP_XX / 2) / 56.7");
            fileContent.Add("\t\tSelect Case FG");
            fileContent.Add("\t\t\t'左詰め");
            fileContent.Add("\t\t\tCase 0");
            fileContent.Add("\t\t\t\tPR_WK_Renamed.AL = FieldAlignEnum.LeftMiddle");
            fileContent.Add("\t\t\t'中央揃え");
            fileContent.Add("\t\t\tCase 1");
            fileContent.Add("\t\t\t\tPR_WK_Renamed.AL = FieldAlignEnum.CenterMiddle");
            fileContent.Add("\t\t\t'右詰め");
            fileContent.Add("\t\t\tCase 2");
            fileContent.Add("\t\t\t\tPR_WK_Renamed.AL = FieldAlignEnum.RightMiddle");
            fileContent.Add("\t\tEnd Select");
            fileContent.Add("\t\tPR_WK_Renamed.WID = XX2 * 56.7 - XX1 * 56.7 - psiP_XX");
            fileContent.Add("\tEnd Function");
            return fileContent;
        }
        public static List<string> ModifyFncPRN_END(string vsPrinterName)
        {
            var name = string.IsNullOrEmpty(vsPrinterName) ? "PRN" : vsPrinterName;
            var fileContent = new List<string>();
            fileContent.Add(string.Empty);
            fileContent.Add("\t'-------------------------------------------------------------------------------");
            fileContent.Add("\t'   処理    :   印刷終了処理");
            fileContent.Add("\t'   関数    :   Sub     PRN_END()");
            fileContent.Add("\t'   機能    :   印刷終了処理を行う。");
            fileContent.Add("\t'-------------------------------------------------------------------------------");
            fileContent.Add("\tPublic Sub PRN_END()");
            fileContent.Add("\t\t'----- 印刷");
            fileContent.Add("\t\tIf P_COUNT > 0 Then");
            if (string.IsNullOrEmpty(vsPrinterName))
                fileContent.Add("\t\t'\\\\TODO: Confirm property name of \"PRN\"");
            fileContent.Add($"\t\t\t{name}.Sections.Detail.Height = (P_COUNT + 1) * P_HEIGHT");
            fileContent.Add("\t\tElse");
            fileContent.Add($"\t\t\t{name}.Sections.Detail.Height = P_HEIGHT");
            fileContent.Add("\t\tEnd If");
            fileContent.Add("\t\t'\\\\ TODO: Confirm name \"C1FlexViewer1\" of ViewForm");
            fileContent.Add($"\t\tViewForm.C1FlexViewer1.DocumentSource = {name}");
            fileContent.Add("\t\tP_COUNT = 0");
            fileContent.Add("\t\tIf ViewFlg = True Then");
            fileContent.Add("\t\t\tSystem.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default");
            fileContent.Add("\t\t\tViewForm.ShowDialog()");
            fileContent.Add("\t\tElse");
            fileContent.Add("\t\t\tIf pDlg Is Nothing Then");
            fileContent.Add("\t\t\t\tCustomPrint(False)");
            fileContent.Add("\t\t\tElse");
            fileContent.Add("\t\t\t\tCustomPrint(True)");
            fileContent.Add("\t\t\tEnd If");
            fileContent.Add("\t\t\tViewForm.Close()");
            fileContent.Add("\t\tEnd If");
            fileContent.Add($"\t\t{name} = Nothing");
            fileContent.Add("\tEnd Sub");
            return fileContent;
        }

        public static List<string> AddFncTextWidthToTwips(string vsPrinterName)
        {
            var name = string.IsNullOrEmpty(vsPrinterName) ? "PRN" : vsPrinterName;
            var fileContent = new List<string>();
            fileContent.Add(string.Empty);
            fileContent.Add("\t'-------------------------------------------------------------------------------");
            fileContent.Add("\t'   処理    :   Get text width                                                  ");
            fileContent.Add("\t'   関数    :   Function         TextWidthToTwips(text)                         ");
            fileContent.Add("\t'   引数    :   text       String                                               ");
            fileContent.Add("\t'   機能    :                                                                   ");
            fileContent.Add("\t'-------------------------------------------------------------------------------");
            fileContent.Add("\tPublic Function TextWidthToTwips(text As String, Optional fontSize As Single = 0) As Single");
            if (string.IsNullOrEmpty(vsPrinterName)) 
                fileContent.Add("\t\t'\\\\TODO: Confirm property name of \"PRN\"");

            fileContent.Add("\t\tIf fontSize = 0 Then");
            fileContent.Add("\t\t\tfontSize = " + name + ".Font.Size");
            fileContent.Add("\t\tEnd If");
            fileContent.Add("\t\tDim font As Font");
            fileContent.Add("\t\tfont = New Font(" + name + ".Font.Name, fontSize, FontStyle.Regular, GraphicsUnit.Point, 128)");
            fileContent.Add("\t\tDim g As Graphics = ViewForm.CreateGraphics()");
            fileContent.Add("\t\tg.PageUnit = GraphicsUnit.Point");
            fileContent.Add("\t\t'A twip = 1/20 point");
            fileContent.Add("\t\tDim w As Single = 20 * g.MeasureString(text, Font, -1, StringFormat.GenericTypographic).Width");
            fileContent.Add("\t\tIf 0F = w Then");
            fileContent.Add("\t\t\t' encoding shift-JIS");
            fileContent.Add("\t\t\tDim countBytes As Integer = Encoding.GetEncoding(932).GetBytes(text).Length");
            fileContent.Add("\t\t\tDim strByByte As New String(\"M\", countBytes)");
            fileContent.Add("\t\t\tw = 20 * g.MeasureString(strByByte, Font, -1, StringFormat.GenericTypographic).Width");
            fileContent.Add("\t\tEnd If");
            fileContent.Add("\t\tReturn w");
            fileContent.Add("\tEnd Function");
            return fileContent;
        }

        public static List<string> AddFncTextHeightToTwips(string vsPrinterName)
        {
            var name = string.IsNullOrEmpty(vsPrinterName) ? "PRN" : vsPrinterName;
            var fileContent = new List<string>();
            fileContent.Add(string.Empty);
            fileContent.Add("\t'-------------------------------------------------------------------------------");
            fileContent.Add("\t'   処理    :   Get text width                                                  ");
            fileContent.Add("\t'   関数    :   Function         TextHeightToTwips(text)                         ");
            fileContent.Add("\t'   引数    :   text       String                                               ");
            fileContent.Add("\t'   機能    :                                                                   ");
            fileContent.Add("\t'-------------------------------------------------------------------------------");
            fileContent.Add("\tPublic Function TextHeightToTwips(text As String, Optional fontSize As Single = 0) As Single");
            if (string.IsNullOrEmpty(vsPrinterName))
                fileContent.Add("\t\t'\\\\TODO: Confirm property name of \"PRN\"");

            fileContent.Add("\t\tIf fontSize = 0 Then");
            fileContent.Add("\t\t\tfontSize = " + name + ".Font.Size");
            fileContent.Add("\t\tEnd If");
            fileContent.Add("\t\tDim font As Font");
            fileContent.Add("\t\tfont = New Font(" + name + ".Font.Name, fontSize, FontStyle.Regular, GraphicsUnit.Point, 128)");
            fileContent.Add("\t\tDim g As Graphics = ViewForm.CreateGraphics()");
            fileContent.Add("\t\tg.PageUnit = GraphicsUnit.Point");
            fileContent.Add("\t\t'A twip = 1/20 point");
            fileContent.Add("\t\tDim h As Single = 20 * g.MeasureString(text, font, -1, StringFormat.GenericTypographic).Height");
            fileContent.Add(string.Empty);
            fileContent.Add("\t\tReturn h");
            fileContent.Add("\tEnd Function");
            return fileContent;
        }

        public static List<string> AddFncRoundFontSize()
        {
            var fileContent = new List<string>();
            fileContent.Add(string.Empty);
            fileContent.Add("\t'-------------------------------------------------------------------------------");
            fileContent.Add("\t'   処理    :   Round FontSize");
            fileContent.Add("\t'   関数    :   Function         RoundFontSize(size)");
            fileContent.Add("\t'   引数    :   size       Single ");
            fileContent.Add("\t'   機能    :   ");
            fileContent.Add("\t'-------------------------------------------------------------------------------");
            fileContent.Add("\tPrivate Function RoundFontSize(size As Single) As Single");
            fileContent.Add("\t\tDim int As Integer = size * 10 \\ 10");
            fileContent.Add("\t\tDim dec As Integer = size * 10 Mod 10");
            fileContent.Add("\t\tDim decRound As Single");
            fileContent.Add(string.Empty);
            fileContent.Add("\t\tSelect Case dec");
            fileContent.Add("\t\t\tCase 0");
            fileContent.Add("\t\t\t\tint -= 1");
            fileContent.Add("\t\t\t\tdecRound = 0.75");
            fileContent.Add("\t\t\tCase 2");
            fileContent.Add("\t\t\t\tdecRound = 0");
            fileContent.Add("\t\t\tCase 4");
            fileContent.Add("\t\t\t\tdecRound = 0.25");
            fileContent.Add("\t\t\tCase 6");
            fileContent.Add("\t\t\t\tdecRound = 0.25");
            fileContent.Add("\t\t\tCase 8");
            fileContent.Add("\t\t\t\tdecRound = 0.5");
            fileContent.Add("\t\tEnd Select");
            fileContent.Add(string.Empty);
            fileContent.Add("\t\tReturn int + decRound");
            fileContent.Add("\tEnd Function");
            return fileContent;
        }

        public static List<string> AddFncIsPaperSize()
        {
            var fileContent = new List<string>();
            fileContent.Add(string.Empty);
            fileContent.Add("\t'-------------------------------------------------------------------------------");
            fileContent.Add("\t'   処理    :   Check PaperSize");
            fileContent.Add("\t'   関数    :   Function         IsPaperSize(paperSizeCollection, paperKind)");
            fileContent.Add("\t'   引数    :   paperSizeCollection       PaperSizeCollection ");
            fileContent.Add("\t'   　　        paperKind   PaperKind");
            fileContent.Add("\t'   機能    :   ");
            fileContent.Add("\t'-------------------------------------------------------------------------------");
            fileContent.Add("\tPrivate Function IsPaperSize(paperSizeCollection As PaperSizeCollection, paperKind As PaperKind) As Boolean");
            fileContent.Add("\t\tDim result = False");
            fileContent.Add("\t\tFor Each item As PaperSize In paperSizeCollection");
            fileContent.Add("\t\t\tIf item.Kind = paperKind Then");
            fileContent.Add("\t\t\t\tresult = True");
            fileContent.Add("\t\t\t\tExit For");
            fileContent.Add("\t\t\tEnd If");
            fileContent.Add("\t\tNext");
            fileContent.Add("\t\tReturn result");
            fileContent.Add("\tEnd Function");
            return fileContent;
        }

        public static List<string> AddFncOpenDialogPrint()
        {
            var fileContent = new List<string>();
            fileContent.Add(string.Empty);
            fileContent.Add("\t'----------------------------------------------------------------------");
            fileContent.Add("\t' サブルーチン名          OpenDialogPrint");
            fileContent.Add("\t'");
            fileContent.Add("\t' 戻値     印刷設定ダイアログ");
            fileContent.Add("\t'----------------------------------------------------------------------");
            fileContent.Add("\tPublic Function OpenDialogPrint() As Boolean");
            fileContent.Add("\t\tDim C1FlexReport1 As New C1FlexReport");
            fileContent.Add("\t\t' レポート描画");
            fileContent.Add("\t\tC1FlexReport1.Render()");
            fileContent.Add(string.Empty);
            fileContent.Add("\t\t' .NET標準の印刷設定ダイアログ");
            fileContent.Add("\t\tpDlg = New PrintDialog");
            fileContent.Add("\t\tpDlg.UseEXDialog = True");
            fileContent.Add(string.Empty);
            fileContent.Add("\t\t' ページ指定を可能にします");
            fileContent.Add("\t\tpDlg.AllowSomePages = True");
            fileContent.Add("\t\tpDlg.PrinterSettings.FromPage = 1");
            fileContent.Add("\t\tpDlg.PrinterSettings.ToPage = C1FlexReport1.PageCount");
            fileContent.Add("\t\tFor Each item As PaperSize In pDlg.PrinterSettings.PaperSizes");
            fileContent.Add("\t\t\tIf item.Kind = P_SIZE Then");
            fileContent.Add("\t\t\t\tpDlg.PrinterSettings.DefaultPageSettings.PaperSize = item");
            fileContent.Add("\t\t\t\tExit For");
            fileContent.Add("\t\t\tEnd If");
            fileContent.Add("\t\tNext");
            fileContent.Add("\t\tIf P_ORIENT = OrientationEnum.Landscape Then pDlg.PrinterSettings.DefaultPageSettings.Landscape = True Else pDlg.PrinterSettings.DefaultPageSettings.Landscape = False");
            fileContent.Add(string.Empty);
            fileContent.Add("\t\t' ダイアログ表示");
            fileContent.Add("\t\tIf pDlg.ShowDialog = DialogResult.OK Then");
            fileContent.Add("\t\t\tP_SIZE = pDlg.PrinterSettings.DefaultPageSettings.PaperSize.Kind");
            fileContent.Add("\t\t\tIf pDlg.PrinterSettings.DefaultPageSettings.Landscape Then");
            fileContent.Add("\t\t\t\tP_ORIENT = OrientationEnum.Landscape");
            fileContent.Add("\t\t\tElse");
            fileContent.Add("\t\t\t\tP_ORIENT = OrientationEnum.Portrait");
            fileContent.Add("\t\t\tEnd If");
            fileContent.Add("\t\t\tReturn True");
            fileContent.Add("\t\tEnd If");
            fileContent.Add("\t\tReturn False");
            fileContent.Add("\tEnd Function");
            return fileContent;
        }

        public static List<string> AddFncCustomPrint(string vsPrinterName)
        {
            var name = string.IsNullOrEmpty(vsPrinterName) ? "PRN" : vsPrinterName;
            var fileContent = new List<string>();
            fileContent.Add(string.Empty);
            fileContent.Add("\t'----------------------------------------------------------------------");
            fileContent.Add("\t' サブルーチン名          CustomPrint");
            fileContent.Add("\t'");
            fileContent.Add("\t' 戻値     印刷");
            fileContent.Add("\t'----------------------------------------------------------------------");
            fileContent.Add("\tPublic Sub CustomPrint(ByVal dialogFlg As Boolean)");
            fileContent.Add("\t\t'\\\\TODO: Confirm property name of \"PRN\"");
            fileContent.Add($"\t\t{name}.Render()");
            fileContent.Add("\t\tIf dialogFlg = False Then");
            fileContent.Add("\t\t\tpDlg = New PrintDialog");
            fileContent.Add("\t\tEnd If");
            fileContent.Add("\t\tpDlg.UseEXDialog = True");
            fileContent.Add(string.Empty);
            fileContent.Add("\t\t' ページ指定を可能にします");
            fileContent.Add("\t\tpDlg.AllowSomePages = True");
            fileContent.Add("\t\tpDlg.PrinterSettings.FromPage = 1");
            fileContent.Add($"\t\tpDlg.PrinterSettings.ToPage = {name}.PageCount");
            fileContent.Add("\t\tFor Each item As PaperSize In pDlg.PrinterSettings.PaperSizes");
            fileContent.Add("\t\t\tIf item.Kind = P_SIZE Then");
            fileContent.Add("\t\t\t\tpDlg.PrinterSettings.DefaultPageSettings.PaperSize = item");
            fileContent.Add("\t\t\t\tExit For");
            fileContent.Add("\t\t\tEnd If");
            fileContent.Add("\t\tNext");
            fileContent.Add("\t\tIf P_ORIENT = OrientationEnum.Landscape Then pDlg.PrinterSettings.DefaultPageSettings.Landscape = True Else pDlg.PrinterSettings.DefaultPageSettings.Landscape = False");
            fileContent.Add("\t\tpDlg.PrinterSettings.PrinterName = P_DevName");
            fileContent.Add(string.Empty);
            fileContent.Add($"\t{name}.Print(pDlg.PrinterSettings)");
            fileContent.Add("\tEnd Sub");
            return fileContent;
        }
    }
}
